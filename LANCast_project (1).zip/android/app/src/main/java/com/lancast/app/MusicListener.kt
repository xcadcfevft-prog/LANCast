package com.lancast.app

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * 「通知使用权」服务。
 *
 * 安卓不允许普通应用读取别的音乐 App 的歌名 / 封面 / 进度，也不允许控制它们播放；唯一的正规途径是
 * MediaSessionManager.getActiveSessions(listenerComponent)，而它要求调用方是一个已被用户授予「通知使用权」的 NotificationListenerService。
 * 没授权时沉浸音乐照样能把声音传过去，只是没有歌名封面、不能远程控制。
 *
 * 歌词：很多国内音乐 App 打开「状态栏歌词」后，会把当前这一句歌词放在通知的 tickerText 里，并带上 Flyme 状态栏歌词的标志位
 * （FLAG_ALWAYS_SHOW_TICKER 0x01000000 / FLAG_ONLY_UPDATE_TICKER 0x02000000）。本服务只认带这个标志位的通知，且只取 tickerText 这一句，
 * 交给 LyricTap；其它通知的任何内容都不读、不存。
 */
class MusicListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        try {
            val sink = LyricTap.sink ?: return
            val n = sbn?.notification ?: return
            if ((n.flags and LyricTap.FLAG_TICKER_LYRIC) == 0) return
            val line = n.tickerText?.toString()?.trim() ?: return
            if (line.isEmpty() || line.length > 300) return
            sink(sbn.packageName ?: "", line)
        } catch (ignored: Throwable) { }
    }
}

/** 沉浸音乐进行时由 MusicService 挂上 sink；没挂（没在沉浸音乐）时通知一律忽略。 */
object LyricTap {
    const val FLAG_TICKER_LYRIC = 0x01000000 or 0x02000000
    @Volatile var sink: ((String, String) -> Unit)? = null
}
