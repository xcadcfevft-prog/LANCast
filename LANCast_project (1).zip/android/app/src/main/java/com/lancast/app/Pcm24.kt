package com.lancast.app

/**
 * 24 bit 音频辅助：优先让 AudioRecord 以 ENCODING_PCM_FLOAT 采集（float 的 24 位尾数可无损承载 24 bit），
 * 量化成 24 bit 有符号整数后，按 s24le（3 字节 / 样本，小端）打包发送；协议里的 fmt = "s24"。
 * 设备不支持 float 采集时由 PcmCapture 退回 16 bit 采集，左移 8 位补成 24 bit 再发，传输格式不变（电脑端无需改动）。
 */
object Pcm24 {
    const val BYTES = 3
    const val SCALE = 8388608f                 // 2^23

    /** 浮点 [-1,1] → 24 bit 有符号整数 */
    fun toS24(f: Float): Int {
        val v = Math.round(f * SCALE)
        return if (v > 8388607) 8388607 else if (v < -8388608) -8388608 else v
    }

    /** 把 n 个浮点采样写成 s24le 字节，返回写入的字节数 */
    fun floatsToS24le(src: FloatArray, n: Int, dst: ByteArray, off: Int): Int {
        var o = off
        for (i in 0 until n) {
            val v = toS24(src[i])
            dst[o++] = v.toByte(); dst[o++] = (v shr 8).toByte(); dst[o++] = (v shr 16).toByte()
        }
        return n * BYTES
    }

    /** 16 bit 兜底：16 bit → 24 bit（左移 8 位，满量程对齐） */
    fun s16ToS24(v: Short): Int = v.toInt() shl 8

    /** 24 bit → 16 bit（AudioTrack 不支持 float 时的播放兜底） */
    fun s24ToS16(v: Int): Short = (v shr 8).toShort()

    /** 把 n 个 16 bit 采样写成 s24le 字节，返回写入的字节数 */
    fun shortsToS24le(src: ShortArray, n: Int, dst: ByteArray, off: Int): Int {
        var o = off
        for (i in 0 until n) {
            val v = s16ToS24(src[i])
            dst[o++] = v.toByte(); dst[o++] = (v shr 8).toByte(); dst[o++] = (v shr 16).toByte()
        }
        return n * BYTES
    }

    /** 读一个 s24le 样本（带符号扩展） */
    fun readS24(b: ByteArray, o: Int): Int =
        (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8) or (b[o + 2].toInt() shl 16)

    fun writeS24(b: ByteArray, o: Int, v: Int) {
        b[o] = v.toByte(); b[o + 1] = (v shr 8).toByte(); b[o + 2] = (v shr 16).toByte()
    }
}
