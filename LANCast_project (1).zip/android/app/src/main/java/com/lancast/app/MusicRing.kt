package com.lancast.app

import java.util.ArrayDeque

/**
 * 沉浸音乐的「断线补发」环形缓冲 —— 纯 JVM 逻辑（不依赖 Android API），规范见 docs/PROTOCOL.md 第 23 节，与 windows/music.js 对应。
 *
 * 采集线程把每一块 PCM 按「帧序号」（一个声道样本组 = 1 帧，从 0 开始连续编号）存进来；发送线程按序号取。
 * 电脑每 500 ms 回一个「N 之前的帧我都收到了」，这之前的就可以丢；连接断开期间继续存，重连后电脑说「从第 N 帧继续」，
 * 发送线程就从 N 开始补发——不丢、不重、不错位。装不下（断线超过 capFrames）时丢最老的，电脑端会把这段记为「丢失」。
 * 整块全 0 的静音只记帧数、不占内存，也不占带宽（对端自己补零，数据上完全等价）。
 */
class MusicRing(private val capFrames: Long) {
    /** data == null 表示整块静音 */
    class Chunk(val start: Long, val frames: Int, val data: ByteArray?)

    private val q = ArrayDeque<Chunk>()
    private var nextIdx = 0L

    /** 已采集的总帧数 = 下一块的起始序号（「实时」位置） */
    @Synchronized fun next(): Long = nextIdx

    /** 缓冲里最老的帧序号；空的时候等于 next() */
    @Synchronized fun oldest(): Long = q.peekFirst()?.start ?: nextIdx

    @Synchronized fun append(data: ByteArray?, frames: Int) {
        if (frames <= 0) return
        q.addLast(Chunk(nextIdx, frames, data))
        nextIdx += frames
        while (q.size > 1 && nextIdx - q.peekFirst()!!.start > capFrames) q.pollFirst()
    }

    /** 电脑确认「idx 之前都收到了」：整块都在 idx 之前的可以丢 */
    @Synchronized fun trimTo(idx: Long) {
        while (true) {
            val c = q.peekFirst() ?: return
            if (c.start + c.frames <= idx) q.pollFirst() else return
        }
    }

    /**
     * 取包含 idx（或 idx 之后第一块）的数据；idx 落在块中间就切片。没有 >= idx 的数据返回 null。
     * 返回块的 start 可能大于 idx（idx 已经被挤出缓冲时从最老的开始），调用方以返回块的 start 为准。
     */
    @Synchronized fun take(idx: Long): Chunk? {
        for (c in q) {
            val end = c.start + c.frames
            if (end <= idx) continue
            if (c.start >= idx) return c
            val skip = (idx - c.start).toInt()
            val rest = c.frames - skip
            val d = c.data
            return Chunk(idx, rest, if (d == null) null else d.copyOfRange(skip * FRAME_BYTES, d.size))
        }
        return null
    }

    @Synchronized fun bufferedFrames(): Long = nextIdx - oldest()

    companion object {
        const val FRAME_BYTES = 6              // 立体声 s24 = 6 字节 / 帧

        fun isSilent(b: ByteArray, n: Int): Boolean {
            for (i in 0 until n) if (b[i].toInt() != 0) return false
            return true
        }
    }
}
