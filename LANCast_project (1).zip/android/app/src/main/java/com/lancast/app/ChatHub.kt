package com.lancast.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * 瞬流「安全聊天」——连接管理与消息状态机（纯逻辑：不碰 Android API，网络 / 存储 / 通知都由 ChatEnv 注入，方便在 JVM 上单元测试）。
 * 与 Windows 端 windows/chathub.js 是同一套逻辑，规范见 docs/PROTOCOL.md 第 14 节。
 *
 * 消息状态：sending（还没收到对方的回执，会自动重发）→ sent（对方已收到）/ failed（对方不在线或多次重发失败，点一下可重试）。
 * 撤回（像 Telegram 的「为所有人删除」）：任何一方随时可以撤回自己发的消息，没有时间限制。撤回时本机立刻删掉内容，只留一个没有内容的「墓碑」，
 * 用来重发撤回指令 {t:"d"} 直到对方回执 {t:"da"}（对方不在线就等它上线）；对方收到后同样删掉内容并留墓碑，这样撤回指令比原消息先到、
 * 或原消息被重发时，都不会把已撤回的消息又显示出来。只有发送者本人能撤回（接收方只认 from = peer 的记录）。
 * 两台设备同时互相发起连接时会出现两条连接：双方用同一条规则（发起方设备 ID 较小的那条）选「发送用」的连接，
 * 接收则两条都收；每条消息有唯一 ID，重复的只存一份，所以不会丢也不会重。
 *
 * 线程：对外的方法都加了同一把锁；ChatEnv 的回调（changed / notify）在锁内同步调用，实现里请只做「投递到主线程」之类不阻塞的事。
 */
class ChatPeer(val id: String, val name: String, val pin: String, val ip: String, val port: Int, val online: Boolean)

/** 一条聊天记录（文字或表情包）。字段名与电脑端存储一致。 */
class ChatMsg(
    val id: String,
    var ts: Long,
    val from: String,            // me | peer
    val k: String,               // m 文字 | s 表情包
    val x: String = "",
    val e: String = "",
    val c: String = "",
    val bg: List<String> = emptyList(),
    var st: String = "sent",     // sending | sent | failed（只对 from = me 有意义）
    var tries: Int = 0,
    var lt: Long = 0L,
    // 撤回：del = true 表示这条消息已被撤回，只剩「墓碑」（id + 状态，没有任何内容）；dst = sending（撤回指令还没送到对方）| gaveup；ur = 收到时算作未读
    val del: Boolean = false,
    var dst: String = "",
    var dtries: Int = 0,
    var dlt: Long = 0L,
    var ur: Boolean = false
) {
    val mine: Boolean get() = from == "me"

    fun toJson(): JSONObject {
        val o = JSONObject().put("id", id).put("ts", ts).put("from", from).put("k", k).put("st", st).put("tries", tries).put("lt", lt)
        if (del) return o.put("del", true).put("dst", dst).put("dtries", dtries).put("dlt", dlt)
        if (ur) o.put("ur", true)
        if (k == "m") o.put("x", x) else {
            o.put("e", e).put("c", c)
            val a = JSONArray(); for (v in bg) a.put(v); o.put("bg", a)
        }
        return o
    }

    companion object {
        fun fromJson(o: JSONObject): ChatMsg? {
            val id = o.optString("id", ""); if (id.isEmpty()) return null
            val bgA = o.optJSONArray("bg")
            val bg = ArrayList<String>()
            if (bgA != null) for (i in 0 until bgA.length()) bg.add(bgA.optString(i))
            return ChatMsg(id, o.optLong("ts", 0L), o.optString("from", "peer"), o.optString("k", "m"), o.optString("x", ""),
                o.optString("e", ""), o.optString("c", ""), bg, o.optString("st", "sent"), o.optInt("tries", 0), o.optLong("lt", 0L),
                o.optBoolean("del", false), o.optString("dst", ""), o.optInt("dtries", 0), o.optLong("dlt", 0L), o.optBoolean("ur", false))
        }
    }
}

/** 一条已建立的会话（握手已通过），由平台层实现：发帧 / 关闭。 */
interface ChatLink {
    fun send(type: Int, payload: ByteArray)
    fun close(reason: String)
    /** 已入队、还没写进 socket 的字节数（语音用它判断网络是否堵住）；不支持就返回 0 */
    fun backlog(): Long = 0L
}

class ChatDial(val link: ChatLink, val serverNonce: String, val clientNonce: String)

interface ChatEnv {
    val myId: String
    val myName: String
    fun myPin(): String
    fun peers(): List<ChatPeer>
    fun load(peerId: String): String?
    fun save(peerId: String, json: String)
    fun loadUnread(): String?
    fun saveUnread(json: String)
    /** 主动连对方（mode = "chat"）并完成握手；阻塞调用，失败抛异常。调用线程不持有 hub 的锁。 */
    fun dial(p: ChatPeer): ChatDial
    fun changed(peerId: String)
    fun notify(peerId: String, name: String, msg: ChatMsg)
    fun now(): Long = System.currentTimeMillis()
    /** 头像同步（docs/PROTOCOL.md 第 20 节）：本机头像缩略图（哈希, JPEG 字节），没有头像返回 null */
    fun myAvatar(): Pair<String, ByteArray>? = null
    /** 本机缓存的对方头像哈希，没有 = 空串 */
    fun peerAvatarHash(peerId: String): String = ""
    /** 收到（并校验过）对方头像；data = null 表示对方移除了头像。在 hub 的锁内同步调用，只做轻量的存取 */
    fun onPeerAvatar(peerId: String, hash: String, data: ByteArray?) {}
    /** 主页介绍同步：本机介绍文字（空串 = 没有） */
    fun myBio(): String = ""
    /** 收到对方的主页介绍（空串 = 对方清除了） */
    fun onPeerBio(peerId: String, text: String) {}
    /** 对方改了设备名称（或重连时带来的最新名称）：更新本机记的名字 */
    fun onPeerName(peerId: String, name: String) {}
}

class ChatHub(private val env: ChatEnv) {
    companion object {
        const val MAX_KEEP = 500
        const val RESEND_MS = 4000L
        const val MAX_TRIES = 4
        const val MAX_DEL_TRIES = 20
        const val FAIL_AFTER_MS = 30000L
        const val REDIAL_MS = 3000L
        const val KEY_TIMEOUT_MS = 8000L
        const val VIDEO_MAX_QUEUE = 160 * 1024      // 视频帧发送前队列里积压超过这个值就丢帧（保证音频不被视频挤得延迟）
        const val VOICE_MAX_QUEUE = 256 * 1024      // 发送队列超过这个值（约 2.7 秒的单声道 PCM）说明网络彻底堵住
    }

    class Meta(val peerId: String, val isClient: Boolean, val serverNonce: String, val clientNonce: String, val pin: String, val peerName: String)

    class Conn(val link: ChatLink, val meta: Meta, val eph: ChatCrypto.Eph, val t: Long) {
        val peerId: String get() = meta.peerId
        val isClient: Boolean get() = meta.isClient
        var tx: ByteArray? = null
        var rx: ByteArray? = null
        var txCtr = 0L
        var rxCtr = 0L
        var ready = false
        var closed = false
        var gotKey = false
        // 头像接收状态：只接收「自己请求过」的哈希
        var avWant: String? = null
        var avN = 0
        var avParts: Array<ByteArray?>? = null
        var avGot = 0
        var avSize = 0
    }

    private val lock = Any()
    private val cache = HashMap<String, ArrayList<ChatMsg>>()
    private val conns = HashMap<String, ArrayList<Conn>>()
    private val dialing = HashSet<String>()
    private val lastDial = HashMap<String, Long>()
    private val pending = HashSet<String>()
    private val sasOf = HashMap<String, String>()
    private val unread = HashMap<String, Int>()

    /** 对方撤回了一条消息（参数 = 对方设备 ID、被撤回的编号）。文件互传用它删除已保存的文件；在锁内同步调用，实现里请只做不阻塞的事 */
    @Volatile var onFileRecall: ((String, String) -> Unit)? = null

    /** 界面正在显示的聊天（该聊天的新消息不计未读） */
    @Volatile var viewing: String? = null

    init {
        try {
            val o = JSONObject(env.loadUnread() ?: "{}")
            for (k in o.keys()) { val n = o.optInt(k, 0); if (n > 0) unread[k] = n }
        } catch (ignored: Exception) { }
        try { for (p in env.peers()) if (msgs(p.id).any { it.mine && (it.st == "sending" || (it.del && it.dst == "sending")) }) pending.add(p.id) } catch (ignored: Exception) { }
    }

    // ───────── 存储 ─────────
    private fun msgs(id: String): ArrayList<ChatMsg> = cache.getOrPut(id) {
        val l = ArrayList<ChatMsg>()
        try {
            val a = JSONArray(env.load(id) ?: "[]")
            for (i in 0 until a.length()) ChatMsg.fromJson(a.getJSONObject(i))?.let { l.add(it) }
        } catch (ignored: Exception) { }
        l
    }

    private fun persist(id: String) {
        val a = msgs(id)
        while (a.size > MAX_KEEP) a.removeAt(0)
        val arr = JSONArray()
        for (m in a) arr.put(m.toJson())
        try { env.save(id, arr.toString()) } catch (ignored: Exception) { }
    }

    private fun setUnread(id: String, n: Int) {
        if (n > 0) unread[id] = n else unread.remove(id)
        val o = JSONObject()
        for ((k, v) in unread) o.put(k, v)
        try { env.saveUnread(o.toString()) } catch (ignored: Exception) { }
    }

    private fun peerInfo(id: String): ChatPeer? = env.peers().firstOrNull { it.id == id }

    // ───────── 连接 ─────────
    private fun liveConns(id: String): List<Conn> = (conns[id] ?: arrayListOf<Conn>()).filter { !it.closed }

    /** 双方一致的选择规则：发起方 ID 较小的那条优先；同一发起方取最新的 */
    private fun bestConn(id: String): Conn? {
        var best: Conn? = null
        var bestRank = ""
        for (c in liveConns(id)) {
            if (!c.ready) continue
            val rank = if (c.isClient) env.myId else id
            if (best == null || rank < bestRank || (rank == bestRank && c.t > best.t)) { best = c; bestRank = rank }
        }
        return best
    }

    private fun sendObj(c: Conn, obj: JSONObject) {
        c.txCtr += 1
        c.link.send(ChatCrypto.T_CHAT_MSG, ChatCrypto.seal(c.tx!!, c.txCtr, obj))
    }

    private fun killLocked(c: Conn, reason: String) {
        if (c.closed) return
        c.closed = true
        conns[c.peerId]?.remove(c)
        try { c.link.close(reason) } catch (ignored: Exception) { }
        env.changed(c.peerId)
    }

    /**
     * 把一条已建立（握手已通过）的会话接进来。**先**调用本方法（它会立刻把本端的临时公钥发出去），**再**让会话开始读数据。
     * 返回的 Conn 交给平台层，之后收到的帧调用 onFrame，会话断开调用 onClosed。
     */
    fun attach(link: ChatLink, meta: Meta): Conn = synchronized(lock) { newConn(link, meta) }

    private fun newConn(link: ChatLink, meta: Meta): Conn {
        val c = Conn(link, meta, ChatCrypto.genEphemeral(), env.now())
        conns.getOrPut(meta.peerId) { ArrayList() }.add(c)
        link.send(ChatCrypto.T_CHAT_KEY, JSONObject().put("v", 1).put("epk", c.eph.pub).toString().toByteArray(Charsets.UTF_8))
        return c
    }

    fun onClosed(c: Conn) {
        synchronized(lock) {
            if (c.closed) return@synchronized
            c.closed = true
            conns[c.peerId]?.remove(c)
            env.changed(c.peerId)
        }
    }

    fun onFrame(c: Conn, type: Int, payload: ByteArray) {
        synchronized(lock) { onFrameLocked(c, type, payload) }
    }

    private fun onFrameLocked(c: Conn, type: Int, payload: ByteArray) {
        if (c.closed) return
        try {
            if (type == ChatCrypto.T_CHAT_KEY) {
                if (c.gotKey) return
                c.gotKey = true
                val epk = try { JSONObject(String(payload, Charsets.UTF_8)).optString("epk", "") } catch (e: Exception) { killLocked(c, "协议错误"); return }
                val k = try {
                    ChatCrypto.deriveSession(c.eph, epk, c.isClient, c.meta.serverNonce, c.meta.clientNonce, c.meta.pin)
                } catch (e: Exception) { killLocked(c, "安全校验失败"); return }
                c.tx = k.txKey; c.rx = k.rxKey; c.ready = true
                sasOf[c.peerId] = k.sas
                sendObj(c, JSONObject().put("t", "hi").put("name", env.myName).put("id", env.myId))
                sendAvatarHash(c)
                sendBio(c)
                env.changed(c.peerId)
                flush(c.peerId)
            } else if (type == ChatCrypto.T_CHAT_MSG) {
                if (!c.ready) { killLocked(c, "协议错误"); return }
                val r = try { ChatCrypto.open(c.rx!!, payload, c.rxCtr) } catch (e: Exception) {
                    killLocked(c, "安全校验失败，已断开（消息被篡改，或对方密钥不对）"); return
                }
                c.rxCtr = r.ctr
                onPlain(c, ChatCrypto.sanitize(r.obj, env.now()))
            } else if (type == ChatCrypto.T_CHAT_VOICE) {         // 语音通话的 PCM 帧：同一把密钥、同一个计数器序列
                if (!c.ready) { killLocked(c, "协议错误"); return }
                val r = try { ChatCrypto.openBin(c.rx!!, payload, c.rxCtr) } catch (e: Exception) {
                    killLocked(c, "安全校验失败，已断开（消息被篡改，或对方密钥不对）"); return
                }
                c.rxCtr = r.ctr
                voice?.onAudio(c.peerId, r.buf)
            } else if (type == ChatCrypto.T_CHAT_VIDEO) {         // 视频通话的 JPEG 帧：同一把密钥、同一个计数器序列
                if (!c.ready) { killLocked(c, "协议错误"); return }
                val r = try { ChatCrypto.openBin(c.rx!!, payload, c.rxCtr, ChatCrypto.MAX_VIDEO_FRAME) } catch (e: Exception) {
                    killLocked(c, "安全校验失败，已断开（消息被篡改，或对方密钥不对）"); return
                }
                c.rxCtr = r.ctr
                voice?.onVideo(c.peerId, r.buf)
            }
        } catch (e: Exception) {
            // 单个帧出问题不影响连接
        }
    }

    // ───────── 头像同步 ─────────
    // 连接建好后双方各发 {t:avh, h}（h = 自己头像缩略图 SHA-256 前 32 位 hex，没有头像 = ""）；
    // 对方的 h 和本机缓存的不同就回 {t:avr, h} 请求，发送方把缩略图切成 ≤24KiB 的块用 {t:avd, h, i, n, b} 逐块发来。
    // 只接收自己请求过的哈希，收齐后校验 SHA-256、大小和 JPEG 文件头才交给界面。
    private fun sendAvatarHash(c: Conn) {
        val mine = try { env.myAvatar() } catch (e: Exception) { null }
        try { sendObj(c, JSONObject().put("t", "avh").put("h", mine?.first ?: "")) } catch (ignored: Exception) { }
    }

    // ───────── 主页介绍 ─────────
    private fun sendName(c: Conn) {
        try { sendObj(c, JSONObject().put("t", "hi").put("name", env.myName).put("id", env.myId)) } catch (ignored: Exception) { }
    }
    fun announceName() { synchronized(lock) { for (list in conns.values.toList()) for (c in list.toList()) if (c.ready && !c.closed) sendName(c) } }
    private fun sendBio(c: Conn) {
        val t = try { env.myBio() } catch (e: Exception) { "" }
        try { sendObj(c, JSONObject().put("t", "bio").put("x", t)) } catch (ignored: Exception) { }
    }

    /** 本机主页介绍变了：通知所有已连上的对方 */
    fun announceBio() { synchronized(lock) { for (list in conns.values.toList()) for (c in list.toList()) if (c.ready && !c.closed) sendBio(c) } }

    /** 本机头像变了：通知所有已连上的对方 */
    fun announceAvatar() { synchronized(lock) { for (list in conns.values.toList()) for (c in list.toList()) if (c.ready && !c.closed) sendAvatarHash(c) } }

    private fun onAvatar(c: Conn, m: ChatCrypto.Plain) {
        val id = c.peerId
        if (m.t == "avh") {
            val have = try { env.peerAvatarHash(id) } catch (e: Exception) { "" }
            if (m.h == have) { c.avWant = null; return }
            if (m.h.isEmpty()) { c.avWant = null; c.avParts = null; try { env.onPeerAvatar(id, "", null) } catch (ignored: Exception) { }; env.changed(id); return }
            c.avWant = m.h; c.avParts = null
            try { sendObj(c, JSONObject().put("t", "avr").put("h", m.h)) } catch (ignored: Exception) { }
            return
        }
        if (m.t == "avr") {
            val mine = try { env.myAvatar() } catch (e: Exception) { null } ?: return
            if (mine.first != m.h || mine.second.size > ChatCrypto.AV_MAX_BYTES) return
            val data = mine.second
            val n = maxOf(1, (data.size + ChatCrypto.AV_CHUNK - 1) / ChatCrypto.AV_CHUNK)
            for (i in 0 until n) {
                val part = data.copyOfRange(i * ChatCrypto.AV_CHUNK, minOf(data.size, (i + 1) * ChatCrypto.AV_CHUNK))
                try { sendObj(c, JSONObject().put("t", "avd").put("h", mine.first).put("i", i).put("n", n).put("b", java.util.Base64.getEncoder().encodeToString(part))) } catch (e: Exception) { return }
            }
            return
        }
        // avd
        if (c.avWant != m.h) return                                          // 没请求过的哈希一律丢弃
        if (c.avParts == null || c.avN != m.n) { c.avParts = arrayOfNulls<ByteArray>(m.n); c.avN = m.n; c.avGot = 0; c.avSize = 0 }
        val parts = c.avParts!!
        if (parts[m.i] != null) return
        if (m.b.size > ChatCrypto.AV_CHUNK || c.avSize + m.b.size > ChatCrypto.AV_MAX_BYTES) { c.avParts = null; c.avWant = null; return }
        parts[m.i] = m.b; c.avSize += m.b.size; c.avGot++
        if (c.avGot < c.avN) return
        val out = java.io.ByteArrayOutputStream(c.avSize)
        for (p in parts) out.write(p!!)
        c.avParts = null; c.avWant = null
        val buf = out.toByteArray()
        val hash = java.security.MessageDigest.getInstance("SHA-256").digest(buf).joinToString("") { "%02x".format(it) }.substring(0, 32)
        if (hash != m.h || buf.size < 16) return          // 无损头像：原图可能是 JPEG/PNG/WebP/HEIC 等，格式由 Avatar.peerSave 用解码器校验
        try { env.onPeerAvatar(id, m.h, buf) } catch (ignored: Exception) { }
        env.changed(id)
    }

    private fun onPlain(c: Conn, m: ChatCrypto.Plain?) {
        if (m == null) return
        val id = c.peerId
        if (m.t == "a") {
            val x = msgs(id).firstOrNull { it.id == m.id && it.mine && !it.del }
            if (x != null && x.st != "sent") { x.st = "sent"; persist(id); env.changed(id) }
            return
        }
        if (m.t == "hi") { val n = m.name.trim(); if (n.isNotEmpty() && (m.id.isEmpty() || m.id == id)) { try { env.onPeerName(id, n) } catch (ignored: Exception) { }; env.changed(id) }; return }      // 设备名称：不存聊天记录、不回执
        if (m.t == "bio") { try { env.onPeerBio(id, m.x) } catch (ignored: Exception) { }; env.changed(id); return }      // 主页介绍：不存聊天记录、不回执
        if (m.t == "avh" || m.t == "avr" || m.t == "avd") { onAvatar(c, m); return }      // 头像同步：不存、不回执
        if (m.t == "gm") { game?.onSignal(id, m); return }                    // 五子棋对战：不存、不回执（TCP 可靠，对局内另有状态校验）
        if (m.t == "vc") { voice?.onSignal(id, m.op, m.vid); return }        // 语音通话信令：不存、不回执
        if (m.t == "da") {                                    // 对方确认收到撤回：我这边的墓碑也可以丢了，不留任何痕迹
            val a = msgs(id)
            val i = a.indexOfFirst { it.id == m.id && it.mine && it.del }
            if (i >= 0) { a.removeAt(i); persist(id); env.changed(id) }
            return
        }
        if (m.t == "d") {                                     // 对方撤回了他自己的消息
            val a = msgs(id)
            if (a.none { it.id == m.id && it.mine }) {        // 不能撤回「我发的」消息：只认对方自己的
                val i = a.indexOfFirst { it.id == m.id && !it.mine }
                if (i >= 0) {
                    val x = a[i]
                    if (!x.del) {
                        if (x.ur && (unread[id] ?: 0) > 0) setUnread(id, (unread[id] ?: 0) - 1)
                        a[i] = ChatMsg(x.id, x.ts, "peer", x.k, del = true)
                    }
                } else a.add(ChatMsg(m.id, env.now(), "peer", "m", del = true))      // 原消息还没到：先记下，之后到的原消息直接丢掉
                persist(id); env.changed(id)
                try { onFileRecall?.invoke(id, m.id) } catch (ignored: Exception) { }      // 这个编号如果是对方发来的文件，就把我这边保存的文件也删掉
            }
            try { sendObj(c, JSONObject().put("t", "da").put("id", m.id)) } catch (ignored: Exception) { }   // 不管有没有处理都回执
            return
        }
        // 文字 / 表情包：先回执（不管是不是重复，回执丢了对方会重发），再存
        try { sendObj(c, JSONObject().put("t", "a").put("id", m.id)) } catch (ignored: Exception) { }
        val a = msgs(id)
        if (a.any { it.id == m.id }) return
        val rec = if (m.t == "s") ChatMsg(m.id, if (m.ts > 0) m.ts else env.now(), "peer", "s", e = m.e, c = m.c, bg = m.bg)
        else ChatMsg(m.id, if (m.ts > 0) m.ts else env.now(), "peer", "m", x = m.x)
        if (viewing != id) rec.ur = true
        a.add(rec)
        a.sortBy { it.ts }
        persist(id)
        if (viewing != id) setUnread(id, (unread[id] ?: 0) + 1)
        val p = peerInfo(id)
        env.notify(id, p?.name ?: c.meta.peerName.ifEmpty { "对方" }, rec)
        env.changed(id)
    }

    // ───────── 发送 / 重发 ─────────
    private fun flush(id: String) {
        val a = msgs(id)
        val c = bestConn(id) ?: return
        var dirty = false
        val now = env.now()
        for (m in a) {
            if (!m.mine || m.st != "sending") continue
            if (m.lt != 0L && now - m.lt < RESEND_MS) continue
            if (m.tries >= MAX_TRIES) { m.st = "failed"; dirty = true; continue }
            m.tries += 1; m.lt = now; dirty = true
            val body = if (m.k == "s") {
                val bg = JSONArray(); for (v in m.bg) bg.put(v)
                JSONObject().put("t", "s").put("id", m.id).put("ts", m.ts).put("e", m.e).put("c", m.c).put("bg", bg)
            } else JSONObject().put("t", "m").put("id", m.id).put("ts", m.ts).put("x", m.x)
            try { sendObj(c, body) } catch (e: Exception) { m.st = "sending" }
        }
        for (m in a) {                                        // 撤回指令：对方没回执就一直重发（对方不在线就等它上线）
            if (!m.del || !m.mine || m.dst != "sending") continue
            if (m.dlt != 0L && now - m.dlt < RESEND_MS) continue
            if (m.dtries >= MAX_DEL_TRIES) { m.dst = "gaveup"; dirty = true; continue }      // 连着发了很多次都不回执：多半是旧版本，不认识撤回
            m.dtries += 1; m.dlt = now; dirty = true
            try { sendObj(c, JSONObject().put("t", "d").put("id", m.id)) } catch (ignored: Exception) { }
        }
        if (dirty) { persist(id); env.changed(id) }
    }

    private fun ensureConnLocked(id: String) {
        if (bestConn(id) != null || liveConns(id).isNotEmpty() || dialing.contains(id)) return
        if (env.now() - (lastDial[id] ?: 0L) < REDIAL_MS) return
        val p = peerInfo(id) ?: return
        lastDial[id] = env.now()
        dialing.add(id)
        Thread {
            try {
                val d = env.dial(p)
                synchronized(lock) {
                    dialing.remove(id)
                    onDialed(id, p, d)
                }
            } catch (e: Exception) {
                synchronized(lock) { dialing.remove(id) }
            }
        }.also { it.isDaemon = true }.start()
    }

    /** dial 成功后（已在锁内）：把会话接进来。平台层需要在 attach 之后启动读线程，所以交给 env 的 onDialed 回调——这里直接用 ChatDial.link 的实现自行启动。 */
    var onAttached: ((Conn) -> Unit)? = null

    private fun onDialed(id: String, p: ChatPeer, d: ChatDial) {
        // 派生密钥用「服务端的配对密钥:客户端的配对密钥」：本端是客户端，服务端的密钥 = 记录里对方的 pin，客户端的 = 本机的
        val c = newConn(d.link, Meta(id, true, d.serverNonce, d.clientNonce, p.pin + ":" + env.myPin(), p.name))
        onAttached?.invoke(c)
    }

    private fun add(id: String, rec: ChatMsg): ChatMsg {
        msgs(id).add(rec); persist(id); pending.add(id); env.changed(id)
        ensureConnLocked(id); flush(id)
        return rec
    }

    fun sendText(id: String, text: String): ChatMsg? {
        val x = ChatCrypto.clip(text, ChatCrypto.MAX_TEXT)
        if (x.isBlank()) return null
        return synchronized(lock) { add(id, ChatMsg(ChatCrypto.newMsgId(), env.now(), "me", "m", x = x, st = "sending")) }
    }

    fun sendSticker(id: String, s: Sticker): ChatMsg? {
        val e = ChatCrypto.clip(s.e, 16)
        if (e.isEmpty()) return null
        return synchronized(lock) {
            add(id, ChatMsg(ChatCrypto.newMsgId(), env.now(), "me", "s", e = e, c = ChatCrypto.clip(s.c, 16), bg = listOf(s.bg1, s.bg2), st = "sending"))
        }
    }

    /** 撤回自己发的消息（双向）。返回 true = 已受理。没发出去过的消息直接删掉；发过的（哪怕没收到回执）留墓碑并通知对方。 */
    fun recall(id: String, msgId: String): Boolean = synchronized(lock) {
        val a = msgs(id)
        val i = a.indexOfFirst { it.id == msgId && it.mine && !it.del }
        if (i < 0) return@synchronized false
        val m = a[i]
        if (m.st != "sent" && m.tries == 0) { a.removeAt(i); persist(id); env.changed(id); return@synchronized true }   // 从没发出去过：对方不可能见过
        a[i] = ChatMsg(m.id, m.ts, "me", m.k, del = true, dst = "sending")
        persist(id); pending.add(id); lastDial.remove(id); env.changed(id)
        ensureConnLocked(id); flush(id)
        true
    }

    /**
     * 撤回自己发出的文件。文件走独立的文件互传连接，没有聊天消息可撤，所以用文件传输编号（fid）当消息编号留一个「墓碑」，
     * 复用撤回指令 {t:"d"} 的重发 / 回执机制：对方不在线就等它上线，收到后对方的文件互传模块按这个编号删掉已保存的文件。
     */
    fun recallFile(id: String, fid: String): Boolean = synchronized(lock) {
        if (fid.length !in 8..32) return@synchronized false
        val a = msgs(id)
        if (a.any { it.id == fid && it.mine }) return@synchronized false
        a.add(ChatMsg(fid, env.now(), "me", "f", del = true, dst = "sending"))
        persist(id); pending.add(id); lastDial.remove(id); env.changed(id)
        ensureConnLocked(id); flush(id)
        true
    }

    private fun unsentRecalls(id: String): List<ChatMsg> = msgs(id).filter { it.del && it.mine && it.dst == "sending" }

    /** 还没送到对方的撤回指令条数（界面用来提示「等对方上线后生效」） */
    fun pendingRecalls(id: String): Int = synchronized(lock) { unsentRecalls(id).size }

    fun retry(id: String, msgId: String) {
        synchronized(lock) {
            val m = msgs(id).firstOrNull { it.id == msgId && it.mine } ?: return@synchronized
            if (m.st != "failed") return@synchronized
            m.st = "sending"; m.tries = 0; m.lt = 0L; m.ts = env.now()
            persist(id); pending.add(id); lastDial.remove(id)
            env.changed(id); ensureConnLocked(id); flush(id)
        }
    }

    // ───────── 语音通话（无损 PCM，走同一条加密连接）─────────
    /** 通话模块（VoiceCall.kt）设置；回调在读线程里同步调用，实现里不要阻塞 */
    interface VoiceSink {
        fun onSignal(peerId: String, op: String, vid: Boolean)
        fun onAudio(peerId: String, buf: ByteArray)
        fun onVideo(peerId: String, buf: ByteArray)
    }
    @Volatile var voice: VoiceSink? = null

    /** 信令只走 bestConn；还没连上就返回 false，并顺手去建连 */
    fun sendSignal(id: String, op: String, vid: Boolean = false): Boolean = synchronized(lock) {
        val c = bestConn(id)
        if (c == null) { ensureConnLocked(id); return@synchronized false }
        try {
            sendObj(c, JSONObject().put("t", "vc").put("op", op).put("rate", 48000).put("ch", 1).put("bits", 24).apply { if (vid) put("vid", true) })
            true
        } catch (e: Exception) { false }
    }

    // ───────── 五子棋对战（走同一条加密连接，见 Gomoku.kt）─────────
    interface GameSink { fun onSignal(peerId: String, m: ChatCrypto.Plain) }
    @Volatile var game: GameSink? = null

    /** 发一条五子棋消息（obj 里不用带 t）。只走 bestConn；还没连上就返回 false，并顺手去建连 */
    fun sendGame(id: String, obj: JSONObject): Boolean = synchronized(lock) {
        val c = bestConn(id)
        if (c == null) { ensureConnLocked(id); return@synchronized false }
        try { obj.put("t", "gm"); sendObj(c, obj); true } catch (e: Exception) { false }
    }

    /** 发一帧语音（明文已打好包）。发送队列堵得太厉害（延迟会越积越多）时返回 false，由调用方丢掉这一帧 */
    fun sendVoice(id: String, plain: ByteArray): Boolean = synchronized(lock) {
        val c = bestConn(id) ?: return@synchronized false
        try {
            if (c.link.backlog() > VOICE_MAX_QUEUE) return@synchronized false
            c.txCtr += 1
            c.link.send(ChatCrypto.T_CHAT_VOICE, ChatCrypto.sealBin(c.tx!!, c.txCtr, plain))
            true
        } catch (e: Exception) { false }
    }

    /** 发一帧视频。发送队列里还有积压（音频要优先、延迟不能越积越多）就返回 false，由调用方丢掉这一帧 */
    fun sendVideo(id: String, plain: ByteArray): Boolean = synchronized(lock) {
        val c = bestConn(id) ?: return@synchronized false
        try {
            if (c.link.backlog() > VIDEO_MAX_QUEUE) return@synchronized false
            c.txCtr += 1
            c.link.send(ChatCrypto.T_CHAT_VIDEO, ChatCrypto.sealBin(c.tx!!, c.txCtr, plain))
            true
        } catch (e: Exception) { false }
    }

    /** 每秒调用一次：补连、重发、把等太久的标成失败、清理超时没完成密钥交换的连接 */
    fun tick() {
        synchronized(lock) {
            val now = env.now()
            for (list in conns.values.toList()) for (c in list.toList()) if (!c.ready && !c.closed && now - c.t > KEY_TIMEOUT_MS) killLocked(c, "安全校验超时")
            for (id in pending.toList()) {
                val waiting = msgs(id).filter { it.mine && it.st == "sending" && !it.del }
                val dels = unsentRecalls(id).size
                if (waiting.isEmpty() && dels == 0) { pending.remove(id); continue }
                if (peerInfo(id) == null) { for (m in waiting) m.st = "failed"; persist(id); env.changed(id); pending.remove(id); continue }
                if (bestConn(id) != null) { flush(id); continue }
                if (waiting.isNotEmpty() || peerInfo(id)?.online == true) ensureConnLocked(id)     // 只有撤回指令在等：对方不在线时不用一直去连
                var dirty = false
                for (m in waiting) if (now - m.ts > FAIL_AFTER_MS) { m.st = "failed"; dirty = true }
                if (dirty) { persist(id); env.changed(id) }
            }
        }
    }

    // ───────── 查询 / 管理 ─────────
    fun messages(id: String): List<ChatMsg> = synchronized(lock) { msgs(id).filter { !it.del } }          // 墓碑（已撤回的消息）不对界面可见
    fun unread(id: String): Int = synchronized(lock) { unread[id] ?: 0 }
    fun totalUnread(): Int = synchronized(lock) { unread.values.sum() }
    fun markRead(id: String) { synchronized(lock) { if ((unread[id] ?: 0) > 0) { for (m in msgs(id)) m.ur = false; persist(id); setUnread(id, 0); env.changed(id) } } }
    fun sas(id: String): String = synchronized(lock) { if (bestConn(id) != null) sasOf[id] ?: "" else "" }
    fun isConnected(id: String): Boolean = synchronized(lock) { bestConn(id) != null }
    fun connections(id: String): Int = synchronized(lock) { liveConns(id).size }
    fun ensure(id: String) { synchronized(lock) { ensureConnLocked(id) } }
    fun clear(id: String) {
        synchronized(lock) {
            // 清空本机记录；还没送到对方的撤回指令要留着，不然对方那边的消息就永远撤不掉了
            val keep = ArrayList(unsentRecalls(id))
            cache[id] = keep; persist(id)
            setUnread(id, 0); if (keep.isEmpty()) pending.remove(id); env.changed(id)
        }
    }
    fun dropPeer(id: String) { synchronized(lock) { for (c in liveConns(id)) killLocked(c, "已取消配对") } }
    fun dispose() { synchronized(lock) { for (l in conns.values.toList()) for (c in l.toList()) killLocked(c, "关闭") } }
}
