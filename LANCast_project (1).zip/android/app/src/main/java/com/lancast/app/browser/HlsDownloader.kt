package com.lancast.app.browser

import java.io.IOException
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Callable
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutionException
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * 极简 HLS(m3u8) 下载器，纯 JDK 实现，无第三方依赖，也不依赖 Android API。
 * 支持：主列表自动选最高码率、AES-128 解密、fMP4 初始化段(EXT-X-MAP)、重定向、分片重试。
 * 不支持：SAMPLE-AES / DRM、BYTERANGE 分片、独立音轨（只下载所选视频码流）。
 * 输出：把所有分片按顺序拼接成一个文件（TS 分片 -> .ts，fMP4 分片 -> .mp4）。
 *
 * @param headers 按请求 URL 返回需要附带的请求头（UA / Referer / Cookie 等）
 */
class HlsDownloader(private val headers: (String) -> Map<String, String>) {

    class Cancelled : IOException("已取消")

    class Key(val url: String, val iv: ByteArray?)
    class Segment(val url: String, val seq: Long, val key: Key?)

    class Variant(val url: String, val bandwidth: Long, val resolution: String?)

    class Playlist(
        val segments: List<Segment>,
        val initUrl: String?,
        val live: Boolean,
        val durationSec: Double = 0.0,
        val bandwidth: Long = 0L,        // 主列表中所选码流的带宽(bit/s)，未知为 0
        val resolution: String? = null   // 如 "1280x720"，未知为 null
    ) {
        val ext: String get() = if (initUrl != null) "mp4" else "ts"
        val mime: String get() = if (initUrl != null) "video/mp4" else "video/mp2t"
    }

    /** 解析 m3u8；如果是主列表，自动跳转到带宽最高的子列表。 */
    fun load(url: String): Playlist {
        var cur = url
        var variant: Variant? = null
        for (depth in 0 until 4) {
            val text = String(fetchBytes(cur), Charsets.UTF_8).removePrefix("﻿")
            val lines = text.lines().map { it.trim() }.filter { it.isNotEmpty() }
            if (lines.firstOrNull()?.startsWith("#EXTM3U") != true) throw IOException("不是有效的 m3u8")
            if (lines.any { it.startsWith("#EXT-X-STREAM-INF") }) {
                val v = pickVariant(cur, lines)
                variant = v
                cur = v.url
            } else return parseMedia(cur, lines, variant)
        }
        throw IOException("m3u8 嵌套层级过深")
    }

    /**
     * 并行下载（默认 4 路）、严格按顺序写入所有分片：一路一个分片串行下载时，每个分片都要等一次连接 + 首包，
     * 带宽常常跑不满；并行后速度明显更快，而内存里最多只同时放 parallel + 2 个分片。
     * onProgress(已完成, 总数)；cancelled() 返回 true 时抛出 [Cancelled]。
     */
    fun writeTo(p: Playlist, out: OutputStream, onProgress: (Int, Int) -> Unit, cancelled: () -> Boolean, parallel: Int = 4) {
        p.initUrl?.let { out.write(fetchBytes(it)) }
        val total = p.segments.size
        if (total == 0) { out.flush(); return }
        val keys = ConcurrentHashMap<String, ByteArray>()
        val n = minOf(maxOf(parallel, 1), total)
        val pool = Executors.newFixedThreadPool(n) { r -> Thread(r).apply { isDaemon = true } }
        try {
            val window = ArrayDeque<Future<ByteArray>>()
            var next = 0
            var written = 0
            while (written < total) {
                while (next < total && window.size < n + 2) {
                    val seg = p.segments[next++]
                    window.addLast(pool.submit(Callable<ByteArray> { fetchSegment(seg, keys) }))
                }
                val data = await(window.removeFirst(), cancelled)
                out.write(data)
                written++
                onProgress(written, total)
            }
            out.flush()
        } finally {
            pool.shutdownNow()      // 取消 / 失败时不再发起新的分片请求
        }
    }

    /** 等一个分片下完；每 300 ms 看一次是否被取消，这样点「取消」能立刻响应，不用等网络超时。 */
    private fun await(f: Future<ByteArray>, cancelled: () -> Boolean): ByteArray {
        while (true) {
            if (cancelled()) throw Cancelled()
            try {
                return f.get(300, TimeUnit.MILLISECONDS)
            } catch (e: TimeoutException) {
                // 还没下完，继续等
            } catch (e: ExecutionException) {
                val c = e.cause
                throw if (c is IOException) c else IOException(c?.message ?: "分片下载失败", c)
            }
        }
    }

    /** 取“初始化段 + 第一个分片”（已解密），用于生成预览图。 */
    fun firstChunk(p: Playlist): ByteArray {
        val out = java.io.ByteArrayOutputStream()
        p.initUrl?.let { out.write(fetchBytes(it)) }
        out.write(fetchSegment(p.segments[0], HashMap()))
        return out.toByteArray()
    }

    /** 探测直链文件大小（用 Range: bytes=0-0，兼容不支持 HEAD 的服务器）；未知返回 -1。 */
    fun contentLength(url: String): Long {
        val c = openConnection(url, mapOf("Range" to "bytes=0-0"))
        try {
            if (c.responseCode == 206) {
                // Content-Range: bytes 0-0/12345
                return c.getHeaderField("Content-Range")?.substringAfterLast('/')?.trim()?.toLongOrNull() ?: -1L
            }
            return c.contentLengthLong
        } finally {
            c.disconnect()
        }
    }

    // ---------- 解析 ----------

    private fun pickVariant(base: String, lines: List<String>): Variant {
        var best: Variant? = null
        for (i in lines.indices) {
            if (!lines[i].startsWith("#EXT-X-STREAM-INF")) continue
            val bw = Regex("[:,]BANDWIDTH=(\\d+)").find(lines[i])?.groupValues?.get(1)?.toLongOrNull() ?: 0L
            val uri = lines.subList(i + 1, lines.size).firstOrNull { !it.startsWith("#") } ?: continue
            val cur = best
            if (cur == null || bw > cur.bandwidth) best = Variant(resolve(base, uri), bw, attr(lines[i], "RESOLUTION"))
        }
        return best ?: throw IOException("主列表中没有可用的码流")
    }

    private fun parseMedia(base: String, lines: List<String>, variant: Variant?): Playlist {
        var seq = 0L
        var duration = 0.0
        var key: Key? = null
        var init: String? = null
        val segs = ArrayList<Segment>()
        for (l in lines) {
            when {
                l.startsWith("#EXT-X-MEDIA-SEQUENCE:") -> seq = l.substringAfter(':').trim().toLongOrNull() ?: 0L
                l.startsWith("#EXT-X-KEY:") -> {
                    val method = attr(l, "METHOD")
                    key = when (method) {
                        "NONE" -> null
                        "AES-128" -> {
                            val keyUri = attr(l, "URI") ?: throw IOException("加密列表缺少密钥地址")
                            Key(resolve(base, keyUri), attr(l, "IV")?.let { hex16(it) })
                        }
                        else -> throw IOException("不支持的加密方式：$method")
                    }
                }
                l.startsWith("#EXTINF:") -> duration += l.substringAfter(':').substringBefore(',').trim().toDoubleOrNull() ?: 0.0
                l.startsWith("#EXT-X-MAP:") -> init = attr(l, "URI")?.let { resolve(base, it) }
                l.startsWith("#EXT-X-BYTERANGE") -> throw IOException("暂不支持 BYTERANGE 分片")
                !l.startsWith("#") -> {
                    segs.add(Segment(resolve(base, l), seq, key))
                    seq++
                }
            }
        }
        if (segs.isEmpty()) throw IOException("m3u8 里没有分片")
        return Playlist(segs, init, !lines.contains("#EXT-X-ENDLIST"), duration, variant?.bandwidth ?: 0L, variant?.resolution)
    }

    private fun attr(line: String, name: String): String? =
        Regex("[:,]$name=(\"[^\"]*\"|[^,]*)").find(line)?.groupValues?.get(1)?.trim('"')

    private fun hex16(s: String): ByteArray {
        val h = s.removePrefix("0x").removePrefix("0X").padStart(32, '0')
        return ByteArray(16) { h.substring(it * 2, it * 2 + 2).toInt(16).toByte() }
    }

    private fun resolve(base: String, ref: String): String = URL(URL(base), ref).toString()

    // ---------- 网络 ----------

    private fun fetchSegment(seg: Segment, keys: MutableMap<String, ByteArray>): ByteArray {
        var last: Exception? = null
        for (attempt in 0 until 3) {
            try {
                var data = fetchBytes(seg.url)
                val k = seg.key
                if (k != null) {
                    val keyBytes = keys.getOrPut(k.url) { fetchBytes(k.url) }
                    // 没有显式 IV 时，按规范用分片序号（大端 128 位）作为 IV
                    val iv = k.iv ?: ByteArray(16).also { b ->
                        for (j in 0 until 8) b[15 - j] = (seg.seq shr (8 * j)).toByte()
                    }
                    val cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
                    cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(keyBytes, "AES"), IvParameterSpec(iv))
                    data = cipher.doFinal(data)
                }
                return data
            } catch (e: Exception) {
                last = e
            }
        }
        throw IOException("分片下载失败：${last?.message}", last)
    }

    private fun fetchBytes(url: String): ByteArray {
        val c = openConnection(url)
        try {
            return c.inputStream.use { it.readBytes() }
        } finally {
            c.disconnect()
        }
    }

    /** 手动跟随重定向（HttpURLConnection 不会跟随 http<->https 跳转），每一跳都重新取请求头。 */
    fun openConnection(url: String, extra: Map<String, String> = emptyMap()): HttpURLConnection {
        var u = url
        for (hop in 0 until 6) {
            val c = URL(u).openConnection() as HttpURLConnection
            try {
                c.connectTimeout = 15000
                c.readTimeout = 30000
                c.instanceFollowRedirects = false
                for ((k, v) in headers(u)) c.setRequestProperty(k, v)
                for ((k, v) in extra) c.setRequestProperty(k, v)
                val code = c.responseCode
                when (code) {
                    in 200..299 -> return c
                    in 300..399 -> {
                        val loc = c.getHeaderField("Location")
                        c.disconnect()
                        if (loc == null) throw IOException("HTTP $code（缺少 Location）")
                        u = resolve(u, loc)
                    }
                    else -> {
                        c.disconnect()
                        throw IOException("HTTP $code")
                    }
                }
            } catch (e: Throwable) {
                c.disconnect()      // 连接超时 / 读超时等异常时，连接对象也要释放，否则下载失败重试多了会堆积 socket
                throw e
            }
        }
        throw IOException("重定向次数过多")
    }
}
