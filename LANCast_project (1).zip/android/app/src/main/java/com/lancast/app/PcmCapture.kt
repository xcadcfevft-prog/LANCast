package com.lancast.app

import android.media.AudioFormat
import android.media.AudioRecord

/**
 * 带兜底的 PCM 采集器：音乐 / 投屏 / 语音三条线共用。
 *
 * 打开顺序：ENCODING_PCM_FLOAT（真 24 bit）→ ENCODING_PCM_16BIT（兜底）。
 * 下面任何一步失败都会换下一种编码重来，而不是直接报错：
 *   · getMinBufferSize 返回错误码（设备不支持该编码 / 采样率 / 声道）
 *   · AudioRecord 构造 / Builder.build() 抛异常
 *   · 构造出来 state != STATE_INITIALIZED
 *   · startRecording() 抛异常，或者之后没有进入 RECORDING 状态
 * 两种都失败才抛异常，错误信息里带上每一种失败的原因，方便定位。
 *
 * 不管用哪种编码采集，对外都是 24 bit：
 *   float  → 量化成 24 bit 整数；
 *   16 bit → 左移 8 位补成 24 bit。
 * 所以协议（fmt = "s24"）和电脑端都不用改。
 */
class PcmCapture private constructor(val rec: AudioRecord, val isFloat: Boolean) {
    private var fbuf = FloatArray(0)
    private var sbuf = ShortArray(0)

    /** 给界面 / 状态栏用的说明 */
    val modeText: String get() = if (isFloat) "24 bit" else "16 bit（此设备不支持 float 采集，已兜底，补成 24 bit 发送）"

    /**
     * 读至多 samples 个采样（每个声道各算一个），写成 s24le 字节放进 dst[off..]。
     * 返回写入的字节数；负数是 AudioRecord 的错误码。
     */
    fun readS24le(dst: ByteArray, off: Int, samples: Int): Int {
        if (isFloat) {
            if (fbuf.size < samples) fbuf = FloatArray(samples)
            val n = rec.read(fbuf, 0, samples, AudioRecord.READ_BLOCKING)
            return if (n <= 0) n else Pcm24.floatsToS24le(fbuf, n, dst, off)
        }
        if (sbuf.size < samples) sbuf = ShortArray(samples)
        val n = rec.read(sbuf, 0, samples, AudioRecord.READ_BLOCKING)
        return if (n <= 0) n else Pcm24.shortsToS24le(sbuf, n, dst, off)
    }

    /**
     * 读至多 samples 个采样，作为 24 bit 有符号整数放进 dst[off..]。
     * 返回读到的采样数；负数是 AudioRecord 的错误码。
     */
    fun readS24(dst: IntArray, off: Int, samples: Int): Int {
        if (isFloat) {
            if (fbuf.size < samples) fbuf = FloatArray(samples)
            val n = rec.read(fbuf, 0, samples, AudioRecord.READ_BLOCKING)
            if (n > 0) for (i in 0 until n) dst[off + i] = Pcm24.toS24(fbuf[i])
            return n
        }
        if (sbuf.size < samples) sbuf = ShortArray(samples)
        val n = rec.read(sbuf, 0, samples, AudioRecord.READ_BLOCKING)
        if (n > 0) for (i in 0 until n) dst[off + i] = Pcm24.s16ToS24(sbuf[i])
        return n
    }

    companion object {
        fun bytesPerSample(enc: Int): Int = if (enc == AudioFormat.ENCODING_PCM_FLOAT) 4 else 2

        fun encName(enc: Int): String = if (enc == AudioFormat.ENCODING_PCM_FLOAT) "float" else "16 bit"

        /** getMinBufferSize，设备不支持这个组合时抛异常（让 open 换下一种编码） */
        fun minBuf(rate: Int, channelMask: Int, enc: Int): Int {
            val m = AudioRecord.getMinBufferSize(rate, channelMask, enc)
            if (m <= 0) throw IllegalStateException("不支持 ${rate}Hz / ${encName(enc)} 采集（错误码 $m）")
            return m
        }

        /**
         * 依次用 float、16 bit 打开并启动采集。
         * make(enc)：按给定编码创建 AudioRecord（里面算缓冲区大小请用 bytesPerSample(enc) / minBuf(...)）；
         * beforeStart：创建成功、startRecording 之前调用（语音在这里给会话挂回声消除 / 降噪）。
         */
        fun open(make: (Int) -> AudioRecord, beforeStart: ((AudioRecord) -> Unit)? = null): PcmCapture {
            val errs = ArrayList<String>()
            for (enc in intArrayOf(AudioFormat.ENCODING_PCM_FLOAT, AudioFormat.ENCODING_PCM_16BIT)) {
                var r: AudioRecord? = null
                try {
                    r = make(enc)
                    if (r.state != AudioRecord.STATE_INITIALIZED) throw IllegalStateException("AudioRecord 初始化失败")
                    beforeStart?.invoke(r)
                    r.startRecording()
                    if (r.recordingState != AudioRecord.RECORDSTATE_RECORDING) throw IllegalStateException("采集器没有进入录制状态")
                    return PcmCapture(r, enc == AudioFormat.ENCODING_PCM_FLOAT)
                } catch (e: Exception) {
                    try { r?.release() } catch (ignored: Exception) { }
                    errs.add("${encName(enc)}：${e.message ?: e.javaClass.simpleName}")
                }
            }
            throw IllegalStateException(errs.joinToString("；"))
        }
    }
}
