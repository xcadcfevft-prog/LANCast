'use strict';
/* 瞬流「沉浸音乐」歌词 —— 电脑端在线解析（纯逻辑 + 极薄的 https 封装，不碰 DOM，方便单元测试）。
 *
 * 手机不需要额外发任何东西：电脑拿手机报来的「歌名 / 歌手 / 时长」自己去网上找带时间轴的 LRC 歌词。
 * 来源（按顺序，找到可用的就停）：
 *   1. LRCLIB  /api/get   （歌名 + 歌手 + 时长精确匹配，免密钥，对英文 / 日韩歌曲较全）
 *   2. 网易云  搜索 + 歌词 （中文歌曲最全，同时带翻译歌词）
 *   3. LRCLIB  /api/search （模糊搜索兜底）
 *   另有 酷我 / QQ 音乐 两个来源。排序按「来自哪个 App、是不是中日韩歌曲」调整：
 *   酷我音乐来的歌先查酷我（同一曲库，歌名 / 时长最对得上）；汽水音乐和其它中文歌先查网易云 → QQ → 酷我；英文歌先查 LRCLIB。
 * 候选按「歌名相似度 + 歌手相似度 + 时长差」打分，分数太低宁可不显示也不显示错歌。
 * 结果缓存在内存里（同一首歌来回切不再联网）；网络失败不缓存，下次换歌 / 重连时会再试。 */
const https = require('https');

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) LANCast/1.0';

/* ---------- LRC 解析 ---------- */
/* "[01:23.45]歌词" / "[1:23]" / 一行多个时间戳 "[00:10.00][01:20.00]副歌" / "[offset:±ms]"；元数据行（[ar:] [ti:] …）忽略。
 * 返回按时间排序的 [{ t: 毫秒, text }]；没有任何带时间的行返回 []。 */
function parseLrc(src) {
  if (typeof src !== 'string') return [];
  const out = [];
  let offset = 0;
  for (const raw of src.replace(/\r/g, '').split('\n')) {
    let line = raw.trim(), m;
    if ((m = /^\[offset:\s*([+-]?\d+)\s*\]/i.exec(line))) { offset = Number(m[1]) || 0; continue; }
    const ts = [];
    while ((m = /^\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?\]/.exec(line))) {
      const frac = m[3] ? Number((m[3] + '00').slice(0, 3)) : 0;
      ts.push(Number(m[1]) * 60000 + Number(m[2]) * 1000 + frac);
      line = line.slice(m[0].length);
    }
    if (!ts.length) continue;
    line = line.replace(/<\d+:\d+(?:[.:]\d+)?>/g, '').trim();        // 逐字时间戳 <00:01.20> 去掉，只保留整行
    for (const t of ts) out.push({ t: Math.max(0, t - offset), text: line });
  }
  out.sort((a, b) => a.t - b.t);
  return out;
}

/* 把翻译歌词按时间戳（±400ms 内最近的一行）合并进原文：line.tr */
function mergeTrans(lines, trans) {
  if (!lines.length || !trans.length) return lines;
  let j = 0;
  for (const l of lines) {
    while (j < trans.length - 1 && Math.abs(trans[j + 1].t - l.t) <= Math.abs(trans[j].t - l.t)) j++;
    const c = trans[j];
    if (c && c.text && Math.abs(c.t - l.t) <= 400 && l.text) l.tr = c.text;
  }
  return lines;
}

/* 当前该高亮第几行：最后一个 t <= pos 的行；还没到第一行返回 -1。lines 已按时间排序，二分。 */
function lineAt(lines, pos) {
  let lo = 0, hi = lines.length - 1, r = -1;
  while (lo <= hi) { const mid = (lo + hi) >> 1; if (lines[mid].t <= pos) { r = mid; lo = mid + 1; } else hi = mid - 1; }
  return r;
}

/* 手机通知里的「此刻这一句」→ 在线歌词里对应的行（文字一致 / 互相包含，且时间相差不超过 12 秒，取最近的）；找不到返回 null */
function matchLine(lines, text, pos) {
  const nt = norm(text); if (!nt) return null;
  let best = null, bd = 12001;
  for (const l of lines) {
    const n = norm(l.text); if (!n) continue;
    if (!(n === nt || (nt.length >= 4 && n.length >= 4 && (n.includes(nt) || nt.includes(n))))) continue;
    const d = Math.abs(pos - l.t); if (d < bd) { bd = d; best = l; }
  }
  return best;
}
const median = a => { const s = a.slice().sort((x, y) => x - y), m = s.length >> 1; return s.length ? (s.length % 2 ? s[m] : (s[m - 1] + s[m]) / 2) : 0; };
/* 没有在线歌词时，用手机报来的歌词行边听边攒：同一句（3 秒内）重复通知忽略。返回是否新增。 */
function addLive(lines, t, text) {
  text = String(text || '').trim(); if (!text) return false;
  for (const l of lines) if (l.text === text && Math.abs(l.t - t) < 3000) return false;
  lines.push({ t, text }); lines.sort((a, b) => a.t - b.t);
  return true;
}

/* ---------- 搜索用的文字清洗 / 相似度 ---------- */
const decodeEnt = t => String(t || '').replace(/&#(\d+);/g, (m, n) => String.fromCharCode(Number(n))).replace(/&nbsp;/g, ' ').replace(/&apos;/g, "'").replace(/&quot;/g, '"').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&');
const PLACEHOLDER_ARTIST = /^(<unknown>|unknown( artist)?|未知(艺术家|歌手|艺人|作者)?|佚名|various artists?|群星|null)$/i;
const CJK = /[\u3040-\u30ff\u4e00-\u9fff\uac00-\ud7af]/;
/* 手机报来的歌名 / 歌手整理：去掉「<unknown>」「未知歌手」这类占位；歌手为空而歌名是「A - B」时拆开（有的 App 把两者拼在标题里，
 * 顺序不固定，所以两种读法都留着，打分时取高的）。返回 { title, artist, alt? } */
function normalizeMeta(title, artist) {
  title = decodeEnt(title).trim(); artist = decodeEnt(artist).trim();
  if (PLACEHOLDER_ARTIST.test(artist)) artist = '';
  if (!artist) {
    const m = /^(.+?)\s+[-–—]\s+(.+)$/.exec(title);
    if (m) return { title: m[1].trim(), artist: m[2].trim(), alt: { title: m[2].trim(), artist: m[1].trim() } };
  }
  return { title, artist };
}
/* 去掉「(Live) [Remastered] （伴奏） - feat.xxx」之类影响搜索的后缀；歌名里带「 - 歌手」时也一并去掉 */
function cleanTitle(t, artist) {
  let s = String(t || '').replace(/[\(（\[【][^\)）\]】]*[\)）\]】]/g, ' ').replace(/\s+(?:feat|ft)\.?\s.*$/i, '');
  if (artist) {
    const a = String(artist).trim();
    if (a && s.toLowerCase().includes(' - ' + a.toLowerCase())) s = s.slice(0, s.toLowerCase().indexOf(' - ' + a.toLowerCase()));
  }
  return s.replace(/\s+-\s+.*$/, ' ').replace(/\s+/g, ' ').trim();
}
/* 多个歌手（"A / B"、"A、B"、"A&B"、"A, B"）取第一个用于搜索 */
function firstArtist(a) { return String(a || '').split(/\s*(?:\/|、|&|,|，|;|；|\bfeat\.?|\bft\.?|×| x )\s*/i)[0].trim(); }
const norm = s => String(s || '').toLowerCase().replace(/[\s\-_·•.,，。!！?？'"“”‘’`~:：;；()（）\[\]【】《》<>]/g, '');
function sim(a, b) {                       // 0..1：完全相同 1，互相包含 0.8，否则按公共字符粗估
  a = norm(a); b = norm(b);
  if (!a || !b) return 0;
  if (a === b) return 1;
  if (a.includes(b) || b.includes(a)) return 0.8;
  const sa = new Set(a), sb = new Set(b); let n = 0;
  for (const c of sa) if (sb.has(c)) n++;
  return (n / Math.max(sa.size, sb.size)) * 0.6;
}
/* 候选打分：{ name, artist, duration(ms) } vs 想找的 { title, artist, duration(ms) }。满分约 3。 */
function score(c, want) {
  const a = score1(c, want);
  return want.alt ? Math.max(a, score1(c, Object.assign({}, want.alt, { duration: want.duration }))) : a;
}
function score1(c, want) {
  let s = sim(c.name, want.title) * 1.6 + (want.artist ? sim(c.artist, want.artist) : 0.5);
  if (want.duration > 0 && c.duration > 0) {
    const d = Math.abs(c.duration - want.duration);
    s += d <= 3000 ? 0.8 : d <= 8000 ? 0.3 : d > 20000 ? -0.8 : 0;
  }
  return s;
}
const MIN_SCORE = 1.7;

/* ---------- 网络 ---------- */
function httpGet(url, headers, timeoutMs) {
  return new Promise((resolve, reject) => {
    const req = https.get(url, { headers: Object.assign({ 'User-Agent': UA, Accept: 'application/json' }, headers || {}) }, res => {
      if (res.statusCode === 404) { res.resume(); return resolve(null); }
      if (res.statusCode !== 200) { res.resume(); return reject(new Error('HTTP ' + res.statusCode)); }
      const chunks = []; let n = 0;
      res.on('data', c => { n += c.length; if (n > 2e6) { req.destroy(new Error('too large')); } else chunks.push(c); });
      res.on('end', () => { try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); } catch (e) { reject(e); } });
      res.on('error', reject);
    });
    req.setTimeout(timeoutMs || 6000, () => req.destroy(new Error('timeout')));
    req.on('error', reject);
  });
}
const q = o => Object.keys(o).filter(k => o[k] !== '' && o[k] != null).map(k => encodeURIComponent(k) + '=' + encodeURIComponent(o[k])).join('&');

/* ---------- 各来源 ---------- */
async function fromLrclibGet(w, get) {
  if (!w.title || !w.artist) return null;
  const j = await get('https://lrclib.net/api/get?' + q({ track_name: w.title, artist_name: w.artist, duration: w.duration > 0 ? Math.round(w.duration / 1000) : '' }));
  const lines = j && parseLrc(j.syncedLyrics);
  return lines && lines.length ? { lines, source: 'LRCLIB' } : null;
}
async function fromNetease(w, get) {
  const H = { Referer: 'https://music.163.com/', Cookie: 'appver=2.0.2' };
  const r = await get('https://music.163.com/api/search/get?' + q({ s: [w.title, w.artist].filter(Boolean).join(' '), type: 1, limit: 8, offset: 0 }), H);
  const songs = (r && r.result && r.result.songs) || [];
  const best = songs.map(x => ({ id: x.id, s: score({ name: x.name, artist: (x.artists || []).map(a => a.name).join('/'), duration: x.duration || (x.dt || 0) }, w) }))
    .sort((a, b) => b.s - a.s)[0];
  if (!best || best.s < MIN_SCORE) return null;
  const j = await get('https://music.163.com/api/song/lyric?' + q({ id: best.id, lv: 1, kv: 1, tv: -1 }), H);
  const lines = j && j.lrc && parseLrc(j.lrc.lyric);
  if (!lines || !lines.length) return null;
  if (j.tlyric && j.tlyric.lyric) mergeTrans(lines, parseLrc(j.tlyric.lyric));
  return { lines, source: '网易云' };
}
async function fromLrclibSearch(w, get) {
  const r = await get('https://lrclib.net/api/search?' + q({ track_name: w.title, artist_name: w.artist }));
  const best = (Array.isArray(r) ? r : []).filter(x => x && x.syncedLyrics)
    .map(x => ({ x, s: score({ name: x.trackName, artist: x.artistName, duration: (x.duration || 0) * 1000 }, w) })).sort((a, b) => b.s - a.s)[0];
  if (!best || best.s < MIN_SCORE) return null;
  const lines = parseLrc(best.x.syncedLyrics);
  return lines.length ? { lines, source: 'LRCLIB' } : null;
}

/* 酷我：搜索要带一个任意的 kw_token（同值放在 Cookie 和 csrf 头里即可）；歌词接口返回 lrclist（time 单位秒） */
async function fromKuwo(w, get) {
  const key = [w.title, w.artist].filter(Boolean).join(' '), tk = 'LANCAST0KW';
  const H = { Cookie: 'kw_token=' + tk, csrf: tk, Referer: 'https://www.kuwo.cn/search/list?key=' + encodeURIComponent(key) };
  const r = await get('https://www.kuwo.cn/api/www/search/searchMusicBykeyWord?' + q({ key, pn: 1, rn: 10, httpsStatus: 1 }), H);
  const list = (r && r.data && r.data.list) || [];
  const best = list.map(x => ({ rid: x.rid, s: score({ name: decodeEnt(x.name), artist: decodeEnt(x.artist), duration: (Number(x.duration) || 0) * 1000 }, w) })).sort((a, b) => b.s - a.s)[0];
  if (!best || best.s < MIN_SCORE) return null;
  const j = await get('https://m.kuwo.cn/newh5/singles/songinfoandlrc?' + q({ musicId: best.rid, httpsStatus: 1 }), { Referer: 'https://m.kuwo.cn/' });
  const arr = j && j.data && j.data.lrclist;
  if (!Array.isArray(arr)) return null;
  const lines = arr.map(x => ({ t: Math.round(Number(x.time) * 1000), text: decodeEnt(x.lineLyric).trim() })).filter(x => Number.isFinite(x.t) && x.text).sort((a, b) => a.t - b.t);
  return lines.length ? { lines, source: '酷我' } : null;
}
/* QQ 音乐：smartbox 搜索（无时长）+ 歌词接口（nobase64；返回里的 : . 换行是 &#58; &#46; &#10; 之类的实体，先解码） */
async function fromQQ(w, get) {
  const H = { Referer: 'https://y.qq.com/' };
  const r = await get('https://c.y.qq.com/splcloud/fcgi-bin/smartbox_new.fcg?' + q({ key: [w.title, w.artist].filter(Boolean).join(' '), format: 'json' }), H);
  const items = (r && r.data && r.data.song && r.data.song.itemlist) || [];
  const best = items.map(x => ({ mid: x.mid, s: score({ name: x.name, artist: x.singer, duration: 0 }, w) })).sort((a, b) => b.s - a.s)[0];
  if (!best || !best.mid || best.s < MIN_SCORE) return null;
  const j = await get('https://c.y.qq.com/lyric/fcgi-bin/fcg_query_lyric_new.fcg?' + q({ songmid: best.mid, format: 'json', nobase64: 1 }), H);
  const lines = j && j.lyric && parseLrc(decodeEnt(j.lyric));
  if (!lines || !lines.length) return null;
  if (j.trans) mergeTrans(lines, parseLrc(decodeEnt(j.trans)));
  return { lines, source: 'QQ音乐' };
}

/* 来源顺序：看是哪个 App 播的、是不是中日韩歌曲 */
function order(meta, w) {
  const app = String(meta.app || '') + ' ' + String(meta.pkg || '');
  const cn = /酷我|kuwo/i.test(app) ? [fromKuwo, fromNetease, fromQQ]
    : /汽水|luna/i.test(app) ? [fromNetease, fromQQ, fromKuwo]
    : CJK.test(w.title + w.artist) ? [fromNetease, fromQQ, fromKuwo] : null;
  return cn ? [...cn, fromLrclibGet, fromLrclibSearch] : [fromLrclibGet, fromNetease, fromQQ, fromKuwo, fromLrclibSearch];
}
/* 取回的歌词明显不是这首（最后一句比歌曲时长还晚 30 秒以上，或太短）就不要，继续试下一个来源 */
function plausible(res, w) {
  if (!res || res.lines.length < 3) return false;
  return !(w.duration > 0 && res.lines[res.lines.length - 1].t > w.duration + 30000);
}

/* ---------- 入口 ---------- */
const cache = new Map();                                            // key → { lines, source } | null（找不到也缓存，免得同一首歌反复联网）
const CACHE_MAX = 60;
const keyOf = w => norm(w.title) + '|' + norm(w.artist);

/* meta: { title, artist, duration(ms) }。返回 { lines, source } 或 null（确实没有）；全部来源都因网络失败时抛异常（不缓存，下次再试）。
 * get 可注入（测试用）。 */
async function fetchLyrics(meta, get) {
  get = get || httpGet;
  const n = normalizeMeta(meta.title, meta.artist), duration = Number(meta.duration) || 0;
  const w = { title: cleanTitle(n.title, n.artist), artist: firstArtist(n.artist), duration };
  if (n.alt) w.alt = { title: cleanTitle(n.alt.title, ''), artist: firstArtist(n.alt.artist) };
  if (!w.title) return null;
  const k = keyOf(w);
  if (cache.has(k)) return cache.get(k);
  let netFail = 0, tried = 0, res = null;
  for (const src of order(meta, w)) {
    tried++;
    try { res = await src(w, get); } catch { netFail++; res = null; }
    if (plausible(res, w)) break;
    res = null;
  }
  if (!res && netFail === tried) throw new Error('网络不可用');
  if (cache.size >= CACHE_MAX) cache.delete(cache.keys().next().value);
  cache.set(k, res);
  return res;
}

module.exports = { matchLine, median, addLive, normalizeMeta, decodeEnt, parseLrc, mergeTrans, lineAt, cleanTitle, firstArtist, sim, score, fetchLyrics, _cache: cache };
