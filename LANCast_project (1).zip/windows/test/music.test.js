'use strict';
// node windows/test/music.test.js —— 沉浸音乐的纯逻辑：帧序号去重 / 对齐、PCM 解码、元数据清洗、进度估算
const assert = require('assert');
const M = require('../music');

let pass = 0, failed = false;
const ok = (name, fn) => { try { fn(); pass++; console.log('PASS ' + name); } catch (e) { failed = true; console.log('FAIL ' + name + '\n     ' + String(e.stack).split('\n').slice(0, 4).join('\n     ')); } };

ok('AudioRx：连续帧全部接收', () => {
  const r = new M.AudioRx();
  assert.deepStrictEqual(r.accept(0, 100), { off: 0, frames: 100 });
  assert.deepStrictEqual(r.accept(100, 50), { off: 0, frames: 50 });
  assert.strictEqual(r.next, 150); assert.strictEqual(r.gapFrames, 0); assert.strictEqual(r.dupFrames, 0);
});
ok('AudioRx：完全重复的补发被丢弃', () => {
  const r = new M.AudioRx(); r.accept(0, 100); r.accept(100, 100);
  assert.strictEqual(r.accept(0, 100), null); assert.strictEqual(r.accept(100, 100), null);
  assert.strictEqual(r.next, 200); assert.strictEqual(r.dupFrames, 200);
});
ok('AudioRx：部分重叠只取新的部分', () => {
  const r = new M.AudioRx(); r.accept(0, 100);
  assert.deepStrictEqual(r.accept(60, 100), { off: 40, frames: 60 });
  assert.strictEqual(r.next, 160); assert.strictEqual(r.dupFrames, 40);
});
ok('AudioRx：中间缺了一段记为丢失', () => {
  const r = new M.AudioRx(); r.accept(0, 100);
  assert.deepStrictEqual(r.accept(1000, 100), { off: 0, frames: 100 });
  assert.strictEqual(r.gapFrames, 900); assert.strictEqual(r.next, 1100);
});
ok('AudioRx：第一块从任意序号开始（手机已经采集了一阵）', () => {
  const r = new M.AudioRx(); assert.deepStrictEqual(r.accept(480000, 1920), { off: 0, frames: 1920 });
  assert.strictEqual(r.gapFrames, 0);
});
ok('AudioRx：空块 / 非法块忽略', () => { const r = new M.AudioRx(); assert.strictEqual(r.accept(0, 0), null); assert.strictEqual(r.accept(0, -5), null); });

ok('parseAudio：PCM 块 / 静音块 / 非法', () => {
  const pcm = Buffer.alloc(16);
  assert.deepStrictEqual(M.parseAudio(0, 7, pcm, 2), { idx: 7, frames: 4, silent: false, pcm });
  const sil = Buffer.alloc(4); sil.writeUInt32BE(48000);
  assert.deepStrictEqual(M.parseAudio(1, 9, sil, 2), { idx: 9, frames: 48000, silent: true, pcm: null });
  assert.throws(() => M.parseAudio(0, 0, Buffer.alloc(15), 2));
  assert.throws(() => M.parseAudio(0, 0, Buffer.alloc(0), 2));
  assert.throws(() => M.parseAudio(1, 0, Buffer.alloc(2), 2));
  const huge = Buffer.alloc(4); huge.writeUInt32BE(0xffffffff);
  assert.throws(() => M.parseAudio(1, 0, huge, 2));
});

ok('s16ToPlanar：逐样本精确（含 off 跳过）', () => {
  const frames = 5, b = Buffer.alloc(frames * 4), L = [0, 1, -1, 32767, -32768], R = [100, -100, 32767, -32768, 0];
  for (let i = 0; i < frames; i++) { b.writeInt16LE(L[i], i * 4); b.writeInt16LE(R[i], i * 4 + 2); }
  const a = M.s16ToPlanar(b, 2, 0, frames);
  for (let i = 0; i < frames; i++) { assert.strictEqual(a.l[i], L[i] / 32768); assert.strictEqual(a.r[i], R[i] / 32768); }
  const c = M.s16ToPlanar(b, 2, 2, 3);
  assert.deepStrictEqual(Array.from(c.l), L.slice(2).map(v => v / 32768)); assert.deepStrictEqual(Array.from(c.r), R.slice(2).map(v => v / 32768));
  const mono = M.s16ToPlanar(Buffer.from([1, 0, 2, 0]), 1, 0, 2); assert.strictEqual(mono.l, mono.r);
});
ok('s16ToPlanar：浮点 → 回到 s16 无损（所有 65536 个取值）', () => {
  const b = Buffer.alloc(65536 * 4);
  for (let v = -32768; v <= 32767; v++) { b.writeInt16LE(v, (v + 32768) * 4); b.writeInt16LE(-v - 1, (v + 32768) * 4 + 2); }
  const a = M.s16ToPlanar(b, 2, 0, 65536);
  for (let i = 0; i < 65536; i++) { assert.strictEqual(Math.round(a.l[i] * 32768), i - 32768); assert.strictEqual(Math.round(a.r[i] * 32768), -(i - 32768) - 1); }
});

ok('s24ToPlanar：逐样本精确（含符号扩展 / 极值 / off 跳过）+ parseAudio 按 s24 校验长度', () => {
  const L = [0, 1, -1, 8388607, -8388608, -1234567], R = [100, -100, 8388607, -8388608, 0, 7654321], frames = L.length, b = Buffer.alloc(frames * 6);
  const w = (v, o) => { b[o] = v & 255; b[o + 1] = (v >> 8) & 255; b[o + 2] = (v >> 16) & 255; };
  for (let i = 0; i < frames; i++) { w(L[i], i * 6); w(R[i], i * 6 + 3); }
  const a = M.s24ToPlanar(b, 2, 0, frames);
  for (let i = 0; i < frames; i++) { assert.strictEqual(a.l[i] * 8388608, L[i]); assert.strictEqual(a.r[i] * 8388608, R[i]); }
  const c = M.s24ToPlanar(b, 2, 2, 3); assert.deepStrictEqual(Array.from(c.l).map(v => v * 8388608), L.slice(2, 5));
  assert.strictEqual(M.parseAudio(0, 0, b, 2, 's24').frames, frames);
  assert.throws(() => M.parseAudio(0, 0, b.subarray(0, 7), 2, 's24'));
  assert.deepStrictEqual(M.parseConfig({ rate: 48000, ch: 2, fmt: 's24', sid: 'x' }), { rate: 48000, ch: 2, fmt: 's24', sid: 'x' });
});

ok('parseConfig', () => {
  assert.deepStrictEqual(M.parseConfig({ rate: 48000, ch: 2, fmt: 's16', sid: 'abc' }), { rate: 48000, ch: 2, fmt: 's16', sid: 'abc' });
  assert.throws(() => M.parseConfig({ rate: 48000, ch: 6, fmt: 's16' }));
  assert.throws(() => M.parseConfig({ rate: 48000, ch: 2, fmt: 'f32' }));
  assert.throws(() => M.parseConfig({ rate: 5, ch: 2, fmt: 's16' }));
});

ok('cleanMeta：限长 / 限类型 / 过滤指令', () => {
  const m = M.cleanMeta({ title: 'x'.repeat(1000), artist: 5, state: 'hacked', duration: 'NaN', pos: -5, speed: 99, can: ['play', 'rm -rf', 'seek'], ctl: 'yes', cover: 'a'.repeat(50) });
  assert.strictEqual(m.title.length, 300); assert.strictEqual(m.artist, ''); assert.strictEqual(m.state, 'none');
  assert.strictEqual(m.duration, 0); assert.strictEqual(m.pos, 0); assert.strictEqual(m.speed, 8);
  assert.deepStrictEqual(m.can, ['play', 'seek']); assert.strictEqual(m.ctl, false); assert.strictEqual(m.cover.length, 16);
  assert.strictEqual(M.cleanMeta({ ctl: true, state: 'playing' }).ctl, true);
});

ok('estimatePos：播放中随时间前进，减去电脑端缓冲；暂停不前进', () => {
  const meta = { pos: 10000, state: 'playing', speed: 1, duration: 200000 };
  assert.strictEqual(M.estimatePos(meta, 1000, 3000, 0), 12000);
  assert.strictEqual(M.estimatePos(meta, 1000, 3000, 1500), 10500);
  assert.strictEqual(M.estimatePos({ pos: 10000, state: 'paused', speed: 1, duration: 200000 }, 1000, 9000, 0), 10000);
  assert.strictEqual(M.estimatePos({ pos: 500, state: 'paused', speed: 1, duration: 0 }, 0, 0, 2000), 0);       // 不为负
  assert.strictEqual(M.estimatePos({ pos: 199000, state: 'playing', speed: 1, duration: 200000 }, 0, 5000, 0), 200000);   // 不超过总长
  assert.strictEqual(M.estimatePos(null, 0, 0, 0), 0);
});

ok('fmtTime', () => {
  assert.strictEqual(M.fmtTime(0), '0:00'); assert.strictEqual(M.fmtTime(65000), '1:05'); assert.strictEqual(M.fmtTime(3600000 + 61000), '1:01:01'); assert.strictEqual(M.fmtTime(-5), '0:00');
});

ok('parseCover / imageMime', () => {
  const img = Buffer.from([0x89, 0x50, 0x4e, 0x47, 1, 2, 3]);
  const c = M.parseCover(Buffer.concat([Buffer.from('0123456789abcdef', 'latin1'), img]));
  assert.strictEqual(c.hash, '0123456789abcdef'); assert.deepStrictEqual(Buffer.from(c.img), img);
  assert.strictEqual(M.imageMime(img), 'image/png'); assert.strictEqual(M.imageMime(Buffer.from([0xff, 0xd8, 0xff])), 'image/jpeg');
  assert.strictEqual(M.imageMime(Buffer.from('<svg onload=alert(1)>')), '');          // 不是位图一律不显示
  assert.throws(() => M.parseCover(Buffer.alloc(16)));
});

ok('driftRatio：偏差 <40ms 恒为 1（逐位原样）；偏差大才微调，幅度 ≤0.2%，带滞回', () => {
  const R = 48000, tgt = 2 * R, d = M.driftRatio;
  assert.strictEqual(d(tgt, tgt, R, false), 1);
  assert.strictEqual(d(tgt + 0.03 * R, tgt, R, false), 1);
  assert.ok(d(tgt + 0.5 * R, tgt, R, false) > 1);
  assert.ok(d(tgt - 0.5 * R, tgt, R, false) < 1);
  assert.ok(d(tgt + 60 * R, tgt, R, false) <= 1.002 + 1e-12);
  assert.ok(d(tgt - 60 * R, tgt, R, false) >= 0.998 - 1e-12);
  assert.notStrictEqual(d(tgt + 0.02 * R, tgt, R, true), 1);
  assert.strictEqual(d(tgt + 0.005 * R, tgt, R, true), 1);
});

console.log(failed ? 'FAILED' : 'ALL ' + pass + ' PASSED'); process.exit(failed ? 1 : 0);
