'use strict';
// node windows/test/lyrics.test.js —— 沉浸音乐歌词：LRC 解析、行定位、搜索清洗、候选打分、多来源回退（网络用桩）
const assert = require('assert');
const L = require('../lyrics');

let pass = 0, failed = false;
const ok = async (name, fn) => { try { await fn(); pass++; console.log('PASS ' + name); } catch (e) { failed = true; console.log('FAIL ' + name + '\n     ' + String(e.stack).split('\n').slice(0, 4).join('\n     ')); } };

(async () => {
  await ok('parseLrc：基本 / 多时间戳 / 元数据 / offset / 逐字标记', () => {
    const r = L.parseLrc('[ti:x]\n[ar:y]\n[offset:500]\n[00:10.50]第一句\r\n[00:05][01:00.5]副歌 <00:05.10>啦\n乱行\n[00:20.123]');
    assert.deepStrictEqual(r.map(x => [x.t, x.text]), [[4500, '副歌 啦'], [10000, '第一句'], [19623, ''], [60000, '副歌 啦']]);
    assert.deepStrictEqual(L.parseLrc('纯文本\n没有时间'), []);
    assert.deepStrictEqual(L.parseLrc(null), []);
  });
  await ok('lineAt：二分定位', () => {
    const ls = [{ t: 1000 }, { t: 2000 }, { t: 3000 }];
    assert.strictEqual(L.lineAt(ls, 0), -1); assert.strictEqual(L.lineAt(ls, 1000), 0); assert.strictEqual(L.lineAt(ls, 2999), 1); assert.strictEqual(L.lineAt(ls, 99999), 2);
    assert.strictEqual(L.lineAt([], 5), -1);
  });
  await ok('mergeTrans：翻译按时间戳合并', () => {
    const ls = L.parseLrc('[00:01.00]hello\n[00:03.00]world');
    L.mergeTrans(ls, L.parseLrc('[00:01.10]你好\n[00:09.00]无关'));
    assert.strictEqual(ls[0].tr, '你好'); assert.strictEqual(ls[1].tr, undefined);
  });
  await ok('cleanTitle / firstArtist', () => {
    assert.strictEqual(L.cleanTitle('晴天 (Live)'), '晴天');
    assert.strictEqual(L.cleanTitle('Song Name [Remastered 2011] feat. Bob'), 'Song Name');
    assert.strictEqual(L.cleanTitle('七里香 - 周杰伦', '周杰伦'), '七里香');
    assert.strictEqual(L.firstArtist('周杰伦 / 方文山'), '周杰伦'); assert.strictEqual(L.firstArtist('A&B'), 'A');
  });
  await ok('score：同名同歌手同时长高分，错歌低于门槛', () => {
    const w = { title: '晴天', artist: '周杰伦', duration: 269000 };
    assert(L.score({ name: '晴天', artist: '周杰伦', duration: 269500 }, w) > 3);
    assert(L.score({ name: '雨天', artist: '某某', duration: 120000 }, w) < 1.7);
  });

  const LRC = '[00:01.00]a\n[00:02.00]b\n[00:03.00]c';
  const mk = routes => async (url) => { for (const [k, v] of routes) if (url.includes(k)) { if (v instanceof Error) throw v; return typeof v === 'function' ? v(url) : v; } return null; };
  await ok('fetchLyrics：LRCLIB 精确命中', async () => {
    L._cache.clear();
    const r = await L.fetchLyrics({ title: 'Hello', artist: 'Adele', duration: 295000 }, mk([['lrclib.net/api/get', { syncedLyrics: LRC }]]));
    assert.strictEqual(r.source, 'LRCLIB'); assert.strictEqual(r.lines.length, 3);
  });
  await ok('fetchLyrics：LRCLIB 没有 → 网易云（带翻译），并缓存', async () => {
    L._cache.clear(); let n = 0;
    const get = mk([['lrclib.net/api/get', null], ['music.163.com/api/search', () => { n++; return { result: { songs: [{ id: 7, name: '晴天', artists: [{ name: '周杰伦' }], duration: 269000 }, { id: 8, name: '别的', artists: [{ name: 'X' }], duration: 1 }] } }; }],
      ['music.163.com/api/song/lyric?id=7', { lrc: { lyric: LRC }, tlyric: { lyric: '[00:01.00]甲' } }]]);
    const r = await L.fetchLyrics({ title: '晴天', artist: '周杰伦', duration: 269000 }, get);
    assert.strictEqual(r.source, '网易云'); assert.strictEqual(r.lines[0].tr, '甲');
    await L.fetchLyrics({ title: '晴天', artist: '周杰伦', duration: 269000 }, get); assert.strictEqual(n, 1);
  });
  await ok('fetchLyrics：网易云候选都不像 → 回退 LRCLIB 搜索；只有纯文本歌词的不算', async () => {
    L._cache.clear();
    const get = mk([['lrclib.net/api/get', null], ['music.163.com/api/search', { result: { songs: [{ id: 1, name: '完全不同', artists: [{ name: 'Z' }], duration: 5000 }] } }],
      ['lrclib.net/api/search', [{ trackName: 'Song', artistName: 'Band', duration: 200, plainLyrics: 'x' }, { trackName: 'Song', artistName: 'Band', duration: 201, syncedLyrics: LRC }]]]);
    const r = await L.fetchLyrics({ title: 'Song', artist: 'Band', duration: 200500 }, get);
    assert.strictEqual(r.lines.length, 3);
  });
  await ok('fetchLyrics：确实没有 → null 并缓存；全部网络失败 → 抛异常且不缓存', async () => {
    L._cache.clear();
    assert.strictEqual(await L.fetchLyrics({ title: 'Nope', artist: 'Nobody', duration: 1000 }, mk([])), null);
    assert.strictEqual(L._cache.size, 1);
    L._cache.clear();
    await assert.rejects(L.fetchLyrics({ title: 'Nope', artist: 'Nobody' }, async () => { throw new Error('offline'); }));
    assert.strictEqual(L._cache.size, 0);
  });

  await ok('normalizeMeta：占位歌手清掉；标题「A - B」拆开并保留两种读法', () => {
    assert.deepStrictEqual(L.normalizeMeta('晴天', '<unknown>'), { title: '晴天', artist: '' });
    assert.deepStrictEqual(L.normalizeMeta('晴天', '未知歌手'), { title: '晴天', artist: '' });
    const r = L.normalizeMeta('周杰伦 - 晴天', '');
    assert.strictEqual(r.title, '周杰伦'); assert.strictEqual(r.alt.title, '晴天'); assert.strictEqual(r.alt.artist, '周杰伦');
    assert.deepStrictEqual(L.normalizeMeta('A &amp; B', '周杰伦'), { title: 'A & B', artist: '周杰伦' });
  });
  await ok('酷我音乐：先查酷我；解析 lrclist；HTML 实体解码', async () => {
    L._cache.clear(); const urls = [];
    const get = async (url) => { urls.push(url);
      if (url.includes('kuwo.cn/api/www/search')) return { data: { list: [{ rid: 99, name: '晴&nbsp;天', artist: '周杰伦', duration: 269 }] } };
      if (url.includes('songinfoandlrc?musicId=99')) return { data: { lrclist: [{ time: '1.5', lineLyric: '甲' }, { time: '5.25', lineLyric: '乙' }, { time: '9', lineLyric: '丙' }] } };
      return null; };
    const r = await L.fetchLyrics({ title: '晴天', artist: '周杰伦', duration: 269000, app: '酷我音乐', pkg: 'cn.kuwo.player' }, get);
    assert.strictEqual(r.source, '酷我'); assert.deepStrictEqual(r.lines.map(l => l.t), [1500, 5250, 9000]);
    assert(urls[0].includes('kuwo.cn'), '酷我来的歌应先查酷我：' + urls[0]);
  });
  await ok('汽水音乐 / 中文歌：先网易云，再 QQ（实体歌词 + 翻译）', async () => {
    L._cache.clear(); const urls = [];
    const get = async (url) => { urls.push(url);
      if (url.includes('smartbox_new')) return { data: { song: { itemlist: [{ mid: 'M1', name: '晴天', singer: '周杰伦' }] } } };
      if (url.includes('fcg_query_lyric_new')) return { lyric: '[ti:晴天]&#10;[00&#58;01&#46;00]甲&#10;[00&#58;05&#46;00]乙&#10;[00&#58;09&#46;00]丙', trans: '[00&#58;01&#46;00]a' };
      return null; };
    const r = await L.fetchLyrics({ title: '晴天', artist: '周杰伦', duration: 269000, app: '汽水音乐', pkg: 'com.luna.music' }, get);
    assert.strictEqual(r.source, 'QQ音乐'); assert.strictEqual(r.lines.length, 3); assert.strictEqual(r.lines[0].tr, 'a');
    assert(urls[0].includes('music.163.com') && !urls.some(u => u.includes('lrclib.net/api/get') && urls.indexOf(u) === 0));
  });
  await ok('标题「歌手 - 歌名」且歌手为空：任一读法都能搜到', async () => {
    L._cache.clear();
    const get = async (url) => {
      if (url.includes('music.163.com/api/search')) return { result: { songs: [{ id: 5, name: '晴天', artists: [{ name: '周杰伦' }], duration: 269000 }] } };
      if (url.includes('lyric?id=5')) return { lrc: { lyric: '[00:01.00]a\n[00:02.00]b\n[00:03.00]c' } };
      return null; };
    const r = await L.fetchLyrics({ title: '周杰伦 - 晴天', artist: '<unknown>', duration: 269000, app: '酷我音乐' }, get);
    assert(r && r.source === '网易云');
  });
  await ok('歌词明显不是这首（比歌曲还长 30 秒以上 / 太短）→ 换下一个来源', async () => {
    L._cache.clear();
    const get = async (url) => {
      if (url.includes('lrclib.net/api/get')) return { syncedLyrics: '[00:01.00]a\n[00:02.00]b\n[09:00.00]c' };       // 最后一句 9 分钟，歌才 3 分钟
      if (url.includes('music.163.com/api/search')) return { result: { songs: [{ id: 5, name: 'Hello', artists: [{ name: 'Adele' }], duration: 180000 }] } };
      if (url.includes('lyric?id=5')) return { lrc: { lyric: '[00:01.00]a\n[00:02.00]b\n[00:03.00]c' } };
      return null; };
    const r = await L.fetchLyrics({ title: 'Hello', artist: 'Adele', duration: 180000 }, get);
    assert.strictEqual(r.source, '网易云');
  });

  await ok('matchLine / median：手机歌词行对上在线歌词并算偏移', () => {
    const ls = L.parseLrc('[00:10.00]我想要的 是你\n[00:20.00]Hello, World!\n[01:20.00]Hello World');
    assert.strictEqual(L.matchLine(ls, '我想要的是你', 10800).t, 10000);
    assert.strictEqual(L.matchLine(ls, 'hello world', 79000).t, 80000);          // 重复的句子取时间最近的
    assert.strictEqual(L.matchLine(ls, '完全不同的一句', 10000), null);
    assert.strictEqual(L.matchLine(ls, '我想要的是你', 60000), null);              // 差超过 12 秒不算
    assert.strictEqual(L.median([800, 700, 5000]), 800); assert.strictEqual(L.median([1, 3]), 2);
  });
  await ok('addLive：边听边攒，3 秒内同一句去重', () => {
    const a = []; assert(L.addLive(a, 5000, '第一句')); assert(!L.addLive(a, 6000, '第一句')); assert(L.addLive(a, 2000, '开头')); assert(L.addLive(a, 60000, '第一句'));
    assert.deepStrictEqual(a.map(x => x.t), [2000, 5000, 60000]); assert(!L.addLive(a, 1, '  '));
  });

  console.log(failed ? '\nFAILED' : '\nALL ' + pass + ' PASSED');
  process.exit(failed ? 1 : 0);
})();
