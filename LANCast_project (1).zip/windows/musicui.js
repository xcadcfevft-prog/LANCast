'use strict';
/* 瞬流「沉浸音乐」电脑端：接收手机发来的无损音频流 + 歌曲信息，渲染成实时播放器，并把控制指令发回手机。
 * 协议与断线续传见 music.js 文件头 / docs/PROTOCOL.md 第 23 节。
 *
 * 保活要点（电脑端）：
 *  · 播放期间阻止系统「应用挂起」（屏幕仍可熄灭）；窗口最小化 / 被遮挡不降速（main.js 已关闭后台节流）。
 *  · 手机重连时（同一个 sid）直接接管新连接，播放器、已缓冲的音频、封面都保留，只是告诉手机「从第 N 帧继续」。
 *  · 每 500 ms 向手机确认已收到的帧序号（也是应用层心跳）；对方 8 秒没任何动静就判定断线，等手机自动重连。 */
(function () {
  const { ipcRenderer } = require('electron');
  const MT = require('./music');
  const LY = require('./lyrics');
  const $ = s => document.querySelector(s);
  const T_CTRL = 5;
  const LSget = (k, d) => { try { const v = localStorage.getItem(k); return v === null ? d : v; } catch { return d; } };
  const LSset = (k, v) => { try { localStorage.setItem(k, String(v)); } catch {} };

  /* AudioWorklet：连续环形缓冲 + 时钟漂移补偿。
   * 倍率 = 1 时逐样本原样输出（无任何运算，真无损）；仅当手机 / 电脑声卡时钟漂移让缓冲偏离目标 >40 ms 才用三次插值微调（≤0.2%，见 music.js driftRatio）。 */
  const WORKLET = `
${MT.driftRatio.toString()}
class MPCM extends AudioWorkletProcessor {
  constructor() {
    super();
    this.cap = 1 << 18; this.L = new Float32Array(this.cap); this.R = new Float32Array(this.cap);
    this.wp = 0; this.rp = 0; this.ph = 0; this.ratio = 1; this.on = false; this.pre = 96000; this.rate = sampleRate; this.drift = true;
    this.played = 0; this.tick = 0; this.tickP = 0; this.under = 0;
    this.port.onmessage = e => {
      const d = e.data;
      if (d.cfg) { if (d.cfg.pre) this.pre = d.cfg.pre; if (d.cfg.drift !== undefined) { this.drift = !!d.cfg.drift; if (!this.drift) { this.ratio = 1; this.ph = 0; } } return; }
      if (d.flush !== undefined) {                       // 跳到实时：只保留最新的 flush 帧（切歌 / 拖动进度时丢掉旧音频）
        this.rp = Math.max(this.rp, this.wp - d.flush); this.ph = 0; this.on = false; return;
      }
      this.push(d.l, d.r);                               // 无损：不丢任何音频，积压多少存多少（断线补发时会一次涌进来很多）
    };
  }
  grow(need) {
    let nc = this.cap; while (nc < need) nc <<= 1;
    const nl = new Float32Array(nc), nr = new Float32Array(nc), om = this.cap - 1, nm = nc - 1;
    for (let k = this.rp - 2; k < this.wp; k++) { nl[k & nm] = this.L[k & om]; nr[k & nm] = this.R[k & om]; }
    this.L = nl; this.R = nr; this.cap = nc;
  }
  push(l, r) {
    const n = l.length;
    if (this.wp - this.rp + n + 8 > this.cap) this.grow(this.wp - this.rp + n + 8);
    const m = this.cap - 1;
    for (let i = 0, w = this.wp; i < n; i++, w++) { this.L[w & m] = l[i]; this.R[w & m] = r[i]; }
    this.wp += n;
  }
  process(inputs, outputs) {
    const o = outputs[0], oL = o[0], oR = o[1] || o[0], len = oL.length, m = this.cap - 1, L = this.L, R = this.R;
    if (!this.on && this.wp - this.rp >= this.pre) this.on = true;
    let i = 0;
    if (this.on) {
      if (this.drift && ++this.tick % 50 === 0) {
        const r = driftRatio(this.wp - this.rp, this.pre, this.rate, this.ratio !== 1);
        if (r === 1 && this.ratio !== 1) this.ph = 0;
        this.ratio = r;
      }
      if (this.ratio === 1) {
        const n = Math.min(len, this.wp - this.rp);
        for (; i < n; i++, this.rp++) { const k = this.rp & m; oL[i] = L[k]; oR[i] = R[k]; }
      } else {
        const rt = this.ratio;
        for (; i < len && this.wp - this.rp >= 3; i++) {
          const t = this.ph, t2 = t * t, t3 = t2 * t, a = (this.rp - 1) & m, b = this.rp & m, c = (this.rp + 1) & m, d = (this.rp + 2) & m;
          const w0 = -0.5 * t3 + t2 - 0.5 * t, w1 = 1.5 * t3 - 2.5 * t2 + 1, w2 = -1.5 * t3 + 2 * t2 + 0.5 * t, w3 = 0.5 * t3 - 0.5 * t2;
          oL[i] = L[a] * w0 + L[b] * w1 + L[c] * w2 + L[d] * w3;
          oR[i] = R[a] * w0 + R[b] * w1 + R[c] * w2 + R[d] * w3;
          this.ph += rt; while (this.ph >= 1) { this.ph -= 1; this.rp++; }
        }
      }
      this.played += i;
      if (i < len) { this.on = false; this.under++; this.ph = 0; this.ratio = 1; }   // 欠载：重新缓冲到预缓冲量再放，避免断断续续
    }
    for (; i < len; i++) { oL[i] = 0; oR[i] = 0; }
    if (++this.tickP % 20 === 0) this.port.postMessage({ q: this.wp - this.rp, played: this.played, on: this.on, ratio: this.ratio, under: this.under });
    return true;
  }
}
registerProcessor('mpcm', MPCM);`;

  /* 统一的线性图标（currentColor 着色），替代 emoji 字符，各平台字体下都一样精致 */
  const SV = (b, extra) => '<svg viewBox="0 0 24 24" aria-hidden="true"' + (extra || ' fill="currentColor"') + '>' + b + '</svg>';
  const SK = ' fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"';
  const IC = {
    prev: SV('<rect x="5" y="5" width="2.4" height="14" rx="1.2"/><path d="M19.6 6.2v11.6a.9.9 0 0 1-1.4.74L9.6 12.74a.9.9 0 0 1 0-1.48l8.6-5.8a.9.9 0 0 1 1.4.74z"/>'),
    next: SV('<rect x="16.6" y="5" width="2.4" height="14" rx="1.2"/><path d="M4.4 6.2v11.6a.9.9 0 0 0 1.4.74l8.6-5.8a.9.9 0 0 0 0-1.48l-8.6-5.8a.9.9 0 0 0-1.4.74z"/>'),
    play: SV('<path d="M8 5.7v12.6a1 1 0 0 0 1.52.86l10.2-6.3a1 1 0 0 0 0-1.72L9.52 4.84A1 1 0 0 0 8 5.7z"/>'),
    pause: SV('<rect x="6.4" y="5" width="4.1" height="14" rx="1.4"/><rect x="13.5" y="5" width="4.1" height="14" rx="1.4"/>'),
    back5: SV('<path d="M4.6 12a7.4 7.4 0 1 0 2.3-5.35"/><path d="M4.4 4.3v3.7h3.7"/><text x="12" y="15.3" font-size="8.4" font-weight="700" text-anchor="middle" fill="currentColor" stroke="none" font-family="Segoe UI,Arial,sans-serif">5</text>', SK),
    fwd5: SV('<path d="M19.4 12a7.4 7.4 0 1 1-2.3-5.35"/><path d="M19.6 4.3v3.7h-3.7"/><text x="12" y="15.3" font-size="8.4" font-weight="700" text-anchor="middle" fill="currentColor" stroke="none" font-family="Segoe UI,Arial,sans-serif">5</text>', SK),
    vol: SV('<path d="M4 9.6v4.8h3.4l4.6 3.9V5.7L7.4 9.6z" fill="currentColor" stroke="none"/><path d="M15.6 9.1a4 4 0 0 1 0 5.8M18.2 6.6a7.4 7.4 0 0 1 0 10.8"/>', SK),
    mute: SV('<path d="M4 9.6v4.8h3.4l4.6 3.9V5.7L7.4 9.6z" fill="currentColor" stroke="none"/><path d="M16 9.6l4.6 4.8M20.6 9.6L16 14.4"/>', SK)
  };
  const setIcon = (el, k) => { if (el && el.dataset.ic !== k) { el.dataset.ic = k; el.innerHTML = IC[k]; } };

  const CSS = `
#musicOv{--ac:255,255,255;--gc:255,255,255;position:fixed;inset:0;z-index:5;color:#fff;background:#0a0b0f;overflow:hidden;user-select:none;font-family:"Segoe UI Variable Text","Segoe UI","Microsoft YaHei UI","Microsoft YaHei",system-ui,sans-serif;-webkit-font-smoothing:antialiased}
#musicOv[hidden]{display:none}
#musicOv.idle{cursor:none}
@keyframes mov-in{from{opacity:0;transform:scale(1.025)}to{opacity:1;transform:none}}
@keyframes mov-out{from{opacity:1;transform:none}to{opacity:0;transform:scale(1.025)}}
#musicOv.in{animation:mov-in .55s cubic-bezier(.22,1,.36,1)}
#musicOv.out{animation:mov-out .28s cubic-bezier(.4,0,1,1) forwards;pointer-events:none}
#musicOv .mbg{position:absolute;inset:-7%;background-size:cover;background-position:center;transform:scale(1.2) translateZ(0);opacity:0;transition:opacity 1.4s cubic-bezier(.4,0,.2,1);will-change:opacity,transform;animation:mdrift 54s ease-in-out infinite alternate}
#musicOv .mbg:nth-of-type(2){animation-delay:-27s;animation-direction:alternate-reverse}
#musicOv .mbg.raw{filter:blur(72px) saturate(1.35) brightness(.46)}
#musicOv.paused .mbg{animation-play-state:paused}
@keyframes mdrift{0%{transform:scale(1.16) translate3d(-1.6%,-1.2%,0) rotate(-1.2deg)}50%{transform:scale(1.28) translate3d(1.8%,.8%,0) rotate(1deg)}100%{transform:scale(1.2) translate3d(-.6%,1.8%,0) rotate(2.4deg)}}
#musicOv .mbg.on{opacity:1}
#musicOv .mglow{position:absolute;inset:0;z-index:3;pointer-events:none;background:radial-gradient(ellipse at 30% 55%,rgba(var(--gc),.28),transparent 60%);opacity:.4;will-change:opacity}
#musicOv .mshade{position:absolute;inset:0;z-index:3;pointer-events:none;background:radial-gradient(ellipse 80% 70% at 50% 46%,transparent 35%,rgba(0,0,0,.5) 100%),linear-gradient(180deg,rgba(0,0,0,.18),rgba(0,0,0,.5))}
#musicOv .mshade::after{content:"";position:absolute;inset:0;opacity:.045;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='160' height='160'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='.9' numOctaves='2' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E")}
#musicOv .mtop{position:absolute;top:0;left:0;right:0;display:flex;align-items:center;gap:10px;padding:18px 24px;z-index:6;font-size:13px;transition:opacity .7s ease}
#musicOv .mtop .sp{flex:1}
#musicOv .mbtns{display:flex;gap:8px;align-items:center;touch-action:none}
#musicOv .mbtns.fl{position:fixed;margin:0;z-index:3}
#musicOv .mbtns.drag{cursor:grabbing;opacity:.92;filter:drop-shadow(0 6px 16px rgba(0,0,0,.5))}
#musicOv #mbHide{background:#ffc66d;color:#222}
#musicOv #mbHide:hover{background:#ffd48a}
#musicOv .mbtns.hid{min-width:48px;min-height:36px}
#musicOv .mbtns.hid > *:not(#mbHide){display:none}
#musicOv button{font:inherit;color:#fff;background:rgba(255,255,255,.1);border:0;border-radius:999px;padding:7px 16px;cursor:pointer;transition:background .25s ease,transform .2s ease,color .25s ease,box-shadow .25s ease}
#musicOv button:hover{background:rgba(255,255,255,.2)}
#musicOv button:active{transform:scale(.95)}
#musicOv button:disabled{opacity:.3;cursor:default;transform:none;background:transparent}
#musicOv button.on{background:rgba(var(--ac),.4)}
#musicOv button:focus-visible,#musicOv select:focus-visible{outline:2px solid rgba(255,255,255,.75);outline-offset:2px}
#musicOv .mbtns button{font-size:clamp(12.5px,1.7vh,17px);padding:.5em 1.3em;letter-spacing:.1em;color:rgba(255,255,255,.8);background:rgba(255,255,255,.1);box-shadow:inset 0 0 0 1px rgba(255,255,255,.1)}
#musicOv .mbtns button:hover{background:rgba(255,255,255,.18);color:#fff}
#musicOv #mEnd:hover{background:rgba(255,120,120,.3)}
#musicOv .mmain{position:absolute;inset:56px 0 0;display:flex;align-items:center;justify-content:center;gap:clamp(32px,5vw,120px);padding:0 4vw 2.5vh;z-index:5}
#musicOv .mcoverw{position:relative;flex:none;width:min(60vh,44vw,820px);aspect-ratio:1;will-change:transform;backface-visibility:hidden}
#musicOv .mcg{position:absolute;inset:-20%;border-radius:50%;background:radial-gradient(closest-side,rgba(var(--gc),.8) 62%,rgba(var(--gc),0) 100%);opacity:.3;will-change:opacity;pointer-events:none}
#musicOv .mcover{width:100%;height:100%;border-radius:10px;background:rgba(255,255,255,.06);box-shadow:0 2px 4px rgba(0,0,0,.3),0 18px 40px rgba(0,0,0,.45),0 40px 90px rgba(0,0,0,.35);position:relative;overflow:hidden;display:flex;align-items:center;justify-content:center;font-size:84px;color:rgba(255,255,255,.3)}
#musicOv .mcover::after{content:"";position:absolute;inset:0;border-radius:inherit;box-shadow:inset 0 0 0 1px rgba(255,255,255,.12);pointer-events:none;z-index:2}
#musicOv .mcover img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;display:block;opacity:0;transition:opacity .9s ease;will-change:opacity}
#musicOv .mcover img.on{opacity:1}
#musicOv .mcover img[hidden]{display:none}
@keyframes mrise{from{opacity:0;transform:translateY(14px);filter:blur(6px)}to{opacity:1;transform:none;filter:blur(0)}}
@keyframes mcin{from{transform:scale(.965)}to{transform:none}}
@keyframes mpop{from{opacity:0;transform:scale(.55) rotate(-14deg)}to{opacity:1;transform:none}}
#musicOv .mcover.swap{animation:mcin 1s cubic-bezier(.2,.9,.25,1.15)}
#musicOv .mctl button.big svg,#musicMini #miPlay svg{animation:mpop .34s cubic-bezier(.2,.9,.3,1.3)}
#musicOv .mtxt.swap > *{animation:mrise .8s cubic-bezier(.22,1,.36,1) backwards}
#musicOv .mtxt.swap > .msub{animation-delay:.07s}
#musicOv .mtxt.swap > .mapp{animation-delay:.14s}
#musicOv .mpanel{flex:1;min-width:0;max-width:min(46vw,860px);max-height:100%;display:flex;flex-direction:column;gap:clamp(12px,2.2vh,30px)}
#musicOv .mtxt{display:flex;flex-direction:column;gap:8px}
#musicOv .mtitle{font-size:clamp(30px,min(4.4vw,6.6vh),68px);font-weight:300;letter-spacing:.03em;line-height:1.28;text-shadow:0 2px 28px rgba(0,0,0,.35);overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}
#musicOv .msub{font-size:clamp(16px,min(1.9vw,2.8vh),28px);letter-spacing:.04em;color:rgba(255,255,255,.72);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#musicOv .mlyr{position:relative;flex:0 1 clamp(150px,32vh,420px);min-height:84px;overflow:hidden;contain:layout paint;-webkit-mask-image:linear-gradient(180deg,transparent,#000 24%,#000 76%,transparent);mask-image:linear-gradient(180deg,transparent,#000 24%,#000 76%,transparent)}
#musicOv .mlyr[hidden]{display:none}
#musicOv .mlyri{position:absolute;left:0;right:0;top:0;--sy:0px}
#musicOv .ml{padding:6px 0;font-size:clamp(18px,min(2.3vw,3.4vh),36px);line-height:1.45;color:#fff;opacity:var(--o,.3);transform:translate3d(0,var(--sy),0) scale(var(--sc,.94));transform-origin:left center;transition:transform .78s cubic-bezier(.22,1,.36,1) var(--dl,0ms),opacity .5s ease,filter .5s ease;cursor:default;overflow-wrap:anywhere}
#musicOv .ml.bl{filter:blur(var(--b,0px))}
#musicOv .ml.far{visibility:hidden;transition:none}
#musicOv .mlyri.jump .ml{transition:none !important}
#musicOv .ml.cur{text-shadow:0 2px 24px rgba(0,0,0,.4)}
#musicOv .ml.sk{cursor:pointer}
#musicOv .ml.sk:hover{opacity:.8 !important;filter:none !important}
#musicOv .ml.cur.sk:hover{opacity:1 !important}
#musicOv .ml small{display:block;font-size:.8em;opacity:.75}
#musicOv .mapp{font-size:clamp(12px,1.7vh,16px);letter-spacing:.06em;color:rgba(255,255,255,.4)}
#musicOv canvas.mviz{width:100%;height:clamp(48px,7vh,100px);display:block;margin-top:6px}
#musicOv .mprog{display:flex;align-items:center;gap:14px;font-size:clamp(12px,1.7vh,16px);letter-spacing:.02em;color:rgba(255,255,255,.55);font-variant-numeric:tabular-nums}
#musicOv .mbar{flex:1;height:28px;display:flex;align-items:center;cursor:pointer;position:relative;touch-action:none}
#musicOv .mbar i{display:block;width:100%;height:3px;border-radius:2px;background:rgba(255,255,255,.18);position:relative;transition:transform .22s cubic-bezier(.22,1,.36,1)}
#musicOv .mbar:hover i,#musicOv .mbar.drag i{transform:scaleY(2)}
#musicOv .mbar b{position:absolute;left:0;top:0;bottom:0;width:100%;transform-origin:left;transform:scaleX(0);background:linear-gradient(90deg,rgba(var(--ac),.5),rgb(var(--ac)));border-radius:inherit;box-shadow:0 0 12px rgba(var(--ac),.5);will-change:transform}
#musicOv .mbar u{position:absolute;top:50%;left:0;width:13px;height:13px;margin:-6.5px 0 0 -6.5px;border-radius:50%;background:#fff;box-shadow:0 1px 6px rgba(0,0,0,.5);opacity:0;transition:opacity .15s;will-change:transform;pointer-events:none}
#musicOv .mbar:hover u,#musicOv .mbar.drag u{opacity:1}
#musicOv .mbar s{position:absolute;bottom:22px;left:0;padding:2px 8px;border-radius:6px;background:rgba(0,0,0,.7);font-size:11px;text-decoration:none;opacity:0;pointer-events:none;transform:translateX(-50%)}
#musicOv .mbar:hover s,#musicOv .mbar.drag s{opacity:1}
#musicOv .mctl{display:flex;align-items:center;justify-content:center;gap:14px;margin-top:2px}
#musicOv .mctl button{width:clamp(54px,7.4vh,84px);height:clamp(54px,7.4vh,84px);padding:0;display:flex;align-items:center;justify-content:center;background:transparent;color:rgba(255,255,255,.88)}
#musicOv .mctl button:hover{background:rgba(255,255,255,.12);color:#fff}
#musicOv .mctl button svg{width:clamp(26px,3.6vh,40px);height:clamp(26px,3.6vh,40px);display:block}
#musicOv .mctl button.sm{width:clamp(48px,6.6vh,76px);height:clamp(48px,6.6vh,76px);color:rgba(255,255,255,.7)}
#musicOv .mctl button.sm svg{width:clamp(30px,4.2vh,46px);height:clamp(30px,4.2vh,46px)}
#musicOv .mctl button.sm:hover{color:#fff}
#musicOv .mctl button.big{width:clamp(76px,10.6vh,112px);height:clamp(76px,10.6vh,112px);margin:0 6px;background:#fff;color:#14161c;box-shadow:0 10px 30px rgba(0,0,0,.4),0 0 0 7px rgba(255,255,255,.09)}
#musicOv .mctl button.big svg{width:clamp(30px,4.4vh,48px);height:clamp(30px,4.4vh,48px)}
#musicOv .mctl button.big:hover{background:#fff;transform:scale(1.05);box-shadow:0 12px 34px rgba(0,0,0,.45),0 0 0 10px rgba(255,255,255,.11)}
#musicOv .mctl button.big:active{transform:scale(.96)}
#musicOv .mctl button.big:disabled{background:rgba(255,255,255,.35);box-shadow:none}
#musicOv .mrow{display:flex;align-items:center;justify-content:center;gap:10px 14px;flex-wrap:wrap;font-size:clamp(12px,1.7vh,15px);color:rgba(255,255,255,.6);opacity:.72;transition:opacity .6s ease,transform .6s cubic-bezier(.22,1,.36,1)}
#musicOv .mrow:hover,#musicOv .mrow:focus-within{opacity:1}
#musicOv .mrow label{display:inline-flex;align-items:center;gap:8px}
#musicOv .mrow button{padding:.4em 1em;font-size:clamp(12px,1.7vh,15px);color:rgba(255,255,255,.85);background:rgba(255,255,255,.08);box-shadow:inset 0 0 0 1px rgba(255,255,255,.08)}
#musicOv .mrow button:hover{background:rgba(255,255,255,.18)}
#musicOv .mrow #mMute{width:32px;height:32px;padding:0;display:inline-flex;align-items:center;justify-content:center}
#musicOv .mrow button svg{width:16px;height:16px;display:block}
#musicOv .mrow input[type=range]{-webkit-appearance:none;appearance:none;width:112px;height:18px;margin:0;background:transparent;cursor:pointer;--v:100%}
#musicOv .mrow input[type=range]::-webkit-slider-runnable-track{height:3px;border-radius:2px;background:linear-gradient(90deg,rgba(255,255,255,.85) var(--v),rgba(255,255,255,.2) var(--v))}
#musicOv .mrow input[type=range]::-webkit-slider-thumb{-webkit-appearance:none;width:11px;height:11px;margin-top:-4px;border-radius:50%;background:#fff;box-shadow:0 1px 5px rgba(0,0,0,.5);transition:transform .15s}
#musicOv .mrow input[type=range]:hover::-webkit-slider-thumb{transform:scale(1.3)}
#musicOv .mrow select{-webkit-appearance:none;appearance:none;font:inherit;color:#fff;background:rgba(255,255,255,.08) url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 10 6'%3E%3Cpath d='M1 1l4 4 4-4' fill='none' stroke='white' stroke-opacity='.7' stroke-width='1.4' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E") no-repeat right 9px center/9px;border:0;border-radius:999px;padding:.4em 2em .4em 1em;cursor:pointer;box-shadow:inset 0 0 0 1px rgba(255,255,255,.08);transition:background-color .25s}
#musicOv .mrow select:hover{background-color:rgba(255,255,255,.16)}
#musicOv .mrow select option{color:#111;background:#fff}
#musicOv .mstat{position:absolute;left:50%;bottom:24px;transform:translateX(-50%);max-width:min(640px,86vw);padding:9px 18px;z-index:6;border-radius:16px;text-align:center;font-size:12.5px;line-height:1.6;white-space:pre-line;color:rgba(255,255,255,.82);background:rgba(0,0,0,.42);-webkit-backdrop-filter:blur(14px);backdrop-filter:blur(14px);box-shadow:inset 0 0 0 1px rgba(255,255,255,.08)}
#musicOv .mstat[hidden]{display:none}
#musicOv .mstat.warn{color:#ffd9a0}
#musicOv .mstat.bad{color:#ffb0b0}
#musicOv.idle .mtop{opacity:0}
#musicOv.idle .mrow{opacity:0;transform:translateY(10px)}
@media (max-width:820px){#musicOv .mmain{flex-direction:column;gap:20px;overflow:auto;align-items:center;justify-content:flex-start;padding-top:8px}#musicOv .mcoverw{width:min(44vh,70vw)}#musicOv .mpanel{width:100%}}
@media (prefers-reduced-motion:reduce){#musicOv,#musicOv *,#musicMini,#musicMini *{transition:none !important;animation:none !important}}
#musicMini{position:fixed;right:16px;bottom:16px;z-index:6;max-width:360px;display:flex;align-items:center;gap:8px;padding:6px 8px 6px 6px;border-radius:999px;background:rgba(18,21,28,.86);-webkit-backdrop-filter:blur(18px);backdrop-filter:blur(18px);color:#fff;font-size:13px;cursor:pointer;box-shadow:0 8px 30px rgba(0,0,0,.4),inset 0 0 0 1px rgba(255,255,255,.08)}
#musicMini.drag{cursor:grabbing;opacity:.92;box-shadow:0 8px 26px rgba(0,0,0,.55);transition:none}
#musicMini{touch-action:none;user-select:none}
@keyframes mmini-in{from{opacity:0;transform:translateY(14px) scale(.94)}to{opacity:1;transform:none}}
@keyframes mspin{to{transform:rotate(360deg)}}
#musicMini.in{animation:mmini-in .5s cubic-bezier(.22,1,.36,1)}
#musicMini #miImg{animation:mspin 22s linear infinite paused}
#musicMini.pl #miImg{animation-play-state:running}
#musicMini #miHide{width:auto;border-radius:999px;padding:0 10px;background:#ffc66d;color:#222;font-size:12px}
#musicMini.hid{background:transparent;box-shadow:none;-webkit-backdrop-filter:none;backdrop-filter:none;min-width:48px;min-height:40px;padding:0}
#musicMini.hid > *:not(#miHide){display:none}
html.noScroll,html.noScroll body,html:fullscreen,html:fullscreen body{overflow:hidden !important;scrollbar-width:none}
html.noScroll::-webkit-scrollbar,html:fullscreen::-webkit-scrollbar,html.noScroll body::-webkit-scrollbar{display:none;width:0;height:0}
#musicMini[hidden]{display:none}
#musicMini img{width:34px;height:34px;border-radius:50%;object-fit:cover;flex:none;background:#2a2e38}
#musicMini .mt{min-width:0;flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;padding:0 4px;letter-spacing:.02em}
#musicMini button{flex:none;width:30px;height:30px;border:0;border-radius:50%;background:rgba(255,255,255,.1);color:#fff;cursor:pointer;padding:0;display:flex;align-items:center;justify-content:center}
#musicMini button svg{width:14px;height:14px;display:block}
#musicMini button:hover{background:rgba(255,255,255,.24)}
#musicMini button:disabled{opacity:.35}
`;

  const HTML = `
<div class="mbg"></div><div class="mbg"></div><div class="mglow"></div><div class="mshade"></div>
<div class="mtop"><span class="sp"></span><div class="mbtns" id="mBtns" title="长按不放可拖动位置，并出现「隐藏」按钮"><button id="mbHide" hidden>隐藏</button><button id="mFs" title="全屏（F）">全屏</button><button id="mHide" title="收起到右下角，音乐继续播放（Esc）">收起</button><button id="mEnd" title="结束并通知手机停止">断开</button></div></div>
<div class="mmain">
  <div class="mcoverw" id="mCoverW"><div class="mcg" id="mCG"></div><div class="mcover" id="mCover"><img id="mImg" alt=""><img id="mImg2" alt=""><span id="mPh">♪</span></div></div>
  <div class="mpanel">
    <div class="mtxt" id="mTxt"><div class="mtitle" id="mTitle">等待手机开始播放…</div><div class="msub" id="mSub"></div><div class="mapp" id="mApp"></div></div>
    <div class="mlyr" id="mLyr" hidden><div class="mlyri" id="mLyrI"></div></div>
    <canvas class="mviz" id="mViz"></canvas>
    <div class="mprog"><span id="mCur">0:00</span><div class="mbar" id="mBar"><i><b id="mFill"></b></i><u id="mThumb"></u><s id="mTip">0:00</s></div><span id="mDur">0:00</span></div>
    <div class="mctl"><button id="mPrev" title="上一首（Ctrl+← / P）">${IC.prev}</button><button id="mBack" class="sm" title="后退 5 秒（←）">${IC.back5}</button><button id="mPlay" class="big" title="播放 / 暂停（空格 / 键盘媒体键）">${IC.play}</button><button id="mFwd" class="sm" title="快进 5 秒（→）">${IC.fwd5}</button><button id="mNext" title="下一首（Ctrl+→ / N）">${IC.next}</button></div>
    <div class="mrow">
      <button id="mMute" title="静音（M）">${IC.vol}</button><input id="mVol" type="range" min="0" max="100" step="1" title="音量（↑ / ↓）">
      <label>缓冲 <select id="mBuf"><option value="0.5">0.5 秒</option><option value="1">1 秒</option><option value="2">2 秒</option><option value="5">5 秒</option><option value="10">10 秒</option></select></label>
      <label title="手机与电脑声卡时钟有微小差异，长时间播放缓冲会慢慢变多或变少。开启：偏差超过 40 ms 才以 ≤0.2% 倍率微调（听不出）；其余时间逐样本原样输出。关闭：绝不改动样本，但可能偶尔欠载重缓冲。">时钟同步 <select id="mDrift"><option value="1">开</option><option value="0">关</option></select></label>
      <button id="mLyrBtn" title="显示 / 隐藏歌词（L）。歌词由电脑按歌名、歌手在线查找（酷我 / 网易云 / QQ音乐 / LRCLIB）。歌词偏早或偏晚：按 [ 提前 0.5 秒、] 推后 0.5 秒，\\ 复位">歌词</button>
      <button id="mLive" title="丢掉电脑端积压的音频，直接跟上手机当前播放的位置">跳到实时</button>
    </div>
  </div>
</div>
<div class="mstat" id="mStat" hidden></div>`;

  let ov = null, mini = null, M = null, tickT = 0, ackT = 0, raf = 0, shown = true, drag = null, hoverF = 0;
  let accent = '255,255,255', lastKey = '', vizW = 0, vizH = 0, dpr = 1, bass = 0, pulse = 0.4, scaleCur = 0.92, scaleV = 0;
  let E = null, szBar = 0, szLyr = 0, lyrRev = 0, barHover = false, lastF = 0, vizHot = true, vizDirty = true, vizCtx = null, vizG = null, vizGK = '', bandKey = '', showT = 0, inT = 0;
  let lastFill = '', lastThumb = '', lastCw = '', lastCg = '', lastGl = '', accF = [255, 255, 255], accTgt = null;
  const bars = new Uint8Array(1024), BN = 56, hv = new Float32Array(BN), pk = new Float32Array(BN), rv = new Float32Array(BN), bk0 = new Int32Array(BN), bk1 = new Int32Array(BN);

  function ensureDom() {
    if (ov) return;
    const st = document.createElement('style'); st.textContent = CSS; document.head.appendChild(st);
    ov = document.createElement('div'); ov.id = 'musicOv'; ov.hidden = true; ov.innerHTML = HTML; document.body.appendChild(ov);
    mini = document.createElement('div'); mini.id = 'musicMini'; mini.hidden = true;
    mini.innerHTML = '<img id="miImg" alt="" hidden><span class="mt" id="miTxt"></span><button data-c="prev" title="上一首">' + IC.prev + '</button><button data-c="toggle" id="miPlay" title="播放 / 暂停">' + IC.play + '</button><button data-c="next" title="下一首">' + IC.next + '</button>';
    mini.insertAdjacentHTML('beforeend', '<button id="miHide" hidden>隐藏</button>');
    mini.title = '长按不放可拖动位置，并出现「隐藏」按钮';
    mini.onclick = e => {
      if (miJust) return;
      if (e.target.id === 'miHide') { miSetHidden(!miHidden); return; }
      if (miHidden) return;
      const b = e.target.closest && e.target.closest('button[data-c]'); if (b) { cmd(b.dataset.c); e.stopPropagation(); } else show(true);
    };
    document.body.appendChild(mini);
    E = { cw: $('#mCoverW'), cg: $('#mCG'), gl: ov.querySelector('.mglow'), fill: $('#mFill'), thumb: $('#mThumb'), bar: $('#mBar'), tip: $('#mTip'), cur: $('#mCur'), dur: $('#mDur'), lyr: $('#mLyr'), lyri: $('#mLyrI'), viz: $('#mViz') };
    if (typeof ResizeObserver === 'function') {                       // 尺寸只在变化时测一次并缓存，逐帧不再读 clientWidth / clientHeight（那会强制重排）
      const ro = new ResizeObserver(() => { szBar = E.bar.clientWidth; szLyr = E.lyr.clientHeight; lyrRev++; vizW = 0; });
      ro.observe(E.bar); ro.observe(E.lyr); ro.observe(E.viz);
    }
    initMiniDrag();
    initBtnsDrag();
    $('#mHide').onclick = () => show(false);
    $('#mEnd').onclick = () => end('已断开', true);
    $('#mFs').onclick = toggleFs;
    $('#mCoverW').ondblclick = toggleFs;
    $('#mPrev').onclick = () => cmd('prev'); $('#mNext').onclick = () => cmd('next');
    $('#mPlay').onclick = () => cmd('toggle');
    $('#mBack').onclick = () => seekBy(-5000); $('#mFwd').onclick = () => seekBy(5000);
    $('#mLive').onclick = () => { if (M && M.node) { M.node.port.postMessage({ flush: Math.round(M.cfg.rate * 0.3) }); } };
    const vol = $('#mVol'); vol.value = LSget('music:vol', '100'); vol.style.setProperty('--v', vol.value + '%');
    vol.oninput = () => { LSset('music:vol', vol.value); if (vol.value > 0) setMute(false); applyGain(); };
    vol.onwheel = e => { e.preventDefault(); stepVol(e.deltaY < 0 ? 5 : -5); };
    $('#mMute').onclick = () => setMute(!muted());
    const buf = $('#mBuf'); buf.value = LSget('music:buf', '2'); if (buf.value !== LSget('music:buf', '2')) buf.value = '2';
    buf.onchange = () => { LSset('music:buf', buf.value); applyBuf(); };
    const dr = $('#mDrift'); dr.value = LSget('music:drift', '1'); dr.onchange = () => { LSset('music:drift', dr.value); applyBuf(); };
    syncMuteBtn();
    $('#mLyrBtn').onclick = lyrToggle;
    $('#mLyrI').onclick = e => { const el = e.target.closest && e.target.closest('.ml'); if (el && canSeek()) cmd('seek', { pos: Number(el.dataset.t) }); };
    applyLyrVis(); syncLyrBtn();
    // 沉浸：鼠标 / 键盘静止几秒后，顶部按钮和底部设置行淡出、光标隐藏；一动就回来
    let lastWake = 0;
    const wakeUi = () => { const t = Date.now(); if (t - lastWake < 400 && !ov.classList.contains('idle')) return; lastWake = t; wakeIdle(); };
    ov.addEventListener('pointermove', wakeUi); ov.addEventListener('pointerdown', wakeUi); document.addEventListener('keydown', () => { if (M && ov && !ov.hidden) wakeIdle(); });
    // 进度条：悬停显示目标时间，按下拖动预览，松手才真正 seek
    const bar = $('#mBar');
    const frac = e => { const r = bar.getBoundingClientRect(); return Math.min(1, Math.max(0, (e.clientX - r.left) / r.width)); };
    const canSeek = () => M && M.meta && M.meta.duration > 0 && M.meta.can.includes('seek') && M.meta.ctl;
    bar.onpointerenter = () => { barHover = true; }; bar.onpointerleave = () => { barHover = false; };
    bar.onpointermove = e => { hoverF = frac(e); if (drag) drag.f = hoverF; };
    bar.onpointerdown = e => { if (!canSeek()) return; drag = { f: frac(e) }; bar.classList.add('drag'); bar.setPointerCapture(e.pointerId); };
    bar.onpointerup = e => {
      if (!drag) return;
      const f = frac(e); drag = null; bar.classList.remove('drag');
      if (canSeek()) cmd('seek', { pos: Math.round(f * M.meta.duration) });
    };
    bar.onpointercancel = () => { drag = null; bar.classList.remove('drag'); };
    document.addEventListener('keydown', e => {
      if (!M || ov.hidden || e.target.closest && e.target.closest('input,textarea,select')) return;
      const k = e.code;
      if (e.altKey || ((e.ctrlKey || e.metaKey) && k !== 'ArrowLeft' && k !== 'ArrowRight')) return;   // 只有 Ctrl+←/→ 属于播放器，其余组合键留给系统 / 其它功能
      if (k === 'Space') cmd('toggle');
      else if (k === 'ArrowRight') { if (e.ctrlKey || e.metaKey) cmd('next'); else seekBy(5000); }
      else if (k === 'ArrowLeft') { if (e.ctrlKey || e.metaKey) cmd('prev'); else seekBy(-5000); }
      else if (k === 'KeyN' || k === 'PageDown') cmd('next');
      else if (k === 'KeyP' || k === 'PageUp') cmd('prev');
      else if (k === 'ArrowUp') stepVol(5); else if (k === 'ArrowDown') stepVol(-5);
      else if (k === 'KeyM') setMute(!muted());
      else if (k === 'KeyF') toggleFs();
      else if (k === 'KeyL') lyrToggle();
      else if (k === 'BracketLeft') lyrNudge(-500); else if (k === 'BracketRight') lyrNudge(500); else if (k === 'Backslash') lyrNudge(0);
      else if (k === 'Escape') { if (document.fullscreenElement) document.exitFullscreen(); else show(false); }
      else return;
      e.preventDefault();
    });
    ipcRenderer.on('music-key', (e, k) => { if (!M) return; if (k === 'toggle') cmd('toggle'); else if (k === 'next') cmd('next'); else if (k === 'prev') cmd('prev'); });
    // 保活：声卡 / 耳机切换、系统唤醒、窗口重新可见后，音频上下文可能被系统挂起，马上恢复
    const wake = () => { if (M && M.ctx && M.ctx.state !== 'running' && M.ctx.state !== 'closed') M.ctx.resume().catch(() => {}); };
    try { navigator.mediaDevices.addEventListener('devicechange', wake); } catch {}
    document.addEventListener('visibilitychange', wake); window.addEventListener('focus', wake);

    window.addEventListener('beforeunload', () => { if (M) { try { ipcRenderer.send('keep-awake-music', false); } catch {} } });   // 页面被刷新：别让主进程一直占着防挂起 / 媒体键
  }

  /* 后台音乐小条：长按约 0.4 秒进入拖动（同时出现「隐藏」按钮），位置按比例记住；隐藏后只留一小块透明区域，再长按出现「显示」。 */
  let miHidden = false, miJust = false;
  function miPlace(l, t) {
    const W = innerWidth - mini.offsetWidth, H = innerHeight - mini.offsetHeight;
    mini.style.right = 'auto'; mini.style.bottom = 'auto';
    mini.style.left = Math.min(Math.max(0, l), Math.max(0, W)) + 'px';
    mini.style.top = Math.min(Math.max(0, t), Math.max(0, H)) + 'px';
  }
  function miRestore() {
    if (!mini || mini.hidden || mini.offsetWidth === 0) return;
    let p = null; try { p = JSON.parse(localStorage.getItem('miniPos') || 'null'); } catch {}
    if (p) miPlace(p.fx * (innerWidth - mini.offsetWidth), p.fy * (innerHeight - mini.offsetHeight));
  }
  function miSetHidden(v) {
    miHidden = !!v; mini.classList.toggle('hid', miHidden); miEditEnd();
    const r = mini.getBoundingClientRect(); miPlace(r.left, r.top);
  }
  let miEditT = 0;
  function miEditShow() { const b = mini.querySelector('#miHide'); b.hidden = false; b.textContent = miHidden ? '显示' : '隐藏'; clearTimeout(miEditT); miEditT = setTimeout(miEditEnd, 4000); }
  function miEditEnd() { clearTimeout(miEditT); const b = mini && mini.querySelector('#miHide'); if (b) b.hidden = true; }
  function initMiniDrag() {
    let timer = 0, dragging = false, sx = 0, sy = 0, ox = 0, oy = 0;
    mini.addEventListener('pointerdown', e => {
      if (e.button !== 0) return;
      sx = e.clientX; sy = e.clientY; clearTimeout(timer);
      timer = setTimeout(() => {
        dragging = true; mini.classList.add('drag'); miEditShow();
        const r = mini.getBoundingClientRect(); ox = r.left; oy = r.top; miPlace(ox, oy);
        try { mini.setPointerCapture(e.pointerId); } catch {}
      }, 400);
    });
    mini.addEventListener('pointermove', e => {
      if (!dragging) { if (Math.hypot(e.clientX - sx, e.clientY - sy) > 6) clearTimeout(timer); return; }
      miPlace(ox + e.clientX - sx, oy + e.clientY - sy);
    });
    const end = () => {
      clearTimeout(timer);
      if (!dragging) return;
      dragging = false; mini.classList.remove('drag'); miJust = true; setTimeout(() => { miJust = false; }, 120);
      const r = mini.getBoundingClientRect(), fw = innerWidth - r.width, fh = innerHeight - r.height;
      try { localStorage.setItem('miniPos', JSON.stringify({ fx: fw > 0 ? r.left / fw : 0, fy: fh > 0 ? r.top / fh : 0 })); } catch {}
    };
    mini.addEventListener('pointerup', end); mini.addEventListener('pointercancel', end);
    window.addEventListener('resize', miRestore);
  }

  /* 右上角「全屏 / 收起 / 断开」：长按约 0.4 秒可拖动（同时出现「隐藏」）；隐藏后只留一小块透明区域，再长按出现「显示」。位置按比例记住。 */
  let bxHidden = false, bxJust = false, bxEditT = 0;
  function bxPlace(l, t) {
    const b = $('#mBtns'), W = innerWidth - b.offsetWidth, H = innerHeight - b.offsetHeight;
    b.classList.add('fl');
    b.style.left = Math.min(Math.max(0, l), Math.max(0, W)) + 'px';
    b.style.top = Math.min(Math.max(0, t), Math.max(0, H)) + 'px';
  }
  function bxRestore() {
    const b = ov && $('#mBtns'); if (!b || b.offsetWidth === 0 || b.classList.contains('drag')) return;
    let p = null; try { p = JSON.parse(localStorage.getItem('musicBtnsPos') || 'null'); } catch {}
    if (p) bxPlace(p.fx * (innerWidth - b.offsetWidth), p.fy * (innerHeight - b.offsetHeight));
  }
  function bxEditEnd() { clearTimeout(bxEditT); const h = $('#mbHide'); if (h) h.hidden = true; }
  function bxEditShow() { const h = $('#mbHide'); h.hidden = false; h.textContent = bxHidden ? '显示' : '隐藏'; clearTimeout(bxEditT); bxEditT = setTimeout(bxEditEnd, 4000); }
  function bxSetHidden(v) {
    const b = $('#mBtns'); bxHidden = !!v; b.classList.toggle('hid', bxHidden); bxEditEnd();
    const r = b.getBoundingClientRect(); bxPlace(r.left, r.top);
  }
  function initBtnsDrag() {
    const b = $('#mBtns'); let timer = 0, dragging = false, sx = 0, sy = 0, ox = 0, oy = 0;
    $('#mbHide').onclick = () => bxSetHidden(!bxHidden);
    b.addEventListener('pointerdown', e => {
      if (e.button !== 0) return;
      sx = e.clientX; sy = e.clientY; clearTimeout(timer);
      if (!$('#mbHide').hidden) { clearTimeout(bxEditT); bxEditT = setTimeout(bxEditEnd, 4000); }
      timer = setTimeout(() => {
        dragging = true; b.classList.add('drag'); bxEditShow();
        const r = b.getBoundingClientRect(); ox = r.left; oy = r.top; bxPlace(ox, oy);
        try { b.setPointerCapture(e.pointerId); } catch {}
      }, 400);
    });
    b.addEventListener('pointermove', e => {
      if (!dragging) { if (Math.hypot(e.clientX - sx, e.clientY - sy) > 6) clearTimeout(timer); return; }
      bxPlace(ox + e.clientX - sx, oy + e.clientY - sy);
    });
    const end = () => {
      clearTimeout(timer);
      if (!dragging) return;
      dragging = false; b.classList.remove('drag'); bxJust = true; setTimeout(() => { bxJust = false; }, 120);
      const r = b.getBoundingClientRect(), fw = innerWidth - r.width, fh = innerHeight - r.height;
      try { localStorage.setItem('musicBtnsPos', JSON.stringify({ fx: fw > 0 ? r.left / fw : 0, fy: fh > 0 ? r.top / fh : 0 })); } catch {}
    };
    b.addEventListener('pointerup', end); b.addEventListener('pointercancel', end);
    b.addEventListener('click', e => { if (bxJust) { e.stopPropagation(); e.preventDefault(); } }, true);   // 拖动结束不触发按钮
    window.addEventListener('resize', bxRestore);
  }
  let idleT = 0;
  function wakeIdle() { if (!ov) return; ov.classList.remove('idle'); clearTimeout(idleT); idleT = setTimeout(goIdle, 3200); }
  function goIdle() {
    if (!ov || ov.hidden || !M) return;
    const busy = drag || !$('#mbHide').hidden || ov.querySelector('.mbtns:hover,.mbtns.drag,.mrow:hover,.mrow:focus-within');   // 正在操作时不淡出
    if (busy) { idleT = setTimeout(goIdle, 1500); return; }
    ov.classList.add('idle');
  }
  function show(on) {
    const was = shown; shown = on; clearTimeout(showT);
    if (ov) {
      if (on) {                                                    // 展开：整体轻轻缩放淡入
        ov.classList.remove('out');
        if (ov.hidden || !was) { ov.hidden = false; ov.classList.remove('in'); void ov.offsetWidth; ov.classList.add('in'); clearTimeout(inT); inT = setTimeout(() => { if (ov) ov.classList.remove('in'); }, 650); }
      } else if (!ov.hidden) {                                     // 收起：先淡出再真正隐藏
        clearTimeout(inT); ov.classList.remove('in'); ov.classList.add('out');
        showT = setTimeout(() => { if (ov) { ov.hidden = true; ov.classList.remove('out'); } }, 300);
      }
    }
    if (mini) { mini.hidden = on || !M; if (!on && M) { mini.classList.remove('in'); void mini.offsetWidth; mini.classList.add('in'); } }
    document.documentElement.classList.toggle('noScroll', !!on);
    if (!on) { clearTimeout(idleT); setTimeout(miRestore, 0); } else { setTimeout(bxRestore, 0); wakeIdle(); }
    if (on) { tick(); startViz(); }
  }
  function toggleFs() {
    try {
      const p = document.fullscreenElement ? document.exitFullscreen() : document.documentElement.requestFullscreen();
      if (p && p.catch) p.catch(() => {});
    } catch {}
  }
  function seekBy(d) {
    if (!M || !M.meta || !(M.meta.duration > 0) || !M.meta.can.includes('seek')) return;
    cmd('seek', { pos: Math.round(Math.min(M.meta.duration, Math.max(0, curPos() + d))) });
  }
  const muted = () => LSget('music:mute', '0') === '1';
  function setMute(v) { LSset('music:mute', v ? 1 : 0); syncMuteBtn(); applyGain(); }
  function syncMuteBtn() {
    const b = $('#mMute'), v = $('#mVol');
    if (v) v.style.setProperty('--v', (muted() ? 0 : Number(v.value)) + '%');                // 音量条已填充的部分
    if (b) { setIcon(b, muted() || Number(v.value) === 0 ? 'mute' : 'vol'); b.classList.toggle('on', muted()); }
  }
  function stepVol(d) { const v = $('#mVol'); v.value = Math.min(100, Math.max(0, Number(v.value) + d)); v.oninput(); syncMuteBtn(); }
  function applyGain() {
    syncMuteBtn();
    if (M && M.gain && M.ctx) M.gain.gain.setTargetAtTime(muted() ? 0 : $('#mVol').value / 100, M.ctx.currentTime, 0.03);   // 平滑过渡，拖音量不出“嚓嚓”声
  }

  /* ───────── 音频输出 ───────── */
  function applyBuf() { if (M && M.node && M.cfg) M.node.port.postMessage({ cfg: { pre: Math.round(M.cfg.rate * Number($('#mBuf').value || 2)), drift: $('#mDrift').value !== '0' } }); }
  function setupAudio(cfg) {
    if (M.cfg && M.cfg.rate === cfg.rate && M.cfg.ch === cfg.ch && M.ctx && M.ctx.state !== 'closed') { M.cfg = cfg; return; }
    teardownAudio();
    M.cfg = cfg;
    const ctx = M.ctx = new AudioContext({ sampleRate: cfg.rate, latencyHint: 'playback' });   // 音乐：用更大的输出缓冲换稳定，不追求低延迟
    ctx.onstatechange = () => { if (M && M.ctx === ctx && ctx.state === 'suspended') ctx.resume().catch(() => {}); };
    const url = URL.createObjectURL(new Blob([WORKLET], { type: 'application/javascript' }));
    const pend = M.pend = M.pend || [];
    ctx.audioWorklet.addModule(url).then(() => {
      URL.revokeObjectURL(url);
      if (M.ctx !== ctx) return;
      const node = M.node = new AudioWorkletNode(ctx, 'mpcm', { outputChannelCount: [2] });
      node.port.onmessage = e => { M.level = e.data.q; M.played = e.data.played; M.playing = e.data.on; M.ratio = e.data.ratio; M.under = e.data.under; M.levelAt = performance.now(); };
      const gain = M.gain = ctx.createGain(); gain.gain.value = muted() ? 0 : $('#mVol').value / 100;
      const an = M.an = ctx.createAnalyser(); an.fftSize = 2048; an.smoothingTimeConstant = 0.55; an.minDecibels = -85; an.maxDecibels = -20;
      node.connect(gain); gain.connect(an); an.connect(ctx.destination);
      applyBuf();
      for (const m of pend) node.port.postMessage(m, m.r === m.l ? [m.l.buffer] : [m.l.buffer, m.r.buffer]);
      M.pend = null; ctx.resume().catch(() => {});
    }).catch(e => { console.warn('music worklet', e); M.audioFail = Date.now(); });
  }
  function teardownAudio() { if (M && M.ctx) { try { M.ctx.close(); } catch {} } if (M) { M.ctx = M.node = M.gain = M.an = null; M.level = 0; M.playing = false; } }
  function post(m) {
    if (M.node) M.node.port.postMessage(m, m.r === m.l ? [m.l.buffer] : [m.l.buffer, m.r.buffer]);
    else if (M.pend && M.pend.length < 4000) M.pend.push(m);
  }
  function feed(f, pts, pl) {
    if (!M.cfg) return;
    const a = MT.parseAudio(f, pts, pl, M.cfg.ch, M.cfg.fmt);
    const r = M.rx.accept(a.idx, a.frames);
    if (!r) return;
    if (a.silent) {
      for (let left = r.frames; left > 0;) { const n = Math.min(left, M.cfg.rate), z = new Float32Array(n); post({ l: z, r: z }); left -= n; }
    } else {
      post((M.cfg.fmt === 's24' ? MT.s24ToPlanar : MT.s16ToPlanar)(a.pcm, M.cfg.ch, r.off, r.frames));
    }
  }
  // 音频上下文看门狗：被系统挂起就恢复；上下文被关闭或 worklet 失联就重建（接着播，不丢后续帧）
  const GIVE_UP_MS = 10 * 60 * 1000;                              // 手机断线超过 10 分钟还没回来：结束会话（否则防挂起 / 全局媒体键 / 定时器会一直占着）
  function audioWatchdog() {
    if (M && !M.s && M.dropAt && Date.now() - M.dropAt > GIVE_UP_MS) { end('手机超过 10 分钟没有重连', false); return; }
    if (!M || !M.cfg) return;
    const c = M.ctx;
    if (!c || c.state === 'closed' || (M.audioFail && Date.now() - M.audioFail > 2000)) {
      const cfg = M.cfg; M.audioFail = 0; M.cfg = null; if (c) teardownAudio(); setupAudio(cfg); return;
    }
    if (c.state === 'suspended' || c.state === 'interrupted') c.resume().catch(() => {});
    if (M.node && M.levelAt && c.state === 'running' && performance.now() - M.levelAt > 4000) {   // worklet 4 秒没吭声
      const cfg = M.cfg; M.cfg = null; teardownAudio(); setupAudio(cfg);
    }
  }

  /* ───────── 会话 ───────── */
  function cmd(c, extra) {
    if (!M || !M.s || !M.s.alive || !M.meta || !M.meta.ctl) return;
    M.s.sendJson(MT.T.CMD, Object.assign({ cmd: c }, extra || {}));
    if (c === 'next' || c === 'prev' || c === 'seek') { if (M.node && M.cfg) M.node.port.postMessage({ flush: 0 }); }   // 切歌 / 拖动：旧音频马上丢掉，不要再播一两秒旧的
    if (c === 'seek' && extra) { M.meta = Object.assign({}, M.meta, { pos: extra.pos }); M.metaAt = performance.now(); }       // 先按目标位置显示，不等手机下一次回报，进度条不回弹
    if (c === 'toggle' || c === 'play' || c === 'pause') { M.meta = Object.assign({}, M.meta, { state: c === 'pause' || (c === 'toggle' && M.meta.state === 'playing') ? 'paused' : 'playing' }); M.metaAt = performance.now(); updateMeta(); }
    tick();
  }

  function sendAck(fresh) {
    if (!M || !M.s || !M.s.alive) return;
    const j = { cmd: 'mack', next: M.rx.started ? M.rx.next : 0 };
    if (fresh) j.fresh = true;
    M.s.sendJson(T_CTRL, j);
  }

  function onPacket(s, t, f, pts, pl) {
    if (!M || M.s !== s) return;
    try {
      if (t === MT.T.ADATA) { feed(f, pts, pl); }
      else if (t === MT.T.META) {
        M.meta = MT.cleanMeta(JSON.parse(pl.toString('utf8'))); M.metaAt = performance.now();
        updateMeta();
      } else if (t === MT.T.LYRIC) {
        onPhoneLine(JSON.parse(pl.toString('utf8')));
      } else if (t === MT.T.COVER) {
        const c = MT.parseCover(pl);
        if (c.hash !== M.coverHash) setCover(c.hash, c.img);
      } else if (t === MT.T.ACONFIG) {
        setupAudio(MT.parseConfig(JSON.parse(pl.toString('utf8'))));
      } else if (t === T_CTRL) {
        const j = JSON.parse(pl.toString('utf8'));
        if (j && j.cmd === 'mstop') end('手机端已结束沉浸音乐', false);
      }
    } catch (e) { console.warn('music packet', t, e.message); }
  }

  function attach(s) {
    s.mode = 'music'; s._lim = 8000;                              // 手机每秒都有心跳 / 进度，8 秒没动静就判定断线，等它重连
    s.onPacket = (t, f, pts, pl) => onPacket(s, t, f, pts, pl);
    s.onClose = reason => {
      if (!M || M.s !== s) return;
      M.s = null; M.dropAt = Date.now();
      M.lastReason = reason;
      tick();
    };
  }

  function onIncoming(s, hello) {
    ensureDom();
    const sid = String((hello && hello.sid) || '').slice(0, 64) || s.peerId || 'default';
    let resumed = false;
    if (M && M.sid === sid) {                                     // 同一次沉浸音乐：手机重连，接管新连接，播放器和缓冲都保留
      const old = M.s; M.s = s; resumed = true; M.dropAt = 0; M.reconnects++;
      if (old) { old.onClose = null; try { old.close('被新连接取代'); } catch {} }
    } else {
      if (M) end('手机开始了新的沉浸音乐', false);
      M = { sid, peerId: s.peerId, peerName: s.peerName, s, rx: new MT.AudioRx(), cfg: null, ctx: null, node: null, gain: null, an: null, pend: null,
            meta: null, metaAt: 0, coverHash: '', coverUrl: '', level: 0, levelAt: 0, played: 0, playing: false, ratio: 1, under: 0, reconnects: 0, dropAt: 0, lastReason: '', since: Date.now(), audioFail: 0 };
      lastKey = ''; setAccentNow([255, 255, 255]); vizHot = true; vizDirty = true; clearLyrics();
      ipcRenderer.send('keep-awake-music', true);                  // 播放期间阻止系统挂起应用（屏幕可以熄灭），并接管键盘媒体键
      tickT = setInterval(() => { tick(); audioWatchdog(); }, 250); ackT = setInterval(() => sendAck(false), 500);
      $('#mTitle').textContent = '等待手机开始播放…'; $('#mSub').textContent = ''; $('#mApp').textContent = '';
      resetLayers();
      show(true);
      try { ipcRenderer.send('focus'); } catch {}
    }
    M.peerName = s.peerName;
    attach(s);
    sendAck(!resumed);                                            // 告诉手机从哪一帧继续（全新会话 = 从实时开始）
    tick();
  }

  function end(reason, tellPhone) {
    if (!M) return;
    const m = M; M = null;
    clearInterval(tickT); clearInterval(ackT); cancelAnimationFrame(raf); raf = 0; drag = null;
    if (m.s) { try { if (tellPhone) m.s.sendJson(T_CTRL, { cmd: 'mstop' }); } catch {} const s = m.s; s.onClose = null; setTimeout(() => { try { s.close(reason); } catch {} }, tellPhone ? 300 : 0); }
    if (m.ctx) { try { m.ctx.close(); } catch {} }
    for (const u of [m.coverUrl, ...(m.oldUrls || [])]) if (u) { try { URL.revokeObjectURL(u); } catch {} }
    ipcRenderer.send('keep-awake-music', false);
    try { if (document.fullscreenElement) document.exitFullscreen(); } catch {}
    clearTimeout(showT); clearTimeout(inT); lastF = 0; accTgt = null;
    if (ov) { ov.hidden = true; ov.classList.remove('in', 'out', 'paused'); } if (mini) mini.hidden = true; document.documentElement.classList.remove('noScroll');
    if (typeof setStatus === 'function') setStatus('沉浸音乐已结束：' + reason);
  }

  /* ───────── 界面 ───────── */
  function setCover(hash, img) {
    const mime = MT.imageMime(img);
    if (!mime) return;
    if (M.coverUrl) (M.oldUrls = M.oldUrls || []).push(M.coverUrl);   // 旧封面还在屏幕上，等新封面解码完再释放，否则会闪黑
    const blob = new Blob([Buffer.from(img)], { type: mime });
    M.coverHash = hash; M.coverUrl = URL.createObjectURL(blob);
    pickAccent(blob, hash);
    updateMeta();
  }
  /* 主色切换：约 0.35 秒的指数缓动，换歌时进度条 / 频谱 / 光晕的颜色柔和过渡（收起或隐藏时直接切换） */
  function setAccentNow(a) { accF = a.slice(); accTgt = null; accent = a.map(Math.round).join(','); if (ov) { ov.style.setProperty('--ac', accent); ov.style.setProperty('--gc', accent); } }
  function setAccent(a) { if (shown && ov && !ov.hidden && M) { accTgt = a.map(Math.round); ov.style.setProperty('--gc', accTgt.join(',')); startViz(); } else setAccentNow(a); }   // 光晕是整屏渐变，逐帧改色会整屏重绘：它一次到位，进度条 / 频谱 / 按钮才做渐变
  function stepAccent(dt) {
    if (!accTgt) return;
    const k = 1 - Math.exp(-dt / 0.35); let done = true;
    for (let i = 0; i < 3; i++) { accF[i] += (accTgt[i] - accF[i]) * k; if (Math.abs(accTgt[i] - accF[i]) > 0.6) done = false; }
    const v = done ? accTgt.slice() : accF.map(Math.round); if (done) { accF = accTgt.slice(); accTgt = null; }
    const str = v.join(','); if (str !== accent) { accent = str; ov.style.setProperty('--ac', str); }
  }
  // 从封面取主色：着色进度条 / 频谱 / 背景光晕
  function pickAccent(blob, hash) {
    if (typeof createImageBitmap !== 'function') return;
    createImageBitmap(blob).then(bm => {
      if (!M || M.coverHash !== hash) { try { bm.close(); } catch {} return; }   // 已经换成别的封面了
      const c = document.createElement('canvas'); c.width = c.height = 16;
      const g = c.getContext('2d', { willReadFrequently: true }); g.drawImage(bm, 0, 0, 16, 16);
      const d = g.getImageData(0, 0, 16, 16).data; let r = 0, gg = 0, b = 0, w = 0;
      for (let i = 0; i < d.length; i += 4) {
        const mx = Math.max(d[i], d[i + 1], d[i + 2]), mn = Math.min(d[i], d[i + 1], d[i + 2]), sat = mx ? (mx - mn) / mx : 0, wt = sat * sat * (mx / 255) + 0.01;
        r += d[i] * wt; gg += d[i + 1] * wt; b += d[i + 2] * wt; w += wt;
      }
      let R = r / w, G = gg / w, B = b / w; const mx = Math.max(R, G, B) || 1, k = 215 / mx;     // 提亮到深色背景上看得清
      R = Math.min(255, R * k); G = Math.min(255, G * k); B = Math.min(255, B * k);
      setAccent([R, G, B]);
      try { bm.close(); } catch {}
    }).catch(() => {});
  }
  /* 封面 / 背景交叉淡入：两层轮流上场，新图在旧图上面渐显，旧图等新图淡完再撤，中间不会露出底色 */
  function resetLayers() {
    if (!ov) return;
    if (M) { clearTimeout(M.fadeT); }
    for (const e of ov.querySelectorAll('.mbg, .mcover img')) e.classList.remove('on');
    $('#mPh').hidden = false;
  }
  /* 背景不再用 CSS filter:blur(72px)（整屏每帧实时模糊，淡入 / 漂移时极吃 GPU）：
   * 封面只在换歌时用 canvas 一次性「缩小 + 模糊 + 调色」成 192px 的小图，之后全程只是合成器缩放贴图，几乎零开销，渐变也更细腻。 */
  function bakeBg(im) {
    try {
      const w = im.naturalWidth, h = im.naturalHeight, m = Math.min(w, h); if (!m) return null;
      const s = document.createElement('canvas'); s.width = s.height = 48;
      const sg = s.getContext('2d'); sg.imageSmoothingQuality = 'high'; sg.drawImage(im, (w - m) / 2, (h - m) / 2, m, m, 0, 0, 48, 48);
      const c = document.createElement('canvas'); c.width = c.height = 192;
      const g = c.getContext('2d'); g.filter = 'blur(9px) saturate(1.45) brightness(.5)'; g.imageSmoothingQuality = 'high';
      g.drawImage(s, -24, -24, 240, 240);                         // 多画出边缘，模糊后四周不会漏出透明
      return c.toDataURL('image/jpeg', 0.9);
    } catch { return null; }
  }
  function swapLayer(url, bg) {
    const bgs = ov.querySelectorAll('.mbg'), imgs = ov.querySelectorAll('.mcover img');
    const cur = M.layer | 0, nxt = cur ^ 1, nb = bgs[nxt], ni = imgs[nxt], ob = bgs[cur], oi = imgs[cur];
    clearTimeout(M.fadeT);
    for (const e of [nb, ni]) { e.style.transition = 'none'; e.classList.remove('on'); }   // 上一轮还没淡完的旧层：直接收掉
    void nb.offsetWidth;
    for (const e of [nb, ni]) e.style.transition = '';
    nb.classList.toggle('raw', !bg);                              // 烘焙失败时退回 CSS 模糊，保证能看
    nb.style.backgroundImage = 'url("' + (bg || url) + '")'; ni.src = url;
    nb.style.zIndex = ni.style.zIndex = 2; ob.style.zIndex = oi.style.zIndex = 1;
    nb.classList.add('on'); ni.classList.add('on'); $('#mPh').hidden = true;
    M.layer = nxt;
    const cvr = $('#mCover'); cvr.classList.remove('swap'); void cvr.offsetWidth; cvr.classList.add('swap');   // 新封面落座的轻微回弹
    M.fadeT = setTimeout(() => { ob.classList.remove('on'); oi.classList.remove('on'); }, 1450);
  }
  function flushOld() {
    if (!M || !M.oldUrls) return;
    M.oldUrls = M.oldUrls.filter(u => { if (u === M.coverUrl || u === M.paintUrl) return true; try { URL.revokeObjectURL(u); } catch {} return false; });
  }
  function paintCover(url) {
    if (M.painting === url) return;
    M.painting = url;
    const im = new Image(); im.src = url;
    const go = () => {
      if (!M || M.painting !== url) return;
      M.painting = ''; if (M.coverUrl !== url) return;
      M.paintUrl = url;
      swapLayer(url, bakeBg(im));
      const mi = $('#miImg'); mi.src = url; mi.hidden = false;
      flushOld();
    };
    if (im.decode) im.decode().then(go, go); else im.onload = im.onerror = go;
  }
  function clearPaint() {
    if (M) M.painting = '';
    resetLayers(); $('#miImg').hidden = true;
    if (M) { M.paintUrl = ''; flushOld(); }
  }
  function updateMeta() {
    const m = M.meta; if (!m) return;
    const title = m.title || (m.state === 'none' ? '手机上还没有在播放的音乐' : '未知歌曲'), sub = [m.artist, m.album].filter(Boolean).join(' · ');
    const key = title + '\n' + sub;
    if (key !== lastKey) {                                          // 换歌：文字淡入上浮
      if (lastKey) { const t = $('#mTxt'); t.classList.remove('swap'); void t.offsetWidth; t.classList.add('swap'); }
      lastKey = key;
    }
    $('#mTitle').textContent = title; $('#mSub').textContent = sub;
    $('#mApp').textContent = (m.app ? '来自「' + m.app + '」' : '') + (M.lyr ? (m.app ? ' · ' : '') + '歌词：' + M.lyr.source + (M.lyr.synced ? '（已与手机同步）' : '') : '');
    if (!m.cover && M.coverUrl && M.coverFor !== key) {              // 换了一首没有封面的歌：丢掉上一首的封面和主色，别张冠李戴（同一首歌里封面短暂缺失则保留，不闪烁）
      (M.oldUrls = M.oldUrls || []).push(M.coverUrl); M.coverUrl = ''; M.coverHash = '';
      setAccent([255, 255, 255]);
    }
    const hasCover = !!(M.coverUrl && (m.cover ? m.cover === M.coverHash : M.coverFor === key));
    if (hasCover) M.coverFor = key;
    // 封面只在新图解码完成后才替换；新封面还没到（m.cover 已变、图还没收到）时继续显示旧的，避免闪黑
    const showCover = !!M.coverUrl && (m.cover ? true : M.coverFor === key);
    if (showCover) { if (M.paintUrl !== M.coverUrl) paintCover(M.coverUrl); }
    else if (M.paintUrl || !M.coverUrl) clearPaint();
    const can = m.ctl, seek = can && m.can.includes('seek');
    for (const id of ['#mPrev', '#mNext', '#mPlay']) $(id).disabled = !can;
    for (const id of ['#mBack', '#mFwd']) $(id).disabled = !seek || !(m.duration > 0);
    const playing = m.state === 'playing';
    ov.classList.toggle('paused', !playing); mini.classList.toggle('pl', playing);
    setIcon($('#mPlay'), playing ? 'pause' : 'play');
    $('#miTxt').textContent = (m.title || '沉浸音乐') + (m.artist ? ' — ' + m.artist : '');
    setIcon($('#miPlay'), playing ? 'pause' : 'play');
    for (const b of mini.querySelectorAll('button')) b.disabled = !can;
    loadLyrics(m);
  }
  /* ---- 歌词：电脑按歌名 / 歌手 / 时长在线查找（lyrics.js），按播放进度逐行高亮并居中滚动 ---- */
  let lyrFlag = null;                                            // 本次运行内的开关（localStorage 不可用时也能切换）
  const lyrOn = () => lyrFlag !== null ? lyrFlag : LSget('music:lyr', '1') !== '0';
  let lyrOffV = null;                                            // 歌词整体提前 / 推后（毫秒，正 = 歌词更晚出现）：不同来源的版本时间轴可能差零点几秒，用 [ ] 键微调
  const lyrOff = () => lyrOffV !== null ? lyrOffV : (lyrOffV = Math.max(-10000, Math.min(10000, Number(LSget('music:lyrOff', '0')) || 0)));
  function lyrNudge(d) {
    lyrOffV = d === 0 ? 0 : Math.max(-10000, Math.min(10000, lyrOff() + d)); LSset('music:lyrOff', lyrOffV);
    if (M) M.lyrCur = -2; syncLyrBtn();
  }
  function syncLyrBtn() { const b = $('#mLyrBtn'); if (b) b.textContent = lyrOff() ? '歌词 ' + (lyrOff() > 0 ? '+' : '') + (lyrOff() / 1000).toFixed(1) + 's' : '歌词'; }
  const lyrToggle = () => { lyrFlag = !lyrOn(); LSset('music:lyr', lyrFlag ? 1 : 0); applyLyrVis(); };
  function applyLyrVis() {
    const box = $('#mLyr'), has = !!(M && M.lyr && M.lyr.lines.length);
    box.hidden = !(has && lyrOn()); $('#mLyrBtn').classList.toggle('on', lyrOn());
    if (M) M.lyrCur = -2;
  }
  function clearLyrics() {
    clearTimeout(M && M.lyrT);
    if (M) { M.lyr = null; M.lyrKey = ''; M.lyrFail = 0; M.lyrCur = -2; M.lyrLast = -9; }
    const box = $('#mLyrI'); if (box) box.textContent = '';
    applyLyrVis();
  }
  function renderLyr(lines) {
    const box = $('#mLyrI'); box.textContent = '';
    for (const l of lines) {
      const d = document.createElement('div'); d.className = 'ml'; d.dataset.t = String(l.t);   // textContent：网络 / 手机来的文字一律当纯文本
      d.appendChild(document.createTextNode(l.text || '♪'));
      if (l.tr) { const sm = document.createElement('small'); sm.textContent = l.tr; d.appendChild(sm); }
      box.appendChild(d);
    }
    if (M) { M.lyrCur = -2; M.lyrLast = -9; }
    applyLyrVis();
  }
  /* 手机把音乐 App 此刻显示的一句歌词（「状态栏歌词」通知）连同播放位置发来：
   *  · 已有在线歌词 → 找到对应行，算出「这一句实际比在线歌词晚 / 早多少」，取最近几次的中位数自动校准（App 播的版本和在线版本时间轴常差零点几到几秒）；
   *  · 没有在线歌词 → 手机发来多少就显示多少，边听边攒。 */
  function onPhoneLine(j) {
    if (!M) return;
    const d = MT.cleanLyric(j); if (!d.line) return;
    const m = M.meta; if (m && m.title && d.title && d.title !== m.title) return;    // 换歌瞬间上一首的尾巴
    const L = M.lyr;
    if (L && !L.live) {
      const l = LY.matchLine(L.lines, d.line, d.pos);
      if (l) { const a = (L.offs = L.offs || []); a.push(d.pos - l.t); if (a.length > 7) a.shift(); L.auto = LY.median(a); L.synced = true; M.lyrCur = -2; }
    } else {
      const ll = L || (M.lyr = { lines: [], source: '手机歌词', live: true });
      if (LY.addLive(ll.lines, d.pos, d.line)) renderLyr(ll.lines);
    }
  }
  function loadLyrics(m) {
    const title = m.state === 'none' ? '' : m.title, key = title ? title + '\n' + m.artist : '';
    if (key === M.lyrKey && !(M.lyrFail && Date.now() - M.lyrFail > 20000)) return;       // 同一首歌不重复查；上次因断网失败的，20 秒后再试
    if (key !== M.lyrKey) { clearTimeout(M.lyrT); M.lyr = null; $('#mLyrI').textContent = ''; applyLyrVis(); }
    M.lyrKey = key; M.lyrFail = 0;
    if (!key) return;
    const mm = M, meta = { title: m.title, artist: m.artist, duration: m.duration, app: m.app, pkg: m.pkg };
    clearTimeout(mm.lyrT);
    mm.lyrT = setTimeout(async () => {                           // 防抖：连续切歌时只查最后一首
      try {
        const r = await LY.fetchLyrics(meta);
        if (M !== mm || mm.lyrKey !== key) return;               // 等结果的时候已经换歌 / 结束了
        if (!r) return;                                          // 没找到：保持现状（手机若发来了歌词行，已经在边听边攒）
        mm.lyr = r;                                              // 在线歌词比「攒出来的」完整，直接替换；之后再用手机的歌词行校准时间
        renderLyr(r.lines);
      } catch { if (M === mm && mm.lyrKey === key) mm.lyrFail = Date.now(); }
    }, 500);
  }
  /* 歌词滚动（类 Apple Music）：整体位移 --sy 作用在每一行上，越靠后的行延迟越久（逐行「流」下来）；
   * 非当前行缩小到 94% 而不是放大当前行，当前行始终 1:1 渲染，文字保持锐利；
   * 只有 transform / opacity / 少量 blur 在动，全部由合成器完成；离屏的行直接 visibility:hidden，不参与动画。 */
  const LY_OP = [1, .55, .38, .27, .2, .15, .11, .08, .06], LY_BL = [0, .5, 1.2, 2, 2.8, 3.4, 4, 4, 4];
  function updateLyrics(pos) {
    const L = M.lyr; if (!L || !L.lines.length || !lyrOn()) return;
    const h = szLyr || (szLyr = E.lyr.clientHeight); if (!h) return;
    const idx = LY.lineAt(L.lines, pos + 150 - lyrOff() - (L.auto || 0));                  // 略微提前，视觉上更跟手
    const seek = !!(M.meta && M.meta.ctl && M.meta.duration > 0 && M.meta.can.includes('seek'));
    if (idx === M.lyrCur && M.lyrRev === lyrRev && seek === M.lyrSeek) return;
    const seekChg = seek !== M.lyrSeek, last = M.lyrLast === undefined ? -9 : M.lyrLast;
    M.lyrRev = lyrRev; M.lyrSeek = seek; M.lyrCur = idx;
    const box = E.lyri, kids = box.children, c = Math.max(0, idx), el = kids[c]; if (!el) return;
    const big = last < -2 || Math.abs(idx - last) > 6; M.lyrLast = idx;                    // 大跨度（拖进度 / 刚载入歌词）：直接就位 + 淡入，不做长距离滑动
    if (big) box.classList.add('jump');
    box.style.setProperty('--sy', Math.round(h / 2 - (el.offsetTop + el.offsetHeight / 2)) + 'px');
    for (let i = 0; i < kids.length; i++) {
      const k = kids[i], dd = i - c, ad0 = Math.abs(dd), far = ad0 > 8, cur = idx >= 0 && i === idx;
      if (seekChg) k.classList.toggle('sk', seek);
      const key = far ? 99 : cur ? 0 : (dd < 0 ? -1 : 1) * Math.max(1, ad0);
      if (k._k === key) continue;
      k._k = key; k.classList.toggle('far', far);
      if (far) continue;
      const ad = cur ? 0 : Math.max(1, ad0), b = LY_BL[ad];
      k.classList.toggle('cur', cur); k.classList.toggle('bl', b > 0);
      k.style.setProperty('--o', String((LY_OP[ad] * (dd < 0 ? .75 : 1)).toFixed(3)));
      k.style.setProperty('--sc', cur ? '1' : ad <= 2 ? '.94' : '.9');
      k.style.setProperty('--dl', (dd > 0 ? Math.min(dd, 6) * 42 : 0) + 'ms');
      if (b > 0) k.style.setProperty('--b', b + 'px');
    }
    if (big) { void box.offsetWidth; box.classList.remove('jump'); try { box.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 420, easing: 'ease-out' }); } catch {} }
  }
  function bufferedMs() { return M && M.cfg ? (M.level / M.cfg.rate) * 1000 : 0; }
  function curPos() {
    const m = M && M.meta; if (!m) return 0;
    return MT.estimatePos(m, M.metaAt ? M.metaAt : performance.now(), performance.now(), bufferedMs());
  }
  // 进度条 / 时间：每帧刷新，丝滑；文字只在秒数变化时改
  let lastSec = -1, lastDur = -1;
  function drawProgress() {
    const m = M.meta; if (!m) return;
    const hasDur = m.duration > 0;
    let f = 0, pos = curPos();
    if (drag && hasDur) { f = drag.f; pos = f * m.duration; }
    else f = hasDur ? Math.min(1, pos / m.duration) : 0;
    updateLyrics(pos);
    const fs = 'scaleX(' + f.toFixed(5) + ')'; if (fs !== lastFill) { lastFill = fs; E.fill.style.transform = fs; }
    const bw = szBar || (szBar = E.bar.clientWidth);                // 宽度来自 ResizeObserver 缓存，逐帧不触发重排
    const ts = 'translate3d(' + (f * bw).toFixed(2) + 'px,0,0)'; if (ts !== lastThumb) { lastThumb = ts; E.thumb.style.transform = ts; }
    const sec = Math.floor(pos / 1000);
    if (sec !== lastSec) { lastSec = sec; E.cur.textContent = MT.fmtTime(pos); }
    const ds = hasDur ? Math.floor(m.duration / 1000) : -1;
    if (ds !== lastDur) { lastDur = ds; E.dur.textContent = hasDur ? MT.fmtTime(m.duration) : '--:--'; }
    if (hasDur && (barHover || drag)) { E.tip.style.left = (hoverF * bw) + 'px'; E.tip.textContent = MT.fmtTime(hoverF * m.duration); }
  }
  function tick() {
    if (!M || !ov) return;
    if (mini.hidden !== shown) mini.hidden = shown;
    if (!shown && !mini._placed) { mini._placed = 1; miRestore(); }
    const vw = $('#viewer'), dsp = (vw && !vw.hidden) ? 'none' : ''; if (ov.style.display !== dsp) ov.style.display = dsp;            // 屏幕投屏窗口打开时让位
    const m = M.meta, buf = bufferedMs();
    if (!shown || ov.hidden) { /* 收起时不画动画；进度文字也无需刷新 */ }
    else drawProgress();
    // 沉浸模式：一切正常时界面上不显示任何技术信息（连接 / 格式 / 缓冲 / 快捷键），只有出了问题才在底部浮出一条简短提示
    const st = $('#mStat'), c = M.cfg, notes = []; let cls = 'mstat';
    if (!M.s) { cls += ' warn'; notes.push('与手机的连接中断，正在自动重连' + (buf >= 500 ? '；已缓冲的 ' + (buf / 1000).toFixed(1) + ' 秒音乐会继续播放' : '')); }
    if (M.rx.gapFrames > 0) { cls += ' bad'; notes.push('有 ' + (M.rx.gapFrames / (c ? c.rate : 48000)).toFixed(1) + ' 秒音频因断线过久而丢失'); }
    if (m && !m.ctl) notes.push('手机还没授予「通知使用权」：能听歌，但看不到歌名封面，也不能从电脑控制（在手机端「沉浸音乐」里开启）');
    const txt = notes.join('\n');
    if (txt !== M.lastTxt) { M.lastTxt = txt; st.className = cls; st.textContent = txt; st.hidden = !txt; }
    startViz();
  }
  function startViz() { if (M && shown && ov && !ov.hidden && !raf) raf = requestAnimationFrame(viz); }

  /* 频谱 + 节拍联动（封面随低频脉动、背景光晕呼吸、暂停时封面缩小）
   * 所有平滑都按真实帧间隔 dt 计算（指数缓动 / 临界阻尼弹簧），60 Hz 与 144 Hz 屏手感一致，帧时间抖动也不会让动画忽快忽慢；
   * 频谱所有竖条合并成一次 fill；暂停且一切都静止后自动停掉逐帧循环（tick 每 250 ms 会唤醒检查），不白耗 GPU / 电。 */
  function viz(now) {
    raf = 0;
    if (!M || ov.hidden || ov.style.display === 'none' || !shown) { lastF = 0; return; }
    const dt = lastF ? Math.min(0.05, Math.max(0.001, (now - lastF) / 1000)) : 1 / 60; lastF = now;
    const cv = E.viz;
    if (!vizW) {
      dpr = Math.min(2, window.devicePixelRatio || 1); vizW = cv.clientWidth || 520; vizH = cv.clientHeight || 64;
      cv.width = Math.round(vizW * dpr); cv.height = Math.round(vizH * dpr); vizGK = ''; vizDirty = true;
    }
    stepAccent(dt);
    const playing = M.meta ? M.meta.state === 'playing' : false;
    let b = 0;
    if (playing || vizHot || vizDirty) {
      const g = vizCtx || (vizCtx = cv.getContext('2d')), W = vizW, H = vizH;
      g.setTransform(dpr, 0, 0, dpr, 0, 0); g.clearRect(0, 0, W, H);
      if (M.an && M.cfg) {
        const an = M.an, rate = M.cfg.rate;
        an.getByteFrequencyData(bars);
        if (bandKey !== rate + ':' + an.fftSize) {                  // 频段边界只在采样率变化时算一次
          bandKey = rate + ':' + an.fftSize;
          const binHz = rate / an.fftSize, lo = 40, hi = Math.min(16000, rate / 2 - 100);
          for (let i = 0; i < BN; i++) {
            const f0 = lo * Math.pow(hi / lo, i / BN), f1 = lo * Math.pow(hi / lo, (i + 1) / BN);
            bk0[i] = Math.floor(f0 / binHz); bk1[i] = Math.max(bk0[i] + 1, Math.ceil(f1 / binHz));
          }
        }
        for (let i = 0; i < BN; i++) { let mx = 0; for (let k = bk0[i], e = Math.min(bk1[i], bars.length); k < e; k++) if (bars[k] > mx) mx = bars[k]; rv[i] = Math.pow(mx / 255, 1.15); }
        const aA = 1 - Math.exp(-dt / 0.04), aR = 1 - Math.exp(-dt / 0.2), fall = dt * 0.4;
        let top = 0;
        for (let i = 0; i < BN; i++) {
          const v = rv[Math.max(0, i - 1)] * 0.2 + rv[i] * 0.6 + rv[Math.min(BN - 1, i + 1)] * 0.2;   // 相邻频段轻微平滑，形状更连贯
          hv[i] += (v - hv[i]) * (v > hv[i] ? aA : aR);             // 起音快、回落柔和
          pk[i] = Math.max(hv[i], pk[i] - fall);                    // 峰值帽缓慢回落
          if (pk[i] > top) top = pk[i];
        }
        vizHot = top > 0.006;
        const w = W / BN, bw = Math.max(1.5, w * 0.42), rr = !!g.roundRect, gk = accent + '|' + H;
        if (gk !== vizGK) { vizGK = gk; vizG = g.createLinearGradient(0, H, 0, 0); vizG.addColorStop(0, 'rgba(' + accent + ',.35)'); vizG.addColorStop(1, 'rgba(' + accent + ',.95)'); }
        g.fillStyle = vizG; g.beginPath();
        for (let i = 0; i < BN; i++) { const h = Math.max(bw, hv[i] * (H - 4)), x = i * w + (w - bw) / 2; if (rr) g.roundRect(x, H - h, bw, h, bw / 2); else g.rect(x, H - h, bw, h); }
        g.fill();
        g.fillStyle = 'rgba(255,255,255,.5)'; g.beginPath(); let caps = 0;      // 峰值小圆点
        for (let i = 0; i < BN; i++) if (pk[i] - hv[i] > 0.03) { const y = H - pk[i] * (H - 4) - bw - 3, x = i * w + (w - bw) / 2; caps++; if (rr) g.roundRect(x, y, bw, bw, bw / 2); else g.rect(x, y, bw, bw); }
        if (caps) g.fill();
        let sum = 0; for (let k = 1; k <= 6; k++) sum += bars[k];     // ≈ 23–140 Hz
        b = Math.pow(sum / 6 / 255, 2.2);
      } else vizHot = false;
      vizDirty = false;
    }
    bass += (b - bass) * (1 - Math.exp(-dt / (b > bass ? 0.05 : 0.25)));         // 低频包络：起音 50 ms、释放 250 ms
    const target = playing ? 1 + 0.04 * bass : 0.9, w0 = playing ? 16 : 7.5;      // 暂停：封面微微缩小；播放：随低频脉动（临界阻尼弹簧，不抖、不过冲）
    scaleV += (-w0 * w0 * (scaleCur - target) - 2 * w0 * scaleV) * dt; scaleCur += scaleV * dt;
    pulse += ((playing ? 0.35 + bass * 0.6 : 0.2) - pulse) * (1 - Math.exp(-dt / 0.25));
    const sCw = 'scale(' + scaleCur.toFixed(4) + ')'; if (sCw !== lastCw) { lastCw = sCw; E.cw.style.transform = sCw; }
    const sCg = (0.22 + bass * 0.5).toFixed(3); if (sCg !== lastCg) { lastCg = sCg; E.cg.style.opacity = sCg; }
    const sGl = pulse.toFixed(3); if (sGl !== lastGl) { lastGl = sGl; E.gl.style.opacity = sGl; }
    drawProgress();
    const quiet = !playing && !vizHot && !vizDirty && !accTgt && !drag && !barHover && Math.abs(scaleCur - target) < 0.0004 && Math.abs(scaleV) < 0.004 && bass < 0.003 && Math.abs(pulse - 0.2) < 0.003;
    if (quiet) { lastF = 0; return; }
    raf = requestAnimationFrame(viz);
  }

  window.MU = { onIncoming, end, active: () => !!M, _state: () => M };
})();
