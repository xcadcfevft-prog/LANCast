// 工具链版本统一放在 gradle/libs.versions.toml（云析模块要求 AGP 8.13 / Kotlin 2.1.0 / KSP）
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.android.library) apply false
    alias(libs.plugins.kotlin.android) apply false
    alias(libs.plugins.kotlin.compose) apply false
    alias(libs.plugins.ksp) apply false
}
