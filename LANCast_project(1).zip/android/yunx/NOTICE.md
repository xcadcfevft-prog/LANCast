# 云析（YunX）模块说明

- 来源：https://github.com/CYQawa/YunX ，版本 v1.3.1（commit 648a16d），作者 CYQawa
- 许可证：GNU AGPL-3.0（见同目录 `LICENSE`）。包含本模块的整个应用分发时须遵守 AGPL-3.0（含向用户提供对应源码）。

## 相对原项目的改动

作为库模块嵌入瞬流，仅保留解析 / 下载 / 登录 / 预览等功能，移除以下非功能代码：

- 应用内公告（`data/announcement`、公告页 / 弹窗 / 红点角标，及其对作者服务器的请求）
- 应用自更新检查与更新弹窗（`UpdateChecker` 仅保留作通用 GitHub Release 抓取器，供 Gopeed 内核下载与镜像加速使用）
- 「支持开发」捐赠页及收款二维码、QQ 交流群入口、引导页的仓库 / 群推广卡片、启动安全提示弹窗
- 防篡改自检（`ArchiveProbe` / `TextCipher` / `LaunchGate` / `YunXApp` 中的探测与强杀逻辑）——嵌入宿主后这些检查必然误判
- 自带崩溃界面与全局未捕获异常处理器（不再接管宿主进程）
- 桌面图标切换（会禁用 `MainActivity`）、独立启动器入口、应用级 `Application` 与网络安全配置

初始化改为 `YunXBootstrap.ensureInit()`，由 `MainActivity` / `DownloadService` 首次启动时调用。
