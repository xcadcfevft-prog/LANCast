/*
 * YunX (云析) - A network drive share-link parser and high-speed downloader for Android.
 * Copyright (C) 2026 CYQawa
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.yunx.app.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.ColumnInfo

/**
 * 下载任务（Room 持久化，断点续传依赖 part 文件 + 已下载大小）。
 */
@Entity(tableName = "download_task")
data class DownloadTaskEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val url: String,
    val fileName: String,
    val totalSize: Long = 0L,
    val downloadedSize: Long = 0L,
    val status: Int = STATUS_PENDING,
    /** 失败原因（服务端/网络/分片等具体错误信息），成功或进行中为空 */
    val errorMsg: String = "",
    /** 完成后的保存位置：MediaStore uri 或文件绝对路径 */
    val savePath: String = "",
    /** 恢复任务所需的请求头 JSON（Cookie/Referer/UA 等） */
    @ColumnInfo(defaultValue = "'{}'")
    val requestHeadersJson: String = "{}",
    /** 首次探测大小后固定的分片数，恢复时不随设置变化 */
    @ColumnInfo(defaultValue = "0")
    val chunkCount: Int = 0,
    /** 与 chunkCount 对应的服务器总大小 */
    @ColumnInfo(defaultValue = "0")
    val plannedTotalSize: Long = 0L,
    /** 下载完成/删除任务后应清理的云端临时目录 ID（当前为夸克） */
    @ColumnInfo(defaultValue = "''")
    val cleanupId: String = "",
    /** 下载来源平台标识（用于按平台应用下载线程数设置）；通用/手动添加为空串 */
    @ColumnInfo(defaultValue = "''")
    val platform: String = "",
    /**
     * 走 Gopeed 引擎下载时的引擎任务 ID；空串 = 这条任务由内置分片下载器执行。
     * 有值时进度由引擎同步协程回写（见 DownloadManager.startEngineSync），暂停/继续/删除都要转发给引擎。
     */
    @ColumnInfo(defaultValue = "''")
    val engineTaskId: String = "",
    /**
     * 单文件多源分片（实验性「多账号下载提速 C2」）的备选下载源 JSON：多账号对同一文件
     * 各取一条直链，内置分片下载器把分片轮流分给不同源（落库前按 `download.altSources` 加密）。
     * 空串 = 单源，与未开启该功能时完全一致。
     */
    @ColumnInfo(defaultValue = "''")
    val altSourcesJson: String = "",
    /**
     * 需要合轨的**音轨直链**（哔哩哔哩 DASH：高清是音视频分离的两路流）。
     * 非空 = 这条任务要先下视频轨（[url]）与音轨（本字段）再合轨成一个 mp4（见 `DashMuxer`）；
     * 空 = 单文件下载，与其它平台完全一致。
     */
    @ColumnInfo(defaultValue = "''")
    val mergeAudioUrl: String = "",
    /** 音轨的请求头 JSON（落库前按 `download.mergeAudioHeaders` 加密） */
    @ColumnInfo(defaultValue = "''")
    val mergeAudioHeadersJson: String = "",
    /**
     * 动图（Live Photo）的**动图资源直链**（微博 `.mov` / 抖音 mp4）。
     * 非空 = 这条任务要把 [url] 的静图与它合成为一张「动态照片」（Motion Photo 单文件，见
     * `MotionPhotoWriter`），产物仍是 `.jpg`；空 = 普通单文件下载，行为完全一致。
     */
    @ColumnInfo(defaultValue = "''")
    val motionUrl: String = "",
    /**
     * **只要音频**：下完整个视频后把音轨抽出来，产物是 `.m4a`（见 `AudioExtractor`）。
     * 单文件平台没有独立的音频直链，只能先拿到完整视频；任务上的 [fileName] 已经是 `.m4a` 名字。
     * false = 普通下载，行为与以前完全一致。
     */
    @ColumnInfo(defaultValue = "0")
    val audioOnly: Boolean = false,
    /** 下载完成时的平均速度（字节/秒）；完成态展示用，进行中为 0 */
    @ColumnInfo(defaultValue = "0")
    val avgSpeed: Long = 0,
    val createTime: Long = System.currentTimeMillis()
) {
    companion object {
        const val STATUS_PENDING = 0
        const val STATUS_DOWNLOADING = 1
        const val STATUS_PAUSED = 2
        const val STATUS_COMPLETED = 3
        const val STATUS_FAILED = 4

        fun statusText(status: Int): String = when (status) {
            STATUS_PENDING -> "等待中"
            STATUS_DOWNLOADING -> "下载中"
            STATUS_PAUSED -> "已暂停"
            STATUS_COMPLETED -> "已完成"
            STATUS_FAILED -> "失败"
            else -> "未知"
        }
    }
}
