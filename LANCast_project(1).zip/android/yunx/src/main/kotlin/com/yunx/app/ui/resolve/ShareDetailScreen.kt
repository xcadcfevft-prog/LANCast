/*
 * YunX (云析) - A network drive share-link parser and high-speed downloader for Android.
 * Copyright (C) 2026 CYQawa
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.yunx.app.ui.resolve

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Shape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.outlined.ArrowUpward
import androidx.compose.material.icons.outlined.BookmarkAdd
import androidx.compose.material.icons.outlined.ChevronRight
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.FolderOpen
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.InsertDriveFile
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.SaveAlt
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.ui.graphics.Color
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarScrollBehavior
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import coil3.compose.AsyncImage
import coil3.network.httpHeaders
import coil3.request.ImageRequest
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import com.yunx.app.data.db.BookmarkEntity
import com.yunx.app.data.network.SharePlatform
import com.yunx.app.data.network.model.ShareFile
import com.yunx.app.data.network.model.ShareSession
import com.yunx.app.data.prefs.SettingsRepository
import com.yunx.app.ui.components.FileNameText
import com.yunx.app.ui.components.ScrollToTopButton
import com.yunx.app.ui.components.YunXLoading
import com.yunx.app.ui.items.MultiSelectAction
import com.yunx.app.ui.items.MultiSelectBar
import com.yunx.app.ui.preview.PreviewKind
import com.yunx.app.ui.preview.PreviewTypes
import com.yunx.app.ui.preview.previewNetworkHeaders
import com.yunx.app.ui.screens.AddToBookmarkDialog
import com.yunx.app.ui.screens.BaiduSaveContent
import com.yunx.app.ui.screens.C139SaveContent
import com.yunx.app.ui.screens.GuangYaSaveContent
import com.yunx.app.ui.screens.Pan115SaveContent
import com.yunx.app.ui.screens.Pan123SaveContent
import com.yunx.app.ui.screens.SaveToCloudContent
import com.yunx.app.ui.screens.UCSaveContent
import com.yunx.app.ui.screens.XunleiSaveContent
import com.yunx.app.ui.viewmodel.BaiduCloudViewModel
import com.yunx.app.ui.viewmodel.C139CloudViewModel
import com.yunx.app.ui.viewmodel.GuangYaCloudViewModel
import com.yunx.app.ui.viewmodel.Pan115CloudViewModel
import com.yunx.app.ui.viewmodel.Pan123CloudViewModel
import com.yunx.app.ui.viewmodel.QuarkCloudViewModel
import com.yunx.app.ui.viewmodel.ResolveViewModel
import com.yunx.app.ui.viewmodel.UCCoudViewModel
import com.yunx.app.ui.viewmodel.XunleiCloudViewModel
import com.yunx.app.ui.theme.ListGroupGap
import com.yunx.app.ui.theme.ThemeController
import com.yunx.app.ui.theme.effectsDefault
import com.yunx.app.ui.theme.effectsFast
import com.yunx.app.ui.theme.listGroupShape
import com.yunx.app.ui.theme.spatialDefault
import com.yunx.app.ui.theme.spatialFast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/** 百度非会员限速阈值：>300MB 提示 */
private const val BAIDU_LIMIT_BYTES = 300L * 1024 * 1024

/**
 * 分享详情页：展示分享标题与文件列表，支持进入文件夹、点击文件获取下载直链。
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ShareDetailScreen(
    session: ShareSession,
    files: List<ShareFile>,
    viewModel: ResolveViewModel,
    /** 夸克云盘浏览 ViewModel（转存目录选择用；与网盘页同一实例） */
    quarkCloudViewModel: QuarkCloudViewModel,
    /** 迅雷网盘云盘浏览 ViewModel（迅雷分享转存目录选择用） */
    xunleiCloudViewModel: XunleiCloudViewModel,
    /** 百度网盘云盘浏览 ViewModel（百度分享转存目录选择用） */
    baiduCloudViewModel: BaiduCloudViewModel,
    /** 139 网盘云盘浏览 ViewModel（139 分享转存目录选择用） */
    c139CloudViewModel: C139CloudViewModel,
    /** UC 网盘云盘浏览 ViewModel（UC 分享转存目录选择用） */
    ucCloudViewModel: UCCoudViewModel,
    /** 123 云盘浏览 ViewModel（123 分享转存目录选择用） */
    pan123CloudViewModel: Pan123CloudViewModel,
    /** 115 网盘浏览 ViewModel（115 分享转存目录选择用） */
    pan115CloudViewModel: Pan115CloudViewModel,
    /** 光鸭云盘浏览 ViewModel（光鸭分享转存目录选择用） */
    guangyaCloudViewModel: GuangYaCloudViewModel,
    scrollBehavior: TopAppBarScrollBehavior,
    /** 文件列表滚动状态（由上层持有，跨目录切换保留） */
    listState: LazyListState,
    /** 各目录滚动位置记忆（key = 目录路径；由上层持有，跨目录切换保留） */
    scrollPositions: MutableMap<String, Int>,
    /** 顶部左上角返回：退出文件页回到输入页（输入框内容保留） */
    onExit: () -> Unit,
    /** 列表「返回上一级」：子目录回上级，根目录回输入页 */
    onBack: () -> Unit,
    /** 顶部额外内容（标题/面包屑之后）：GitHub 用于显示「forked from」 */
    extraHeaderContent: @Composable (() -> Unit)? = null,
    /** 列表底部额外内容（items 之后）：GitHub 用于显示 README 原文 */
    extraFooterContent: @Composable (() -> Unit)? = null,
    /** 文件行徽章（文件名旁）：GitHub 用于 Releases 最新/预发布/草稿、账号 repo Fork/语言 */
    fileBadge: @Composable ((ShareFile) -> Unit)? = null,
    /** 下拉刷新回调（仅 GitHub 平台传入）；null 时不启用下拉刷新，非 GitHub 平台行为不变 */
    onRefresh: (() -> Unit)? = null,
    /** 是否正在刷新（下拉刷新指示器状态） */
    refreshing: Boolean = false,
    modifier: Modifier = Modifier
) {
    val pathNames = viewModel.pathNames
    // 百度 >300MB 限速提示（解析页百度分享下载）
    val context = LocalContext.current
    val baiduSettings = remember { SettingsRepository(context) }
    var baiduLimitDismissed by remember { mutableStateOf(baiduSettings.baiduLimitHintDismissed) }
    var showBaiduLimitDialog by remember { mutableStateOf(false) }
    var pendingBaiduAction by remember { mutableStateOf<(() -> Unit)?>(null) }
    // 「添加至收藏」弹窗
    var showAddBookmark by remember { mutableStateOf(false) }
    // 文件操作弹窗（点击文件行 / 文件夹行尾「更多」打开）：下载 / 转存
    var actionFile by remember { mutableStateOf<ShareFile?>(null) }

    /** 百度分享下载前检查：>300MB 且未忽略时弹提示，确认后执行 */
    fun checkBaiduLimit(file: ShareFile, proceed: () -> Unit) {
        if (viewModel.isBaidu && !baiduLimitDismissed && file.fsize > BAIDU_LIMIT_BYTES) {
            pendingBaiduAction = proceed
            showBaiduLimitDialog = true
        } else {
            proceed()
        }
    }
    // 系统返回键：多选模式下先退出多选，否则返回上一级目录 / 根目录回输入页
    BackHandler {
        if (viewModel.multiSelectMode) viewModel.exitMultiSelect() else onBack()
    }
    // 文件列表滚动状态（由上层 ResolveScreen 持有：进入文件夹/返回时列表重建也不会丢失）
    // 搜索过滤（本地过滤当前目录文件）
    var searchQuery by rememberSaveable { mutableStateOf("") }
    var showSearch by rememberSaveable { mutableStateOf(false) }
    val displayFiles = remember(files, searchQuery) {
        val q = searchQuery.trim()
        if (q.isEmpty()) files else files.filter { it.fname.contains(q, ignoreCase = true) }
    }
    // 各目录滚动位置记忆：进入文件夹/返回时按目录路径恢复，避免返回后列表回到顶部
    val currentDirKey = remember(pathNames) { pathNames.joinToString("/") }
    // 已应用过滚动位置的目录：从在线预览返回时（本页会随预览页一起离开组合）该标记随保存态恢复，
    // 于是同目录不再被这里强制拉回顶部，位置交给 listState 自己的 rememberSaveable 恢复
    var appliedDirKey by rememberSaveable { mutableStateOf<String?>(null) }
    LaunchedEffect(currentDirKey) {
        // 只有切换目录才重置滚动；无记录（如首次进入）则回到顶部
        if (appliedDirKey == currentDirKey) return@LaunchedEffect
        appliedDirKey = currentDirKey
        listState.scrollToItem(scrollPositions[currentDirKey] ?: 0)
    }
    // 多选模式：底部批量操作栏 + 处理中弹窗
    // 内容抽成 lambda：仅 GitHub 平台包 PullToRefreshBox 下拉刷新，非 GitHub 路径原样渲染
    val listContent: @Composable () -> Unit = {
    Box(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .nestedScroll(scrollBehavior.nestedScrollConnection),
            contentPadding = PaddingValues(
                        start = 16.dp, end = 16.dp, top = 16.dp,
                        bottom = if (viewModel.multiSelectMode) 96.dp else 16.dp
                    ),
            // 列表组：各项首尾相接（组内间距用 ListGroupGap），行圆角按首/中/末分段给
            verticalArrangement = Arrangement.spacedBy(ListGroupGap)
        ) {
            item {
                Column(modifier = Modifier.padding(bottom = 8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (viewModel.multiSelectMode) {
                            // 多选模式：取消选择
                            IconButton(onClick = { viewModel.exitMultiSelect() }) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "取消选择")
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "已选 ${viewModel.selected.size} 项",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Medium
                                )
                                Text(
                                    text = if (viewModel.selected.size == displayFiles.size) "已全选" else "点击选择更多文件",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            TextButton(onClick = { viewModel.toggleSelectAll(displayFiles) }) {
                                Text(if (viewModel.selected.size == displayFiles.size) "取消全选" else "全选")
                            }
                        } else {
                            IconButton(onClick = onExit) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "返回")
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = session.title.ifBlank { "分享内容" },
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Medium,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = if (searchQuery.isBlank()) "共 ${files.size} 项"
                                    else "匹配 ${displayFiles.size} / ${files.size} 项",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(onClick = { showAddBookmark = true }) {
                                Icon(
                                    imageVector = Icons.Outlined.BookmarkAdd,
                                    contentDescription = "添加至收藏",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                            IconButton(onClick = { showSearch = !showSearch }) {
                                Icon(
                                    imageVector = Icons.Outlined.Search,
                                    contentDescription = if (showSearch) "关闭搜索" else "搜索文件",
                                    tint = if (showSearch) {
                                        MaterialTheme.colorScheme.primary
                                    } else {
                                        MaterialTheme.colorScheme.onSurfaceVariant
                                    }
                                )
                            }
                        }
                    }
                    // 可点击面包屑（多选模式下隐藏）
                    if (!viewModel.multiSelectMode) {
                        CrumbBar(
                            rootTitle = session.title.ifBlank { "分享内容" },
                            pathNames = pathNames,
                            onNavigate = { level ->
                                scrollPositions[currentDirKey] = listState.firstVisibleItemIndex
                                viewModel.navigateToLevel(level)
                            }
                        )
                    }
                    // 搜索框（点击放大镜展开；与面包屑保持间距 + 展开/收起动画）
                    AnimatedVisibility(
                        visible = showSearch && !viewModel.multiSelectMode,
                        enter = expandVertically(spatialDefault()) + fadeIn(effectsDefault()),
                        exit = shrinkVertically(spatialFast()) + fadeOut(effectsFast())
                    ) {
                        Column {
                            Spacer(modifier = Modifier.height(10.dp))
                            OutlinedTextField(
                                value = searchQuery,
                                onValueChange = { searchQuery = it },
                                modifier = Modifier.fillMaxWidth(),
                                placeholder = { Text("搜索当前目录文件") },
                                leadingIcon = { Icon(Icons.Outlined.Search, contentDescription = null) },
                                trailingIcon = {
                                    if (searchQuery.isNotEmpty()) {
                                        IconButton(onClick = { searchQuery = "" }) {
                                            Icon(Icons.Filled.Close, contentDescription = "清空搜索")
                                        }
                                    }
                                },
                                singleLine = true,
                                shape = MaterialTheme.shapes.large
                            )
                        }
                    }
                    // 顶部额外内容（GitHub：forked from 等）
                    extraHeaderContent?.let { header ->
                        Spacer(modifier = Modifier.height(6.dp))
                        header()
                    }
                    // 游客模式（未登录）：列表可用；夸克/UC 可直接下载，其余平台下载/转存需登录 —— 常驻一行说明，避免点了才报错
                    if (viewModel.isGuest) {
                        Spacer(modifier = Modifier.height(10.dp))
                        GuestBrowseNotice(viewModel.sharePlatform)
                    }
                }
            }

            // 返回上一级（独立于文件列表组，故自带下间距）
            if (pathNames.isNotEmpty()) {
                item {
                    Column(modifier = Modifier.padding(bottom = 8.dp)) {
                        BackToParentItem(onClick = {
                            // 记录当前目录滚动位置，返回上级后恢复上级位置
                            scrollPositions[currentDirKey] = listState.firstVisibleItemIndex
                            onBack()
                        })
                    }
                }
            }

            if (displayFiles.isEmpty()) {
                item {
                    Text(
                        text = if (files.isEmpty()) "此目录为空" else "未找到匹配「${searchQuery.trim()}」的文件",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 32.dp),
                        textAlign = TextAlign.Center
                    )
                }
            }

            itemsIndexed(displayFiles, key = { _, f -> f.fid }) { index, file ->
                ShareFileRow(
                    file = file,
                    shape = listGroupShape(index, displayFiles.size),
                    onClick = {
                        if (viewModel.multiSelectMode) {
                            viewModel.toggleSelect(file)
                        } else if (file.isdir) {
                            // 记录当前目录滚动位置，进入子目录后恢复子目录位置
                            scrollPositions[currentDirKey] = listState.firstVisibleItemIndex
                            viewModel.openFolder(file)
                        } else {
                            // 文件：先弹文件操作弹窗（下载/转存），不再直接进入下载流程
                            actionFile = file
                        }
                    },
                    // 文件夹点击是进入目录，故用行尾「更多」打开同一个弹窗（与网盘页一致）；
                    // 文件点击即弹窗，不再需要行尾按钮（原来的「转存」图标已统一进弹窗）
                    onMore = if (!viewModel.multiSelectMode && file.isdir) {
                        { actionFile = file }
                    } else {
                        null
                    },
                    onLongClick = if (!viewModel.multiSelectMode) {
                        { viewModel.enterMultiSelect(file) }
                    } else {
                        null
                    },
                    selected = viewModel.selected.contains(file),
                    showCheckbox = viewModel.multiSelectMode,
                    badge = fileBadge?.let { b -> { b(file) } }
                )
            }

            // 列表底部额外内容（GitHub：README 原文）
            extraFooterContent?.let { footer ->
                item(key = "extra_footer") {
                    footer()
                }
            }
        }

        // 返回顶部按钮（上滑离开顶部后显示；多选模式下上移避开底部批量栏）
        ScrollToTopButton(
            listState = listState,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(
                    end = 16.dp,
                    bottom = if (viewModel.multiSelectMode) 104.dp else 16.dp
                )
        )

        // 多选模式：底部批量操作栏（转存/下载）
        if (viewModel.multiSelectMode) {
            MultiSelectBar(
                busy = viewModel.isSaving || viewModel.batchProgress != null,
                count = viewModel.selected.size,
                actions = buildList {
                    // 转存仅夸克分享支持
                    if (viewModel.canSave) {
                        add(
                            MultiSelectAction("转存", Icons.Outlined.SaveAlt, MaterialTheme.colorScheme.primary) {
                                viewModel.batchSaveToCloud()
                            }
                        )
                    }
                    add(
                        MultiSelectAction("下载", Icons.Outlined.Download, MaterialTheme.colorScheme.primary) {
                            // 百度批量下载：选中项含 >300MB 文件时先弹限速提示
                            val hasBig = viewModel.selected.any { it.fsize > BAIDU_LIMIT_BYTES }
                            if (viewModel.isBaidu && !baiduLimitDismissed && hasBig) {
                                pendingBaiduAction = { viewModel.batchDownload() }
                                showBaiduLimitDialog = true
                            } else {
                                viewModel.batchDownload()
                            }
                        }
                    )
                }
            )
        }
    }
    }

    // 仅传入 onRefresh（GitHub 平台）时启用下拉刷新；否则原样渲染内容
    if (onRefresh != null) {
        PullToRefreshBox(
            isRefreshing = refreshing,
            onRefresh = onRefresh,
            modifier = Modifier.fillMaxSize()
        ) {
            listContent()
        }
    } else {
        listContent()
    }

    // 百度 >300MB 限速提示弹窗（解析页百度分享下载，可勾选不再显示）
    if (showBaiduLimitDialog) {
        var neverShow by remember { mutableStateOf(baiduLimitDismissed) }
        AlertDialog(
            onDismissRequest = { showBaiduLimitDialog = false },
            title = { Text("下载大文件提示") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "百度网盘非会员超过300MB会被限速，下载速度可能较慢。是否继续下载？",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = neverShow, onCheckedChange = { neverShow = it })
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("不再显示此提示", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showBaiduLimitDialog = false
                        baiduSettings.baiduLimitHintDismissed = neverShow
                        baiduLimitDismissed = neverShow
                        pendingBaiduAction?.invoke()
                        pendingBaiduAction = null
                    }
                ) { Text("继续下载") }
            },
            dismissButton = {
                TextButton(onClick = { showBaiduLimitDialog = false }) { Text("取消") }
            }
        )
    }

    // 批量处理中：加载弹窗（批量下载显示获取进度，如 "正在获取下载链接 2/5"；可中断）
    if (viewModel.isBatchWorking) {
        AlertDialog(
            onDismissRequest = { },
            confirmButton = { },
            dismissButton = {
                TextButton(onClick = { viewModel.cancelBatch() }) {
                    Text("中断", color = MaterialTheme.colorScheme.error)
                }
            },
            title = { Text("批量处理中") },
            text = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    YunXLoading(modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Text(
                        text = viewModel.batchProgress?.let { "正在获取下载链接 $it" }
                            ?: "正在批量处理，请稍候…",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        )
    }

    // 添加至收藏弹窗（当前分享链接，支持自定义标题与分类）
    if (showAddBookmark) {
        AddToBookmarkDialog(
            title = session.title.ifBlank { "分享内容" },
            initialCategory = BookmarkEntity.DEFAULT_CATEGORY,
            categories = BookmarkEntity.PRESET_CATEGORIES,
            onConfirm = { title, category ->
                showAddBookmark = false
                viewModel.addCurrentToBookmark(title, category)
            },
            onDismiss = { showAddBookmark = false }
        )
    }

    // 文件操作弹窗（点击文件行 / 文件夹行尾「更多」）：下载 / 转存
    // 与网盘页同一形态（ModalBottomSheet + 文件信息 + 操作项）；弹窗内部先播放退场动画再动作，
    // 所以这里一关弹窗就执行动作不会出现「弹窗瞬间消失」或与下载链接弹窗/转存弹窗重叠。
    actionFile?.let { file ->
        ResolveFileActionSheet(
            file = file,
            canSave = viewModel.canSave,
            saving = viewModel.isSaving,
            onDownload = {
                actionFile = null
                // 百度分享 >300MB 限速提示（与原来直接点击文件时一致）
                checkBaiduLimit(file) { viewModel.fetchDownloadLink(file) }
            },
            // 在线预览：仅「可预览类型且非目录」才给入口 —— 可见性统一由 PreviewTypes 判断
            // （压缩包/安装包/未知类型返回 null 不显示，避免点了必然失败的菜单项）
            onPreview = if (!file.isdir && PreviewTypes.kindOf(file.fname) != null) {
                {
                    actionFile = null
                    viewModel.openPreview(file)
                }
            } else {
                null
            },
            onDownloadFolder = {
                actionFile = null
                viewModel.downloadFolder(file)
            },
            // 不关弹窗：准备好转存状态后弹窗内部切到转存步骤（内容淡入淡出，不再另开一个弹窗）
            // 游客模式例外：转存会被 ViewModel 拦下并弹 Snackbar，这里先关掉弹窗让提示可见
            onSave = {
                if (viewModel.isGuest) actionFile = null
                viewModel.requestSave(file)
            },
            // 关弹窗时顺手清掉转存状态，避免下次打开仍停在上次的目录选择
            onDismiss = {
                actionFile = null
                viewModel.dismissSave()
            },
            // 转存步骤：与网盘页「移动到」同为弹窗内二级内容，返回箭头回主菜单
            saveStep = { onBack, onDone ->
                // 转存成功后 ViewModel 会清空 saveTarget（失败/未登录则保留，让用户重试）
                LaunchedEffect(viewModel.saveTarget) {
                    if (viewModel.saveTarget == null) onDone()
                }
                when {
                    viewModel.isSaveXunlei -> XunleiSaveContent(viewModel, xunleiCloudViewModel, onBack)
                    viewModel.isSaveBaidu -> BaiduSaveContent(viewModel, baiduCloudViewModel, onBack)
                    viewModel.isSaveC139 -> C139SaveContent(viewModel, c139CloudViewModel, onBack)
                    viewModel.isSaveUC -> UCSaveContent(viewModel, ucCloudViewModel, onBack)
                    viewModel.isSavePan123 -> Pan123SaveContent(viewModel, pan123CloudViewModel, onBack)
                    viewModel.isSavePan115 -> Pan115SaveContent(viewModel, pan115CloudViewModel, onBack)
                    viewModel.isSaveGuangYa -> GuangYaSaveContent(viewModel, guangyaCloudViewModel, onBack)
                    else -> SaveToCloudContent(viewModel, quarkCloudViewModel, onBack)
                }
            }
        )
    }
}

/**
 * 游客模式提示条：未登录也能浏览分享列表（7 个网盘的列表接口都允许匿名）。
 * 夸克/UC 还能直接下载（夸克约 50MB 以内的小文件、UC 不限大小），其余平台下载与 7 平台转存都要登录
 * —— 见 Agent.md §3.19。
 */
@Composable
private fun GuestBrowseNotice(platform: SharePlatform) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surfaceContainerHigh
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Outlined.Info,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(16.dp)
            )
            Spacer(Modifier.width(8.dp))
            Text(
                text = when (platform) {
                    SharePlatform.QUARK ->
                        "未登录浏览：可直接下载约 50MB 以内的小文件；更大的文件和转存需先到「网盘」页登录"
                    SharePlatform.UC ->
                        "未登录浏览：可直接下载（不限大小）；转存需先到「网盘」页登录"
                    else ->
                        "未登录浏览：可查看文件列表，下载/转存需先到「网盘」页登录"
                },
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
internal fun BackToParentItem(onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Outlined.ArrowUpward,
                contentDescription = null,
                modifier = Modifier.size(20.dp),
                tint = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = "返回上一级",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

/**
 * 可点击面包屑：根标题 > 目录1 > 目录2。
 * 非当前层可点击回退到对应目录；当前层高亮（文件夹图标 + 主题色）。
 * 横向滚动并自动定位到当前层。
 */
@Composable
internal fun CrumbBar(
    rootTitle: String,
    pathNames: List<String>,
    onNavigate: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val crumbs = buildList {
        add(rootTitle.ifBlank { "根目录" })
        pathNames.forEach { add(it) }
    }
    val scroll = rememberScrollState()
    LaunchedEffect(crumbs.size, crumbs.lastOrNull()) {
        scroll.scrollTo(scroll.maxValue)
    }
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = modifier
            .fillMaxWidth()
            .horizontalScroll(scroll)
            .padding(start = 8.dp, top = 4.dp)
    ) {
        crumbs.forEachIndexed { i, name ->
            val isLast = i == crumbs.size - 1
            if (!isLast) {
                // 可点击层级：点击回退到该目录
                Text(
                    text = name,
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    modifier = Modifier
                        .clickable { onNavigate(i) }
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                )
                Icon(
                    imageVector = Icons.Outlined.ChevronRight,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp),
                    tint = MaterialTheme.colorScheme.outline
                )
            } else {
                // 当前层：高亮 + 文件夹图标（不可点）
                Icon(
                    imageVector = Icons.Outlined.FolderOpen,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp),
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = name,
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 1,
                    modifier = Modifier.padding(end = 4.dp)
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class, ExperimentalMaterial3ExpressiveApi::class)
@Composable
internal fun ShareFileRow(
    file: ShareFile,
    onClick: () -> Unit,
    /** 非空时行尾显示「更多」按钮（打开文件操作弹窗） */
    onMore: (() -> Unit)? = null,
    /** 长按进入多选（多选模式下为 null） */
    onLongClick: (() -> Unit)? = null,
    /** 多选模式：是否选中 */
    selected: Boolean = false,
    /** 是否显示行首复选框（仅多选模式列表传 true；移动/转存等选择器不显示） */
    showCheckbox: Boolean = false,
    /** 文件徽章（文件名旁；GitHub Releases 最新/预发布/草稿、账号 repo Fork/语言） */
    badge: @Composable (() -> Unit)? = null,
    /** 行形状：网盘页列表组传 listGroupShape(index, count)（首/末项大圆角、中间项小圆角）；默认整行圆角 */
    shape: Shape = MaterialTheme.shapes.large,
    /** 列表项动画等（调用方传入 Modifier.animateItem()） */
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            // ★ 必须先裁到卡片圆角再挂点击/长按：combinedClickable 位于 Card 的 Surface 之外，
            //   不裁剪的话点击与长按涟漪会画到圆角之外（四角溢出）。
            .clip(shape)
            .combinedClickable(
                onClick = onClick,
                onLongClick = onLongClick
            ),
        shape = shape,
        colors = CardDefaults.cardColors(
            containerColor = if (selected) {
                MaterialTheme.colorScheme.primaryContainer
            } else {
                MaterialTheme.colorScheme.surfaceContainerLow
            }
        )
    ) {
        // ★ 行内容交给 Material 3 的 ListItem（不再手写 Row + Column）：
        //   行高、内边距、标题/副标题字号层级由组件按 M3 规范给出，七个网盘页与本页共用同一形态。
        //   外层保留 Card 负责圆角、选中底色与涟漪裁剪，故 ListItem 容器设为透明。
        ListItem(
            headlineContent = {
                // 文件名 + 徽章（同一行；展示方式由「主题与外观 → 文件名显示」决定：跑马灯 / 多行折行）
                Row(verticalAlignment = Alignment.CenterVertically) {
                    FileNameText(
                        text = file.fname,
                        // weight(fill = false)：先给徽章留出位置，文件名再占满剩余宽度（短名不拉伸）
                        modifier = Modifier.weight(1f, fill = false)
                    )
                    if (badge != null) {
                        Spacer(modifier = Modifier.width(6.dp))
                        badge()
                    }
                }
            },
            supportingContent = {
                // 副标题行：文件夹/大小 + 修改时间（同一行展示）
                Text(
                    text = buildString {
                        append(if (file.isdir) "文件夹" else formatSize(file.fsize))
                        val time = formatModifyTime(file.modifyTime)
                        if (time.isNotBlank()) {
                            append("  ·  ")
                            append(time)
                        }
                    },
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            },
            leadingContent = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    // 多选模式：行首复选框（仅多选列表显示）
                    if (showCheckbox) {
                        Checkbox(
                            checked = selected,
                            onCheckedChange = { onClick() },
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                    }
                    // 行首图标 / 缩略图（见 FileLeadingIcon）
                    FileLeadingIcon(file = file)
                }
            },
            trailingContent = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (onMore != null) {
                        IconButton(onClick = onMore, modifier = Modifier.size(36.dp)) {
                            Icon(
                                imageVector = Icons.Outlined.MoreVert,
                                contentDescription = "更多",
                                modifier = Modifier.size(18.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Icon(
                        imageVector = Icons.Outlined.ChevronRight,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.outline
                    )
                }
            },
            // 底色/选中底色由外层 Card 决定，这里必须透明，否则会盖住卡片颜色
            colors = ListItemDefaults.colors(containerColor = Color.Transparent)
        )
    }
}

/**
 * 列表行行首：有缩略图就画小图，否则画文件图标。
 *
 * ★ 缩略图信息（地址 + 请求头）由列表接口随条目一起给出（`FileThumbnail`），这里不需要接触账号凭证；
 *   开关在「设置 → 通用 → 列表缩略图」，关掉后**一个取图请求都不发**（不是画完再藏起来）。
 *
 * 为什么把文件图标垫在缩略图下面：Coil 加载失败时什么都不画，占位图标自然成了兜底 ——
 * 不必再维护一份 error painter，也不会出现「空框」；加载过程中同样露着图标，列表不会一行行跳变。
 */
@Composable
private fun FileLeadingIcon(file: ShareFile) {
    val thumbnail = file.thumbnail?.takeIf {
        !file.isdir &&
            ThemeController.cloudThumbnails &&
            // 只给图片：视频/文档的缩略图各家给得并不一致，先不放开
            PreviewTypes.kindOf(file.fname) == PreviewKind.IMAGE
    }
    if (thumbnail == null) {
        FileIconBadge(file = file)
        return
    }
    val context = LocalContext.current
    val request = remember(thumbnail.url, thumbnail.headers) {
        ImageRequest.Builder(context)
            .data(thumbnail.url)
            .httpHeaders(previewNetworkHeaders(thumbnail.headers))
            .build()
    }
    Box(
        modifier = Modifier
            .size(40.dp)
            .clip(RoundedCornerShape(9.dp))
            .background(MaterialTheme.colorScheme.surfaceContainerHighest),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = Icons.Outlined.InsertDriveFile,
            contentDescription = null,
            modifier = Modifier.size(20.dp),
            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f)
        )
        AsyncImage(
            model = request,
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )
    }
}

/** 行首圆形图标（文件夹 / 没有缩略图的文件）：网盘页、解析页与移动/转存选择器共用同一形态 */
@Composable
private fun FileIconBadge(file: ShareFile) {
    Surface(
        modifier = Modifier.size(40.dp),
        shape = CircleShape,
        color = if (file.isdir) {
            MaterialTheme.colorScheme.secondaryContainer
        } else {
            MaterialTheme.colorScheme.surfaceContainerHighest
        }
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(
                imageVector = if (file.isdir) Icons.Outlined.Folder else Icons.Outlined.InsertDriveFile,
                contentDescription = null,
                modifier = Modifier.size(20.dp),
                tint = if (file.isdir) {
                    MaterialTheme.colorScheme.onSecondaryContainer
                } else {
                    MaterialTheme.colorScheme.onSurfaceVariant
                }
            )
        }
    }
}

internal fun formatSize(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    var value = bytes.toDouble()
    var i = 0
    while (value >= 1024 && i < units.size - 1) {
        value /= 1024
        i++
    }
    return String.format("%.1f %s", value, units[i])
}

/**
 * 各网盘返回的时间字段格式不统一，统一解析为毫秒时间戳；无法识别返回 null。
 * 已覆盖：
 * - 夸克 / UC：`updated_at` / `modify_time` —— 13 位毫秒时间戳
 * - 百度：`server_mtime` —— 10 位秒级时间戳
 * - 迅雷：`modified_time` —— ISO 8601（带时区偏移或 Z）
 * - 139：云盘 `updatedAt` ISO 8601；分享 `udTime`/`ctTime` 可能为 yyyyMMddHHmmss
 * - 123：`UpdateAt` —— ISO 8601 或 "yyyy-MM-dd HH:mm:ss"
 */
private fun parseModifyTimeMillis(raw: String): Long? {
    val s = raw.trim()
    if (s.isEmpty()) return null

    // 1) 纯数字：时间戳（13 位毫秒 / 10 位秒）或紧凑日期串 yyyyMMddHHmmss
    if (s.all(Char::isDigit)) {
        return when (s.length) {
            13 -> s.toLongOrNull()
            10 -> s.toLongOrNull()?.times(1000L)
            14 -> runCatching {
                SimpleDateFormat("yyyyMMddHHmmss", Locale.getDefault()).apply {
                    isLenient = false
                }.parse(s)?.time
            }.getOrNull()
            // 其余长度按数值大小推断秒/毫秒（阈值≈1973 年的毫秒值）
            else -> s.toLongOrNull()?.let { if (it > 100_000_000_000L) it else it * 1000L }
        }
    }

    // 2) 文本时间：先剥离时区后缀，再按「长 → 短」模式尝试解析
    //    （不用 SimpleDateFormat 的 XXX 模式，它要求 API 24+）
    var work = s.replace('T', ' ')
    var tz: TimeZone? = null
    if (work.endsWith("Z", ignoreCase = true)) {
        tz = TimeZone.getTimeZone("UTC")
        work = work.dropLast(1)
    } else {
        val m = Regex("([+-]\\d{2}:?\\d{2})$").find(work)
        if (m != null) {
            tz = TimeZone.getTimeZone("GMT${m.groupValues[1]}")
            work = work.removeRange(m.range)
        }
    }
    // 去掉毫秒小数部分
    val body = work.trim().substringBefore('.')
    val zone: TimeZone? = tz

    val patterns = listOf(
        "yyyy-MM-dd HH:mm:ss",
        "yyyy-MM-dd HH:mm",
        "yyyy/MM/dd HH:mm:ss",
        "yyyy-MM-dd",
        "yyyy/MM/dd"
    )
    for (p in patterns) {
        val fmt = SimpleDateFormat(p, Locale.getDefault())
        fmt.isLenient = false
        if (zone != null) fmt.timeZone = zone
        runCatching { fmt.parse(body) }.getOrNull()?.let { return it.time }
    }
    return null
}

/**
 * 文件修改时间展示（列表副标题用，尽量紧凑）：
 * 今年内 → "MM-dd HH:mm"；跨年 → "yyyy-MM-dd"；无法解析 → 空串（调用方据此隐藏）。
 */
internal fun formatModifyTime(raw: String): String {
    val millis = parseModifyTimeMillis(raw) ?: return ""
    if (millis <= 0) return ""
    val cal = Calendar.getInstance()
    val currentYear = cal.get(Calendar.YEAR)
    cal.timeInMillis = millis
    val pattern = if (cal.get(Calendar.YEAR) == currentYear) "MM-dd HH:mm" else "yyyy-MM-dd"
    return runCatching {
        SimpleDateFormat(pattern, Locale.getDefault()).format(Date(millis))
    }.getOrDefault("")
}