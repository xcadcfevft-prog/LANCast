/*
 * YunX (云析) - A network drive share-link parser and high-speed downloader for Android.
 * Copyright (C) 2026 CYQawa
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.yunx.app

import android.app.Application
import android.content.ComponentCallbacks2
import android.content.Context

/**
 * 云析模块的一次性初始化（原先在 `YunXApp.onCreate` 里）。
 *
 * 云析现在是宿主应用（瞬流）里的一个功能模块，没有自己的 Application，
 * 所以改成「用到才初始化」：[MainActivity] 与 [com.yunx.app.data.download.DownloadService]
 * 启动时都会调 [ensureInit]，幂等，只会真正执行一次。
 *
 * 注意：不再安装全局未捕获异常处理器（那是宿主进程级的东西，不能被云析接管）。
 */
object YunXBootstrap {

    @Volatile
    private var done = false

    fun ensureInit(context: Context) {
        if (done) return
        synchronized(this) {
            if (done) return
            val app = context.applicationContext as Application
            com.yunx.app.data.network.XunleiDeviceFingerprint.init(app)
            // 123 云盘的设备标识（loginuuid）：必须跨启动保持稳定
            com.yunx.app.data.network.Pan123DeviceId.install(app)
            // 隐藏 WebView 解析通道：需要跟踪「当前前台 Activity」
            com.yunx.app.data.network.video.HeadlessWebView.install(app)
            // 恢复用户配置的 HTTP 代理（任何异常都不得影响启动）
            runCatching {
                val prefs = app.getSharedPreferences("yunx_settings", Context.MODE_PRIVATE)
                if (prefs.getBoolean("proxy_enabled", false)) {
                    val host = prefs.getString("proxy_host", "")?.takeIf { it.isNotBlank() }
                    val port = prefs.getInt("proxy_port", 7890)
                    if (host != null && port in 1..65535) {
                        com.yunx.app.data.network.HttpClients.setProxy(host, port)
                    }
                }
            }
            purgeDownloadLeftovers(app)
            com.yunx.app.util.DiagnosticLog.install(app)
            com.yunx.app.data.download.DownloadDebugLog.install(app)
            runCatching { com.yunx.app.util.LinkOpener.syncAll(app) }
            autoStartGopeedIfSelected(app)
            done = true
        }
    }

    /** 内存压力时释放空闲 HTTP 连接；宿主 Application.onTrimMemory 可选择性转发过来。 */
    fun onTrimMemory(level: Int) {
        if (level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_LOW) {
            com.yunx.app.data.network.HttpClients.evictIdleConnections()
        }
    }

    /** 清理历史版本保存失败遗留的不可见下载半成品，放后台线程做一次。 */
    private fun purgeDownloadLeftovers(ctx: Context) {
        Thread {
            runCatching { com.yunx.app.data.download.DownloadSaver.purgeOwnPendingFiles(ctx) }
        }.start()
    }

    /**
     * 选了 Gopeed 引擎时，启动就把引擎加载起来（只有导入过内核才做）；
     * 无论选哪个下载器，都先把引擎的内存状态与真实文件对齐一次。任何失败只记日志。
     */
    private fun autoStartGopeedIfSelected(ctx: Context) {
        val engine = com.yunx.app.data.gopeed.GopeedEngine
        val settingsRepo = com.yunx.app.data.prefs.SettingsRepository(ctx)
        engine.syncInstalledState(ctx)
        if (settingsRepo.downloadEngine != com.yunx.app.data.prefs.SettingsRepository.ENGINE_GOPEED) return
        if (!engine.isInstalled(ctx)) {
            settingsRepo.downloadEngine = com.yunx.app.data.prefs.SettingsRepository.ENGINE_BUILTIN
            return
        }
        Thread {
            runCatching {
                engine.start(ctx, engine.resolveDownloadDir(ctx))
            }.onFailure {
                android.util.Log.e("YunX", "启动时自动加载 Gopeed 引擎失败：${it.message}", it)
            }
        }.start()
    }
}
