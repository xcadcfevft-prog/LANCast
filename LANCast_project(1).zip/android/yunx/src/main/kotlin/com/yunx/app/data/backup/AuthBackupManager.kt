/*
 * YunX (云析) - A network drive share-link parser and high-speed downloader for Android.
 * Copyright (C) 2026 CYQawa
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.yunx.app.data.backup

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.yunx.app.data.db.BaiduAccountDao
import com.yunx.app.data.db.BaiduAccountEntity
import com.yunx.app.data.db.C139AccountDao
import com.yunx.app.data.db.C139AccountEntity
import com.yunx.app.data.db.GuangYaAccountDao
import com.yunx.app.data.db.GuangYaAccountEntity
import com.yunx.app.data.db.ILanzouAccountDao
import com.yunx.app.data.db.ILanzouAccountEntity
import com.yunx.app.data.db.LanzouAccountDao
import com.yunx.app.data.db.LanzouAccountEntity
import com.yunx.app.data.db.Pan115AccountDao
import com.yunx.app.data.db.Pan115AccountEntity
import com.yunx.app.data.db.Pan123AccountDao
import com.yunx.app.data.db.Pan123AccountEntity
import com.yunx.app.data.db.QuarkAccountDao
import com.yunx.app.data.db.QuarkAccountEntity
import com.yunx.app.data.db.UCAccountDao
import com.yunx.app.data.db.UCAccountEntity
import com.yunx.app.data.db.XunleiAccountDao
import com.yunx.app.data.db.XunleiAccountEntity
import com.yunx.app.data.db.VideoAccountDao
import com.yunx.app.data.db.VideoAccountEntity
import com.yunx.app.data.network.GitHubTokenStore
import com.yunx.app.data.network.video.VideoPlatform
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 认证信息备份：把已登录的平台（网盘：夸克/UC/迅雷/百度/139/123/115/光鸭/蓝奏云优享版/蓝奏云；
 * 视频解析：哔哩哔哩/小红书/Pixiv 等）凭证打包为 JSON，可导出到下载目录并在另一台设备导入恢复。
 */
class AuthBackupManager(
    private val quarkDao: QuarkAccountDao,
    private val ucDao: UCAccountDao,
    private val xunleiDao: XunleiAccountDao,
    private val baiduDao: BaiduAccountDao,
    private val c139Dao: C139AccountDao,
    private val pan123Dao: Pan123AccountDao,
    private val pan115Dao: Pan115AccountDao,
    private val guangyaDao: GuangYaAccountDao,
    private val ilanzouDao: ILanzouAccountDao,
    private val lanzouDao: LanzouAccountDao,
    private val videoAccountDao: VideoAccountDao
) {

    private companion object {
        const val APP_TAG = "yunx_auth_backup"
        const val VERSION = 1

        /**
         * 视频解析平台在备份里的前缀：哔哩哔哩存成 `video:BILIBILI`。
         * 视频账号与网盘账号是**两张表**（见 VideoAccountEntity），靠这个前缀在同一个 `accounts`
         * 数组里区分；它也不会和任何网盘的 platform 值撞名。
         */
        const val VIDEO_PREFIX = "video:"
    }

    /**
     * 导出认证信息（网盘 + 视频解析平台；强制 AES-GCM 加密）：
     * @param password 至少 8 位的备份口令
     * @param onlyLoggedIn true=仅导出凭证可用的已登录平台；false=导出数据库里全部绑定记录
     * @param context 用于读取 GitHub Token（Keystore 解密）
     * @return 明文 JSON 或 Base64 密文
     */
    suspend fun export(password: String? = null, onlyLoggedIn: Boolean = true, context: Context): String =
        withContext(Dispatchers.IO) {
            require(!password.isNullOrBlank() && password.length >= 8) { "备份口令至少 8 位" }
            val json = exportJson(onlyLoggedIn, context)
            AuthCrypto.encrypt(json, password)
        }

    /** 导出所有已登录平台为 JSON 字符串；无已登录平台时返回空 accounts */
    suspend fun exportJson(onlyLoggedIn: Boolean = true, context: Context): String = withContext(Dispatchers.IO) {
        val accounts = JSONArray()
        quarkDao.getAccount()?.let { a ->
            if (!onlyLoggedIn || a.cookie.isNotBlank()) accounts.put(
                JSONObject()
                    .put("platform", "quark")
                    .put("cookie", a.cookie)
                    .put("nickname", a.nickname)
                    .put("updatedAt", a.updatedAt)
            )
        }
        ucDao.getAccount()?.let { a ->
            if (!onlyLoggedIn || a.cookie.isNotBlank()) accounts.put(
                JSONObject()
                    .put("platform", "uc")
                    .put("cookie", a.cookie)
                    .put("nickname", a.nickname)
                    .put("updatedAt", a.updatedAt)
            )
        }
        xunleiDao.getAccount()?.let { a ->
            if (!onlyLoggedIn || a.accessToken.isNotBlank()) accounts.put(
                JSONObject()
                    .put("platform", "xunlei")
                    .put("accessToken", a.accessToken)
                    .put("refreshToken", a.refreshToken)
                    .put("deviceId", a.deviceId)
                    .put("captchaToken", a.captchaToken)
                    .put("nickname", a.nickname)
                    // 登录方式必须一起备份：网页登录的 token 只能用网页 OAuth 客户端刷新，
                    // 丢了它恢复后一刷新就失效（老备份没有这个字段，导入时按空串=App 通道处理）
                    .put("authType", a.authType)
                    .put("updatedAt", a.updatedAt)
            )
        }
        baiduDao.getAccount()?.let { a ->
            if (!onlyLoggedIn || a.cookie.isNotBlank()) accounts.put(
                JSONObject()
                    .put("platform", "baidu")
                    .put("cookie", a.cookie)
                    .put("nickname", a.nickname)
                    .put("updatedAt", a.updatedAt)
            )
        }
        c139Dao.getAccount()?.let { a ->
            if (!onlyLoggedIn || a.cookie.isNotBlank()) accounts.put(
                JSONObject()
                    .put("platform", "c139")
                    .put("cookie", a.cookie)
                    .put("authorization", a.authorization)
                    .put("nickname", a.nickname)
                    .put("updatedAt", a.updatedAt)
            )
        }
        pan123Dao.getAccount()?.let { a ->
            if (!onlyLoggedIn || a.accessToken.isNotBlank()) accounts.put(
                JSONObject()
                    .put("platform", "pan123")
                    .put("accessToken", a.accessToken)
                    .put("account", a.account)
                    .put("nickname", a.nickname)
                    .put("updatedAt", a.updatedAt)
            )
        }
        pan115Dao.getAccount()?.let { a ->
            if (!onlyLoggedIn || a.cookie.isNotBlank()) accounts.put(
                JSONObject()
                    .put("platform", "pan115")
                    .put("cookie", a.cookie)
                    .put("nickname", a.nickname)
                    .put("updatedAt", a.updatedAt)
            )
        }
        guangyaDao.getAccount()?.let { a ->
            if (!onlyLoggedIn || a.accessToken.isNotBlank()) accounts.put(
                JSONObject()
                    .put("platform", "guangya")
                    .put("accessToken", a.accessToken)
                    .put("refreshToken", a.refreshToken)
                    .put("deviceId", a.deviceId)
                    .put("deviceSign", a.deviceSign)
                    .put("account", a.account)
                    .put("nickname", a.nickname)
                    .put("updatedAt", a.updatedAt)
            )
        }
        ilanzouDao.getAccount()?.let { a ->
            if (!onlyLoggedIn || a.appToken.isNotBlank()) accounts.put(
                JSONObject()
                    .put("platform", "ilanzou")
                    .put("appToken", a.appToken)
                    .put("uuid", a.uuid)
                    .put("account", a.account)
                    .put("password", a.password)
                    .put("userId", a.userId)
                    .put("nickname", a.nickname)
                    .put("updatedAt", a.updatedAt)
            )
        }
        lanzouDao.getAccount()?.let { a ->
            if (!onlyLoggedIn || a.cookie.isNotBlank()) accounts.put(
                JSONObject()
                    .put("platform", "lanzou")
                    .put("cookie", a.cookie)
                    .put("nickname", a.nickname)
                    .put("updatedAt", a.updatedAt)
            )
        }
        // ★ 视频解析平台（哔哩哔哩/小红书/Pixiv…）：登录态同样只在手机本地，换机后要逐个重登，
        //   所以和网盘一起备份（2026-10-23 用户反馈「那三个视频平台没有进去」）。
        //   一张表存全部平台、允许同平台多账号，所以逐行导出，靠 id 还原「主账号/备注」这些行级状态。
        videoAccountDao.getAccounts().forEach { a ->
            if (a.cookie.isNotBlank()) accounts.put(
                JSONObject()
                    .put("platform", VIDEO_PREFIX + a.platform)
                    .put("id", a.id)
                    .put("cookie", a.cookie)
                    .put("nickname", a.nickname)
                    .put("isPrimary", a.isPrimary)
                    .put("remark", a.remark)
                    .put("updatedAt", a.updatedAt)
            )
        }
        val root = JSONObject()
            .put("app", APP_TAG)
            .put("version", VERSION)
            .put("exportedAt", System.currentTimeMillis())
            .put("accounts", accounts)
        // GitHub Token 单独顶层字段（它是单个标量凭证，存 Keystore 而非 Room，与网盘账号结构不同）。
        // 仅在已配置 Token 时导出；明文 token 仅存在于导出 JSON 内，最终由 AuthCrypto 口令加密保护，
        // 不落盘到其他位置、不打印日志。
        // 注意：runCatching 返回 Result，必须先 getOrNull() 解包出 String? 才能 ?.takeIf（否则 it 是 Result 类型编译失败）
        runCatching { GitHubTokenStore.getToken(context) }.getOrNull()
            ?.takeIf { !it.isNullOrBlank() && (!onlyLoggedIn || GitHubTokenStore.hasToken(context)) }
            ?.let { root.put("githubToken", it) }
        root.toString(2)
    }

    /**
     * 导入认证内容（可选 AES 解密）：
     * @param password 非空时先解密（密码错误抛异常）；null/空按明文 JSON 解析
     * @param context 用于恢复 GitHub Token（Keystore 重新加密）
     * @return 成功恢复的平台数；文件不合法抛异常
     */
    suspend fun import(content: String, password: String? = null, context: Context): Int =
        withContext(Dispatchers.IO) {
            val json = if (password.isNullOrBlank()) content else AuthCrypto.decrypt(content, password)
            importJson(json, context)
        }

    /** 导入 JSON，恢复各平台凭证；返回成功恢复的平台数；文件不合法抛异常 */
    suspend fun importJson(json: String, context: Context): Int = withContext(Dispatchers.IO) {
        val root = JSONObject(json)
        if (root.optString("app") != APP_TAG) {
            throw IllegalArgumentException("不是有效的云析认证备份文件")
        }
        val accounts = root.optJSONArray("accounts") ?: return@withContext 0
        var count = 0
        for (i in 0 until accounts.length()) {
            val obj = accounts.optJSONObject(i) ?: continue
            val platform = obj.optString("platform")
            // 视频解析平台（video:BILIBILI 这种）：与网盘同一张 accounts 数组，靠前缀分流
            if (platform.startsWith(VIDEO_PREFIX)) {
                val name = platform.removePrefix(VIDEO_PREFIX)
                // 只恢复本版本仍认识的平台：枚举被改名/删除后，旧备份不会写进谁也读不到的孤儿行
                if (VideoPlatform.fromName(name) == null) continue
                val c = obj.optString("cookie")
                if (c.isNotBlank()) {
                    videoAccountDao.upsert(
                        VideoAccountEntity(
                            // 多账号靠 id 定位原来的行；旧备份没有 id 时退回平台名（即该平台的主行）
                            id = obj.optString("id").ifBlank { name },
                            platform = name,
                            cookie = c,
                            nickname = obj.optString("nickname"),
                            updatedAt = obj.optLong("updatedAt", System.currentTimeMillis()),
                            isPrimary = obj.optBoolean("isPrimary", false),
                            remark = obj.optString("remark")
                        )
                    ); count++
                }
                continue
            }
            when (platform) {
                "quark" -> {
                    val c = obj.optString("cookie")
                    if (c.isNotBlank()) {
                        quarkDao.upsert(
                            QuarkAccountEntity(
                                id = "quark", cookie = c,
                                nickname = obj.optString("nickname"),
                                updatedAt = obj.optLong("updatedAt", System.currentTimeMillis())
                            )
                        ); count++
                    }
                }
                "uc" -> {
                    val c = obj.optString("cookie")
                    if (c.isNotBlank()) {
                        ucDao.upsert(
                            UCAccountEntity(
                                id = "uc", cookie = c,
                                nickname = obj.optString("nickname"),
                                updatedAt = obj.optLong("updatedAt", System.currentTimeMillis())
                            )
                        ); count++
                    }
                }
                "xunlei" -> {
                    val t = obj.optString("accessToken")
                    if (t.isNotBlank()) {
                        xunleiDao.upsert(
                            XunleiAccountEntity(
                                id = "xunlei", accessToken = t,
                                refreshToken = obj.optString("refreshToken"),
                                deviceId = obj.optString("deviceId"),
                                captchaToken = obj.optString("captchaToken"),
                                nickname = obj.optString("nickname"),
                                authType = obj.optString("authType"),
                                updatedAt = obj.optLong("updatedAt", System.currentTimeMillis())
                            )
                        ); count++
                    }
                }
                "baidu" -> {
                    val c = obj.optString("cookie")
                    if (c.isNotBlank()) {
                        baiduDao.upsert(
                            BaiduAccountEntity(
                                id = "baidu", cookie = c,
                                nickname = obj.optString("nickname"),
                                updatedAt = obj.optLong("updatedAt", System.currentTimeMillis())
                            )
                        ); count++
                    }
                }
                "c139" -> {
                    val c = obj.optString("cookie")
                    if (c.isNotBlank()) {
                        c139Dao.upsert(
                            C139AccountEntity(
                                id = "c139", cookie = c,
                                authorization = obj.optString("authorization"),
                                nickname = obj.optString("nickname"),
                                updatedAt = obj.optLong("updatedAt", System.currentTimeMillis())
                            )
                        ); count++
                    }
                }
                "pan123" -> {
                    val t = obj.optString("accessToken")
                    if (t.isNotBlank()) {
                        pan123Dao.upsert(
                            Pan123AccountEntity(
                                id = "pan123", accessToken = t,
                                account = obj.optString("account"),
                                nickname = obj.optString("nickname"),
                                updatedAt = obj.optLong("updatedAt", System.currentTimeMillis())
                            )
                        ); count++
                    }
                }
                "pan115" -> {
                    val c = obj.optString("cookie")
                    if (c.isNotBlank()) {
                        pan115Dao.upsert(
                            Pan115AccountEntity(
                                id = "pan115", cookie = c,
                                nickname = obj.optString("nickname"),
                                updatedAt = obj.optLong("updatedAt", System.currentTimeMillis())
                            )
                        ); count++
                    }
                }
                "guangya" -> {
                    val t = obj.optString("accessToken")
                    if (t.isNotBlank()) {
                        guangyaDao.upsert(
                            GuangYaAccountEntity(
                                id = "guangya", accessToken = t,
                                refreshToken = obj.optString("refreshToken"),
                                deviceId = obj.optString("deviceId"),
                                deviceSign = obj.optString("deviceSign"),
                                account = obj.optString("account"),
                                nickname = obj.optString("nickname"),
                                updatedAt = obj.optLong("updatedAt", System.currentTimeMillis())
                            )
                        ); count++
                    }
                }
                "ilanzou" -> {
                    val t = obj.optString("appToken")
                    if (t.isNotBlank()) {
                        ilanzouDao.upsert(
                            ILanzouAccountEntity(
                                id = "ilanzou", appToken = t,
                                uuid = obj.optString("uuid"),
                                account = obj.optString("account"),
                                password = obj.optString("password"),
                                userId = obj.optString("userId"),
                                nickname = obj.optString("nickname"),
                                updatedAt = obj.optLong("updatedAt", System.currentTimeMillis())
                            )
                        ); count++
                    }
                }
                "lanzou" -> {
                    val c = obj.optString("cookie")
                    if (c.isNotBlank()) {
                        lanzouDao.upsert(
                            LanzouAccountEntity(
                                id = "lanzou", cookie = c,
                                nickname = obj.optString("nickname"),
                                updatedAt = obj.optLong("updatedAt", System.currentTimeMillis())
                            )
                        ); count++
                    }
                }
            }
        }
        // GitHub Token：顶层字段恢复。单独 runCatching 包住，失败不阻断其余账号导入；
        // 旧备份无该字段时 optString 返回空串，跳过——**不清除**设备上现有 Token（避免导入旧备份误清）。
        runCatching {
            val ghToken = root.optString("githubToken", "")
            if (ghToken.isNotBlank()) {
                GitHubTokenStore.setToken(context, ghToken)
                count++
            }
        }
        count
    }

    /**
     * 把备份内容保存到公共下载目录（Android 10+ 走 MediaStore 无需权限）。
     * @param encrypted true 时文件名为 .yunx（加密备份），否则 .json（明文）
     */
    suspend fun saveToDownloads(context: Context, content: String, encrypted: Boolean = false): Boolean =
        withContext(Dispatchers.IO) {
            runCatching {
                val fileName = if (encrypted) {
                    "yunx_auth_backup_${timestamp()}.yunx"
                } else {
                    "yunx_auth_backup_${timestamp()}.json"
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val values = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, fileName)
                        put(
                            MediaStore.Downloads.MIME_TYPE,
                            if (encrypted) "application/octet-stream" else "application/json"
                        )
                        put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                    }
                    val uri: Uri = context.contentResolver
                        .insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                        ?: return@runCatching false
                    context.contentResolver.openOutputStream(uri)?.use { out ->
                        out.write(content.toByteArray(Charsets.UTF_8))
                    } ?: return@runCatching false
                    true
                } else {
                    val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    if (!dir.exists()) dir.mkdirs()
                    val file = File(dir, fileName)
                    FileOutputStream(file).use { it.write(content.toByteArray(Charsets.UTF_8)) }
                    true
                }
            }.getOrDefault(false)
        }

    private fun timestamp(): String =
        SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
}
