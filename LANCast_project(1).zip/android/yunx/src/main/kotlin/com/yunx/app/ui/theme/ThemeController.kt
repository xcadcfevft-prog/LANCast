/*
 * YunX (云析) - A network drive share-link parser and high-speed downloader for Android.
 * Copyright (C) 2026 CYQawa
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.yunx.app.ui.theme

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.yunx.app.data.prefs.SettingsRepository

/**
 * 主题与显示设置控制器（单例）：
 * - 内存中持有主题设置与「列表缩略图」这类纯显示开关（mutableStateOf），修改后 Compose 自动重组；
 * - 读写同时同步 SharedPreferences 持久化；
 * - 由 ComposeEmptyActivityTheme 初始化（幂等），确保任何入口（主界面/崩溃页）都能读到。
 */
object ThemeController {

    /** 深色模式：0=跟随系统，1=浅色，2=深色 */
    var darkMode by mutableStateOf(0)
        private set

    /** 主题色模式：0=动态色彩，1=默认蓝色，2=自定义种子色 */
    var colorMode by mutableStateOf(0)
        private set

    /** 自定义主题种子色（ARGB） */
    var seedColor by mutableStateOf(SettingsRepository.DEFAULT_SEED_COLOR)
        private set

    /** 文件名显示方式：false=单行跑马灯滚动（默认），true=多行折行显示 */
    var fileNameMultiLine by mutableStateOf(false)
        private set

    /**
     * 列表缩略图：网盘/分享文件列表里给图片显示小图（默认开启）。
     * 关掉后列表行退回文件图标，**不发任何取图请求**（见 `ShareFileRow` / `FileThumbnail`）。
     */
    var cloudThumbnails by mutableStateOf(true)
        private set

    /** 自动识别剪贴板分享链接：关闭后不再读取剪贴板（默认开启） */
    var clipboardSuggestEnabled by mutableStateOf(true)
        private set

    /** 接受预发布版更新：检查更新时包含 GitHub Pre-release（默认关闭） */
    var acceptPrereleaseUpdate by mutableStateOf(false)
        private set

    /** 下载调试：开启后下载页长按任务可查看「调试信息」（默认关闭；关闭会清空全部调试日志） */
    var downloadDebug by mutableStateOf(false)
        private set

    private var initialized = false

    /** 从持久化存储加载（幂等；首次调用有效） */
    fun init(context: Context) {
        if (initialized) return
        val s = SettingsRepository(context)
        darkMode = s.darkMode
        colorMode = s.themeColorMode
        seedColor = s.themeSeedColor
        fileNameMultiLine = s.fileNameMultiLine
        cloudThumbnails = s.cloudThumbnails
        clipboardSuggestEnabled = s.clipboardSuggestEnabled
        acceptPrereleaseUpdate = s.acceptPrereleaseUpdate
        downloadDebug = s.downloadDebug
        initialized = true
    }

    /** 设置深色模式并持久化 */
    fun setDarkMode(context: Context, value: Int) {
        darkMode = value.coerceIn(0, 2)
        SettingsRepository(context).darkMode = darkMode
    }

    /** 设置主题色模式并持久化（0=动态 / 1=默认 / 2=自定义） */
    fun setColorMode(context: Context, value: Int) {
        colorMode = value.coerceIn(0, 2)
        SettingsRepository(context).themeColorMode = colorMode
    }

    /** 设置自定义种子色（自动切到自定义模式）并持久化 */
    fun setSeedColor(context: Context, argb: Long) {
        seedColor = argb
        colorMode = 2
        SettingsRepository(context).apply {
            themeSeedColor = argb
            themeColorMode = 2
        }
    }

    /** 设置文件名显示方式并持久化（true=多行折行，false=单行跑马灯） */
    fun setFileNameMultiLine(context: Context, value: Boolean) {
        fileNameMultiLine = value
        SettingsRepository(context).fileNameMultiLine = value
    }

    /** 设置列表缩略图开关并持久化（关掉后列表立刻退回文件图标） */
    fun setCloudThumbnails(context: Context, value: Boolean) {
        cloudThumbnails = value
        SettingsRepository(context).cloudThumbnails = value
    }

    /** 设置是否自动识别剪贴板分享链接并持久化 */
    fun setClipboardSuggestEnabled(context: Context, value: Boolean) {
        clipboardSuggestEnabled = value
        SettingsRepository(context).clipboardSuggestEnabled = value
    }

    /** 设置是否接受预发布版更新并持久化 */
    fun setAcceptPrereleaseUpdate(context: Context, value: Boolean) {
        acceptPrereleaseUpdate = value
        SettingsRepository(context).acceptPrereleaseUpdate = value
    }

    /**
     * 设置下载调试开关并持久化。**关闭会清空全部调试日志**，所以清空与提示由调用方负责
     * （设置页关开关前会先弹二次确认，确认后调用 `DownloadDebugLog.setEnabled`）。
     */
    fun setDownloadDebug(context: Context, value: Boolean) {
        downloadDebug = value
        SettingsRepository(context).downloadDebug = value
    }
}
