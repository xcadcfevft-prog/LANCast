/*
 * YunX (云析) - A network drive share-link parser and high-speed downloader for Android.
 * Copyright (C) 2026 CYQawa
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.yunx.app.ui

import com.yunx.app.ui.theme.useNavigationRail
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.ExperimentalSharedTransitionApi
import androidx.compose.animation.SharedTransitionLayout
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Bookmarks
import androidx.compose.material.icons.outlined.Campaign
import androidx.compose.material.icons.outlined.SwapVert
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.VisibilityOff
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MediumFlexibleTopAppBar
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.ShortNavigationBar
import androidx.compose.material3.ShortNavigationBarDefaults
import androidx.compose.material3.ShortNavigationBarItem
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberTopAppBarState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.yunx.app.data.db.AppDatabase
import com.yunx.app.data.download.ChunkDownloader
import com.yunx.app.data.download.DownloadManager
import com.yunx.app.data.download.DownloadPlatform
import com.yunx.app.data.backup.AuthBackupManager
import com.yunx.app.data.network.BaiduApi
import com.yunx.app.data.network.C139Api
import com.yunx.app.data.network.C139DeviceInfo
import com.yunx.app.data.network.GitHubApi
import com.yunx.app.data.network.GitHubLinkParser
import com.yunx.app.data.network.GitHubTokenStore
import com.yunx.app.data.network.GuangYaApi
import com.yunx.app.data.network.ILanzouApi
import com.yunx.app.data.network.LanzouApi
import com.yunx.app.data.network.Pan115Api
import com.yunx.app.data.network.Pan123Api
import com.yunx.app.data.network.QuarkApi
import com.yunx.app.data.network.TokenCheck
import com.yunx.app.data.network.UCApi
import com.yunx.app.data.network.XunleiApi
import com.yunx.app.data.network.video.VideoPlatform
import com.yunx.app.data.prefs.SettingsRepository
import com.yunx.app.data.repository.AccountDirectory
import com.yunx.app.data.repository.BaiduAccountRepository
import com.yunx.app.data.repository.BaiduResolveRepository
import com.yunx.app.data.repository.C139AccountRepository
import com.yunx.app.data.repository.C139ResolveRepository
import com.yunx.app.data.repository.GuangYaAccountRepository
import com.yunx.app.data.repository.GuangYaResolveRepository
import com.yunx.app.data.repository.ILanzouAccountRepository
import com.yunx.app.data.repository.ILanzouResolveRepository
import com.yunx.app.data.repository.LanzouAccountRepository
import com.yunx.app.data.repository.LanzouResolveRepository
import com.yunx.app.data.repository.Pan115AccountRepository
import com.yunx.app.data.repository.Pan115ResolveRepository
import com.yunx.app.data.repository.Pan123AccountRepository
import com.yunx.app.data.repository.Pan123ResolveRepository
import com.yunx.app.data.repository.QuarkAccountRepository
import com.yunx.app.data.repository.QuarkResolveRepository
import com.yunx.app.data.repository.UCAccountRepository
import com.yunx.app.data.repository.UCResolveRepository
import com.yunx.app.data.repository.XunleiAccountRepository
import com.yunx.app.data.repository.XunleiResolveRepository
import com.yunx.app.data.repository.VideoAccountRepository
import com.yunx.app.data.repository.VideoParseRepository
import com.yunx.app.ui.login.BaiduLoginScreen
import com.yunx.app.ui.login.C139LoginScreen
import com.yunx.app.ui.login.GuangYaLoginScreen
import com.yunx.app.ui.login.ILanzouLoginScreen
import com.yunx.app.ui.login.LanzouLoginScreen
import com.yunx.app.ui.login.Pan115LoginScreen
import com.yunx.app.ui.login.Pan123LoginScreen
import com.yunx.app.ui.login.QuarkLoginScreen
import com.yunx.app.ui.login.UCLoginScreen
import com.yunx.app.ui.login.XunleiLoginScreen
import com.yunx.app.ui.login.XunleiVerifyWebViewScreen
import com.yunx.app.ui.login.XunleiWebLoginScreen
import com.yunx.app.ui.login.VideoLoginScreen
import com.yunx.app.ui.navigation.MainTab
import com.yunx.app.ui.preview.MediaPreviewScreen
import com.yunx.app.ui.preview.PreviewLauncher
import com.yunx.app.ui.screens.AboutScreen
import com.yunx.app.ui.screens.BookmarkScreen
import com.yunx.app.ui.screens.DownloadScreen
import com.yunx.app.ui.screens.DriveScreen
import com.yunx.app.ui.screens.DownloadEngineScreen
import com.yunx.app.ui.screens.LinkOpenScreen
import com.yunx.app.ui.screens.MultiAccountDownloadScreen
import com.yunx.app.ui.screens.OnboardingScreen
import com.yunx.app.ui.screens.ResolveScreen
import com.yunx.app.ui.screens.SettingsScreen
import com.yunx.app.ui.screens.ThemeScreen
import com.yunx.app.ui.viewmodel.BaiduAccountViewModel
import com.yunx.app.ui.viewmodel.BaiduCloudViewModel
import com.yunx.app.ui.viewmodel.BookmarkViewModel
import com.yunx.app.ui.viewmodel.C139AccountViewModel
import com.yunx.app.ui.viewmodel.C139CloudViewModel
import com.yunx.app.ui.viewmodel.GuangYaAccountViewModel
import com.yunx.app.ui.viewmodel.GuangYaCloudViewModel
import com.yunx.app.ui.viewmodel.ILanzouAccountViewModel
import com.yunx.app.ui.viewmodel.ILanzouCloudViewModel
import com.yunx.app.ui.viewmodel.LanzouAccountViewModel
import com.yunx.app.ui.viewmodel.LanzouCloudViewModel
import com.yunx.app.ui.viewmodel.DownloadViewModel
import com.yunx.app.ui.viewmodel.DriveQuotaViewModel
import com.yunx.app.ui.viewmodel.MultiAccountViewModel
import com.yunx.app.ui.viewmodel.Pan115AccountViewModel
import com.yunx.app.ui.viewmodel.Pan115CloudViewModel
import com.yunx.app.ui.viewmodel.Pan123AccountViewModel
import com.yunx.app.ui.viewmodel.Pan123CloudViewModel
import com.yunx.app.ui.viewmodel.QuarkAccountViewModel
import com.yunx.app.ui.viewmodel.QuarkCloudViewModel
import com.yunx.app.ui.viewmodel.ResolveViewModel
import com.yunx.app.ui.viewmodel.UCCoudViewModel
import com.yunx.app.ui.viewmodel.UCAccountViewModel
import com.yunx.app.ui.viewmodel.XunleiAccountViewModel
import com.yunx.app.ui.viewmodel.XunleiCloudViewModel
import com.yunx.app.ui.viewmodel.VideoAccountViewModel
import com.yunx.app.util.AppLinks
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.yunx.app.data.network.HttpClients
import com.yunx.app.ui.theme.ThemeController
import com.yunx.app.ui.theme.effectsDefault
import com.yunx.app.ui.theme.effectsFast

/**
 * 容器变换的共享 key：源（设置页那一行）与目标（叠加页）必须用同一个 key，形变才会发生。
 * 两处都在本文件里构造（源侧修饰符见 MainScreen 里 themeRowModifier 等，目标侧见 OverlayPage 的调用处）。
 */
internal const val OVERLAY_KEY_ABOUT = "overlay-about"
internal const val OVERLAY_KEY_THEME = "overlay-theme"

/** 收藏页从顶栏图标进入，没有"被点的那一项"，不做共享元素形变（普通淡入即可） */
internal const val OVERLAY_KEY_BOOKMARKS = "overlay-bookmarks"

/** Gopeed 引擎页从设置页那一行进入，同样没有共享元素形变（普通淡入即可） */
internal const val OVERLAY_KEY_GOPEED = "overlay-gopeed"

/** 公告页：源是顶栏那个公告图标（与收藏页同一手法 —— 图标本身当"源"，长成整页） */

/** 链接唤起（深链接注册项）设置页：从设置页那一行进入，整行长成整页 */
internal const val OVERLAY_KEY_LINK_OPEN = "overlay-link-open"

/** 多账号下载（两个实验性开关）设置页：从设置页那一行进入 */
internal const val OVERLAY_KEY_MULTI_ACCOUNT = "overlay-multi-account"

/**
 * 主页框架：
 * - 顶部可折叠标题（MediumFlexibleTopAppBar，Expressive 柔性顶栏），切换 Tab 时标题文字随 Tab 变化，折叠状态不受影响；
 * - 导航 Tab（解析 / 账号 / 下载 / 设置）：竖屏为底部导航条（ShortNavigationBar），横屏切换为侧边导航栏（NavigationRail）；
 * - 通过 SaveableStateHolder 保存各页面状态，切换 Tab 再切回来不会重置；
 * - 各平台登录页（含视频平台的通用 WebView 登录页）全屏覆盖展示。
 */
@OptIn(
    ExperimentalMaterial3Api::class,
    ExperimentalMaterial3ExpressiveApi::class,
    ExperimentalSharedTransitionApi::class
)
@Composable
fun MainScreen(
    /** 外部来源请求直接打开的 Tab（如点击实况通知 → 下载页）；null = 用默认「解析」页 */
    openTab: MainTab? = null,
    /** [openTab] 被消费后回调：调用方负责清空它，避免旋转/重组时重复切页 */
    onOpenTabConsumed: () -> Unit = {},
    /** 深链接 / 外部分享拿到的待解析文本（分享链接、中文口令、带链接的文案都行）；null = 没有 */
    incomingLink: String? = null,
    /** [incomingLink] 被解析页接手后回调（调用方清空，避免重组时重复解析） */
    onIncomingLinkConsumed: () -> Unit = {},
    /** 深链接拿到的直链 / 磁力：走下载页「添加下载任务」弹窗预填（磁力只有 Gopeed 引擎能下，不能走解析链路） */
    incomingAddUrl: String? = null,
    /** [incomingAddUrl] 被下载页接手后回调 */
    onIncomingAddUrlConsumed: () -> Unit = {}
) {
    var currentTab by rememberSaveable { mutableStateOf(MainTab.Resolve) }

    // 账号页顶栏「排序」：弹窗和网盘列表都在 DriveScreen，但入口按钮画在全局顶栏，
    // 所以开关状态提升到本层（弹窗内容由 DriveScreen 渲染）。
    var showDriveSort by rememberSaveable { mutableStateOf(false) }
    // 账号页是否正停在某个网盘的浏览子页：子页打开时隐藏「排序」按钮（它只属于账号列表）
    var driveSubPageOpen by rememberSaveable { mutableStateOf(false) }

    // 实况通知等外部来源请求切 Tab：读一次即消费（清空由调用方做）
    LaunchedEffect(openTab) {
        if (openTab != null) {
            currentTab = openTab
            onOpenTabConsumed()
        }
    }
    var showQuarkLogin by rememberSaveable { mutableStateOf(false) }
    var showUCLogin by rememberSaveable { mutableStateOf(false) }
    var showXunleiLogin by rememberSaveable { mutableStateOf(false) }
    var showXunleiWebLogin by rememberSaveable { mutableStateOf(false) }
    var showXunleiVerify by rememberSaveable { mutableStateOf(false) }
    var xunleiVerifyUrl by rememberSaveable { mutableStateOf("") }
    var xunleiVerifyDeviceId by rememberSaveable { mutableStateOf("") }
    var showBaiduLogin by rememberSaveable { mutableStateOf(false) }
    var showC139Login by rememberSaveable { mutableStateOf(false) }
    var showPan123Login by rememberSaveable { mutableStateOf(false) }
    var showPan115Login by rememberSaveable { mutableStateOf(false) }
    var showGuangYaLogin by rememberSaveable { mutableStateOf(false) }
    var showILanzouLogin by rememberSaveable { mutableStateOf(false) }
    var showLanzouLogin by rememberSaveable { mutableStateOf(false) }
    // 视频平台登录页：null = 不展示；否则为正在登录的平台（枚举是 Serializable，可直接交给 rememberSaveable）
    var videoLoginPlatform by rememberSaveable { mutableStateOf<VideoPlatform?>(null) }
    // 本次视频登录是否算「新增账号」（账号弹窗点「添加账号」时为 true，登录后落成新的一行）
    var videoLoginAsNewAccount by rememberSaveable { mutableStateOf(false) }
    var showAbout by rememberSaveable { mutableStateOf(false) }
    var showTheme by rememberSaveable { mutableStateOf(false) }
    var showLinkOpen by rememberSaveable { mutableStateOf(false) }
    var showMultiAccountDownload by rememberSaveable { mutableStateOf(false) }
    var showBookmarks by rememberSaveable { mutableStateOf(false) }
    var showGopeed by rememberSaveable { mutableStateOf(false) }
    val saveableStateHolder = rememberSaveableStateHolder()

    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    // 按可用窗口宽高选择导航，支持分屏与平板窗口
    val windowConfiguration = LocalConfiguration.current
    val useRail = useNavigationRail(windowConfiguration.screenWidthDp, windowConfiguration.screenHeightDp)
    // 首次启动引导页（context 声明后检测）
    var showOnboarding by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        val prefs = context.getSharedPreferences("yunx_prefs", android.content.Context.MODE_PRIVATE)
        showOnboarding = !prefs.getBoolean("onboarding_shown", false)
    }



    val api = remember { QuarkApi() }
    val ucApi = remember { UCApi() }
    val xunleiApi = remember { XunleiApi() }
    val baiduApi = remember { BaiduApi() }
    val appContext = context.applicationContext
    val c139Api = remember(appContext) {
        C139Api(deviceInfoProvider = { C139DeviceInfo.from(appContext) })
    }
    val pan123Api = remember { Pan123Api() }
    val pan115Api = remember { Pan115Api() }
    val guangyaApi = remember { GuangYaApi() }
    val ilanzouApi = remember { ILanzouApi() }
    val lanzouApi = remember { LanzouApi() }
    val db = remember { AppDatabase.get(context) }

    val settings = remember { SettingsRepository(context) }
    val repository = remember {
        QuarkAccountRepository(db.quarkAccountDao(), api)
    }
    val ucRepository = remember {
        UCAccountRepository(db.ucAccountDao(), ucApi)
    }
    val xunleiRepository = remember {
        XunleiAccountRepository(db.xunleiAccountDao(), xunleiApi)
    }
    val baiduRepository = remember {
        BaiduAccountRepository(db.baiduAccountDao(), baiduApi)
    }
    val c139Repository = remember {
        C139AccountRepository(db.c139AccountDao())
    }
    val pan123Repository = remember {
        Pan123AccountRepository(db.pan123AccountDao(), pan123Api)
    }
    val pan115Repository = remember {
        Pan115AccountRepository(db.pan115AccountDao(), pan115Api)
    }
    val guangyaRepository = remember {
        GuangYaAccountRepository(db.guangyaAccountDao(), guangyaApi)
    }
    // 光鸭业务 API（个人盘 / 分享）必须带 did 设备头：从仓库缓存的 deviceId 同步注入
    guangyaApi.deviceIdProvider = { guangyaRepository.cachedDeviceId() }
    val ilanzouRepository = remember {
        ILanzouAccountRepository(db.ilanzouAccountDao(), ilanzouApi)
    }
    val lanzouRepository = remember {
        LanzouAccountRepository(db.lanzouAccountDao(), lanzouApi)
    }
    // 认证备份：打包/恢复各平台凭证（网盘 + 视频解析平台）
    val backupManager = remember {
        AuthBackupManager(
            db.quarkAccountDao(),
            db.ucAccountDao(),
            db.xunleiAccountDao(),
            db.baiduAccountDao(),
            db.c139AccountDao(),
            db.pan123AccountDao(),
            db.pan115AccountDao(),
            db.guangyaAccountDao(),
            db.ilanzouAccountDao(),
            db.lanzouAccountDao(),
            db.videoAccountDao()
        )
    }
    // GitHub API 封装：Token 从 GitHubTokenStore 动态读取（Keystore 加密），提升 API 限额
    val githubApi = remember {
        GitHubApi(tokenProvider = { GitHubTokenStore.getToken(context) })
    }
    // 网盘页 GitHub 卡片登录态：保存/清除 Token 后即时刷新卡片主按钮文案
    var githubHasTokenState by remember { mutableStateOf(GitHubTokenStore.hasToken(context)) }
    // 无效 Token 会被 GitHub 全量拒绝（401，连公开仓库解析也失败）：自动清除 Token、清空缓存并提示
    LaunchedEffect(githubApi) {
        githubApi.onUnauthorized = {
            scope.launch {
                GitHubTokenStore.setToken(context, null)
                githubHasTokenState = false
                SnackbarController.show("GitHub Token 无效或已过期，已自动清除并回退匿名限额，请重新配置")
            }
        }
    }
    // GitHub Token 配置弹窗 / 清除二次确认
    var showGitHubTokenDialog by remember { mutableStateOf(false) }
    var showGitHubClearConfirm by remember { mutableStateOf(false) }
    // 下载管理器：OkHttp 分片下载器 + Room 任务持久化 + 可配置线程数（设置页动态生效）
    // 下载客户端由全局 HttpClients 统一管理（大 Dispatcher 保障分片并发，不锁死 CDN host；
    // 并支持隐藏菜单「忽略 SSL 证书」开关，抓包调试时即时生效，无需重启）
    val downloadManager = remember {
        DownloadManager(
            context = context,
            dao = db.downloadTaskDao(),
            downloader = ChunkDownloader({ HttpClients.downloadClient() }),
            threadProvider = { platform -> settings.downloadThreadsFor(platform) },
            // 自定义下载保存目录（SAF tree Uri），设置页可选，动态生效
            saveDirProvider = { settings.downloadDirUri },
            // 网络与下载策略（设置页可调，动态生效）：并发任务数 / 全局限速 / 失败重试
            concurrencyProvider = { settings.maxConcurrentDownloads },
            speedLimitProvider = { settings.downloadSpeedLimit },
            retryCountProvider = { settings.downloadRetryCount },
            // 锁屏保持下载 / 通知栏速度开关
            keepWhenLockedProvider = { settings.keepDownloadWhenLocked },
            showSpeedProvider = { settings.notificationShowSpeed }
        )
    }
    // Android 9- 写公共 Download 需要 WRITE_EXTERNAL_STORAGE 运行时授权：
    // 下载完成保存前由 DownloadManager.storagePermissionProvider 触发动态申请，授权后自动继续保存
    var pendingStoragePermission by remember { mutableStateOf<CompletableDeferred<Boolean>?>(null) }
    val storagePermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        pendingStoragePermission?.complete(granted)
        pendingStoragePermission = null
    }
    downloadManager.storagePermissionProvider = {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            true // Android 10+ MediaStore 无需存储权限
        } else if (ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
            true
        } else {
            val deferred = CompletableDeferred<Boolean>()
            pendingStoragePermission = deferred
            withContext(Dispatchers.Main) {
                storagePermissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
            }
            deferred.await()
        }
    }
    val viewModel: QuarkAccountViewModel = viewModel(
        factory = QuarkAccountViewModel.Factory(repository)
    )
    val ucViewModel: UCAccountViewModel = viewModel(
        factory = UCAccountViewModel.Factory(ucRepository)
    )
    val xunleiViewModel: XunleiAccountViewModel = viewModel(
        factory = XunleiAccountViewModel.Factory(xunleiRepository)
    )
    val baiduViewModel: BaiduAccountViewModel = viewModel(
        factory = BaiduAccountViewModel.Factory(baiduRepository)
    )
    val c139ViewModel: C139AccountViewModel = viewModel(
        factory = C139AccountViewModel.Factory(c139Repository)
    )
    val pan123ViewModel: Pan123AccountViewModel = viewModel(
        factory = Pan123AccountViewModel.Factory(pan123Repository)
    )
    val pan115ViewModel: Pan115AccountViewModel = viewModel(
        factory = Pan115AccountViewModel.Factory(pan115Repository)
    )
    val guangyaViewModel: GuangYaAccountViewModel = viewModel(
        factory = GuangYaAccountViewModel.Factory(guangyaRepository)
    )
    val ilanzouViewModel: ILanzouAccountViewModel = viewModel(
        factory = ILanzouAccountViewModel.Factory(ilanzouRepository)
    )
    val lanzouViewModel: LanzouAccountViewModel = viewModel(
        factory = LanzouAccountViewModel.Factory(lanzouRepository)
    )
    // 多账号：账号列表 / 设主账号 / 改备注 / 退出 的统一入口
    // （这四件事对 10 个平台同构，见 AccountDirectory；平台专属的凭证读写仍在各平台仓库里）
    val multiAccountViewModel: MultiAccountViewModel = viewModel(
        factory = MultiAccountViewModel.Factory(AccountDirectory(db))
    )
    // 视频解析账号：账号页「视频解析」区的登录态与账号管理（所有视频平台共用一张表、一个 Cookie）
    val videoAccountViewModel: VideoAccountViewModel = viewModel(
        factory = VideoAccountViewModel.Factory(context)
    )
    // 视频区需要的两份数据：各平台当前账号（决定「未登录 / 昵称 / 备注」）与全部账号（多账号计数、弹窗列表）
    val videoLoginState by videoAccountViewModel.loginState.collectAsState()
    val videoAccounts by videoAccountViewModel.accounts.collectAsState()
    // 各平台「账号是否已登录」流：云盘浏览 VM 在启动期（未登录）init 加载会残留「请先登录…」错误态，
    // 首次登录成功后由 VM 监听该流自动重载根目录（见各 XxxCloudViewModel init）
    val quarkLoginState = remember { repository.observeAccount().map { it != null } }
    val ucLoginState = remember { ucRepository.observeAccount().map { it != null } }
    val xunleiLoginState = remember { xunleiRepository.observeAccount().map { it != null } }
    val baiduLoginState = remember { baiduRepository.observeAccount().map { it != null } }
    val c139LoginState = remember { c139Repository.observeAccount().map { it != null } }
    val pan123LoginState = remember { pan123Repository.observeAccount().map { it != null } }
    val pan115LoginState = remember { pan115Repository.observeAccount().map { it != null } }
    val guangyaLoginState = remember { guangyaRepository.observeAccount().map { it != null } }
    val ilanzouLoginState = remember { ilanzouRepository.observeAccount().map { it != null } }
    val lanzouLoginState = remember { lanzouRepository.observeAccount().map { it != null } }
    // 夸克云盘浏览：作为网盘 Tab 内容展示（非全屏），cookie 从数据库读取（避免 StateFlow 初始值为空的竞态）；
    // 下载前经 getFreshCookie 惰性刷新 __puus（修复 AlistGo/alist#830 下载 412）
    val quarkCloudViewModel: QuarkCloudViewModel = viewModel(
        factory = QuarkCloudViewModel.Factory(
            api,
            { repository.getFreshCookie() },
            downloadManager,
            loginState = quarkLoginState
        )
    )
    // UC 网盘云盘浏览：点击已登录的 UC 卡片打开（cookie 从数据库读取）；
    // 取链前经 getFreshCookie 惰性刷新 __puus（与夸克同源，修复取链/直链过期失败）
    val ucCloudViewModel: UCCoudViewModel = viewModel(
        factory = UCCoudViewModel.Factory(
            ucApi,
            { ucRepository.getFreshCookie() },
            downloadManager,
            loginState = ucLoginState
        )
    )
    // 迅雷 access_token 过期（401 unauthenticated）自动刷新：refresh_token 换新并持久化（对齐官方 /v1/auth/token 抓包）
    xunleiApi.refreshTokenProvider = { deviceId ->
        val acc = xunleiRepository.getAccount()
        if (acc == null || acc.refreshToken.isBlank()) null
        else xunleiApi.refreshToken(acc.refreshToken, deviceId, acc.authType)?.also { (at, nrt) ->
            xunleiRepository.updateTokens(at, nrt)
        }
    }
    // 网页登录的 captcha：本地 9 盐签名现换（快、后台可用），签名被拒才回退网页会话
    xunleiApi.webCaptchaRefresher = { deviceId, action ->
        xunleiRepository.refreshWebCaptcha(deviceId, action)
    }
    // 迅雷云盘浏览：点击已登录的迅雷卡片打开（access_token/设备指纹/captcha 从数据库读取）
    val xunleiCloudViewModel: XunleiCloudViewModel = viewModel(
        factory = XunleiCloudViewModel.Factory(
            xunleiApi,
            { xunleiRepository.getAccount()?.accessToken },
            { xunleiRepository.getAccount()?.deviceId },
            { xunleiRepository.getAccount()?.captchaToken },
            downloadManager,
            loginState = xunleiLoginState
        )
    )
    // 百度网盘云盘浏览：点击已登录的百度卡片打开（cookie 从数据库读取）
    val baiduCloudViewModel: BaiduCloudViewModel = viewModel(
        factory = BaiduCloudViewModel.Factory(
            baiduApi,
            { baiduRepository.getAccount()?.cookie },
            downloadManager,
            loginState = baiduLoginState
        )
    )
    // 139 网盘云盘浏览：点击已登录的 139 卡片打开（cookie 从数据库读取）
    val c139CloudViewModel: C139CloudViewModel = viewModel(
        factory = C139CloudViewModel.Factory(
            c139Api,
            { c139Repository.getAccount()?.cookie },
            downloadManager,
            loginState = c139LoginState
        )
    )
    // 123 云盘浏览：点击已登录的 123 卡片打开（token 从数据库读取）
    val pan123CloudViewModel: Pan123CloudViewModel = viewModel(
        factory = Pan123CloudViewModel.Factory(
            pan123Api,
            { pan123Repository.getAccount()?.accessToken },
            downloadManager,
            loginState = pan123LoginState
        )
    )
    // 115 网盘浏览：点击已登录的 115 卡片打开（Cookie 从数据库读取）
    val pan115CloudViewModel: Pan115CloudViewModel = viewModel(
        factory = Pan115CloudViewModel.Factory(
            pan115Api,
            { pan115Repository.getAccount()?.cookie },
            downloadManager,
            loginState = pan115LoginState
        )
    )
    // 光鸭云盘浏览：点击已登录的光鸭卡片打开（access token / 设备标识从数据库读取）
    val guangyaCloudViewModel: GuangYaCloudViewModel = viewModel(
        factory = GuangYaCloudViewModel.Factory(
            guangyaApi,
            guangyaRepository,
            downloadManager,
            loginState = guangyaLoginState
        )
    )
    // 蓝奏云优享版浏览：点击已登录的蓝奏优享卡片打开（appToken + uuid 从数据库读取）
    val ilanzouCloudViewModel: ILanzouCloudViewModel = viewModel(
        factory = ILanzouCloudViewModel.Factory(
            ilanzouApi,
            ilanzouRepository,
            downloadManager,
            loginState = ilanzouLoginState
        )
    )
    // 蓝奏云浏览：点击已登录的蓝奏云卡片打开（Cookie 从数据库读取）
    val lanzouCloudViewModel: LanzouCloudViewModel = viewModel(
        factory = LanzouCloudViewModel.Factory(
            lanzouApi,
            lanzouRepository,
            downloadManager,
            loginState = lanzouLoginState
        )
    )
    // 网盘空间详情：网盘页顶部「空间总览」展示各平台容量使用
    val driveQuotaViewModel: DriveQuotaViewModel = viewModel(
        factory = DriveQuotaViewModel.Factory(
            api, { repository.getAccount()?.cookie },
            ucApi, { ucRepository.getAccount()?.cookie },
            xunleiApi,
            { xunleiRepository.getAccount()?.accessToken },
            { xunleiRepository.getAccount()?.deviceId },
            { xunleiRepository.getAccount()?.captchaToken },
            baiduApi, { baiduRepository.getAccount()?.cookie },
            c139Api, { c139Repository.getAccount()?.cookie },
            pan123Api, { pan123Repository.getAccount()?.accessToken },
            pan115Api, { pan115Repository.getAccount()?.cookie },
            guangyaApi, { guangyaRepository.getAccount() },
            ilanzouApi, { ilanzouRepository.getAccount() }
        )
    )
    val xunleiResolveRepository = remember {
        XunleiResolveRepository(
            api = xunleiApi,
            accountProvider = { xunleiRepository.getAccount()?.accessToken },
            deviceIdProvider = { xunleiRepository.getAccount()?.deviceId },
            captchaProvider = { xunleiRepository.getAccount()?.captchaToken },
            // token 过期（含导入恢复后旧 token 过期）自动用 refresh_token 刷新并持久化
            refreshProvider = {
                val acc = xunleiRepository.getAccount()
                if (acc == null || acc.refreshToken.isBlank()) null
                else xunleiApi.refreshToken(acc.refreshToken, acc.deviceId, acc.authType)?.also { (at, nrt) ->
                    xunleiRepository.updateTokens(at, nrt)
                }
            },
            // 多账号下载：按 access_token 反查该账号自己的设备指纹与 captcha —— 迅雷的请求
            // 必须「token + 设备号 + captcha」三件套同属一个账号，否则会被拒（见 identityFor）
            accountByTokenProvider = { token ->
                xunleiRepository.getAccounts().firstOrNull { it.accessToken == token }
            }
        )
    }
    val baiduResolveRepository = remember {
        BaiduResolveRepository(baiduApi)
    }
    val c139ResolveRepository = remember {
        C139ResolveRepository(c139Api)
    }
    val pan123ResolveRepository = remember {
        Pan123ResolveRepository(
            api = pan123Api,
            tokenProvider = { pan123Repository.getAccount()?.accessToken }
        )
    }
    val pan115ResolveRepository = remember {
        Pan115ResolveRepository(pan115Api)
    }
    val guangyaResolveRepository = remember {
        GuangYaResolveRepository(
            api = guangyaApi,
            // 转存取链需要有效 access：用 ensureAccessToken（临近过期会先刷新）
            tokenProvider = { guangyaRepository.ensureAccessToken() }
        )
    }
    val lanzouResolveRepository = remember {
        LanzouResolveRepository(lanzouApi)
    }
    val ilanzouResolveRepository = remember {
        ILanzouResolveRepository(ilanzouApi, ilanzouRepository)
    }
    // 视频解析仓库：解析页「视频解析」入口使用（与视频账号页共用同一份 Cookie 账号表）
    val videoParseRepository = remember {
        VideoParseRepository(VideoAccountRepository(db.videoAccountDao()))
    }
    val resolveViewModel: ResolveViewModel = viewModel(
        factory = ResolveViewModel.Factory(
            repository,
            QuarkResolveRepository(api),
            ucRepository,
            UCResolveRepository(ucApi),
            xunleiRepository,
            xunleiResolveRepository,
            baiduRepository,
            baiduResolveRepository,
            c139Repository,
            c139ResolveRepository,
            pan123Repository,
            pan123ResolveRepository,
            pan115Repository,
            pan115ResolveRepository,
            guangyaRepository,
            guangyaResolveRepository,
            ilanzouRepository,
            ilanzouResolveRepository,
            lanzouRepository,
            lanzouResolveRepository,
            downloadManager,
            db.bookmarkDao(),
            githubApi,
            // 取链方式开关：设置页「免转存下载」实时生效
            noSaveDownloadProvider = { settings.quarkNoSaveDownload },
            // 多账号下载 / 单文件多源分片（两个实验性开关）：实时读设置，改完立即生效
            multiAccountDownloadProvider = { settings.multiAccountDownload },
            // 用 multiSourceActive()：C2 依赖 C1，关掉 C1 后这里也自动为 false（见 SettingsRepository）
            multiSourceDownloadProvider = { settings.multiSourceActive() },
            // 视频解析仓库（抖音/小红书/快手/微博/AcFun/B站/Pixiv）
            videoParseRepository = videoParseRepository
        )
    )
    val downloadViewModel: DownloadViewModel = viewModel(
        factory = DownloadViewModel.Factory(downloadManager)
    )
    val bookmarkViewModel: BookmarkViewModel = viewModel(
        factory = BookmarkViewModel.Factory(db.bookmarkDao())
    )
    val quarkAccount by viewModel.quarkAccount.collectAsState()
    val ucAccount by ucViewModel.ucAccount.collectAsState()
    val xunleiAccount by xunleiViewModel.xunleiAccount.collectAsState()
    val baiduAccount by baiduViewModel.baiduAccount.collectAsState()
    val c139Account by c139ViewModel.c139Account.collectAsState()
    val pan123Account by pan123ViewModel.pan123Account.collectAsState()
    val pan115Account by pan115ViewModel.pan115Account.collectAsState()
    val guangyaAccount by guangyaViewModel.guangyaAccount.collectAsState()
    val ilanzouAccount by ilanzouViewModel.ilanzouAccount.collectAsState()
    val lanzouAccount by lanzouViewModel.lanzouAccount.collectAsState()

    // 解析页发起下载后，自动切换到「下载」Tab
    LaunchedEffect(resolveViewModel.downloadStarted) {
        if (resolveViewModel.downloadStarted) {
            currentTab = MainTab.Download
            resolveViewModel.consumeDownloadStarted()
        }
    }

    // 网盘更新无法自动化时，切回「解析」Tab 由用户手动处理
    LaunchedEffect(resolveViewModel.updateFallbackToResolve) {
        if (resolveViewModel.updateFallbackToResolve) {
            currentTab = MainTab.Resolve
            resolveViewModel.consumeUpdateFallbackToResolve()
        }
    }

    // ★ 电池优化引导不再在这里弹：统一收到引导页第 3 页（OnboardingPermissionPage 的「后台运行」卡片），
    //   之后只有设置页「锁屏后保持下载」那一项里的手动入口能再次跳系统设置。

    // 首次启动引导页：全屏覆盖（优先级最高）
    if (showOnboarding) {
        OnboardingScreen(
            onFinish = {
                context.getSharedPreferences("yunx_prefs", android.content.Context.MODE_PRIVATE)
                    .edit()
                    .putBoolean("onboarding_shown", true)
                    .apply()
                showOnboarding = false
            }
        )
        return
    }

    // 夸克登录页：全屏覆盖
    if (showQuarkLogin) {
        QuarkLoginScreen(
            viewModel = viewModel,
            onBack = {
                showQuarkLogin = false
                viewModel.cancelAddAccount()
            },
            onSaved = { showQuarkLogin = false }
        )
        return
    }

    // UC 登录页：全屏覆盖
    if (showUCLogin) {
        UCLoginScreen(
            viewModel = ucViewModel,
            onBack = {
                showUCLogin = false
                ucViewModel.cancelAddAccount()
            },
            onSaved = { showUCLogin = false }
        )
        return
    }

    // 迅雷登录页：全屏覆盖（账号密码 / 短信登录 / 网页登录三个入口）
    if (showXunleiLogin) {
        XunleiLoginScreen(
            viewModel = xunleiViewModel,
            onBack = {
                showXunleiLogin = false
                xunleiViewModel.cancelAddAccount()
            },
            onSaved = { showXunleiLogin = false },
            onVerify = { url, deviceId ->
                // 应用内验证：登录页让位，切到验证 WebView 全屏承载（不再跳外部浏览器）
                xunleiVerifyUrl = url
                xunleiVerifyDeviceId = deviceId
                showXunleiLogin = false
                showXunleiVerify = true
            },
            onWebLogin = {
                // 网页登录：另一套接口，不受 App 通道风控影响，收不到短信时的兜底
                showXunleiLogin = false
                showXunleiWebLogin = true
            }
        )
        return
    }

    // 迅雷网页登录页：全屏覆盖（WebView 打开 pan.xunlei.com，提取 localStorage 的网页凭据）
    if (showXunleiWebLogin) {
        XunleiWebLoginScreen(
            viewModel = xunleiViewModel,
            onBack = {
                showXunleiWebLogin = false
                xunleiViewModel.cancelAddAccount()
            },
            onSaved = { showXunleiWebLogin = false }
        )
        return
    }

    // 迅雷验证页（应用内 WebView 承载验证面板）：全屏覆盖（兜底承载，核心验证仍走自有短信流）
    if (showXunleiVerify) {
        XunleiVerifyWebViewScreen(
            verifyUrl = xunleiVerifyUrl,
            deviceId = xunleiVerifyDeviceId,
            onResult = { success, _ ->
                showXunleiVerify = false
                showXunleiLogin = true // 回到登录页
                if (success) {
                    // 设备已验证受信任：自动重试密码登录（应直接成功并自动关闭登录页）
                    SnackbarController.show("验证完成，正在自动登录…")
                    xunleiViewModel.retryLoginAfterVerify()
                } else {
                    SnackbarController.show("验证未完成，请重试")
                }
            },
            onBack = {
                showXunleiVerify = false
                showXunleiLogin = true // 返回登录页短信步骤
            }
        )
        return
    }

    // 百度登录页：全屏覆盖（WebView 登录提取 Cookie）
    if (showBaiduLogin) {
        BaiduLoginScreen(
            viewModel = baiduViewModel,
            onBack = { showBaiduLogin = false },
            onSaved = { showBaiduLogin = false }
        )
        return
    }

    // 139 登录页：全屏覆盖（WebView 登录提取 Cookie）
    if (showC139Login) {
        C139LoginScreen(
            viewModel = c139ViewModel,
            onBack = {
                showC139Login = false
                c139ViewModel.cancelAddAccount()
            },
            onSaved = { showC139Login = false }
        )
        return
    }

    // 123 登录页：全屏覆盖（WebView 打开官网登录，提取 localStorage 的 authorToken）
    if (showPan123Login) {
        Pan123LoginScreen(
            viewModel = pan123ViewModel,
            onBack = {
                showPan123Login = false
                pan123ViewModel.cancelAddAccount()
            },
            onSaved = { showPan123Login = false }
        )
        return
    }

    // 115 登录页：全屏覆盖（WebView 打开官网登录，提取 115.com 域 Cookie）
    if (showPan115Login) {
        Pan115LoginScreen(
            viewModel = pan115ViewModel,
            onBack = {
                showPan115Login = false
                pan115ViewModel.cancelAddAccount()
            },
            onSaved = { showPan115Login = false }
        )
        return
    }

    // 光鸭登录页：全屏覆盖（账号密码登录）
    if (showGuangYaLogin) {
        GuangYaLoginScreen(
            viewModel = guangyaViewModel,
            onBack = {
                showGuangYaLogin = false
                guangyaViewModel.cancelAddAccount()
            },
            onSaved = { showGuangYaLogin = false }
        )
        return
    }

    // 蓝奏云优享版登录页：全屏覆盖（账号密码登录）
    if (showILanzouLogin) {
        ILanzouLoginScreen(
            viewModel = ilanzouViewModel,
            onBack = {
                showILanzouLogin = false
                ilanzouViewModel.cancelAddAccount()
            },
            onSaved = { showILanzouLogin = false }
        )
        return
    }

    // 蓝奏云登录页：全屏覆盖（账号密码登录）
    if (showLanzouLogin) {
        LanzouLoginScreen(
            viewModel = lanzouViewModel,
            onBack = {
                showLanzouLogin = false
                lanzouViewModel.cancelAddAccount()
            },
            onSaved = { showLanzouLogin = false }
        )
        return
    }

    // 视频平台登录页：全屏覆盖（通用 WebView Cookie 登录页，按 platform 参数化）
    val videoLoginTarget = videoLoginPlatform
    if (videoLoginTarget != null) {
        VideoLoginScreen(
            platform = videoLoginTarget,
            viewModel = videoAccountViewModel,
            newAccount = videoLoginAsNewAccount,
            onBack = {
                videoLoginPlatform = null
                videoLoginAsNewAccount = false
            },
            // 保存成功后登录态 Flow 会自动刷新账号页，这里只需关掉登录页
            onSaved = {
                videoLoginPlatform = null
                videoLoginAsNewAccount = false
            }
        )
        return
    }

    // ★ 在线预览页：全屏覆盖，优先级最高。
    //   放在这条 return 链的**最后**：它要盖住所有页面（主界面、各叠加页，甚至正开着的叠加页），
    //   而这里的 return 会让 MainScreen 整棵树（含下面 SharedTransitionLayout 里的叠加页 AnimatedVisibility）
    //   完全不组合，天然满足「预览一旦打开就独占屏幕」；排在登录页之后是为了让登录流程不被预览打断
    //   （登录是更长的事务，用户点开登录页时不该被一次预览请求顶掉）。
    //   预览页自己带 Scaffold + BackHandler，关闭即 PreviewLauncher.dismiss() → request 变 null → 回到原页面。
    val previewRequest by PreviewLauncher.request.collectAsState()
    if (previewRequest != null) {
        MediaPreviewScreen(
            request = previewRequest!!,
            onClose = { PreviewLauncher.dismiss() }
        )
        return
    }

    // 当前叠加页路由（null = 主界面）：容器变换用它当"源/目标"的共享 key
    val overlayRoute = when {
        showAbout -> OVERLAY_KEY_ABOUT
        showTheme -> OVERLAY_KEY_THEME
        showLinkOpen -> OVERLAY_KEY_LINK_OPEN
        showMultiAccountDownload -> OVERLAY_KEY_MULTI_ACCOUNT
        showBookmarks -> OVERLAY_KEY_BOOKMARKS
        showGopeed -> OVERLAY_KEY_GOPEED
        else -> null
    }
    // 正在展示的叠加页路由：打开时更新，关闭时**保留**（退出动画要用它渲染那个页面）
    var shownRoute by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(overlayRoute) {
        if (overlayRoute != null) shownRoute = overlayRoute
    }

    // 折叠标题状态提升到本层：跨页面共享，页面切换时折叠/展开状态保持不变
    // 用 exitUntilCollapsed（默认实现，含松手吸附）：滚动时标题先收起再滚内容；
    // 向上滚动回顶部过程中标题保持收起，只有列表到达最顶部后继续下拉（overscroll）才重新展开
    val topAppBarState = rememberTopAppBarState()
    // ★ flingAnimationSpec = null 是「切页后首次快速滑动，列表恰好卡在标题收起完毕处」的修复：
    //   material3 AppBar.kt 的 ExitUntilCollapsedScrollBehavior.onPostFling → settleAppBar 里，
    //   惯性开始时若顶栏尚未完全收起，顶栏会先用 flingAnimationSpec 做衰减动画、把惯性速度消耗在自己收起上，
    //   只把「剩余速度」还给列表；一次快速滑动的速度往往不够既收起标题又带动列表，于是列表停住不动。
    //   传 null 后：顶栏仍随滚动增量收起/展开、松手时吸附到位，但不再吞掉列表的惯性速度。
    val scrollBehavior = TopAppBarDefaults.exitUntilCollapsedScrollBehavior(
        topAppBarState,
        flingAnimationSpec = null
    )

    // 全局 Snackbar 宿主（Material3，替换原 Toast 提示）
    val snackbarHostState = rememberGlobalSnackbarHostState()

    // ★ 容器变换（Container Transform）：源 = 主界面（设置页里被点的那一行），目标 = 叠加页。
    //   两者在同一个 SharedTransitionLayout 里、用同一个 key 的 sharedBounds 做形变：
    //   被点的卡片自己长成整页，行内内容淡出、页面内容在容器内淡入。
    //   ★ 主界面这个"源"用 AnimatedVisibility 承载：叠加页打开时它会被真正移出组合，
    //     而不是像以前那样常驻叠在下面 —— 那正是"卡片底色整片画不出来"的根因（见 OverlayPage 注释）。
    SharedTransitionLayout(modifier = Modifier.fillMaxSize()) {
        // 底色放最外面：过渡期间主界面淡出、叠加页容器还在长大时，露出来的是页面底色而不是系统窗口的白色
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.surface)
        ) {
            AnimatedVisibility(
                visible = overlayRoute == null,
                enter = fadeIn(effectsDefault()),
                exit = fadeOut(effectsFast())
            ) {
                // 源侧共享元素修饰符：设置页里能进入独立页面的那几行各自对应一个 key（见 SettingsScreen）。
                // ★ rememberSharedContentState 是 @Composable，必须在 composable 作用域里直接调用，
                //   不能包在普通 lambda 里延迟构造 —— 所以这里一次性建好再传下去。
                val sourceScope = this
                val themeRowModifier = Modifier.sharedBounds(
                    rememberSharedContentState(OVERLAY_KEY_THEME),
                    animatedVisibilityScope = sourceScope
                )
                val aboutRowModifier = Modifier.sharedBounds(
                    rememberSharedContentState(OVERLAY_KEY_ABOUT),
                    animatedVisibilityScope = sourceScope
                )
                // 「下载引擎」行 → 下载引擎页：和上面两行同样走容器变换（整行长成整页）
                val engineRowModifier = Modifier.sharedBounds(
                    rememberSharedContentState(OVERLAY_KEY_GOPEED),
                    animatedVisibilityScope = sourceScope
                )
                // 「链接唤起」行 → 链接唤起设置页：同样走容器变换
                val linkOpenRowModifier = Modifier.sharedBounds(
                    rememberSharedContentState(OVERLAY_KEY_LINK_OPEN),
                    animatedVisibilityScope = sourceScope
                )
                // 「多账号下载」行 → 多账号下载设置页：同样走容器变换
                val multiAccountRowModifier = Modifier.sharedBounds(
                    rememberSharedContentState(OVERLAY_KEY_MULTI_ACCOUNT),
                    animatedVisibilityScope = sourceScope
                )
                Box(modifier = Modifier.fillMaxSize()) {
                // 顶部可折叠标题（竖屏 / 横屏共用）：Expressive 的「中号柔性顶栏」
                val topBarContent: @Composable () -> Unit = {
                    // ★ 标题不要写死 style/fontWeight：柔性顶栏内部用 ProvideContentColorTextStyle 注入样式，
                    //   展开时取 headlineMedium、收起时取 titleLarge，并在这两档之间做字号形变；
                    //   这两个 token 都解析到 MaterialTheme.typography（即本项目 Type.kt 的 22sp / 18sp SemiBold），
                    //   自己再传 style 会覆盖注入值，柔性形变直接失效。
                    MediumFlexibleTopAppBar(
                        title = {
                            Text(text = currentTab.title)
                        },
                        actions = {
                            // 解析页标题右上角：收藏网盘链接入口
                            if (currentTab == MainTab.Resolve) {
                                IconButton(
                                    onClick = { showBookmarks = true },
                                    // ★ 收藏页就是从这个图标进来的：图标本身当"源"，用同一个 key 做容器变换，
                                    //   打开时图标长成整页、关闭时收回图标（与设置页那三行的做法完全一致）
                                    modifier = Modifier.sharedBounds(
                                        rememberSharedContentState(OVERLAY_KEY_BOOKMARKS),
                                        animatedVisibilityScope = sourceScope
                                    )
                                ) {
                                    Icon(Icons.Outlined.Bookmarks, contentDescription = "收藏网盘链接")
                                }
                            }
                            // 账号页标题右上角：网盘列表排序 / 隐藏未登录
                            // ★ 只在账号列表上显示：进了某个网盘的浏览子页时排序没有意义，
                            //   由 DriveScreen 通过 onSubPageChange 通知本层隐藏。
                            if (currentTab == MainTab.Drive && !driveSubPageOpen) {
                                IconButton(onClick = { showDriveSort = true }) {
                                    Icon(
                                        imageVector = Icons.Outlined.SwapVert,
                                        contentDescription = "排序网盘"
                                    )
                                }
                            }
                        },
                        scrollBehavior = scrollBehavior,
                        // 柔性顶栏没有专用的 largeTopAppBarColors，用通用 topAppBarColors（同为 TopAppBarColors 类型）
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.surface,
                            scrolledContainerColor = MaterialTheme.colorScheme.surface
                        )
                    )
                }
                // ★ Material 3 Expressive 动效规格：MaterialTheme.motionScheme 是 @Composable 属性，只能在 composable 作用域读取；
                //   而 AnimatedContent 的 transitionSpec 是普通 lambda（非 @Composable），所以必须在这里先取好、再捕获进 lambda。
                //   （P4 全项目替换 tween 时遵循同一规则：规格取在 composable 里，transitionSpec / 回调里只用捕获值）
                val motionScheme = MaterialTheme.motionScheme
                val tabSlideSpec = motionScheme.defaultSpatialSpec<IntOffset>()
                val tabFadeSpec = motionScheme.defaultEffectsSpec<Float>()
                // Tab 内容区（竖屏 / 横屏共用）：每个页面独立保存状态，切换 Tab 再切回来不丢失；带 Material3 过渡动画（按 Tab 顺序决定方向）
                val tabContent: @Composable () -> Unit = {
                    AnimatedContent(
                        targetState = currentTab,
                        transitionSpec = {
                            // 根据 Tab 顺序决定滑动方向：向右切（新Tab在右边）→ 新页从右滑入；向左切反向
                            val forward = targetState.ordinal > initialState.ordinal
                            // 位移/尺寸走 spatial 弹簧，透明度/颜色走 effects 弹簧（替代原来的 tween(220)/tween(160)）
                            if (forward) {
                                (fadeIn(tabFadeSpec) + slideInHorizontally(tabSlideSpec) { it / 4 })
                                    .togetherWith(fadeOut(tabFadeSpec) + slideOutHorizontally(tabSlideSpec) { -it / 4 })
                            } else {
                                (fadeIn(tabFadeSpec) + slideInHorizontally(tabSlideSpec) { -it / 4 })
                                    .togetherWith(fadeOut(tabFadeSpec) + slideOutHorizontally(tabSlideSpec) { it / 4 })
                            }
                        },
                        label = "mainTab"
                    ) { tab ->
                        saveableStateHolder.SaveableStateProvider(tab) {
                            when (tab) {
                                MainTab.Resolve -> ResolveScreen(
                                    scrollBehavior,
                                    resolveViewModel,
                                    quarkCloudViewModel,
                                    xunleiCloudViewModel,
                                    baiduCloudViewModel,
                                    c139CloudViewModel,
                                    ucCloudViewModel,
                                    pan123CloudViewModel,
                                    pan115CloudViewModel,
                                    guangyaCloudViewModel,
                                    bookmarkViewModel = bookmarkViewModel,
                                    onOpenBookmarks = { showBookmarks = true },
                                    // 深链接 / 分享进来的链接：解析页填进输入框并自动发起解析
                                    incomingLink = incomingLink,
                                    onIncomingLinkConsumed = onIncomingLinkConsumed
                                )
                                MainTab.Drive -> DriveScreen(
                                    scrollBehavior = scrollBehavior,
                                    quarkAccount = quarkAccount,
                                    ucAccount = ucAccount,
                                    xunleiAccount = xunleiAccount,
                                    baiduAccount = baiduAccount,
                                    c139Account = c139Account,
                                    pan123Account = pan123Account,
                                    pan115Account = pan115Account,
                                    guangyaAccount = guangyaAccount,
                                    ilanzouAccount = ilanzouAccount,
                                    lanzouAccount = lanzouAccount,
                                    quarkCloudViewModel = quarkCloudViewModel,
                                    ucCloudViewModel = ucCloudViewModel,
                                    xunleiCloudViewModel = xunleiCloudViewModel,
                                    baiduCloudViewModel = baiduCloudViewModel,
                                    c139CloudViewModel = c139CloudViewModel,
                                    pan123CloudViewModel = pan123CloudViewModel,
                                    pan115CloudViewModel = pan115CloudViewModel,
                                    guangyaCloudViewModel = guangyaCloudViewModel,
                                    ilanzouCloudViewModel = ilanzouCloudViewModel,
                                    lanzouCloudViewModel = lanzouCloudViewModel,
                                    driveQuotaViewModel = driveQuotaViewModel,
                                    onQuarkLogin = { showQuarkLogin = true },
                                    // 「添加账号」：先给对应平台的账号 VM 打上「新增」标记，再打开它的登录页；
                                    // 登录成功后这次登录会落成新的一行（见 resolveAccountSlot），
                                    // 登录页关闭时会清掉标记，不会影响日后的普通重新登录
                                    onAddAccount = { platform ->
                                        // 先清 WebView 登录态：否则网页登录页会自动检测出旧账号又存一遍
                                        // （见 MultiAccountViewModel.prepareAddAccount）
                                        multiAccountViewModel.prepareAddAccount()
                                        when (platform) {
                                            DownloadPlatform.QUARK -> {
                                                viewModel.beginAddAccount(); showQuarkLogin = true
                                            }

                                            DownloadPlatform.UC -> {
                                                ucViewModel.beginAddAccount(); showUCLogin = true
                                            }

                                            DownloadPlatform.XUNLEI -> {
                                                xunleiViewModel.beginAddAccount(); showXunleiLogin = true
                                            }

                                            DownloadPlatform.BAIDU -> {
                                                baiduViewModel.beginAddAccount(); showBaiduLogin = true
                                            }

                                            DownloadPlatform.C139 -> {
                                                c139ViewModel.beginAddAccount(); showC139Login = true
                                            }

                                            DownloadPlatform.PAN123 -> {
                                                pan123ViewModel.beginAddAccount(); showPan123Login = true
                                            }

                                            DownloadPlatform.PAN115 -> {
                                                pan115ViewModel.beginAddAccount(); showPan115Login = true
                                            }

                                            DownloadPlatform.GUANGYA -> {
                                                guangyaViewModel.beginAddAccount(); showGuangYaLogin = true
                                            }

                                            DownloadPlatform.ILANZOU -> {
                                                ilanzouViewModel.beginAddAccount(); showILanzouLogin = true
                                            }

                                            DownloadPlatform.LANZOU -> {
                                                lanzouViewModel.beginAddAccount(); showLanzouLogin = true
                                            }
                                        }
                                    },
                                    multiAccountViewModel = multiAccountViewModel,
                                    onDownloadStarted = { currentTab = MainTab.Download },
                                    onUCLogin = { showUCLogin = true },
                                    onXunleiLogin = { showXunleiLogin = true },
                                    onBaiduLogin = { showBaiduLogin = true },
                                    onC139Login = { showC139Login = true },
                                    onPan123Login = { showPan123Login = true },
                                    onPan115Login = { showPan115Login = true },
                                    onGuangYaLogin = { showGuangYaLogin = true },
                                    onILanzouLogin = { showILanzouLogin = true },
                                    onLanzouLogin = { showLanzouLogin = true },
                                    githubHasToken = githubHasTokenState,
                                    onGitHubTokenClick = { showGitHubTokenDialog = true },
                                    // 已配置 Token 点卡片主体：用 GET /user 取 login，经统一解析入口进入该账号仓库列表
                                    onGitHubBrowseHome = {
                                        scope.launch {
                                            val login = githubApi.getUserLogin()
                                            if (!login.isNullOrBlank()) {
                                                resolveViewModel.startResolve("https://github.com/$login", "")
                                                currentTab = MainTab.Resolve
                                            } else {
                                                // 取不到 login：Token 无效/已过期，或网络异常
                                                SnackbarController.show("无法获取 GitHub 账号信息，请检查网络或重新配置 Token")
                                            }
                                        }
                                    },
                                    // 更多菜单「清除 Token」：先二次确认再清除
                                    onGitHubClearToken = { showGitHubClearConfirm = true },
                                    // 视频解析区：登录态 + 账号管理（弹窗里的操作全部落到 VideoAccountViewModel）
                                    videoLoginState = videoLoginState,
                                    videoAccounts = videoAccounts,
                                    onVideoLogin = { platform ->
                                        // 普通登录：覆盖当前账号那一行，不新增记录
                                        videoLoginAsNewAccount = false
                                        videoLoginPlatform = platform
                                    },
                                    onVideoAddAccount = { platform ->
                                        // 先清一次 WebView 登录态：否则登录页会自动检测出旧账号，
                                        // 「添加账号」加进来的还是同一个账号（与网盘的 prepareAddAccount 同因）
                                        multiAccountViewModel.prepareAddAccount()
                                        videoLoginAsNewAccount = true
                                        videoLoginPlatform = platform
                                    },
                                    onVideoSetPrimary = { platform, id ->
                                        videoAccountViewModel.setPrimary(platform, id)
                                    },
                                    onVideoRename = { id, remark ->
                                        videoAccountViewModel.updateRemark(id, remark)
                                    },
                                    onVideoRemove = { id -> videoAccountViewModel.remove(id) },
                                    onVideoRemoveAll = { platform ->
                                        videoAccountViewModel.removeAll(platform)
                                    },
                                    // 顶栏「排序」入口：弹窗、顺序与隐藏开关都由 DriveScreen 渲染
                                    showSortDialog = showDriveSort,
                                    onDismissSortDialog = { showDriveSort = false },
                                    onSubPageChange = { driveSubPageOpen = it }
                                )
                                MainTab.Download -> DownloadScreen(
                                    scrollBehavior,
                                    downloadViewModel,
                                    // 下载调试开关（开发调试菜单）：开启后下载页长按任务可进「调试信息」页
                                    downloadDebug = ThemeController.downloadDebug,
                                    // 深链接进来的直链 / 磁力：预填「添加下载任务」弹窗，由用户确认后入队
                                    incomingAddUrl = incomingAddUrl,
                                    onIncomingAddUrlConsumed = onIncomingAddUrlConsumed
                                )
                                MainTab.Settings -> SettingsScreen(
                                    scrollBehavior = scrollBehavior,
                                    themeRowModifier = themeRowModifier,
                                    aboutRowModifier = aboutRowModifier,
                                    engineRowModifier = engineRowModifier,
                                    linkOpenRowModifier = linkOpenRowModifier,
                                    multiAccountRowModifier = multiAccountRowModifier,
                                    onThemeClick = { showTheme = true },
                                    onAboutClick = { showAbout = true },
                                    onGopeedClick = { showGopeed = true },
                                    onLinkOpenClick = { showLinkOpen = true },
                                    onMultiAccountDownloadClick = { showMultiAccountDownload = true },
                                    backupManager = backupManager,
                                )
                            }
                        }
                    }
                }

                if (useRail) {
                    // 横屏：左侧侧边导航栏（NavigationRail）+ 右侧顶栏 & 内容
                    // ★ 外层 Surface 不只是底色（竖屏由 Scaffold 提供背景，横屏手动布局必须自己铺，
                    //   否则露出窗口默认白色）：**只有 Surface/Scaffold 才会提供 LocalContentColor**
                    //   （其默认值是黑色）——横屏没有 Scaffold，少了这层，深色模式下没写 color 的文本
                    //   （例如 ShareFileRow 里的文件名）就会变成黑字。
                    Surface(
                        modifier = Modifier.fillMaxSize(),
                        color = MaterialTheme.colorScheme.background
                    ) {
                        Box(modifier = Modifier.fillMaxSize()) {
                            Row(modifier = Modifier.fillMaxSize()) {
                                MainNavigationRail(
                                    currentTab = currentTab,
                                    onTabSelected = { currentTab = it }
                                )
                                Column(
                                    modifier = Modifier
                                        .weight(1f)
                                        .fillMaxSize()
                                ) {
                                    topBarContent()
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .fillMaxWidth()
                                    ) {
                                        tabContent()
                                    }
                                }
                            }
                            // 全局 Snackbar（横屏无底部栏，悬浮底部居中）
                            SnackbarHost(
                                hostState = snackbarHostState,
                                modifier = Modifier.align(Alignment.BottomCenter)
                            )
                        }
                    }
                } else {
                    // 竖屏：Scaffold + 底部导航栏
                    Scaffold(
                        modifier = Modifier.fillMaxSize(),
                        snackbarHost = { SnackbarHost(snackbarHostState) },
                        topBar = { topBarContent() },
                        bottomBar = {
                            MainBottomBar(
                                currentTab = currentTab,
                                onTabSelected = { currentTab = it }
                            )
                        }
                    ) { innerPadding ->
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                        ) {
                            tabContent()
                        }
                    }
                }

                }
            }

            // 目标：叠加页（整屏 + 不透明底 + sharedBounds：从被点那一项长出来）
            AnimatedVisibility(
                visible = overlayRoute != null,
                enter = fadeIn(effectsDefault()),
                // ★ 退出时长必须≥ sharedBounds 形变的时长（默认 bounds 弹簧约 300ms）：
                //   AnimatedVisibility 的退出一结束就会把内容移出组合，页面提前消失 → 回收形变被截断，
                //   观感就是"退出一闪而过、像没做动画"。所以这里刻意用 300ms 的 tween 而不是 effectsFast(≈64ms)。
                exit = fadeOut(tween(durationMillis = 300))
            ) {
                val targetScope = this
                // ★ 读"正在展示的路由"而不是 overlayRoute：后者在点返回的瞬间就变 null 了，
                //   退出动画会因此没有内容可放（整段退出效果消失）。
                val route = shownRoute
                if (route != null) {
                    OverlayPage(
                        // 收藏页的"源"是顶栏那个书签图标（见上），其余三页是设置页里被点的那一行；
                        // 两者都用同一个 route key，所以这里不再需要特例分支
                        modifier = Modifier.sharedBounds(
                            rememberSharedContentState(route),
                            animatedVisibilityScope = targetScope
                        )
                    ) {
                        when (route) {
                            OVERLAY_KEY_ABOUT -> AboutScreen(
                                onBack = { showAbout = false },
                                onPreviewOnboarding = {
                                    context.getSharedPreferences("yunx_prefs", android.content.Context.MODE_PRIVATE)
                                        .edit()
                                        .putBoolean("onboarding_shown", false)
                                        .apply()
                                    showAbout = false
                                    showOnboarding = true
                                }
                            )
                            OVERLAY_KEY_THEME -> ThemeScreen(onBack = { showTheme = false })
                            OVERLAY_KEY_LINK_OPEN -> LinkOpenScreen(onBack = { showLinkOpen = false })
                            OVERLAY_KEY_MULTI_ACCOUNT -> MultiAccountDownloadScreen(
                                onBack = { showMultiAccountDownload = false }
                            )
                            OVERLAY_KEY_GOPEED -> DownloadEngineScreen(onBack = { showGopeed = false })
                            else -> BookmarkScreen(
                                viewModel = bookmarkViewModel,
                                onBack = { showBookmarks = false },
                                onResolve = { link, pwd ->
                                    showBookmarks = false
                                    currentTab = MainTab.Resolve
                                    // GitHub 收藏（仓库链接）走 GitHub 解析入口，与主页快捷方式一致
                                    val github = GitHubLinkParser.parse(link)
                                    if (github != null) {
                                        resolveViewModel.startGitHubResolve(github)
                                    } else {
                                        resolveViewModel.startResolve(link, pwd)
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }

    // GitHub Token 配置弹窗（网盘页入口）：Keystore 加密存储，输入用密码可见性切换
    if (showGitHubTokenDialog) {
        var tokenInput by rememberSaveable { mutableStateOf(GitHubTokenStore.getToken(context) ?: "") }
        var passwordVisible by remember { mutableStateOf(false) }
        // 校验失败提示（显示在输入框下方），修改输入即清除
        var tokenError by remember { mutableStateOf<String?>(null) }
        AlertDialog(
            onDismissRequest = { showGitHubTokenDialog = false },
            title = { Text("GitHub Token") },
            text = {
                Column {
                    Text(
                        text = "Token 仅用于提升 API 限额（匿名 60/小时，认证后 5000/小时）。经 Android Keystore AES-GCM 加密存储。",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Spacer(Modifier.height(10.dp))
                    Text(
                        text = "如何获取 Token：",
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "1. 电脑浏览器打开 GitHub，右上角头像 → Settings\n" +
                            "2. 左侧 Developer settings → Personal access tokens → Tokens (classic) → Generate new token\n" +
                            "3. 勾选 public_repo 即可浏览公开仓库；如需在主页看到自己的私有仓库，再勾选 repo\n" +
                            "4. 有效期建议选 90 天或 No expiration，生成后复制粘贴到上方输入框",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    // 那四步是让人在电脑上手翻路径，手机上翻不动 —— 直接给一个跳到预填好权限的表单的入口
                    TextButton(
                        onClick = {
                            // 与设置页「GitHub 仓库」同一口径：没有可用浏览器就复制链接，不静默失败
                            if (!AppLinks.openGitHubTokenPage(context)) {
                                copyToClipboard(context, AppLinks.GITHUB_TOKEN_PAGE)
                                SnackbarController.show("未找到可用浏览器，链接已复制")
                            }
                        },
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Text(
                            text = "↗ 从 GitHub 获取 Token",
                            style = MaterialTheme.typography.bodySmall,
                            textDecoration = TextDecoration.Underline
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "安全提示：仅给最小权限，勿勾选删除/管理类权限；Token 不明文保存、不上传，清除只需清空后保存。",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = tokenInput,
                        onValueChange = {
                            tokenInput = it
                            tokenError = null
                        },
                        singleLine = true,
                        isError = tokenError != null,
                        label = { Text("Personal Access Token") },
                        supportingText = { tokenError?.let { Text(it) } },
                        visualTransformation = if (passwordVisible) VisualTransformation.None
                        else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { passwordVisible = !passwordVisible }) {
                                Icon(
                                    if (passwordVisible) Icons.Outlined.Visibility
                                    else Icons.Outlined.VisibilityOff,
                                    contentDescription = if (passwordVisible) "隐藏" else "显示"
                                )
                            }
                        }
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val input = tokenInput.trim()
                    if (input.isBlank()) {
                        // 清空即清除 Token（无需联网校验）
                        GitHubTokenStore.setToken(context, null)
                        githubHasTokenState = false
                        showGitHubTokenDialog = false
                        SnackbarController.show("已清除 GitHub Token")
                    } else {
                        // 保存前先校验：无效 Token 会让 GitHub 拒绝之后的所有请求（含公开仓库解析）
                        scope.launch {
                            when (val check = githubApi.validateToken(input)) {
                                is TokenCheck.Valid -> {
                                    // 保存失败（本机加密密钥暂时不可用）时留在弹窗里如实提示：
                                    // 写不进去却报「已保存」，用户会以为配好了、实际仍在走匿名限额
                                    if (GitHubTokenStore.setToken(context, input)) {
                                        githubHasTokenState = true
                                        showGitHubTokenDialog = false
                                        SnackbarController.show("GitHub Token 已保存（@${check.login}）")
                                    } else {
                                        tokenError = "保存失败：本机加密密钥暂时不可用，请稍后重试"
                                    }
                                }
                                TokenCheck.Invalid -> tokenError = "Token 无效或已过期，请重新生成后再保存"
                                TokenCheck.Unknown -> tokenError = "无法校验 Token（网络异常），请联网后重试"
                            }
                        }
                    }
                }) { Text("保存") }
            },
            dismissButton = {
                TextButton(onClick = { showGitHubTokenDialog = false }) { Text("取消") }
            }
        )
    }

    // 清除 GitHub Token 二次确认（网盘页更多菜单）
    if (showGitHubClearConfirm) {
        AlertDialog(
            onDismissRequest = { showGitHubClearConfirm = false },
            title = { Text("清除 GitHub Token？") },
            text = { Text("清除后 GitHub API 回退匿名限额（60 次/小时/IP）。") },
            confirmButton = {
                TextButton(onClick = {
                    GitHubTokenStore.setToken(context, null)
                    githubHasTokenState = false
                    showGitHubClearConfirm = false
                    SnackbarController.show("已清除 GitHub Token")
                }) { Text("清除", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { showGitHubClearConfirm = false }) { Text("取消") }
            }
        )
    }
}


/** 复制文本到剪贴板（写剪贴板不受「自动识别剪贴板」开关约束，见 Agent.md §3.22） */
private fun copyToClipboard(context: Context, text: String) {
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("yunx_link", text))
}

/**
 * 叠加页容器（关于云析 / 支持开发 / 主题与外观 / 收藏）：整屏 + 不透明底色 + 可选的 sharedBounds 形变。
 *
 * ★ 它与主界面的关系是「互斥」而不是「叠加」：两者是同一个 SharedTransitionLayout 下两个
 *   `AnimatedVisibility`，叠加页打开时**主界面会被移出组合**。这一点是硬要求，不是洁癖——
 *   实测（多轮截图 + E 级日志）证明：只要主界面常驻叠在下面，这些页面里的 `Card` 底色就会整片
 *   画不出来（文字/图标/描边/分隔线都在，就是底色没了；把底色写死成亮绿也一样不画 ⇒ 与颜色无关），
 *   而且缺失区域的分界线会随滚动/折叠状态移动。改成互斥（源被移除）后完全正常。
 *   过渡期间两者会短暂共存（形变需要源的边界），这是可接受的：动画一结束源就被释放。
 *
 * ★ 底色仍要自己铺：M3E(material3 1.5.0-alpha18) 的 Scaffold 已不带底色
 *   （`ScaffoldDefaults` 只剩 `getContentWindowInsets`），页面不铺底就是透的。
 */
@Composable
private fun OverlayPage(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    // sharedBounds 加在"底色之外"：形变中的容器自带不透明底色，过渡期间不会透出下层的窗口底色
    Box(
        modifier = Modifier
            .fillMaxSize()
            .then(modifier)
            .background(MaterialTheme.colorScheme.surface)
    ) {
        content()
    }
}

/**
 * 底部导航条（竖屏）：4 个主 Tab（解析 / 账号 / 下载 / 设置）。
 * 用 Expressive 的 ShortNavigationBar（选中项带形状指示器 + 弹簧动效，item 由组件内部按 EqualWeight 均分，
 * 不需要自己加 weight）。
 * ★ 高度：Expressive 规范高度是 64dp（NavigationBarTokens.ContainerHeight），比经典 NavigationBar 的
 *   TallContainerHeight（80dp）矮 16dp，产品上要求保持原高度。注意不能直接给 ShortNavigationBar 传
 *   Modifier.heightIn —— 它内部布局按 TopStart 对齐，撑高外层只会让 64dp 的内容贴顶。
 *   故外面套一层同色 Box 并居中：视觉上等价于原来的 80dp 导航栏，item 布局仍是 Expressive。
 *   三键导航机型上系统栏内边距会再叠加（经典版同样如此），因此会比 80dp 更高一点，属正常。
 */
@Composable
private fun MainBottomBar(
    currentTab: MainTab,
    onTabSelected: (MainTab) -> Unit
) {
    val barColor = ShortNavigationBarDefaults.containerColor
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 80.dp)
            .background(barColor),
        contentAlignment = Alignment.Center
    ) {
        ShortNavigationBar(containerColor = barColor) {
            MainTab.values().forEach { tab ->
                ShortNavigationBarItem(
                    selected = currentTab == tab,
                    onClick = { onTabSelected(tab) },
                    icon = {
                        Icon(
                            imageVector = if (currentTab == tab) tab.selectedIcon else tab.unselectedIcon,
                            contentDescription = tab.title
                        )
                    },
                    label = { Text(tab.title) }
                )
            }
        }
    }
}


/**
 * 侧边导航栏（横屏）：同 4 个主 Tab，未选中项只显示图标，节省横向空间。
 */
@Composable
private fun MainNavigationRail(
    currentTab: MainTab,
    onTabSelected: (MainTab) -> Unit
) {
    NavigationRail {
        MainTab.values().forEach { tab ->
            NavigationRailItem(
                selected = currentTab == tab,
                onClick = { onTabSelected(tab) },
                icon = {
                    Icon(
                        imageVector = if (currentTab == tab) tab.selectedIcon else tab.unselectedIcon,
                        contentDescription = tab.title
                    )
                },
                label = { Text(tab.title) },
                alwaysShowLabel = currentTab == tab
            )
        }
    }
}
