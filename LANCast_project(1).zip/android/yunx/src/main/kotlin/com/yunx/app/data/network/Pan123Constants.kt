/*
 * YunX (云析) - A network drive share-link parser and high-speed downloader for Android.
 * Copyright (C) 2026 CYQawa
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.yunx.app.data.network

object Pan123Constants {

    // ---------- BaseURL（按用途，文档 §3.1） ----------

    /** 个人盘业务 API / 分享列表（主域式） */
    const val API_BASE = "https://yun.123pan.cn"

    /** 分享下载信息（抓包实证；alist 用 yun.123pan.com 等价） */
    const val DOWNLOAD_BASE = "https://www.123865.com"

    // ---------- API 路径（严格按文档 §5，不要自行加/去 /b） ----------

    /** 网页登录页：官网个人盘主页（未登录自动进入登录流程；登录后 localStorage 写入 authorToken） */
    const val WEB_LOGIN_URL = "https://yun.123pan.cn/"

    /**
     * 账号密码登录（原生接口，与网页登录并列的第二条路）。
     * 注意域名是 user.123pan.cn，与个人盘 API 的 yun.123pan.cn 不是同一个站。
     */
    const val SIGN_IN_URL = "https://user.123pan.cn/api/user/sign_in"

    /** 账号密码登录的 Origin / Referer（缺了会被风控拒绝） */
    const val SIGN_IN_ORIGIN = "https://user.123pan.cn"
    const val SIGN_IN_REFERER = "https://user.123pan.cn/"

    /** 账号密码登录专用 app-version（网页端是 3，登录接口要 132，两者不能混用） */
    const val APP_VERSION_SIGN_IN = "132"

    /** 网页登录态在 localStorage 中的键名：值即 Bearer JWT（与旧 sign_in 返回的 data.token 同源同形） */
    const val LOCAL_STORAGE_TOKEN_KEY = "authorToken"

    /** 分享文件列表（GET /b/api/share/get，匿名、无签名） */
    const val SHARE_GET_URL = "$API_BASE/b/api/share/get"

    /** 分享下载信息（POST /b/api/share/download/info，需登录+签名） */
    const val SHARE_DOWNLOAD_INFO_URL = "$DOWNLOAD_BASE/b/api/share/download/info"

    /** 个人盘文件列表（GET /b/api/file/list/new，需登录+签名） */
    const val FILE_LIST_URL = "$API_BASE/b/api/file/list/new"

    /** 个人盘下载信息（POST /api/file/download_info，注意无 /b/） */
    const val FILE_DOWNLOAD_INFO_URL = "$API_BASE/api/file/download_info"

    /** 流量校验（POST /b/api/file/download/traffic/check） */
    const val TRAFFIC_CHECK_URL = "$API_BASE/b/api/file/download/traffic/check"

    /** 删除/移入回收站（POST /b/api/file/trash） */
    const val FILE_TRASH_URL = "$API_BASE/b/api/file/trash"

    /** 重命名（POST /b/api/file/rename） */
    const val FILE_RENAME_URL = "$API_BASE/b/api/file/rename"

    /** 移动（POST /b/api/file/mod_pid） */
    const val FILE_MOD_PID_URL = "$API_BASE/b/api/file/mod_pid"

    /**
     * 新建文件夹 / 上传预创建（POST /b/api/file/upload_request）：
     * 123 没有独立的建目录端点，靠同一个接口的 `type` 区分（1 = 建目录、0 = 文件；文档 §2/§8）。
     */
    const val FILE_UPLOAD_REQUEST_URL = "$API_BASE/b/api/file/upload_request"

    /**
     * 上传：预签名分片地址。
     * - 单分片走 `s3_upload_object/auth`；
     * - 多分片走 `s3_repare_upload_parts_batch`（批量取，`partNumberStart/End` 控制范围）。
     */
    const val FILE_S3_UPLOAD_AUTH_URL = "$API_BASE/b/api/file/s3_upload_object/auth"
    const val FILE_S3_REPARE_PARTS_URL = "$API_BASE/b/api/file/s3_repare_upload_parts_batch"

    /** 上传：合并（S3 直传凭据路径用 `upload_complete`，预签名分片路径用 `upload_complete/v2`） */
    const val FILE_UPLOAD_COMPLETE_URL = "$API_BASE/b/api/file/upload_complete"
    const val FILE_UPLOAD_COMPLETE_V2_URL = "$API_BASE/b/api/file/upload_complete/v2"

    /** 创建分享（POST /b/api/share/create） */
    const val SHARE_CREATE_URL = "$API_BASE/b/api/share/create"

    /** 用户信息（GET /b/api/user/info，校验登录态/取昵称/容量） */
    const val USER_INFO_URL = "$API_BASE/b/api/user/info"

    // ---------- 公共请求头（文档 §3.2） ----------

    /** 浏览器 UA（web 系抓包） */
    const val WEB_UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36"

    /** Dart UA（分享列表匿名请求） */
    const val DART_UA = "Dart/3.12 (dart:io)"

    /** platform：web（个人盘/分享列表/登录） */
    const val PLATFORM_WEB = "web"

    /** platform：android（分享下载信息 www.123865.com） */
    const val PLATFORM_ANDROID = "android"

    /** app-version：web 系 */
    const val APP_VERSION_WEB = "3"

    /** app-version：android 系（仅分享下载） */
    const val APP_VERSION_ANDROID = "39"

    /** 分享下载真实 CDN 直链下载时必须携带的 Referer（文档 §5.3.1） */
    const val DOWNLOAD_REFERER = "https://yun.123pan.cn/"

    // ---------- 签名算法常量（文档 §6.2） ----------

    /** 数字 0-9 的替换表，索引 = 数字值 */
    const val SIGN_TABLE = "adefghlmyijnopkqrstubcvwsz"

    /** 签名内部固定 OS */
    const val SIGN_OS = "web"

    /** 签名内部固定 VER */
    const val SIGN_VER = "3"

    /** timeSign 时间基准偏移：ts + 57600 秒（+16h，UTC 格式化；抓包实证，文档 §6.3） */
    const val SIGN_OFFSET_SECONDS = 57600L

    /** 永久分享的过期时间（文档 §5.10：永久=2099-12-12T08:00:00+08:00） */
    const val EXPIRATION_FOREVER = "2099-12-12T08:00:00+08:00"

    /** 生成 32 位十六进制 loginuuid（文档 §3.2：设备标识，不参与签名，可固定复用） */
    fun newLoginUuid(): String {
        val chars = "0123456789abcdef"
        return buildString {
            repeat(32) { append(chars.random()) }
        }
    }
}
