plugins {
    alias(libs.plugins.android.library)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.ksp)
}

// 云析（YunX）v1.3.1 —— https://github.com/CYQawa/YunX ，GNU AGPL-3.0。
// 在原项目基础上：改为库模块嵌入瞬流；移除了公告 / 检查更新 / 捐赠 / 社群推广 / 防篡改自检等非功能代码。
android {
    namespace = "com.yunx.app"
    compileSdk = 36

    defaultConfig {
        minSdk = 24
        consumerProguardFiles("consumer-rules.pro")
    }

    buildFeatures {
        compose = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlin {
        compilerOptions {
            jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.fromTarget("17"))
        }
    }
}

dependencies {
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.8.7")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.7")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation(libs.material)

    // Gopeed 内置下载引擎的 gomobile 桥接类（只含类型定义；真正的 libgojni.so 由用户在设置页导入，运行时加载）
    implementation(files("libs/gopeed-classes.jar"))

    implementation(libs.room.runtime)
    implementation(libs.room.ktx)
    ksp(libs.room.compiler)

    // GitHub README 的 GFM 渲染
    implementation(libs.markdownRenderer)

    // 在线预览/播放：ExoPlayer + 官方 PlayerView
    implementation(libs.androidx.media3.exoplayer)
    implementation(libs.androidx.media3.ui)
    implementation(libs.androidx.media3.hls)
    // 图片加载
    implementation(libs.androidx.coil.compose)
    implementation(libs.androidx.coil.network.okhttp)
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.webkit)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.ui)
    implementation(libs.androidx.ui.graphics)
    implementation(libs.androidx.ui.tooling.preview)
    implementation(libs.androidx.material3)

    // 强制 kotlin-stdlib 与项目 Kotlin 2.1.0 对齐
    constraints {
        implementation("org.jetbrains.kotlin:kotlin-stdlib:2.1.0")
    }
}
