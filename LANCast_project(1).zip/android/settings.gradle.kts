pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "LANCast"
include(":app")
include(":yunx")   // 云析：网盘 / 视频分享链接解析与高速下载（Compose 模块，来自 CYQawa/YunX v1.3.1，AGPL-3.0）
