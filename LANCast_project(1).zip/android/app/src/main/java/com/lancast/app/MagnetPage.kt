package com.lancast.app

import android.app.AlertDialog
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import kotlin.concurrent.thread

/** 磁力下载页（纯代码布局，和其它页面同风格）。引擎见 Magnet.kt。 */
class MagnetPage(
    private val ctx: Context,
    private val onBack: () -> Unit,
    private val onPickTorrent: () -> Unit,
    private val onSend: (List<File>) -> Unit
) {
    val view: FrameLayout = FrameLayout(ctx)
    private val ui = Handler(Looper.getMainLooper())
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private fun px(v: Int) = ctx.px(v)
    private val input: EditText
    private val hint: TextView
    private val list: LinearLayout
    private val sumTv: TextView
    private val dirTv: TextView
    private class Row(val box: LinearLayout, val name: TextView, val state: TextView, val bar: ProgressBar, val info: TextView, val btns: LinearLayout) { var sig = "" }
    private val rows = LinkedHashMap<String, Row>()
    private var resolving: Thread? = null
    @Volatile private var cancelled = false
    private var visible = false
    private var dialog: AlertDialog? = null

    private fun tv(t: String, sp: Float, color: Int = C.INK, bold: Boolean = false) = TextView(ctx).apply {
        text = t; textSize = sp; setTextColor(color); if (bold) typeface = android.graphics.Typeface.DEFAULT_BOLD
    }
    private fun lp(w: Int, h: Int, weight: Float = 0f, top: Int = 0) = LinearLayout.LayoutParams(w, h, weight).apply { topMargin = px(top) }
    private fun btn(t: String, filled: Boolean = false, f: () -> Unit) = tv(t, 13.5f, if (filled) android.graphics.Color.WHITE else C.PRIMARY, true).apply {
        gravity = Gravity.CENTER; setPadding(px(14), px(8), px(14), px(8))
        background = ctx.shape(if (filled) C.PRIMARY else C.SOFT, 18f); setOnClickListener { f() }
    }
    private fun card() = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL; setPadding(px(16), px(14), px(16), px(14))
        background = ctx.shape(C.CARD, 18f, C.CARD_LINE, 1f)
    }

    init {
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(px(20), px(16), px(20), px(24)) }
        val bar = FrameLayout(ctx)
        val back = FrameLayout(ctx).apply { background = circle(C.BACK) }
        back.addView(IconView(ctx, "back", C.INK), FrameLayout.LayoutParams(px(22), px(22), Gravity.CENTER))
        back.setOnClickListener { onBack() }
        bar.addView(back, FrameLayout.LayoutParams(px(44), px(44), Gravity.START or Gravity.CENTER_VERTICAL))
        bar.addView(tv("磁力下载", 24f, C.INK, true), FrameLayout.LayoutParams(WRAP, WRAP, Gravity.CENTER))
        col.addView(bar, lp(MATCH, WRAP))

        val inCard = card()
        inCard.addView(tv("粘贴磁力链接 / Hash，或打开 .torrent：先解析，看文件列表，勾选要下的再开始。默认不限速，DHT、Tracker、PEX 全开。", 12.5f, C.SUB))
        input = EditText(ctx).apply {
            hint = "magnet:?xt=urn:btih:…（也支持 40 位 Hash）"; textSize = 14f; setTextColor(C.INK); setHintTextColor(C.GRAY)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS or InputType.TYPE_TEXT_VARIATION_URI
            maxLines = 3; setPadding(px(14), px(10), px(14), px(10)); background = ctx.shape(C.BG, 12f, C.INPUT_LINE, 1f)
        }
        inCard.addView(input, lp(MATCH, WRAP, 0f, 10))
        val r = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        r.addView(btn("解析", true) { go() }, lp(WRAP, WRAP))
        r.addView(btn("粘贴") { paste(true) }, lp(WRAP, WRAP).apply { leftMargin = px(8) })
        r.addView(btn(".torrent") { onPickTorrent() }, lp(WRAP, WRAP).apply { leftMargin = px(8) })
        inCard.addView(r, lp(MATCH, WRAP, 0f, 10))
        hint = tv("", 12.5f, C.PRIMARY); inCard.addView(hint, lp(MATCH, WRAP, 0f, 8))
        col.addView(inCard, lp(MATCH, WRAP, 0f, 16))

        val set = card()
        dirTv = tv("", 12.5f, C.SUB)
        set.addView(tv("下载设置", 15f, C.INK, true))
        set.addView(dirTv, lp(MATCH, WRAP, 0f, 6))
        val sr = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        sr.addView(btn("保存位置") { chooseDir() }, lp(WRAP, WRAP))
        sr.addView(btn("限速") { limitDialog() }, lp(WRAP, WRAP).apply { leftMargin = px(8) })
        lateinit var seedBtn: TextView
        seedBtn = btn(if (Magnet.seedAfter) "做种：开" else "做种：关") { Magnet.seedAfter = !Magnet.seedAfter; seedBtn.text = if (Magnet.seedAfter) "做种：开" else "做种：关" }
        sr.addView(seedBtn, lp(WRAP, WRAP).apply { leftMargin = px(8) })
        set.addView(sr, lp(MATCH, WRAP, 0f, 10))
        col.addView(set, lp(MATCH, WRAP, 0f, 14))

        val head = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(tv("下载任务", 17f, C.INK, true), lp(0, WRAP, 1f))
        sumTv = tv("", 12.5f, C.SUB); head.addView(sumTv)
        val clr = tv("清除已完成", 13f, C.SUB).apply { setPadding(px(12), px(4), 0, px(4)); setOnClickListener { thread { Magnet.clearFinished() } } }
        head.addView(clr)
        col.addView(head, lp(MATCH, WRAP, 0f, 20))
        list = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        col.addView(list, lp(MATCH, WRAP, 0f, 8))
        view.addView(ScrollView(ctx).apply { setBackgroundColor(C.BG); overScrollMode = View.OVER_SCROLL_NEVER; addView(col) }, FrameLayout.LayoutParams(MATCH, MATCH))
        view.visibility = View.GONE
        showDir()
    }

    /* ── 生命周期 ── */
    fun open() { visible = true; view.visibility = View.VISIBLE; showDir(); paste(false); ensure { }; ui.post(tick) }
    fun close() { visible = false; view.visibility = View.GONE; ui.removeCallbacks(tick); cancelDialog() }
    fun stop() { ui.removeCallbacks(tick) }
    fun resume() { if (visible) ui.post(tick) }

    private fun ensure(then: () -> Unit) {
        if (Magnet.started) { then(); return }
        thread {
            try { Magnet.start(ctx); ui.post { then() } }
            catch (t: Throwable) { ui.post { say("下载引擎启动失败：" + (t.message ?: t.javaClass.simpleName), true) } }
        }
    }
    private fun say(m: String, err: Boolean = false) { hint.text = m; hint.setTextColor(if (err) C.BAD else C.PRIMARY) }
    private fun showDir() {
        dirTv.text = "保存到：" + Magnet.dirLabel()
    }

    /* ── 输入入口 ── */
    private fun paste(force: Boolean) {
        try {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val t = cm.primaryClip?.getItemAt(0)?.coerceToText(ctx)?.toString() ?: ""
            val n = Magnet.normalize(t)
            if (n != null && (force || input.text.isEmpty())) { input.setText(n); say("已识别到磁力链接，点「解析」开始") }
            else if (force) say("剪贴板里没有磁力链接", true)
        } catch (ignored: Exception) { }
    }
    fun openUri(uri: String) { input.setText(uri); if (!visible) open(); go() }
    fun openTorrent(data: ByteArray) {
        if (!visible) open()
        try { ensure { showMeta(Magnet.resolveTorrent(data)) } } catch (e: Exception) { say(e.message ?: "无法读取 .torrent", true) }
    }
    private fun go() {
        val u = Magnet.normalize(input.text.toString())
        if (u == null) { say("没认出磁力链接：请粘贴 magnet:?xt=… 开头的链接，或 40 位 Hash", true); return }
        if (resolving != null) return
        say("")
        cancelled = false
        val d = AlertDialog.Builder(ctx).setTitle("正在解析…").setMessage("正在通过 DHT / Tracker 寻找节点并获取文件信息，冷门资源可能需要一两分钟。")
            .setNegativeButton("取消") { _, _ -> cancelled = true }.setOnCancelListener { cancelled = true }.create()
        d.show(); dialog = d
        ensure {
            resolving = thread(name = "mag-resolve", isDaemon = true) {
                var meta: Magnet.Meta? = null; var err = ""
                try { meta = Magnet.resolve(u) { cancelled } } catch (e: Exception) { err = e.message ?: "解析失败" }
                ui.post {
                    resolving = null; cancelDialog()
                    when {
                        cancelled -> {}
                        meta != null -> showMeta(meta)
                        else -> say(if (err.isNotEmpty()) err else "没有获取到文件信息：可能暂时没有人做种，可稍后重试", true)
                    }
                }
            }
        }
    }
    private fun cancelDialog() { try { dialog?.dismiss() } catch (ignored: Exception) { }; dialog = null }

    /* ── 选文件 ── */
    private fun sz(n: Long): String = when {
        n >= 1L shl 30 -> String.format("%.2f GB", n / 1073741824.0)
        n >= 1L shl 20 -> String.format("%.1f MB", n / 1048576.0)
        n >= 1024 -> String.format("%d KB", n / 1024)
        else -> "$n B"
    }
    private fun showMeta(m: Magnet.Meta) {
        val checked = BooleanArray(m.files.size) { true }
        val names = Array(m.files.size) { m.files[it].path.substringAfter('/', m.files[it].path) + "  (" + sz(m.files[it].size) + ")" }
        fun total() = m.files.indices.filter { checked[it] }.sumOf { m.files[it].size }
        fun title() = m.name + "\n已选 " + checked.count { it } + "/" + checked.size + " · " + sz(total())
        val d = AlertDialog.Builder(ctx).setTitle(title())
            .setMultiChoiceItems(names, checked) { dlg, i, on -> checked[i] = on; (dlg as AlertDialog).setTitle(title()) }
            .setPositiveButton("开始下载", null).setNegativeButton("取消", null).setNeutralButton("全选/全不选", null).create()
        d.show()
        d.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
            val on = checked.any { !it }
            for (i in checked.indices) { checked[i] = on; d.listView.setItemChecked(i, on) }; d.setTitle(title())
        }
        d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val sel = m.files.indices.filter { checked[it] }.map { m.files[it].index }.toSet()
            if (sel.isEmpty()) { Toast.makeText(ctx, "至少选一个文件", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            d.dismiss()
            thread {
                try { Magnet.add(m, Magnet.saveDir(), sel); ui.post { input.setText(""); say("已开始下载：" + m.name); MagnetService.ensure(ctx); tick.run() } }
                catch (e: Exception) { ui.post { say(e.message ?: "无法开始下载", true) } }
            }
        }
    }

    /* ── 设置 ── */
    private fun chooseDir() {
        val opts = arrayOf("应用专属目录（无需权限）", "下载/瞬流/磁力（需要「所有文件访问」权限）")
        AlertDialog.Builder(ctx).setTitle("下载保存位置").setSingleChoiceItems(opts, if (Magnet.publicDir) 1 else 0) { dlg, i ->
            dlg.dismiss()
            if (i == 1 && !Magnet.canUsePublicDir()) {
                Toast.makeText(ctx, "请在设置里允许瞬流访问所有文件，再回来重选", Toast.LENGTH_LONG).show()
                try { ctx.startActivity(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { }
            } else { Magnet.publicDir = i == 1; showDir() }
        }.show()
    }
    private fun limitDialog() {
        val box = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(px(22), px(8), px(22), 0) }
        fun et(h: String, v: Int) = EditText(ctx).apply { hint = h; inputType = InputType.TYPE_CLASS_NUMBER; setText(v.toString()) }
        val d = et("下载限速 KB/s（0 = 不限）", Magnet.downKb); val u = et("上传限速 KB/s（0 = 不限）", Magnet.upKb)
        box.addView(tv("下载限速 KB/s（0 = 不限）", 13f, C.SUB)); box.addView(d); box.addView(tv("上传限速 KB/s（0 = 不限）", 13f, C.SUB)); box.addView(u)
        AlertDialog.Builder(ctx).setTitle("限速").setView(box).setPositiveButton("保存") { _, _ ->
            Magnet.downKb = d.text.toString().toIntOrNull() ?: 0; Magnet.upKb = u.text.toString().toIntOrNull() ?: 0
        }.setNegativeButton("取消", null).show()
    }

    /* ── 任务列表 ── */
    private fun fmtSp(n: Int) = if (n >= 1 shl 20) String.format("%.1f MB/s", n / 1048576.0) else String.format("%d KB/s", n / 1024)
    private fun fmtT(s: Long): String { val h = s / 3600; val m = s % 3600 / 60; val ss = s % 60; return if (h > 0) String.format("%d:%02d:%02d", h, m, ss) else String.format("%d:%02d", m, ss) }
    private val tick = object : Runnable {
        override fun run() {
            if (!visible) return
            if (!Magnet.started) { ui.postDelayed(this, 1000); return }
            thread { val l = Magnet.tasks(); ui.post { render(l); if (visible) ui.postDelayed(this, 1000) } }
        }
    }
    private fun render(l: List<Magnet.Task>) {
        val (d, u) = Magnet.speeds(l)
        sumTv.text = if (l.isEmpty()) "" else "↓ " + fmtSp(d) + "  ↑ " + fmtSp(u)
        val want = HashSet<String>()
        var idx = 0
        for (t in l.sortedBy { if (it.finished) 1 else 0 }) {
            want.add(t.hash)
            val r = rows.getOrPut(t.hash) { mkRow() }
            fill(r, t)
            if (r.box.parent == null) list.addView(r.box, idx, lp(MATCH, WRAP, 0f, 10))
            else if (list.indexOfChild(r.box) != idx) { list.removeView(r.box); list.addView(r.box, idx, lp(MATCH, WRAP, 0f, 10)) }
            idx++
        }
        val it = rows.entries.iterator()
        while (it.hasNext()) { val e = it.next(); if (!want.contains(e.key)) { list.removeView(e.value.box); it.remove() } }
    }
    private fun mkRow(): Row {
        val box = card()
        val top = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val name = tv("", 14.5f, C.INK, true); val st = tv("", 12f, C.PRIMARY, true)
        top.addView(name, lp(0, WRAP, 1f)); top.addView(st)
        box.addView(top)
        val bar = ProgressBar(ctx, null, android.R.attr.progressBarStyleHorizontal).apply { max = 1000; progressTintList = android.content.res.ColorStateList.valueOf(C.PRIMARY) }
        box.addView(bar, lp(MATCH, px(6), 0f, 10))
        val info = tv("", 12f, C.SUB); box.addView(info, lp(MATCH, WRAP, 0f, 6))
        val btns = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        box.addView(btns, lp(MATCH, WRAP, 0f, 8))
        return Row(box, name, st, bar, info, btns)
    }
    private fun fill(r: Row, t: Magnet.Task) {
        r.name.text = t.name
        val label = when (t.state) { "down" -> if (t.down > 0) "下载中" else if (t.peers > 0) "等待数据" else "寻找节点"; "meta" -> "获取元数据"; "check" -> "校验中"
            "paused" -> "已暂停"; "done" -> "已完成"; "seed" -> "做种中"; "error" -> "失败"; else -> t.state }
        r.state.text = label
        r.state.setTextColor(when (t.state) { "error" -> C.BAD; "done", "seed" -> C.OK; "paused" -> C.SUB; else -> C.PRIMARY })
        val pct = if (t.total > 0) (t.done * 1000 / t.total).toInt().coerceIn(0, 1000) else 0
        r.bar.progress = if (t.finished) 1000 else pct
        r.info.text = when {
            t.state == "error" -> t.err.ifEmpty { "下载出错" }
            t.finished -> sz(t.total) + " · " + t.dir
            else -> String.format("%.1f%%", pct / 10.0) + " · " + sz(t.done) + " / " + (if (t.total > 0) sz(t.total) else "—") +
                (if (t.state == "down" || t.state == "seed") " · ↓" + fmtSp(t.down) + " ↑" + fmtSp(t.up) + " · 连接 " + t.peers + "（做种 " + t.seeds + "）" + (if (t.eta > 0) " · 剩余 " + fmtT(t.eta) else "") else "")
        }
        val sig = t.state
        if (r.sig != sig) {
            r.sig = sig; r.btns.removeAllViews()
            fun add(b: TextView) { r.btns.addView(b, lp(WRAP, WRAP).apply { rightMargin = px(8) }) }
            if (t.state == "paused") add(btn("继续", true) { thread { Magnet.resume(t.hash) } })
            else if (t.state == "down" || t.state == "meta" || t.state == "check") add(btn("暂停") { thread { Magnet.pause(t.hash) } })
            if (t.finished || t.state == "seed") add(btn("发送到设备", true) { onSend(t.files.map { File(it) }.filter { it.isFile }) })
            add(btn("删除") { confirmRemove(t) })
        }
    }
    private fun confirmRemove(t: Magnet.Task) {
        AlertDialog.Builder(ctx).setTitle("删除任务").setMessage(t.name + "\n要连同已下载的文件一起删除吗？")
            .setPositiveButton("同时删除文件") { _, _ -> thread { Magnet.remove(t.hash, true) } }
            .setNeutralButton("仅删除任务") { _, _ -> thread { Magnet.remove(t.hash, false) } }
            .setNegativeButton("取消", null).show()
    }
}
