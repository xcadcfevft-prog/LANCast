package com.lancast.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.content.ContextCompat

/**
 * 磁力下载的前台服务：有任务在下载 / 做种时保活进程，持有 CPU 唤醒锁和 Wi-Fi 高性能锁（息屏后不降速），
 * 通知栏显示总速度；没有活动任务时自动退出。进程被系统杀掉后 START_STICKY 会把它拉起来，引擎再按任务记录恢复。
 */
class MagnetService : Service() {
    companion object {
        private const val CH = "lancast_magnet"
        private const val NID = 5

        fun ensure(ctx: Context) {
            try { ContextCompat.startForegroundService(ctx, Intent(ctx, MagnetService::class.java)) } catch (ignored: Exception) { }
        }
    }

    private val ui = Handler(Looper.getMainLooper())
    private var wake: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null
    private var idle = 0
    private val tick = object : Runnable {
        override fun run() {
            Thread {
                val list = Magnet.tasks()
                val busy = Magnet.busy(list)
                Magnet.persist()
                ui.post {
                    if (busy) { idle = 0; notifyNow(list) } else if (++idle >= 5) { stopSelf(); return@post }
                    ui.postDelayed(this, 2000)
                }
            }.start()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Link.init(this)
        Magnet.start(this)
        try {
            wake = (getSystemService(Context.POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "lancast:magnet").apply { setReferenceCounted(false); acquire() }
            @Suppress("DEPRECATION")
            wifi = (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "lancast:magnet").apply { setReferenceCounted(false); acquire() }
        } catch (ignored: Exception) { }
        goForeground("磁力下载", "正在准备…")
        ui.post(tick)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        try { Magnet.persist(true) } catch (ignored: Exception) { }
        try { wake?.takeIf { it.isHeld }?.release() } catch (ignored: Exception) { }
        try { wifi?.takeIf { it.isHeld }?.release() } catch (ignored: Exception) { }
        super.onDestroy()
    }

    private fun fmt(n: Int): String = if (n >= 1 shl 20) String.format("%.1f MB/s", n / 1048576.0) else String.format("%d KB/s", n / 1024)

    private fun notifyNow(list: List<Magnet.Task>) {
        val act = list.count { it.state == "down" || it.state == "meta" || it.state == "check" }
        val (d, u) = Magnet.speeds(list)
        goForeground("磁力下载 · " + act + " 个任务", "↓ " + fmt(d) + "   ↑ " + fmt(u))
    }

    private fun goForeground(title: String, text: String) {
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CH, "磁力下载", NotificationManager.IMPORTANCE_LOW))
            val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java).putExtra("openMagnet", true), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val n = Notification.Builder(this, CH).setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle(title).setContentText(text).setContentIntent(pi).setOngoing(true).setOnlyAlertOnce(true).build()
            startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } catch (e: Exception) {
            stopSelf()
        }
    }
}
