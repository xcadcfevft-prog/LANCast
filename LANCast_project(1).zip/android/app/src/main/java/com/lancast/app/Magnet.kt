package com.lancast.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Environment
import com.frostwire.jlibtorrent.Priority
import com.frostwire.jlibtorrent.SessionManager
import com.frostwire.jlibtorrent.SessionParams
import com.frostwire.jlibtorrent.SettingsPack
import com.frostwire.jlibtorrent.Sha1Hash
import com.frostwire.jlibtorrent.SessionHandle
import com.frostwire.jlibtorrent.TorrentFlags
import com.frostwire.jlibtorrent.TorrentHandle
import com.frostwire.jlibtorrent.TorrentInfo
import com.frostwire.jlibtorrent.TorrentStatus
import com.frostwire.jlibtorrent.Vectors
import com.frostwire.jlibtorrent.AlertListener
import com.frostwire.jlibtorrent.alerts.Alert
import com.frostwire.jlibtorrent.alerts.AlertType
import com.frostwire.jlibtorrent.alerts.SaveResumeDataAlert
import com.frostwire.jlibtorrent.alerts.TorrentAlert
import com.frostwire.jlibtorrent.swig.add_torrent_params
import com.frostwire.jlibtorrent.swig.settings_pack
import com.frostwire.jlibtorrent.swig.torrent_flags_t
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/**
 * 磁力 / BT 下载引擎（安卓端）。内核：jlibtorrent（libtorrent 2.x 的 Java 绑定）。
 *
 * 支持：magnet 链接 / 40 位 Hash / 32 位 base32 Hash / .torrent 文件；DHT、PEX、LSD、Tracker（内置 + 在线更新）、
 *       uTP、协议加密（兼容模式）、UPnP / NAT-PMP、WebSeed、选择性下载、断点续传（重启后自动恢复）、做种（可选）。
 * 速度：默认不限速，连接数放大，所有 Tracker / Tier 同时 announce，DHT 路由表持久化（第二次起解析明显更快）。
 *
 * 流程：resolve()（取元数据，不下载内容）→ 用户勾选文件 → add()（开始下载）。任务记录存在 filesDir/magnet/，
 *       进程被杀、手机重启后由 [MagnetService] / 打开应用时自动恢复。
 * 所有公开方法都可以在任意线程调用；resolve() 会阻塞，请放在后台线程。
 */
object Magnet {
    class MFile(val index: Int, val path: String, val size: Long)
    class Meta(val hash: String, val name: String, val files: List<MFile>, val total: Long, val torrent: ByteArray)
    class Task(val hash: String) {
        var name = ""; var dir = ""; var total = 0L; var done = 0L; var down = 0; var up = 0
        var peers = 0; var seeds = 0; var state = "meta"; var err = ""; var eta = 0L
        var files: List<String> = emptyList()
        val finished: Boolean get() = state == "done"
    }

    private val BUILTIN = listOf(
        "udp://tracker.opentrackr.org:1337/announce", "udp://open.demonii.com:1337/announce", "udp://open.stealth.si:80/announce",
        "udp://tracker.torrent.eu.org:451/announce", "udp://exodus.desync.com:6969/announce", "udp://tracker.openbittorrent.com:6969/announce",
        "udp://explodie.org:6969/announce", "udp://tracker1.bt.moack.co.kr:80/announce", "udp://tracker.dler.org:6969/announce",
        "udp://open.tracker.cl:1337/announce", "udp://tracker.tiny-vps.com:6969/announce", "udp://opentracker.i2p.rocks:6969/announce",
        "udp://p4p.arenabg.com:1337/announce", "udp://tracker.theoks.net:6969/announce", "udp://tracker.bittor.pw:1337/announce",
        "udp://tracker-udp.gbitt.info:80/announce", "https://tracker.tamersunion.org:443/announce", "http://tracker.opentrackr.org:1337/announce"
    )
    private val SOURCES = listOf(
        "https://cdn.jsdelivr.net/gh/ngosang/trackerslist@master/trackers_best.txt",
        "https://raw.githubusercontent.com/ngosang/trackerslist/master/trackers_best.txt",
        "https://ghproxy.net/https://raw.githubusercontent.com/ngosang/trackerslist/master/trackers_best.txt"
    )

    private lateinit var app: Context
    private lateinit var store: File
    fun init(ctx: Context) { if (!::app.isInitialized) app = ctx.applicationContext }
    private var sm: SessionManager? = null
    private val records = LinkedHashMap<String, JSONObject>()     // hash -> 任务记录
    @Volatile var trackers: List<String> = BUILTIN
        private set
    private var lastStateSave = 0L
    private var lastResumeSave = 0L
    /** 任务完成时回调（主线程之外调用）。 */
    @Volatile var onFinished: ((Task) -> Unit)? = null

    private val prefs get() = Link.prefs

    /* ───────────── 设置 ───────────── */
    var downKb: Int
        get() = prefs.getInt("mag_down", 0)
        set(v) { prefs.edit().putInt("mag_down", v.coerceAtLeast(0)).apply(); applyLimits() }
    var upKb: Int
        get() = prefs.getInt("mag_up", 0)
        set(v) { prefs.edit().putInt("mag_up", v.coerceAtLeast(0)).apply(); applyLimits() }
    var seedAfter: Boolean
        get() = prefs.getBoolean("mag_seed", false)
        set(v) { prefs.edit().putBoolean("mag_seed", v).apply() }
    var publicDir: Boolean
        get() = prefs.getBoolean("mag_public", false)
        set(v) { prefs.edit().putBoolean("mag_public", v).apply() }

    fun canUsePublicDir(): Boolean = android.os.Build.VERSION.SDK_INT < 30 || Environment.isExternalStorageManager()

    /** 当前下载目录：应用专属目录（无需任何权限）或「下载/瞬流/磁力」（需要「所有文件访问」权限）。 */
    fun saveDir(): File {
        val d = if (publicDir && canUsePublicDir())
            File(File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "瞬流"), "磁力")
        else
            File(app.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: app.filesDir, "磁力")
        d.mkdirs()
        return d
    }

    fun dirLabel(): String = if (publicDir && canUsePublicDir()) "下载/瞬流/磁力" else "应用专属目录（文件管理器：Android/data/com.lancast.app/files/Download/磁力）"

    /* ───────────── 输入解析 ───────────── */
    private val MAGNET_RE = Regex("magnet:\\?[^\\s\"'<>]+", RegexOption.IGNORE_CASE)

    /** 从任意文本里找出磁力链接；也接受 40 位十六进制 / 32 位 base32 的 Hash。认不出返回 null。 */
    fun normalize(text: String): String? {
        val s = text.trim()
        MAGNET_RE.find(s)?.let { return it.value.trimEnd(')', ',', '.', ';') }
        val h = s.removePrefix("urn:btih:").removePrefix("btih:").trim()
        if (Regex("[0-9a-fA-F]{40}").matches(h)) return "magnet:?xt=urn:btih:" + h.lowercase()
        if (Regex("[A-Za-z2-7]{32}").matches(h)) return "magnet:?xt=urn:btih:" + h.uppercase()
        return null
    }

    private fun withTrackers(uri: String): String {
        val sb = StringBuilder(uri)
        val low = uri.lowercase()
        for (t in trackers.take(30)) {
            val enc = URLEncoder.encode(t, "UTF-8")
            if (!low.contains(enc.lowercase()) && !low.contains(t.lowercase())) sb.append("&tr=").append(enc)
        }
        return sb.toString()
    }

    /* ───────────── 启动 ───────────── */
    @Synchronized
    fun start(ctx: Context) {
        if (sm != null) return
        app = ctx.applicationContext
        store = File(app.filesDir, "magnet").apply { mkdirs() }
        loadRecords()
        loadTrackers()
        val s = SessionManager(false)
        val stateFile = File(store, "session.state")
        val params = try {
            if (stateFile.exists() && stateFile.length() > 0) SessionParams(stateFile.readBytes()) else SessionParams()
        } catch (e: Throwable) { SessionParams() }
        val sp: SettingsPack = params.getSettings()
        sp.connectionsLimit(800)                      // 总连接数放大（默认 200）
        sp.activeDownloads(6)
        sp.activeSeeds(4)
        sp.activeLimit(500)
        sp.setEnableDht(true)
        sp.setEnableLsd(true)
        sp.downloadRateLimit(downKb * 1024)           // 0 = 不限速
        sp.uploadRateLimit(upKb * 1024)
        sp.setBoolean(settings_pack.bool_types.announce_to_all_trackers.swigValue(), true)
        sp.setBoolean(settings_pack.bool_types.announce_to_all_tiers.swigValue(), true)
        sp.setBoolean(settings_pack.bool_types.enable_upnp.swigValue(), true)
        sp.setBoolean(settings_pack.bool_types.enable_natpmp.swigValue(), true)
        sp.setBoolean(settings_pack.bool_types.enable_outgoing_utp.swigValue(), true)
        sp.setBoolean(settings_pack.bool_types.enable_incoming_utp.swigValue(), true)
        params.setSettings(sp)
        s.addListener(listener)
        s.start(params)
        sm = s
        restore(s)
        refreshTrackers()
    }

    val started: Boolean get() = sm != null

    private fun applyLimits() {
        val s = sm ?: return
        try { s.downloadRateLimit(downKb * 1024); s.uploadRateLimit(upKb * 1024) } catch (ignored: Throwable) { }
    }

    /** 保存会话状态（DHT 路由表等）与各任务的续传数据；服务停止 / 应用退出前调用。 */
    fun persist(force: Boolean = false) {
        val s = sm ?: return
        val now = System.currentTimeMillis()
        try {
            if (force || now - lastStateSave > 120_000L) {
                lastStateSave = now
                s.saveState()?.let { File(store, "session.state").writeBytes(it) }
            }
            if (force || now - lastResumeSave > 30_000L) {
                lastResumeSave = now
                for (h in s.torrentHandles) if (h.isValid && records.containsKey(hashOf(h)) && h.needSaveResumeData()) h.saveResumeData()
            }
        } catch (ignored: Throwable) { }
    }

    /* ───────────── 事件：续传数据、暂停状态恢复 ───────────── */
    private val listener = object : AlertListener {
        override fun types(): IntArray? = intArrayOf(AlertType.SAVE_RESUME_DATA.swig(), AlertType.ADD_TORRENT.swig())
        override fun alert(alert: Alert<*>) {
            try {
                val t = alert.type()
                if (t == AlertType.SAVE_RESUME_DATA) {
                    val a = alert as SaveResumeDataAlert
                    val hash = hashOf(a.handle())
                    if (records.containsKey(hash)) {
                        val buf = add_torrent_params.write_resume_data_buf(a.params().swig())
                        File(store, "$hash.resume").writeBytes(Vectors.byte_vector2bytes(buf))
                    }
                } else if (t == AlertType.ADD_TORRENT) {
                    val h = (alert as TorrentAlert<*>).handle()
                    val rec = records[hashOf(h)] ?: return
                    try { h.prioritizeFiles(prioritiesOf(rec, h.torrentFile().numFiles())) } catch (ignored: Throwable) { }   // 选择性下载：新任务在这里落实文件优先级
                    if (rec.optBoolean("paused")) { h.unsetFlags(TorrentFlags.AUTO_MANAGED); h.pause() }
                }
            } catch (ignored: Throwable) { }
        }
    }

    private fun hashOf(h: TorrentHandle): String = try { h.infoHash().toHex().lowercase() } catch (e: Throwable) { "" }

    /* ───────────── 任务记录 ───────────── */
    @Synchronized
    private fun loadRecords() {
        records.clear()
        try {
            val f = File(store, "tasks.json")
            if (f.exists()) {
                val a = JSONArray(f.readText())
                for (i in 0 until a.length()) { val o = a.getJSONObject(i); records[o.getString("hash")] = o }
            }
        } catch (ignored: Throwable) { }
    }

    @Synchronized
    private fun saveRecords() {
        try {
            val a = JSONArray(); for (o in records.values) a.put(o)
            File(store, "tasks.json").writeText(a.toString())
        } catch (ignored: Throwable) { }
    }

    private fun restore(s: SessionManager) {
        for (rec in records.values.toList()) {
            if (rec.optBoolean("done") && !seedAfter) continue
            try {
                val hash = rec.getString("hash")
                val tf = File(store, "$hash.torrent"); if (!tf.exists()) continue
                val ti = TorrentInfo.bdecode(tf.readBytes())
                s.download(ti, File(rec.getString("dir")), File(store, "$hash.resume"), prioritiesOf(rec, ti.numFiles()), null, torrent_flags_t())
            } catch (ignored: Throwable) { rec.put("err", "恢复失败：" + ignored.message) }
        }
    }

    private fun prioritiesOf(rec: JSONObject, n: Int): Array<Priority> {
        val sel = HashSet<Int>(); val a = rec.optJSONArray("sel")
        if (a != null) for (i in 0 until a.length()) sel.add(a.getInt(i))
        val all = a == null || a.length() == 0
        return Array(n) { if (all || sel.contains(it)) Priority.NORMAL else Priority.IGNORE }
    }

    /* ───────────── 解析（阻塞，放后台线程） ───────────── */
    /** 取磁力链接的元数据。cancelled() 为 true 时尽快返回 null；最长约 5 分钟。出错抛 IllegalArgumentException。 */
    fun resolve(uri: String, cancelled: () -> Boolean): Meta? {
        val s = sm ?: throw IllegalStateException("下载引擎还没启动")
        val full = withTrackers(uri)
        val tmp = File(app.cacheDir, "magnet-tmp").apply { mkdirs() }
        var bytes: ByteArray? = null
        var i = 0
        while (bytes == null && !cancelled() && i < 10) {
            bytes = s.fetchMagnet(full, if (i == 0) 45 else 30, tmp)       // 每轮失败后重试：DHT 路由表越用越热
            i++
        }
        if (bytes == null || cancelled()) return null
        return metaOf(bytes)
    }

    fun resolveTorrent(data: ByteArray): Meta {
        if (data.isEmpty() || data[0] != 'd'.code.toByte()) throw IllegalArgumentException("这不是有效的 .torrent 文件")
        return metaOf(data)
    }

    private fun metaOf(bytes: ByteArray): Meta {
        val ti = TorrentInfo.bdecode(bytes)
        val fs = ti.files()
        val list = ArrayList<MFile>()
        for (i in 0 until fs.numFiles()) {
            if (fs.padFileAt(i)) continue
            list.add(MFile(i, fs.filePath(i), fs.fileSize(i)))
        }
        return Meta(ti.infoHashV1().toHex().lowercase(), ti.name(), list, list.sumOf { it.size }, bytes)
    }

    /* ───────────── 开始 / 暂停 / 删除 ───────────── */
    /** 开始下载 meta 里被勾选（index 在 selected 里）的文件，保存到 dir。 */
    fun add(meta: Meta, dir: File, selected: Set<Int>) {
        val s = sm ?: throw IllegalStateException("下载引擎还没启动")
        if (records[meta.hash]?.optBoolean("done") == false) throw IllegalArgumentException("这个任务已经在列表里了")
        val ti = TorrentInfo.bdecode(meta.torrent)
        val fs = ti.files()
        val picked = meta.files.filter { selected.contains(it.index) }
        if (picked.isEmpty()) throw IllegalArgumentException("没有选择任何文件")
        dir.mkdirs()
        File(store, "${meta.hash}.torrent").writeBytes(meta.torrent)
        File(store, "${meta.hash}.resume").delete()
        val rec = JSONObject().put("hash", meta.hash).put("name", meta.name).put("dir", dir.absolutePath)
            .put("sel", JSONArray(selected.toList())).put("total", picked.sumOf { it.size }).put("done", false).put("paused", false)
            .put("ts", System.currentTimeMillis())
            .put("files", JSONArray(picked.map { File(dir, fs.filePath(it.index)).absolutePath }))
        synchronized(this) { records[meta.hash] = rec }
        saveRecords()
        s.download(ti, dir, null, prioritiesOf(rec, ti.numFiles()), null, torrent_flags_t())
    }

    private fun handleOf(hash: String): TorrentHandle? {
        val s = sm ?: return null
        return s.torrentHandles.firstOrNull { it.isValid && hashOf(it) == hash }
    }

    fun pause(hash: String) {
        records[hash]?.put("paused", true); saveRecords()
        handleOf(hash)?.let { it.unsetFlags(TorrentFlags.AUTO_MANAGED); it.pause(); it.saveResumeData() }
    }

    fun resume(hash: String) {
        records[hash]?.put("paused", false); saveRecords()
        val h = handleOf(hash)
        if (h != null) { h.setFlags(TorrentFlags.AUTO_MANAGED); h.resume(); h.forceReannounce(); h.forceDHTAnnounce() }
        else restoreOne(hash)
    }

    private fun restoreOne(hash: String) {
        val s = sm ?: return; val rec = records[hash] ?: return
        try {
            val ti = TorrentInfo.bdecode(File(store, "$hash.torrent").readBytes())
            s.download(ti, File(rec.getString("dir")), File(store, "$hash.resume"), prioritiesOf(rec, ti.numFiles()), null, torrent_flags_t())
        } catch (ignored: Throwable) { }
    }

    fun remove(hash: String, withFiles: Boolean) {
        val s = sm ?: return
        val rec = records[hash]
        val h = handleOf(hash)
        if (h != null) { if (withFiles) s.remove(h, SessionHandle.DELETE_FILES) else s.remove(h) }
        else if (withFiles && rec != null) {                         // 已完成、不在会话里的任务：自己删文件（只删任务目录内的）
            val root = File(rec.optString("dir")).canonicalFile
            val a = rec.optJSONArray("files")
            if (a != null) for (i in 0 until a.length()) {
                val f = File(a.getString(i)).canonicalFile
                if (f.path.startsWith(root.path + File.separator)) f.delete()
            }
        }
        synchronized(this) { records.remove(hash) }
        saveRecords()
        File(store, "$hash.torrent").delete(); File(store, "$hash.resume").delete()
    }

    /** 清除记录里所有已完成的任务（不删文件）。 */
    fun clearFinished() {
        for (rec in records.values.toList()) if (rec.optBoolean("done")) remove(rec.getString("hash"), false)
    }

    /* ───────────── 任务列表（UI / 服务每秒调用） ───────────── */
    fun tasks(): List<Task> {
        val s = sm ?: return emptyList()
        val live = HashMap<String, TorrentHandle>()
        for (h in s.torrentHandles) if (h.isValid) live[hashOf(h)] = h
        val out = ArrayList<Task>()
        for (rec in records.values.toList()) {
            val hash = rec.getString("hash")
            val t = Task(hash)
            t.name = rec.optString("name"); t.dir = rec.optString("dir"); t.total = rec.optLong("total")
            val fa = rec.optJSONArray("files"); val fl = ArrayList<String>()
            if (fa != null) for (i in 0 until fa.length()) fl.add(fa.getString(i))
            t.files = fl
            val h = live[hash]
            if (rec.optBoolean("done")) {
                t.done = t.total
                if (h != null && seedAfter) fill(t, h.status(), true) else t.state = "done"
                t.done = t.total
            } else if (h != null) {
                fill(t, h.status(), false)
                if (t.state == "done" || t.state == "seed") finish(rec, t, h)
            } else {
                t.state = if (rec.optBoolean("paused")) "paused" else "meta"
                t.err = rec.optString("err")
                if (t.err.isNotEmpty()) t.state = "error"
            }
            out.add(t)
        }
        return out
    }

    private fun fill(t: Task, st: TorrentStatus, seeding: Boolean) {
        t.total = if (st.totalWanted() > 0) st.totalWanted() else t.total
        t.done = st.totalWantedDone()
        t.down = st.downloadPayloadRate(); t.up = st.uploadPayloadRate()
        t.peers = st.numPeers(); t.seeds = st.numSeeds()
        val paused = st.flags().and_(TorrentFlags.PAUSED).nonZero() && !st.flags().and_(TorrentFlags.AUTO_MANAGED).nonZero()
        t.state = when {
            st.errorCode().isError -> "error"
            paused -> "paused"
            seeding || st.isSeeding -> "seed"
            st.isFinished -> "done"
            st.state() == TorrentStatus.State.CHECKING_FILES || st.state() == TorrentStatus.State.CHECKING_RESUME_DATA -> "check"
            st.state() == TorrentStatus.State.DOWNLOADING_METADATA -> "meta"
            else -> "down"
        }
        if (t.state == "error") t.err = st.errorCode().message()
        t.eta = if (t.down > 0 && t.total > t.done) (t.total - t.done) / t.down else 0L
    }

    /** 下载完成：写记录、通知；不做种就把任务从会话里移走（文件保留），释放连接和队列位置。 */
    private fun finish(rec: JSONObject, t: Task, h: TorrentHandle) {
        rec.put("done", true); saveRecords()
        File(store, "${t.hash}.resume").delete()
        if (!seedAfter) { try { sm?.remove(h) } catch (ignored: Throwable) { } }
        try { notifyDone(t) } catch (ignored: Throwable) { }
        try { onFinished?.invoke(t) } catch (ignored: Throwable) { }
        t.done = t.total
    }

    private fun notifyDone(t: Task) {
        val nm = app.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("lancast_magnet_done", "磁力下载完成", NotificationManager.IMPORTANCE_DEFAULT))
        val open = android.content.Intent(app, MainActivity::class.java).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK or android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("openMagnet", true)
        val pi = android.app.PendingIntent.getActivity(app, 7, open, android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT)
        val n = Notification.Builder(app, "lancast_magnet_done").setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("下载完成").setContentText(t.name).setContentIntent(pi).setAutoCancel(true).build()
        nm.notify(2000 + (t.hash.hashCode() and 0xFFF), n)
    }

    /** 是否还有在下载 / 排队 / 做种 / 解析中的任务（前台服务据此决定要不要继续保活）。 */
    fun busy(list: List<Task> = tasks()): Boolean = list.any { it.state == "down" || it.state == "meta" || it.state == "check" || it.state == "seed" }

    fun speeds(list: List<Task>): Pair<Int, Int> = Pair(list.sumOf { it.down }, list.sumOf { it.up })

    /* ───────────── Tracker 列表（失败不影响使用） ───────────── */
    private fun loadTrackers() {
        try {
            val f = File(store, "trackers.txt")
            if (f.exists()) {
                val l = f.readLines().map { it.trim() }.filter { it.matches(Regex("^(udp|http|https|ws|wss)://.+")) }.distinct()
                if (l.size >= 5) trackers = l
            }
        } catch (ignored: Throwable) { }
    }

    private fun refreshTrackers() {
        val f = File(store, "trackers.txt")
        if (f.exists() && System.currentTimeMillis() - f.lastModified() < 24 * 3600_000L) return
        Thread {
            for (u in SOURCES) {
                try {
                    val c = URL(u).openConnection() as HttpURLConnection
                    c.connectTimeout = 8000; c.readTimeout = 8000
                    val text = c.inputStream.bufferedReader().use { it.readText() }
                    val l = text.split(Regex("\\s+")).map { it.trim() }.filter { it.matches(Regex("^(udp|http|https|ws|wss)://.+")) }.distinct()
                    if (l.size >= 5) { f.writeText(l.joinToString("\n")); trackers = l; return@Thread }
                } catch (ignored: Throwable) { }
            }
        }.apply { isDaemon = true; name = "mag-trackers" }.start()
    }
}
