package com.lancast.app

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.ConnectivityManager
import android.net.Network
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import org.json.JSONObject
import java.nio.ByteBuffer
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/**
 * 沉浸音乐（手机端）—— 把手机正在播放的声音（无损 PCM）+ 歌曲信息实时发给电脑，电脑渲染成播放器，并可反向控制手机播放。规范见 docs/PROTOCOL.md 第 23 节。
 *
 * 为什么息屏不会断：
 *   · 全程没有屏幕采集（不建 VirtualDisplay），只用 MediaProjection 里的「系统播放声音采集」；
 *   · 跑在 mediaProjection 类型的前台服务里 + 常驻通知，进程不会被系统当作后台应用回收；
 *   · 持有 CPU 唤醒锁和两把 Wi-Fi 锁，息屏后 Wi-Fi 不会打盹；
 *   · 设置界面会引导用户把瞬流设为「不受电池优化限制」，这样 Doze（息屏静止后的省电模式）也不会掐掉网络。
 *
 * 连接保活（任何一环断了音乐都不中断）：
 *   · 采集线程独立于网络：连接断开期间照常采集，音频存在 90 秒的环形缓冲里（MusicRing）；
 *   · 连接断开（8 秒没收到任何数据 / 网络切换 / 对方重启）立刻自动重连，退避 0.3 → 4 秒封顶，永不放弃，直到用户在任一端结束；
 *   · 重连后电脑回报「从第 N 帧继续」，缓冲里没送达的部分补发，电脑端按帧序号去重对齐，所以不丢、不重、不错位；
 *   · 系统层 TCP keepalive + 应用层 PING（1 秒）+ 歌曲进度心跳（1 秒）+ 电脑端的确认包（0.5 秒）多重心跳；
 *   · 监听网络切换（Wi-Fi ↔ 移动数据 ↔ 虚拟局域网）：默认网络一变就立刻断开旧连接、走新路径重连，而不是干等超时（并跳过退避等待，立刻重试）。
 *
 * 看门狗（music-dog，每 2 秒）：
 *   · 采集 4 秒没有任何数据（被别的 App 抢了音频焦点 / 系统回收了采集器）→ 停掉旧 AudioRecord，采集线程自动重建，最多连续重试 6 次；
 *   · 唤醒锁 / Wi-Fi 锁被系统悄悄释放 → 立刻重新持有；
 *   · 连上了但电脑 10 秒都没确认（半死连接）→ 主动断开重连；
 *   · 前台通知被用户划掉 / 被系统清掉 → 每 10 秒重新发布，保证前台服务的身份不丢。
 */
class MusicService : Service() {

    companion object {
        private const val CH = "lancast_music"
        private const val NID = 5
        private const val RATE = 48000
        private const val CHUNK_FRAMES = 1920                 // 40 ms
        private const val RING_SECONDS = 90L
        private const val IDLE_MS = 8000L

        @Volatile var current: MusicService? = null
        fun running(): Boolean = current != null

        fun stop(ctx: Context) {
            try { ctx.startService(Intent(ctx, MusicService::class.java).setAction("stop")) } catch (ignored: Exception) { }
        }
    }

    /** 一条到电脑的连接。ready = 电脑已回报「从第几帧开始」 */
    private class Conn(val s: Session) {
        @Volatile var ready = false
        @Volatile var sendIdx = 0L
        @Volatile var cfgSent = false
        @Volatile var coverKey = ""
        val born = SystemClock.elapsedRealtime()
        val closed = CountDownLatch(1)
    }

    private val main = Handler(Looper.getMainLooper())
    private val sid = P.randomHex(8)
    private val ring = MusicRing(RATE * RING_SECONDS)
    private val audioLock = Object()
    private val metaLock = Object()
    @Volatile private var metaDirty = true
    @Volatile private var running = false
    @Volatile private var conn: Conn? = null
    @Volatile private var reconnects = 0
    @Volatile private var capAt = 0L
    @Volatile private var kickLink = false
    private val linkLock = Object()
    private var lastText = ""
    private var chReady = false
    @Volatile private var proj: MediaProjection? = null
    @Volatile private var rec: AudioRecord? = null
    @Volatile private var meta: MusicMeta? = null
    private var netCb: ConnectivityManager.NetworkCallback? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var host = ""
    private var port = P.PORT
    private var pin = ""
    private var peerName = ""
    private var finished = false
    private val coverCache = HashMap<String, ByteArray>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i == null) { stopSelf(); return START_NOT_STICKY }
        if (i.action == "stop") { shutdown("已在手机上结束", true); return START_NOT_STICKY }
        if (running) return START_NOT_STICKY
        restoreStaleMute()
        current = this
        running = true
        finished = false
        host = i.getStringExtra("host") ?: ""
        port = i.getIntExtra("port", P.PORT)
        pin = i.getStringExtra("pin") ?: ""
        peerName = i.getStringExtra("peer") ?: "电脑"
        val code = i.getIntExtra("code", 0)
        val data = readIntent(i)
        notifyState("正在启动…")
        grabLocks()
        thread(name = "music-start", isDaemon = true) {
            try {
                if (data == null) throw IllegalStateException("没有拿到录制授权")
                val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                val p = mpm.getMediaProjection(code, data)
                p.registerCallback(object : MediaProjection.Callback() {
                    override fun onStop() { main.post { shutdown("系统收回了音频采集授权", true) } }
                }, main)
                proj = p
                startCapture(p)
                val m = MusicMeta(applicationContext) { kickMeta() }
                meta = m
                m.start()
                LyricTap.sink = { pkg, line -> sendLyric(m, pkg, line) }
                watchNet()
                thread(name = "music-link", isDaemon = true) { linkLoop() }
                thread(name = "music-write", isDaemon = true) { writeLoop() }
                thread(name = "music-meta", isDaemon = true) { metaLoop() }
                thread(name = "music-dog", isDaemon = true) { watchdog() }
            } catch (e: Exception) {
                shutdown("启动失败：${e.message}", false)
            }
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun readIntent(i: Intent): Intent? =
        if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra("data", Intent::class.java) else i.getParcelableExtra("data")

    /* ───────────── 保活：唤醒锁 / Wi-Fi 锁 ───────────── */
    @SuppressLint("WakelockTimeout")
    private fun grabLocks() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "lancast:music").apply { setReferenceCounted(false); acquire() }   // 不设超时：播多久持有多久，结束时一定释放
        } catch (ignored: Exception) { }
        Link.holdWifi(true)
    }

    private fun releaseLocks() {
        try { if (wakeLock?.isHeld == true) wakeLock?.release() } catch (ignored: Exception) { }
        wakeLock = null
        if (!Link.busy) Link.holdWifi(false)
    }

    /* ───────────── 采集：系统播放的声音（原始 PCM，不转码）───────────── */
    @SuppressLint("MissingPermission")
    private fun buildRecord(p: MediaProjection): AudioRecord {
        val cfg = AudioPlaybackCaptureConfiguration.Builder(p)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .build()
        val fmt = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(RATE)
            .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
            .build()
        val minBuf = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
        val r = AudioRecord.Builder()
            .setAudioFormat(fmt)
            .setBufferSizeInBytes(maxOf(minBuf * 4, RATE / 2 * 4))       // 500 ms：采集线程被系统调度延迟几百毫秒也不丢样本
            .setAudioPlaybackCaptureConfig(cfg)
            .build()
        r.startRecording()
        return r
    }

    private fun startCapture(p: MediaProjection) {
        rec = buildRecord(p)
        capAt = SystemClock.elapsedRealtime()
        thread(name = "music-cap", isDaemon = true) {
            val buf = ByteArray(CHUNK_FRAMES * MusicRing.FRAME_BYTES)
            var fails = 0
            while (running) {
                try {
                    val r = rec ?: throw IllegalStateException("采集器不存在")
                    if (r.recordingState != AudioRecord.RECORDSTATE_RECORDING) throw IllegalStateException("采集已停止")
                    val n = r.read(buf, 0, buf.size, AudioRecord.READ_BLOCKING)
                    if (n < 0) throw IllegalStateException("AudioRecord 错误 $n")
                    capAt = SystemClock.elapsedRealtime()
                    fails = 0
                    val nn = n - n % MusicRing.FRAME_BYTES
                    if (nn <= 0) continue
                    ring.append(if (MusicRing.isSilent(buf, nn)) null else buf.copyOf(nn), nn / MusicRing.FRAME_BYTES)
                    synchronized(audioLock) { audioLock.notifyAll() }
                } catch (e: Exception) {
                    if (!running) break
                    if (++fails > 6) { main.post { shutdown("声音采集反复中断：${e.message}", true) }; break }
                    updateStatus("声音采集中断，正在恢复…（${e.message}）")
                    try { Thread.sleep(300L * fails) } catch (ignored: InterruptedException) { }
                    try {                                                  // 重建采集器：旧的释放掉，用同一个录制授权再建一个
                        try { rec?.stop() } catch (ignored: Exception) { }
                        try { rec?.release() } catch (ignored: Exception) { }
                        rec = null
                        val p2 = proj ?: break
                        rec = buildRecord(p2)
                        capAt = SystemClock.elapsedRealtime()
                    } catch (e2: Exception) { /* 下一轮继续重试 */ }
                }
            }
        }
    }

    /* ───────────── 手机静音 ─────────────
     * 把「媒体音量」压到 0：手机喇叭 / 耳机不再出声，但 AudioPlaybackCapture 抓的是应用输出的数据流（在系统音量之前），电脑照常收到完整音频，
     * 电脑端音量由电脑自己调。Android 没有给第三方 App 的「只静音某一个 App」接口，所以静音的是媒体音量（来电、闹钟、通知音不受影响）；
     * 当前正在播放的 App 名称（meta.app）显示在电脑端按钮提示里。进程被杀时上一次的音量存在偏好里，下次启动会还原。 */
    private fun prefs() = getSharedPreferences("music_mute", Context.MODE_PRIVATE)


    private fun restoreStaleMute() {
        try {
            val prev = prefs().getInt("prev", -1)
            if (prev > 0) {
                val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                if (am.getStreamVolume(AudioManager.STREAM_MUSIC) == 0) am.setStreamVolume(AudioManager.STREAM_MUSIC, prev, 0)
                prefs().edit().remove("prev").apply()
            }
        } catch (ignored: Exception) { }
    }

    /* ───────────── 看门狗 ───────────── */
    @SuppressLint("WakelockTimeout")
    private fun watchdog() {
        var n = 0
        while (running) {
            try { Thread.sleep(2000) } catch (ignored: InterruptedException) { }
            if (!running) break
            n++
            try {
                if (SystemClock.elapsedRealtime() - capAt > 4000) { try { rec?.stop() } catch (ignored: Exception) { }; capAt = SystemClock.elapsedRealtime() }   // 逼采集线程的阻塞读报错，进入重建流程
                if (wakeLock?.isHeld != true) wakeLock?.acquire()
                Link.holdWifi(true)
                val c = conn
                if (c != null && !c.ready && SystemClock.elapsedRealtime() - c.born > 10000) drop("电脑没有确认")
                if (n % 5 == 0 && lastText.isNotEmpty()) notifyState(lastText)
            } catch (ignored: Exception) { }
        }
    }

    /* ───────────── 连接：永不放弃的重连循环 ───────────── */
    private fun linkLoop() {
        var backoff = 300L
        var everConnected = false
        while (running) {
            var c: Conn? = null
            try {
                updateStatus(if (everConnected) "连接中断，正在重连…" else "正在连接电脑…")
                val s = Session.connect(host, port, pin, "music", Link.name, "", JSONObject().put("sid", sid))
                s.fixedIdleMs = IDLE_MS
                val cc = Conn(s)
                c = cc
                conn = cc
                s.start(object : SessionHandler {
                    override fun onPacket(s: Session, p: Pkt) = handlePacket(cc, p)
                    override fun onClosed(s: Session, reason: String) { cc.closed.countDown() }
                })
                if (everConnected) reconnects++
                everConnected = true
                backoff = 300L
                updateStatus(if (reconnects > 0) "已重新连上（累计重连 $reconnects 次）" else "已连接")
                synchronized(metaLock) { metaDirty = true; metaLock.notifyAll() }
                // 等到断开；这期间采集、缓冲照常进行
                while (running && !cc.closed.await(1, TimeUnit.SECONDS)) { }
            } catch (e: Exception) {
                val msg = e.message ?: ""
                if (msg.contains("配对已失效") || msg.contains("身份校验")) {          // 密钥不对 / 对方不是原来那台：重试没有意义
                    main.post { shutdown("连接被拒绝：$msg", false) }
                    return
                }
                updateStatus("连不上电脑，重试中…（$msg）")
            }
            if (conn === c) conn = null
            try { c?.s?.close("重连") } catch (ignored: Exception) { }
            if (!running) break
            val kicked = synchronized(linkLock) {
                if (!kickLink) try { linkLock.wait(backoff) } catch (ignored: InterruptedException) { }
                val k = kickLink; kickLink = false; k
            }
            backoff = if (kicked) 300L else minOf(backoff * 2, 4000L)        // 网络刚变过：别再按旧的退避等了，马上重试
        }
    }

    private fun handlePacket(c: Conn, p: Pkt) {
        try {
            when (p.type) {
                P.T_CTRL -> {
                    val j = p.json()
                    when (j.optString("cmd")) {
                        "mack" -> {
                            val next = j.optLong("next", 0L)
                            if (!c.ready) {                                                       // 每条连接的第一个确认：决定从哪一帧开始发
                                c.sendIdx = if (j.optBoolean("fresh", false)) ring.next() else maxOf(next, ring.oldest())
                                c.ready = true
                                synchronized(audioLock) { audioLock.notifyAll() }
                            }
                            ring.trimTo(if (j.optBoolean("fresh", false)) c.sendIdx else next)
                        }
                        "mstop" -> main.post { shutdown("电脑端结束了沉浸音乐", false) }
                    }
                }
                P.T_MUSIC_CMD -> {
                    val j = p.json()
                    meta?.command(j.optString("cmd"), j.optLong("pos", 0L))
                    kickMeta()
                }
            }
        } catch (ignored: Exception) { }
    }

    /* ───────────── 发送：按帧序号从缓冲里取，跟得上就实时，落后就补发 ───────────── */
    private fun writeLoop() {
        while (running) {
            val c = conn
            if (c == null || !c.ready || !c.s.alive) {
                try { Thread.sleep(20) } catch (ignored: InterruptedException) { }
                continue
            }
            try {
                if (!c.cfgSent) {
                    c.s.sendHi(P.jsonPkt(P.T_ACONFIG, JSONObject().put("rate", RATE).put("ch", 2).put("fmt", "s16").put("music", 1).put("sid", sid)))
                    c.cfgSent = true
                }
                if (c.s.hiQueued() > 256 * 1024) {                                               // 网络跟不上：别往内存里堆，留在环形缓冲里等
                    try { Thread.sleep(5) } catch (ignored: InterruptedException) { }
                    continue
                }
                val ch = ring.take(c.sendIdx)
                if (ch == null) {
                    synchronized(audioLock) { audioLock.wait(30) }
                    continue
                }
                val d = ch.data
                if (d == null) {
                    val pkt = P.newPkt(P.T_ADATA, 1, ch.start, 4)
                    ByteBuffer.wrap(pkt).putInt(P.HDR, ch.frames)
                    c.s.sendHi(pkt)
                } else {
                    val pkt = P.newPkt(P.T_ADATA, 0, ch.start, d.size)
                    System.arraycopy(d, 0, pkt, P.HDR, d.size)
                    c.s.sendHi(pkt)
                }
                c.sendIdx = ch.start + ch.frames
            } catch (e: Exception) {
                try { Thread.sleep(50) } catch (ignored: InterruptedException) { }
            }
        }
    }

    /* ───────────── 歌曲信息：有变化立即发，没变化也每秒发一次（进度 + 应用层心跳）───────────── */
    /** 音乐 App 的「状态栏歌词」通知来了一句：带上当时的播放位置发给电脑（只发正在被控制的那个 App 的） */
    private fun sendLyric(m: MusicMeta, pkg: String, line: String) {
        val c = conn
        if (c == null || !c.ready || !c.s.alive || pkg.isEmpty() || pkg != m.currentPkg()) return
        try {
            val j = m.lyricStamp()
            j.put("sid", sid).put("line", line).put("pkg", pkg)
            c.s.sendHi(P.jsonPkt(P.T_MUSIC_LYRIC, j))
        } catch (ignored: Exception) { }
    }

    private fun kickMeta() { synchronized(metaLock) { metaDirty = true; metaLock.notifyAll() } }

    private fun metaLoop() {
        var tick = 0
        while (running) {
            synchronized(metaLock) { if (!metaDirty) try { metaLock.wait(1000) } catch (ignored: InterruptedException) { }; metaDirty = false }
            val c = conn
            if (c == null || !c.ready || !c.s.alive) continue
            try {
                if (++tick % 5 == 0) meta?.refresh()
                val m = meta
                val snap = m?.snapshot()
                val j = snap?.json ?: JSONObject().put("state", "none").put("title", "").put("ctl", false)
                j.put("sid", sid)
                if (snap != null && snap.coverKey.isEmpty()) c.coverKey = ""
                if (snap != null && snap.coverKey.isNotEmpty() && snap.cover != null && c.coverKey != snap.coverKey) {
                    val png = coverCache[snap.coverKey] ?: encodeCover(snap.cover)?.also { if (coverCache.size > 8) coverCache.clear(); coverCache[snap.coverKey] = it }
                    if (png != null) {
                        val pkt = P.newPkt(P.T_MUSIC_COVER, 0, 0, 16 + png.size)
                        System.arraycopy(snap.coverKey.toByteArray(Charsets.US_ASCII), 0, pkt, P.HDR, 16)
                        System.arraycopy(png, 0, pkt, P.HDR + 16, png.size)
                        c.s.sendHi(pkt)
                    }
                    c.coverKey = snap.coverKey
                }
                c.s.sendHi(P.jsonPkt(P.T_MUSIC_META, j))
                if (tick % 2 == 0) updateNotif(j)
            } catch (ignored: Exception) { }
        }
    }

    /* ───────────── 网络切换：马上断开旧连接，走新路径重连 ───────────── */
    private fun watchNet() {
        try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            var first = true
            val cb = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) { if (first) { first = false; return }; drop("网络切换"); kick() }
                override fun onLost(network: Network) { first = false; drop("网络断开") }
            }
            cm.registerDefaultNetworkCallback(cb)
            netCb = cb
        } catch (ignored: Exception) { }
    }

    private fun kick() { synchronized(linkLock) { kickLink = true; linkLock.notifyAll() } }

    private fun drop(why: String) {
        val c = conn ?: return
        thread(isDaemon = true) { try { c.s.close(why) } catch (ignored: Exception) { } }
    }

    /* ───────────── 结束 ───────────── */
    @Synchronized
    private fun shutdown(reason: String, tellPeer: Boolean) {
        if (finished) return
        finished = true
        running = false
        val c = conn
        if (tellPeer && c != null) {
            try { c.s.sendHi(P.jsonPkt(P.T_CTRL, JSONObject().put("cmd", "mstop"))) } catch (ignored: Exception) { }
            thread(isDaemon = true) { try { Thread.sleep(300) } catch (ignored: InterruptedException) { }; try { c.s.close("结束") } catch (ignored: Exception) { } }
        } else {
            try { c?.s?.close("结束") } catch (ignored: Exception) { }
        }
        conn = null
        synchronized(audioLock) { audioLock.notifyAll() }
        synchronized(metaLock) { metaLock.notifyAll() }
        synchronized(linkLock) { linkLock.notifyAll() }
        try { rec?.stop() } catch (ignored: Exception) { }
        try { rec?.release() } catch (ignored: Exception) { }
        rec = null
        LyricTap.sink = null
        try { meta?.stop() } catch (ignored: Exception) { }
        try { netCb?.let { (getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager).unregisterNetworkCallback(it) } } catch (ignored: Exception) { }
        netCb = null
        try { proj?.stop() } catch (ignored: Exception) { }
        proj = null
        releaseLocks()
        Link.status("沉浸音乐已结束：$reason")
        current = null
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (ignored: Exception) { }
        stopSelf()
    }

    override fun onTaskRemoved(rootIntent: Intent?) { /* 用户把瞬流Pro从最近任务里划掉：沉浸音乐继续播（前台服务不受影响），只能通过通知上的「结束」或电脑端结束 */ }

    override fun onDestroy() {
        if (!finished) shutdown("服务被系统停止", false)
        super.onDestroy()
    }

    /* ───────────── 通知 / 状态 ───────────── */
    private var lastStatus = ""
    private fun updateStatus(s: String) {
        if (s == lastStatus) return
        lastStatus = s
        Link.status("沉浸音乐：$s")
        notifyState(s)
    }

    private var lastNotifAt = 0L
    private fun updateNotif(j: JSONObject) {
        val now = System.currentTimeMillis()
        if (now - lastNotifAt < 4000) return
        lastNotifAt = now
        val t = j.optString("title")
        notifyState(if (t.isNotEmpty()) "$t · ${j.optString("artist")}" else lastStatus)
    }

    private fun notifyState(text: String) {
        lastText = text
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (!chReady) { nm.createNotificationChannel(NotificationChannel(CH, "沉浸音乐", NotificationManager.IMPORTANCE_LOW)); chReady = true }
            val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            val stop = PendingIntent.getService(this, 4, Intent(this, MusicService::class.java).setAction("stop"), PendingIntent.FLAG_IMMUTABLE)
            val n = Notification.Builder(this, CH)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle("瞬流Pro 沉浸音乐 → $peerName")
                .setContentText(text)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, "结束", stop)
                .setContentIntent(pi)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setCategory(Notification.CATEGORY_TRANSPORT)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .apply { if (Build.VERSION.SDK_INT >= 31) setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE) }
                .build()
            if (!finished && !fgStarted) {
                startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
                fgStarted = true
            } else if (!finished) nm.notify(NID, n)
        } catch (ignored: Exception) { }
    }

    private var fgStarted = false
}
