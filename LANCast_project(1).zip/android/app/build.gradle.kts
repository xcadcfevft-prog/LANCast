plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.lancast.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.lancast.app"
        minSdk = 29            // AudioPlaybackCapture(无损采集系统声音) 需要 Android 10+
        targetSdk = 34
        versionCode = 2
        versionName = "1.1"
        ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }     // jlibtorrent 原生库只带真机架构
    }
    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // 磁力 / BT 下载引擎：jlibtorrent（libtorrent 2.x）。换版本只改 jlt；原生库按真机架构各一个包
    val jlt = "2.0.12.7"
    implementation("com.frostwire:jlibtorrent:$jlt")
    implementation("com.frostwire:jlibtorrent-android-arm64:$jlt")
    implementation("com.frostwire:jlibtorrent-android-arm:$jlt")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-ktx:1.9.2")
    implementation("com.journeyapps:zxing-android-embedded:4.3.0")   // 扫码（自带取景界面，不依赖 Google 服务）
    implementation("com.google.zxing:core:3.5.3")                    // 生成二维码
}
