plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.lancast.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.lancast.app"
        minSdk = 29            // AudioPlaybackCapture(无损采集系统声音) 需要 Android 10+
        targetSdk = 34
        versionCode = 7
        versionName = "5.0"
    }
    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlin {
        compilerOptions {
            jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.fromTarget("17"))
        }
    }
}

dependencies {
    implementation(project(":yunx"))   // 云析（网盘 / 视频解析下载）
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-ktx:1.9.2")
    implementation("com.journeyapps:zxing-android-embedded:4.3.0")   // 扫码（自带取景界面，不依赖 Google 服务）
    implementation("com.google.zxing:core:3.5.3")                    // 生成二维码
    // 瞬浏视界（内置浏览器）的播放器：Media3 ExoPlayer（只引核心 + HLS + DASH，播放界面是代码写的）
    val media3 = "1.5.1"
    implementation("androidx.media3:media3-exoplayer:$media3")
    implementation("androidx.media3:media3-exoplayer-hls:$media3")
    implementation("androidx.media3:media3-exoplayer-dash:$media3")
    implementation("androidx.annotation:annotation-experimental:1.4.1")
}
