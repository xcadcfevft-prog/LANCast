'use strict';
/* 播放器窗口「沉浸外壳」：状态清洗、标题、任务栏进度、防休眠锁的获取 / 释放、失联兜底 */
const assert = require('assert');
const ps = require('../playerstate');

// ── 纯函数 ──
assert.strictEqual(ps.makeTitle(null), ps.BASE_TITLE);
assert.strictEqual(ps.makeTitle({ title: '晴天', artist: '周杰伦' }), '晴天 - 周杰伦 · 瞬流Pro');
assert.strictEqual(ps.makeTitle({ title: '晴天', artist: '' }), '晴天 · 瞬流Pro');
const dirty = ps.sanitize({ playing: 'yes', title: 'a\u0000b\n c', artist: 5, pos: 999, dur: 100, fs: 1 });
assert.strictEqual(dirty.playing, false); assert.strictEqual(dirty.fs, false);       // 只认严格的 true
assert.strictEqual(dirty.title, 'a b c'); assert.strictEqual(dirty.artist, '');
assert.strictEqual(dirty.pos, 100, '进度不能超过时长');
assert.deepStrictEqual(ps.sanitize(undefined).title, ''); assert.strictEqual(ps.sanitize({ dur: NaN, pos: -3 }).pos, 0);
assert.strictEqual(ps.sanitize({ title: 'x'.repeat(1000) }).title.length, 200);
assert.strictEqual(ps.progressOf({ dur: 0, pos: 0, title: 't', playing: true }), -1);
assert.strictEqual(ps.progressOf({ dur: 200, pos: 50, title: 't', playing: true }), 0.25);
assert.strictEqual(ps.progressOf({ dur: 200, pos: 50, title: '', playing: false }), -1);

// ── 外壳 ──
function mk(over) {
  const log = { power: [], title: [], prog: [] };
  let nextId = 0, fs = false, audible = false, destroyed = false, t = 1000;
  const win = {
    isDestroyed: () => destroyed, isFullScreen: () => fs,
    setTitle: x => log.title.push(x), setProgressBar: (p, o) => log.prog.push([p, o && o.mode])
  };
  const power = { start: type => { const id = nextId++; log.power.push(['start', type, id]); return id; }, stop: id => log.power.push(['stop', id]) };
  const sh = ps.createShell(Object.assign({ win, power, audible: () => audible, pollMs: 0, staleMs: 5000, now: () => t }, over));
  return { sh, log, setFs: v => (fs = v), setAudible: v => (audible = v), setT: v => (t = v), kill: () => (destroyed = true) };
}

{ // 播放 → 拿应用挂起锁；全屏才拿屏幕锁；暂停全部释放
  const m = mk();
  m.sh.update({ playing: true, title: '晴天', artist: '周杰伦', pos: 10, dur: 200 });
  assert.deepStrictEqual(m.log.power, [['start', 'prevent-app-suspension', 0]]);
  assert.strictEqual(m.log.title.at(-1), '晴天 - 周杰伦 · 瞬流Pro');
  assert.deepStrictEqual(m.log.prog.at(-1), [0.05, 'normal']);
  m.setFs(true); m.sh.refresh();
  assert.deepStrictEqual(m.log.power.at(-1), ['start', 'prevent-display-sleep', 1]);
  m.sh.update({ playing: true, title: '晴天', artist: '周杰伦', pos: 10.2, dur: 200 });
  assert.strictEqual(m.log.power.length, 2, '重复汇报不能重复拿锁');
  const n = m.log.prog.length;
  m.sh.update({ playing: true, title: '晴天', artist: '周杰伦', pos: 10.2, dur: 200 });
  assert.strictEqual(m.log.prog.length, n, '同样的进度不重复刷新任务栏');
  m.sh.update({ playing: false, title: '晴天', artist: '周杰伦', pos: 20, dur: 200 });
  assert.deepStrictEqual(m.log.power.slice(2).map(x => x[0]), ['stop', 'stop']);
  assert.deepStrictEqual(m.log.prog.at(-1), [0.1, 'paused'], '暂停时任务栏进度变黄');
  assert.strictEqual(m.sh.isPlaying(), false);
}
{ // 页面内全屏（HTML Fullscreen）也算全屏
  const m = mk();
  m.sh.update({ playing: true, fs: true, title: 'a', pos: 1, dur: 10 });
  assert(m.log.power.some(x => x[1] === 'prevent-display-sleep'));
}
{ // 失联：页面不再汇报超过 staleMs 视为停止，锁被释放，标题复原
  const m = mk();
  m.sh.update({ playing: true, title: 'a', artist: 'b', pos: 1, dur: 10 });
  assert.strictEqual(m.sh.isPlaying(), true);
  m.setT(1000 + 6000); m.sh.refresh();
  assert.strictEqual(m.sh.isPlaying(), false);
  assert.deepStrictEqual(m.log.power.at(-1), ['stop', 0]);
  assert.strictEqual(m.log.title.at(-1), ps.BASE_TITLE);
  assert.deepStrictEqual(m.log.prog.at(-1), [-1, undefined]);
}
{ // 页面没汇报（WebAudio 播放）：用 Chromium 的「正在出声」兜底；页面明确说暂停则不被延迟的 audible 误导
  const m = mk();
  m.setAudible(true); m.sh.refresh();
  assert.strictEqual(m.sh.isPlaying(), true); assert.strictEqual(m.log.power[0][1], 'prevent-app-suspension');
  m.sh.update({ playing: false, title: '', pos: 0, dur: 0 });
  assert.strictEqual(m.sh.isPlaying(), false, '页面说暂停了就是暂停');
  m.setAudible(false); m.setT(1000 + 9000); m.sh.refresh();
  assert.strictEqual(m.sh.isPlaying(), false);
}
{ // 脏数据 / 窗口销毁 / dispose 不抛异常，dispose 释放所有锁
  const m = mk();
  m.sh.update('garbage'); m.sh.update(null); m.sh.update({ playing: true, title: 't', dur: 10 });
  m.setFs(true); m.sh.refresh();
  m.sh.dispose();
  const starts = m.log.power.filter(x => x[0] === 'start').length, stops = m.log.power.filter(x => x[0] === 'stop').length;
  assert.strictEqual(starts, stops, '每个锁都要释放');
  m.sh.update({ playing: true, title: 'x', dur: 10 }); assert.strictEqual(m.log.power.length, starts + stops, 'dispose 之后不再拿锁');
  const m2 = mk(); m2.kill(); m2.sh.update({ playing: true }); assert.strictEqual(m2.sh.isPlaying(), false);
}
{ // power.start 抛异常 / 返回 0 都要正确处理
  const m = mk({ power: { start: () => { throw new Error('x'); }, stop() {} } });
  m.sh.update({ playing: true, title: 't', dur: 10 });                   // 不抛
  const calls = []; const m3 = mk({ power: { start: () => 0, stop: id => calls.push(id) } });
  m3.sh.update({ playing: true, title: 't', dur: 10 }); m3.sh.update({ playing: false, title: 't', dur: 10 });
  assert.deepStrictEqual(calls, [0], 'id 为 0 也是有效的锁');
}
console.log('playerstate.test.js ok');
