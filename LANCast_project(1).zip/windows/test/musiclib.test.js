'use strict';
/* 本地音乐库：ID3v2 / FLAC / M4A 标签解析、文件名兜底、扫描缓存、歌词 */
const assert = require('assert'), fs = require('fs'), os = require('os'), path = require('path');
const ml = require('../musiclib');
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'ml-'));
const be32 = n => { const b = Buffer.alloc(4); b.writeUInt32BE(n); return b; };
const ss32 = n => Buffer.from([(n >> 21) & 127, (n >> 14) & 127, (n >> 7) & 127, n & 127]);
const jpg = Buffer.concat([Buffer.from([0xFF, 0xD8, 0xFF, 0xE0]), Buffer.alloc(400, 7)]);

(async () => {
  // 文件名兜底
  assert.deepStrictEqual(ml.parseName('/a/01 周杰伦 - 晴天.mp3'), { artist: '周杰伦', title: '晴天', no: 1 });
  assert.strictEqual(ml.parseName('/a/Hello.wav').title, 'Hello');

  // ID3v2.3：UTF-16 标题 + GBK(latin1 标记) 歌手 + 封面
  const fr = (id, d) => Buffer.concat([Buffer.from(id), be32(d.length), Buffer.alloc(2), d]);
  const title = Buffer.concat([Buffer.from([1, 0xFF, 0xFE]), Buffer.from('晴天', 'utf16le')]);
  const artist = Buffer.concat([Buffer.from([0]), Buffer.from([0xD6, 0xDC, 0xBD, 0xDC, 0xC2, 0xD7])]);   // GBK「周杰伦」
  const apic = Buffer.concat([Buffer.from([0]), Buffer.from('image/jpeg\0'), Buffer.from([3]), Buffer.from('\0'), jpg]);
  const body = Buffer.concat([fr('TIT2', title), fr('TPE1', artist), fr('TALB', Buffer.concat([Buffer.from([3]), Buffer.from('叶惠美')])), fr('TRCK', Buffer.concat([Buffer.from([0]), Buffer.from('3/10')])), fr('APIC', apic)]);
  const mp3 = path.join(tmp, 'a.mp3');
  fs.writeFileSync(mp3, Buffer.concat([Buffer.from('ID3'), Buffer.from([3, 0, 0]), ss32(body.length), body, Buffer.alloc(100)]));
  const t = await ml.parseFile(mp3, fs.statSync(mp3), path.join(tmp, 'covers'));
  assert.strictEqual(t.title, '晴天'); assert.strictEqual(t.artist, '周杰伦'); assert.strictEqual(t.album, '叶惠美'); assert.strictEqual(t.no, 3);
  assert(t.cover && fs.existsSync(t.cover) && fs.readFileSync(t.cover).length === jpg.length, '应写出封面文件');

  // FLAC：STREAMINFO(时长) + VORBIS_COMMENT + PICTURE
  const si = Buffer.alloc(34); const sr = 44100, total = sr * 200;
  si[10] = (sr >> 12) & 255; si[11] = (sr >> 4) & 255; si[12] = ((sr & 15) << 4) | 0; si.writeUInt32BE(total >>> 0, 14);
  const cm = ['TITLE=Song', 'ARTIST=Band', 'ALBUM=Rec', 'TRACKNUMBER=7'].map(s => { const b = Buffer.from(s); const l = Buffer.alloc(4); l.writeUInt32LE(b.length); return Buffer.concat([l, b]); });
  const v = Buffer.alloc(4); v.writeUInt32LE(0); const c = Buffer.alloc(4); c.writeUInt32LE(cm.length);
  const vc = Buffer.concat([v, c, ...cm]);
  const blk = (type, last, d) => Buffer.concat([Buffer.from([type | (last ? 128 : 0), (d.length >> 16) & 255, (d.length >> 8) & 255, d.length & 255]), d]);
  const flac = path.join(tmp, 'b.flac');
  fs.writeFileSync(flac, Buffer.concat([Buffer.from('fLaC'), blk(0, false, si), blk(4, true, vc)]));
  const f = await ml.parseFile(flac, fs.statSync(flac), null);
  assert.strictEqual(f.title, 'Song'); assert.strictEqual(f.artist, 'Band'); assert.strictEqual(f.album, 'Rec'); assert.strictEqual(f.no, 7);
  assert(Math.abs(f.dur - 200) < 0.01, 'FLAC 时长 ' + f.dur);

  // M4A
  const at = (type, d) => Buffer.concat([be32(8 + d.length), Buffer.from(type, 'latin1'), d]);
  const item = (type, s) => at(type, at('data', Buffer.concat([Buffer.alloc(8), Buffer.from(s)])));
  const mvhd = Buffer.alloc(100); mvhd.writeUInt32BE(1000, 12); mvhd.writeUInt32BE(123000, 16);
  const ilst = at('ilst', Buffer.concat([item('\xa9nam', '海阔天空'), item('\xa9ART', 'Beyond')]));
  const moov = at('moov', Buffer.concat([at('mvhd', mvhd), at('udta', at('meta', Buffer.concat([Buffer.alloc(4), ilst])))]));
  const m4a = path.join(tmp, 'c.m4a');
  fs.writeFileSync(m4a, Buffer.concat([at('ftyp', Buffer.from('M4A \0\0\0\0')), moov]));
  const m = await ml.parseFile(m4a, fs.statSync(m4a), null);
  assert.strictEqual(m.title, '海阔天空'); assert.strictEqual(m.artist, 'Beyond'); assert(Math.abs(m.dur - 123) < 0.01);

  // 扫描：递归 + 非音频忽略 + 缓存命中 + 离线文件夹保留旧记录
  fs.mkdirSync(path.join(tmp, 'sub')); fs.writeFileSync(path.join(tmp, 'sub', '02 X - Y.ogg'), 'x'); fs.writeFileSync(path.join(tmp, 'note.txt'), 'x');
  fs.writeFileSync(path.join(tmp, 'sub', 'cover.jpg'), jpg);
  const r1 = await ml.scan({ folders: [tmp], cache: {}, coverDir: path.join(tmp, 'covers2') });
  assert.strictEqual(Object.keys(r1).length, 4);
  const ogg = r1[path.join(tmp, 'sub', '02 X - Y.ogg')];
  assert.strictEqual(ogg.title, 'Y'); assert.strictEqual(ogg.artist, 'X'); assert(/cover\.jpg$/.test(ogg.cover), '应使用同目录封面');
  const r2 = await ml.scan({ folders: [tmp], cache: r1, coverDir: path.join(tmp, 'covers2') });
  assert.strictEqual(r2[mp3], r1[mp3], '未变化的文件应直接用缓存');
  const gone = path.join(tmp, 'offline');
  const fake = { [path.join(gone, 'k.mp3')]: { title: 'k' } };
  const r3 = await ml.scan({ folders: [gone], cache: fake });
  assert.strictEqual(Object.keys(r3).length, 1, '文件夹不可达时保留旧记录');

  // 歌词
  fs.writeFileSync(path.join(tmp, 'a.lrc'), '[00:01.00]你好');
  assert(ml.readLyrics(mp3).includes('你好'));
  assert.strictEqual(ml.readLyrics(flac), '');

  fs.rmSync(tmp, { recursive: true, force: true });
  console.log('musiclib.test.js: 全部通过');
})().catch(e => { console.error(e); process.exit(1); });
