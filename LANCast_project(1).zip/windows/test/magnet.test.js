'use strict';
/* 磁力引擎自测：用一个假的 aria2 JSON-RPC 服务验证调用顺序和参数（真机上的 aria2c.exe 行为见 README 的手动验证清单）。 */
const assert = require('assert'), http = require('http'), os = require('os'), fs = require('fs'), path = require('path'), { EventEmitter } = require('events');
const M = require('../magnet.js');
let n = 0; const ok = (c, m) => { assert(c, m); n++; };

/* ── 输入解析 ── */
const H = '0123456789abcdef0123456789abcdef01234567';
ok(M.normalizeInput('magnet:?xt=urn:btih:' + H + '&dn=a%20b').uri.startsWith('magnet:?xt=urn:btih:' + H), '标准磁力');
ok(M.normalizeInput('看这个 (magnet:?xt=urn:btih:' + H + '). 谢谢').uri === 'magnet:?xt=urn:btih:' + H, '夹在文字里 + 去掉结尾标点');
ok(M.normalizeInput(H.toUpperCase()).uri === 'magnet:?xt=urn:btih:' + H, '40 位 Hash');
ok(M.normalizeInput('urn:btih:' + H).kind === 'magnet', 'urn:btih 前缀');
ok(M.normalizeInput('A'.repeat(32)).uri === 'magnet:?xt=urn:btih:' + 'A'.repeat(32), 'base32 Hash');
ok(M.normalizeInput('hello') === null && M.normalizeInput('') === null && M.normalizeInput('magnet') === null, '非法输入');
ok(M.cleanTrackers(['udp://a:1/announce', 'udp://a:1/announce', 'junk', ' http://b/announce ']).length === 2, 'Tracker 去重 / 过滤');

/* ── 假 aria2 ── */
const calls = []; let phase = 0;
function fakeSpawn(bin, args) {
  const port = +args.find(a => a.startsWith('--rpc-listen-port=')).split('=')[1];
  const secret = args.find(a => a.startsWith('--rpc-secret=')).split('=')[1];
  const ee = new EventEmitter(); ee.kill = () => srv.close(); ee.args = args;
  const handle = (method, p) => {
    calls.push([method, p]);
    switch (method) {
      case 'aria2.getVersion': return { version: 'fake' };
      case 'aria2.addUri': return 'g1';
      case 'aria2.tellStatus':
        if (p[0] === 'g1') return phase === 0 ? { status: 'active', connections: '3', numSeeders: '1', downloadSpeed: '100' } : { status: 'complete', followedBy: ['g2'] };
        return { bittorrent: { info: { name: 'Demo' } }, infoHash: H, dir: path.join(os.tmpdir(), 'dl') };
      case 'aria2.getFiles': return [{ index: '1', path: path.join(os.tmpdir(), 'dl', 'Demo', 'a.mkv'), length: '1000' }, { index: '2', path: path.join(os.tmpdir(), 'dl', 'Demo', 'b.srt'), length: '10' }, { index: '3', path: path.join(os.tmpdir(), 'dl', 'Demo', '_____padding_file_0_x'), length: '5' }];
      case 'aria2.changeOption': case 'aria2.unpause': case 'aria2.changeGlobalOption': case 'aria2.forceRemove': case 'aria2.removeDownloadResult': case 'aria2.forcePause': return 'OK';
      case 'aria2.shutdown': return 'OK';
      case 'system.multicall': return [
        [[{ gid: 'g2', status: 'active', totalLength: '1010', completedLength: '505', downloadSpeed: '2048', uploadSpeed: '1', connections: '7', numSeeders: '2', bittorrent: { info: { name: 'Demo' } }, files: [{ path: 'x/Demo/a.mkv', selected: 'true' }, { path: 'x/Demo/b.srt', selected: 'false' }], dir: 'x' }]],
        [[{ gid: 'g9', status: 'waiting', totalLength: '0', completedLength: '0', files: [] }]],
        [[{ gid: 'g1', status: 'complete', followedBy: ['g2'], files: [] }, { gid: 'g3', status: 'error', errorMessage: 'boom', files: [{ path: 'x/f', selected: 'true' }], dir: 'x' }]]
      ];
    }
    throw Object.assign(new Error('unknown ' + method), { code: 1 });
  };
  const srv = http.createServer((req, res) => {
    let s = ''; req.on('data', d => { s += d; }); req.on('end', () => {
      const j = JSON.parse(s); res.setHeader('Content-Type', 'application/json');
      if (j.params[0] !== 'token:' + secret) return res.end(JSON.stringify({ id: j.id, error: { code: 1, message: 'Unauthorized' } }));
      try { res.end(JSON.stringify({ id: j.id, result: handle(j.method, j.params.slice(1)) })); }
      catch (e) { res.end(JSON.stringify({ id: j.id, error: { code: e.code || 1, message: e.message } })); }
    });
  });
  srv.listen(port, '127.0.0.1');
  return ee;
}

(async () => {
  const dataDir = fs.mkdtempSync(path.join(os.tmpdir(), 'mag-')), dl = path.join(dataDir, 'dl');
  const E = M.createEngine({ bin: 'fake', dataDir, defaultDir: dl, spawn: fakeSpawn, pid: 4242 });
  await E.start();
  const proc = E._st.proc, a = proc.args.join(' ');
  ok(a.includes('--rpc-listen-all=false') && a.includes('--stop-with-process=4242') && a.includes('--enable-dht=true') && a.includes('--enable-dht6=true') && a.includes('--bt-enable-lpd=true') && a.includes('--max-overall-download-limit=0') && a.includes('--pause-metadata=true') && a.includes('--bt-tracker=udp://tracker.opentrackr.org'), '启动参数：本机 RPC / 不限速 / DHT / LPD / Tracker / 随父进程退出');
  ok(a.includes('--dht-entry-point=') && a.includes('--input-file=') && a.includes('--save-session='), 'DHT 入口 + 会话持久化');
  ok(!a.includes('--rpc-secret=undefined') && /--rpc-secret=[0-9a-f]{32}/.test(a), 'RPC 口令随机');

  const h = await E.resolveMagnet('magnet:?xt=urn:btih:' + H, dl);
  const add = calls.find(c => c[0] === 'aria2.addUri');
  ok(add[1][0][0].startsWith('magnet:') && add[1][1]['pause-metadata'] === 'true' && add[1][1].dir === dl && add[1][1]['bt-tracker'].includes('udp://'), 'addUri：暂停元数据 + 目录 + Tracker');
  let r = await E.poll(h);
  ok(r.state === 'resolving' && r.peers === 3 && r.seeders === 1, '解析中：节点数');
  phase = 1; r = await E.poll(h);
  ok(r.state === 'ready' && r.gid === 'g2' && r.name === 'Demo' && r.files.length === 2 && r.total === 1010, '解析完成：文件列表（过滤 padding 文件）');
  ok(r.files[0].rel === 'Demo/a.mkv', '相对路径');
  await E.confirm('g2', { dir: dl, selected: [1], numFiles: 2 });
  const co = calls.find(c => c[0] === 'aria2.changeOption');
  ok(co[1][0] === 'g2' && co[1][1]['select-file'] === '1' && co[1][1].dir === dl, '确认：select-file + dir');
  ok(calls.map(c => c[0]).slice(-2).join() === 'aria2.changeOption,aria2.unpause', '先改选项再继续下载');
  calls.length = 0; await E.confirm('g2', { dir: dl, selected: [1, 2], numFiles: 2 });
  ok(!calls.find(c => c[0] === 'aria2.changeOption')[1][1]['select-file'], '全选时不设 select-file');

  const t = await E.tasks();
  ok(t.length === 3 && !t.find(x => x.gid === 'g1'), '任务列表：隐藏元数据任务');
  const g2 = t.find(x => x.gid === 'g2');
  ok(g2.name === 'Demo' && g2.files.length === 1 && g2.eta === 0 || g2.eta > 0, '任务映射：只含已选文件');
  ok(g2.eta === Math.round(505 / 2048), 'ETA');
  ok(t.find(x => x.gid === 'g3').err === 'boom', '错误信息');

  await E.setGlobal({ down: 500, up: 0, seed: true });
  const gl = calls.filter(c => c[0] === 'aria2.changeGlobalOption').pop()[1][0];
  ok(gl['max-overall-download-limit'] === '512000' && gl['max-overall-upload-limit'] === '0' && gl['seed-ratio'] === '1.0' && gl['seed-time'] === '720', '全局限速 / 做种');
  ok(await E.setTrackers(['udp://x:1/announce', 'bad']) === 1, '更新 Tracker');

  /* 删除文件只能删任务目录内的 */
  const inside = path.join(dataDir, 'dl', 'f.bin'), outside = path.join(dataDir, 'keep.txt');
  fs.mkdirSync(dl, { recursive: true }); fs.writeFileSync(inside, 'x'); fs.writeFileSync(outside, 'y');
  E.deleteFiles({ dir: dl, files: [inside, outside, path.join(dl, '..', 'keep.txt')] });
  ok(!fs.existsSync(inside) && fs.existsSync(outside), '删除文件不会越出任务目录');

  /* .torrent 校验 */
  let bad = false; try { await E.resolveTorrent(Buffer.from('hello'), dl); } catch (e) { bad = /不是有效/.test(e.message); }
  ok(bad, '拒绝非 .torrent 文件');

  /* 引擎启动失败时给出中文错误 */
  const E2 = M.createEngine({ bin: '', dataDir, defaultDir: dl, spawn: fakeSpawn });
  let msg = ''; try { await E2.start(); } catch (e) { msg = e.message; }
  ok(/aria2c/.test(msg), '找不到引擎的提示');

  await E.shutdown(); console.log('magnet.test.js：' + n + ' 项通过'); process.exit(0);
})().catch(e => { console.error('FAIL', e); process.exit(1); });
