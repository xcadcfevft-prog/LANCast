'use strict';
/* folia「第二角色」：找目录 / 子进程环境 / 启动参数 / 启动失败判定，以及 folia-host 对 app 的准备工作（用假的 electron 模块真跑一遍） */
const assert = require('assert');
const path = require('path');
const fs = require('fs');
const os = require('os');
const Module = require('module');
const L = require('../foliaLauncher');

// ── 找 folia 目录：必须同时有主进程、预加载、前端产物和 package.json ──
{
  const res = path.join(path.sep + 'app', 'resources'), dev = path.join(path.sep + 'src', 'windows');
  assert.deepStrictEqual(L.candidateDirs(res, dev), [path.join(res, 'folia'), path.join(dev, 'folia')]);
  assert.deepStrictEqual(L.candidateDirs('', dev), [path.join(dev, 'folia')]);
  const full = new Set(L.REQUIRED.map(f => path.join(res, 'folia', f)));
  assert.strictEqual(L.findFoliaDir(L.candidateDirs(res, dev), p => full.has(p)), path.join(res, 'folia'));
  const noDist = new Set([...full].filter(p => !p.endsWith('index.html')));
  assert.strictEqual(L.findFoliaDir(L.candidateDirs(res, dev), p => noDist.has(p)), null, '缺前端产物 = 没打包');
  assert.strictEqual(L.findFoliaDir([res + path.sep + 'folia'], () => { throw new Error('io'); }), null, 'exists 抛错也只是找不到');
  assert.strictEqual(L.findFoliaDir(null, () => true), null);
  const devOnly = new Set(L.REQUIRED.map(f => path.join(dev, 'folia', f)));
  assert.strictEqual(L.findFoliaDir(L.candidateDirs(res, dev), p => devOnly.has(p)), path.join(dev, 'folia'), '安装目录没有时用开发目录');
}

// ── 子进程环境 ──
{
  const base = { PATH: 'x', ELECTRON_RUN_AS_NODE: '1', FOLIA_RELAUNCH: '1', ELECTRON_DEV: 'true', NODE_ENV: 'development', KEEP: 'me' };
  const e = L.childEnv(base, { dir: 'D', userData: 'U' });
  assert.strictEqual(e.ELECTRON_RUN_AS_NODE, undefined, '不能让 Electron 退化成纯 Node');
  assert.strictEqual(e.FOLIA_RELAUNCH, undefined);
  assert.strictEqual(e.ELECTRON_DEV, 'false', '不进 folia 开发模式');
  assert.strictEqual(e.NODE_ENV, undefined);
  assert.strictEqual(e[L.ROLE_ENV], L.ROLE_FOLIA);
  assert.strictEqual(e.LANCAST_FOLIA_DIR, 'D'); assert.strictEqual(e.LANCAST_FOLIA_USERDATA, 'U');
  assert.strictEqual(e.KEEP, 'me'); assert.strictEqual(base.ELECTRON_RUN_AS_NODE, '1', '不改传入的对象');
  assert.strictEqual(L.childEnv({ NODE_ENV: 'production' }, { dir: 'D', userData: 'U' }).NODE_ENV, 'production');
}

assert.deepStrictEqual(L.spawnArgs(true, '/a'), []);
assert.deepStrictEqual(L.spawnArgs(false, '/a'), ['/a'], '开发时要带应用路径，否则 electron.exe 打开欢迎页');

// ── 启动失败判定 ──
assert.strictEqual(L.judgeExit({ code: 1, signal: null, elapsedMs: 900 }), 'failed-early');
assert.strictEqual(L.judgeExit({ code: null, signal: 'SIGSEGV', elapsedMs: 900 }), 'failed-early', '被信号杀掉也算');
assert.strictEqual(L.judgeExit({ code: 3221225477, signal: null, elapsedMs: 1200 }), 'failed-early', 'Windows 崩溃码');
assert.strictEqual(L.judgeExit({ code: 0, signal: null, elapsedMs: 900 }), 'ok', '退出码 0 = 已有实例接管了，不是失败');
assert.strictEqual(L.judgeExit({ code: 1, signal: null, elapsedMs: L.GRACE_MS + 1 }), 'ok', '用了一阵才退出的不算没跑起来');
assert.strictEqual(L.judgeExit({ code: 1 }), 'ok', '没有耗时信息时不误判');
assert.strictEqual(L.judgeExit(null), 'ok');

// ── folia-host：用假的 electron 模块真跑 ──
const realLoad = Module._load;
function withFakeElectron(fn) {
  const calls = { name: null, paths: {}, exit: null };
  const app = {
    setName: n => { calls.name = n; }, setPath: (k, v) => { calls.paths[k] = v; }, exit: c => { calls.exit = c; },
    getAppPath: () => 'LANCAST-APP', getVersion: () => '5.0.0'
  };
  Module._load = function (req) { return req === 'electron' ? { app } : realLoad.apply(this, arguments); };
  delete require.cache[require.resolve('../folia-host')];
  const hadRes = Object.prototype.hasOwnProperty.call(process, 'resourcesPath'), oldRes = process.resourcesPath;
  try { fn(app, calls); } finally {
    Module._load = realLoad;
    if (hadRes) process.resourcesPath = oldRes; else delete process.resourcesPath;
    delete require.cache[require.resolve('../folia-host')];
  }
}
function mkFolia(mainBody) {
  const d = fs.mkdtempSync(path.join(os.tmpdir(), 'folia-host-'));
  fs.mkdirSync(path.join(d, 'electron'));
  fs.writeFileSync(path.join(d, 'package.json'), JSON.stringify({ name: 'folia-major', productName: 'Folia', version: '0.7.25' }));
  fs.writeFileSync(path.join(d, 'electron', 'main.cjs'), mainBody);
  return d;
}
{ // 正常：先设好 userData / 路径 / 版本，再加载 main.cjs（main.cjs 在加载时看到的就是 folia 自己的环境）
  const dir = mkFolia("const { app } = require('electron'); global.__foliaSeen = { appPath: app.getAppPath(), ver: app.getVersion(), res: process.resourcesPath };");
  const ud = path.join(os.tmpdir(), 'folia-host-ud-' + process.pid, 'folia');
  withFakeElectron((app, calls) => {
    delete global.__foliaSeen;
    require('../folia-host').run({ LANCAST_FOLIA_DIR: dir, LANCAST_FOLIA_USERDATA: ud });
    assert.strictEqual(calls.exit, null, '成功时不退出');
    assert.strictEqual(calls.name, 'Folia');
    assert.strictEqual(calls.paths.userData, ud, 'userData 要在加载 main.cjs 之前设好');
    assert.ok(fs.existsSync(ud), 'userData 目录被创建');
    assert.deepStrictEqual(global.__foliaSeen, { appPath: dir, ver: '0.7.25', res: dir });
    assert.strictEqual(app.getAppPath(), dir);
  });
  fs.rmSync(dir, { recursive: true, force: true }); fs.rmSync(path.dirname(ud), { recursive: true, force: true });
}
{ // main.cjs 加载时抛错：以 1 退出，瞬流据此退回内置播放器
  const dir = mkFolia("throw new Error('boom');");
  withFakeElectron((app, calls) => {
    const origErr = console.error; console.error = () => {};
    try { require('../folia-host').run({ LANCAST_FOLIA_DIR: dir }); } finally { console.error = origErr; }
    assert.strictEqual(calls.exit, 1);
  });
  fs.rmSync(dir, { recursive: true, force: true });
}
{ // 没给目录 / 目录不对：同样以 1 退出，不抛到外面
  withFakeElectron((app, calls) => {
    const origErr = console.error; console.error = () => {};
    try { require('../folia-host').run({}); } finally { console.error = origErr; }
    assert.strictEqual(calls.exit, 1);
  });
}

console.log('folialauncher.test.js ok');
