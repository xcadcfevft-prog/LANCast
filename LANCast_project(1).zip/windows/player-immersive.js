/* 注入到独立播放器页面（folia / 内置本地音乐库）里的「沉浸层」。由主进程在每次页面 dom-ready 时用 executeJavaScript 注入，样式由主进程 insertCSS（见 main.js），
 * 所以不受页面 CSP 影响，也不需要改 folia 的源码。可重复注入（幂等）。
 *   · 全屏时鼠标静止 2.6 秒自动隐藏光标，一动就回来
 *   · 全屏时换歌，左下角淡入淡出显示「歌名 — 歌手」
 *   · 每秒向主进程汇报：是否在播放 / 歌名 / 歌手 / 进度（主进程据此防休眠、改标题、任务栏进度条）
 *   · window.__lcFade(ms)：关闭窗口前把音量淡出，避免声音「啪」地断掉
 * 识别播放器：<audio>/<video>、new Audio()（拦截 HTMLMediaElement.prototype.play 登记）、navigator.mediaSession 的歌曲信息。 */
(() => {
  'use strict';
  if (window.__lcImm) return;
  const lib = window.lib;
  const sendState = lib && typeof lib.state === 'function' ? s => { try { lib.state(s); } catch {} } : () => {};
  const root = document.documentElement;

  /* ───── 媒体元素登记（new Audio() 不在 DOM 里，只能在 play() 时拦截） ───── */
  const seen = new WeakSet(), refs = [];
  let last = null;
  const EV = ['play', 'playing', 'pause', 'ended', 'emptied', 'durationchange', 'seeked', 'loadedmetadata'];
  const reg = el => {
    if (!el || seen.has(el)) return;
    seen.add(el); refs.push(new WeakRef(el));
    EV.forEach(e => el.addEventListener(e, () => { if (e === 'play' || e === 'playing') last = new WeakRef(el); queue(); }));
  };
  const live = () => {
    document.querySelectorAll('audio,video').forEach(reg);
    const out = [];
    for (let i = refs.length - 1; i >= 0; i--) { const el = refs[i].deref(); if (el) out.push(el); else refs.splice(i, 1); }
    return out;
  };
  const proto = HTMLMediaElement.prototype, origPlay = proto.play;
  proto.play = function () { reg(this); last = new WeakRef(this); return origPlay.apply(this, arguments); };

  const isPlaying = el => !el.paused && !el.ended && el.readyState > 0;
  const primary = () => {
    const all = live();
    return all.find(isPlaying) || (last && last.deref()) || all.find(e => Number.isFinite(e.duration) && e.duration > 0) || null;
  };

  /* ───── 汇报状态 ───── */
  let key = '';
  const isFull = () => !!document.fullscreenElement || (innerWidth >= screen.width && innerHeight >= screen.height);
  function report() {
    const el = primary(), md = navigator.mediaSession && navigator.mediaSession.metadata;
    const s = {
      playing: !!(el && isPlaying(el)), fs: isFull(),
      title: (md && md.title) || '', artist: (md && md.artist) || '',
      pos: el && Number.isFinite(el.currentTime) ? el.currentTime : 0,
      dur: el && Number.isFinite(el.duration) ? el.duration : 0
    };
    sendState(s);
    const k = s.title + '\n' + s.artist;
    if (k !== key) { const first = key === ''; key = k; if (!first && s.title && s.playing && isFull()) toast(s.title, s.artist); }
  }
  let q = 0;
  function queue() { if (!q) q = setTimeout(() => { q = 0; report(); }, 60); }
  setInterval(report, 1000);
  document.addEventListener('visibilitychange', queue);

  /* ───── 换歌提示 ───── */
  let tEl = null, tT = 0;
  function toast(title, artist) {
    if (!tEl) { tEl = document.createElement('div'); tEl.className = 'lc-np'; tEl.setAttribute('aria-hidden', 'true'); root.appendChild(tEl); }
    tEl.textContent = '';
    const a = document.createElement('b'); a.textContent = title; tEl.appendChild(a);
    if (artist) { const b = document.createElement('span'); b.textContent = artist; tEl.appendChild(b); }
    tEl.classList.remove('on'); void tEl.offsetWidth; tEl.classList.add('on');
    clearTimeout(tT); tT = setTimeout(() => tEl && tEl.classList.remove('on'), 3600);
  }

  /* ───── 全屏时自动隐藏光标 ───── */
  let idleT = 0, lx = -1, ly = -1;
  const wake = () => { root.classList.remove('lc-idle'); clearTimeout(idleT); idleT = setTimeout(() => { if (isFull()) root.classList.add('lc-idle'); }, 2600); };
  addEventListener('mousemove', e => { if (e.screenX === lx && e.screenY === ly) return; lx = e.screenX; ly = e.screenY; wake(); }, true);   // 页面重排会触发位置没变的假 mousemove，不算活动
  ['mousedown', 'wheel', 'keydown', 'touchstart'].forEach(t => addEventListener(t, wake, { capture: true, passive: true }));
  document.addEventListener('fullscreenchange', wake);
  addEventListener('resize', wake);
  wake();

  /* ───── 关闭前淡出音量 ───── */
  window.__lcFade = ms => new Promise(res => {
    const els = live().filter(isPlaying);
    if (!els.length) return res(false);
    const v0 = els.map(e => e.volume), t0 = performance.now(), dur = Math.max(60, Math.min(1500, ms | 0 || 350));
    const step = () => {
      const k = Math.min(1, (performance.now() - t0) / dur), g = (1 - k) * (1 - k);
      els.forEach((e, i) => { try { e.volume = v0[i] * g; } catch {} });
      if (k < 1) return setTimeout(step, 16);
      els.forEach((e, i) => { try { e.pause(); e.volume = v0[i]; } catch {} });      // 音量还原：页面可能把音量存起来，不能把「0」留给下次启动
      setTimeout(() => res(true), 80);                                                // 给页面的 volumechange 处理留点时间，保证它最后存下的是还原后的值
    };
    step();
  });

  window.__lcImm = { report, version: 1 };
  queue();
})();
