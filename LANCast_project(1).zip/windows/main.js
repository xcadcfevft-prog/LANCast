'use strict';
const { app, BrowserWindow, session, desktopCapturer, screen, powerSaveBlocker, ipcMain, dialog, shell, globalShortcut, Menu, nativeTheme } = require('electron');
const path = require('path');
const playerstate = require('./playerstate');

// 窗口被最小化/遮挡时也不要降低定时器与渲染优先级（投屏时很重要）
app.commandLine.appendSwitch('disable-renderer-backgrounding');
app.commandLine.appendSwitch('disable-background-timer-throttling');
app.commandLine.appendSwitch('disable-backgrounding-occluded-windows');
// 被别的窗口盖住 / 最小化时，Chromium 会把页面判成「不可见」并降低优先级：控制电脑时对方一最大化别的窗口、盖住瞬流窗口，投屏就可能顿住
app.commandLine.appendSwitch('disable-features', 'CalculateNativeWinOcclusion');
// 让部分被 Chromium 黑名单误伤的显卡也能走硬件编解码
app.commandLine.appendSwitch('ignore-gpu-blocklist');

let win = null;
let psb = null;
let ctlLive = false;        // 本机正被对方控制中
let quitting = false;      // 真的要退出（托盘 / 系统关机 / app.quit）
const END_KEY = 'CommandOrControl+Alt+Shift+Q';
/* 被控期间不再显示屏幕顶部的「正在被控制」提示条；终止方式保留全局热键 Ctrl+Alt+Shift+Q（以及观看方 / 本机主窗口里结束会话）。 */
function ctlBanner(on) {
  if (on) { try { globalShortcut.register(END_KEY, () => { if (win && !win.isDestroyed()) win.webContents.send('ctl-end'); }); } catch {} }
  else { try { globalShortcut.unregister(END_KEY); } catch {} }
}
let playerWin = null;     // 内置本地音乐库播放器窗口（player-local/）。folia 是独立进程，不在这里（见 startFolia）
let playerShell = null;   // 播放器窗口的「沉浸外壳」状态（防休眠 / 标题 / 任务栏进度，见 playerstate.js）
let gameWin = null, gameInit = null, gameReady = false, gameQ = [], gameClosing = false;   // 五子棋对战窗口
function closeGameWin(silent) {
  if (!gameWin || gameWin.isDestroyed()) { gameWin = null; return; }
  gameClosing = !!silent;
  try { gameWin.destroy(); } catch {}
  gameClosing = false; gameWin = null;
}
let psbM = null;          // 沉浸音乐播放期间阻止应用被系统挂起（屏幕可以熄灭）；与文件传输各用各的，互不覆盖
let psbX = null;          // 文件传输期间阻止系统休眠（屏幕可以熄灭）

/* ───────── 独立音乐播放器窗口 ───────── */
const PLAYER_PART = 'persist:player';          // 独立分区：登录状态 / 音乐库 / 设置在重启后都还在，也不和主窗口互相污染
const playerCfgPath = () => path.join(app.getPath('userData'), 'player.json');
function readPlayerCfg() { try { return JSON.parse(require('fs').readFileSync(playerCfgPath(), 'utf8')) || {}; } catch { return {}; } }
function writePlayerCfg(o) { try { require('fs').writeFileSync(playerCfgPath(), JSON.stringify(o)); } catch {} }
/* 地址规范化：只接受 http(s)；没写协议时，内网 / 本机地址补 http://，其余补 https:// */
function normPlayerUrl(s) {
  s = String(s || '').trim();
  if (!s) return '';
  if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(s)) s = (/^(localhost|127\.|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/i.test(s) ? 'http://' : 'https://') + s;
  try { const u = new URL(s); return /^https?:$/.test(u.protocol) ? u.href : ''; } catch { return ''; }
}
const escHtml = t => String(t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
function playerErrorPage(url, desc) {
  const h = '<!doctype html><meta charset="utf-8"><title>音乐播放器</title><body style="margin:0;height:100vh;display:flex;align-items:center;justify-content:center;background:#000;color:#ddd;font:15px/1.7 system-ui,\'Microsoft YaHei\',sans-serif;text-align:center">' +
    '<div style="max-width:520px;padding:24px"><div style="font-size:40px">🎵</div><h2 style="font-weight:600;margin:8px 0">播放器页面打不开</h2>' +
    '<p style="color:#999;margin:0 0 4px">' + escHtml(desc || '网络不可用') + '</p><p style="color:#666;font-size:12px;word-break:break-all;margin:0 0 20px">' + escHtml(url) + '</p>' +
    '<button onclick="location.href=' + escHtml(JSON.stringify(url)) + '" style="padding:8px 26px;border:0;border-radius:8px;background:#fff;color:#000;font-size:14px;cursor:pointer">重试</button>' +
    '<p style="color:#666;font-size:12px;margin-top:18px">F5 / Ctrl+R 也可重新加载；</p></div></body>';
  return 'data:text/html;charset=utf-8,' + encodeURIComponent(h);
}
/* 沉浸层样式（配合 player-immersive.js，由 insertCSS 注入，不受页面 CSP 限制）：全屏静止隐藏光标 + 换歌提示 */
const IMM_CSS = 'html.lc-idle,html.lc-idle *{cursor:none!important}' +
  '.lc-np{position:fixed;left:28px;bottom:34px;z-index:2147483647;max-width:min(60vw,640px);padding:11px 18px;border-radius:14px;background:rgba(0,0,0,.42);-webkit-backdrop-filter:blur(18px) saturate(1.4);backdrop-filter:blur(18px) saturate(1.4);color:#fff;font:600 15px/1.35 system-ui,"Microsoft YaHei",sans-serif;pointer-events:none;opacity:0;transform:translateY(10px);transition:opacity .55s ease,transform .55s ease;text-shadow:0 1px 8px rgba(0,0,0,.4)}' +
  '.lc-np.on{opacity:1;transform:none}.lc-np b,.lc-np span{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.lc-np span{margin-top:2px;font-weight:400;font-size:13px;opacity:.72}';
let immSrcCache = null;
const immSrc = () => immSrcCache || (immSrcCache = require('fs').readFileSync(path.join(__dirname, 'player-immersive.js'), 'utf8'));

function openPlayerWin(src) {
  const cfg = readPlayerCfg(), b = cfg.bounds || {};
  const okB = b && b.width >= 720 && b.height >= 520;
  const ses = session.fromPartition(PLAYER_PART);
  // 权限：只放行播放器需要的（全屏 / 复制 / 本机字体），其余一律拒绝
  const OK_PERM = new Set(['fullscreen', 'clipboard-sanitized-write', 'local-fonts', 'fileSystem']);   // fileSystem：folia 本地音乐库读取用户选的文件夹
  ses.setPermissionRequestHandler((wc, perm, cb) => cb(OK_PERM.has(perm)));
  ses.setPermissionCheckHandler((wc, perm) => OK_PERM.has(perm));
  const pw = playerWin = new BrowserWindow({
    width: okB ? b.width : 1280, height: okB ? b.height : 820, x: okB && Number.isFinite(b.x) ? b.x : undefined, y: okB && Number.isFinite(b.y) ? b.y : undefined,
    minWidth: 720, minHeight: 520, show: false,
    backgroundColor: '#000000', title: '音乐播放器 · 瞬流Pro', icon: path.join(__dirname, 'icon.png'), autoHideMenuBar: true,
    webPreferences: { preload: path.join(__dirname, 'player-preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true, backgroundThrottling: false, partition: PLAYER_PART }
  });
  if (okB && b.max) pw.maximize();
  /* 沉浸外壳：深色原生标题栏（只在播放器开着时；主窗口没有按系统主题写样式，不受影响）+ 播放状态联动（防休眠 / 标题 / 任务栏进度，见 playerstate.js） */
  nativeTheme.themeSource = 'dark';
  const shell = playerShell = playerstate.createShell({
    win: pw, power: { start: t => powerSaveBlocker.start(t), stop: id => powerSaveBlocker.stop(id) },
    audible: () => pw.webContents.isCurrentlyAudible()
  });
  const refreshShell = () => { try { shell.refresh(); } catch {} };
  ['enter-full-screen', 'leave-full-screen', 'enter-html-full-screen', 'leave-html-full-screen'].forEach(ev => pw.on(ev, refreshShell));
  pw.webContents.on('dom-ready', () => {                 // 每次页面加载都注入沉浸层（只对内置播放器窗口；folia 自己有等价功能）；报错页（data:）不注入
    const wc = pw.webContents;
    let u = ''; try { u = wc.getURL(); } catch {}
    if (!u || u.startsWith('data:')) return;
    wc.insertCSS(IMM_CSS).catch(() => {});
    wc.executeJavaScript(immSrc()).catch(() => {});
  });
  const showT = setTimeout(() => { try { if (!pw.isDestroyed()) pw.show(); } catch {} }, 3000);   // 页面久不出画面也要先把窗口亮出来（黑底，不闪白）
  pw.once('ready-to-show', () => { clearTimeout(showT); try { pw.show(); } catch {} });
  pw.on('page-title-updated', e => e.preventDefault());
  let origin = '';
  try { if (src.url) origin = new URL(src.url).origin; } catch {}
  pw.webContents.setWindowOpenHandler(({ url }) => { if (/^https?:/.test(url)) shell.openExternal(url); return { action: 'deny' }; });
  pw.webContents.on('will-navigate', (e, url) => {          // 网页版：不让播放器窗口被带去别的站点；离开本站的链接交给系统浏览器
    if (url.startsWith('data:')) return;
    let o = ''; try { o = new URL(url).origin; } catch {}
    if (src.file ? !url.startsWith('file:') : o !== origin) { e.preventDefault(); if (/^https?:/.test(url)) shell.openExternal(url); }
  });
  pw.webContents.on('did-fail-load', (e, code, desc, url, isMain) => {
    if (!isMain || code === -3 || !src.url) return;         // -3 = 被新的导航取代，不算失败
    pw.loadURL(playerErrorPage(src.url, desc));
  });
  // 没有菜单栏：补上常用快捷键（刷新 / 全屏 / 缩放）
  pw.webContents.on('before-input-event', (e, i) => {
    if (i.type !== 'keyDown') return;
    const ctrl = i.control || i.meta, wc = pw.webContents, k = i.key;
    if (k === 'F5' || (ctrl && (k === 'r' || k === 'R'))) { e.preventDefault(); i.shift ? wc.reloadIgnoringCache() : wc.reload(); }
    else if (k === 'F11') { e.preventDefault(); pw.setFullScreen(!pw.isFullScreen()); }
    else if (ctrl && (k === '=' || k === '+')) { e.preventDefault(); wc.setZoomLevel(Math.min(wc.getZoomLevel() + 0.5, 3)); }
    else if (ctrl && k === '-') { e.preventDefault(); wc.setZoomLevel(Math.max(wc.getZoomLevel() - 0.5, -3)); }
    else if (ctrl && k === '0') { e.preventDefault(); wc.setZoomLevel(0); }
  });
  const saveBounds = () => { try { if (pw.isDestroyed() || pw.isFullScreen() || pw.isMinimized()) return; const c = readPlayerCfg(); const max = pw.isMaximized(); c.bounds = Object.assign({}, max ? c.bounds : pw.getBounds(), { max }); writePlayerCfg(c); } catch {} };
  pw.on('close', saveBounds);
  let fading = false;                                       // 关窗口时正在播放：先把音量淡出 ~0.35 秒再关，声音不会「啪」地断掉（player.json 里 fadeOut:false 可关闭）
  pw.on('close', e => {
    if (fading || quitting || pw.isDestroyed() || !shell.isPlaying() || readPlayerCfg().fadeOut === false) return;
    e.preventDefault(); fading = true;
    const done = () => { try { if (!pw.isDestroyed()) pw.close(); } catch {} };
    Promise.race([pw.webContents.executeJavaScript('window.__lcFade?window.__lcFade(350):false').catch(() => {}), new Promise(r => setTimeout(r, 900))]).then(done, done);
  });
  pw.on('closed', () => {
    clearTimeout(showT);
    try { shell.dispose(); } catch {}
    if (pw === playerWin) { playerWin = null; playerShell = null; }
    if (!playerWin) nativeTheme.themeSource = 'system';
  });
  if (src.file) pw.loadFile(src.file); else pw.loadURL(src.url);
}

function createWindow() {
  win = new BrowserWindow({
    width: 1120,
    height: 740,
    minWidth: 760,
    minHeight: 520,
    backgroundColor: '#e9edf1',
    title: '瞬流Pro',
    icon: path.join(__dirname, 'icon.png'),
    autoHideMenuBar: true,
    webPreferences: {
      nodeIntegration: true,      // 渲染进程直接使用 net / dgram / crypto（只加载本地页面）
      contextIsolation: false,
      backgroundThrottling: false
    }
  });
  win.on('focus', () => { try { win.flashFrame(false); } catch {} });
  /* 被控制期间，对方在电脑画面里点瞬流窗口右上角的「×」不应该把整个程序关掉（关掉 = 连接断开 = 对方失去控制）：改成最小化。
   * 想真正退出：先结束会话（本机主窗口「结束当前会话」，或全局热键 Ctrl+Alt+Shift+Q），再关窗口。 */
  win.on('close', e => { if (ctlLive && !quitting) { e.preventDefault(); try { win.minimize(); } catch {} } });
  win.on('session-end', () => { quitting = true; });
  win.loadFile('index.html');
}

app.whenReady().then(() => {
  Menu.setApplicationMenu(null);     // 去掉默认菜单：否则控制对方时 Ctrl+R 之类的按键会被本机菜单抢走
  // getDisplayMedia 不弹选择框：直接抓主屏 + 系统音频回环（WASAPI loopback，无损 PCM）
  session.defaultSession.setDisplayMediaRequestHandler(async (req, cb) => {
    try {
      const srcs = await desktopCapturer.getSources({ types: ['screen'] });
      const pid = String(screen.getPrimaryDisplay().id);
      const src = srcs.find(s => s.display_id === pid) || srcs[0];
      cb({ video: src, audio: 'loopback' });
    } catch (e) {
      cb({});
    }
  }, { useSystemPicker: false });

  ipcMain.on('keep-awake', (e, on) => {
    if (on && psb === null) psb = powerSaveBlocker.start('prevent-display-sleep');
    if (!on && psb !== null) { powerSaveBlocker.stop(psb); psb = null; }
  });

  // ── 文件互传需要的系统对话框 / 路径 / 防休眠 ──
  ipcMain.on('keep-awake-xfer', (e, on) => {
    if (on && psbX === null) psbX = powerSaveBlocker.start('prevent-app-suspension');
    if (!on && psbX !== null) { powerSaveBlocker.stop(psbX); psbX = null; }
  });
  // 沉浸音乐：播放期间 ① 阻止应用被系统挂起 ② 接管键盘媒体键（播放/暂停、上一首、下一首）③ 渲染进程保持高优先级
  const MEDIA_KEYS = { MediaPlayPause: 'toggle', MediaNextTrack: 'next', MediaPreviousTrack: 'prev' };
  ipcMain.on('keep-awake-music', (e, on) => {
    if (on && psbM === null) psbM = powerSaveBlocker.start('prevent-app-suspension');
    if (!on && psbM !== null) { powerSaveBlocker.stop(psbM); psbM = null; }
    for (const [acc, k] of Object.entries(MEDIA_KEYS)) {
      try {
        if (on) globalShortcut.register(acc, () => { if (win && !win.isDestroyed()) win.webContents.send('music-key', k); });
        else globalShortcut.unregister(acc);
      } catch {}
    }
    try { if (win && !win.isDestroyed()) win.webContents.setBackgroundThrottling(false); } catch {}
  });
  ipcMain.on('get-path', (e, name) => { try { e.returnValue = app.getPath(name); } catch { e.returnValue = ''; } });
  ipcMain.handle('pick-files', async () => {
    const r = await dialog.showOpenDialog(win, { title: '选择要发送的文件', properties: ['openFile', 'multiSelections'] });
    return r.canceled ? [] : r.filePaths;
  });
  ipcMain.handle('pick-folder', async (e, def) => {
    const r = await dialog.showOpenDialog(win, { title: '选择接收文件的保存位置', defaultPath: def || undefined, properties: ['openDirectory', 'createDirectory'] });
    return r.canceled ? '' : r.filePaths[0];
  });
  ipcMain.on('open-folder', (e, p) => { if (p) shell.openPath(p); });
  ipcMain.on('show-item', (e, p) => { if (p) shell.showItemInFolder(p); });
  ipcMain.on('open-item', (e, p) => { if (p) shell.openPath(p); });      // 聊天里的图片 / 视频预览：内核打不开的格式交给系统默认程序

  // Chromium 要求 getDisplayMedia 必须在「用户手势」中调用；网络事件触发的调用没有手势，
  // 所以由主进程用 userGesture=true 的方式在页面里执行（页面把流存到 window.__capStream）。
  ipcMain.handle('capture', (e, json) => win.webContents.executeJavaScript('window.__capture(' + json + ')', true));

  // ── 屏幕控制（本机被控）──
  // 输入注入（inject.js）在渲染进程里执行，见 renderer.js 顶部的说明；主进程只管全局热键和「被控期间关窗口 = 最小化」
  ipcMain.on('ctl-active', (e, info) => { ctlLive = !!(info && info.on); ctlBanner(ctlLive); });
  ipcMain.on('ctl-end', () => { if (win && !win.isDestroyed()) win.webContents.send('ctl-end'); });

  ipcMain.on('flash', () => { try { if (win && !win.isDestroyed() && !win.isFocused()) win.flashFrame(true); } catch {} });   // 收到聊天消息：任务栏图标闪烁
  ipcMain.on('focus', () => { if (!win) return; if (win.isMinimized()) win.restore(); win.show(); win.focus(); });

  // ── 独立音乐播放器：内置本地音乐库（player-local/ + musiclib.js），打开即用，不依赖网络 / 网页版地址 ──
  const musiclib = require('./musiclib');
  const fsx = require('fs');
  const { pathToFileURL } = require('url');
  const libPath = () => path.join(app.getPath('userData'), 'player-lib.json');
  const coverDir = () => path.join(app.getPath('userData'), 'covers');
  let lib = null, scanning = null;
  const loadLib = () => {
    if (lib) return lib;
    try { lib = JSON.parse(fsx.readFileSync(libPath(), 'utf8')) || {}; } catch { lib = {}; }
    lib.folders = Array.isArray(lib.folders) ? lib.folders : []; lib.files = Array.isArray(lib.files) ? lib.files : []; lib.tracks = lib.tracks && typeof lib.tracks === 'object' ? lib.tracks : {};
    return lib;
  };
  const saveLib = () => { try { const t = libPath() + '.tmp'; fsx.writeFileSync(t, JSON.stringify(lib)); fsx.renameSync(t, libPath()); } catch {} };
  const under = (p, dir) => p.toLowerCase().startsWith(dir.toLowerCase() + path.sep);
  const libView = () => {
    const L = loadLib();
    return {
      folders: L.folders.map(f => ({ path: f, n: Object.keys(L.tracks).filter(p => under(p, f)).length })),
      tracks: Object.entries(L.tracks).map(([p, t]) => ({ path: p, url: pathToFileURL(p).href, title: t.title, artist: t.artist, album: t.album, no: t.no, dur: t.dur, cover: t.cover ? pathToFileURL(t.cover).href : '' }))
    };
  };
  const fromPlayer = e => !!(playerWin && !playerWin.isDestroyed() && e.sender === playerWin.webContents);
  const doScan = () => {
    if (scanning) return scanning;
    const L = loadLib();
    scanning = musiclib.scan({
      folders: L.folders, files: L.files, cache: L.tracks, coverDir: coverDir(),
      onProgress: d => { try { if (playerWin && !playerWin.isDestroyed()) playerWin.webContents.send('pl-progress', d); } catch {} }
    }).then(t => { L.tracks = t; saveLib(); }).catch(() => {}).then(() => { scanning = null; return libView(); });
    return scanning;
  };
  const addPaths = async list => {
    const L = loadLib();
    for (const p of list) {
      if (typeof p !== 'string' || !path.isAbsolute(p)) continue;
      let st; try { st = fsx.statSync(p); } catch { continue; }
      if (st.isDirectory()) { if (!L.folders.some(f => f.toLowerCase() === p.toLowerCase())) L.folders.push(p); }
      else if (musiclib.isAudio(p) && !L.files.includes(p)) L.files.push(p);
    }
    saveLib();
    return doScan();
  };
  ipcMain.handle('pl-get', e => (fromPlayer(e) ? libView() : null));
  ipcMain.handle('pl-rescan', e => (fromPlayer(e) ? doScan() : null));
  ipcMain.handle('pl-add-folders', async e => {
    if (!fromPlayer(e)) return null;
    const r = await dialog.showOpenDialog(playerWin, { title: '选择音乐文件夹', properties: ['openDirectory', 'multiSelections'] });
    return r.canceled || !r.filePaths.length ? null : addPaths(r.filePaths);
  });
  ipcMain.handle('pl-add-files', async e => {
    if (!fromPlayer(e)) return null;
    const r = await dialog.showOpenDialog(playerWin, { title: '选择音频文件', properties: ['openFile', 'multiSelections'], filters: [{ name: '音频', extensions: [...musiclib.EXT].map(x => x.slice(1)) }] });
    return r.canceled || !r.filePaths.length ? null : addPaths(r.filePaths);
  });
  ipcMain.handle('pl-add-paths', (e, list) => (fromPlayer(e) && Array.isArray(list) ? addPaths(list.slice(0, 5000)) : null));
  ipcMain.handle('pl-remove-folder', (e, p) => {
    if (!fromPlayer(e)) return null;
    const L = loadLib();
    L.folders = L.folders.filter(f => f !== p);
    for (const k of Object.keys(L.tracks)) if (under(k, String(p)) && !L.files.includes(k)) delete L.tracks[k];
    saveLib();
    return libView();
  });
  ipcMain.handle('pl-remove-track', (e, p) => {      // 只从音乐库移除，不删电脑上的文件
    if (!fromPlayer(e)) return null;
    const L = loadLib();
    L.files = L.files.filter(f => f !== p); delete L.tracks[p];
    saveLib();
    return libView();
  });
  ipcMain.on('pl-state', (e, s) => { if (fromPlayer(e) && playerShell) playerShell.update(s); });   // 页面汇报播放状态（player-immersive.js）
  ipcMain.handle('pl-lyrics',(e, p) => (fromPlayer(e) && loadLib().tracks[p] ? musiclib.readLyrics(p) : ''));
  ipcMain.on('pl-reveal', (e, p) => { if (fromPlayer(e) && loadLib().tracks[p]) shell.showItemInFolder(p); });
  ipcMain.on('pl-dur', (e, m) => {                   // 渲染进程在后台量出的时长，回写缓存
    if (!fromPlayer(e) || !m || typeof m !== 'object') return;
    const L = loadLib();
    for (const [p, d] of Object.entries(m)) if (L.tracks[p] && !L.tracks[p].dur && d > 0 && d < 86400) L.tracks[p].dur = d;
    saveLib();
  });
  // folia 完整桌面端（resources/folia，CI 构建，见 build-player.js）：不是网页。用同一个 exe 以 LANCAST_ROLE=folia 再起一个进程，原样运行 folia 自己的主进程（entry.js → folia-host.js → electron/main.cjs），
  // 所以原生文件夹选择与「受限文件夹」提示、设置存储、任务栏按钮、全局快捷键、在线音乐后端等都是 folia 自带的真实环境；与瞬流主进程互相独立（各用各的 userData），folia 崩了不影响投屏 / 传文件。
  // 没打包 folia、或它起来后几秒内就异常退出时，退回内置本地音乐库播放器（player-local/，沉浸外壳只对它生效）。
  const { spawn } = require('child_process');
  const launcher = require('./foliaLauncher');
  const foliaDir = () => launcher.findFoliaDir(launcher.candidateDirs(process.resourcesPath, __dirname), p => fsx.existsSync(p));
  const foliaLog = () => path.join(app.getPath('userData'), 'folia-host.log');
  const wantBuiltin = () => !!readPlayerCfg().builtin || process.env.LANCAST_PLAYER === 'builtin';
  const openBuiltin = () => openPlayerWin({ file: path.join(__dirname, 'player-local', 'index.html') });
  function startFolia(dir) {
    let fd = -1, child;
    try {
      const lp = foliaLog();
      try { if (fsx.statSync(lp).size > 1048576) fsx.truncateSync(lp, 0); } catch {}
      fd = fsx.openSync(lp, 'a');                        // 子进程的 stderr 直接写文件（不用管道：瞬流先退出时管道断开，folia 往 stderr 写会出错）
      child = spawn(process.execPath, launcher.spawnArgs(app.isPackaged, app.getAppPath()), {
        env: launcher.childEnv(process.env, { dir, userData: path.join(app.getPath('userData'), 'folia') }),
        stdio: ['ignore', 'ignore', fd], detached: false, windowsHide: false
      });
    } catch { try { if (fd >= 0) fsx.closeSync(fd); } catch {} return false; }
    try { fsx.closeSync(fd); } catch {}
    const t0 = Date.now();
    const fallback = why => {                            // 异步退回：IPC 已经先答复「已打开」，所以这里补开内置版并告诉主窗口原因
      let tail = ''; try { tail = fsx.readFileSync(foliaLog(), 'utf8').slice(-600); } catch {}
      console.error('[folia] 启动失败：' + why + '\n' + tail);
      if (!playerWin || playerWin.isDestroyed()) openBuiltin();
      try { if (win && !win.isDestroyed()) win.webContents.send('player-fallback', 'folia 没能启动，已改用内置播放器（日志：' + foliaLog() + '）'); } catch {}
    };
    child.on('error', err => fallback(String(err && err.message || err)));
    child.on('exit', (code, signal) => { if (launcher.judgeExit({ code, signal, elapsedMs: Date.now() - t0 }) === 'failed-early') fallback('退出码 ' + code + (signal ? ' / ' + signal : '')); });
    return true;
  }
  ipcMain.handle('player-mode', (e, toggle) => {          // 右键按钮：在 folia 与简易内置版之间切换（没打包 folia 时只有内置版）
    if (!win || e.sender !== win.webContents) return null;
    const has = !!foliaDir();
    if (toggle && has) { const c = readPlayerCfg(); c.builtin = !c.builtin; writePlayerCfg(c); try { if (playerWin && !playerWin.isDestroyed()) playerWin.destroy(); } catch {} }
    return { has, mode: has && !wantBuiltin() ? 'folia' : 'builtin' };
  });
  ipcMain.handle('player-open', async e => {
    if (!win || e.sender !== win.webContents) return { ok: false };
    if (playerWin && !playerWin.isDestroyed()) { if (playerWin.isMinimized()) playerWin.restore(); playerWin.show(); playerWin.focus(); return { ok: true, mode: 'builtin' }; }
    const dir = !wantBuiltin() && foliaDir();
    if (dir && startFolia(dir)) return { ok: true, mode: 'folia' };     // folia 已在运行时再起一次：新进程拿不到单实例锁，会让已有窗口弹到前面然后自己退出（退出码 0，不算失败）
    openBuiltin();
    return { ok: true, mode: 'builtin' };
  });

  // ── 五子棋对战：独立窗口（gomoku.html + gomoku-preload.js）。消息经主进程在「主窗口 ⇄ 棋盘窗口」之间转发 ──
  ipcMain.on('game-open', (e, info) => {
    if (!win || e.sender !== win.webContents || !info) return;
    closeGameWin(true);
    gameInit = { side: info.side === 2 ? 2 : 1, turn: info.turn === 2 ? 2 : 1, host: !!info.host, peerName: String(info.peerName || '对方').slice(0, 64), gid: String(info.gid || '') };
    gameReady = false; gameQ = [];
    const gw = gameWin = new BrowserWindow({
      width: 1240, height: 900, minWidth: 360, minHeight: 560,
      backgroundColor: '#e6d8bb', title: '智斗五子棋·文房雅趣 · 瞬流Pro', icon: path.join(__dirname, 'icon.png'), autoHideMenuBar: true,
      webPreferences: { preload: path.join(__dirname, 'gomoku-preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true, backgroundThrottling: false }
    });
    gw.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
    gw.on('closed', () => {
      const mine = gw === gameWin;
      if (mine) { gameWin = null; gameReady = false; gameQ = []; }
      if (mine && !gameClosing && win && !win.isDestroyed()) win.webContents.send('game-closed');
    });
    gw.loadFile('gomoku.html');
    try { gw.focus(); } catch {}
  });
  ipcMain.on('game-init', e => { e.returnValue = gameWin && e.sender === gameWin.webContents ? gameInit : null; });
  ipcMain.on('game-ready', e => {
    if (!gameWin || e.sender !== gameWin.webContents) return;
    gameReady = true;
    for (const d of gameQ) gameWin.webContents.send('game-msg', d);
    gameQ = [];
  });
  ipcMain.on('game-send', (e, d) => { if (gameWin && e.sender === gameWin.webContents && win && !win.isDestroyed()) win.webContents.send('game-out', d); });
  ipcMain.on('game-in', (e, d) => {
    if (!win || e.sender !== win.webContents || !gameWin) return;
    if (gameReady) gameWin.webContents.send('game-msg', d); else if (gameQ.length < 500) gameQ.push(d);
  });
  ipcMain.on('game-close', e => { if (win && e.sender === win.webContents) closeGameWin(true); });
  ipcMain.on('game-focus', e => { if (gameWin && !gameWin.isDestroyed()) { if (gameWin.isMinimized()) gameWin.restore(); gameWin.show(); gameWin.focus(); } });

  createWindow();
});

app.on('before-quit', () => { quitting = true; });
app.on('will-quit', () => { try { globalShortcut.unregisterAll(); } catch {} });
app.on('window-all-closed', () => app.quit());
