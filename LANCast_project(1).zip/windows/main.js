'use strict';
const { app, BrowserWindow, session, desktopCapturer, screen, powerSaveBlocker, ipcMain, dialog, shell, globalShortcut, Menu } = require('electron');
const path = require('path');

// 窗口被最小化/遮挡时也不要降低定时器与渲染优先级（投屏时很重要）
app.commandLine.appendSwitch('disable-renderer-backgrounding');
app.commandLine.appendSwitch('disable-background-timer-throttling');
app.commandLine.appendSwitch('disable-backgrounding-occluded-windows');
// 被别的窗口盖住 / 最小化时，Chromium 会把页面判成「不可见」并降低优先级：控制电脑时对方一最大化别的窗口、盖住瞬流窗口，投屏就可能顿住
app.commandLine.appendSwitch('disable-features', 'CalculateNativeWinOcclusion');
// 让部分被 Chromium 黑名单误伤的显卡也能走硬件编解码
app.commandLine.appendSwitch('ignore-gpu-blocklist');

let win = null;
let psb = null;
let ctlLive = false;        // 本机正被对方控制中
let quitting = false;      // 真的要退出（托盘 / 系统关机 / app.quit）
const END_KEY = 'CommandOrControl+Alt+Shift+Q';
/* 被控期间不再显示屏幕顶部的「正在被控制」提示条；终止方式保留全局热键 Ctrl+Alt+Shift+Q（以及观看方 / 本机主窗口里结束会话）。 */
function ctlBanner(on) {
  if (on) { try { globalShortcut.register(END_KEY, () => { if (win && !win.isDestroyed()) win.webContents.send('ctl-end'); }); } catch {} }
  else { try { globalShortcut.unregister(END_KEY); } catch {} }
}
let playerWin = null;     // 独立音乐播放器窗口（folia-major 网页版，见 build-player.js）
let gameWin = null, gameInit = null, gameReady = false, gameQ = [], gameClosing = false;   // 五子棋对战窗口
function closeGameWin(silent) {
  if (!gameWin || gameWin.isDestroyed()) { gameWin = null; return; }
  gameClosing = !!silent;
  try { gameWin.destroy(); } catch {}
  gameClosing = false; gameWin = null;
}
let psbM = null;          // 沉浸音乐播放期间阻止应用被系统挂起（屏幕可以熄灭）；与文件传输各用各的，互不覆盖
let psbX = null;          // 文件传输期间阻止系统休眠（屏幕可以熄灭）

/* ───────── 独立音乐播放器窗口 ───────── */
const PLAYER_PART = 'persist:player';          // 独立分区：登录状态 / 音乐库 / 设置在重启后都还在，也不和主窗口互相污染
const playerCfgPath = () => path.join(app.getPath('userData'), 'player.json');
function readPlayerCfg() { try { return JSON.parse(require('fs').readFileSync(playerCfgPath(), 'utf8')) || {}; } catch { return {}; } }
function writePlayerCfg(o) { try { require('fs').writeFileSync(playerCfgPath(), JSON.stringify(o)); } catch {} }
/* 地址规范化：只接受 http(s)；没写协议时，内网 / 本机地址补 http://，其余补 https:// */
function normPlayerUrl(s) {
  s = String(s || '').trim();
  if (!s) return '';
  if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(s)) s = (/^(localhost|127\.|10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/i.test(s) ? 'http://' : 'https://') + s;
  try { const u = new URL(s); return /^https?:$/.test(u.protocol) ? u.href : ''; } catch { return ''; }
}
const escHtml = t => String(t).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
function playerErrorPage(url, desc) {
  const h = '<!doctype html><meta charset="utf-8"><title>音乐播放器</title><body style="margin:0;height:100vh;display:flex;align-items:center;justify-content:center;background:#000;color:#ddd;font:15px/1.7 system-ui,\'Microsoft YaHei\',sans-serif;text-align:center">' +
    '<div style="max-width:520px;padding:24px"><div style="font-size:40px">🎵</div><h2 style="font-weight:600;margin:8px 0">播放器页面打不开</h2>' +
    '<p style="color:#999;margin:0 0 4px">' + escHtml(desc || '网络不可用') + '</p><p style="color:#666;font-size:12px;word-break:break-all;margin:0 0 20px">' + escHtml(url) + '</p>' +
    '<button onclick="location.href=' + escHtml(JSON.stringify(url)) + '" style="padding:8px 26px;border:0;border-radius:8px;background:#fff;color:#000;font-size:14px;cursor:pointer">重试</button>' +
    '<p style="color:#666;font-size:12px;margin-top:18px">F5 / Ctrl+R 也可重新加载；换地址请回主窗口右键「沉浸音乐播放器」按钮</p></div></body>';
  return 'data:text/html;charset=utf-8,' + encodeURIComponent(h);
}
function openPlayerWin(src) {
  const cfg = readPlayerCfg(), b = cfg.bounds || {};
  const okB = b && b.width >= 720 && b.height >= 520;
  const ses = session.fromPartition(PLAYER_PART);
  // 权限：只放行播放器需要的（全屏 / 复制 / 本机字体），其余一律拒绝
  const OK_PERM = new Set(['fullscreen', 'clipboard-sanitized-write', 'local-fonts']);
  ses.setPermissionRequestHandler((wc, perm, cb) => cb(OK_PERM.has(perm)));
  ses.setPermissionCheckHandler((wc, perm) => OK_PERM.has(perm));
  const pw = playerWin = new BrowserWindow({
    width: okB ? b.width : 1280, height: okB ? b.height : 820, x: okB && Number.isFinite(b.x) ? b.x : undefined, y: okB && Number.isFinite(b.y) ? b.y : undefined,
    minWidth: 720, minHeight: 520, show: false,
    backgroundColor: '#000000', title: '音乐播放器 · 瞬流Pro', icon: path.join(__dirname, 'icon.png'), autoHideMenuBar: true,
    webPreferences: { contextIsolation: true, nodeIntegration: false, sandbox: true, backgroundThrottling: false, partition: PLAYER_PART }
  });
  if (okB && b.max) pw.maximize();
  const showT = setTimeout(() => { try { if (!pw.isDestroyed()) pw.show(); } catch {} }, 3000);   // 页面久不出画面也要先把窗口亮出来（黑底，不闪白）
  pw.once('ready-to-show', () => { clearTimeout(showT); try { pw.show(); } catch {} });
  pw.on('page-title-updated', e => e.preventDefault());
  let origin = '';
  try { if (src.url) origin = new URL(src.url).origin; } catch {}
  pw.webContents.setWindowOpenHandler(({ url }) => { if (/^https?:/.test(url)) shell.openExternal(url); return { action: 'deny' }; });
  pw.webContents.on('will-navigate', (e, url) => {          // 网页版：不让播放器窗口被带去别的站点；离开本站的链接交给系统浏览器
    if (url.startsWith('data:')) return;
    let o = ''; try { o = new URL(url).origin; } catch {}
    if (src.file ? !url.startsWith('file:') : o !== origin) { e.preventDefault(); if (/^https?:/.test(url)) shell.openExternal(url); }
  });
  pw.webContents.on('did-fail-load', (e, code, desc, url, isMain) => {
    if (!isMain || code === -3 || !src.url) return;         // -3 = 被新的导航取代，不算失败
    pw.loadURL(playerErrorPage(src.url, desc));
  });
  // 没有菜单栏：补上常用快捷键（刷新 / 全屏 / 缩放）
  pw.webContents.on('before-input-event', (e, i) => {
    if (i.type !== 'keyDown') return;
    const ctrl = i.control || i.meta, wc = pw.webContents, k = i.key;
    if (k === 'F5' || (ctrl && (k === 'r' || k === 'R'))) { e.preventDefault(); i.shift ? wc.reloadIgnoringCache() : wc.reload(); }
    else if (k === 'F11') { e.preventDefault(); pw.setFullScreen(!pw.isFullScreen()); }
    else if (ctrl && (k === '=' || k === '+')) { e.preventDefault(); wc.setZoomLevel(Math.min(wc.getZoomLevel() + 0.5, 3)); }
    else if (ctrl && k === '-') { e.preventDefault(); wc.setZoomLevel(Math.max(wc.getZoomLevel() - 0.5, -3)); }
    else if (ctrl && k === '0') { e.preventDefault(); wc.setZoomLevel(0); }
  });
  const saveBounds = () => { try { if (pw.isDestroyed() || pw.isFullScreen() || pw.isMinimized()) return; const c = readPlayerCfg(); const max = pw.isMaximized(); c.bounds = Object.assign({}, max ? c.bounds : pw.getBounds(), { max }); writePlayerCfg(c); } catch {} };
  pw.on('close', saveBounds);
  pw.on('closed', () => { clearTimeout(showT); if (pw === playerWin) playerWin = null; });
  if (src.file) pw.loadFile(src.file); else pw.loadURL(src.url);
}

function createWindow() {
  win = new BrowserWindow({
    width: 1120,
    height: 740,
    minWidth: 760,
    minHeight: 520,
    backgroundColor: '#e9edf1',
    title: '瞬流Pro',
    icon: path.join(__dirname, 'icon.png'),
    autoHideMenuBar: true,
    webPreferences: {
      nodeIntegration: true,      // 渲染进程直接使用 net / dgram / crypto（只加载本地页面）
      contextIsolation: false,
      backgroundThrottling: false
    }
  });
  win.on('focus', () => { try { win.flashFrame(false); } catch {} });
  /* 被控制期间，对方在电脑画面里点瞬流窗口右上角的「×」不应该把整个程序关掉（关掉 = 连接断开 = 对方失去控制）：改成最小化。
   * 想真正退出：先结束会话（本机主窗口「结束当前会话」，或全局热键 Ctrl+Alt+Shift+Q），再关窗口。 */
  win.on('close', e => { if (ctlLive && !quitting) { e.preventDefault(); try { win.minimize(); } catch {} } });
  win.on('session-end', () => { quitting = true; });
  win.loadFile('index.html');
}

app.whenReady().then(() => {
  Menu.setApplicationMenu(null);     // 去掉默认菜单：否则控制对方时 Ctrl+R 之类的按键会被本机菜单抢走
  // getDisplayMedia 不弹选择框：直接抓主屏 + 系统音频回环（WASAPI loopback，无损 PCM）
  session.defaultSession.setDisplayMediaRequestHandler(async (req, cb) => {
    try {
      const srcs = await desktopCapturer.getSources({ types: ['screen'] });
      const pid = String(screen.getPrimaryDisplay().id);
      const src = srcs.find(s => s.display_id === pid) || srcs[0];
      cb({ video: src, audio: 'loopback' });
    } catch (e) {
      cb({});
    }
  }, { useSystemPicker: false });

  ipcMain.on('keep-awake', (e, on) => {
    if (on && psb === null) psb = powerSaveBlocker.start('prevent-display-sleep');
    if (!on && psb !== null) { powerSaveBlocker.stop(psb); psb = null; }
  });

  // ── 文件互传需要的系统对话框 / 路径 / 防休眠 ──
  ipcMain.on('keep-awake-xfer', (e, on) => {
    if (on && psbX === null) psbX = powerSaveBlocker.start('prevent-app-suspension');
    if (!on && psbX !== null) { powerSaveBlocker.stop(psbX); psbX = null; }
  });
  // 沉浸音乐：播放期间 ① 阻止应用被系统挂起 ② 接管键盘媒体键（播放/暂停、上一首、下一首）③ 渲染进程保持高优先级
  const MEDIA_KEYS = { MediaPlayPause: 'toggle', MediaNextTrack: 'next', MediaPreviousTrack: 'prev' };
  ipcMain.on('keep-awake-music', (e, on) => {
    if (on && psbM === null) psbM = powerSaveBlocker.start('prevent-app-suspension');
    if (!on && psbM !== null) { powerSaveBlocker.stop(psbM); psbM = null; }
    for (const [acc, k] of Object.entries(MEDIA_KEYS)) {
      try {
        if (on) globalShortcut.register(acc, () => { if (win && !win.isDestroyed()) win.webContents.send('music-key', k); });
        else globalShortcut.unregister(acc);
      } catch {}
    }
    try { if (win && !win.isDestroyed()) win.webContents.setBackgroundThrottling(false); } catch {}
  });
  ipcMain.on('get-path', (e, name) => { try { e.returnValue = app.getPath(name); } catch { e.returnValue = ''; } });
  ipcMain.handle('pick-files', async () => {
    const r = await dialog.showOpenDialog(win, { title: '选择要发送的文件', properties: ['openFile', 'multiSelections'] });
    return r.canceled ? [] : r.filePaths;
  });
  ipcMain.handle('pick-folder', async (e, def) => {
    const r = await dialog.showOpenDialog(win, { title: '选择接收文件的保存位置', defaultPath: def || undefined, properties: ['openDirectory', 'createDirectory'] });
    return r.canceled ? '' : r.filePaths[0];
  });
  ipcMain.on('open-folder', (e, p) => { if (p) shell.openPath(p); });
  ipcMain.on('show-item', (e, p) => { if (p) shell.showItemInFolder(p); });
  ipcMain.on('open-item', (e, p) => { if (p) shell.openPath(p); });      // 聊天里的图片 / 视频预览：内核打不开的格式交给系统默认程序

  // Chromium 要求 getDisplayMedia 必须在「用户手势」中调用；网络事件触发的调用没有手势，
  // 所以由主进程用 userGesture=true 的方式在页面里执行（页面把流存到 window.__capStream）。
  ipcMain.handle('capture', (e, json) => win.webContents.executeJavaScript('window.__capture(' + json + ')', true));

  // ── 屏幕控制（本机被控）──
  // 输入注入（inject.js）在渲染进程里执行，见 renderer.js 顶部的说明；主进程只管全局热键和「被控期间关窗口 = 最小化」
  ipcMain.on('ctl-active', (e, info) => { ctlLive = !!(info && info.on); ctlBanner(ctlLive); });
  ipcMain.on('ctl-end', () => { if (win && !win.isDestroyed()) win.webContents.send('ctl-end'); });

  ipcMain.on('flash', () => { try { if (win && !win.isDestroyed() && !win.isFocused()) win.flashFrame(true); } catch {} });   // 收到聊天消息：任务栏图标闪烁
  ipcMain.on('focus', () => { if (!win) return; if (win.isMinimized()) win.restore(); win.show(); win.focus(); });

  // ── 独立音乐播放器（folia-major）：优先用本地打包的 player/；还没构建时直接打开 folia-major 网页版（地址在页面里设置一次，之后记住） ──
  ipcMain.handle('player-url-get', () => readPlayerCfg().url || '');
  ipcMain.handle('player-url-set', (e, u) => {
    const url = u === '' ? '' : normPlayerUrl(u);
    if (u !== '' && !url) return { ok: false };
    const c = readPlayerCfg(); c.url = url; writePlayerCfg(c);
    return { ok: true, url };
  });
  ipcMain.handle('player-open', e => {
    if (!win || e.sender !== win.webContents) return { ok: false };
    if (playerWin && !playerWin.isDestroyed()) { if (playerWin.isMinimized()) playerWin.restore(); playerWin.show(); playerWin.focus(); return { ok: true }; }
    const fs = require('fs');
    const idx = path.join(__dirname, 'player', 'index.html');
    const local = fs.existsSync(idx);
    const remote = local ? '' : (process.env.LANCAST_PLAYER_URL ? normPlayerUrl(process.env.LANCAST_PLAYER_URL) : normPlayerUrl(readPlayerCfg().url));
    if (!local && !remote) return { ok: false, needUrl: true };      // 既没打包也没配地址：让页面弹出设置框
    openPlayerWin(local ? { file: idx } : { url: remote });
    return { ok: true, mode: local ? 'local' : 'web' };
  });

  // ── 五子棋对战：独立窗口（gomoku.html + gomoku-preload.js）。消息经主进程在「主窗口 ⇄ 棋盘窗口」之间转发 ──
  ipcMain.on('game-open', (e, info) => {
    if (!win || e.sender !== win.webContents || !info) return;
    closeGameWin(true);
    gameInit = { side: info.side === 2 ? 2 : 1, turn: info.turn === 2 ? 2 : 1, host: !!info.host, peerName: String(info.peerName || '对方').slice(0, 64), gid: String(info.gid || '') };
    gameReady = false; gameQ = [];
    const gw = gameWin = new BrowserWindow({
      width: 1240, height: 900, minWidth: 360, minHeight: 560,
      backgroundColor: '#e6d8bb', title: '智斗五子棋·文房雅趣 · 瞬流Pro', icon: path.join(__dirname, 'icon.png'), autoHideMenuBar: true,
      webPreferences: { preload: path.join(__dirname, 'gomoku-preload.js'), contextIsolation: true, nodeIntegration: false, sandbox: true, backgroundThrottling: false }
    });
    gw.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
    gw.on('closed', () => {
      const mine = gw === gameWin;
      if (mine) { gameWin = null; gameReady = false; gameQ = []; }
      if (mine && !gameClosing && win && !win.isDestroyed()) win.webContents.send('game-closed');
    });
    gw.loadFile('gomoku.html');
    try { gw.focus(); } catch {}
  });
  ipcMain.on('game-init', e => { e.returnValue = gameWin && e.sender === gameWin.webContents ? gameInit : null; });
  ipcMain.on('game-ready', e => {
    if (!gameWin || e.sender !== gameWin.webContents) return;
    gameReady = true;
    for (const d of gameQ) gameWin.webContents.send('game-msg', d);
    gameQ = [];
  });
  ipcMain.on('game-send', (e, d) => { if (gameWin && e.sender === gameWin.webContents && win && !win.isDestroyed()) win.webContents.send('game-out', d); });
  ipcMain.on('game-in', (e, d) => {
    if (!win || e.sender !== win.webContents || !gameWin) return;
    if (gameReady) gameWin.webContents.send('game-msg', d); else if (gameQ.length < 500) gameQ.push(d);
  });
  ipcMain.on('game-close', e => { if (win && e.sender === win.webContents) closeGameWin(true); });
  ipcMain.on('game-focus', e => { if (gameWin && !gameWin.isDestroyed()) { if (gameWin.isMinimized()) gameWin.restore(); gameWin.show(); gameWin.focus(); } });

  createWindow();
});

app.on('before-quit', () => { quitting = true; });
app.on('will-quit', () => { try { globalShortcut.unregisterAll(); } catch {} });
app.on('window-all-closed', () => app.quit());
