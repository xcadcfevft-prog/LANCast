'use strict';
/* 应用入口（package.json 的 main）：同一个 exe 有两个角色。
 *   默认           → 瞬流自己的主进程（main.js）
 *   LANCAST_ROLE=folia → folia 播放器的主进程（folia-host.js，原样运行 resources/folia/electron/main.cjs，见 foliaLauncher.js） */
if (process.env.LANCAST_ROLE === 'folia') require('./folia-host').run();
else require('./main');
