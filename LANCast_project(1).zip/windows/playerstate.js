'use strict';
/* 独立音乐播放器窗口（folia / 内置本地音乐库）的「沉浸外壳」逻辑 —— 纯逻辑，不 require electron，方便单元测试。
 * 页面里的 player-immersive.js 把「是否在播放 / 歌名 / 歌手 / 进度」报上来，这里据此：
 *   ① 播放期间阻止应用被系统挂起（息屏后音乐不断）；全屏沉浸时再阻止屏幕熄灭 / 降亮（歌词视觉效果不被打断）
 *   ② 窗口标题显示「歌名 - 歌手」，任务栏图标上显示歌曲进度条（暂停时变黄）
 *   ③ 页面汇报失联（页面崩溃 / 跳转）超过 staleMs 视为已停止，防止防休眠锁漏掉
 *   ④ 页面没汇报（比如 folia 走 WebAudio、没有 <audio> 元素）时，用 Chromium 自己的「正在出声」判断兜底
 * 不依赖 folia 源码：folia 只要设置了 navigator.mediaSession（现代播放器基本都会）或使用 <audio>/<video>/new Audio() 就能识别。 */

const BASE_TITLE = '音乐播放器 · 瞬流Pro';

const clean = (v, n) => (typeof v === 'string' ? v.replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, n) : '');
const num = (v, max) => (typeof v === 'number' && Number.isFinite(v) && v >= 0 && v <= max ? v : 0);

/* 页面报上来的东西一律当不可信数据清洗 */
function sanitize(raw) {
  const r = raw && typeof raw === 'object' ? raw : {};
  const dur = num(r.dur, 86400 * 2);
  return { playing: r.playing === true, fs: r.fs === true, title: clean(r.title, 200), artist: clean(r.artist, 200), pos: Math.min(num(r.pos, 86400 * 2), dur || Infinity), dur };
}

function makeTitle(s) {
  if (!s || !s.title) return BASE_TITLE;
  return s.title + (s.artist ? ' - ' + s.artist : '') + ' · 瞬流Pro';
}

/* 任务栏进度：-1 = 不显示；否则 0..1（保留 3 位，避免每秒抖动都去刷新任务栏） */
function progressOf(s) {
  if (!s || !(s.dur > 0) || !s.title && !s.playing) return -1;
  return Math.round(Math.min(1, Math.max(0, s.pos / s.dur)) * 1000) / 1000;
}

/* opts: { win, power:{start(type)→id, stop(id)}, audible?:()→bool, staleMs?, pollMs?, now?:()→ms } */
function createShell(opts) {
  const win = opts.win, power = opts.power, audible = opts.audible || (() => false);
  const staleMs = opts.staleMs || 5000, pollMs = opts.pollMs === undefined ? 1500 : opts.pollMs, now = opts.now || Date.now;
  let st = sanitize(null), seen = 0, lastTitle = null, lastProg = null, lastMode = null, idApp = null, idDisp = null, dead = false, timer = null;
  const live = () => !dead && win && !(typeof win.isDestroyed === 'function' && win.isDestroyed());
  const safe = f => { try { return f(); } catch { return undefined; } };

  const fresh = () => seen > 0 && now() - seen <= staleMs;
  /* 在播放吗：页面新鲜地报「在播放」，或者页面没说话 / 说没播但 Chromium 听得到声音 */
  const playing = () => (fresh() && st.playing) || (!!safe(audible) && !(fresh() && st.paused));
  const full = () => !!safe(() => win.isFullScreen()) || (fresh() && st.fs);      // 窗口全屏（F11）或页面内全屏（HTML Fullscreen API）

  function apply() {
    if (!live()) return;
    const p = playing();
    // ① 电源锁
    if (p && idApp === null) idApp = safe(() => power.start('prevent-app-suspension')) ?? null;
    if (!p && idApp !== null) { safe(() => power.stop(idApp)); idApp = null; }
    const wantDisp = p && full();
    if (wantDisp && idDisp === null) idDisp = safe(() => power.start('prevent-display-sleep')) ?? null;
    if (!wantDisp && idDisp !== null) { safe(() => power.stop(idDisp)); idDisp = null; }
    // ② 标题 + 任务栏进度
    const info = fresh() ? st : sanitize(null);
    const t = makeTitle(info);
    if (t !== lastTitle) { lastTitle = t; safe(() => win.setTitle(t)); }
    const prog = progressOf(info), mode = p ? 'normal' : 'paused';
    if (prog !== lastProg || (prog >= 0 && mode !== lastMode)) {
      lastProg = prog; lastMode = mode;
      safe(() => (prog < 0 ? win.setProgressBar(-1) : win.setProgressBar(prog, { mode })));
    }
  }

  function update(raw) {
    if (!live()) return;
    const s = sanitize(raw);
    s.paused = !s.playing;                       // 页面明确说「没在播」
    st = s; seen = now();
    apply();
  }

  if (pollMs > 0) { timer = setInterval(apply, pollMs); if (timer.unref) timer.unref(); }   // 失联检测 + 全屏切换 + 音频兜底，都靠这个心跳
  return {
    update,
    refresh: apply,                               // 窗口进入 / 退出全屏时调用，立即调整屏幕防熄灭
    isPlaying: () => live() && playing(),
    dispose() {
      if (dead) return;
      if (idApp !== null) safe(() => power.stop(idApp)); if (idDisp !== null) safe(() => power.stop(idDisp));
      idApp = idDisp = null;
      if (timer) clearInterval(timer);
      safe(() => win.setProgressBar(-1));
      dead = true;
    }
  };
}

module.exports = { BASE_TITLE, sanitize, makeTitle, progressOf, createShell };
