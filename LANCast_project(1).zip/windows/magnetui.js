'use strict';
/* 瞬流 · 磁力下载界面（Windows）。引擎见 magnet.js；本文件只在 Electron 页面里运行。 */
(function () {
  if (typeof document === 'undefined' || !document.getElementById('magSec')) return;
  const { ipcRenderer, clipboard } = require('electron');
  const fs = require('fs'), path = require('path'), os = require('os'), cp = require('child_process');
  const M = require('./magnet.js');
  const q = s => document.querySelector(s);
  const sz = M.sizeText;
  const fmtT = s => { s = Math.max(0, Math.round(s)); const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), ss = s % 60; return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(ss).padStart(2, '0'); };
  const jget = (k, d) => { try { const v = JSON.parse(LS.get(k, '')); return v == null ? d : v; } catch { return d; } };

  /* ── 引擎 ── */
  const here = (() => { try { return path.dirname(require('url').fileURLToPath(location.href)); } catch { return process.cwd(); } })();
  const findBin = () => {
    for (const p of [path.join(process.resourcesPath || '', 'bin', 'aria2c.exe'), path.join(here, 'bin', 'aria2c.exe')]) { try { if (fs.existsSync(p)) return p; } catch {} }
    return 'aria2c';
  };
  const downloads = (() => { try { return ipcRenderer.sendSync('get-path', 'downloads') || ''; } catch { return ''; } })() || path.join(os.homedir(), 'Downloads');
  const dataDir = path.join((() => { try { return ipcRenderer.sendSync('get-path', 'userData') || ''; } catch { return ''; } })() || path.join(os.homedir(), '.lancast'), 'magnet');
  let saveDir = LS.get('magDir', '') || path.join(downloads, '瞬流', '磁力');
  const E = M.createEngine({ bin: findBin(), dataDir, defaultDir: saveDir, spawn: cp.spawn, pid: process.pid, trackers: jget('magTrk', null) });

  /* ── 小工具 ── */
  const hint = (m, cls) => { const h = q('#magHint'); h.textContent = m || ''; h.className = cls || ''; };
  const showDir = () => { q('#magDir').textContent = saveDir; };
  const pickDir = async () => { const d = await ipcRenderer.invoke('pick-folder', saveDir); if (d) { saveDir = d; LS.set('magDir', d); showDir(); } return d; };
  showDir();
  q('#magOpenDir').onclick = () => { try { fs.mkdirSync(saveDir, { recursive: true }); } catch {} ipcRenderer.send('open-folder', saveDir); };
  q('#magChgDir').onclick = pickDir;

  /* ── 高级设置 ── */
  const advInit = () => {
    q('#magDown').value = LS.get('magDown', '0'); q('#magUp').value = LS.get('magUp', '0'); q('#magSeed').checked = LS.get('magSeed', '0') === '1';
    const apply = async () => { try { await E.setGlobal({ down: +LS.get('magDown', '0') || 0, up: +LS.get('magUp', '0') || 0, seed: LS.get('magSeed', '0') === '1' }); } catch {} };
    q('#magDown').onchange = () => { LS.set('magDown', String(Math.max(0, +q('#magDown').value || 0))); apply(); };
    q('#magUp').onchange = () => { LS.set('magUp', String(Math.max(0, +q('#magUp').value || 0))); apply(); };
    q('#magSeed').onchange = () => { LS.set('magSeed', q('#magSeed').checked ? '1' : '0'); apply(); };
    ipcRenderer.invoke('magnet-protocol', null).then(on => { q('#magProto').checked = !!on; }).catch(() => {});
    q('#magProto').onchange = () => ipcRenderer.invoke('magnet-protocol', q('#magProto').checked).then(on => { q('#magProto').checked = !!on; hint(on ? '已设为默认。以后在浏览器里点磁力链接会直接打开瞬流（Windows 可能会让你在「默认应用」里确认一次）' : '已取消默认', 'ok'); });
    return apply;
  };
  const applyGlobal = advInit();
  const trkText = () => { q('#magTrk').textContent = 'Tracker：' + E.trackers.length + ' 个' + (jget('magTrkT', 0) ? '（已于 ' + new Date(jget('magTrkT', 0)).toLocaleDateString() + ' 在线更新）' : '（内置列表，联网后自动更新）'); };
  trkText();
  const refreshTrackers = async () => {
    if (Date.now() - jget('magTrkT', 0) < 24 * 3600e3 && jget('magTrk', null)) return;
    const list = await M.fetchTrackers(fetch.bind(window)); if (!list) return;
    LS.set('magTrk', JSON.stringify(list)); LS.set('magTrkT', String(Date.now()));
    await E.setTrackers(list); trkText();
  };

  /* ── 启动引擎（有未完成任务时开机即启动，否则第一次用时再启动） ── */
  let started = false, pollT = 0;
  async function ensure() {
    if (!started) {
      started = true;
      try { await E.start(); } catch (e) { started = false; throw e; }
      applyGlobal(); refreshTrackers();
      pollT = setInterval(tick, 1000); tick();
    }
  }
  const sessionFile = path.join(dataDir, 'aria2.session');
  try { if (fs.existsSync(sessionFile) && fs.statSync(sessionFile).size > 10) ensure().catch(e => hint(e.message, 'err')); } catch {}
  window.addEventListener('beforeunload', () => { try { E.shutdown(); } catch {} });

  /* ── 解析 / 选文件弹窗 ── */
  let cur = null;          // { h, timer, files, picked:Set, dir }
  const modal = q('#magModal');
  const closeModal = () => { modal.hidden = true; if (cur) { clearInterval(cur.timer); cur = null; } };
  function openModal(title) {
    q('#magMT').textContent = title; q('#magMS').textContent = ''; q('#magSpin').hidden = false; q('#magFilesWrap').hidden = true;
    q('#magStart').disabled = true; q('#magStart').hidden = false; q('#magCancel').textContent = '取消'; modal.hidden = false;
  }
  function modalError(msg) {
    if (cur) clearInterval(cur.timer);
    q('#magMT').textContent = '解析失败'; q('#magMS').textContent = msg; q('#magSpin').hidden = true; q('#magStart').hidden = true; q('#magCancel').textContent = '关闭';
  }
  const friendly = m => /already|重复|registered/i.test(m || '') ? '这个任务已经在列表里了' : (m || '未知错误');

  async function resolve(kind, payload) {
    if (cur) return;
    hint('');
    openModal(kind === 'magnet' ? '正在解析磁力链接…' : '正在读取 .torrent…');
    let h;
    try { await ensure(); h = kind === 'magnet' ? await E.resolveMagnet(payload, saveDir) : await E.resolveTorrent(payload, saveDir); }
    catch (e) { cur = {}; modalError(friendly(e.message)); return; }
    cur = { h, files: [], picked: new Set(), dir: saveDir, timer: 0 };
    const me = cur;
    const step = async () => {
      if (cur !== me) return;
      let r; try { r = await E.poll(h); } catch (e) { return modalError(friendly(e.message)); }
      if (cur !== me) return;
      if (r.state === 'error') return modalError(friendly(r.msg));
      if (r.state === 'resolving') {
        q('#magMS').textContent = '正在通过 DHT / Tracker 寻找节点并获取文件信息… 已连上 ' + r.peers + ' 个节点 · 用时 ' + r.secs + ' 秒' +
          (r.secs > 30 ? '\n还没找到？冷门资源可能暂时没人做种，可以继续等或稍后再试。' : '');
        q('#magMS').style.whiteSpace = 'pre-line';
        if (r.secs > 300) modalError('5 分钟仍未获取到文件信息，可能没有人做种。');
        return;
      }
      clearInterval(me.timer); showFiles(r);
    };
    me.timer = setInterval(step, 800); step();
  }

  function showFiles(r) {
    cur.r = r; cur.files = r.files.slice().sort((a, b) => a.rel.localeCompare(b.rel, 'zh'));
    cur.picked = new Set(cur.files.map(f => f.index));
    q('#magMT').textContent = r.name; q('#magSpin').hidden = true; q('#magFilesWrap').hidden = false; q('#magMS').textContent = '';
    q('#magMDir').textContent = cur.dir;
    const box = q('#magFiles'); box.innerHTML = '';
    const frag = document.createDocumentFragment();
    for (const f of cur.files) {
      const row = document.createElement('label'); row.className = 'mf';
      const cb = document.createElement('input'); cb.type = 'checkbox'; cb.checked = true; cb.dataset.i = f.index;
      const n = document.createElement('span'); n.className = 'n';
      const dir = path.posix.dirname(f.rel); n.textContent = path.posix.basename(f.rel);
      if (dir && dir !== '.') { const sm = document.createElement('small'); sm.textContent = '  ' + dir; n.appendChild(sm); }
      const s = document.createElement('span'); s.className = 's'; s.textContent = sz(f.length);
      row.append(cb, n, s); frag.appendChild(row);
    }
    box.appendChild(frag); syncSel();
  }
  function syncSel() {
    if (!cur) return;
    const boxes = [...q('#magFiles').querySelectorAll('input')]; cur.picked = new Set(boxes.filter(b => b.checked).map(b => +b.dataset.i));
    let tot = 0; for (const f of cur.files) if (cur.picked.has(f.index)) tot += f.length;
    q('#magSel').textContent = '已选 ' + cur.picked.size + ' / ' + cur.files.length + ' 个文件 · ' + sz(tot);
    q('#magAll').checked = cur.picked.size === cur.files.length; q('#magStart').disabled = cur.picked.size === 0;
  }
  q('#magFiles').addEventListener('change', syncSel);
  q('#magAll').onchange = () => { const on = q('#magAll').checked; q('#magFiles').querySelectorAll('input').forEach(b => { b.checked = on; }); syncSel(); };
  q('#magInv').onclick = () => { q('#magFiles').querySelectorAll('input').forEach(b => { b.checked = !b.checked; }); syncSel(); };
  q('#magMChg').onclick = async () => { const d = await pickDir(); if (d && cur) { cur.dir = d; q('#magMDir').textContent = d; } };
  q('#magCancel').onclick = async () => { const c = cur; closeModal(); if (c && c.h) { try { await E.discard(c.h); } catch {} } };
  q('#magStart').onclick = async () => {
    const c = cur; if (!c || !c.r) return; q('#magStart').disabled = true;
    try {
      await E.confirm(c.r.gid, { dir: c.dir, selected: [...c.picked], numFiles: c.files.length });
      closeModal(); q('#magInput').value = ''; hint('已开始下载：' + c.r.name, 'ok'); tick();
    } catch (e) { q('#magStart').disabled = false; q('#magMS').textContent = '开始失败：' + e.message; }
  };

  /* ── 入口：粘贴 / 回车 / .torrent / 剪贴板 / 系统打开 ── */
  function go() {
    const t = q('#magInput').value, n = M.normalizeInput(t);
    if (!n) { hint('没认出磁力链接：请粘贴 magnet:?xt=… 开头的链接，或 40 位 Hash', 'err'); return; }
    resolve('magnet', n.uri);
  }
  q('#magGo').onclick = go;
  q('#magInput').addEventListener('keydown', e => { if (e.key === 'Enter') go(); });
  q('#magTorrent').onclick = async () => { const f = await ipcRenderer.invoke('pick-torrent'); if (f) resolve('torrent', f); };
  let lastClip = '';
  const peekClipboard = () => {
    try {
      if (q('#magInput').value || !modal.hidden) return;
      const t = clipboard.readText(), n = M.normalizeInput(t);
      if (n && n.uri !== lastClip) { lastClip = n.uri; q('#magInput').value = n.uri; hint('已从剪贴板识别到磁力链接，点「解析」开始', 'ok'); }
    } catch {}
  };
  window.addEventListener('focus', peekClipboard); setTimeout(peekClipboard, 600);
  window.addEventListener('drop', e => {              // 把 .torrent 拖进本区域：解析，而不是当成文件发给手机
    if (!e.target.closest || !e.target.closest('#magSec')) return;
    const f = [...(e.dataTransfer ? e.dataTransfer.files : [])].find(x => /\.torrent$/i.test(x.name)); if (!f) return;
    e.preventDefault(); e.stopPropagation();
    let p = ''; try { p = require('electron').webUtils.getPathForFile(f) || f.path; } catch { p = f.path; }
    if (p) resolve('torrent', p);
  }, true);
  const openExternal = x => {
    if (!x) return; const n = M.normalizeInput(x);
    ipcRenderer.send('focus');
    if (n) { q('#magInput').value = n.uri; resolve('magnet', n.uri); }
    else if (/\.torrent$/i.test(x)) resolve('torrent', x);
  };
  ipcRenderer.on('magnet-open', (e, x) => openExternal(x));
  ipcRenderer.invoke('magnet-pending').then(list => (list || []).forEach(openExternal)).catch(() => {});

  /* ── 任务列表 ── */
  const cards = new Map();
  let doneLog = jget('magDone', []), lastTasks = [], awake = false;
  const saveLog = () => LS.set('magDone', JSON.stringify(doneLog.slice(0, 200)));
  const keyOf = t => (t.dir || '') + '|' + t.name;

  const stateOf = t => {
    if (t.status === 'error') return ['err', '失败'];
    if (t.status === 'complete') return ['done', '已完成'];
    if (t.status === 'paused') return ['paused', '已暂停'];
    if (t.status === 'waiting') return ['', '排队中'];
    if (t.verifying) return ['', '校验中'];
    if (t.seeding) return ['done', '做种中'];
    if (!t.total) return ['', '获取元数据'];
    return ['', t.down > 0 ? '下载中' : (t.peers ? '等待数据' : '寻找节点')];
  };
  function mkCard(gid) {
    const el = document.createElement('div'); el.className = 'mt';
    el.innerHTML = '<div class="mtTop"><span class="mtName"></span><span class="mtState"></span></div><div class="mtBar"><i></i></div><div class="mtInfo"><span class="mtStat"></span><span class="mtBtns"></span></div>';
    el._btns = ''; cards.set(gid, el); return el;
  }
  function btn(txt, fn, primary) { const b = document.createElement('button'); b.textContent = txt; if (primary) b.className = 'primary'; b.onclick = fn; return b; }
  async function removeTask(t) {
    const r = await ask('删除任务', '「' + t.name + '」\n要连同已下载的文件一起删除吗？', { buttons: ['仅删除任务', '同时删除文件', '取消'] });
    if (r.i === 2) return;
    if (t.live) { try { await E.remove(t, r.i === 1); } catch {} } else if (r.i === 1) E.deleteFiles(t);
    doneLog = doneLog.filter(x => keyOf(x) !== keyOf(t)); saveLog(); tick();
  }
  function sendTo(t) {
    const files = (t.files || []).filter(f => { try { return fs.statSync(f).isFile(); } catch { return false; } });
    if (!files.length) { hint('找不到已下载的文件（可能被移动或删除了）', 'err'); return; }
    if (window.FX && window.FX.sendTo) window.FX.sendTo(null, files);
  }
  function fill(el, t) {
    const [cls, label] = stateOf(t);
    el.className = 'mt ' + cls;
    el.querySelector('.mtName').textContent = t.name;
    el.querySelector('.mtState').textContent = label;
    const pct = t.total ? Math.min(100, t.done / t.total * 100) : (t.status === 'complete' ? 100 : 0);
    el.querySelector('.mtBar i').style.width = (t.status === 'complete' ? 100 : pct) + '%';
    let st;
    if (t.status === 'complete') st = sz(t.total) + ' · 已保存到 ' + (t.dir || '');
    else if (t.status === 'error') st = t.err || '下载出错';
    else st = pct.toFixed(1) + '% · ' + sz(t.done) + ' / ' + (t.total ? sz(t.total) : '—') +
      (t.status === 'active' ? ' · ↓ ' + sz(t.down) + '/s ↑ ' + sz(t.up) + '/s · 连接 ' + t.peers + '（做种 ' + t.seeders + '）' + (t.eta ? ' · 剩余 ' + fmtT(t.eta) : '') : '');
    el.querySelector('.mtStat').textContent = st;
    const sig = t.status + (t.seeding ? 's' : '') + (t.live ? '' : 'x');
    if (el._btns !== sig) {
      el._btns = sig; const box = el.querySelector('.mtBtns'); box.innerHTML = '';
      if (t.live) {
        if (t.status === 'active' || t.status === 'waiting') box.appendChild(btn('暂停', () => E.pause(t.gid).then(tick).catch(() => {})));
        if (t.status === 'paused') box.appendChild(btn('继续', () => E.resume(t.gid).then(tick).catch(() => {}), true));
      }
      if (t.status === 'complete') {
        box.appendChild(btn('发送到设备…', () => sendTo(t), true));
        box.appendChild(btn('在文件夹中显示', () => { const f = (t.files || [])[0]; if (f && fs.existsSync(f)) ipcRenderer.send('show-item', f); else ipcRenderer.send('open-folder', t.dir); }));
      }
      box.appendChild(btn('删除', () => removeTask(t)));
    }
    el._t = t;
  }
  function render(list) {
    const box = q('#magTasks'), want = new Set();
    const live = list.map(t => Object.assign({ live: true }, t));
    const liveKeys = new Set(live.map(keyOf));
    const old = doneLog.filter(x => !liveKeys.has(keyOf(x))).map(x => Object.assign({ live: false, status: 'complete', gid: 'log:' + keyOf(x), done: x.total, down: 0, up: 0, peers: 0, seeders: 0 }, x));
    const all = live.concat(old);
    const rank = t => t.status === 'complete' && !t.seeding ? 2 : t.status === 'paused' ? 1 : 0;
    all.sort((a, b) => rank(a) - rank(b));
    let prev = null;
    for (const t of all) {
      want.add(t.gid); let el = cards.get(t.gid) || mkCard(t.gid); fill(el, t);
      if (el.parentNode !== box || el.previousSibling !== prev) box.insertBefore(el, prev ? prev.nextSibling : box.firstChild);
      prev = el;
    }
    for (const [g, el] of cards) if (!want.has(g)) { el.remove(); cards.delete(g); }
    if (!all.length && !box.firstChild) { /* 空列表：不显示占位 */ }
  }
  let busy = false;
  async function tick() {
    if (busy || !started) return; busy = true;
    try {
      const list = await E.tasks(); lastTasks = list;
      for (const t of list) {
        if (t.status === 'complete' && !doneLog.some(x => keyOf(x) === keyOf(t))) {
          doneLog.unshift({ name: t.name, dir: t.dir, files: t.files, total: t.total, ts: Date.now() }); saveLog();
          try { new Notification('瞬流 · 下载完成', { body: t.name }); } catch {}
        }
      }
      render(list);
      const act = list.some(t => t.status === 'active' || t.status === 'waiting');
      if (act !== awake) { awake = act; ipcRenderer.send('keep-awake-mag', act); }
    } catch (e) { /* 引擎暂时没响应：下一秒再试 */ } finally { busy = false; }
  }
  q('#magClear').onclick = async () => {
    doneLog = []; saveLog();
    for (const t of lastTasks) if (t.status === 'complete' || t.status === 'error') { try { await E.remove(t, false); } catch {} }
    tick(); render(lastTasks.filter(t => t.status !== 'complete' && t.status !== 'error'));
  };
  render([]);
  window.MAG = { resolve, engine: E };
})();
