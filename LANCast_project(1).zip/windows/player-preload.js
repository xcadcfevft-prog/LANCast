'use strict';
/* 独立播放器窗口的预加载脚本：只暴露「音乐库」所需的最小接口（沙箱 + contextIsolation） */
const { contextBridge, ipcRenderer, webUtils } = require('electron');
contextBridge.exposeInMainWorld('lib', {
  get: () => ipcRenderer.invoke('pl-get'),
  rescan: () => ipcRenderer.invoke('pl-rescan'),
  addFolders: () => ipcRenderer.invoke('pl-add-folders'),
  addFiles: () => ipcRenderer.invoke('pl-add-files'),
  addPaths: list => ipcRenderer.invoke('pl-add-paths', list),
  removeFolder: p => ipcRenderer.invoke('pl-remove-folder', p),
  removeTrack: p => ipcRenderer.invoke('pl-remove-track', p),
  lyrics: p => ipcRenderer.invoke('pl-lyrics', p),
  reveal: p => ipcRenderer.send('pl-reveal', p),
  setDur: m => ipcRenderer.send('pl-dur', m),
  state: s => ipcRenderer.send('pl-state', s),            // 沉浸层汇报播放状态（见 player-immersive.js / playerstate.js）
  pathOf: f => { try { return webUtils.getPathForFile(f); } catch { return ''; } },
  onProgress: cb => ipcRenderer.on('pl-progress', (e, d) => cb(d))
});
