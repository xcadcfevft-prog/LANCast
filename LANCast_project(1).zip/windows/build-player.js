'use strict';
/* 构建独立播放器：拉取 folia-major（AGPL-3.0），以 ELECTRON=true（相对路径）构建网页版，输出到 windows/player/。
 * 用法：node build-player.js   （需要 git、Node >= 22、能访问 github / npm） */
const { execSync } = require('child_process');
const fs = require('fs'), path = require('path'), os = require('os');
const out = path.join(__dirname, 'player');
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'folia-'));
const run = (c, cwd, env) => execSync(c, { cwd, stdio: 'inherit', env: { ...process.env, ...env } });
run('git clone --depth 1 https://github.com/chthollyphile/folia-major .', tmp);
run('npm ci --no-audit --no-fund --ignore-scripts', tmp);
run('npx vite build', tmp, { ELECTRON: 'true' });
fs.rmSync(out, { recursive: true, force: true });
fs.cpSync(path.join(tmp, 'dist'), out, { recursive: true });
try { fs.copyFileSync(path.join(tmp, 'LICENSE'), path.join(out, 'LICENSE-folia-major')); } catch {}
fs.rmSync(tmp, { recursive: true, force: true });
console.log('播放器已输出到', out);
