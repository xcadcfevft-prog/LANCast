'use strict';
/* 构建 folia 播放器：拉取 folia-major（AGPL-3.0），打上 folia-patches/ 里的极简界面补丁，以 ELECTRON=true（相对路径）构建网页版，输出到 windows/player/。
 * 注意：LICENSE 文件和源码里的版权声明保持原样（AGPL 要求保留）。
 * 打包进 exe 后，主窗口「本地音乐库」按钮优先打开它；没构建 / 构建失败时自动使用内置的本地音乐库播放器（player-local/）。
 * 用法：node build-player.js   （需要 git、Node >= 24、能访问 github / npm） */
const { execSync } = require('child_process');
const fs = require('fs'), path = require('path'), os = require('os');
const out = path.join(__dirname, 'player');
const TAG = process.env.FOLIA_TAG || 'v0.7.25';          // 固定到已验证过的版本；设成空字符串则取最新
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'folia-'));
const run = (c, cwd, env) => execSync(c, { cwd, stdio: 'inherit', env: { ...process.env, ...env } });
try {
  try { run('git clone --depth 1' + (TAG ? ' --branch ' + TAG : '') + ' https://github.com/chthollyphile/folia-major .', tmp); }
  catch { fs.rmSync(tmp, { recursive: true, force: true }); fs.mkdirSync(tmp); run('git clone --depth 1 https://github.com/chthollyphile/folia-major .', tmp); }
  // 极简界面补丁：去掉更新说明 / 社区群 / 版本号 / 更新行 / 项目链接 / 网盘下载链接等（见 folia-patches/）。补丁对不上（上游版本变了）就让构建失败，退回内置播放器，也不发布带广告的版本。
  const pdir = path.join(__dirname, 'folia-patches');
  for (const f of fs.readdirSync(pdir).filter(x => x.endsWith('.patch')).sort()) run('git apply -p1 --whitespace=nowarn "' + path.join(pdir, f) + '"', tmp);
  run('npm ci --no-audit --no-fund --ignore-scripts', tmp);
  run('npx vite build', tmp, { ELECTRON: 'true' });
  if (!fs.existsSync(path.join(tmp, 'dist', 'index.html'))) throw new Error('构建产物缺少 index.html');
  fs.rmSync(out, { recursive: true, force: true });
  fs.cpSync(path.join(tmp, 'dist'), out, { recursive: true });
  try { fs.copyFileSync(path.join(tmp, 'LICENSE'), path.join(out, 'LICENSE-folia-major')); } catch {}
  console.log('播放器已输出到', out);
} catch (e) {
  console.error('folia 构建失败，将使用内置本地音乐库播放器：', e.message);   // 不让整个打包失败
} finally {
  fs.rmSync(tmp, { recursive: true, force: true });
}
