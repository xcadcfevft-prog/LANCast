'use strict';
/* 构建 folia 完整桌面端并放到 windows/folia/（随安装包进 resources/folia/）。
 * 不再只构建网页：folia 自带 Electron 主进程（electron/main.cjs）和预加载（preload.cjs），这里把它们连同前端产物、生产依赖一起装好，
 * 运行时由瞬流用同一个 exe 以 LANCAST_ROLE=folia 原样跑它（见 foliaLauncher.js / folia-host.js / entry.js）。
 * 步骤：取源码 → 打 folia-patches/*.patch → npm ci → vite build（ELECTRON=true）→ 只留生产依赖 → 组装目录 →（Windows 上）尽力拉取音频转码用的 ffmpeg。
 * 源码来源：环境变量 FOLIA_SRC 指向本地源码目录或 .tar.gz（离线 / 自己改过的版本）；否则按 FOLIA_TAG（默认 v0.7.25）从 GitHub 浅克隆。
 * 注意：LICENSE 和源码里的版权声明保持原样（AGPL-3.0 要求保留）。
 * 失败不会让打包失败：保留上一次成功的构建；没有的话放一个空目录占位（electron-builder 的 extraResources 需要它存在），运行时发现没有 folia 就用内置播放器。
 * 用法：node build-player.js   （需要 Node >= 24、git、能访问 github / npm） */
const { execSync } = require('child_process');
const fs = require('fs'), path = require('path'), os = require('os');
const launcher = require('./foliaLauncher');

const out = path.join(__dirname, 'folia');
const TAG = process.env.FOLIA_TAG || 'v0.7.25';          // 固定版本：补丁是针对这个版本写的，不回退到「最新」
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'folia-'));
const src = path.join(tmp, 'src'), stage = path.join(tmp, 'stage');
const run = (c, cwd, env) => execSync(c, { cwd, stdio: 'inherit', env: { ...process.env, ...env } });
const sizeMB = d => { let n = 0; const walk = p => { for (const e of fs.readdirSync(p, { withFileTypes: true })) { const f = path.join(p, e.name); if (e.isDirectory()) walk(f); else try { n += fs.statSync(f).size; } catch {} } }; walk(d); return (n / 1048576).toFixed(0); };

function fetchSource() {
  fs.mkdirSync(src, { recursive: true });
  const s = process.env.FOLIA_SRC;
  if (!s) { run('git clone --depth 1 --branch ' + TAG + ' https://github.com/chthollyphile/folia-major .', src); return; }
  const abs = path.resolve(s);
  if (fs.statSync(abs).isDirectory()) { fs.cpSync(abs, src, { recursive: true, filter: p => !/[\\/](node_modules|\.git|dist)([\\/]|$)/.test(p) }); return; }
  const ex = path.join(tmp, 'extract');
  fs.mkdirSync(ex);
  run('tar -xzf "' + abs + '" -C "' + ex + '"', tmp);                                // 压缩包里通常有一层 folia-major-x.y.z/
  const top = fs.readdirSync(ex).filter(n => fs.statSync(path.join(ex, n)).isDirectory());
  fs.cpSync(top.length === 1 ? path.join(ex, top[0]) : ex, src, { recursive: true });
  fs.rmSync(ex, { recursive: true, force: true });
}

/* 只带运行需要的：精简 package.json（去掉 electron-builder 配置 / 脚本 / 开发依赖），发布通道设成 internal = 关闭 folia 自己的检查更新 */
function assemble() {
  fs.mkdirSync(stage, { recursive: true });
  const pkg = JSON.parse(fs.readFileSync(path.join(src, 'package.json'), 'utf8'));
  const slim = { name: pkg.name, productName: pkg.productName || 'Folia', version: pkg.version, description: pkg.description, author: pkg.author, license: pkg.license, type: pkg.type, main: 'electron/main.cjs', foliaReleaseChannel: 'internal', dependencies: pkg.dependencies, optionalDependencies: pkg.optionalDependencies };
  fs.writeFileSync(path.join(stage, 'package.json'), JSON.stringify(slim, null, 2));
  for (const d of ['electron', 'shared', 'dist', 'node_modules']) if (fs.existsSync(path.join(src, d))) fs.cpSync(path.join(src, d), path.join(stage, d), { recursive: true });
  fs.mkdirSync(path.join(stage, 'build'), { recursive: true });
  for (const f of ['icon.png', 'miao.png', 'trayTemplate.png', 'trayTemplate@2x.png']) { try { fs.copyFileSync(path.join(src, 'build', f), path.join(stage, 'build', f)); } catch {} }
  try { fs.cpSync(path.join(src, 'build', 'thumbar'), path.join(stage, 'build', 'thumbar'), { recursive: true }); } catch {}
  for (const f of ['icon.png', 'trayTemplate.png', 'trayTemplate@2x.png']) { try { fs.copyFileSync(path.join(src, 'build', f), path.join(stage, f)); } catch {} }   // folia 把 process.resourcesPath 当作安装目录根找这些图标
  try { fs.rmSync(path.join(stage, 'node_modules', 'youtubei.js', 'bundle'), { recursive: true, force: true }); } catch {}   // 与 folia 自己的打包规则一致（!**/node_modules/youtubei.js/bundle/**）
  try { fs.copyFileSync(path.join(src, 'LICENSE'), path.join(stage, 'LICENSE-folia-major')); } catch {}
}

/* 音频转码兜底（folia 自己的「转码回退」，播放 WebAudio 解不了的格式时用）：尽力而为，拉不到就没有这个能力，不影响其它 */
function ffmpegBestEffort() {
  const osName = { win32: 'win', darwin: 'mac', linux: 'linux' }[process.platform];
  if (!osName || (process.platform !== 'win32' && process.env.FOLIA_FFMPEG !== '1')) return;
  try {
    run('node packaging/ffmpeg/fetch-ffmpeg.mjs', src);
    const dir = path.join(src, 'build', 'ffmpeg', osName + '-' + process.arch);
    if (fs.existsSync(dir)) { fs.cpSync(dir, path.join(stage, 'ffmpeg-audio'), { recursive: true }); console.log('已带上音频转码 ffmpeg（ffmpeg-audio/）'); }
  } catch (e) { console.warn('没能拉取音频转码用的 ffmpeg，继续（少数格式可能放不了）：', e.message); }
}

try {
  fetchSource();
  const pdir = path.join(__dirname, 'folia-patches');                 // 极简界面（去推广）+ 放行用户亲手选的下载 / 桌面 / 文档 / 音乐文件夹；对不上就让整个构建失败，不发布半成品
  for (const f of fs.readdirSync(pdir).filter(x => x.endsWith('.patch')).sort()) run('git apply -p1 --whitespace=nowarn "' + path.join(pdir, f) + '"', src);
  run('npm ci --no-audit --no-fund --ignore-scripts', src);
  run('npx vite build', src, { ELECTRON: 'true', ELECTRON_DEV: 'false' });
  if (!fs.existsSync(path.join(src, 'dist', 'index.html'))) throw new Error('构建产物缺少 dist/index.html');
  run('npm prune --omit=dev --no-audit --no-fund --ignore-scripts', src);   // 去掉 vite / electron / 测试等开发依赖，只留主进程运行需要的
  assemble();
  ffmpegBestEffort();
  if (!launcher.findFoliaDir([stage], fs.existsSync)) throw new Error('组装结果缺少必需文件：' + launcher.REQUIRED.join(', '));
  if (!fs.existsSync(path.join(stage, 'node_modules', 'electron-store'))) throw new Error('生产依赖不完整（缺 electron-store）');
  fs.rmSync(out, { recursive: true, force: true });
  fs.cpSync(stage, out, { recursive: true });
  console.log('folia 完整桌面端已输出到 ' + out + '（约 ' + sizeMB(out) + ' MB）');
} catch (e) {
  console.error('folia 构建失败，将使用内置本地音乐库播放器：', e.message);   // 不让整个打包失败
  try { if (!fs.existsSync(out)) { fs.mkdirSync(out, { recursive: true }); fs.writeFileSync(path.join(out, 'NOT-BUILT.txt'), 'folia 没有构建成功，运行时会使用内置播放器。\n'); } } catch {}
} finally {
  fs.rmSync(tmp, { recursive: true, force: true });
}
