'use strict';
/*
 * 瞬流 · 磁力下载引擎（Windows）
 * ─────────────────────────────────────────────────────────────
 * 内核：aria2c 子进程（bin/aria2c.exe）+ 本机 JSON-RPC（127.0.0.1、随机端口、随机口令）。
 * 支持：magnet 链接 / 40 位 Hash / 32 位 base32 Hash / .torrent 文件；DHT(v4+v6)、PEX、LSD、Tracker、
 *       协议加密(可选)、WebSeed、选择性下载、断点续传、重启后自动恢复任务。
 *
 * 解析流程（两步，先看文件再下载）：
 *   1. resolveMagnet / resolveTorrent：用 pause-metadata 取元数据，下载任务停在「暂停」，不写任何数据；
 *   2. poll(handle) 返回文件列表 → 用户勾选 → confirm(...) 设置 select-file / dir 后继续下载。
 * 速度相关默认值：不限速、连接数放大、内置 + 在线更新的公共 Tracker 列表、DHT 路由表持久化。
 */
const http = require('http'), fs = require('fs'), path = require('path'), net = require('net'), crypto = require('crypto');

const BUILTIN_TRACKERS = [
  'udp://tracker.opentrackr.org:1337/announce', 'udp://open.demonii.com:1337/announce', 'udp://open.stealth.si:80/announce',
  'udp://tracker.torrent.eu.org:451/announce', 'udp://exodus.desync.com:6969/announce', 'udp://tracker.openbittorrent.com:6969/announce',
  'udp://explodie.org:6969/announce', 'udp://tracker1.bt.moack.co.kr:80/announce', 'udp://tracker.dler.org:6969/announce',
  'udp://open.tracker.cl:1337/announce', 'udp://tracker.tiny-vps.com:6969/announce', 'udp://opentracker.i2p.rocks:6969/announce',
  'udp://p4p.arenabg.com:1337/announce', 'udp://tracker.theoks.net:6969/announce', 'udp://tracker.bittor.pw:1337/announce',
  'udp://tracker-udp.gbitt.info:80/announce', 'udp://retracker.lanta-net.ru:2710/announce',
  'https://tracker.tamersunion.org:443/announce', 'http://tracker.opentrackr.org:1337/announce'
];
const TRACKER_SOURCES = [
  'https://cdn.jsdelivr.net/gh/ngosang/trackerslist@master/trackers_best.txt',
  'https://raw.githubusercontent.com/ngosang/trackerslist/master/trackers_best.txt',
  'https://ghproxy.net/https://raw.githubusercontent.com/ngosang/trackerslist/master/trackers_best.txt'
];
const KEYS = ['gid', 'status', 'totalLength', 'completedLength', 'downloadSpeed', 'uploadSpeed', 'connections', 'numSeeders',
  'followedBy', 'belongsTo', 'bittorrent', 'files', 'errorMessage', 'errorCode', 'infoHash', 'dir', 'seeder', 'verifiedLength', 'verifyIntegrityPending'];

/* ── 输入解析 ── */
function normalizeInput(text) {
  const s = String(text || '').trim();
  const m = s.match(/magnet:\?[^\s"'<>]+/i);
  if (m) return { kind: 'magnet', uri: m[0].replace(/[),.;]+$/, '') };
  const h = s.replace(/^(urn:)?btih:/i, '').trim();
  if (/^[0-9a-f]{40}$/i.test(h) || /^[A-Z2-7]{32}$/i.test(h)) return { kind: 'magnet', uri: 'magnet:?xt=urn:btih:' + (h.length === 40 ? h.toLowerCase() : h.toUpperCase()) };
  return null;
}
function magnetName(uri) { try { return new URL(uri).searchParams.get('dn') || ''; } catch { return ''; } }
function cleanTrackers(list) {
  const seen = new Set(), out = [];
  for (let t of list || []) {
    t = String(t || '').trim();
    if (!/^(udp|http|https|ws|wss):\/\//i.test(t) || seen.has(t)) continue;
    seen.add(t); out.push(t);
  }
  return out;
}

function freePort() {
  return new Promise((res, rej) => {
    const s = net.createServer(); s.on('error', rej);
    s.listen(0, '127.0.0.1', () => { const p = s.address().port; s.close(() => res(p)); });
  });
}

/*
 * o = { bin, dataDir, defaultDir, spawn, pid, log }
 * 返回的对象所有方法都是 async，出错抛 Error（message 为中文）。
 */
function createEngine(o) {
  const st = { proc: null, port: 0, secret: '', ready: null, trackers: cleanTrackers(o.trackers && o.trackers.length ? o.trackers : BUILTIN_TRACKERS), hidden: new Set(), dead: false };
  const log = o.log || (() => {});
  let rid = 0;

  function call(method, params, port, secret) {
    return new Promise((resolve, reject) => {
      const body = JSON.stringify({ jsonrpc: '2.0', id: String(++rid), method, params: ['token:' + secret].concat(params || []) });
      const req = http.request({ host: '127.0.0.1', port, path: '/jsonrpc', method: 'POST', headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body) }, timeout: 15000 }, res => {
        let s = ''; res.setEncoding('utf8'); res.on('data', d => { s += d; });
        res.on('end', () => {
          let j; try { j = JSON.parse(s); } catch { return reject(new Error('下载引擎返回了无法识别的数据')); }
          if (j.error) { const e = new Error(j.error.message || '下载引擎错误'); e.code = j.error.code; return reject(e); }
          resolve(j.result);
        });
      });
      req.on('timeout', () => req.destroy(new Error('下载引擎没有响应')));
      req.on('error', e => reject(e));
      req.end(body);
    });
  }
  const rpc = (method, ...params) => start().then(() => call(method, params, st.port, st.secret));

  function args(port) {
    const d = o.dataDir;
    return [
      '--enable-rpc=true', '--rpc-listen-port=' + port, '--rpc-listen-all=false', '--rpc-secret=' + st.secret, '--rpc-allow-origin-all=false',
      '--dir=' + o.defaultDir, '--input-file=' + path.join(d, 'aria2.session'), '--save-session=' + path.join(d, 'aria2.session'), '--save-session-interval=15',
      '--continue=true', '--auto-file-renaming=false', '--allow-overwrite=true', '--file-allocation=none', '--disk-cache=64M', '--async-dns=false',
      '--max-concurrent-downloads=5', '--max-overall-download-limit=0', '--max-overall-upload-limit=0', '--max-download-limit=0',
      /* BT：不限速、放大连接数、能找的渠道全开 */
      '--bt-max-peers=300', '--bt-request-peer-speed-limit=10M', '--bt-max-open-files=200', '--bt-tracker-connect-timeout=8', '--bt-tracker-timeout=15',
      '--bt-enable-lpd=true', '--enable-peer-exchange=true', '--enable-dht=true', '--enable-dht6=true',
      '--dht-entry-point=router.bittorrent.com:6881', '--dht-entry-point6=router.bittorrent.com:6881',
      '--dht-file-path=' + path.join(d, 'dht.dat'), '--dht-file-path6=' + path.join(d, 'dht6.dat'),
      '--listen-port=6881-6999', '--dht-listen-port=6881-6999',
      '--bt-min-crypto-level=plain', '--bt-require-crypto=false', '--bt-force-encryption=false',
      '--bt-save-metadata=true', '--bt-load-saved-metadata=true', '--bt-detach-seed-only=true', '--pause-metadata=true',
      '--follow-torrent=true', '--seed-time=0', '--seed-ratio=0',
      '--bt-tracker=' + st.trackers.join(','),
      '--stop-with-process=' + (o.pid || process.pid),
      '--console-log-level=warn', '--log-level=warn', '--log=' + path.join(d, 'aria2.log'), '--summary-interval=0', '--quiet=true'
    ];
  }

  function start() {
    if (st.ready) return st.ready;
    st.ready = (async () => {
      if (!o.bin) throw new Error('找不到下载引擎 aria2c.exe（应在安装目录的 resources\\bin 里）');
      fs.mkdirSync(o.dataDir, { recursive: true }); fs.mkdirSync(o.defaultDir, { recursive: true });
      st.secret = crypto.randomBytes(16).toString('hex');
      st.port = await freePort();
      let exited = '';
      const p = o.spawn(o.bin, args(st.port), { windowsHide: true, stdio: 'ignore' });
      st.proc = p; st.dead = false;
      p.on('error', e => { exited = e.message; });
      p.on('exit', code => { st.dead = true; exited = exited || ('退出码 ' + code); st.ready = null; log('aria2 exit ' + code); });
      for (let i = 0; i < 60; i++) {
        if (exited) throw new Error('下载引擎启动失败：' + exited);
        try { await call('aria2.getVersion', [], st.port, st.secret); return true; } catch {}
        await new Promise(r => setTimeout(r, 150));
      }
      try { p.kill(); } catch {}
      throw new Error('下载引擎启动超时（可能被杀毒软件拦截）');
    })();
    st.ready.catch(() => { st.ready = null; });
    return st.ready;
  }

  const baseOpts = (dir, extra) => Object.assign({ dir: dir || o.defaultDir, 'bt-tracker': st.trackers.join(',') }, extra || {});

  /* ── 第一步：取元数据（任务停在暂停，不下载内容） ── */
  async function resolveMagnet(uri, dir) {
    const gid = await rpc('aria2.addUri', [uri], baseOpts(dir, { 'pause-metadata': 'true' }));
    st.hidden.add(gid);
    return { gid, dir: dir || o.defaultDir, t0: Date.now(), hint: magnetName(uri) };
  }
  async function resolveTorrent(fileOrBuf, dir) {
    const buf = Buffer.isBuffer(fileOrBuf) ? fileOrBuf : fs.readFileSync(fileOrBuf);
    if (!buf.length || buf[0] !== 0x64) throw new Error('这不是有效的 .torrent 文件');
    const gid = await rpc('aria2.addTorrent', buf.toString('base64'), [], baseOpts(dir, { pause: 'true' }));
    st.hidden.add(gid);
    return { gid, dir: dir || o.defaultDir, t0: Date.now(), hint: '', direct: true };
  }
  async function poll(h) {
    const s = await rpc('aria2.tellStatus', h.gid, KEYS);
    if (s.status === 'error' || s.status === 'removed') return { state: 'error', msg: s.errorMessage || '解析失败' };
    let gid2 = h.direct ? h.gid : (s.followedBy && s.followedBy[0]);
    if (!gid2) return { state: 'resolving', peers: +s.connections || 0, seeders: +s.numSeeders || 0, speed: +s.downloadSpeed || 0, secs: Math.round((Date.now() - h.t0) / 1000) };
    st.hidden.add(gid2); h.gid2 = gid2;
    const [files, info] = await Promise.all([rpc('aria2.getFiles', gid2), rpc('aria2.tellStatus', gid2, ['bittorrent', 'infoHash', 'dir'])]);
    const root = (info.dir || h.dir);
    const list = files.map(f => ({ index: +f.index, path: f.path, rel: path.relative(root, f.path).replace(/\\/g, '/'), length: +f.length })).filter(f => !/(^|\/)_____padding_file/i.test(f.rel));
    const name = (info.bittorrent && info.bittorrent.info && info.bittorrent.info.name) || h.hint || (list[0] && list[0].rel.split('/')[0]) || info.infoHash;
    return { state: 'ready', gid: gid2, name, infoHash: info.infoHash, files: list, total: list.reduce((a, f) => a + f.length, 0) };
  }
  /* ── 第二步：确认 ── */
  async function confirm(gid, opt) {
    const o2 = { dir: opt.dir || o.defaultDir };
    if (opt.selected && opt.selected.length && opt.selected.length !== opt.numFiles) o2['select-file'] = opt.selected.slice().sort((a, b) => a - b).join(',');
    try { await rpc('aria2.changeOption', gid, o2); }
    catch (e) { if (!o2['select-file']) throw e; await rpc('aria2.changeOption', gid, { 'select-file': o2['select-file'] }); }   // 个别版本不允许改 dir：保住选文件
    st.hidden.delete(gid);
    await rpc('aria2.unpause', gid);
  }
  async function discard(h) {
    for (const g of [h.gid, h.gid2]) {
      if (!g) continue;
      try { await rpc('aria2.forceRemove', g); } catch {}
      try { await rpc('aria2.removeDownloadResult', g); } catch {}
      st.hidden.delete(g);
    }
  }

  /* ── 任务列表 ── */
  function mapTask(t) {
    const files = (t.files || []);
    const sel = files.filter(f => f.selected === 'true');
    const bt = t.bittorrent && t.bittorrent.info && t.bittorrent.info.name;
    const first = sel[0] || files[0];
    const total = +t.totalLength || 0, done = +t.completedLength || 0;
    return {
      gid: t.gid, name: bt || (first && path.basename(first.path)) || t.infoHash || t.gid, status: t.status, total, done,
      down: +t.downloadSpeed || 0, up: +t.uploadSpeed || 0, peers: +t.connections || 0, seeders: +t.numSeeders || 0,
      dir: t.dir, files: sel.map(f => f.path), seeding: t.seeder === 'true', err: t.errorMessage || '', verifying: t.verifyIntegrityPending === 'true',
      eta: (+t.downloadSpeed > 0 && total > done) ? Math.round((total - done) / +t.downloadSpeed) : 0
    };
  }
  async function tasks() {
    const r = await rpc('system.multicall', [
      { methodName: 'aria2.tellActive', params: ['token:' + st.secret, KEYS] },
      { methodName: 'aria2.tellWaiting', params: ['token:' + st.secret, 0, 200, KEYS] },
      { methodName: 'aria2.tellStopped', params: ['token:' + st.secret, 0, 200, KEYS] }
    ]);
    const all = [].concat(...r.map(x => Array.isArray(x) && Array.isArray(x[0]) ? x[0] : []));
    return all.filter(t => !st.hidden.has(t.gid) && !(t.followedBy && t.followedBy.length) && !t.belongsTo).map(mapTask);
  }
  const pause = gid => rpc('aria2.forcePause', gid);
  const resume = gid => rpc('aria2.unpause', gid);
  function deleteFiles(task) {
    if (!task.dir) return;
    const root = path.resolve(task.dir);
    for (const f of task.files || []) {
      const p = path.resolve(f);
      if (p.startsWith(root + path.sep)) { try { fs.rmSync(p, { force: true }); fs.rmSync(p + '.aria2', { force: true }); } catch {} }
    }
  }
  async function remove(task, withFiles) {
    try { await rpc('aria2.forceRemove', task.gid); } catch {}
    try { await rpc('aria2.removeDownloadResult', task.gid); } catch {}
    if (withFiles) deleteFiles(task);
  }
  /* ── 全局设置（0 = 不限） ── */
  async function setGlobal(g) {
    const opt = {};
    if (g.down != null) opt['max-overall-download-limit'] = String(Math.max(0, g.down | 0) * 1024);
    if (g.up != null) opt['max-overall-upload-limit'] = String(Math.max(0, g.up | 0) * 1024);
    if (g.seed != null) { opt['seed-time'] = g.seed ? '720' : '0'; opt['seed-ratio'] = g.seed ? '1.0' : '0'; }   // seed-time=0 即不做种
    if (g.peers != null) opt['bt-max-peers'] = String(Math.max(0, g.peers | 0));
    if (Object.keys(opt).length) await rpc('aria2.changeGlobalOption', opt);
  }
  async function setTrackers(list) {
    const t = cleanTrackers(list); if (!t.length) return 0;
    st.trackers = t;
    try { await rpc('aria2.changeGlobalOption', { 'bt-tracker': t.join(',') }); } catch {}
    return t.length;
  }
  async function global() { const s = await rpc('aria2.getGlobalStat'); return { down: +s.downloadSpeed || 0, up: +s.uploadSpeed || 0, active: +s.numActive || 0 }; }
  async function shutdown() {
    if (!st.proc || st.dead) return;
    try { await call('aria2.shutdown', [], st.port, st.secret); } catch { try { st.proc.kill(); } catch {} }
  }

  return { start, rpc, resolveMagnet, resolveTorrent, poll, confirm, discard, tasks, pause, resume, remove, deleteFiles, setGlobal, setTrackers, global, shutdown, get trackers() { return st.trackers; }, _st: st };
}

/* 在线 Tracker 列表（失败不影响使用，回退到内置列表） */
async function fetchTrackers(fetchFn, sources) {
  for (const u of sources || TRACKER_SOURCES) {
    try {
      const ctl = new AbortController(); const tm = setTimeout(() => ctl.abort(), 8000);
      const r = await fetchFn(u, { signal: ctl.signal }); clearTimeout(tm);
      if (!r.ok) continue;
      const list = cleanTrackers((await r.text()).split(/\s+/));
      if (list.length >= 5) return list;
    } catch {}
  }
  return null;
}

const sizeText = n => n >= 2 ** 40 ? (n / 2 ** 40).toFixed(2) + ' TB' : n >= 2 ** 30 ? (n / 2 ** 30).toFixed(2) + ' GB' : n >= 2 ** 20 ? (n / 2 ** 20).toFixed(1) + ' MB' : n >= 1024 ? (n / 1024).toFixed(0) + ' KB' : Math.round(n) + ' B';

module.exports = { createEngine, normalizeInput, fetchTrackers, cleanTrackers, BUILTIN_TRACKERS, sizeText, mapTaskKeys: KEYS };
