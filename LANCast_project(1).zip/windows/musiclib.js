'use strict';
/* 本地音乐库（电脑端独立播放器用）：递归扫描文件夹，解析 ID3v2 / FLAC / M4A 标签、内嵌封面、时长，结果缓存到 userData。
 * 纯 Node 逻辑，不碰 electron，方便单元测试。 */
const fs = require('fs'), path = require('path'), crypto = require('crypto');

const EXT = new Set(['.mp3', '.flac', '.wav', '.m4a', '.aac', '.ogg', '.oga', '.opus', '.wma', '.ape', '.aiff', '.aif', '.mp4', '.webm']);
const SKIP_DIR = /^(\$recycle\.bin|system volume information|node_modules|\.git)$/i;
const MAX_TAG = 16 * 1024 * 1024;
const isAudio = p => EXT.has(path.extname(p).toLowerCase());

async function rd(fh, pos, len) {
  const b = Buffer.alloc(len);
  const { bytesRead } = await fh.read(b, 0, len, pos);
  return bytesRead < len ? b.subarray(0, bytesRead) : b;
}
const syncsafe = (b, o) => ((b[o] & 127) << 21) | ((b[o + 1] & 127) << 14) | ((b[o + 2] & 127) << 7) | (b[o + 3] & 127);
const clean = s => String(s || '').replace(/\u0000+$/g, '').replace(/^\uFEFF/, '').trim();

function decodeText(enc, buf) {
  try {
    if (enc === 3) return clean(buf.toString('utf8'));
    if (enc === 1 || enc === 2) {
      let b = buf, be = enc === 2;
      if (b[0] === 0xFF && b[1] === 0xFE) { b = b.subarray(2); be = false; }
      else if (b[0] === 0xFE && b[1] === 0xFF) { b = b.subarray(2); be = true; }
      if (be) { b = Buffer.from(b); b.swap16(); }
      return clean(b.toString('utf16le'));
    }
    if (buf.some(x => x >= 0x80)) {          // 很多中文 MP3 标签其实是 GBK 却标成 latin1
      try { return clean(new TextDecoder('gbk', { fatal: true }).decode(buf)); } catch {}
    }
    return clean(buf.toString('latin1'));
  } catch { return ''; }
}
function termIdx(buf, from, enc) {            // 找字符串结尾（UTF-16 是双零字节）
  if (enc === 1 || enc === 2) { for (let i = from; i + 1 < buf.length; i += 2) if (buf[i] === 0 && buf[i + 1] === 0) return i; return buf.length; }
  const i = buf.indexOf(0, from); return i < 0 ? buf.length : i;
}

async function readId3(fh) {
  const h = await rd(fh, 0, 10);
  if (h.length < 10 || h.toString('latin1', 0, 3) !== 'ID3') return null;
  const ver = h[3], flags = h[5], size = syncsafe(h, 6);
  const buf = await rd(fh, 10, Math.min(size, MAX_TAG));
  const r = {};
  let p = 0;
  if ((flags & 0x40) && ver >= 3 && buf.length >= 4) p = ver === 4 ? syncsafe(buf, 0) : buf.readUInt32BE(0) + 4;
  const idLen = ver === 2 ? 3 : 4, hLen = ver === 2 ? 6 : 10;
  while (p + hLen <= buf.length) {
    const id = buf.toString('latin1', p, p + idLen);
    if (!/^[A-Z0-9]+$/.test(id)) break;
    const fsz = ver === 2 ? (buf[p + 3] << 16) | (buf[p + 4] << 8) | buf[p + 5] : ver === 4 ? syncsafe(buf, p + 4) : buf.readUInt32BE(p + 4);
    const ds = p + hLen;
    if (fsz <= 0 || ds + fsz > buf.length) break;
    const d = buf.subarray(ds, ds + fsz);
    p = ds + fsz;
    const text = () => decodeText(d[0], d.subarray(1));
    if (id === 'TIT2' || id === 'TT2') r.title = text();
    else if (id === 'TPE1' || id === 'TP1') r.artist = text();
    else if (id === 'TALB' || id === 'TAL') r.album = text();
    else if (id === 'TRCK' || id === 'TRK') r.no = parseInt(text(), 10) || 0;
    else if ((id === 'APIC' || id === 'PIC') && !r.pic) {
      const enc = d[0];
      let q = 1;
      if (id === 'PIC') q += 3; else q = d.indexOf(0, 1) + 1;
      if (q <= 0) continue;
      q += 1;                                   // 图片类型
      q = termIdx(d, q, enc) + (enc === 1 || enc === 2 ? 2 : 1);
      if (q < d.length) r.pic = d.subarray(q);
    }
  }
  return r;
}

async function readFlac(fh) {
  if ((await rd(fh, 0, 4)).toString('latin1') !== 'fLaC') return null;
  const r = {};
  let pos = 4;
  for (let n = 0; n < 64; n++) {
    const hd = await rd(fh, pos, 4);
    if (hd.length < 4) break;
    const last = hd[0] & 128, type = hd[0] & 127, len = hd.readUIntBE(1, 3);
    pos += 4;
    if (type === 0 && len >= 18) {
      const d = await rd(fh, pos, 18);
      const sr = (d[10] << 12) | (d[11] << 4) | (d[12] >> 4);
      const total = (d[13] & 15) * 4294967296 + d.readUInt32BE(14);
      if (sr > 0 && total > 0) r.dur = total / sr;
    } else if (type === 4 && len <= MAX_TAG) {
      const d = await rd(fh, pos, len);
      let q = 0;
      const vl = d.readUInt32LE(q); q += 4 + vl;
      const cnt = d.readUInt32LE(q); q += 4;
      for (let i = 0; i < cnt && q + 4 <= d.length; i++) {
        const l = d.readUInt32LE(q); q += 4;
        const kv = d.toString('utf8', q, q + l); q += l;
        const eq = kv.indexOf('=');
        if (eq < 0) continue;
        const k = kv.slice(0, eq).toUpperCase(), v = clean(kv.slice(eq + 1));
        if (k === 'TITLE') r.title = v; else if (k === 'ARTIST') r.artist = v; else if (k === 'ALBUM') r.album = v;
        else if (k === 'TRACKNUMBER') r.no = parseInt(v, 10) || 0;
      }
    } else if (type === 6 && len <= MAX_TAG && !r.pic) {
      const d = await rd(fh, pos, len);
      let q = 4;
      const ml = d.readUInt32BE(q); q += 4 + ml;
      const dl = d.readUInt32BE(q); q += 4 + dl + 16;
      const pl = d.readUInt32BE(q); q += 4;
      if (pl > 0 && q + pl <= d.length) r.pic = d.subarray(q, q + pl);
    }
    pos += len;
    if (last) break;
  }
  return r;
}

function* atoms(buf, s, e) {
  let p = s;
  while (p + 8 <= e) {
    let size = buf.readUInt32BE(p), hl = 8;
    const type = buf.toString('latin1', p + 4, p + 8);
    if (size === 1) { if (p + 16 > e) return; size = Number(buf.readBigUInt64BE(p + 8)); hl = 16; }
    else if (size === 0) size = e - p;
    if (size < hl || p + size > e) return;
    yield { type, ds: p + hl, de: p + size };
    p += size;
  }
}
async function readMp4(fh, fsize) {
  let pos = 0, moov = null;
  while (pos + 8 <= fsize) {
    const h = await rd(fh, pos, 16);
    if (h.length < 8) break;
    let size = h.readUInt32BE(0);
    const type = h.toString('latin1', 4, 8);
    if (size === 1 && h.length >= 16) size = Number(h.readBigUInt64BE(8));
    else if (size === 0) size = fsize - pos;
    if (size < 8) break;
    if (type === 'moov') { if (size > 32 * 1024 * 1024) return null; moov = await rd(fh, pos, size); break; }
    pos += size;
  }
  if (!moov) return null;
  const r = {};
  const find = (s, e, t) => { for (const a of atoms(moov, s, e)) if (a.type === t) return a; return null; };
  const mv = find(8, moov.length, 'mvhd');
  if (mv) {
    const v = moov[mv.ds];
    const ts = v === 1 ? moov.readUInt32BE(mv.ds + 20) : moov.readUInt32BE(mv.ds + 12);
    const du = v === 1 ? Number(moov.readBigUInt64BE(mv.ds + 24)) : moov.readUInt32BE(mv.ds + 16);
    if (ts > 0 && du > 0) r.dur = du / ts;
  }
  const udta = find(8, moov.length, 'udta'), meta = udta && find(udta.ds, udta.de, 'meta'), ilst = meta && find(meta.ds + 4, meta.de, 'ilst');
  if (ilst) {
    for (const it of atoms(moov, ilst.ds, ilst.de)) {
      const da = find(it.ds, it.de, 'data');
      if (!da) continue;
      const c = moov.subarray(da.ds + 8, da.de);
      if (it.type === '\xa9nam') r.title = clean(c.toString('utf8'));
      else if (it.type === '\xa9ART') r.artist = clean(c.toString('utf8'));
      else if (it.type === '\xa9alb') r.album = clean(c.toString('utf8'));
      else if (it.type === 'aART' && !r.artist) r.artist = clean(c.toString('utf8'));
      else if (it.type === 'trkn' && c.length >= 4) r.no = c.readUInt16BE(2);
      else if (it.type === 'covr') r.pic = c;
    }
  }
  return r;
}

/* 「歌手 - 歌名」「01 歌名」之类的文件名兜底 */
function parseName(file) {
  const b = path.basename(file, path.extname(file)).replace(/_/g, ' ').trim();
  let m = /^(\d{1,3})[\s.\-_)]+(.+)$/.exec(b), no = 0, rest = b;
  if (m) { no = +m[1]; rest = m[2]; }
  m = /^(.+?)\s+-\s+(.+)$/.exec(rest);
  if (m) return { artist: m[1].trim(), title: m[2].trim(), no };
  return { artist: '', title: rest.trim() || b, no };
}

const picExt = b => (b[0] === 0x89 && b[1] === 0x50 ? '.png' : b[0] === 0x47 && b[1] === 0x49 ? '.gif' : b[0] === 0x52 && b[1] === 0x49 ? '.webp' : '.jpg');

async function parseFile(file, st, coverDir) {
  const ext = path.extname(file).toLowerCase();
  let fh = null, tag = null;
  try {
    fh = await fs.promises.open(file, 'r');
    if (ext === '.mp3') tag = await readId3(fh);
    else if (ext === '.flac') tag = await readFlac(fh);
    else if (ext === '.m4a' || ext === '.mp4' || ext === '.aac') tag = await readMp4(fh, st.size);
    if (ext === '.flac' && !tag) tag = await readId3(fh);
  } catch { tag = null; } finally { try { if (fh) await fh.close(); } catch {} }
  tag = tag || {};
  const nm = parseName(file);
  const t = { title: tag.title || nm.title, artist: tag.artist || nm.artist, album: tag.album || '', no: tag.no || nm.no || 0, dur: tag.dur || 0, cover: '' };
  if (tag.pic && tag.pic.length > 200 && coverDir) {
    try {
      const name = crypto.createHash('sha1').update(tag.pic).digest('hex').slice(0, 20) + picExt(tag.pic);
      const fp = path.join(coverDir, name);
      if (!fs.existsSync(fp)) { fs.mkdirSync(coverDir, { recursive: true }); fs.writeFileSync(fp, tag.pic); }
      t.cover = fp;
    } catch {}
  }
  return t;
}

const dirCoverCache = new Map();
function folderCover(dir) {               // 没有内嵌封面时，用同目录的 cover / folder / front 图片
  if (dirCoverCache.has(dir)) return dirCoverCache.get(dir);
  let r = '';
  try {
    const names = fs.readdirSync(dir);
    for (const base of ['cover', 'folder', 'front', 'album', 'albumart']) {
      const hit = names.find(n => /\.(jpe?g|png|webp)$/i.test(n) && path.basename(n, path.extname(n)).toLowerCase() === base);
      if (hit) { r = path.join(dir, hit); break; }
    }
  } catch {}
  dirCoverCache.set(dir, r);
  return r;
}

async function walk(root, out, depth = 0) {
  let ents;
  try { ents = await fs.promises.readdir(root, { withFileTypes: true }); } catch { return; }
  for (const e of ents) {
    if (e.name.startsWith('.')) continue;
    const p = path.join(root, e.name);
    if (e.isDirectory()) { if (depth < 12 && !SKIP_DIR.test(e.name)) await walk(p, out, depth + 1); }
    else if (e.isFile() && isAudio(p)) out.push(p);
  }
}

/* 扫描：folders = 整个文件夹；files = 单独添加的文件；cache = { 路径: 旧记录 }。返回新的 tracks 对象 */
async function scan({ folders = [], files = [], cache = {}, coverDir, onProgress }) {
  const list = new Set(files.filter(f => isAudio(f) && fs.existsSync(f)));
  const offline = [];
  for (const f of folders) {
    let ok = false;
    try { ok = (await fs.promises.stat(f)).isDirectory(); } catch {}
    if (!ok) { offline.push(f); continue; }
    const out = []; await walk(f, out); out.forEach(x => list.add(x));
  }
  dirCoverCache.clear();
  const tracks = {};
  for (const [p, t] of Object.entries(cache)) {       // 文件夹所在的盘没插上：保留旧记录，别把库清空
    if (offline.some(o => p.toLowerCase().startsWith(o.toLowerCase() + path.sep))) tracks[p] = t;
  }
  const all = [...list];
  let done = 0;
  for (const p of all) {
    let st;
    try { st = await fs.promises.stat(p); } catch { continue; }
    const old = cache[p];
    if (old && old.size === st.size && old.mtime === Math.floor(st.mtimeMs)) tracks[p] = old;
    else {
      const t = await parseFile(p, st, coverDir);
      tracks[p] = Object.assign(t, { size: st.size, mtime: Math.floor(st.mtimeMs) });
    }
    if (!tracks[p].cover) tracks[p].cover = folderCover(path.dirname(p));
    if (onProgress && (++done % 25 === 0 || done === all.length)) onProgress({ done, total: all.length });
  }
  return tracks;
}

/* 同名 .lrc 歌词 */
function readLyrics(file) {
  const base = file.slice(0, file.length - path.extname(file).length);
  for (const e of ['.lrc', '.LRC', '.Lrc']) {
    try {
      const b = fs.readFileSync(base + e);
      if (b.length > 2 * 1024 * 1024) return '';
      let s = b.toString('utf8');
      if (s.includes('\uFFFD')) { try { s = new TextDecoder('gbk').decode(b); } catch {} }
      return s.replace(/^\uFEFF/, '');
    } catch {}
  }
  return '';
}

module.exports = { scan, parseFile, parseName, readLyrics, isAudio, EXT, readId3, readFlac };
