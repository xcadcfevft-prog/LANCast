'use strict';
/* 「folia 角色」的宿主：同一个 exe 以 LANCAST_ROLE=folia 启动时由 entry.js 调到这里（见 foliaLauncher.js 的说明）。
 * 只做三件 folia 默认「以为自己是独立安装的应用」才成立的事，然后原样加载它的 electron/main.cjs，不改它一行源码：
 *   ① 单独的 userData（单实例锁、设置、缓存、音乐库索引都和瞬流分开）—— 必须在加载 main.cjs 之前设好，它的 electron-store 在加载时就读这个路径
 *   ② 让 app.getAppPath() / app.getVersion() / process.resourcesPath 指向 folia 自己的目录：它按这些找 dist/、build/ 图标、ffmpeg-audio/、package.json 里的发布通道
 *   ③ 主进程一加载就抛错时以非 0 退出，瞬流那边据此退回内置播放器 */
const { app } = require('electron');
const path = require('path');
const fs = require('fs');

function force(obj, key, value) {                        // 这些属性是原生挂在对象上的，先试 defineProperty，再试直接赋值；都不行就算了（只影响图标 / 版本显示一类）
  try { Object.defineProperty(obj, key, { value, configurable: true, writable: true }); return true; } catch {}
  try { obj[key] = value; return true; } catch {}
  return false;
}

function run(env) {
  env = env || process.env;
  const dir = env.LANCAST_FOLIA_DIR, userData = env.LANCAST_FOLIA_USERDATA;
  try {
    if (!dir) throw new Error('LANCAST_FOLIA_DIR 未设置');
    const pkg = JSON.parse(fs.readFileSync(path.join(dir, 'package.json'), 'utf8'));
    try { app.setName(pkg.productName || 'Folia'); } catch {}
    if (userData) { fs.mkdirSync(userData, { recursive: true }); app.setPath('userData', userData); }
    force(app, 'getAppPath', () => dir);
    force(app, 'getVersion', () => String(pkg.version || '0.0.0'));
    force(process, 'resourcesPath', dir);
    require(path.join(dir, 'electron', 'main.cjs'));
  } catch (e) {
    try { console.error('[folia-host] 启动失败：', e && e.stack || e); } catch {}
    try { app.exit(1); } catch { process.exit(1); }
  }
}

module.exports = { run };
