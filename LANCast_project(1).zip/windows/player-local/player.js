'use strict';
/* 本地音乐库播放器：所有数据来自主进程的 musiclib（window.lib），歌曲直接用 file:// 播放。 */
const $ = s => document.querySelector(s);
const au = $('#au'), view = $('#view');
const st = { tracks: [], folders: [], v: 'songs', filter: null, q: '', queue: [], qi: -1, mode: 0, hist: [], lines: [], li: -1 };
const byPath = new Map();
const fmt = s => { s = Math.max(0, Math.floor(s || 0)); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); };
const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const cmp = (a, b) => String(a || '').localeCompare(String(b || ''), 'zh');
const MODES = [['🔁', '顺序播放'], ['🔀', '随机播放'], ['🔂', '单曲循环']];
let toastT = 0;
function toast(t) { const e = $('#toast'); e.textContent = t; e.hidden = false; clearTimeout(toastT); toastT = setTimeout(() => (e.hidden = true), 2600); }

/* ───── 数据 ───── */
function setData(d) {
  if (!d) return;
  st.folders = d.folders;
  st.tracks = d.tracks.sort((a, b) => cmp(a.artist, b.artist) || cmp(a.album, b.album) || (a.no || 0) - (b.no || 0) || cmp(a.title, b.title));
  byPath.clear(); st.tracks.forEach(t => byPath.set(t.path, t));
  render();
  bgDur();
}
function visible() {
  let a = st.tracks;
  const f = st.filter;
  if (f) a = a.filter(t => (f.type === 'album' ? (t.album || '未知专辑') : (t.artist || '未知歌手')) === f.key);
  const q = st.q.trim().toLowerCase();
  if (q) a = a.filter(t => (t.title + ' ' + t.artist + ' ' + t.album).toLowerCase().includes(q));
  return a;
}

/* ───── 列表渲染 ───── */
let shown = [], shownN = 0;
function rowHtml(t, i) {
  const cur = st.queue[st.qi] === t.path ? ' cur' : '';
  return '<div class="row' + cur + '" data-i="' + i + '"><div class="n">' + (cur ? '♪' : i + 1) + '</div><div class="t">' +
    (t.cover ? '<img loading="lazy" src="' + esc(t.cover) + '">' : '<i></i>') + '<span>' + esc(t.title) + '</span></div><div class="a">' + esc(t.artist) + '</div><div class="b">' + esc(t.album) + '</div><div class="d">' + (t.dur ? fmt(t.dur) : '') + '</div></div>';
}
function more() {
  if (shownN >= shown.length) return;
  const end = Math.min(shown.length, shownN + 200);
  let h = '';
  for (let i = shownN; i < end; i++) h += rowHtml(shown[i], i);
  view.querySelector('.list').insertAdjacentHTML('beforeend', h);
  shownN = end;
}
view.addEventListener('scroll', () => { if (st.v === 'songs' && view.scrollTop + view.clientHeight > view.scrollHeight - 600) more(); });

function render() {
  document.querySelectorAll('#nav button').forEach(b => b.classList.toggle('on', b.dataset.v === st.v));
  const chip = $('#chip');
  chip.hidden = !st.filter;
  if (st.filter) chip.textContent = (st.filter.type === 'album' ? '专辑：' : '歌手：') + st.filter.key + '  ✕';
  if (!st.tracks.length && st.v !== 'folders') {
    $('#cnt').textContent = '';
    view.innerHTML = '<div class="empty"><div class="ic">🎶</div><h2>建立你的私人音乐库</h2><div>选择存放音乐的文件夹，自动识别歌名 / 歌手 / 封面 / 同名 .lrc 歌词<br>也可以直接把文件夹或音频文件拖进窗口</div><button class="pri" id="emptyAdd">选择音乐文件夹</button></div>';
    $('#emptyAdd').onclick = addFolder;
    return;
  }
  if (st.v === 'songs') {
    shown = visible(); shownN = 0;
    $('#cnt').textContent = shown.length + ' 首';
    view.innerHTML = shown.length
      ? '<div class="row hd"><div class="n">#</div><div>标题</div><div>歌手</div><div>专辑</div><div class="d">时长</div></div><div class="list"></div>'
      : '<div class="empty"><div>没有匹配的歌曲</div></div>';
    if (shown.length) more();
  } else if (st.v === 'albums' || st.v === 'artists') {
    const al = st.v === 'albums', m = new Map();
    for (const t of visible()) {
      const k = al ? (t.album || '未知专辑') : (t.artist || '未知歌手');
      let g = m.get(k); if (!g) m.set(k, g = { k, n: 0, cover: '', sub: al ? t.artist : '' });
      g.n++; if (!g.cover && t.cover) g.cover = t.cover;
    }
    const gs = [...m.values()].sort((a, b) => cmp(a.k, b.k));
    $('#cnt').textContent = gs.length + (al ? ' 张专辑' : ' 位歌手');
    view.innerHTML = '<div class="grid">' + gs.map((g, i) => '<div class="card" data-i="' + i + '"><div class="im"' + (g.cover ? ' style="background-image:url(\'' + esc(g.cover).replace(/'/g, '%27') + '\')"' : '') + '>' + (g.cover ? '' : '♪') + '</div><b>' + esc(g.k) + '</b><small>' + g.n + ' 首' + (g.sub ? ' · ' + esc(g.sub) : '') + '</small></div>').join('') + '</div>';
    view._groups = gs;
  } else {
    $('#cnt').textContent = st.folders.length + ' 个文件夹';
    view.innerHTML = (st.folders.length ? st.folders.map((f, i) => '<div class="fold"><div>' + esc(f.path) + '<br><small>' + f.n + ' 首</small></div><button data-rm="' + i + '">移除</button></div>').join('') : '<div class="empty"><div>还没有添加文件夹</div></div>') +
      '<div style="padding:16px"><button id="rescan">重新扫描全部</button> <small style="color:var(--dim)">移除只会把音乐从库里去掉，不会删除电脑上的文件。库里新增 / 改名的歌曲，重新扫描即可。</small></div>';
    const rs = $('#rescan'); if (rs) rs.onclick = async () => { busy(true); setData(await lib.rescan()); busy(false); toast('已重新扫描'); };
  }
}
function markCur() {
  view.querySelectorAll('.row.cur').forEach(r => { r.classList.remove('cur'); r.firstChild.textContent = +r.dataset.i + 1; });
  const p = st.queue[st.qi], i = shown.findIndex(t => t.path === p);
  const r = st.v === 'songs' && i >= 0 && view.querySelector('.row[data-i="' + i + '"]');
  if (r) { r.classList.add('cur'); r.firstChild.textContent = '♪'; }
}

/* ───── 交互 ───── */
view.addEventListener('dblclick', e => {
  const r = e.target.closest('.row[data-i]'); if (!r || r.classList.contains('hd')) return;
  playList(shown, +r.dataset.i);
});
view.addEventListener('click', e => {
  const c = e.target.closest('.card');
  if (c && view._groups) { st.filter = { type: st.v === 'albums' ? 'album' : 'artist', key: view._groups[+c.dataset.i].k }; st.v = 'songs'; render(); return; }
  const rm = e.target.closest('[data-rm]');
  if (rm) { const f = st.folders[+rm.dataset.rm]; if (f) lib.removeFolder(f.path).then(setData); }
});
view.addEventListener('contextmenu', e => {
  const r = e.target.closest('.row[data-i]'); if (!r || r.classList.contains('hd')) return;
  e.preventDefault();
  const t = shown[+r.dataset.i], m = $('#ctx');
  m.innerHTML = '<div data-a="play">播放</div><div data-a="show">在文件夹中显示</div><div data-a="rm">从音乐库移除</div>';
  m.hidden = false; m.style.left = Math.min(e.clientX, innerWidth - 170) + 'px'; m.style.top = Math.min(e.clientY, innerHeight - 120) + 'px';
  m._t = t; m._i = +r.dataset.i;
});
$('#ctx').addEventListener('click', e => {
  const m = $('#ctx'), a = e.target.dataset.a; m.hidden = true;
  if (a === 'play') playList(shown, m._i);
  else if (a === 'show') lib.reveal(m._t.path);
  else if (a === 'rm') lib.removeTrack(m._t.path).then(setData);
});
document.addEventListener('mousedown', e => { if (!e.target.closest('#ctx')) $('#ctx').hidden = true; });
$('#nav').addEventListener('click', e => { const b = e.target.closest('button'); if (!b) return; st.v = b.dataset.v; if (st.v !== 'songs') st.filter = null; render(); });
$('#chip').onclick = () => { st.filter = null; render(); };
$('#q').addEventListener('input', e => { st.q = e.target.value; if (st.v !== 'songs' && st.v !== 'albums' && st.v !== 'artists') st.v = 'songs'; render(); });

function busy(on, d) { const p = $('#prog'); p.hidden = !on; if (on) p.textContent = d && d.total ? '扫描中 ' + d.done + ' / ' + d.total : '扫描中…'; }
lib.onProgress(d => busy(true, d));
async function addFolder() { const r = await lib.addFolders(); if (r) { busy(false); setData(r); toast('已加入 ' + r.tracks.length + ' 首'); } }
async function addFiles() { const r = await lib.addFiles(); if (r) { busy(false); setData(r); toast('已加入 ' + r.tracks.length + ' 首'); } }
$('#addFolder').onclick = addFolder;
$('#addFiles').onclick = addFiles;

/* 拖拽导入 */
let dragN = 0;
addEventListener('dragenter', e => { e.preventDefault(); dragN++; $('#drop').hidden = false; });
addEventListener('dragleave', () => { if (--dragN <= 0) { dragN = 0; $('#drop').hidden = true; } });
addEventListener('dragover', e => e.preventDefault());
addEventListener('drop', async e => {
  e.preventDefault(); dragN = 0; $('#drop').hidden = true;
  const ps = [...e.dataTransfer.files].map(f => lib.pathOf(f)).filter(Boolean);
  if (!ps.length) return;
  busy(true); const r = await lib.addPaths(ps); busy(false); if (r) { setData(r); toast('已加入音乐库'); }
});

/* ───── 播放 ───── */
function playList(list, i) { st.queue = list.map(t => t.path); st.hist = []; playAt(i); }
function playAt(i, noHist) {
  if (i < 0 || i >= st.queue.length) return;
  if (!noHist && st.qi >= 0) st.hist.push(st.qi);
  st.qi = i;
  const t = byPath.get(st.queue[i]); if (!t) return next();
  au.src = t.url; au.play().catch(() => {});
  $('#nt').textContent = t.title; $('#na').textContent = [t.artist, t.album].filter(Boolean).join(' · ');
  $('#cov').src = t.cover || ''; $('#lcov').src = t.cover || '';
  $('#lt').textContent = t.title; $('#la').textContent = t.artist;
  $('#lbg').style.backgroundImage = t.cover ? 'url("' + t.cover + '")' : 'none';
  document.title = t.title + ' · 音乐播放器';
  if ('mediaSession' in navigator) navigator.mediaSession.metadata = new MediaMetadata({ title: t.title, artist: t.artist, album: t.album, artwork: t.cover ? [{ src: t.cover }] : [] });
  markCur(); loadLyrics(t);
  try { localStorage.setItem('last', JSON.stringify({ p: t.path })); } catch {}
}
function next(auto) {
  if (!st.queue.length) return;
  if (auto && st.mode === 2) { au.currentTime = 0; au.play(); return; }
  let i;
  if (st.mode === 1 && st.queue.length > 1) { do i = Math.floor(Math.random() * st.queue.length); while (i === st.qi); }
  else i = (st.qi + 1) % st.queue.length;
  playAt(i);
}
function prev() {
  if (au.currentTime > 3 || !st.hist.length) { au.currentTime = 0; return; }
  playAt(st.hist.pop(), true);
}
const toggle = () => { if (!au.src) { if (shown.length) playList(shown, 0); return; } au.paused ? au.play() : au.pause(); };
$('#play').onclick = toggle; $('#next').onclick = () => next(); $('#prev').onclick = prev;
$('#mode').onclick = () => { st.mode = (st.mode + 1) % 3; $('#mode').textContent = MODES[st.mode][0]; $('#mode').title = MODES[st.mode][1]; toast(MODES[st.mode][1]); try { localStorage.setItem('mode', st.mode); } catch {} };
au.addEventListener('play', () => ($('#play').textContent = '⏸'));
au.addEventListener('pause', () => ($('#play').textContent = '▶'));
au.addEventListener('ended', () => next(true));
au.addEventListener('error', () => { const t = byPath.get(st.queue[st.qi]); toast('无法播放：' + (t ? t.title : '') + '（文件可能已移动或格式不支持）'); setTimeout(() => { if (st.queue.length > 1) next(); }, 800); });
let seeking = false;
au.addEventListener('timeupdate', () => {
  if (!seeking && au.duration) $('#pos').value = au.currentTime / au.duration * 1000;
  $('#cur').textContent = fmt(au.currentTime); $('#dur').textContent = fmt(au.duration);
  syncLyric();
});
$('#pos').addEventListener('input', () => { seeking = true; if (au.duration) $('#cur').textContent = fmt($('#pos').value / 1000 * au.duration); });
$('#pos').addEventListener('change', () => { if (au.duration) au.currentTime = $('#pos').value / 1000 * au.duration; seeking = false; });
$('#vr').addEventListener('input', () => { au.volume = $('#vr').value / 100; try { localStorage.setItem('vol', $('#vr').value); } catch {} });
if ('mediaSession' in navigator) {
  navigator.mediaSession.setActionHandler('previoustrack', prev);
  navigator.mediaSession.setActionHandler('nexttrack', () => next());
}

/* ───── 歌词（同名 .lrc）───── */
function parseLrc(txt) {
  const out = [];
  for (const ln of String(txt).split(/\r?\n/)) {
    const ts = [...ln.matchAll(/\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?\]/g)];
    if (!ts.length) continue;
    const text = ln.replace(/\[[^\]]*\]/g, '').trim();
    for (const m of ts) out.push({ t: +m[1] * 60 + +m[2] + (m[3] ? +('0.' + m[3]) : 0), s: text });
  }
  return out.sort((a, b) => a.t - b.t);
}
async function loadLyrics(t) {
  st.lines = []; st.li = -1;
  const box = $('#llines');
  box.innerHTML = '';
  const txt = await lib.lyrics(t.path);
  if (byPath.get(st.queue[st.qi]) !== t) return;
  st.lines = parseLrc(txt);
  box.innerHTML = st.lines.length ? st.lines.map((l, i) => '<div data-i="' + i + '">' + (esc(l.s) || '♪') + '</div>').join('') : '<div class="none">暂无歌词<br><small>把同名的 .lrc 文件放在歌曲旁边即可显示</small></div>';
  box.scrollTop = 0;
}
function syncLyric() {
  if (!st.lines.length || $('#ly').hidden) return;
  let i = -1;
  for (let k = 0; k < st.lines.length; k++) { if (st.lines[k].t <= au.currentTime + 0.15) i = k; else break; }
  if (i === st.li) return;
  st.li = i;
  const box = $('#llines');
  box.querySelectorAll('.on').forEach(e => e.classList.remove('on'));
  const el = box.children[i]; if (!el) return;
  el.classList.add('on');
  box.scrollTo({ top: el.offsetTop - box.clientHeight / 2 + el.clientHeight / 2, behavior: 'smooth' });
}
$('#llines').addEventListener('click', e => { const d = e.target.closest('[data-i]'); if (d && st.lines[+d.dataset.i]) { au.currentTime = st.lines[+d.dataset.i].t; au.play(); } });
function lyricOpen(on) { $('#ly').hidden = !on; if (on) { st.li = -2; syncLyric(); } }
$('#lyr').onclick = () => lyricOpen($('#ly').hidden);
$('#cov').onclick = () => { if (au.src) lyricOpen(true); };
$('#lclose').onclick = () => lyricOpen(false);

/* ───── 键盘 ───── */
addEventListener('keydown', e => {
  if (e.target.tagName === 'INPUT' && e.target.type === 'search') { if (e.key === 'Escape') e.target.blur(); return; }
  if (e.key === ' ') { e.preventDefault(); toggle(); }
  else if (e.key === 'ArrowRight' && e.ctrlKey) next();
  else if (e.key === 'ArrowLeft' && e.ctrlKey) prev();
  else if (e.key === 'ArrowRight') au.currentTime = Math.min(au.duration || 0, au.currentTime + 5);
  else if (e.key === 'ArrowLeft') au.currentTime = Math.max(0, au.currentTime - 5);
  else if (e.key === 'ArrowUp') { $('#vr').value = Math.min(100, +$('#vr').value + 5); $('#vr').dispatchEvent(new Event('input')); }
  else if (e.key === 'ArrowDown') { $('#vr').value = Math.max(0, +$('#vr').value - 5); $('#vr').dispatchEvent(new Event('input')); }
  else if (e.key === 'l' || e.key === 'L') lyricOpen($('#ly').hidden);
  else if (e.key === 'Escape') lyricOpen(false);
  else if (e.key === 'f' && e.ctrlKey) { e.preventDefault(); $('#q').focus(); }
});

/* ───── 后台补全时长（标签里没有的，如 mp3 / wav / ogg）───── */
let durRun = false;
async function bgDur() {
  if (durRun) return; durRun = true;
  const todo = st.tracks.filter(t => !t.dur), got = {};
  let n = 0;
  const probe = t => new Promise(res => {
    const a = new Audio(); a.preload = 'metadata';
    const done = d => { a.src = ''; res(d); };
    a.onloadedmetadata = () => done(isFinite(a.duration) ? a.duration : 0);
    a.onerror = () => done(0);
    setTimeout(() => done(0), 6000);
    a.src = t.url;
  });
  const worker = async () => {
    while (todo.length) {
      const t = todo.shift(), d = await probe(t);
      if (d) { t.dur = d; got[t.path] = d; n++; }
      if (n && n % 40 === 0) { lib.setDur(got); for (const k in got) delete got[k]; }
    }
  };
  await Promise.all([worker(), worker()]);
  if (Object.keys(got).length) lib.setDur(got);
  durRun = false;
  if (n && st.v === 'songs') { const sy = view.scrollTop, k = shownN; render(); while (shownN < k) more(); view.scrollTop = sy; markCur(); }
}

/* ───── 启动 ───── */
(async () => {
  try { const v = localStorage.getItem('vol'); if (v != null) $('#vr').value = v; const m = +localStorage.getItem('mode'); if (m >= 0 && m < 3) { st.mode = m; $('#mode').textContent = MODES[m][0]; } } catch {}
  au.volume = $('#vr').value / 100;
  setData(await lib.get());              // 先用缓存秒开
  if (st.folders.length) { busy(true); setData(await lib.rescan()); busy(false); }   // 再后台增量扫描：新增 / 变动的歌曲自动出现
  render();
})();
