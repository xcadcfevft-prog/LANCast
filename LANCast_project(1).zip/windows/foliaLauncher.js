'use strict';
/* folia 播放器的「第二角色」启动逻辑 —— 纯逻辑，不 require electron，方便单元测试。
 * 做法：folia 自带完整的 Electron 主进程（electron/main.cjs）和预加载（preload.cjs）。瞬流把它整份打进安装包（resources/folia/），
 * 点「本地音乐库」时用同一个 exe 再起一个进程，环境变量 LANCAST_ROLE=folia，入口（entry.js）看到后不加载瞬流自己的主进程，
 * 而是把 folia 的 main.cjs 原样跑起来（见 folia-host.js）。这样 folia 拿到的是它设计时就有的完整桌面环境：
 * 原生文件夹选择与受限目录处理、设置存储、任务栏按钮、全局快捷键、在线音乐后端、HiFi 输出等，而不是一个被塞进窗口的网页。
 * 与瞬流的主进程互相独立：各用各的 userData（单实例锁、缓存、设置都分开），folia 崩了不影响投屏 / 传文件。 */

const path = require('path');

const ROLE_ENV = 'LANCAST_ROLE';
const ROLE_FOLIA = 'folia';
const GRACE_MS = 8000;           // 起来后这段时间内就以非 0 退出，视为「没跑起来」，退回内置播放器

/* folia 应用目录必须同时有主进程入口和前端产物，缺一个都当作「没打包」 */
const REQUIRED = [path.join('electron', 'main.cjs'), path.join('electron', 'preload.cjs'), path.join('dist', 'index.html'), 'package.json'];

/* 候选目录：安装后在 resources/folia；开发时（npm start）在 windows/folia */
function candidateDirs(resourcesPath, baseDir) {
  const out = [];
  if (resourcesPath) out.push(path.join(resourcesPath, 'folia'));
  if (baseDir) out.push(path.join(baseDir, 'folia'));
  return out;
}

function findFoliaDir(candidates, exists) {
  for (const dir of candidates || []) {
    if (REQUIRED.every(f => { try { return !!exists(path.join(dir, f)); } catch { return false; } })) return dir;
  }
  return null;
}

/* 子进程环境：去掉会让 Electron 退化成纯 Node 的开关、不让 folia 误入它的开发模式，并带上角色 / 目录 / 数据目录 */
function childEnv(base, opts) {
  const env = Object.assign({}, base || {});
  delete env.ELECTRON_RUN_AS_NODE;
  delete env.ELECTRON_NO_ATTACH_CONSOLE;
  delete env.FOLIA_RELAUNCH;
  env.ELECTRON_DEV = 'false';                                   // folia 里 ELECTRON_DEV === 'true' 才是开发模式
  if (env.NODE_ENV === 'development') delete env.NODE_ENV;
  env[ROLE_ENV] = ROLE_FOLIA;
  env.LANCAST_FOLIA_DIR = opts.dir;
  env.LANCAST_FOLIA_USERDATA = opts.userData;
  return env;
}

/* 打包后直接 exe 不带参数；开发时（electron .）要把应用路径带上，否则 electron.exe 会打开它自带的欢迎页 */
function spawnArgs(packaged, appPath) {
  return packaged ? [] : [appPath];
}

/* 起来后很快就异常退出 = 没跑起来（缺文件 / 原生模块加载失败 / 主进程抛错）；退出码 0 是「已有实例，已被它接管」，不算失败 */
function judgeExit(info, graceMs) {
  const i = info || {};
  const ms = typeof i.elapsedMs === 'number' ? i.elapsedMs : Infinity;
  const bad = (typeof i.code === 'number' && i.code !== 0) || (i.code == null && !!i.signal);
  return bad && ms < (graceMs || GRACE_MS) ? 'failed-early' : 'ok';
}

module.exports = { ROLE_ENV, ROLE_FOLIA, GRACE_MS, REQUIRED, candidateDirs, findFoliaDir, childEnv, spawnArgs, judgeExit };
