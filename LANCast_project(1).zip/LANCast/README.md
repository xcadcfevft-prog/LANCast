# LANCast 打包说明

## 方式一：GitHub 云端构建（不用装任何环境）
1. 在 GitHub 新建一个仓库，把本目录全部内容（含 .github 文件夹）上传/推送上去。
2. 打开仓库的 Actions 页面，等 "Build LANCast" 跑完（约 5–10 分钟；也可手动点 Run workflow）。
3. 在运行结果底部的 Artifacts 下载：
   - LANCast-windows-exe：安装版 Setup.exe + 便携版 exe
   - LANCast-android-apk：app-debug.apk（已用调试签名，可直接安装）

## 方式二：本机构建
- Windows exe：装好 Node.js 18+，双击 build-windows.bat，产物在 windows\dist。
- Android apk：用 Android Studio 打开 android 目录，Sync 后 Build → Build APK(s)。

## 说明
- Kotlin 代码此前未经编译验证。如果 Actions 里 android-apk 任务报错，把日志发给我即可修复。
- 首次运行 Windows 版时，防火墙请允许「专用网络」（TCP 47800、UDP 47801）。

## 文件互传（手机 ⇄ 电脑）

- **无损**：文件按原始字节传输，不转码、不压缩。传完后发送方和接收方各自对整个文件计算 SHA-256 并比对，一致才算成功；不一致则丢弃并报错，不会留下损坏的文件。
- **不限大小**：偏移量和大小都是 64 位，边收边写盘，内存占用恒定。电脑端已用 4.3 GB（超过 32 位边界）的文件做过逐字节比对测试。
- **不限格式**：任何文件都能传，文件名（含中文）原样保留；电脑端只会替换 Windows 不允许的字符。暂不支持直接发送文件夹（请先压缩）。
- **断点续传**：中途断线后，接收方会保留未完成的部分，重新发送同一个文件时会从断点继续（续传前会重新校验已收到的部分）。
- **用法**：电脑端在「文件互传」区拖入文件，或点「选择文件…」/设备旁的「发文件…」；手机端点「选择文件并发送…」。双方都需要在同一局域网，发送方输入接收方屏幕上显示的 PIN。
- **保存位置**：电脑端默认 `下载\LANCast`（可更改）；手机端为 `下载/LANCast`。
- 文件互传和投屏使用同一个端口（TCP 47800），互不占用，可以同时进行。
- 协议见 `windows/filexfer.js` 和 `android/.../FileXfer.kt` 文件开头的注释。
