# LANCast 打包说明

## 方式一：GitHub 云端构建（不用装任何环境）
1. 在 GitHub 新建一个仓库，把本目录全部内容（含 .github 文件夹）上传/推送上去。
2. 打开仓库的 Actions 页面，等 "Build LANCast" 跑完（约 5–10 分钟；也可手动点 Run workflow）。
3. 在运行结果底部的 Artifacts 下载：
   - LANCast-windows-exe：安装版 Setup.exe + 便携版 exe
   - LANCast-android-apk：app-debug.apk（已用调试签名，可直接安装）

## 方式二：本机构建
- Windows exe：装好 Node.js 18+，双击 build-windows.bat，产物在 windows\dist。
- Android apk：用 Android Studio 打开 android 目录，Sync 后 Build → Build APK(s)。

## 说明
- Kotlin 代码此前未经编译验证。如果 Actions 里 android-apk 任务报错，把日志发给我即可修复。
- 首次运行 Windows 版时，防火墙请允许「专用网络」（TCP 47800、UDP 47801）。
