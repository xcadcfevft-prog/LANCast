'use strict';
/* 观看方的控制编码器：把鼠标 / 滚轮 / 键盘整理成 T_INPUT 指令（JSON）。不碰 DOM、不碰 socket，只通过 send(cmd) 往外送，所以能直接在 Node 里测试。
 *
 * 按「被控设备的平台」选语义（协议见 docs/PROTOCOL.md 第 11、12 节）：
 *   android 被控  触摸语义：鼠标左键 = 手指（d / m / u，连续笔画，实时跟手）；右键 = 返回；中键 = 主页；滚轮 = 一次滑动 w
 *   windows 被控  鼠标键盘语义：pm 指针移动 / pd、pu 鼠标键 / w 滚轮 / kd、ku 虚拟键 / key 组合键 / e 文字
 * 坐标一律是 0..1 的归一化坐标（相对画面）；t 是事件时间（毫秒，单调递增即可）。
 */
const r4 = v => Math.round(Math.min(1, Math.max(0, v)) * 10000) / 10000;
const BTN_NAME = ['l', 'm', 'r'];          // DOM MouseEvent.button：0 左 1 中 2 右
/* 默认时钟。注意必须是「箭头函数包一层再调全局」：浏览器 / Electron 渲染进程里 setTimeout 等是 window 的方法，
 * 一旦像 { setTimeout } 那样挂到别的对象上再 obj.setTimeout() 调用，就会抛 TypeError: Illegal invocation，
 * 按下 / 移动 / 滚轮的指令一条都发不出去（Node 里不会报错，所以单元测试发现不了；见 controller.test.js 的回归用例）。 */
const defaultClock = () => ({
  now: () => Date.now(),
  setTimeout: (fn, ms) => setTimeout(fn, ms),
  clearTimeout: id => clearTimeout(id),
  setInterval: (fn, ms) => setInterval(fn, ms),
  clearInterval: id => clearInterval(id)
});

class RemoteControl {
  constructor(platform, send, clock) {
    this.desktop = String(platform).toLowerCase() === 'windows';
    this.send = send;
    this.c = clock || defaultClock();
    this.sid = 0; this.down = false; this.t0 = 0; this.buf = []; this.last = [0, 0];     // 触摸语义状态
    this.btns = new Set(); this.keys = new Set(); this.pend = [];                          // 鼠标键盘语义状态
    this.lastSend = 0; this.flushTimer = 0; this.keepTimer = 0;
    this.wx = 0; this.wy = 0; this.wfx = 0; this.wfy = 0; this.wpix = false; this.wpos = null; this.wTimer = 0; this.lastWheel = -1e9;
    /* 滚动约 16ms（一帧）一包。安卓端以前是 160ms 一包、每包是一次「整段滑动」：滚得一抽一抽，还会排队积压；
     * 现在安卓端用一根连续的手指跟着位移走（见 InputService.kt 的「丝滑滚动」），包越密越跟手。 */
    this.wheelMs = 16;
  }

  /* ───────── 指针 ───────── */
  buttonDown(button, x, y, t) {
    if (this.desktop) {
      this._flushMoves();
      const b = BTN_NAME[button]; if (!b) return;
      this.btns.add(b); this._emit({ t: 'pd', b, x: r4(x), y: r4(y) }); this._keep();
      return;
    }
    if (button === 0) {                         // 手指按下
      this._flushMoves(); this.sid++; this.down = true; this.t0 = t; this.buf = []; this.last = [x, y];
      this._emit({ t: 'd', i: this.sid, x: r4(x), y: r4(y) }); this._keep();
    } else if (button === 2) this.nav('back');
    else if (button === 1) this.nav('home');
  }
  buttonUp(button, x, y, t) {
    if (this.desktop) {
      this._flushMoves();
      const b = BTN_NAME[button]; if (!b || !this.btns.has(b)) return;
      this.btns.delete(b); this._emit({ t: 'pu', b, x: r4(x), y: r4(y) });
      return;
    }
    if (button === 0 && this.down) {
      this._flushMoves();
      this._emit({ t: 'u', i: this.sid, x: r4(x), y: r4(y), d: Math.max(0, Math.round(t - this.t0)) });
      this.down = false;
    }
  }
  /* points: [[x, y, t], ...]（一次 pointermove 里的合并事件），无按键时 = 悬停 */
  move(points) {
    if (!points.length) return;
    const hold = this.desktop ? this.btns.size > 0 : this.down;
    if (!this.desktop) {
      if (!hold) return;                        // 触摸语义没有「悬停」
      let lastMs = this.buf.length ? this.buf[this.buf.length - 1][2] : 0;
      for (const p of points) {
        const ms = Math.max(lastMs, Math.round(p[2] - this.t0)); lastMs = ms;
        this.buf.push([r4(p[0]), r4(p[1]), ms]); this.last = [p[0], p[1]];
      }
      if (this.buf.length >= 24) this._flushMoves(); else this._schedule();
      return;
    }
    if (hold) for (const p of points) this.pend.push([r4(p[0]), r4(p[1])]);      // 拖动：每个点都要（画图 / 选文字）
    else this.pend = [[r4(points[points.length - 1][0]), r4(points[points.length - 1][1])]];   // 悬停：只要最新位置
    if (this.pend.length >= 24) this._flushMoves(); else this._schedule();
  }
  /* dx / dy：「格」，正 = 向下 / 向右（与 DOM 的 deltaY 符号一致）。
   * fx / fy（可选）：手指应移动的距离占画面宽 / 高的比例，正 = 向右 / 向下，即「内容跟着手指走」的方向（和 dx / dy 符号相反）。
   * 给了 fx / fy，安卓被控方就按像素 1:1 跟手；不给就按 dx / dy 的格数估算（旧行为）。电脑被控方只看 dx / dy。 */
  wheel(dx, dy, x, y, fx, fy) {
    this.wx += dx; this.wy += dy; this.wpos = [x, y];
    if (typeof fx === 'number' && typeof fy === 'number') { this.wfx += fx; this.wfy += fy; this.wpix = true; }
    if (!this.wTimer) this.wTimer = this.c.setTimeout(() => this._flushWheel(), Math.max(0, this.wheelMs - (this.c.now() - this.lastWheel)));
  }

  /* ───────── 键盘 / 文字 / 导航 ───────── */
  keyDown(vk) { if (!this.desktop) return; this.keys.add(vk); this._emit({ t: 'kd', vk }); this._keep(); }
  keyUp(vk) { if (!this.desktop || !this.keys.has(vk)) return; this.keys.delete(vk); this._emit({ t: 'ku', vk }); }
  combo(k) { this._emit({ t: 'key', k }); }                      // 仅电脑被控有意义
  nav(k) { this._emit({ t: 'k', k }); }                          // back | home | recents | notif | quick
  text(s) {                                                      // 把一段文字打到对方当前焦点处（\n = 回车）
    s = String(s || '');
    const parts = s.split('\n');
    parts.forEach((part, i) => {
      if (i > 0) this._emit({ t: 'e', op: 'enter' });
      for (let o = 0; o < part.length; o += 512) this._emit({ t: 'e', op: 'append', s: part.slice(o, o + 512) });
    });
  }
  del(n) { this._emit(n > 1 ? { t: 'e', op: 'del', n } : { t: 'e', op: 'del' }); }
  enter() { this._emit({ t: 'e', op: 'enter' }); }

  /* ───────── 收尾 ───────── */
  release() {                                   // 控制关闭 / 窗口失焦 / 断开：把还按着的「手指 / 键」都松开
    this._flushMoves(); this._flushWheel();
    if (this.desktop) {
      for (const b of [...this.btns]) this._emit({ t: 'pu', b });
      for (const k of [...this.keys]) this._emit({ t: 'ku', vk: k });
      this.btns.clear(); this.keys.clear();
    } else if (this.down) {
      this._emit({ t: 'u', i: this.sid, x: r4(this.last[0]), y: r4(this.last[1]), d: 0 });
      this.down = false;
    }
    this.c.clearInterval(this.keepTimer); this.keepTimer = 0;
  }
  destroy() { this.release(); this.c.clearTimeout(this.flushTimer); this.c.clearTimeout(this.wTimer); this.flushTimer = this.wTimer = 0; this.send = () => {}; }

  /* ───────── 内部 ───────── */
  _emit(cmd) { this.lastSend = this.c.now(); this.send(cmd); }
  _schedule() {                                  // 约 12ms 合并一包：延迟低，又不会每个鼠标事件发一帧
    if (this.flushTimer) return;
    const wait = Math.max(0, 12 - (this.c.now() - this.lastSend));
    this.flushTimer = this.c.setTimeout(() => this._flushMoves(), wait);
  }
  _flushMoves() {
    this.c.clearTimeout(this.flushTimer); this.flushTimer = 0;
    if (this.desktop) {
      if (this.pend.length) { const p = this.pend; this.pend = []; for (let i = 0; i < p.length; i += 64) this._emit({ t: 'pm', p: p.slice(i, i + 64) }); }
    } else if (this.buf.length) {
      const b = this.buf; this.buf = [];
      for (let i = 0; i < b.length; i += 64) this._emit({ t: 'm', i: this.sid, p: b.slice(i, i + 64) });
    }
  }
  _flushWheel() {
    this.c.clearTimeout(this.wTimer); this.wTimer = 0;
    const dx = Math.round(this.wx * 1000) / 1000, dy = Math.round(this.wy * 1000) / 1000;
    const sx = Math.round(this.wfx * 1e5) / 1e5, sy = Math.round(this.wfy * 1e5) / 1e5, pix = this.wpix;
    this.wx = this.wy = this.wfx = this.wfy = 0; this.wpix = false;
    if (!dx && !dy && !sx && !sy) return;
    const cmd = { t: 'w', dx, dy };
    if (pix && !this.desktop) { cmd.sx = sx; cmd.sy = sy; }
    if (this.wpos) { cmd.x = r4(this.wpos[0]); cmd.y = r4(this.wpos[1]); }
    this.lastWheel = this.c.now();
    this._emit(cmd);
  }
  _keep() {                                      // 按住不动时每 500ms 一个保活，对方才不会把「按着」当成掉线而松开
    if (this.keepTimer) return;
    this.keepTimer = this.c.setInterval(() => {
      const held = this.desktop ? (this.btns.size || this.keys.size) : this.down;
      if (!held) { this.c.clearInterval(this.keepTimer); this.keepTimer = 0; return; }
      if (this.c.now() - this.lastSend >= 400) this._emit({ t: 'h', i: this.sid });
    }, 500);
  }
}

module.exports = { RemoteControl, r4 };
