'use strict';
/* Win32 注入后端。两个实现，接口相同：{ name, send(ops) → 失败的事件个数, close() }
 *   koffi       进程内直接调用 user32.SendInput（koffi 自带 Windows 预编译库，不需要编译环境，延迟最低）
 *   powershell  常驻一个 powershell.exe，通过 stdin 一行一条指令（koffi 加载失败时的退路，不依赖任何 npm 包）
 * SendInput 返回 0 通常是被 UIPI 拦了：目标窗口是以管理员身份运行的（任务管理器、UAC 弹窗、管理员终端…），
 * 普通权限的程序不能向它们注入输入——此时返回失败数，上层会提示对方。
 */
const path = require('path');
const os = require('os');
const fs = require('fs');

function koffiBackend() {
  if (process.platform !== 'win32') throw new Error('仅支持 Windows');
  const koffi = require('koffi');
  const user32 = koffi.load('user32.dll');
  const MOUSEINPUT = koffi.struct('MOUSEINPUT', { dx: 'int32', dy: 'int32', mouseData: 'uint32', dwFlags: 'uint32', time: 'uint32', dwExtraInfo: 'uintptr_t' });
  const KEYBDINPUT = koffi.struct('KEYBDINPUT', { wVk: 'uint16', wScan: 'uint16', dwFlags: 'uint32', time: 'uint32', dwExtraInfo: 'uintptr_t' });
  const INPUT_U = koffi.union('INPUT_U', { mi: MOUSEINPUT, ki: KEYBDINPUT });
  const INPUT = koffi.struct('INPUT', { type: 'uint32', u: INPUT_U });
  const SIZE = koffi.sizeof(INPUT);
  if (SIZE !== 40 && SIZE !== 28) throw new Error('INPUT 结构大小异常：' + SIZE);   // x64 = 40，x86 = 28
  const SendInput = user32.func('uint32 __stdcall SendInput(uint32 cInputs, INPUT *pInputs, int cbSize)');
  const MapVirtualKeyW = user32.func('uint32 __stdcall MapVirtualKeyW(uint32 uCode, uint32 uMapType)');
  MapVirtualKeyW(0x41, 0);                                    // 自检：能调用 user32 就说明 FFI 正常

  return {
    name: 'koffi',
    send(ops) {
      let failed = 0;
      for (const o of ops) {
        const inp = o.t === 'm'
          ? { type: 0, u: { mi: { dx: o.x | 0, dy: o.y | 0, mouseData: o.data >>> 0, dwFlags: o.flags >>> 0, time: 0, dwExtraInfo: 0 } } }
          : { type: 1, u: { ki: { wVk: o.vk, wScan: o.vk ? MapVirtualKeyW(o.vk, 0) : o.scan, dwFlags: o.flags >>> 0, time: 0, dwExtraInfo: 0 } } };
        if (SendInput(1, inp, SIZE) !== 1) failed++;
      }
      return failed;
    },
    close() {}
  };
}

const PS_SCRIPT = `
$ErrorActionPreference = 'SilentlyContinue'
$src = @'
using System;
using System.Runtime.InteropServices;
public static class LC {
  [StructLayout(LayoutKind.Sequential)] public struct MOUSEINPUT { public int dx; public int dy; public uint mouseData; public uint dwFlags; public uint time; public IntPtr dwExtraInfo; }
  [StructLayout(LayoutKind.Sequential)] public struct KEYBDINPUT { public ushort wVk; public ushort wScan; public uint dwFlags; public uint time; public IntPtr dwExtraInfo; }
  [StructLayout(LayoutKind.Explicit)] public struct IU { [FieldOffset(0)] public MOUSEINPUT mi; [FieldOffset(0)] public KEYBDINPUT ki; }
  [StructLayout(LayoutKind.Sequential)] public struct INPUT { public uint type; public IU u; }
  [DllImport("user32.dll", SetLastError=true)] static extern uint SendInput(uint n, INPUT[] i, int cb);
  [DllImport("user32.dll")] static extern uint MapVirtualKey(uint c, uint t);
  public static void M(int dx, int dy, uint data, uint fl) {
    INPUT[] a = new INPUT[1]; a[0].type = 0;
    a[0].u.mi.dx = dx; a[0].u.mi.dy = dy; a[0].u.mi.mouseData = data; a[0].u.mi.dwFlags = fl;
    SendInput(1, a, Marshal.SizeOf(typeof(INPUT)));
  }
  public static void K(ushort vk, ushort sc, uint fl) {
    INPUT[] a = new INPUT[1]; a[0].type = 1;
    if (vk != 0 && sc == 0) sc = (ushort)MapVirtualKey(vk, 0);
    a[0].u.ki.wVk = vk; a[0].u.ki.wScan = sc; a[0].u.ki.dwFlags = fl;
    SendInput(1, a, Marshal.SizeOf(typeof(INPUT)));
  }
}
'@
Add-Type -TypeDefinition $src
while ($true) {
  $l = [Console]::In.ReadLine()
  if ($l -eq $null) { break }
  $p = $l.Split(' ')
  if ($p[0] -eq 'M') { [LC]::M([int]$p[1], [int]$p[2], [uint32]$p[3], [uint32]$p[4]) }
  elseif ($p[0] -eq 'K') { [LC]::K([uint16]$p[1], [uint16]$p[2], [uint32]$p[3]) }
}
`;

function powershellBackend() {
  if (process.platform !== 'win32') throw new Error('仅支持 Windows');
  const { spawn } = require('child_process');
  const file = path.join(os.tmpdir(), 'lancast-input-' + process.pid + '.ps1');
  fs.writeFileSync(file, PS_SCRIPT, 'utf8');
  const ps = spawn('powershell.exe', ['-NoLogo', '-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', file],
    { stdio: ['pipe', 'ignore', 'ignore'], windowsHide: true });
  let dead = false;
  ps.on('exit', () => { dead = true; });
  ps.on('error', () => { dead = true; });
  ps.stdin.on('error', () => { dead = true; });
  return {
    name: 'powershell',
    send(ops) {
      if (dead) throw new Error('PowerShell 注入进程已退出');
      const lines = ops.map(o => o.t === 'm'
        ? 'M ' + (o.x | 0) + ' ' + (o.y | 0) + ' ' + (o.data >>> 0) + ' ' + (o.flags >>> 0)
        : 'K ' + o.vk + ' ' + o.scan + ' ' + (o.flags >>> 0));
      ps.stdin.write(lines.join('\n') + '\n');
      return 0;
    },
    close() { dead = true; try { ps.kill(); } catch {} try { fs.unlinkSync(file); } catch {} }
  };
}

module.exports = { factories: [koffiBackend, powershellBackend], koffiBackend, powershellBackend, PS_SCRIPT };
