'use strict';
/* 瞬流 聊天里图片 / 视频文件的「严格无损」预览（Windows 端，与安卓端 Preview.kt 对齐）。
 *
 * 严格无损 = 预览不改动、不重新编码任何一个字节：
 *   · 直接读「原文件」（发送方 = 选的原文件；接收方 = 已通过 SHA-256 校验、保存下来的文件），不压缩、不转码、不另存副本；
 *   · 聊天气泡里只是缩略图（必须缩小才能放进气泡，同一个原文件由浏览器内核缩放显示），点开后是全分辨率查看：
 *       - 图片：按原始像素显示（naturalWidth × naturalHeight），放大超过物理像素 1:1 时用最近邻（pixelated），看到的就是文件里真实的像素；
 *         「1:1」按物理像素算（已考虑 Windows 显示缩放 devicePixelRatio）；滚轮缩放、拖动平移、双击在「适应窗口 / 1:1」间切换；
 *       - 视频：用内置播放器直接播放原文件，不转码。
 *   · 浏览器内核不支持的格式（如 HEIC、部分编码的视频）会明确提示，可一键用系统默认程序打开，文件本身不受影响。
 */
(function () {
  const IMG = new Set(['jpg', 'jpeg', 'png', 'webp', 'gif', 'bmp', 'avif', 'heic', 'heif']);
  const VID = new Set(['mp4', 'm4v', 'mov', 'webm', 'mkv', 'ogv', '3gp']);

  /** 按扩展名判断：'image' | 'video' | ''（其它文件） */
  function kind(name) {
    const m = /\.([^.\\/]+)$/.exec(String(name || ''));
    if (!m) return '';
    const e = m[1].toLowerCase();
    return IMG.has(e) ? 'image' : VID.has(e) ? 'video' : '';
  }
  const sizeText = n => n >= 2 ** 40 ? (n / 2 ** 40).toFixed(2) + ' TB' : n >= 2 ** 30 ? (n / 2 ** 30).toFixed(2) + ' GB' :
    n >= 2 ** 20 ? (n / 2 ** 20).toFixed(1) + ' MB' : n >= 1024 ? Math.round(n / 1024) + ' KB' : n + ' B';
  const clock = s => { s = Math.max(0, Math.floor(s)); const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), ss = s % 60; return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(ss).padStart(2, '0'); };

  const MP = { kind, sizeText, clock };
  if (typeof module !== 'undefined' && module.exports) module.exports = MP;
  if (typeof document === 'undefined') return;

  const fileUrl = p => require('url').pathToFileURL(p).href;
  const openDefault = p => { try { require('electron').ipcRenderer.send('open-item', p); } catch {} };

  /* ───────── 气泡缩略图 ─────────
   * 返回 { el, setOverlay(text) }：el 是缩略图元素（点击 → onOpen）；setOverlay 在传输中 / 失败时盖一层状态文字。 */
  MP.thumb = function (path, k, onOpen) {
    const el = document.createElement('div'); el.className = 'pvbox';
    const ov = document.createElement('div'); ov.className = 'ov'; ov.hidden = true;
    const fit = (w, h) => { if (w > 0 && h > 0) el.style.aspectRatio = '1 / ' + Math.min(1.5, Math.max(0.6, h / w)); };       // 和安卓端一样把高宽比限制在 0.6 ~ 1.5
    const broken = () => { const b = document.createElement('div'); b.className = 'pvx'; b.textContent = '预览不可用（文件已被移动 / 删除，或格式不支持）· 点击尝试打开'; el.replaceChildren(b, ov); };
    if (k === 'video') {
      const v = document.createElement('video');
      v.preload = 'metadata'; v.muted = true; v.playsInline = true; v.src = fileUrl(path) + '#t=0.1';
      v.addEventListener('loadedmetadata', () => {
        fit(v.videoWidth, v.videoHeight);
        if (isFinite(v.duration) && v.duration > 0) { const d = document.createElement('span'); d.className = 'dur'; d.textContent = clock(v.duration); el.appendChild(d); }
      });
      v.addEventListener('error', broken);
      const play = document.createElement('span'); play.className = 'play'; play.textContent = '▶';
      el.append(v, play);
    } else {
      const i = document.createElement('img');
      i.decoding = 'async'; i.draggable = false; i.src = fileUrl(path);
      i.addEventListener('load', () => fit(i.naturalWidth, i.naturalHeight));
      i.addEventListener('error', broken);
      el.appendChild(i);
    }
    el.appendChild(ov);
    el.onclick = () => onOpen && onOpen();
    return { el, setOverlay(t) { ov.textContent = t || ''; ov.hidden = !t; } };
  };

  /* ───────── 全屏查看器 ───────── */
  let V = null;
  function build() {
    const root = document.createElement('div'); root.id = 'mview'; root.hidden = true;
    root.innerHTML = '<div class="mvbar"><button class="mvclose">✕ 关闭</button><b class="mvname"></b><button class="mvopen">系统默认程序打开</button><button class="mvrecall danger">撤回</button></div>' +
      '<div class="mvinfo"></div><div class="mvstage"></div>';
    document.body.appendChild(root);
    V = { root, name: root.querySelector('.mvname'), info: root.querySelector('.mvinfo'), stage: root.querySelector('.mvstage'),
      closeB: root.querySelector('.mvclose'), openB: root.querySelector('.mvopen'), recallB: root.querySelector('.mvrecall'), cur: null };
    V.closeB.onclick = close;
    document.addEventListener('keydown', e => { if (e.key === 'Escape' && !root.hidden) { e.stopPropagation(); close(); } }, true);
  }

  function close() {
    if (!V || V.root.hidden) return;
    if (V.cur && V.cur.dispose) V.cur.dispose();
    V.cur = null; V.stage.replaceChildren(); V.root.hidden = true;
  }

  /** 打开查看器。opts: { path, name, size, kind: 'image'|'video', onRecall? }；onRecall 不为空时右上角有「撤回」（只有我发出的、已送达的文件有） */
  MP.open = function (opts) {
    if (!V) build();
    close();
    const { path, name, size, kind: k } = opts;
    V.name.textContent = name; V.root.hidden = false; V.info.textContent = k === 'image' ? '正在解码原图…' : '';
    V.openB.onclick = () => openDefault(path);
    V.recallB.hidden = !opts.onRecall;
    V.recallB.onclick = () => { close(); opts.onRecall(); };
    const sz = sizeText(size || 0);
    if (k === 'video') {
      const v = document.createElement('video');
      v.controls = true; v.autoplay = true; v.src = fileUrl(path); v.className = 'mvvid';
      v.addEventListener('loadedmetadata', () => {
        V.info.textContent = '原始视频 · ' + (v.videoWidth ? v.videoWidth + '×' + v.videoHeight + ' · ' : '') + (isFinite(v.duration) ? clock(v.duration) + ' · ' : '') + sz + ' · 原文件直接播放，未经转码';
      });
      v.addEventListener('error', () => { V.info.textContent = '内置播放器无法播放这个视频（编码不支持，或文件已被移动 / 删除）· 可点「系统默认程序打开」'; });
      V.stage.appendChild(v);
      V.info.textContent = '原始视频 · ' + sz + ' · 原文件直接播放，未经转码';
      V.cur = { dispose() { try { v.pause(); v.removeAttribute('src'); v.load(); } catch {} } };
      return;
    }
    // 图片：缩放 / 平移全部用 CSS transform，原图只加载一份、不重新编码
    const stage = V.stage, img = document.createElement('img');
    img.draggable = false; img.className = 'mvimg';
    let s = 1, tx = 0, ty = 0, fit = 1, nw = 0, nh = 0, drag = null;
    const dpr = () => window.devicePixelRatio || 1;
    const maxS = () => Math.max(16 / dpr(), fit * 4);
    function clampPan() {
      const W = stage.clientWidth, H = stage.clientHeight, dw = nw * s, dh = nh * s;
      tx = dw <= W ? (W - dw) / 2 : Math.min(0, Math.max(W - dw, tx));
      ty = dh <= H ? (H - dh) / 2 : Math.min(0, Math.max(H - dh, ty));
    }
    function apply() {
      clampPan();
      img.style.transform = 'translate(' + tx + 'px,' + ty + 'px) scale(' + s + ')';
      img.style.imageRendering = s * dpr() > 1.0001 ? 'pixelated' : 'auto';       // 放大超过物理像素 1:1 用最近邻：看到的就是文件里真实的像素，不做插值美化
    }
    function zoomAt(ns, fx, fy) {
      ns = Math.min(Math.max(ns, fit), maxS());
      tx = fx - (fx - tx) * ns / s; ty = fy - (fy - ty) * ns / s; s = ns; apply();
    }
    function computeFit() { fit = Math.min(stage.clientWidth / nw, stage.clientHeight / nh); }
    img.addEventListener('load', () => {
      nw = img.naturalWidth; nh = img.naturalHeight;
      img.style.width = nw + 'px'; img.style.height = nh + 'px';
      computeFit(); s = fit; apply();
      V.info.textContent = '原始图片 · ' + nw + '×' + nh + ' 像素 · ' + sz + ' · 原文件直接显示，未经压缩 / 重新编码 · 滚轮缩放 · 双击在「适应窗口 / 1:1 原始像素」间切换';
    });
    img.addEventListener('error', () => { V.info.textContent = '无法显示这张图片（内核不支持这个格式，或文件已被移动 / 删除）· 可点「系统默认程序打开」'; });
    stage.appendChild(img);
    img.src = fileUrl(path);
    const rect = () => stage.getBoundingClientRect();
    const onWheel = e => { e.preventDefault(); if (!nw) return; const r = rect(); zoomAt(s * Math.exp(-e.deltaY * 0.0015), e.clientX - r.left, e.clientY - r.top); };
    const onDown = e => { if (e.button !== 0 || !nw) return; drag = { x: e.clientX, y: e.clientY, tx, ty }; stage.classList.add('grab'); };
    const onMove = e => { if (!drag) return; tx = drag.tx + e.clientX - drag.x; ty = drag.ty + e.clientY - drag.y; apply(); };
    const onUp = () => { drag = null; stage.classList.remove('grab'); };
    const onDbl = e => {
      if (!nw) return;
      const r = rect();
      zoomAt(s > fit * 1.05 ? fit : Math.max(1 / dpr(), fit * 2.5), e.clientX - r.left, e.clientY - r.top);        // 已放大 → 适应窗口；否则放大到物理像素 1:1（原图比窗口还小就放大 2.5 倍）
    };
    const onResize = () => { if (!nw) return; const keep = s <= fit * 1.001; computeFit(); if (keep) s = fit; apply(); };
    stage.addEventListener('wheel', onWheel, { passive: false });
    stage.addEventListener('mousedown', onDown); window.addEventListener('mousemove', onMove); window.addEventListener('mouseup', onUp);
    stage.addEventListener('dblclick', onDbl); window.addEventListener('resize', onResize);
    V.cur = { dispose() {
      window.removeEventListener('mousemove', onMove); window.removeEventListener('mouseup', onUp); window.removeEventListener('resize', onResize);
      stage.removeEventListener('wheel', onWheel); stage.removeEventListener('mousedown', onDown); stage.removeEventListener('dblclick', onDbl);
      img.removeAttribute('src');
    } };
  };
  MP.close = close;
  if (typeof window !== 'undefined') window.MP = MP;
})();
