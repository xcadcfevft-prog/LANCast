'use strict';
/* 五子棋对战窗口的预加载脚本：把「和主窗口之间的消息通道」以 window.GomokuNet 的形式交给棋盘页面（gomoku.html）。
 * 页面本身不能直接访问 Node / 网络，所有消息经主进程转给主窗口，再由主窗口走加密聊天连接发给对方。 */
const { contextBridge, ipcRenderer } = require('electron');
let cb = null;
ipcRenderer.on('game-msg', (e, o) => { if (cb) { try { cb(o); } catch {} } });
contextBridge.exposeInMainWorld('GomokuNet', {
  init: ipcRenderer.sendSync('game-init'),
  send: o => ipcRenderer.send('game-send', o),
  onMessage: f => { cb = f; },
  ready: () => ipcRenderer.send('game-ready')
});
