'use strict';
/* 瞬流「安全聊天」——连接管理与消息状态机（纯逻辑：不碰 DOM / socket，会话对象和存储都由外面注入，方便单元测试）。
 * 安卓端 android/.../Chat.kt 的 ChatHub 是同一套逻辑。规范见 docs/PROTOCOL.md 第 14 节。
 *
 * 注入的东西：
 *   store   { load(peerId) → 消息数组, save(peerId, 数组), loadUnread() → {peerId: n}, saveUnread(obj) }
 *   peers() 已配对设备列表 [{ id, name, pin, ip, port, platform, online }]
 *   myPin()  本机的配对密钥（别人连本机时用的那个）
 *   dial(peer) → Promise<{ session, serverNonce, clientNonce }>   主动连对方（mode = "chat"）；session 要有
 *               sendFrame(type, buf) / attach(fn(type, flags, pts, payload)) / onClose = fn(reason) / close(reason)
 *   changed(peerId)           界面刷新
 *   notify({peerId, name, msg})  收到新消息（界面决定弹不弹通知）
 *
 * 消息状态：sending（还没收到对方的回执，会自动重发）→ sent（对方已收到）/ failed（对方不在线或多次重发失败，点一下可重试）。
 * 撤回（像 Telegram 的「为所有人删除」）：任何一方随时可以撤回自己发的消息，没有时间限制。撤回时本机立刻删掉内容，只留一个没有内容的「墓碑」
 * （id + 撤回状态），用来重发撤回指令直到对方回执 {t:'da'}（对方不在线就等它上线）；对方收到 {t:'d'} 后同样删掉内容，并留一个墓碑，
 * 这样撤回指令比原消息先到、或原消息被重发时，都不会把已撤回的消息又显示出来。只有发送者本人能撤回（接收方只认 from = peer 的记录）。
 * 两台设备同时互相发起连接时会出现两条连接：双方用同一条规则（发起方设备 ID 较小的那条）选「发送用」的连接，
 * 接收则两条都收；每条消息有唯一 ID，重复的只存一份，所以不会丢也不会重。
 */
const CC = require('./chatcrypto');

const MAX_KEEP = 500;                 // 每个聊天最多保留的消息条数
const RESEND_MS = 4000, MAX_TRIES = 4, MAX_DEL_TRIES = 20, FAIL_AFTER_MS = 30000, REDIAL_MS = 3000, KEY_TIMEOUT_MS = 8000;

function createHub(o) {
  const { myId, myName, myPin, store, peers, dial, changed = () => {}, notify = () => {}, now = () => Date.now() } = o;
  const cache = new Map();            // peerId → 消息数组
  const conns = new Map();            // peerId → Set<Conn>
  const dialing = new Map();          // peerId → 开始时间
  const lastDial = new Map();         // peerId → 上次尝试时间
  const pending = new Set();          // 有 sending 消息的 peerId
  const sasOf = new Map();
  let unread = {};
  try { unread = store.loadUnread() || {}; } catch {}
  const hub = { viewing: null };

  const msgs = id => { if (!cache.has(id)) { let a = []; try { a = store.load(id) || []; } catch {} cache.set(id, Array.isArray(a) ? a : []); } return cache.get(id); };
  const persist = id => { const a = msgs(id); if (a.length > MAX_KEEP) a.splice(0, a.length - MAX_KEEP); try { store.save(id, a); } catch {} };
  const peerInfo = id => peers().find(p => p.id === id) || null;
  const wipe = m => { for (const k of ['x', 'e', 'c', 'bg', 'st', 'tries', 'lt', 'ur', 'k']) delete m[k]; m.del = true; };     // 删光内容，只留墓碑
  const setUnread = (id, n) => { if (n > 0) unread[id] = n; else delete unread[id]; try { store.saveUnread(unread); } catch {} };

  /* ───────── 连接 ───────── */
  const liveConns = id => [...(conns.get(id) || [])].filter(c => !c.closed);
  function bestConn(id) {                                    // 双方一致的选择规则：发起方 ID 较小的那条优先
    let best = null;
    for (const c of liveConns(id)) {
      if (!c.ready) continue;
      const rank = c.isClient ? myId : id;
      if (!best || rank < best.rank || (rank === best.rank && c.t > best.c.t)) best = { c, rank };
    }
    return best ? best.c : null;
  }
  function sendObj(c, obj) {
    c.s.sendFrame(CC.T_CHAT_MSG, CC.seal(c.tx, ++c.txCtr, obj));
  }

  /* 把一条已建立（握手已通过）的会话接进来。meta: { peerId, isClient, serverNonce, clientNonce, pin, peerName } */
  hub.attach = function (s, meta) {
    const c = { s, peerId: meta.peerId, isClient: !!meta.isClient, meta, eph: CC.genEphemeral(), tx: null, rx: null, txCtr: 0, rxCtr: 0, ready: false, closed: false, t: now() };
    if (!conns.has(c.peerId)) conns.set(c.peerId, new Set());
    conns.get(c.peerId).add(c);
    const kill = reason => { if (c.closed) return; c.closed = true; clearTimeout(c.kt); const set = conns.get(c.peerId); if (set) set.delete(c); try { s.close(reason); } catch {} changed(c.peerId); };
    c.kill = kill;
    s.onClose = () => { if (c.closed) return; c.closed = true; clearTimeout(c.kt); const set = conns.get(c.peerId); if (set) set.delete(c); changed(c.peerId); };
    c.kt = setTimeout(() => { if (!c.ready) kill('安全校验超时'); }, KEY_TIMEOUT_MS);
    // 先发自己的密钥，再挂接收处理：attach 会立刻处理握手后已经到达的对方密钥，那时就要立刻回「hi」，次序反了对方会先收到 hi 再收到密钥
    s.sendFrame(CC.T_CHAT_KEY, Buffer.from(JSON.stringify({ v: 1, epk: c.eph.pub }), 'utf8'));
    s.attach((type, flags, pts, pl) => {
      try {
        if (type === CC.T_CHAT_KEY) {
          if (c.rx) return;                                  // 只接受一次
          let j; try { j = JSON.parse(pl.toString('utf8')); } catch { kill('协议错误'); return; }
          let k;
          try { k = CC.deriveSession({ eph: c.eph, peerPub: String(j.epk || ''), isClient: c.isClient, serverNonce: meta.serverNonce, clientNonce: meta.clientNonce, pin: meta.pin }); }
          catch (e) { kill('安全校验失败'); return; }
          c.tx = k.txKey; c.rx = k.rxKey; c.ready = true; sasOf.set(c.peerId, k.sas); clearTimeout(c.kt);
          sendObj(c, { t: 'hi', name: myName, id: myId });
          changed(c.peerId); flush(c.peerId);
        } else if (type === CC.T_CHAT_MSG) {
          if (!c.ready) { kill('协议错误'); return; }
          let r; try { r = CC.open(c.rx, pl, c.rxCtr); } catch (e) { kill('安全校验失败，已断开（消息被篡改，或对方密钥不对）'); return; }
          c.rxCtr = r.ctr;
          onPlain(c, CC.sanitizeIncoming(r.obj));
        } else if (type === CC.T_CHAT_VOICE) {              // 语音通话的 PCM 帧：同一把密钥、同一个计数器序列，解开后直接交给通话模块
          if (!c.ready) { kill('协议错误'); return; }
          let r; try { r = CC.openBin(c.rx, pl, c.rxCtr); } catch (e) { kill('安全校验失败，已断开（消息被篡改，或对方密钥不对）'); return; }
          c.rxCtr = r.ctr;
          if (hub.voice && hub.voice.onAudio) hub.voice.onAudio(c.peerId, r.buf);
        }
      } catch (e) { try { console.error('chat packet', e); } catch {} }
    });
    return c;
  };

  function onPlain(c, m) {
    if (!m) return;
    const id = c.peerId;
    if (m.t === 'a') {
      const x = msgs(id).find(v => v.id === m.id && v.from === 'me' && !v.del);
      if (x && x.st !== 'sent') { x.st = 'sent'; persist(id); changed(id); }
      return;
    }
    if (m.t === 'hi') { return; }
    if (m.t === 'vc') { if (hub.voice && hub.voice.onSignal) hub.voice.onSignal(id, m); return; }      // 语音通话信令：不存、不回执
    if (m.t === 'da') {                                       // 对方确认收到撤回：我这边的墓碑也可以丢了，不留任何痕迹
      const a = msgs(id), i = a.findIndex(v => v.id === m.id && v.from === 'me' && v.del);
      if (i >= 0) { a.splice(i, 1); persist(id); changed(id); }
      return;
    }
    if (m.t === 'd') {                                        // 对方撤回了他自己的消息
      const a = msgs(id);
      if (!a.some(v => v.id === m.id && v.from === 'me')) {   // 不能撤回「我发的」消息：只认对方自己的
        const x = a.find(v => v.id === m.id && v.from === 'peer');
        if (x) { if (!x.del) { if (x.ur && unread[id] > 0) setUnread(id, unread[id] - 1); wipe(x); } }
        else a.push({ id: m.id, ts: now(), from: 'peer', del: true });          // 原消息还没到：先记下，之后到的原消息直接丢掉
        persist(id); changed(id);
      }
      try { sendObj(c, { t: 'da', id: m.id }); } catch {}     // 不管有没有处理，都回执（回执丢了对方会重发）
      return;
    }
    // 文字 / 表情包：先回执（不管是不是重复，回执丢了对方会重发），再存
    try { sendObj(c, { t: 'a', id: m.id }); } catch {}
    const a = msgs(id);
    if (a.some(v => v.id === m.id)) return;
    const rec = Object.assign({}, m, { from: 'peer', k: m.t, ts: m.ts || now() });
    delete rec.t;
    if (hub.viewing !== id) rec.ur = true;
    a.push(rec); a.sort((x, y) => x.ts - y.ts); persist(id);
    if (hub.viewing !== id) setUnread(id, (unread[id] | 0) + 1);
    const p = peerInfo(id);
    notify({ peerId: id, name: p ? p.name : (c.meta.peerName || '对方'), msg: rec });
    changed(id);
  }

  /* ───────── 发送 / 重发 ───────── */
  function flush(id) {
    const a = msgs(id), c = bestConn(id); let dirty = false;
    for (const m of a) {
      if (m.from !== 'me' || m.st !== 'sending') continue;
      if (!c) continue;
      if (m.lt && now() - m.lt < RESEND_MS) continue;
      if ((m.tries | 0) >= MAX_TRIES) { m.st = 'failed'; dirty = true; continue; }
      m.tries = (m.tries | 0) + 1; m.lt = now(); dirty = true;
      const body = m.k === 's' ? { t: 's', id: m.id, ts: m.ts, e: m.e, c: m.c, bg: m.bg } : { t: 'm', id: m.id, ts: m.ts, x: m.x };
      try { sendObj(c, body); } catch { m.st = 'sending'; }
    }
    if (c) for (const m of a) {                                // 撤回指令：对方没回执就一直重发（对方不在线就等它上线）
      if (!m.del || m.from !== 'me' || m.dst !== 'sending') continue;
      if (m.dlt && now() - m.dlt < RESEND_MS) continue;
      if ((m.dtries | 0) >= MAX_DEL_TRIES) { m.dst = 'gaveup'; dirty = true; continue; }    // 连着发了很多次对方都不回执：多半是旧版本，不认识撤回
      m.dtries = (m.dtries | 0) + 1; m.dlt = now(); dirty = true;
      try { sendObj(c, { t: 'd', id: m.id }); } catch {}
    }
    if (dirty) { persist(id); changed(id); }
  }
  function ensureConn(id) {
    if (bestConn(id) || liveConns(id).length || dialing.has(id)) return;
    if (now() - (lastDial.get(id) || 0) < REDIAL_MS) return;
    const p = peerInfo(id); if (!p) return;
    lastDial.set(id, now()); dialing.set(id, now());
    Promise.resolve().then(() => dial(p)).then(r => {
      dialing.delete(id);
      hub.attach(r.session, { peerId: id, isClient: true, serverNonce: r.serverNonce, clientNonce: r.clientNonce, pin: p.pin + ':' + myPin(), peerName: p.name });      // 派生密钥用「服务端的配对密钥:客户端的配对密钥」：冒充别人 ID 的设备不知道对方自己的密钥，算不出同一把钥匙
    }).catch(() => { dialing.delete(id); });
  }
  function add(id, rec) {
    const a = msgs(id); a.push(rec); persist(id); pending.add(id); changed(id);
    ensureConn(id); flush(id);
    return rec;
  }
  hub.sendText = (id, text) => {
    const x = CC.clip(String(text), CC.MAX_TEXT); if (!x.trim()) return null;
    return add(id, { id: CC.newMsgId(), ts: now(), from: 'me', k: 'm', x, st: 'sending', tries: 0, lt: 0 });
  };
  hub.sendSticker = (id, st) => {
    const e = CC.clip(st.e, 16); if (!e) return null;
    return add(id, { id: CC.newMsgId(), ts: now(), from: 'me', k: 's', e, c: CC.clip(st.c, 16), bg: st.bg, st: 'sending', tries: 0, lt: 0 });
  };
  hub.retry = (id, msgId) => {
    const m = msgs(id).find(v => v.id === msgId && v.from === 'me');
    if (!m || m.st !== 'failed') return;
    m.st = 'sending'; m.tries = 0; m.lt = 0; m.ts = now(); persist(id); pending.add(id); lastDial.delete(id);
    changed(id); ensureConn(id); flush(id);
  };
  /* 撤回自己发的消息（双向）。返回 true = 已受理。没发出去过的消息直接删掉；发过的（哪怕没收到回执）留墓碑并通知对方。 */
  hub.recall = (id, msgId) => {
    const a = msgs(id), i = a.findIndex(v => v.id === msgId && v.from === 'me' && !v.del);
    if (i < 0) return false;
    const m = a[i];
    if (m.st !== 'sent' && !(m.tries | 0)) { a.splice(i, 1); persist(id); changed(id); return true; }       // 从没发出去过：对方不可能见过
    wipe(m); m.dst = 'sending'; m.dtries = 0; m.dlt = 0;
    persist(id); pending.add(id); lastDial.delete(id); changed(id);
    ensureConn(id); flush(id);
    return true;
  };
  const unsentRecalls = id => msgs(id).filter(m => m.del && m.from === 'me' && m.dst === 'sending');
  hub.pendingRecalls = id => unsentRecalls(id).length;
  /* ───────── 语音通话（无损 PCM，走同一条加密连接）─────────
   * hub.voice = { onSignal(peerId, obj), onAudio(peerId, Buffer) } 由通话模块（voice.js）设置。
   * 信令 / 音频只走 bestConn；信令发不出去（还没连上）返回 false，并顺手去建连。 */
  const VOICE_MAX_QUEUE = 256 * 1024;          // 发送队列超过这个值（约 2.7 秒的单声道 PCM）说明网络彻底堵住：丢掉这一帧，别让延迟越积越多
  hub.sendSignal = (id, obj) => {
    const c = bestConn(id);
    if (!c) { ensureConn(id); return false; }
    try { sendObj(c, Object.assign({ t: 'vc' }, obj)); return true; } catch { return false; }
  };
  hub.sendVoice = (id, plain) => {
    const c = bestConn(id); if (!c) return false;
    try {
      const sock = c.s && c.s.sock;
      if (sock && sock.writableLength > VOICE_MAX_QUEUE) return false;
      c.s.sendFrame(CC.T_CHAT_VOICE, CC.sealBin(c.tx, ++c.txCtr, plain)); return true;
    } catch { return false; }
  };
  hub.voice = null;

  /* 每秒调用一次：补连、重发、把等太久的标成失败 */
  hub.tick = () => {
    for (const id of [...pending]) {
      const a = msgs(id), waiting = a.filter(m => m.from === 'me' && m.st === 'sending'), dels = unsentRecalls(id).length;
      if (!waiting.length && !dels) { pending.delete(id); continue; }
      if (!peerInfo(id)) { for (const m of waiting) m.st = 'failed'; persist(id); changed(id); pending.delete(id); continue; }
      if (bestConn(id)) { flush(id); continue; }
      if (waiting.length || (peerInfo(id) || {}).online) ensureConn(id);      // 只有撤回指令在等：对方不在线时不用一直去连
      let dirty = false;
      for (const m of waiting) if (now() - m.ts > FAIL_AFTER_MS) { m.st = 'failed'; dirty = true; }
      if (dirty) { persist(id); changed(id); }
    }
  };

  /* ───────── 查询 / 管理 ───────── */
  hub.messages = id => msgs(id).filter(m => !m.del);          // 墓碑（已撤回的消息）不对界面可见
  hub.unread = id => unread[id] | 0;
  hub.totalUnread = () => Object.values(unread).reduce((s, v) => s + (v | 0), 0);
  hub.markRead = id => { if (unread[id]) { for (const m of msgs(id)) delete m.ur; persist(id); setUnread(id, 0); changed(id); } };
  hub.sas = id => (bestConn(id) ? sasOf.get(id) || '' : '');
  hub.ensure = id => ensureConn(id);                         // 界面打开某个聊天时：提前把加密连接建好（锁头 / 安全码才能显示）
  hub.isConnected = id => !!bestConn(id);
  hub.clear = id => {                                         // 清空本机记录；还没送到对方的撤回指令要留着，不然对方那边的消息就永远撤不掉了
    const keep = unsentRecalls(id);
    cache.set(id, keep); try { store.save(id, keep); } catch {} setUnread(id, 0);
    if (!keep.length) pending.delete(id); changed(id);
  };
  hub.dropPeer = id => { for (const c of liveConns(id)) c.kill('已取消配对'); };
  hub.connections = id => liveConns(id).length;
  hub.dispose = () => { for (const set of conns.values()) for (const c of set) { try { c.kill('关闭'); } catch {} } };
  // 启动时：上次没发完的消息继续发
  try { for (const p of peers()) if (msgs(p.id).some(m => (m.from === 'me' && m.st === 'sending') || (m.del && m.from === 'me' && m.dst === 'sending'))) pending.add(p.id); } catch {}
  return hub;
}

module.exports = { createHub, MAX_KEEP };
