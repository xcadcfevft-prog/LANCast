'use strict';
const { app, BrowserWindow, session, desktopCapturer, screen, powerSaveBlocker, ipcMain, dialog, shell } = require('electron');

// 窗口被最小化/遮挡时也不要降低定时器与渲染优先级（投屏时很重要）
app.commandLine.appendSwitch('disable-renderer-backgrounding');
app.commandLine.appendSwitch('disable-background-timer-throttling');
app.commandLine.appendSwitch('disable-backgrounding-occluded-windows');
// 让部分被 Chromium 黑名单误伤的显卡也能走硬件编解码
app.commandLine.appendSwitch('ignore-gpu-blocklist');

let win = null;
let psb = null;

function createWindow() {
  win = new BrowserWindow({
    width: 1120,
    height: 740,
    minWidth: 760,
    minHeight: 520,
    backgroundColor: '#e9edf1',
    title: 'LANCast',
    autoHideMenuBar: true,
    webPreferences: {
      nodeIntegration: true,      // 渲染进程直接使用 net / dgram / crypto（只加载本地页面）
      contextIsolation: false,
      backgroundThrottling: false
    }
  });
  // 文件被拖进窗口时，Electron 默认会把页面「导航」成那个文件；这里彻底禁止（拖放发文件由页面自己处理）
  win.webContents.on('will-navigate', e => e.preventDefault());
  win.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  win.loadFile('index.html');
}

app.whenReady().then(() => {
  // getDisplayMedia 不弹选择框：直接抓主屏 + 系统音频回环（WASAPI loopback，无损 PCM）
  session.defaultSession.setDisplayMediaRequestHandler(async (req, cb) => {
    try {
      const srcs = await desktopCapturer.getSources({ types: ['screen'] });
      const pid = String(screen.getPrimaryDisplay().id);
      const src = srcs.find(s => s.display_id === pid) || srcs[0];
      cb({ video: src, audio: 'loopback' });
    } catch (e) {
      cb({});
    }
  }, { useSystemPicker: false });

  ipcMain.on('keep-awake', (e, on) => {
    if (on && psb === null) psb = powerSaveBlocker.start('prevent-display-sleep');
    if (!on && psb !== null) { powerSaveBlocker.stop(psb); psb = null; }
  });

  // Chromium 要求 getDisplayMedia 必须在「用户手势」中调用；网络事件触发的调用没有手势，
  // 所以由主进程用 userGesture=true 的方式在页面里执行（页面把流存到 window.__capStream）。
  ipcMain.handle('capture', (e, json) => win.webContents.executeJavaScript('window.__capture(' + json + ')', true));

  // 文件互传：系统文件选择框 / 选择接收目录 / 打开接收目录
  ipcMain.handle('pick-files', async () => {
    const r = await dialog.showOpenDialog(win, { title: '选择要发送的文件（可多选）', properties: ['openFile', 'multiSelections'] });
    return r.canceled ? [] : r.filePaths;
  });
  ipcMain.handle('pick-dir', async (e, def) => {
    const r = await dialog.showOpenDialog(win, { title: '选择接收文件夹', defaultPath: def || undefined, properties: ['openDirectory', 'createDirectory'] });
    return r.canceled ? null : r.filePaths[0];
  });
  ipcMain.on('open-dir', (e, dir) => { if (typeof dir === 'string' && dir) shell.openPath(dir); });

  ipcMain.on('focus', () => { if (!win) return; if (win.isMinimized()) win.restore(); win.show(); win.focus(); });

  createWindow();
});

app.on('window-all-closed', () => app.quit());
