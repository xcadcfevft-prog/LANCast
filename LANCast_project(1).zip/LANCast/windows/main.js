'use strict';
const { app, BrowserWindow, session, desktopCapturer, screen, powerSaveBlocker, ipcMain, dialog, shell, globalShortcut, Menu } = require('electron');
const path = require('path');
const { createInjector } = require('./inject');
const { factories } = require('./inject-win');

// 窗口被最小化/遮挡时也不要降低定时器与渲染优先级（投屏时很重要）
app.commandLine.appendSwitch('disable-renderer-backgrounding');
app.commandLine.appendSwitch('disable-background-timer-throttling');
app.commandLine.appendSwitch('disable-backgrounding-occluded-windows');
// 让部分被 Chromium 黑名单误伤的显卡也能走硬件编解码
app.commandLine.appendSwitch('ignore-gpu-blocklist');

let win = null;
let psb = null;
const injector = createInjector({
  factories,
  log: m => console.log('[inject]', m),
  onBlocked: () => { if (win && !win.isDestroyed()) win.webContents.send('ctl-blocked'); }
});
const END_KEY = 'CommandOrControl+Alt+Shift+Q';
/* 被控期间不再显示屏幕顶部的「正在被控制」提示条；终止方式保留全局热键 Ctrl+Alt+Shift+Q（以及观看方 / 本机主窗口里结束会话）。 */
function ctlBanner(on) {
  if (on) { try { globalShortcut.register(END_KEY, () => { if (win && !win.isDestroyed()) win.webContents.send('ctl-end'); }); } catch {} }
  else { try { globalShortcut.unregister(END_KEY); } catch {} }
}
let psbX = null;          // 文件传输期间阻止系统休眠（屏幕可以熄灭）

function createWindow() {
  win = new BrowserWindow({
    width: 1120,
    height: 740,
    minWidth: 760,
    minHeight: 520,
    backgroundColor: '#e9edf1',
    title: '瞬流',
    icon: path.join(__dirname, 'icon.png'),
    autoHideMenuBar: true,
    webPreferences: {
      nodeIntegration: true,      // 渲染进程直接使用 net / dgram / crypto（只加载本地页面）
      contextIsolation: false,
      backgroundThrottling: false
    }
  });
  win.on('focus', () => { try { win.flashFrame(false); } catch {} });
  win.loadFile('index.html');
}

app.whenReady().then(() => {
  Menu.setApplicationMenu(null);     // 去掉默认菜单：否则控制对方时 Ctrl+R 之类的按键会被本机菜单抢走
  // getDisplayMedia 不弹选择框：直接抓主屏 + 系统音频回环（WASAPI loopback，无损 PCM）
  session.defaultSession.setDisplayMediaRequestHandler(async (req, cb) => {
    try {
      const srcs = await desktopCapturer.getSources({ types: ['screen'] });
      const pid = String(screen.getPrimaryDisplay().id);
      const src = srcs.find(s => s.display_id === pid) || srcs[0];
      cb({ video: src, audio: 'loopback' });
    } catch (e) {
      cb({});
    }
  }, { useSystemPicker: false });

  ipcMain.on('keep-awake', (e, on) => {
    if (on && psb === null) psb = powerSaveBlocker.start('prevent-display-sleep');
    if (!on && psb !== null) { powerSaveBlocker.stop(psb); psb = null; }
  });

  // ── 文件互传需要的系统对话框 / 路径 / 防休眠 ──
  ipcMain.on('keep-awake-xfer', (e, on) => {
    if (on && psbX === null) psbX = powerSaveBlocker.start('prevent-app-suspension');
    if (!on && psbX !== null) { powerSaveBlocker.stop(psbX); psbX = null; }
  });
  ipcMain.on('get-path', (e, name) => { try { e.returnValue = app.getPath(name); } catch { e.returnValue = ''; } });
  ipcMain.handle('pick-files', async () => {
    const r = await dialog.showOpenDialog(win, { title: '选择要发送的文件', properties: ['openFile', 'multiSelections'] });
    return r.canceled ? [] : r.filePaths;
  });
  ipcMain.handle('pick-folder', async (e, def) => {
    const r = await dialog.showOpenDialog(win, { title: '选择接收文件的保存位置', defaultPath: def || undefined, properties: ['openDirectory', 'createDirectory'] });
    return r.canceled ? '' : r.filePaths[0];
  });
  ipcMain.on('open-folder', (e, p) => { if (p) shell.openPath(p); });
  ipcMain.on('show-item', (e, p) => { if (p) shell.showItemInFolder(p); });

  // Chromium 要求 getDisplayMedia 必须在「用户手势」中调用；网络事件触发的调用没有手势，
  // 所以由主进程用 userGesture=true 的方式在页面里执行（页面把流存到 window.__capStream）。
  ipcMain.handle('capture', (e, json) => win.webContents.executeJavaScript('window.__capture(' + json + ')', true));

  // ── 屏幕控制（本机被控）──
  ipcMain.handle('ctl-init', () => injector.init());                       // 授权前确认输入注入可用
  ipcMain.on('ctl-active', (e, info) => { injector.setActive(!!(info && info.on)); ctlBanner(!!(info && info.on)); });
  ipcMain.on('inject', (e, cmd) => injector.handle(cmd));
  ipcMain.on('ctl-end', () => { if (win && !win.isDestroyed()) win.webContents.send('ctl-end'); });

  ipcMain.on('flash', () => { try { if (win && !win.isDestroyed() && !win.isFocused()) win.flashFrame(true); } catch {} });   // 收到聊天消息：任务栏图标闪烁
  ipcMain.on('focus', () => { if (!win) return; if (win.isMinimized()) win.restore(); win.show(); win.focus(); });

  createWindow();
});

app.on('will-quit', () => { try { globalShortcut.unregisterAll(); } catch {} injector.close(); });
app.on('window-all-closed', () => app.quit());
