'use strict';
/* LANCast 文件互传（Windows 端）
 *
 * 复用现有的 TCP 47800 连接和 PIN 认证，握手时 mode = "file"。
 * 帧格式与投屏相同：16 字节包头(大端) type u8 | flags u8 | reserved u16 | len u32 | pts u64。
 * 文件互传的帧类型：
 *   32 OFFER  发送方→接收方  JSON {id, name, size, mtime}                        “我要发这个文件”
 *   33 REPLY  接收方→发送方  JSON {id, action:"accept"|"reject", offset, reason}  “可以；从 offset 字节开始续传”
 *   34 DATA   发送方→接收方  原始字节（≤1 MiB），pts = 这块数据在文件中的起始偏移   不做任何编码/压缩/转换
 *   35 END    发送方→接收方  JSON {id, size, sha256}                              整个文件的 SHA-256
 *   36 RESULT 接收方→发送方  JSON {id, ok, reason, sha256}                        接收方校验结果
 *   37 BYE    发送方→接收方  （空）                                               这一批文件发完了
 *
 * 无损保证：
 *   1. 文件内容按原始字节流式传输，不转码、不压缩、不限制格式；
 *   2. 偏移量和文件大小都是 64 位（JSON 里是 53 位安全整数，约 9 PB），没有大小限制；
 *   3. 发送方和接收方各自对完整文件计算 SHA-256，一致才算成功；不一致则删除临时文件并报告失败；
 *   4. 接收先写到「文件名.xxxx.lancast-part」，校验通过后才改成正式文件名，因此文件夹里不会出现“半个文件”冒充成功；
 *   5. 连接中断时保留 .lancast-part，重新发送同一个文件会自动从断点续传（续传前会重新校验已收到的部分）。
 */
(function () {
  const fs = require('fs'), fsp = fs.promises, path = require('path'), crypto = require('crypto');

  const FT = { OFFER: 32, REPLY: 33, DATA: 34, END: 35, RESULT: 36, BYE: 37 };
  const CHUNK = 1 << 20;                 // 每个 DATA 帧 1 MiB
  const MAX_DATA = 4 * CHUNK, MAX_JSON = 1 << 20;
  const NOP = () => {};
  const ACTIVE = new Set(['queued', 'offering', 'sending', 'receiving', 'verifying']);

  /* ───────────── 帧读写 ───────────── */
  function putHdr(b, type, len, pts) {
    b[0] = type; b[1] = 0; b.writeUInt16BE(0, 2); b.writeUInt32BE(len, 4);
    pts = Math.max(0, Math.floor(pts || 0));
    b.writeUInt32BE(Math.floor(pts / 4294967296) >>> 0, 8); b.writeUInt32BE(pts >>> 0, 12);
    return b;
  }
  function jsonFrame(type, obj) {
    const body = Buffer.from(JSON.stringify(obj), 'utf8');
    const b = Buffer.allocUnsafe(16 + body.length);
    putHdr(b, type, body.length, 0); body.copy(b, 16);
    return b;
  }

  /* 从 socket 精确读取 n 字节。用 read(n) + 'readable'：磁盘写不过来时自然反压，内存不会暴涨 */
  class Reader {
    constructor(sock) {
      this.sock = sock; this.err = null; this.ended = false; this.waiters = [];
      sock.on('readable', () => this._wake());
      sock.on('end', () => { this.ended = true; this._wake(); });
      sock.on('close', () => { this.ended = true; this._wake(); });
      sock.on('error', e => { this.err = e; this._wake(); });
    }
    _wake() { const w = this.waiters; this.waiters = []; for (const f of w) f(); }
    async read(n) {
      if (n === 0) return Buffer.alloc(0);
      for (;;) {
        if (this.err) throw this.err;
        const b = this.sock.read(n);
        if (b) { if (b.length < n) throw new Error('连接已断开'); return b; }
        if (this.ended || this.sock.destroyed) throw new Error('连接已断开');
        await new Promise(r => this.waiters.push(r));
      }
    }
    async frame() {
      const h = await this.read(16);
      const type = h[0], len = h.readUInt32BE(4), pts = h.readUInt32BE(8) * 4294967296 + h.readUInt32BE(12);
      if (len > (type === FT.DATA ? MAX_DATA : MAX_JSON)) throw new Error('收到非法数据');
      return { type, pts, body: await this.read(len) };
    }
    async json(type) {
      const f = await this.frame();
      if (f.type !== type) throw new Error('协议错误（收到类型 ' + f.type + '）');
      try { return JSON.parse(f.body.toString('utf8')); } catch { throw new Error('协议错误'); }
    }
  }

  /* 写入并遵守反压 */
  async function sendBuf(sock, buf) {
    if (sock.destroyed) throw new Error('连接已断开');
    if (sock.write(buf)) return;
    await new Promise((res, rej) => {
      const cleanup = () => { sock.off('drain', ok); sock.off('close', bad); sock.off('error', bad); };
      const ok = () => { cleanup(); res(); };
      const bad = e => { cleanup(); rej(e instanceof Error ? e : new Error('连接已断开')); };
      sock.once('drain', ok); sock.once('close', bad); sock.once('error', bad);
    });
  }

  function explain(e) {                  // 把底层网络错误翻译成人话
    const m = (e && e.message) || '连接中断';
    return /ECONNRESET|EPIPE|ECONNABORTED|连接已断开|socket hang up/i.test(m) ? '连接中断（对方取消，或网络断开）' : m;
  }
  function watchdog(sock, ctl, ms) {
    return setInterval(() => {
      if (ctl.phase === 'data' && Date.now() - ctl.lastAct > ms) sock.destroy(new Error('传输停滞超过 ' + Math.round(ms / 1000) + ' 秒，已中止'));
    }, 5000);
  }

  /* ───────────── 文件名 / 磁盘 ───────────── */
  /* 只做 Windows 必须的清理：非法字符、保留设备名、结尾的点和空格、过长。中文等 Unicode 原样保留。 */
  function safeName(raw) {
    let s = String(raw == null ? '' : raw).replace(/[\u0000-\u001f\u007f\\/:*?"<>|]/g, '_').replace(/^\s+/, '').replace(/[. \u00a0]+$/g, '');
    if (!s) s = 'file';
    if (/^(con|prn|aux|nul|com[0-9]|lpt[0-9])(\..*)?$/i.test(s)) s = '_' + s;
    if (s.length > 180) {
      const ext = path.extname(s), e = ext.length <= 16 ? ext : '';
      let stem = s.slice(0, 180 - e.length);
      if (/[\ud800-\udbff]$/.test(stem)) stem = stem.slice(0, -1);
      s = stem + e;
    }
    return s;
  }
  function uniqueName(dir, name) {
    if (!fs.existsSync(path.join(dir, name))) return name;
    const ext = path.extname(name), stem = name.slice(0, name.length - ext.length);
    for (let i = 1; ; i++) {
      const n = stem + ' (' + i + ')' + ext;
      if (!fs.existsSync(path.join(dir, n))) return n;
    }
  }
  const partKey = (name, size, mtime) => crypto.createHash('sha1').update(name + '|' + size + '|' + mtime).digest('hex').slice(0, 10);
  async function freeBytes(dir) {
    try { const s = await fsp.statfs(dir); return Number(s.bavail) * Number(s.bsize); } catch { return Infinity; }
  }
  async function writeFull(fh, buf, pos) {
    let o = 0;
    while (o < buf.length) {
      const { bytesWritten } = await fh.write(buf, o, buf.length - o, pos + o);
      if (!bytesWritten) throw new Error('写入磁盘失败');
      o += bytesWritten;
    }
  }
  async function readFull(fh, buf, off, len, pos) {
    let n = 0;
    while (n < len) {
      const { bytesRead } = await fh.read(buf, off + n, len - n, pos + n);
      if (!bytesRead) break;
      n += bytesRead;
    }
    return n;
  }
  const sizeText = n => n >= 2 ** 40 ? (n / 2 ** 40).toFixed(2) + ' TB' : n >= 2 ** 30 ? (n / 2 ** 30).toFixed(2) + ' GB' :
    n >= 2 ** 20 ? (n / 2 ** 20).toFixed(1) + ' MB' : n >= 1024 ? Math.round(n / 1024) + ' KB' : n + ' B';

  /* ───────────── 发送 ─────────────
   * items: [{ path, x }]，x 是界面用的传输记录 {name,size,done,state,msg,...}；ctl: {cancelled, phase, lastAct}
   * 已建立并认证好的 socket；一个连接里按顺序发多个文件。 */
  async function sendFiles(sock, items, ctl, hooks) {
    const upd = (hooks && hooks.update) || NOP;
    const r = new Reader(sock);
    const wd = watchdog(sock, ctl, 120000);
    try {
      for (const it of items) {
        if (ctl.cancelled) break;
        await sendOne(sock, r, it, ctl, upd);
      }
      if (!ctl.cancelled) { ctl.phase = 'idle'; await sendBuf(sock, putHdr(Buffer.allocUnsafe(16), FT.BYE, 0, 0)); }
    } catch (e) {
      const why = ctl.cancelled ? '已取消' : explain(e);
      for (const it of items) {
        if (ACTIVE.has(it.x.state)) { it.x.state = ctl.cancelled ? 'cancelled' : 'failed'; it.x.msg = why; upd(it.x, true); }
      }
    } finally {
      clearInterval(wd);
      for (const it of items) if (ACTIVE.has(it.x.state)) { it.x.state = 'cancelled'; it.x.msg = '已取消'; upd(it.x, true); }
      try { sock.end(); } catch {}
      setTimeout(() => { try { sock.destroy(); } catch {} }, 800);
    }
  }

  async function sendOne(sock, r, it, ctl, upd) {
    const x = it.x;
    let st;
    try {
      st = await fsp.stat(it.path);
      if (!st.isFile()) throw new Error(st.isDirectory() ? '这是文件夹，暂不支持直接发送文件夹（请先压缩成一个文件）' : '不是普通文件');
    } catch (e) { x.state = 'failed'; x.msg = '无法读取：' + e.message; upd(x, true); return; }
    x.size = st.size; x.done = 0;
    const id = crypto.randomBytes(6).toString('hex');
    x.state = 'offering'; ctl.phase = 'idle'; upd(x, true);
    await sendBuf(sock, jsonFrame(FT.OFFER, { id, name: path.basename(it.path), size: st.size, mtime: Math.floor(st.mtimeMs) }));
    const rep = await r.json(FT.REPLY);
    if (rep.id !== id) throw new Error('协议错误（编号不符）');
    if (rep.action !== 'accept') { x.state = 'failed'; x.msg = rep.reason || '对方拒绝接收'; upd(x, true); return; }
    const offset = Number(rep.offset) || 0;
    if (!Number.isSafeInteger(offset) || offset < 0 || offset > st.size) throw new Error('协议错误（续传位置无效）');

    const h = crypto.createHash('sha256');
    const fh = await fsp.open(it.path, 'r');
    try {
      x.state = 'sending'; x.msg = offset > 0 ? '从 ' + sizeText(offset) + ' 处续传' : ''; x.done = 0; upd(x, true);
      ctl.phase = 'data'; ctl.lastAct = Date.now();
      let pos = 0;
      while (pos < st.size) {
        if (ctl.cancelled) throw new Error('已取消');
        if (!x.startAt && pos >= offset) { x.startAt = Date.now(); x.startDone = pos; }
        const limit = pos < offset ? offset : st.size;       // 续传：[0,offset) 只参与校验，不再发送
        const want = Math.min(CHUNK, limit - pos);
        const b = Buffer.allocUnsafe(16 + want);
        const n = await readFull(fh, b, 16, want, pos);
        if (n < want) throw new Error('读取文件失败：文件在传输过程中被改动或变小');
        h.update(b.subarray(16));
        if (pos >= offset) { putHdr(b, FT.DATA, want, pos); await sendBuf(sock, b); }
        pos += want; x.done = pos; ctl.lastAct = Date.now(); upd(x);
      }
      if (!x.startAt) { x.startAt = Date.now(); x.startDone = st.size; }
    } finally { await fh.close().catch(NOP); }

    ctl.phase = 'idle';
    x.state = 'verifying'; x.msg = '等待对方校验…'; upd(x, true);
    const digest = h.digest('hex');
    await sendBuf(sock, jsonFrame(FT.END, { id, size: st.size, sha256: digest }));
    const res = await r.json(FT.RESULT);
    if (res.ok) { x.state = 'done'; x.msg = '已完成 · SHA-256 校验一致'; x.sha = digest; }
    else { x.state = 'failed'; x.msg = res.reason || '对方校验失败'; }
    upd(x, true);
  }

  /* ───────────── 接收 ─────────────
   * opts: { dir: string | () => string, newItem(info) → x, hooks: { update } }
   * 接收端不限大小：边收边写盘，内存占用恒定（约几 MB）。 */
  async function receiveLoop(sock, opts, ctl) {
    const upd = (opts.hooks && opts.hooks.update) || NOP;
    const r = new Reader(sock);
    const wd = watchdog(sock, ctl, 120000);
    const cur = { x: null };
    try {
      for (;;) {
        ctl.phase = 'idle';
        const f = await r.frame();
        if (f.type === FT.BYE) break;
        if (f.type !== FT.OFFER) throw new Error('协议错误（期待 OFFER，收到 ' + f.type + '）');
        let offer;
        try { offer = JSON.parse(f.body.toString('utf8')); } catch { throw new Error('协议错误'); }
        await recvOne(sock, r, offer, opts, ctl, upd, cur);
        cur.x = null;
      }
    } catch (e) {
      const x = cur.x;
      if (x && ACTIVE.has(x.state)) {
        x.state = ctl.cancelled ? 'cancelled' : 'failed';
        x.msg = ctl.cancelled ? '已取消' : explain(e) + (x.done > 0 && x.keepPart ? '；已保留 ' + sizeText(x.done) + '，重新发送同一个文件会自动续传' : '');
        upd(x, true);
      }
    } finally {
      clearInterval(wd);
      try { sock.end(); } catch {}
      setTimeout(() => { try { sock.destroy(); } catch {} }, 800);
    }
  }

  async function recvOne(sock, r, offer, opts, ctl, upd, cur) {
    const id = String(offer.id || ''), size = Number(offer.size), mtime = Number(offer.mtime) || 0;
    const reply = o => sendBuf(sock, jsonFrame(FT.REPLY, Object.assign({ id }, o)));
    const rejectWith = async (x, reason) => { if (x) { x.state = 'failed'; x.msg = reason; upd(x, true); } await reply({ action: 'reject', reason }); };

    const safe = safeName(offer.name);
    const x = opts.newItem({ id, name: safe, rawName: String(offer.name || ''), size: Number.isSafeInteger(size) ? size : 0 });
    cur.x = x; x.state = 'offering'; upd(x, true);
    if (!Number.isSafeInteger(size) || size < 0) return rejectWith(x, '文件大小无效');

    const dir = typeof opts.dir === 'function' ? opts.dir() : opts.dir;
    try { await fsp.mkdir(dir, { recursive: true }); } catch (e) { return rejectWith(x, '接收方无法创建文件夹：' + e.message); }

    const part = path.join(dir, safe + '.' + partKey(safe, size, mtime) + '.lancast-part');
    let offset = 0, st = null;
    try { st = await fsp.stat(part); } catch {}
    if (st) {
      if (st.isFile() && st.size <= size) offset = st.size;
      else await fsp.unlink(part).catch(NOP);
    }
    const free = await freeBytes(dir);
    if (size - offset + 16 * 2 ** 20 > free) return rejectWith(x, '接收方磁盘空间不足（还需要 ' + sizeText(size - offset) + '，可用 ' + sizeText(free) + '）');

    const h = crypto.createHash('sha256');
    if (offset > 0) {                                             // 续传：先重新校验已收到的部分
      x.state = 'verifying'; x.done = offset; x.msg = '正在校验已收到的 ' + sizeText(offset) + '…'; upd(x, true);
      try { for await (const c of fs.createReadStream(part, { highWaterMark: CHUNK })) { h.update(c); if (ctl.cancelled) throw new Error('已取消'); } }
      catch (e) { if (ctl.cancelled) throw e; return rejectWith(x, '读取临时文件失败：' + e.message); }
    }
    let fh;
    try { fh = await fsp.open(part, offset > 0 ? 'r+' : 'w'); } catch (e) { return rejectWith(x, '接收方无法写入文件：' + e.message); }
    x.keepPart = true; x.done = offset; x.startDone = offset; x.startAt = Date.now();
    x.state = 'receiving'; x.msg = offset > 0 ? '从 ' + sizeText(offset) + ' 处续传' : ''; upd(x, true);
    await reply({ action: 'accept', offset });

    let pos = offset, end = null;
    ctl.phase = 'data'; ctl.lastAct = Date.now();
    try {
      for (;;) {
        const fr = await r.frame();
        ctl.lastAct = Date.now();
        if (fr.type === FT.DATA) {
          if (fr.pts !== pos) throw new Error('数据错位（偏移 ' + fr.pts + '，应为 ' + pos + '）');
          if (pos + fr.body.length > size) throw new Error('收到的数据超过声明的文件大小');
          h.update(fr.body);
          await writeFull(fh, fr.body, pos);
          pos += fr.body.length; x.done = pos; upd(x);
        } else if (fr.type === FT.END) {
          try { end = JSON.parse(fr.body.toString('utf8')); } catch { throw new Error('协议错误'); }
          break;
        } else throw new Error('协议错误（数据阶段收到类型 ' + fr.type + '）');
      }
      ctl.phase = 'idle';
      x.state = 'verifying'; x.msg = '正在校验…'; upd(x, true);
      try { await fh.sync(); } catch {}
    } catch (e) {
      await fh.close().catch(NOP);
      if (ctl.cancelled) { x.keepPart = false; await fsp.unlink(part).catch(NOP); }
      throw e;
    }
    await fh.close().catch(NOP);

    const digest = h.digest('hex');
    if (pos !== size || Number(end.size) !== size || String(end.sha256).toLowerCase() !== digest) {
      await fsp.unlink(part).catch(NOP); x.keepPart = false;
      const why = pos !== size ? '收到的字节数（' + pos + '）与文件大小（' + size + '）不符' : 'SHA-256 校验不一致，文件可能在传输中损坏，已丢弃，请重新发送';
      x.state = 'failed'; x.msg = why; upd(x, true);
      await sendBuf(sock, jsonFrame(FT.RESULT, { id, ok: false, reason: why, sha256: digest }));
      return;
    }
    const finalName = uniqueName(dir, safe), finalPath = path.join(dir, finalName);
    try { await fsp.rename(part, finalPath); }
    catch (e) {
      x.state = 'failed'; x.msg = '无法保存文件：' + e.message; upd(x, true);
      await sendBuf(sock, jsonFrame(FT.RESULT, { id, ok: false, reason: '接收方无法保存文件：' + e.message, sha256: digest }));
      return;
    }
    x.keepPart = false;
    if (mtime > 0) { try { await fsp.utimes(finalPath, new Date(), new Date(mtime)); } catch {} }
    x.state = 'done'; x.saved = finalPath; x.sha = digest;
    x.msg = '已完成 · SHA-256 校验一致' + (finalName !== safe ? ' · 已另存为 ' + finalName : '');
    upd(x, true);
    await sendBuf(sock, jsonFrame(FT.RESULT, { id, ok: true, sha256: digest }));
  }

  const FX = { FT, CHUNK, ACTIVE, safeName, uniqueName, sizeText, sendFiles, receiveLoop };
  if (typeof module !== 'undefined' && module.exports) module.exports = FX;
  if (typeof window !== 'undefined') window.FX = FX;
  if (typeof document !== 'undefined') initUi(FX);

  /* ═════════════════════ 界面部分（只在 Electron 页面里运行） ═════════════════════ */
  function initUi(FX) {
    const os = require('os');
    const { ipcRenderer, webUtils } = require('electron');
    const xfers = [];                    // 所有传输记录（新的在前）
    const rows = new Map();              // x → 行元素
    let seq = 0, activeCount = 0, renderTimer = 0;
    const fileSec = $('#fileSec');
    if (!fileSec) return;

    const downloads = (() => { try { return ipcRenderer.sendSync('get-path', 'downloads') || ''; } catch { return ''; } })() || path.join(os.homedir(), 'Downloads');
    let recvDir = LS.get('recvDir', '') || path.join(downloads, 'LANCast');
    const fmtT = s => { s = Math.max(0, Math.round(s)); const h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), ss = s % 60; return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(ss).padStart(2, '0'); };

    function newX(p) {
      const x = Object.assign({ seq: ++seq, state: 'queued', msg: '', size: 0, done: 0, startAt: 0, startDone: 0, spd: 0, lastT: 0, lastD: 0, saved: '' }, p);
      xfers.unshift(x); render(); return x;
    }
    function update(x, force) {
      const now = performance.now();
      if (!x.lastT) { x.lastT = now; x.lastD = x.done; }
      else if (now - x.lastT >= 500) { const inst = (x.done - x.lastD) / ((now - x.lastT) / 1000); x.spd = x.spd ? x.spd * 0.6 + inst * 0.4 : inst; x.lastT = now; x.lastD = x.done; }
      if (force) { clearTimeout(renderTimer); renderTimer = 0; render(); return; }
      if (!renderTimer) renderTimer = setTimeout(() => { renderTimer = 0; render(); }, 200);
    }
    const hooks = { update };

    function activity(delta) {
      const was = activeCount > 0; activeCount = Math.max(0, activeCount + delta);
      if (was !== activeCount > 0) ipcRenderer.send('keep-awake-xfer', activeCount > 0);
    }

    function stateText(x) {
      switch (x.state) {
        case 'queued': return '排队中';
        case 'offering': return x.msg || '等待对方确认…';
        case 'sending': case 'receiving': {
          const pct = x.size ? (x.done / x.size * 100) : 100;
          const left = x.spd > 1 ? ' · 剩余 ' + fmtT((x.size - x.done) / x.spd) : '';
          return pct.toFixed(1) + '% · ' + FX.sizeText(x.done) + ' / ' + FX.sizeText(x.size) + (x.spd > 1 ? ' · ' + FX.sizeText(x.spd) + '/s' + left : '') + (x.msg ? ' · ' + x.msg : '');
        }
        case 'verifying': return x.msg || '校验中…';
        case 'done': return x.msg + ' · ' + FX.sizeText(x.size);
        default: return x.msg || '';
      }
    }
    function render() {
      const box = $('#xfers');
      if (!xfers.length) { rows.clear(); box.innerHTML = '<div class="empty">还没有传输记录。拖入文件，或点上面的“选择文件…”。</div>'; return; }
      if (box.querySelector('.empty')) box.innerHTML = '';
      for (const x of xfers) {
        let row = rows.get(x);
        if (!row) {
          const el = document.createElement('div'); el.className = 'xf';
          el.innerHTML = '<div class="xtop"><b class="xn"></b><span class="xd muted"></span></div><progress class="xp" max="1000" value="0"></progress><div class="xrow"><span class="xi"></span><span class="xb"></span></div>';
          row = { el, n: el.querySelector('.xn'), d: el.querySelector('.xd'), p: el.querySelector('.xp'), i: el.querySelector('.xi'), b: el.querySelector('.xb'), btn: '' };
          rows.set(x, row);
        }
        const active = FX.ACTIVE.has(x.state);
        row.n.textContent = x.name;
        row.d.textContent = (x.dir === 'send' ? '↑ 发送给 ' : '↓ 来自 ') + x.peer;
        row.p.value = x.size ? Math.min(1000, Math.round(x.done / x.size * 1000)) : (x.state === 'done' ? 1000 : 0);
        row.p.className = 'xp ' + x.state;
        row.i.textContent = stateText(x);
        row.i.className = 'xi ' + (x.state === 'failed' ? 'bad' : x.state === 'done' ? 'ok' : 'muted');
        const want = active ? 'cancel' : (x.state === 'done' && x.dir === 'recv' ? 'show' : '');
        if (row.btn !== want) {
          row.btn = want; row.b.innerHTML = '';
          if (want) {
            const b = document.createElement('button'); b.textContent = want === 'cancel' ? '取消' : '在文件夹中显示';
            b.onclick = want === 'cancel' ? () => cancelX(x) : () => ipcRenderer.send('show-item', x.saved);
            row.b.appendChild(b);
          }
        }
      }
      for (const [x, row] of [...rows]) if (!xfers.includes(x)) { row.el.remove(); rows.delete(x); }   // 移除已被清除的行
      let i = 0;                                                                                          // 按 xfers 的顺序排列
      for (const x of xfers) { const el = rows.get(x).el; if (box.children[i] !== el) box.insertBefore(el, box.children[i] || null); i++; }
    }
    function cancelX(x) {
      const c = x.ctl; if (!c) return;
      c.cancelled = true;
      if (c.sock) { try { c.sock.destroy(); } catch {} }
      for (const o of xfers) if (o.ctl === c && FX.ACTIVE.has(o.state)) { o.state = 'cancelled'; o.msg = '已取消'; }
      render();
    }

    /* 发送 */
    async function startSend(host, port, pin, peerName, files) {
      const ctl = { cancelled: false, sock: null, phase: 'idle', lastAct: Date.now() };
      const items = files.map(p => ({ path: p, x: null }));
      for (let i = items.length - 1; i >= 0; i--) items[i].x = newX({ dir: 'send', name: path.basename(items[i].path), peer: peerName, ctl });   // 倒序创建，列表里第一个文件在最上面
      activity(+1);
      try {
        let s;
        try { s = await connectTo(host, port, pin, 'file'); }
        catch (e) { for (const it of items) { it.x.state = 'failed'; it.x.msg = '连接失败：' + e.message; } render(); return; }
        const sock = s.detach(); ctl.sock = sock;
        if (ctl.cancelled) { sock.destroy(); for (const it of items) { it.x.state = 'cancelled'; it.x.msg = '已取消'; } render(); return; }
        setStatus('正在向「' + peerName + '」发送 ' + files.length + ' 个文件');
        await FX.sendFiles(sock, items, ctl, hooks);
      } finally { activity(-1); }
    }

    /* 接收（由 renderer.js 在对方以 mode=file 连入并认证后调用） */
    FX.onIncoming = function (s) {
      const sock = s.detach();
      const ctl = { cancelled: false, sock, phase: 'idle', lastAct: Date.now() };
      activity(+1);
      setStatus('「' + s.peerName + '」正在向本机发送文件');
      FX.receiveLoop(sock, {
        dir: () => recvDir,
        newItem: info => newX({ dir: 'recv', name: info.name, size: info.size, peer: s.peerName, ctl }),
        hooks
      }, ctl).finally(() => activity(-1));
    };

    /* 选目标设备 + PIN，然后发送 */
    async function chooseTargetAndSend(files, preferred) {
      if (!files.length) return;
      if (!$('#modal').hidden) return;
      let p = preferred;
      if (!p) {
        const list = [...peers.values()];
        if (list.length === 1) p = list[0];
        else if (list.length > 1) {
          const r = await ask('发送到哪台设备？', files.length + ' 个文件', { buttons: list.map(v => v.name + '（' + v.ip + '）').concat(['取消']) });
          if (r.i >= list.length) return; p = list[r.i];
        } else {
          const ip = $('#ip').value.trim();
          if (!ip) { setStatus('没有发现设备：请在上方“附近的设备”处输入对方 IP，再发送文件', true); return; }
          p = { id: 'ip_' + ip, name: ip, ip, port: PORT };
        }
      }
      const r = await ask('发送文件到 ' + p.name, files.length + ' 个文件 · 请输入对方屏幕上显示的 6 位 PIN', {
        input: true, value: LS.get('pin_' + p.id, ''), placeholder: 'PIN', buttons: ['发送', '取消'] });
      if (r.i !== 0 || !r.v) return;
      LS.set('pin_' + p.id, r.v);
      startSend(p.ip, p.port, r.v, p.name, files);
    }
    FX.pickAndSend = async function (peer) {
      const files = await ipcRenderer.invoke('pick-files');
      if (files && files.length) chooseTargetAndSend(files, peer);
    };

    /* 拖放 */
    let dragDepth = 0;
    const drop = $('#drop');
    window.addEventListener('dragenter', e => { e.preventDefault(); dragDepth++; drop.classList.add('hot'); });
    window.addEventListener('dragover', e => e.preventDefault());
    window.addEventListener('dragleave', () => { dragDepth = Math.max(0, dragDepth - 1); if (!dragDepth) drop.classList.remove('hot'); });
    window.addEventListener('drop', e => {
      e.preventDefault(); dragDepth = 0; drop.classList.remove('hot');
      const files = [...(e.dataTransfer ? e.dataTransfer.files : [])].map(f => { try { return webUtils.getPathForFile(f) || f.path; } catch { return f.path; } }).filter(Boolean);
      chooseTargetAndSend(files, null);
    });

    $('#pickFiles').onclick = () => FX.pickAndSend(null);
    $('#manualSend').onclick = () => { const ip = $('#ip').value.trim(); if (!ip) { setStatus('请先在上面输入对方 IP', true); return; } ipcRenderer.invoke('pick-files').then(f => { if (f && f.length) chooseTargetAndSend(f, { id: 'ip_' + ip, name: ip, ip, port: PORT }); }); };
    $('#clearX').onclick = () => { for (let i = xfers.length - 1; i >= 0; i--) if (!FX.ACTIVE.has(xfers[i].state)) xfers.splice(i, 1); render(); };
    const showDir = () => { $('#recvDir').textContent = recvDir; };
    $('#openDir').onclick = () => { try { fs.mkdirSync(recvDir, { recursive: true }); } catch {} ipcRenderer.send('open-folder', recvDir); };
    $('#chgDir').onclick = async () => { const d = await ipcRenderer.invoke('pick-folder', recvDir); if (d) { recvDir = d; LS.set('recvDir', d); showDir(); } };
    showDir(); render();
  }
})();
