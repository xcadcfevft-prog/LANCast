'use strict';
/* 瞬流握手协议 v2（Windows 端）—— 纯逻辑，不碰 DOM / socket，方便单元测试。
 * 与 android/.../Net.kt 的 Session.connect / acceptClient 逐项对应，规范见 docs/PROTOCOL.md 第 2 节：
 *   · CHALLENGE / HELLO / ACCEPT 里带 ver、id、caps
 *   · 服务端身份证明 proof = HMAC-SHA256(pin, "srv:" + 服务端nonce + ":" + 客户端cn)
 *   · 屏幕控制 ctl：pull 时客户端发 "req"，服务端在 ACCEPT 里回 true/false；push 时客户端发 "grant" 表示允许对方控制自己
 */
const crypto = require('crypto');

const VER = 2;
const CAPS = ['file', 'resume', 'push', 'pull', 'proof', 'ctl'];
const CN_RE = /^[0-9a-f]{16,64}$/;

const hmacHex = (key, msg) => crypto.createHmac('sha256', key).update(msg).digest('hex');
const proofHex = (pin, serverNonce, clientNonce) => hmacHex(pin, 'srv:' + serverNonce + ':' + clientNonce);
function constEq(a, b) {
  const x = Buffer.from(String(a), 'utf8'), y = Buffer.from(String(b), 'utf8');
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}
function parseCaps(a) { return Array.isArray(a) ? a.slice(0, 32).map(String) : []; }

/* ───────── 服务端 ───────── */
function buildChallenge(nonce, name, id) {
  return { nonce, name, platform: 'windows', ver: VER, id, caps: CAPS };
}
/* 校验 HELLO 里的 auth；通过则返回对方信息，否则返回 null */
function readHello(j, nonce, pin) {
  if (!constEq(j.auth || '', hmacHex(pin, nonce))) return null;
  const peerVer = Number.isInteger(j.ver) ? j.ver : 1;
  const cn = typeof j.cn === 'string' ? j.cn : '';
  return {
    peerVer,
    peerId: typeof j.id === 'string' ? j.id : '',
    peerCaps: parseCaps(j.caps),
    clientNonce: peerVer >= 2 && CN_RE.test(cn) ? cn : '',
    ctlReq: peerVer >= 2 && j.ctl === 'req',          // pull：对方请求控制本机
    ctlGrant: peerVer >= 2 && j.ctl === 'grant'       // push：对方允许本机控制它
  };
}
/* ACCEPT 正文。ctlReq 时必须回答「是否同意被控制」；对方是 v2 时附上身份证明。 */
function buildAccept({ ctlReq, ctlAllowed, clientNonce, nonce, pin }) {
  const j = { ok: true };
  if (ctlReq) j.ctl = !!ctlAllowed;
  if (clientNonce) { j.ver = VER; j.proof = proofHex(pin, nonce, clientNonce); }
  return j;
}

/* ───────── 客户端 ───────── */
function buildHello({ name, id, mode, pin, nonce, ctl, cn }) {
  const h = { ver: VER, name, platform: 'windows', mode, id, caps: CAPS, cn, auth: hmacHex(pin, nonce) };
  if (ctl) h.ctl = ctl;                 // "req" | "grant"
  return h;
}
/* 校验服务端的 ACCEPT。requiresProof：本机配对记录里这台设备已被确认为 v2（防降级）。 */
function checkAccept({ challenge, accept, pin, cn, requiresProof, ctl }) {
  const cv = Number.isInteger(challenge.ver) ? challenge.ver : 1;
  const proofOk = constEq(accept.proof || '', proofHex(pin, challenge.nonce, cn));
  if ((cv >= 2 || requiresProof) && !proofOk) {
    return { ok: false, error: '对方未通过身份校验，已断开（可能不是你要连接的设备）' };
  }
  const av = Number.isInteger(accept.ver) ? accept.ver : 1;
  return {
    ok: true,
    proofOk,
    peerVer: proofOk ? Math.max(cv, av) : 1,
    canControl: proofOk && ctl === 'req' && accept.ctl === true
  };
}

module.exports = { VER, CAPS, CN_RE, hmacHex, proofHex, constEq, parseCaps, buildChallenge, readHello, buildAccept, buildHello, checkAccept };
