// 悬浮「磁力解析」面板（不改动现有布局）
// 安全约定：种子里的名字/路径是不可信输入，界面里一律用 textContent，绝不拼进 innerHTML。
(() => {
  const { resolveMagnet, extractMagnets, parseTorrent, fmtSize } = require('./magnet');
  const { clipboard, shell, ipcRenderer } = require('electron');
  const fs = require('fs'), path = require('path'), os = require('os');
  const cacheDir = (() => { try { return path.join(ipcRenderer.sendSync('get-path', 'userData'), 'magnet-cache'); } catch { return ''; } })();
  const LS = {
    get(k, d) { try { const v = localStorage.getItem(k); return v === null ? d : JSON.parse(v); } catch { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} }
  };

  const css = document.createElement('style');
  css.textContent = `
  #mg-btn{position:fixed;right:16px;bottom:16px;z-index:9998;padding:8px 16px;border:0;border-radius:18px;background:var(--accent,#0b6e8a);color:#fff;cursor:pointer;box-shadow:0 2px 10px #0003}
  #mg-box{position:fixed;right:16px;bottom:62px;width:480px;max-width:calc(100vw - 32px);max-height:80vh;z-index:9998;display:none;flex-direction:column;gap:8px;padding:12px;background:var(--panel,#f7f9fb);color:var(--ink,#1c2733);border:1px solid var(--line,#cbd4dd);border-radius:10px;box-shadow:0 8px 30px #0004}
  #mg-box.drag{outline:2px dashed var(--accent,#0b6e8a)}
  #mg-box textarea{width:100%;min-height:54px;max-height:120px;resize:vertical;padding:6px 8px;font:12.5px/1.4 Consolas,"Microsoft YaHei UI",monospace}
  #mg-top{display:flex;gap:8px;align-items:center}
  #mg-top .sp{flex:1;font-size:12px;color:var(--muted,#5d6b7a)}
  #mg-list{overflow:auto;display:flex;flex-direction:column;gap:8px;min-height:0}
  .mg-card{border:1px solid var(--line,#cbd4dd);border-radius:8px;background:#fff;padding:8px 10px;display:flex;flex-direction:column;gap:6px}
  .mg-t{font-weight:600;overflow-wrap:anywhere}
  .mg-s{font-size:12px;color:var(--muted,#5d6b7a);overflow-wrap:anywhere}
  .mg-s.err{color:var(--warn,#a85a05)}
  .mg-row{display:flex;gap:6px;flex-wrap:wrap;align-items:center}
  .mg-row button,#mg-box button{padding:3px 10px;font-size:12px}
  .mg-row input{flex:1;min-width:120px;padding:3px 8px;font-size:12px}
  .mg-files{max-height:230px;overflow:auto;border-top:1px solid var(--line,#cbd4dd);font-size:12px}
  .mg-f{display:flex;gap:10px;padding:2px 0;border-bottom:1px dotted #e3e9ee}
  .mg-f span:first-child{flex:1;min-width:0;overflow-wrap:anywhere}
  .mg-f span:last-child{white-space:nowrap;color:var(--muted,#5d6b7a);font-variant-numeric:tabular-nums}
  .mg-hist{display:flex;gap:6px;flex-wrap:wrap;font-size:12px}
  .mg-hist button{max-width:150px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}`;
  document.head.appendChild(css);

  const h = (tag, props = {}, ...kids) => {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(props)) { if (k === 'text') e.textContent = v; else if (k.startsWith('on')) e[k] = v; else e[k] = v; }
    for (const k of kids) if (k) e.append(k);
    return e;
  };
  const btn = h('button', { id: 'mg-btn', textContent: '磁力解析', title: '粘贴磁力链接，查看里面有哪些文件' });
  const input = h('textarea', { id: 'mg-in', placeholder: '粘贴 magnet:?xt=urn:btih:… （支持多条、迅雷链接、纯哈希，可拖入 .torrent 文件）', spellcheck: false });
  const go = h('button', { className: 'primary', textContent: '解析' });
  const hint = h('span', { className: 'sp' });
  const list = h('div', { id: 'mg-list' });
  const hist = h('div', { className: 'mg-hist' });
  const box = h('div', { id: 'mg-box' }, input, h('div', { id: 'mg-top' }, go, hint, h('button', { textContent: '清空', onclick: () => { list.textContent = ''; } })), hist, list);
  document.body.append(btn, box);

  /* ── 工具 ── */
  const copy = (txt, label) => { try { clipboard.writeText(txt); } catch {} flash(label + '已复制'); };
  let hintTimer = 0;
  const flash = msg => { hint.textContent = msg; clearTimeout(hintTimer); hintTimer = setTimeout(() => { hint.textContent = ''; }, 2500); };
  const safeFile = s => (String(s).replace(/[<>:"/\\|?*\u0000-\u001f]/g, '_').replace(/[. ]+$/, '').slice(0, 120) || 'torrent');
  function saveTorrent(r) {
    try {
      let dir = ''; try { dir = ipcRenderer.sendSync('get-path', 'downloads'); } catch {}
      dir = dir || path.join(os.homedir(), 'Downloads');
      fs.mkdirSync(dir, { recursive: true });
      let f = path.join(dir, safeFile(r.name) + '.torrent'), n = 1;
      while (fs.existsSync(f)) f = path.join(dir, `${safeFile(r.name)} (${n++}).torrent`);
      fs.writeFileSync(f, r.torrent); shell.showItemInFolder(f); flash('已保存到下载目录');
    } catch (e) { flash('保存失败：' + e.message); }
  }
  const pushHistory = r => {
    const a = LS.get('mg-hist', []).filter(x => x.hash !== r.hash);
    a.unshift({ hash: r.hash, name: r.name || r.hash, magnet: r.magnet }); LS.set('mg-hist', a.slice(0, 12)); renderHist();
  };
  function renderHist() {
    hist.textContent = '';
    const a = LS.get('mg-hist', []);
    if (!a.length) return;
    hist.append(h('span', { className: 'mg-s', textContent: '最近：' }));
    for (const x of a.slice(0, 6)) hist.append(h('button', { textContent: x.name, title: x.name, onclick: () => { input.value = x.magnet || ('magnet:?xt=urn:btih:' + x.hash); input.focus(); } }));
  }

  /* ── 结果卡片 ── */
  function renderFiles(r, wrap) {
    wrap.textContent = '';
    let sortBySize = false, q = '', limit = 200;
    const q1 = h('input', { placeholder: '过滤文件名…', oninput: () => { q = q1.value.trim().toLowerCase(); limit = 200; draw(); } });
    const sortBtn = h('button', { textContent: '按大小排序', onclick: () => { sortBySize = !sortBySize; sortBtn.textContent = sortBySize ? '按原顺序' : '按大小排序'; draw(); } });
    const area = h('div', { className: 'mg-files' });
    wrap.append(h('div', { className: 'mg-row' }, q1, sortBtn), area);
    function draw() {
      let fs_ = q ? r.files.filter(f => f.path.toLowerCase().includes(q)) : r.files.slice();
      if (sortBySize) fs_.sort((a, b) => b.size - a.size);
      area.textContent = '';
      for (const f of fs_.slice(0, limit)) area.append(h('div', { className: 'mg-f' }, h('span', { text: f.path }), h('span', { text: fmtSize(f.size) })));
      if (fs_.length > limit) area.append(h('button', { textContent: `显示更多（还有 ${fs_.length - limit} 个）`, onclick: () => { limit += 500; draw(); } }));
      if (!fs_.length) area.append(h('div', { className: 'mg-s', text: '没有匹配的文件' }));
    }
    draw();
  }
  function renderResult(card, r) {
    card.textContent = '';
    const files = h('div');
    card.append(
      h('div', { className: 'mg-t', text: r.name || r.hash }),
      h('div', { className: 'mg-s', text: `${fmtSize(r.total)} · ${r.fileCount} 个文件 · ${r.fromCache ? '来自缓存' : '用时 ' + (r.elapsedMs / 1000).toFixed(1) + ' 秒'}${r.private ? ' · 私有种子' : ''}` }),
      h('div', { className: 'mg-s', text: 'Hash: ' + r.hash }),
      h('div', { className: 'mg-row' },
        h('button', { textContent: '复制磁力', onclick: () => copy(r.magnet, '磁力链接') }),
        h('button', { textContent: '复制 Hash', onclick: () => copy(r.hash, 'Hash') }),
        h('button', { textContent: '复制文件列表', onclick: () => copy(r.files.map(f => `${fmtSize(f.size)}\t${f.path}`).join('\n'), '文件列表') }),
        h('button', { textContent: '保存 .torrent', onclick: () => saveTorrent(r) })),
      files);
    renderFiles(r, files);
  }

  /* ── 解析任务（最多同时 2 个） ── */
  const queue = []; let running = 0;
  function enqueue(link, card) { queue.push({ link, card }); pump(); }
  function pump() {
    while (running < 2 && queue.length) { const j = queue.shift(); running++; run(j.link, j.card).finally(() => { running--; pump(); }); }
  }
  async function run(link, card) {
    const ac = new AbortController();
    const status = h('div', { className: 'mg-s', text: '排队中…' });
    const cancel = h('button', { textContent: '取消', onclick: () => ac.abort() });
    card.textContent = '';
    card.append(h('div', { className: 'mg-t', text: link.name || link.hash }), status, h('div', { className: 'mg-row' }, cancel));
    const onProgress = s => {
      const sec = Math.round(s.elapsed / 1000);
      status.textContent = s.stage === 'searching' ? `正在寻找节点… DHT 回应 ${s.dhtReplies} · Tracker ${s.trackersOk}/${s.trackers} · ${sec}s`
        : s.stage === 'connecting' ? `发现 ${s.peers} 个节点，已尝试 ${s.tried}，连上 ${s.connected} · ${sec}s`
        : `获取元数据 ${s.pieces}/${s.totalPieces || '?'} 片 · ${s.withMeta} 个节点可用 · ${sec}s`;
    };
    status.textContent = '正在寻找节点…';
    const r = await resolveMagnet(link.magnet, { timeout: 60, onProgress, signal: ac.signal, cacheDir });
    if (r.files) { renderResult(card, r); pushHistory(r); return; }
    card.textContent = '';
    card.append(h('div', { className: 'mg-t', text: r.name || link.name || link.hash }),
      h('div', { className: 'mg-s err', text: '⚠ ' + r.error }),
      h('div', { className: 'mg-row' }, r.code === 'ABORTED' || r.code === 'INVALID' ? null : h('button', { textContent: '重试', onclick: () => enqueue(link, card) }),
        h('button', { textContent: '复制磁力', onclick: () => copy(link.magnet, '磁力链接') })));
  }

  function start() {
    const links = extractMagnets(input.value);
    if (!links.length) { flash(input.value.trim() ? '没有识别到有效的磁力链接' : '请先粘贴磁力链接'); return; }
    flash(links.length > 1 ? `识别到 ${links.length} 条链接，依次解析` : '');
    for (const link of links) { const card = h('div', { className: 'mg-card' }); list.prepend(card); enqueue(link, card); }
    input.value = '';
  }
  go.onclick = start;
  input.onkeydown = e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); start(); } };
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && box.style.display === 'flex') btn.onclick(); });

  btn.onclick = () => {
    const open = box.style.display !== 'flex';
    box.style.display = open ? 'flex' : 'none';
    if (!open) return;
    renderHist();
    if (!input.value.trim()) {
      let t = ''; try { t = clipboard.readText(); } catch {}
      if (t && extractMagnets(t).length) { input.value = t.trim(); flash('已从剪贴板读取，按回车解析'); }
    }
    input.focus();
  };

  /* ── 拖入 .torrent 直接看文件列表 ── */
  box.addEventListener('dragover', e => { e.preventDefault(); box.classList.add('drag'); });
  box.addEventListener('dragleave', () => box.classList.remove('drag'));
  box.addEventListener('drop', async e => {
    e.preventDefault(); box.classList.remove('drag');
    for (const f of e.dataTransfer.files) {
      if (!/\.torrent$/i.test(f.name)) continue;
      const card = h('div', { className: 'mg-card' }); list.prepend(card);
      try {
        const buf = Buffer.from(await f.arrayBuffer()), m = parseTorrent(buf);
        renderResult(card, { ...m, torrent: buf, fromCache: true, elapsedMs: 0, magnet: require('./magnet').buildMagnet({ hash: m.hash, name: m.name, trackers: m.trackers.slice(0, 8) }) });
      } catch (err) { card.append(h('div', { className: 'mg-s err', text: `${f.name}：${err.message}` })); }
    }
  });
})();
