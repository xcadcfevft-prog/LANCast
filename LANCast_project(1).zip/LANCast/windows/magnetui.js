// 悬浮「磁力」面板（不改动现有布局）
(() => {
  const { resolveMagnet } = require('./magnet');
  const css = document.createElement('style');
  css.textContent = `#mg-btn{position:fixed;right:16px;bottom:16px;z-index:9998;padding:8px 14px;border:0;border-radius:18px;background:#3b82f6;color:#fff;cursor:pointer}
  #mg-box{position:fixed;right:16px;bottom:60px;width:420px;max-height:70vh;z-index:9998;display:none;flex-direction:column;gap:8px;padding:12px;background:#1f2937;color:#e5e7eb;border-radius:10px;box-shadow:0 4px 20px #0006}
  #mg-box input{padding:6px;border-radius:6px;border:1px solid #4b5563;background:#111827;color:inherit}
  #mg-out{overflow:auto;font-size:12px;white-space:pre-wrap;word-break:break-all}`;
  document.head.appendChild(css);
  const btn = Object.assign(document.createElement('button'), { id: 'mg-btn', textContent: '磁力解析' });
  const box = document.createElement('div'); box.id = 'mg-box';
  box.innerHTML = '<input id="mg-in" placeholder="粘贴 magnet:?xt=urn:btih:..."><button id="mg-go">解析</button><div id="mg-out"></div>';
  document.body.append(btn, box);
  btn.onclick = () => { box.style.display = box.style.display === 'flex' ? 'none' : 'flex'; };
  const fmt = n => n > 1e9 ? (n / 1e9).toFixed(2) + ' GB' : n > 1e6 ? (n / 1e6).toFixed(1) + ' MB' : (n / 1e3).toFixed(0) + ' KB';
  document.getElementById('mg-go').onclick = async () => {
    const out = document.getElementById('mg-out'); out.textContent = '解析中…(最长约 60 秒)';
    const r = await resolveMagnet(document.getElementById('mg-in').value.trim());
    if (r.error && !r.hash) { out.textContent = '错误: ' + r.error; return; }
    out.textContent = `名称: ${r.name || '-'}\nHash: ${r.hash}\nTracker: ${r.trackers.length}` +
      (r.files ? `\n总大小: ${fmt(r.total)}  文件数: ${r.files.length}\n` + r.files.map(f => `${fmt(f.size)}  ${f.path}`).join('\n')
               : `\n⚠ ${r.error}`);
  };
})();
