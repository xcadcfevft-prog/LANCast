// 悬浮「磁力」面板：解析 → 勾选下载 / 边下边播 → 下载管理（不改动现有布局）
// 安全约定：种子里的名字/路径是不可信输入，界面里一律用 textContent，绝不拼进 innerHTML。
(() => {
  const { resolveMagnet, extractMagnets, parseTorrent, buildMagnet, fmtSize } = require('./magnet');
  const { BtManager, mediaKind } = require('./btdl');
  const { clipboard, shell, ipcRenderer } = require('electron');
  const fs = require('fs'), path = require('path'), os = require('os');
  const sysPath = n => { try { return ipcRenderer.sendSync('get-path', n) || ''; } catch { return ''; } };
  const userData = sysPath('userData') || path.join(os.homedir(), '.lancast');
  const defaultDir = path.join(sysPath('downloads') || path.join(os.homedir(), 'Downloads'), '瞬流磁力');
  const cacheDir = path.join(userData, 'magnet-cache');
  const LS = {
    get(k, d) { try { const v = localStorage.getItem(k); return v === null ? d : JSON.parse(v); } catch { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} }
  };
  let mgr = null;
  try { mgr = new BtManager({ dataDir: path.join(userData, 'bt'), defaultDir }); mgr.load(); } catch (e) { console.error('[magnet] 下载管理器启动失败', e); }
  window.addEventListener('beforeunload', () => { try { mgr && mgr.destroy(); } catch {} });
  const saveDir = () => LS.get('mg-dir', defaultDir);

  const css = document.createElement('style');
  css.textContent = `
  #mg-btn{position:fixed;right:16px;bottom:16px;z-index:9998;padding:8px 16px;border:0;border-radius:18px;background:var(--accent,#0b6e8a);color:#fff;cursor:pointer;box-shadow:0 2px 10px #0003}
  #mg-box{position:fixed;right:16px;bottom:62px;width:520px;max-width:calc(100vw - 32px);max-height:82vh;z-index:9998;display:none;flex-direction:column;gap:8px;padding:12px;background:var(--panel,#f7f9fb);color:var(--ink,#1c2733);border:1px solid var(--line,#cbd4dd);border-radius:10px;box-shadow:0 8px 30px #0004}
  #mg-box.drag{outline:2px dashed var(--accent,#0b6e8a)}
  #mg-box textarea{width:100%;min-height:54px;max-height:120px;resize:vertical;padding:6px 8px;font:12.5px/1.4 Consolas,"Microsoft YaHei UI",monospace}
  #mg-tabs{display:flex;gap:6px}#mg-tabs button.on{background:var(--accent,#0b6e8a);color:#fff;border-color:var(--accent,#0b6e8a)}
  .mg-view{display:flex;flex-direction:column;gap:8px;min-height:0}
  #mg-top{display:flex;gap:8px;align-items:center}
  #mg-top .sp{flex:1;font-size:12px;color:var(--muted,#5d6b7a)}
  #mg-list,#mg-dl{overflow:auto;display:flex;flex-direction:column;gap:8px;min-height:0}
  .mg-card{border:1px solid var(--line,#cbd4dd);border-radius:8px;background:#fff;padding:8px 10px;display:flex;flex-direction:column;gap:6px}
  .mg-t{font-weight:600;overflow-wrap:anywhere}
  .mg-s{font-size:12px;color:var(--muted,#5d6b7a);overflow-wrap:anywhere}
  .mg-s.err{color:var(--warn,#a85a05)}
  .mg-row{display:flex;gap:6px;flex-wrap:wrap;align-items:center}
  #mg-box button{padding:3px 10px;font-size:12px}
  .mg-row input[type=text],.mg-row input:not([type]){flex:1;min-width:120px;padding:3px 8px;font-size:12px}
  .mg-files{max-height:230px;overflow:auto;border-top:1px solid var(--line,#cbd4dd);font-size:12px}
  .mg-f{display:flex;gap:8px;padding:2px 0;border-bottom:1px dotted #e3e9ee;align-items:center}
  .mg-f .n{flex:1;min-width:0;overflow-wrap:anywhere}
  .mg-f .z{white-space:nowrap;color:var(--muted,#5d6b7a);font-variant-numeric:tabular-nums}
  .mg-f button{padding:0 6px!important}
  .mg-card progress{width:100%;height:8px;accent-color:var(--accent,#0b6e8a)}
  .mg-hist{display:flex;gap:6px;flex-wrap:wrap;font-size:12px}
  .mg-hist button{max-width:150px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  #mg-player{position:fixed;inset:0;z-index:10000;background:#000;display:none;flex-direction:column}
  #mg-player video{flex:1;min-height:0;width:100%;background:#000}
  #mg-pbar{display:flex;gap:8px;align-items:center;padding:8px 12px;background:#111c;color:#dfe8ee;font-size:12.5px}
  #mg-pbar .t{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
  #mg-pbar button{background:transparent;color:#e8eef3;border-color:#fff4;padding:3px 10px}`;
  document.head.appendChild(css);

  const h = (tag, props = {}, ...kids) => {
    const e = document.createElement(tag);
    for (const [k, v] of Object.entries(props)) { if (k === 'text') e.textContent = v; else e[k] = v; }
    for (const k of kids) if (k) e.append(k);
    return e;
  };
  const btn = h('button', { id: 'mg-btn', textContent: '磁力', title: '磁力解析 / 下载 / 边下边播' });
  const input = h('textarea', { id: 'mg-in', placeholder: '粘贴 magnet:?xt=urn:btih:… （支持多条、迅雷链接、纯哈希，可拖入 .torrent 文件）', spellcheck: false });
  const go = h('button', { className: 'primary', textContent: '解析' });
  const hint = h('span', { className: 'sp' });
  const list = h('div', { id: 'mg-list' });
  const hist = h('div', { className: 'mg-hist' });
  const dirLine = h('span', { className: 'mg-s' });
  const tabParse = h('button', { textContent: '解析', className: 'on', onclick: () => tab('parse') });
  const tabDl = h('button', { textContent: '下载', onclick: () => tab('dl') });
  const dl = h('div', { id: 'mg-dl' });
  const viewParse = h('div', { className: 'mg-view' }, input,
    h('div', { id: 'mg-top' }, go, hint, h('button', { textContent: '清空', onclick: () => { list.textContent = ''; } })),
    h('div', { className: 'mg-row' }, dirLine, h('button', { textContent: '更改保存位置', onclick: async () => { const d = await ipcRenderer.invoke('pick-folder', saveDir()); if (d) { LS.set('mg-dir', d); showDir(); } } })),
    hist, list);
  const viewDl = h('div', { className: 'mg-view' }, dl);
  viewDl.style.display = 'none';
  const box = h('div', { id: 'mg-box' }, h('div', { id: 'mg-tabs' }, tabParse, tabDl), viewParse, viewDl);
  document.body.append(btn, box);
  const showDir = () => { dirLine.textContent = '保存到：' + saveDir(); };
  function tab(n) {
    viewParse.style.display = n === 'parse' ? 'flex' : 'none'; viewDl.style.display = n === 'dl' ? 'flex' : 'none';
    tabParse.className = n === 'parse' ? 'on' : ''; tabDl.className = n === 'dl' ? 'on' : '';
    if (n === 'dl') refreshDl(true);
  }

  /* ── 工具 ── */
  const copy = (txt, label) => { try { clipboard.writeText(txt); } catch {} flash(label + '已复制'); };
  let hintTimer = 0;
  const flash = msg => { hint.textContent = msg; clearTimeout(hintTimer); hintTimer = setTimeout(() => { hint.textContent = ''; }, 3000); };
  const safeFile = s => (String(s).replace(/[<>:"/\\|?*\u0000-\u001f]/g, '_').replace(/[. ]+$/, '').slice(0, 120) || 'torrent');
  const spd = n => fmtSize(n) + '/s';
  function saveTorrent(r) {
    try {
      const dir = saveDir(); fs.mkdirSync(dir, { recursive: true });
      let f = path.join(dir, safeFile(r.name) + '.torrent'), n = 1;
      while (fs.existsSync(f)) f = path.join(dir, `${safeFile(r.name)} (${n++}).torrent`);
      fs.writeFileSync(f, r.torrent); shell.showItemInFolder(f); flash('已保存 .torrent');
    } catch (e) { flash('保存失败：' + e.message); }
  }
  const pushHistory = r => {
    const a = LS.get('mg-hist', []).filter(x => x.hash !== r.hash);
    a.unshift({ hash: r.hash, name: r.name || r.hash, magnet: r.magnet }); LS.set('mg-hist', a.slice(0, 12)); renderHist();
  };
  function renderHist() {
    hist.textContent = '';
    const a = LS.get('mg-hist', []);
    if (!a.length) return;
    hist.append(h('span', { className: 'mg-s', textContent: '最近：' }));
    for (const x of a.slice(0, 6)) hist.append(h('button', { textContent: x.name, title: x.name, onclick: () => { input.value = x.magnet || ('magnet:?xt=urn:btih:' + x.hash); input.focus(); } }));
  }

  /* ── 下载 / 播放 ── */
  function download(r, indexes) {
    if (!mgr) { flash('下载引擎未启动'); return; }
    try {
      const t = mgr.add({ torrent: r.torrent, dir: saveDir(), selected: indexes && indexes.length ? indexes : null });
      flash(`已加入下载：${t.name}`); tab('dl');
    } catch (e) { flash('无法下载：' + e.message); }
  }
  const biggestMedia = files => files.filter(f => mediaKind(f.path)).sort((a, b) => b.size - a.size)[0];
  async function play(r, fileIndex) {
    if (!mgr) { flash('下载引擎未启动'); return; }
    try {
      if (!mgr.get(r.hash)) mgr.add({ torrent: r.torrent, dir: saveDir(), selected: [fileIndex] });
      const f = mgr.get(r.hash).files[fileIndex];
      const url = await mgr.streamUrl(r.hash, fileIndex);
      openPlayer(r.hash, url, f.path.split('/').pop());
    } catch (e) { flash('无法播放：' + e.message); }
  }

  /* ── 结果卡片 ── */
  function renderFiles(r, wrap, onPick) {
    wrap.textContent = '';
    let sortBySize = false, q = '', limit = 200;
    const q1 = h('input', { placeholder: '过滤文件名…', oninput: () => { q = q1.value.trim().toLowerCase(); limit = 200; draw(); } });
    const sortBtn = h('button', { textContent: '按大小排序', onclick: () => { sortBySize = !sortBySize; sortBtn.textContent = sortBySize ? '按原顺序' : '按大小排序'; draw(); } });
    const area = h('div', { className: 'mg-files' });
    wrap.append(h('div', { className: 'mg-row' }, q1, sortBtn), area);
    function draw() {
      let fs_ = q ? r.files.filter(f => f.path.toLowerCase().includes(q)) : r.files.slice();
      if (sortBySize) fs_.sort((a, b) => b.size - a.size);
      area.textContent = '';
      for (const f of fs_.slice(0, limit)) {
        const cb = h('input', { type: 'checkbox', checked: onPick.set.has(f.index), onchange: () => { cb.checked ? onPick.set.add(f.index) : onPick.set.delete(f.index); onPick.update(); } });
        area.append(h('div', { className: 'mg-f' }, cb, h('span', { className: 'n', text: f.path }), h('span', { className: 'z', text: fmtSize(f.size) }),
          mediaKind(f.path) ? h('button', { textContent: '▶', title: '边下边播', onclick: () => play(r, f.index) }) : null));
      }
      if (fs_.length > limit) area.append(h('button', { textContent: `显示更多（还有 ${fs_.length - limit} 个）`, onclick: () => { limit += 500; draw(); } }));
      if (!fs_.length) area.append(h('div', { className: 'mg-s', text: '没有匹配的文件' }));
    }
    draw();
  }
  function renderResult(card, r) {
    card.textContent = '';
    const files = h('div'), pick = { set: new Set(), update: () => { dlSel.textContent = `下载选中（${pick.set.size}）`; dlSel.disabled = !pick.set.size; } };
    const dlSel = h('button', { textContent: '下载选中（0）', disabled: true, onclick: () => download(r, [...pick.set]) });
    const media = biggestMedia(r.files);
    card.append(
      h('div', { className: 'mg-t', text: r.name || r.hash }),
      h('div', { className: 'mg-s', text: `${fmtSize(r.total)} · ${r.fileCount} 个文件 · ${r.fromCache ? '来自缓存' : '用时 ' + (r.elapsedMs / 1000).toFixed(1) + ' 秒'}${r.private ? ' · 私有种子' : ''}` }),
      h('div', { className: 'mg-s', text: 'Hash: ' + r.hash }),
      h('div', { className: 'mg-row' },
        media ? h('button', { className: 'primary', textContent: '▶ 边下边播', title: media.path, onclick: () => play(r, media.index) }) : null,
        h('button', { className: media ? '' : 'primary', textContent: '下载全部', onclick: () => download(r, null) }), dlSel),
      h('div', { className: 'mg-row' },
        h('button', { textContent: '复制磁力', onclick: () => copy(r.magnet, '磁力链接') }),
        h('button', { textContent: '复制 Hash', onclick: () => copy(r.hash, 'Hash') }),
        h('button', { textContent: '复制文件列表', onclick: () => copy(r.files.map(f => `${fmtSize(f.size)}\t${f.path}`).join('\n'), '文件列表') }),
        h('button', { textContent: '保存 .torrent', onclick: () => saveTorrent(r) })),
      files);
    renderFiles(r, files, pick);
  }

  /* ── 解析任务（最多同时 2 个） ── */
  const queue = []; let running = 0;
  function enqueue(link, card) { queue.push({ link, card }); pump(); }
  function pump() {
    while (running < 2 && queue.length) { const j = queue.shift(); running++; run(j.link, j.card).finally(() => { running--; pump(); }); }
  }
  async function run(link, card) {
    const ac = new AbortController();
    const status = h('div', { className: 'mg-s', text: '排队中…' });
    const cancel = h('button', { textContent: '取消', onclick: () => ac.abort() });
    card.textContent = '';
    card.append(h('div', { className: 'mg-t', text: link.name || link.hash }), status, h('div', { className: 'mg-row' }, cancel));
    const onProgress = s => {
      const sec = Math.round(s.elapsed / 1000);
      status.textContent = s.stage === 'searching' ? `正在寻找节点… DHT 回应 ${s.dhtReplies} · Tracker ${s.trackersOk}/${s.trackers} · ${sec}s`
        : s.stage === 'connecting' ? `发现 ${s.peers} 个节点，已尝试 ${s.tried}，连上 ${s.connected} · ${sec}s`
        : `获取元数据 ${s.pieces}/${s.totalPieces || '?'} 片 · ${s.withMeta} 个节点可用 · ${sec}s`;
    };
    status.textContent = '正在寻找节点…';
    const r = await resolveMagnet(link.magnet, { timeout: 60, onProgress, signal: ac.signal, cacheDir });
    if (r.files) { renderResult(card, r); pushHistory(r); return; }
    card.textContent = '';
    card.append(h('div', { className: 'mg-t', text: r.name || link.name || link.hash }),
      h('div', { className: 'mg-s err', text: '⚠ ' + r.error }),
      h('div', { className: 'mg-row' }, r.code === 'ABORTED' || r.code === 'INVALID' ? null : h('button', { textContent: '重试', onclick: () => enqueue(link, card) }),
        h('button', { textContent: '复制磁力', onclick: () => copy(link.magnet, '磁力链接') })));
  }
  function start() {
    const links = extractMagnets(input.value);
    if (!links.length) { flash(input.value.trim() ? '没有识别到有效的磁力链接' : '请先粘贴磁力链接'); return; }
    flash(links.length > 1 ? `识别到 ${links.length} 条链接，依次解析` : '');
    for (const link of links) { const card = h('div', { className: 'mg-card' }); list.prepend(card); enqueue(link, card); }
    input.value = '';
  }
  go.onclick = start;
  input.onkeydown = e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); start(); } };

  /* ── 下载管理 ── */
  const cards = new Map();
  const stateText = s => {
    const pct = Math.floor(s.progress * 100);
    if (s.state === 'checking') return `正在校验已有文件 ${Math.floor(s.checked * 100)}%`;
    if (s.state === 'error') return '出错：' + s.error;
    if (s.state === 'paused') return `已暂停 · ${pct}% · ${fmtSize(s.doneBytes)} / ${fmtSize(s.wantedBytes)}`;
    if (s.state === 'seeding') return `已完成 · ${fmtSize(s.wantedBytes)}`;
    const eta = s.eta >= 0 ? ` · 剩余 ${s.eta >= 3600 ? Math.floor(s.eta / 3600) + ' 小时 ' + Math.floor(s.eta % 3600 / 60) + ' 分' : s.eta >= 60 ? Math.floor(s.eta / 60) + ' 分 ' + (s.eta % 60) + ' 秒' : s.eta + ' 秒'}` : '';
    return `${pct}% · ${fmtSize(s.doneBytes)} / ${fmtSize(s.wantedBytes)} · ↓ ${spd(s.speedDown)} ↑ ${spd(s.speedUp)} · ${s.peers} 个节点${s.peers ? '' : '（正在寻找…）'}${eta}${s.streaming ? ' · 播放中' : ''}`;
  };
  function makeTaskCard(hash) {
    const t = () => mgr.get(hash);
    const nameEl = h('div', { className: 'mg-t' }), info = h('div', { className: 'mg-s' }), bar = h('progress', { max: 1, value: 0 });
    const filesBox = h('div'), delRow = h('div', { className: 'mg-row' });
    delRow.style.display = 'none';
    let rows = null;
    const pauseBtn = h('button', { onclick: () => { const s = t().status(); s.state === 'paused' || s.state === 'error' ? mgr.resume(hash) : mgr.pause(hash); refreshDl(); } });
    const playBtn = h('button', { className: 'primary', textContent: '▶ 播放', onclick: () => {
      const f = biggestMedia(t().files); if (!f) { flash('这个任务里没有可播放的音视频文件'); return; }
      play({ hash, torrent: null }, f.index);
    } });
    const filesBtn = h('button', { textContent: '文件', onclick: () => { filesBox.style.display = filesBox.style.display === 'none' ? 'block' : 'none'; rows = null; refreshDl(); } });
    filesBox.style.display = 'none';
    const openBtn = h('button', { textContent: '打开目录', onclick: () => { const x = t(); const f = x.files.find(f => fs.existsSync(f.abs)); f ? shell.showItemInFolder(f.abs) : shell.openPath(x.dir); } });
    const delBtn = h('button', { textContent: '删除', onclick: () => { delRow.style.display = delRow.style.display === 'none' ? 'flex' : 'none'; } });
    delRow.append(h('span', { className: 'mg-s', text: '确定删除？' }),
      h('button', { textContent: '仅移除任务', onclick: () => { mgr.remove(hash, false); refreshDl(); } }),
      h('button', { className: 'danger', textContent: '连同已下载文件一起删除', onclick: () => { mgr.remove(hash, true); refreshDl(); } }),
      h('button', { textContent: '取消', onclick: () => { delRow.style.display = 'none'; } }));
    const el = h('div', { className: 'mg-card' }, nameEl, bar, info, h('div', { className: 'mg-row' }, pauseBtn, playBtn, filesBtn, openBtn, delBtn), delRow, filesBox);
    const update = () => {
      const x = t(); if (!x) return;
      const s = x.status(filesBox.style.display !== 'none');
      nameEl.textContent = s.name; info.textContent = stateText(s); bar.value = s.progress;
      pauseBtn.textContent = s.state === 'paused' || s.state === 'error' ? '继续' : '暂停';
      playBtn.style.display = biggestMedia(x.files) ? '' : 'none';
      if (s.files) {
        if (!rows) {
          filesBox.textContent = ''; rows = [];
          for (const f of s.files) {
            const cb = h('input', { type: 'checkbox', checked: f.selected, onchange: () => { const sel = new Set(x.selectedIndexes()); cb.checked ? sel.add(f.index) : sel.delete(f.index); x.setSelected([...sel]); } });
            const z = h('span', { className: 'z' });
            filesBox.append(h('div', { className: 'mg-f' }, cb, h('span', { className: 'n', text: f.path }), z, mediaKind(f.path) ? h('button', { textContent: '▶', onclick: () => play({ hash, torrent: null }, f.index) }) : null));
            rows.push({ cb, z });
          }
        }
        s.files.forEach((f, i) => { rows[i].z.textContent = `${fmtSize(f.done)} / ${fmtSize(f.size)}`; rows[i].cb.checked = f.selected; });
      }
    };
    return { el, update };
  }
  let lastCount = -1;
  function refreshDl(force) {
    if (!mgr) return;
    const hashes = new Set(mgr.list().map(s => s.hash));
    if (hashes.size !== lastCount) { lastCount = hashes.size; tabDl.textContent = hashes.size ? `下载（${hashes.size}）` : '下载'; }
    if (viewDl.style.display === 'none' && !force) return;
    for (const [hash, c] of cards) if (!hashes.has(hash)) { c.el.remove(); cards.delete(hash); }
    for (const hash of hashes) {
      let c = cards.get(hash);
      if (!c) { c = makeTaskCard(hash); cards.set(hash, c); dl.prepend(c.el); }
      c.update();
    }
    if (!hashes.size && !dl.querySelector('.mg-empty')) dl.append(h('div', { className: 'mg-s mg-empty', text: '还没有下载任务。解析磁力后点「▶ 边下边播」或「下载」。' }));
    if (hashes.size) { const e = dl.querySelector('.mg-empty'); if (e) e.remove(); }
  }
  setInterval(() => { try { refreshDl(); } catch {} }, 1000);
  if (mgr) mgr.on('done', hash => { const t = mgr.get(hash); if (t) flash(`下载完成：${t.name}`); });

  /* ── 内置播放器 ── */
  let player = null;
  function openPlayer(hash, url, title) {
    if (!player) {
      const video = h('video', { controls: true, autoplay: true });
      const t = h('span', { className: 't' }), info = h('span');
      const m3u = () => { const f = path.join(os.tmpdir(), 'lancast-stream.m3u'); fs.writeFileSync(f, `#EXTM3U\n#EXTINF:-1,${player.title.replace(/[\r\n]/g, ' ')}\n${player.url}\n`); return f; };
      const bar = h('div', { id: 'mg-pbar' }, t, info,
        h('button', { textContent: '外部播放器', title: '用 PotPlayer / VLC 等打开（支持更多编码）', onclick: async () => { const e = await shell.openPath(m3u()); if (e) { clipboard.writeText(player.url); info.textContent = '没有可用的外部播放器，已复制地址，可粘贴到播放器的「打开 URL」里'; } } }),
        h('button', { textContent: '复制地址', onclick: () => { clipboard.writeText(player.url); info.textContent = '地址已复制'; } }),
        h('button', { textContent: '关闭 (Esc)', onclick: () => closePlayer() }));
      const el = h('div', { id: 'mg-player' }, bar, video);
      video.onerror = () => { info.textContent = '内置播放器无法解码该文件（常见于 HEVC / AC3 / DTS），请点「外部播放器」'; };
      document.body.append(el);
      player = { el, video, t, info, hash, url, title, timer: 0 };
    }
    player.hash = hash; player.url = url; player.title = title; player.t.textContent = title; player.info.textContent = '准备中…';
    player.el.style.display = 'flex'; player.video.src = url; player.video.play().catch(() => {});
    clearInterval(player.timer);
    player.timer = setInterval(() => {
      const x = mgr && mgr.get(hash); if (!x) return;
      const s = x.status(), v = player.video;
      if (player.info.textContent.startsWith('内置播放器') || player.info.textContent.startsWith('没有可用')) return;
      player.info.textContent = `${v.readyState < 3 && !v.paused ? '缓冲中… · ' : ''}已下载 ${Math.floor(s.progress * 100)}% · ↓ ${spd(s.speedDown)} · ${s.peers} 个节点`;
    }, 1000);
  }
  function closePlayer() {
    if (!player) return;
    clearInterval(player.timer); player.video.pause(); player.video.removeAttribute('src'); player.video.load(); player.el.style.display = 'none';
  }
  document.addEventListener('keydown', e => {
    if (e.key !== 'Escape') return;
    if (player && player.el.style.display === 'flex') closePlayer();
    else if (box.style.display === 'flex') btn.onclick();
  });

  btn.onclick = () => {
    const open = box.style.display !== 'flex';
    box.style.display = open ? 'flex' : 'none';
    if (!open) return;
    renderHist(); showDir(); refreshDl(true);
    if (!input.value.trim()) {
      let t = ''; try { t = clipboard.readText(); } catch {}
      if (t && extractMagnets(t).length) { input.value = t.trim(); flash('已从剪贴板读取，按回车解析'); }
    }
    input.focus();
  };

  /* ── 拖入 .torrent 直接看文件列表 / 下载 ── */
  box.addEventListener('dragover', e => { e.preventDefault(); box.classList.add('drag'); });
  box.addEventListener('dragleave', () => box.classList.remove('drag'));
  box.addEventListener('drop', async e => {
    e.preventDefault(); box.classList.remove('drag'); tab('parse');
    for (const f of e.dataTransfer.files) {
      if (!/\.torrent$/i.test(f.name)) continue;
      const card = h('div', { className: 'mg-card' }); list.prepend(card);
      try {
        const buf = Buffer.from(await f.arrayBuffer()), m = parseTorrent(buf);
        renderResult(card, { ...m, torrent: buf, fromCache: true, elapsedMs: 0, magnet: buildMagnet({ hash: m.hash, name: m.name, trackers: m.trackers.slice(0, 8) }) });
      } catch (err) { card.append(h('div', { className: 'mg-s err', text: `${f.name}：${err.message}` })); }
    }
  });
})();
