'use strict';
/* 网络地址工具（Windows 端）—— 纯逻辑，不碰 DOM / 文件；探测用的 connect 由调用方注入，方便测试。
 * 与 android/.../NetX.kt 一一对应（同样的分类、排序、配对链接格式）。规范见 docs/PROTOCOL.md 第 15 节。
 *
 * 为什么需要：原来只认「同一个 Wi-Fi 局域网」——网卡名里带 vpn / tailscale / zerotier 的会被当成垃圾网卡丢掉，
 * 设备发现只靠 UDP 广播，已配对设备也只记一个 IP。借助蒲公英（贝锐）、ZeroTier、Tailscale 等「虚拟局域网」
 * 跨网络互联时，这三件事都会出问题。现在：
 *   · 网卡分三类：lan（真实局域网）/ overlay（虚拟局域网 / VPN）/ junk（虚拟机、Docker、蓝牙等，只有别无选择时才用）；
 *     二维码、配对链接里放 lan + overlay 的地址
 *   · 已配对设备记录「主地址 + 备用地址列表」，连接时并行探测，哪个通就走哪个
 *   · 配对链接 lancast://pair?...（和二维码内容完全一样），不在一起时复制粘贴就能配对
 */

const V4 = /^(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})$/;
const JUNK_NIC = /vethernet|vmware|virtualbox|vbox|vmnet|hyper-v|wsl|docker|bluetooth|loopback|npcap|isatap|teredo|pseudo/i;
const OVERLAY_NIC = /pgy|oray|蒲公英|贝锐|zerotier|tailscale|wireguard|wintun|tap-windows|\btap\b|openvpn|hamachi|radmin|easytier|netbird|nebula|\bn2n\b|vpn|\btun\b|clash|mihomo|sing-box|meta/i;
const MAX_ADDRS = 6;

function toInt(ip) {
  const m = V4.exec(String(ip == null ? '' : ip).trim());
  if (!m) return null;
  let n = 0;
  for (let i = 1; i <= 4; i++) { const b = Number(m[i]); if (b > 255) return null; n = n * 256 + b; }
  return n;
}
function inRange(ip, base, prefix) {
  const a = toInt(ip), b = toInt(base);
  if (a === null || b === null) return false;
  if (prefix <= 0) return true;
  const mask = prefix >= 32 ? 0xFFFFFFFF : (0xFFFFFFFF << (32 - prefix)) >>> 0;
  return ((a & mask) >>> 0) === ((b & mask) >>> 0);
}
/* 能不能当作「别的设备可以连过来的本机地址」：排除回环、169.254、组播 / 保留、CLAT(192.0.0.x)、Clash 一类的假 IP 段(198.18/15) */
function usableV4(ip) {
  const n = toInt(ip);
  if (n === null) return false;
  const a = Math.floor(n / 16777216);
  if (a === 0 || a === 127 || a >= 224) return false;
  if (inRange(ip, '169.254.0.0', 16) || inRange(ip, '192.0.0.0', 29) || inRange(ip, '198.18.0.0', 15)) return false;
  return true;
}
/* 私有地址：10/8、172.16/12、192.168/16，以及 100.64/10（运营商 NAT / Tailscale） */
function isPrivate(ip) {
  return inRange(ip, '10.0.0.0', 8) || inRange(ip, '172.16.0.0', 12) || inRange(ip, '192.168.0.0', 16) || inRange(ip, '100.64.0.0', 10);
}
function prefixOfMask(mask) {
  let n = toInt(mask), c = 0;
  if (n === null) return 0;
  while (n) { c += n & 1; n = Math.floor(n / 2); }
  return c;
}
const uniq = list => [...new Set(list)];
function cleanIps(list, max = 8) {
  return uniq((Array.isArray(list) ? list : []).map(s => String(s == null ? '' : s).trim())).filter(s => usableV4(s)).slice(0, max);
}

/* ───────── 本机地址 ───────── */
function kindOfIface(name) { return JUNK_NIC.test(name) ? 'junk' : OVERLAY_NIC.test(name) ? 'overlay' : 'lan'; }
/* os.networkInterfaces() → [{ ip, prefix, iface, kind }]（只要可用的 IPv4） */
function localAddrs(ifs) {
  const out = [];
  for (const name of Object.keys(ifs || {})) for (const a of ifs[name] || []) {
    if (!(a.family === 'IPv4' || a.family === 4) || a.internal || !usableV4(a.address)) continue;
    let prefix = a.netmask ? prefixOfMask(a.netmask) : (a.cidr ? Number(String(a.cidr).split('/')[1]) : 24);
    if (!(prefix >= 1 && prefix <= 32)) prefix = 24;
    out.push({ ip: a.address, prefix, iface: name, kind: kindOfIface(name) });
  }
  return out;
}
const homeRank = ip => ip.startsWith('192.168.') ? 0 : ip.startsWith('10.') ? 1 : ip.startsWith('172.') ? 2 : isPrivate(ip) ? 3 : 4;
/* 二维码 / 配对链接里放的本机地址：真实局域网在前，虚拟局域网在后；都没有才退而求其次用 junk */
function qrAddrs(locals, max = MAX_ADDRS) {
  const by = k => locals.filter(l => l.kind === k).map(l => l.ip).sort((a, b) => homeRank(a) - homeRank(b));
  let r = [...by('lan'), ...by('overlay')];
  if (!r.length) r = by('junk');
  return uniq(r).slice(0, max);
}
function describeNet(locals) {
  const part = (k, label) => { const l = locals.filter(x => x.kind === k).map(x => x.ip).sort((a, b) => homeRank(a) - homeRank(b)); return l.length ? label + ' ' + l.join(' / ') : ''; };
  return [part('lan', '局域网'), part('overlay', '虚拟网络')].filter(Boolean).join(' · ');
}

/* ───────── 对方地址：排序 / 分类 ───────── */
/* 越小越优先：0 与本机某真实网卡同网段（局域网直连）；1 与某虚拟网卡同网段（虚拟局域网）；2 与虚拟机网段同网段；3 其他私有地址；4 其他 */
function rank(ip, locals) {
  for (const l of locals) if (l.kind === 'lan' && inRange(ip, l.ip, l.prefix)) return 0;
  for (const l of locals) if (l.kind === 'overlay' && inRange(ip, l.ip, l.prefix)) return 1;
  for (const l of locals) if (l.kind === 'junk' && inRange(ip, l.ip, l.prefix)) return 2;
  return isPrivate(ip) ? 3 : 4;
}
function order(cands, locals) {                       // 稳定排序：同一等级里保持传入顺序
  return uniq(cands.filter(c => toInt(c) !== null)).map((c, i) => ({ c, i, r: rank(c, locals) })).sort((a, b) => (a.r - b.r) || (a.i - b.i)).map(x => x.c);
}
function pathLabel(ip, locals) { const r = rank(ip, locals); return r === 0 ? '局域网直连' : r === 1 ? '虚拟局域网' : '远程连接'; }
/* 要不要向这个地址单播发现包：只给「本机真有路可走」的地址发——同网段的、公网的，或本机在虚拟局域网里时的其他私有地址；
 * 免得在移动网络 / 别人的局域网里把设备名发给不相干的私有地址。 */
function shouldUnicast(ip, locals) { return rank(ip, locals) === 3 ? locals.some(l => l.kind === 'overlay') : true; }
/* 对方是否就在本机的真实局域网里（不是 → 链路可能是 VPN / 中继，心跳超时要放宽） */
function isLanPeer(ip, locals) { return locals.some(l => (l.kind === 'lan' || l.kind === 'junk') && inRange(ip, l.ip, l.prefix)); }
/* 把 extra 并进地址列表：primary 排第一，总数不超过 max；返回 { ip, ips } */
function mergeAddrs(primary, ips, extra, max = MAX_ADDRS) {
  const all = uniq([primary, ...(ips || []), ...(extra || [])].filter(s => toInt(s) !== null));
  return { ip: all[0] || primary || '', ips: all.slice(1, max) };
}
/* 一条配对记录的全部已知地址（主地址在前） */
const recAddrs = rec => uniq([rec && rec.ip, ...((rec && rec.ips) || [])].filter(s => toInt(s) !== null));

/* ───────── 配对链接 ───────── */
function buildPairLink({ id, name, pin, port, ips }) {
  return 'lancast://pair?v=2&id=' + id + '&n=' + encodeURIComponent(name) + '&p=' + pin + '&port=' + (port || 47800) + '&ip=' + (ips || []).join(',');
}
/* 从一段文字里找出 lancast://pair?... 并解析（前后有别的字也行）；不是配对链接返回 null */
function parsePairLink(text) {
  const m = /lancast:\/\/pair\?([\x21-\x7E]+)/i.exec(String(text || ''));
  if (!m) return null;
  const q = parseQuery(m[1].replace(/[).,;\]>"']+$/, ''));
  const id = q.id || '', pin = q.p || '';
  if (!/^[0-9a-zA-Z]{4,64}$/.test(id) || !/^\d{4,12}$/.test(pin)) return null;
  const ips = cleanIps((q.ip || '').split(','), 8);
  if (!ips.length) return null;
  let port = Number(q.port);
  if (!(port >= 1 && port <= 65535)) port = 47800;
  return { id, name: (q.n || '对方设备').slice(0, 64), pin, port, ips };
}
/* a=1&b=%E4%B8%AD → { a: '1', b: '中' }（不依赖 URLSearchParams；同名参数取第一个；解码失败就保留原文） */
function parseQuery(qs) {
  const out = Object.create(null);
  for (const kv of String(qs).split('&')) {
    const i = kv.indexOf('=');
    if (i <= 0) continue;
    const k = kv.slice(0, i);
    let v = kv.slice(i + 1).replace(/\+/g, ' ');
    try { v = decodeURIComponent(v); } catch {}
    if (!(k in out)) out[k] = v;
  }
  return out;
}

/* 连不上对方时给用户的提示：按「本机有没有虚拟局域网」区分，直接告诉下一步该做什么 */
function unreachableHint(locals, ips) {
  const hasOverlay = locals.some(l => l.kind === 'overlay');
  const tried = '连不上对方（试过 ' + (ips || []).join('、') + '）。';
  return tried + (hasOverlay
    ? '请确认：对方已打开瞬流Pro，并且和本机在同一个虚拟局域网里；对方是电脑的话，防火墙要放行（点「放行防火墙」）。'
    : '本机目前没有检测到虚拟局域网：两台设备不在同一个局域网时，请先在两边都登录蒲公英（或 ZeroTier / Tailscale）加入同一个虚拟网络，再重试。');
}

/* ───────── 并行探测 ─────────
 * connect({ host, port }) 返回 net.Socket 一类的对象（'connect' / 'error' / 'close' 事件、destroy()），由调用方注入。
 * 默认「抢跑」：排在最前的候选一连通就立刻返回；排在前面的还没出结果时，后面的连通了也最多再等 graceMs。
 * all = true：等全部候选出结果（或超时）再返回，用于配对（要依次尝试所有连得通的地址）。
 * 返回连得通的地址，按传入顺序（= 优先级）排列；一个都不通返回 []。 */
function probe(cands, port, opt = {}) {
  const { connect, timeoutMs = 2500, graceMs = 350, all = false } = opt;
  cands = uniq(cands.filter(c => toInt(c) !== null));
  return new Promise(resolve => {
    if (!cands.length || typeof connect !== 'function') { resolve([]); return; }
    const st = cands.map(() => null), socks = [];
    let firstOk = 0, done = false, iv = null, to = null;
    const finish = () => {
      if (done) return; done = true; clearInterval(iv); clearTimeout(to);
      for (const s of socks) { try { s.destroy(); } catch {} }
      resolve(cands.filter((c, i) => st[i] === true));
    };
    const decide = () => {
      if (done) return;
      if (!st.some(v => v === null)) { finish(); return; }
      if (all) return;
      for (let i = 0; i < st.length; i++) { if (st[i] === true) { finish(); return; } if (st[i] === null) break; }   // 最前面的已连通
      if (firstOk && Date.now() - firstOk >= graceMs) finish();
    };
    cands.forEach((host, i) => {
      let s;
      const settle = v => { if (st[i] !== null) return; st[i] = v; if (v && !firstOk) firstOk = Date.now(); decide(); };
      try { s = connect({ host, port }); } catch { st[i] = false; return; }
      socks.push(s);
      s.once('connect', () => settle(true));
      s.once('error', () => settle(false));
      s.once('close', () => settle(false));
    });
    to = setTimeout(() => { for (let i = 0; i < st.length; i++) if (st[i] === null) st[i] = false; finish(); }, timeoutMs);
    iv = setInterval(decide, 50);
    decide();
  });
}

/* ───────── 防火墙一键放行 ─────────
 * 蒲公英等虚拟网卡常被 Windows 归为「公用网络」，而系统弹窗默认只勾「专用网络」——于是虚拟局域网里的对方怎么都连不进来。
 * 这里生成「所有网络类型」都放行 TCP 47800 / UDP 47801 的命令（规则名只用 ASCII，免得被控制台代码页弄乱）。 */
const FW_RULES = [['LANCast-TCP-47800', 'TCP', 47800], ['LANCast-UDP-47801', 'UDP', 47801]];
function firewallScript() {
  const sh = 'netsh advfirewall firewall';
  return FW_RULES.map(([n]) => sh + ' delete rule name=' + n).concat(
    FW_RULES.map(([n, p, port]) => sh + ' add rule name=' + n + ' dir=in action=allow protocol=' + p + ' localport=' + port + ' profile=any')
  ).join(' & ');
}
/* 提升权限（弹 UAC）执行上面的脚本。规则里没有单引号，可以放心放进 PowerShell 的单引号字符串。 */
function firewallPowerShell() {
  return "Start-Process -FilePath cmd.exe -Verb RunAs -WindowStyle Hidden -Wait -ArgumentList '/c " + firewallScript() + "'";
}

module.exports = {
  MAX_ADDRS, JUNK_NIC, OVERLAY_NIC, FW_RULES,
  toInt, inRange, usableV4, isPrivate, prefixOfMask, uniq, cleanIps,
  kindOfIface, localAddrs, qrAddrs, describeNet,
  rank, order, pathLabel, isLanPeer, shouldUnicast, mergeAddrs, recAddrs,
  buildPairLink, parsePairLink, unreachableHint, probe, firewallScript, firewallPowerShell
};
