'use strict';
/*
 * BT 下载引擎（纯 Node，无外部依赖）：
 *   Torrent     单个种子的下载：分片校验 → 落盘 → 断点续传；基础上传（对方请求就给，换取下载速度）；
 *               流式读取 createReadStream()：播放位置附近的分片优先下载（边下边播，拖动进度条也行）
 *   BtManager   多任务管理：持久化任务列表、自动续传、本地 HTTP(Range) 流媒体服务
 * 找节点（Tracker + DHT）复用 magnet.js 的 discoverPeers。只用 TCP 明文连接（无 uTP / 强制加密）。
 */
const net = require('net'), http = require('http'), fs = require('fs'), path = require('path'), crypto = require('crypto');
const { EventEmitter } = require('events');
const { Readable } = require('stream');
const { bencode, bdecode, parseTorrent, discoverPeers, _internal } = require('./magnet');
const { decodeAt, parseCompact } = _internal;

const BLOCK = 16384, LOCAL_PEX = 1, LOCAL_UT = 2;
const sha1 = b => crypto.createHash('sha1').update(b).digest();
const RESERVED = /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(\..*)?$/i;
const fsSeg = s => {
  s = String(s).replace(/[<>:"|?*\\/\u0000-\u001f]/g, '_').replace(/[. ]+$/, '');
  if (!s) s = '_'; if (RESERVED.test(s)) s = '_' + s;
  return s.slice(0, 200);
};
const MIME = { mp4: 'video/mp4', m4v: 'video/mp4', mkv: 'video/x-matroska', webm: 'video/webm', avi: 'video/x-msvideo', mov: 'video/quicktime', ts: 'video/mp2t', flv: 'video/x-flv', wmv: 'video/x-ms-wmv', mpg: 'video/mpeg', mpeg: 'video/mpeg', rmvb: 'application/vnd.rn-realmedia-vbr', '3gp': 'video/3gpp',
  mp3: 'audio/mpeg', flac: 'audio/flac', aac: 'audio/aac', m4a: 'audio/mp4', ogg: 'audio/ogg', opus: 'audio/ogg', wav: 'audio/wav', wma: 'audio/x-ms-wma', srt: 'text/plain; charset=utf-8', vtt: 'text/vtt' };
const extOf = p => (/\.([A-Za-z0-9]+)$/.exec(p) || [])[1]?.toLowerCase() || '';
/** 'video' | 'audio' | '' */
function mediaKind(p) { const m = MIME[extOf(p)] || ''; return m.startsWith('video/') || m.includes('realmedia') ? 'video' : m.startsWith('audio/') ? 'audio' : ''; }

async function withHandle(abs, flags, fn) {
  const fh = await fs.promises.open(abs, flags);
  try { return await fn(fh); } finally { await fh.close().catch(() => {}); }
}

class Torrent extends EventEmitter {
  /**
   * @param {object} o { torrent:Buffer(.torrent), dir:保存目录, selected:[文件序号]|null(全部), resumeFile:续传文件路径, trackers:[], maxConns, readahead }
   */
  constructor(o) {
    super();
    const m = this.meta = parseTorrent(o.torrent);
    if (!m.pieces || !m.pieceLength) throw new Error('暂不支持纯 BT v2 种子的下载');
    this.hash = m.hash; this.ih = Buffer.from(m.hash, 'hex'); this.name = m.name;
    this.pl = m.pieceLength; this.n = m.pieces.length / 20;
    this.total = m.layout.reduce((a, f) => a + f.size, 0);
    this.lastLen = this.total - (this.n - 1) * this.pl;
    if (this.n < 1 || this.lastLen <= 0 || this.lastLen > this.pl) throw new Error('种子的分片信息不一致');
    this.opts = o; this.dir = o.dir; this.resumeFile = o.resumeFile || ''; this.extraTrackers = o.trackers || [];
    this.maxConns = o.maxConns || 50; this.readahead = o.readahead || Math.max(32 * 1024 * 1024, 4 * this.pl);
    this.layout = m.layout.map(e => ({ ...e, abs: e.pad ? '' : path.join(this.dir, ...e.path.split('/').map(fsSeg)) }));
    const vis = this.layout.filter(e => !e.pad);        // 与 meta.files 一一对应
    this.files = m.files.map((f, i) => {
      return { index: i, path: f.path, size: f.size, offset: f.offset, abs: vis[i].abs, selected: true, first: f.size ? Math.floor(f.offset / this.pl) : -1, last: f.size ? Math.floor((f.offset + f.size - 1) / this.pl) : -1 };
    });
    this.have = new Uint8Array(this.n); this.haveCount = 0;
    this.wanted = new Uint8Array(this.n);
    this.avail = new Uint16Array(this.n);
    this.inprog = new Map(); this.writing = new Set(); this.maxInprog = Math.max(16, Math.floor(160 * 1024 * 1024 / this.pl));
    this.order = []; this._orderDirty = true;
    this.peers = new Set(); this.queue = []; this.known = new Map(); this.banned = new Set();
    this.pid = Buffer.concat([Buffer.from('-LC0120-'), crypto.randomBytes(12)]);
    this.streams = new Set(); this.hints = new Map(); this.waiters = new Map();
    this.rxBytes = 0; this.txBytes = 0; this._rxHist = []; this._txHist = []; this.speedDown = 0; this.speedUp = 0;
    this.state = 'paused'; this.error = ''; this.checked = 0;
    this._timers = []; this._disc = null; this._lastDisc = 0; this._resumeDirty = false; this._started = false; this._destroyed = false;
    this.setSelected(o.selected || null, true);
  }

  /* ───────────── 选择 / 进度 ───────────── */
  setSelected(sel, quiet) {
    const set = sel ? new Set(sel) : null;
    this.files.forEach(f => { f.selected = !set || set.has(f.index); });
    this.wanted.fill(0);
    for (const f of this.files) if (f.selected && f.first >= 0) for (let p = f.first; p <= f.last; p++) this.wanted[p] = 1;
    this._recount(); this._orderDirty = true; this._resumeDirty = true;
    if (!quiet) { this._maybeRestart(); this.emit('state'); }
  }
  selectedIndexes() { return this.files.filter(f => f.selected).map(f => f.index); }
  _plen(p) { return p === this.n - 1 ? this.lastLen : this.pl; }
  _recount() {
    let wb = 0, db = 0, miss = 0;
    for (let p = 0; p < this.n; p++) if (this.wanted[p]) { const l = this._plen(p); wb += l; if (this.have[p]) db += l; else miss++; }
    this.wantedBytes = wb; this.doneBytes = db; this.missing = miss;
  }
  _maybeRestart() {
    if (this._started && !this._destroyed && this.state === 'seeding' && this.missing > 0) { this._setState('downloading'); this._net(); }
  }
  _setState(s) { if (this.state !== s) { this.state = s; this.emit('state'); } }

  status(withFiles) {
    const s = {
      hash: this.hash, name: this.name, state: this.state, error: this.error, dir: this.dir, total: this.total,
      wantedBytes: this.wantedBytes, doneBytes: this.doneBytes, progress: this.wantedBytes ? this.doneBytes / this.wantedBytes : 1,
      speedDown: this.speedDown, speedUp: this.speedUp, peers: [...this.peers].filter(p => p.shook).length, conns: this.peers.size,
      seeds: [...this.peers].filter(p => p.shook && p.hasCount === this.n).length,
      eta: this.speedDown > 1024 ? Math.round((this.wantedBytes - this.doneBytes) / this.speedDown) : -1,
      streaming: this.streams.size > 0, checked: this.checked / this.n, rx: this.rxBytes, tx: this.txBytes, fileCount: this.files.length
    };
    if (withFiles) s.files = this.files.map(f => ({ index: f.index, path: f.path, size: f.size, selected: f.selected, done: this._fileDone(f) }));
    return s;
  }
  _fileDone(f) {
    if (!f.size) return 0;
    let d = 0;
    for (let p = f.first; p <= f.last; p++) {
      if (!this.have[p]) continue;
      const a = Math.max(p * this.pl, f.offset), b = Math.min(p * this.pl + this._plen(p), f.offset + f.size);
      d += Math.max(0, b - a);
    }
    return d;
  }

  /* ───────────── 启动 / 暂停 / 销毁 ───────────── */
  async start() {
    if (this._started || this._destroyed) return;
    this._started = true; this.error = '';
    try {
      await fs.promises.mkdir(this.dir, { recursive: true });
      const had = await this._loadResume();
      if (!had && this.layout.some(e => !e.pad && fs.existsSync(e.abs))) await this.recheck();   // 没有续传记录但文件已存在：校验一遍
      if (this._destroyed || !this._started) return;
      this._recount(); this._orderDirty = true;
      this._setState(this.missing ? 'downloading' : 'seeding');
      if (this.missing) this._net(); else this.emit('done');
    } catch (e) { this._fail(e); }
  }
  pause() {
    if (this._destroyed) return;
    this._stopNet(); this._saveResume(true); this._started = false; this._setState('paused');
  }
  resume() { if (!this._started && !this._destroyed) this.start(); }
  destroy() {
    if (this._destroyed) return;
    this._destroyed = true; this._stopNet(); this._saveResume(true);
    for (const s of [...this.streams]) s.stream.destroy(new Error('任务已移除'));
    for (const set of this.waiters.values()) set.forEach(f => f(false));
    this.waiters.clear(); this.state = 'paused';
  }
  _fail(e) { this.error = e.message || String(e); this._stopNet(); this._setState('error'); this.emit('error', e); }

  _net() {
    this._stopNet();
    // 之前见过的节点重新排进连接队列（暂停 / 继续、追加选择文件后不用等重新发现）
    this.queue = [...this.known.values()].filter(r => !this.banned.has(r.host) && r.fails < 2).map(r => { r.nextTry = 0; return r; });
    this._timers.push(setInterval(() => this._tick(), 1000), setInterval(() => { if (this._orderDirty) this._rebuild(); }, 400));
    this._discover(); this._pump();
  }
  _stopNet() {
    this._timers.forEach(t => clearInterval(t)); this._timers = [];
    if (this._disc) { this._disc.stop(); this._disc = null; }
    for (const p of [...this.peers]) this._kill(p);
    this.queue.length = 0; this.speedDown = this.speedUp = 0;
  }
  _discover() {
    this._lastDisc = Date.now();
    if (this.opts.discovery === false) return;
    if (this._disc) this._disc.stop();
    this._disc = discoverPeers({
      hash: this.hash, trackers: [...this.meta.trackers, ...this.extraTrackers], durationMs: 90000,
      left: Math.max(1, this.wantedBytes - this.doneBytes), onPeers: l => this._addPeers(l)
    });
  }
  _addPeers(list) {
    for (const p of list) {
      const key = p.host + ':' + p.port;
      if (this.known.has(key) || this.banned.has(p.host) || this.known.size > 4000) continue;
      const rec = { host: p.host, port: p.port, key, fails: 0, nextTry: 0 };
      this.known.set(key, rec); this.queue.push(rec);
    }
    this._pump();
  }
  _pump() {
    if (this._destroyed || !this._started || this.state !== 'downloading') return;
    const now = Date.now(), keep = [];
    for (const rec of this.queue) {
      if (this.peers.size >= this.maxConns || rec.nextTry > now) { keep.push(rec); continue; }
      this._connect(rec);
    }
    this.queue = keep;
  }
  _tick() {
    const now = Date.now();
    this._rxHist.push(this.rxBytes); this._txHist.push(this.txBytes);
    if (this._rxHist.length > 6) { this._rxHist.shift(); this._txHist.shift(); }
    const k = this._rxHist.length - 1;
    this.speedDown = k ? (this._rxHist[k] - this._rxHist[0]) / k : 0; this.speedUp = k ? (this._txHist[k] - this._txHist[0]) / k : 0;
    for (const peer of [...this.peers]) {
      for (const [key, r] of peer.reqs) {
        if (now - r.ts > 20000) { this._dropReq(peer, key, r); peer.snubs++; }
      }
      if (peer.shook && peer.snubs >= 4) { this._kill(peer); continue; }
      if (!peer.shook && now - peer.t0 > 9000) { this._kill(peer); continue; }
      if (peer.shook && now - peer.lastData > 120000) { this._kill(peer); continue; }
      if (!peer.choked && peer.interested) this._fill(peer);
    }
    if (this.state === 'downloading') {
      const act = [...this.peers].filter(p => p.shook).length;
      if ((act < 8 && now - this._lastDisc > 45000) || now - this._lastDisc > 10 * 60000) this._discover();
      this._pump();
    }
    if (this._resumeDirty && now - (this._lastSave || 0) > 8000) this._saveResume();
  }

  /* ───────────── 优先级 / 选片 ───────────── */
  _windows() {
    const w = [];
    for (const s of this.streams) { const f = this.files[s.file]; w.push({ file: s.file, a: s.pos, b: Math.min(f.offset + f.size, s.pos + this.readahead) }); }
    for (const [fi, list] of this.hints) { const f = this.files[fi]; for (const h of list) w.push({ file: fi, a: f.offset + h.start, b: Math.min(f.offset + f.size, f.offset + h.end) }); }
    return w;
  }
  _rebuild() {
    this._orderDirty = false;
    const seen = new Uint8Array(this.n), order = [];
    const add = p => { if (p >= 0 && p < this.n && !seen[p] && !this.have[p] && this.wanted[p]) { seen[p] = 1; order.push(p); } };
    const wins = this._windows().sort((x, y) => x.a - y.a);
    const urg = new Set();
    for (const w of wins) for (let p = Math.floor(w.a / this.pl); p <= Math.floor((w.b - 1) / this.pl); p++) { add(p); urg.add(p); }
    const streamedFiles = new Set(wins.map(w => w.file));
    for (const fi of streamedFiles) { const f = this.files[fi]; if (f.first >= 0) for (let p = f.first; p <= f.last; p++) add(p); }
    const rest = [];
    for (let p = 0; p < this.n; p++) if (!seen[p] && !this.have[p] && this.wanted[p]) rest.push(p);
    rest.sort((x, y) => this.avail[x] - this.avail[y] || x - y);
    this.order = order.concat(rest);
    this._urgent = urg;
  }
  _startPiece(p) {
    const len = this._plen(p), nb = Math.ceil(len / BLOCK);
    const ip = { buf: Buffer.allocUnsafe(len), len, nb, recv: new Uint8Array(nb), req: new Uint8Array(nb), recvCount: 0, cursor: 0, contrib: new Set() };
    this.inprog.set(p, ip); return ip;
  }
  _blen(ip, b) { return Math.min(BLOCK, ip.len - b * BLOCK); }
  _nextBlock(peer) {
    if (this._orderDirty) this._rebuild();
    const endgame = this.missing > 0 && this.missing - this.inprog.size <= 0;
    let cand = null;
    for (const p of this.order) {
      if (this.have[p] || this.writing.has(p) || !peer.bf[p]) continue;
      let ip = this.inprog.get(p);
      if (!ip) {
        if (endgame) continue;
        if (this.inprog.size >= this.maxInprog && !(this._urgent && this._urgent.has(p))) continue;
        ip = this._startPiece(p);
      }
      for (let b = ip.cursor; b < ip.nb; b++) {
        if (ip.recv[b]) { if (b === ip.cursor) ip.cursor++; continue; }
        if (ip.req[b] === 0) return { p, b, ip };
        if (!cand && ip.req[b] < 2 && !peer.reqs.has(p * 65536 + b) && endgame) cand = { p, b, ip };
      }
    }
    return cand;
  }
  _fill(peer) {
    if (peer.choked || !peer.interested || peer.dead || this.state !== 'downloading') return;
    const max = peer.pipe;
    while (peer.reqs.size < max) {
      const r = this._nextBlock(peer);
      if (!r) break;
      const key = r.p * 65536 + r.b;
      peer.reqs.set(key, { p: r.p, b: r.b, ts: Date.now() }); r.ip.req[r.b]++;
      const pl = Buffer.alloc(12); pl.writeUInt32BE(r.p, 0); pl.writeUInt32BE(r.b * BLOCK, 4); pl.writeUInt32BE(this._blen(r.ip, r.b), 8);
      this._send(peer, 6, pl);
    }
  }
  _dropReq(peer, key, r) {
    peer.reqs.delete(key);
    const ip = this.inprog.get(r.p);
    if (ip && ip.req[r.b] > 0) { ip.req[r.b]--; if (r.b < ip.cursor) ip.cursor = r.b; }
  }
  _wantsFrom(peer) {
    if (this._orderDirty) this._rebuild();
    for (const p of this.order) if (!this.have[p] && peer.bf[p]) return true;
    return false;
  }
  _updateInterest(peer) {
    const want = this._wantsFrom(peer);
    if (want && !peer.interested) { peer.interested = true; this._send(peer, 2); }
    else if (!want && peer.interested) { peer.interested = false; this._send(peer, 3); }
  }

  /* ───────────── 节点连接 ───────────── */
  _connect(rec) {
    const sock = net.connect({ host: rec.host, port: rec.port }); sock.setNoDelay(true);
    const peer = {
      rec, sock, buf: Buffer.alloc(0), shook: false, bf: new Uint8Array(this.n), hasCount: 0, choked: true, interested: false,
      theirInterested: false, amChoking: true, reqs: new Map(), pipe: 24, snubs: 0, bad: 0, dead: false, t0: Date.now(), lastData: Date.now(), up: 0
    };
    this.peers.add(peer);
    sock.once('connect', () => {
      const hs = Buffer.alloc(68); hs[0] = 19; hs.write('BitTorrent protocol', 1, 'latin1'); hs[25] = 0x10;
      this.ih.copy(hs, 28); this.pid.copy(hs, 48); sock.write(hs);
    });
    sock.on('data', d => {
      this.rxBytes += d.length; peer.lastData = Date.now();
      peer.buf = peer.buf.length ? Buffer.concat([peer.buf, d]) : d;
      try { this._onData(peer); } catch (e) { this._kill(peer); }
    });
    sock.on('error', () => this._kill(peer)); sock.on('close', () => this._kill(peer));
  }
  _kill(peer) {
    if (peer.dead) return; peer.dead = true;
    try { peer.sock.destroy(); } catch {}
    this.peers.delete(peer);
    for (const [key, r] of [...peer.reqs]) this._dropReq(peer, key, r);
    if (peer.shook) for (let p = 0; p < this.n; p++) if (peer.bf[p] && this.avail[p]) this.avail[p]--;
    const rec = peer.rec;
    if (!this.banned.has(rec.host) && !this._destroyed) {
      if (peer.shook) { rec.fails = 0; rec.nextTry = Date.now() + 90000; this.queue.push(rec); }
      else if (++rec.fails < 2) { rec.nextTry = Date.now() + 5 * 60000; this.queue.push(rec); }
    }
    if (!this._destroyed) this._pump();
  }
  _ban(peer) { this.banned.add(peer.rec.host); this._kill(peer); }
  _send(peer, id, payload) {
    if (peer.dead) return;
    const len = 1 + (payload ? payload.length : 0), b = Buffer.allocUnsafe(4 + len);
    b.writeUInt32BE(len, 0); b[4] = id; if (payload) payload.copy(b, 5);
    try { peer.sock.write(b); } catch {}
  }
  _sendExt(peer, id, payload) { this._send(peer, 20, Buffer.concat([Buffer.from([id]), payload])); }

  _onData(peer) {
    if (!peer.shook) {
      if (peer.buf.length < 68) return;
      if (peer.buf[0] !== 19 || peer.buf.toString('latin1', 1, 20) !== 'BitTorrent protocol') throw new Error('not bt');
      if (!peer.buf.subarray(28, 48).equals(this.ih)) throw new Error('infohash');
      peer.ext = !!(peer.buf[25] & 0x10);
      peer.buf = peer.buf.subarray(68); peer.shook = true;
      if (peer.ext) this._sendExt(peer, 0, bencode({ m: { ut_pex: LOCAL_PEX, ut_metadata: LOCAL_UT }, v: 'LANCast', reqq: 64 }));
      if (this.haveCount) {
        const bf = Buffer.alloc(Math.ceil(this.n / 8));
        for (let p = 0; p < this.n; p++) if (this.have[p]) bf[p >> 3] |= 0x80 >> (p & 7);
        this._send(peer, 5, bf);
      }
    }
    while (peer.buf.length >= 4) {
      const len = peer.buf.readUInt32BE(0);
      if (len > 4 * 1024 * 1024) throw new Error('too big');
      if (peer.buf.length < 4 + len) break;
      const msg = peer.buf.subarray(4, 4 + len); peer.buf = peer.buf.subarray(4 + len);
      if (len) this._onMsg(peer, msg[0], msg.subarray(1));
    }
  }
  _onMsg(peer, id, pl) {
    switch (id) {
      case 0: // choke：对方丢弃了我们所有未完成的请求
        peer.choked = true; for (const [key, r] of [...peer.reqs]) this._dropReq(peer, key, r); break;
      case 1: peer.choked = false; this._fill(peer); break;
      case 2:
        peer.theirInterested = true;
        if (peer.amChoking && [...this.peers].filter(x => !x.amChoking).length < 8) { peer.amChoking = false; this._send(peer, 1); }
        break;
      case 3: peer.theirInterested = false; break;
      case 4: {
        const p = pl.readUInt32BE(0);
        if (p < this.n && !peer.bf[p]) { peer.bf[p] = 1; peer.hasCount++; this.avail[p]++; this._orderDirty = true; }
        this._updateInterest(peer); this._fill(peer); break;
      }
      case 5: {
        if (pl.length < Math.ceil(this.n / 8)) throw new Error('bad bitfield');
        for (let p = 0; p < this.n; p++) if (pl[p >> 3] & (0x80 >> (p & 7)) && !peer.bf[p]) { peer.bf[p] = 1; peer.hasCount++; this.avail[p]++; }
        this._orderDirty = true; this._updateInterest(peer); this._fill(peer); break;
      }
      case 6: this._onRequest(peer, pl); break;
      case 7: this._onPiece(peer, pl); break;
      case 20: this._onExt(peer, pl); break;
      default: break;
    }
  }
  _onExt(peer, pl) {
    const eid = pl[0], body = pl.subarray(1);
    if (eid === 0) { const d = bdecode(body); peer.utId = Number(d.m && d.m.ut_metadata) || 0; }
    else if (eid === LOCAL_PEX) {
      const d = bdecode(body), ps = [];
      if (Buffer.isBuffer(d.added)) ps.push(...parseCompact(d.added, false));
      if (Buffer.isBuffer(d.added6)) ps.push(...parseCompact(d.added6, true));
      if (ps.length) this._addPeers(ps);
    } else if (eid === LOCAL_UT && peer.utId) {
      const [h] = decodeAt(body, 0, 0);
      if (Number(h.msg_type) === 0) this._sendExt(peer, peer.utId, bencode({ msg_type: 2, piece: Number(h.piece) }));   // 我们不提供元数据
    }
  }

  /* ───────────── 收块 / 校验 / 落盘 ───────────── */
  _onPiece(peer, pl) {
    const p = pl.readUInt32BE(0), begin = pl.readUInt32BE(4), data = pl.subarray(8);
    const ip = this.inprog.get(p);
    const key = p * 65536 + begin / BLOCK;
    const r = peer.reqs.get(key);
    if (!ip || begin % BLOCK) { if (r) peer.reqs.delete(key); return; }
    const b = begin / BLOCK;
    if (data.length !== this._blen(ip, b)) throw new Error('bad block');
    if (r) { peer.reqs.delete(key); if (ip.req[b] > 0) ip.req[b]--; peer.snubs = 0; }
    if (!ip.recv[b]) {
      data.copy(ip.buf, begin); ip.recv[b] = 1; ip.recvCount++; ip.contrib.add(peer);
      if (ip.req[b] > 0) {                                           // 收尾阶段同一块被多个节点请求：通知其它节点取消
        for (const o of this.peers) {
          const k2 = o.reqs.get(key);
          if (o !== peer && k2) { o.reqs.delete(key); const c = Buffer.alloc(12); c.writeUInt32BE(p, 0); c.writeUInt32BE(begin, 4); c.writeUInt32BE(data.length, 8); this._send(o, 8, c); }
        }
        ip.req[b] = 0;
      }
      if (ip.recvCount === ip.nb) this._complete(p, ip);
    }
    this._fill(peer);
  }
  async _complete(p, ip) {
    this.inprog.delete(p);
    const ok = sha1(ip.buf).equals(this.meta.pieces.subarray(p * 20, p * 20 + 20));
    if (!ok) {
      const sole = ip.contrib.size === 1;
      for (const peer of ip.contrib) { peer.bad++; if (sole || peer.bad >= 3) this._ban(peer); }
      this._orderDirty = true; return;
    }
    this.writing.add(p);
    try { await this._writePiece(p, ip.buf); } catch (e) { this.writing.delete(p); return this._fail(new Error('写入磁盘失败：' + e.message)); }
    this.writing.delete(p);
    if (this._destroyed || this.have[p]) return;
    this.have[p] = 1; this.haveCount++; this._resumeDirty = true;
    if (this.wanted[p]) { this.doneBytes += ip.len; this.missing--; }
    this._orderDirty = true;
    const hv = Buffer.alloc(4); hv.writeUInt32BE(p, 0);
    for (const peer of this.peers) if (peer.shook) this._send(peer, 4, hv);
    const ws = this.waiters.get(p); if (ws) { this.waiters.delete(p); ws.forEach(f => f(true)); }
    this.emit('piece', p);
    if (this.missing === 0 && this.state === 'downloading') {
      this._stopNet(); this._saveResume(true); this._setState('seeding'); this.emit('done');
    }
  }

  /* ───────────── 磁盘读写 ───────────── */
  _findEntry(off) {
    let lo = 0, hi = this.layout.length - 1;
    while (lo < hi) { const mid = (lo + hi + 1) >> 1; if (this.layout[mid].offset <= off) lo = mid; else hi = mid - 1; }
    return lo;
  }
  _spans(start, len) {
    const out = []; let off = start; const end = start + len; let i = this._findEntry(off);
    while (off < end && i < this.layout.length) {
      const e = this.layout[i], eEnd = e.offset + e.size;
      if (eEnd <= off) { i++; continue; }
      const n = Math.min(end, eEnd) - off;
      out.push({ e, fileOff: off - e.offset, bufOff: off - start, n }); off += n; i++;
    }
    return out;
  }
  async _writePiece(p, buf) {
    for (const s of this._spans(p * this.pl, buf.length)) {
      if (s.e.pad) continue;
      const open = async () => {
        try { return await fs.promises.open(s.e.abs, 'r+'); }
        catch (e) { if (e.code !== 'ENOENT') throw e; await fs.promises.mkdir(path.dirname(s.e.abs), { recursive: true }); return fs.promises.open(s.e.abs, 'w+'); }
      };
      const fh = await open();
      try {
        const st = await fh.stat(); if (st.size < s.e.size) await fh.truncate(s.e.size);
        await fh.write(buf, s.bufOff, s.n, s.fileOff);
      } finally { await fh.close().catch(() => {}); }
    }
  }
  async _read(start, len) {
    const out = Buffer.alloc(len);
    for (const s of this._spans(start, len)) {
      if (s.e.pad) continue;
      await withHandle(s.e.abs, 'r', async fh => {
        let got = 0;
        while (got < s.n) { const r = await fh.read(out, s.bufOff + got, s.n - got, s.fileOff + got); if (!r.bytesRead) throw new Error('文件数据不完整'); got += r.bytesRead; }
      });
    }
    return out;
  }
  _onRequest(peer, pl) {
    const p = pl.readUInt32BE(0), begin = pl.readUInt32BE(4), len = pl.readUInt32BE(8);
    if (peer.amChoking || p >= this.n || !this.have[p] || len > 32768 || begin + len > this._plen(p) || peer.up > 32) return;
    peer.up++;
    this._read(p * this.pl + begin, len).then(data => {
      peer.up--;
      const h = Buffer.alloc(8); h.writeUInt32BE(p, 0); h.writeUInt32BE(begin, 4);
      this._send(peer, 7, Buffer.concat([h, data])); this.txBytes += len;
    }).catch(() => { peer.up--; });
  }

  /* ───────────── 续传 / 校验 ───────────── */
  async _loadResume() {
    if (!this.resumeFile) return false;
    let j; try { j = JSON.parse(await fs.promises.readFile(this.resumeFile, 'utf8')); } catch { return false; }
    const bf = Buffer.from(j.have || '', 'base64');
    if (bf.length !== Math.ceil(this.n / 8)) return false;
    for (let p = 0; p < this.n; p++) if (bf[p >> 3] & (0x80 >> (p & 7))) { this.have[p] = 1; this.haveCount++; }
    for (const e of this.layout) {          // 文件被删 / 被改小：对应分片作废
      if (e.pad || !e.size) continue;
      let ok = false; try { ok = fs.statSync(e.abs).size >= e.size; } catch {}
      if (!ok) { const a = Math.floor(e.offset / this.pl), b = Math.floor((e.offset + e.size - 1) / this.pl); for (let p = a; p <= b; p++) if (this.have[p]) { this.have[p] = 0; this.haveCount--; } }
    }
    return true;
  }
  _saveResume(sync) {
    this._resumeDirty = false; this._lastSave = Date.now();
    if (!this.resumeFile) return;
    const bf = Buffer.alloc(Math.ceil(this.n / 8));
    for (let p = 0; p < this.n; p++) if (this.have[p]) bf[p >> 3] |= 0x80 >> (p & 7);
    const data = JSON.stringify({ v: 1, have: bf.toString('base64'), selected: this.selectedIndexes() });
    try {
      fs.mkdirSync(path.dirname(this.resumeFile), { recursive: true });
      const tmp = this.resumeFile + '.tmp';
      if (sync) { fs.writeFileSync(tmp, data); fs.renameSync(tmp, this.resumeFile); }
      else fs.promises.writeFile(tmp, data).then(() => fs.promises.rename(tmp, this.resumeFile)).catch(() => {});
    } catch {}
  }
  /** 逐片读盘校验，恢复已有进度（用于没有续传记录、但文件已存在的情况） */
  async recheck() {
    this._setState('checking'); this.have.fill(0); this.haveCount = 0; this.checked = 0;
    for (let p = 0; p < this.n && !this._destroyed; p++) {
      try {
        const buf = await this._read(p * this.pl, this._plen(p));
        if (sha1(buf).equals(this.meta.pieces.subarray(p * 20, p * 20 + 20))) { this.have[p] = 1; this.haveCount++; }
      } catch {}
      this.checked = p + 1;
    }
    this._resumeDirty = true; this._recount();
  }

  /* ───────────── 边下边播 ───────────── */
  /** 播放一个文件前调用：把文件头部（索引 / 元数据）和尾部（mp4 的 moov、mkv 的索引）排到最前面 */
  prefetch(fileIndex) {
    const f = this.files[fileIndex]; if (!f) return;
    if (!f.selected) this.setSelected([...this.selectedIndexes(), fileIndex]);
    const head = Math.min(f.size, this.opts.hintHead || Math.max(8 * 1024 * 1024, this.pl)), tail = Math.min(f.size, this.opts.hintTail || 4 * 1024 * 1024);
    this.hints.set(fileIndex, [{ start: 0, end: head }, { start: f.size - tail, end: f.size }]);
    this._orderDirty = true;
    if (!this._started) this.resume();
    else if (this.state === 'seeding' && this.missing > 0) this._maybeRestart();
  }
  clearHints(fileIndex) { if (this.hints.delete(fileIndex)) this._orderDirty = true; }
  _waitPiece(p) {
    return new Promise(res => { let s = this.waiters.get(p); if (!s) this.waiters.set(p, s = new Set()); s.add(res); });
  }
  /** 返回 Readable：读到哪、哪里的分片就优先下载；分片没到会等待，不会返回错误数据 */
  createReadStream(fileIndex, range) {
    const f = this.files[fileIndex]; if (!f) throw new Error('没有这个文件');
    if (!f.selected) this.setSelected([...this.selectedIndexes(), fileIndex]);
    const start = range && range.start != null ? range.start : 0, end = range && range.end != null ? range.end : f.size - 1;
    const t = this;
    const reg = { file: fileIndex, pos: f.offset + start, stream: null };
    let pos = start, busy = false, closed = false;
    const rs = new Readable({
      highWaterMark: 1 << 20,
      read() { pull(); },
      destroy(err, cb) { closed = true; t.streams.delete(reg); t._orderDirty = true; cb(err); }
    });
    reg.stream = rs;
    this.streams.add(reg); this._orderDirty = true;
    if (!this._started) this.resume(); else if (this.state === 'seeding' && this.missing > 0) this._maybeRestart();
    async function pull() {
      if (busy) return; busy = true;
      try {
        while (!closed) {
          if (pos > end || f.size === 0) { rs.push(null); break; }
          const abs = f.offset + pos, p = Math.floor(abs / t.pl);
          if (reg.pos !== abs) { reg.pos = abs; t._orderDirty = true; }
          if (!t.have[p]) { const ok = await t._waitPiece(p); if (!ok && (closed || t._destroyed)) break; continue; }
          const lastWanted = Math.floor((f.offset + end) / t.pl);
          let lp = p; while (lp < lastWanted && lp - p < 4 && t.have[lp + 1]) lp++;
          const stopAbs = Math.min(f.offset + end + 1, (lp + 1) * t.pl);
          const len = Math.min(stopAbs - abs, 1 << 20);
          const buf = await t._read(abs, len);
          if (closed) break;
          pos += len;
          if (!rs.push(buf)) break;
        }
      } catch (e) { if (!closed) rs.destroy(e); }
      finally { busy = false; }
    }
    return rs;
  }
}

/* ───────────── 管理器 + 本地 HTTP 流媒体服务 ───────────── */
function parseRange(h, size) {
  if (!h) return null;
  const m = /^bytes=(\d*)-(\d*)$/.exec(String(h).trim());
  if (!m || (m[1] === '' && m[2] === '')) return 'bad';
  let a, b;
  if (m[1] === '') { const n = Number(m[2]); a = Math.max(0, size - n); b = size - 1; }
  else { a = Number(m[1]); b = m[2] === '' ? size - 1 : Math.min(Number(m[2]), size - 1); }
  return a > b || a >= size ? 'bad' : { start: a, end: b };
}

class BtManager extends EventEmitter {
  /** @param {object} o { dataDir:任务数据目录(torrents/resume/state.json), defaultDir:默认下载目录 } */
  constructor(o) {
    super();
    this.torrentOpts = o.torrentOpts || {};
    this.dataDir = o.dataDir; this.defaultDir = o.defaultDir; this.tasks = new Map(); this.server = null; this.port = 0;
    fs.mkdirSync(path.join(this.dataDir, 'torrents'), { recursive: true });
    fs.mkdirSync(path.join(this.dataDir, 'resume'), { recursive: true });
  }
  _tfile(h) { return path.join(this.dataDir, 'torrents', h + '.torrent'); }
  _save() { clearTimeout(this._st); this._st = setTimeout(() => this._flush(), 300); }
  _flush() {
    clearTimeout(this._st);
    const list = [...this.tasks.values()].map(t => ({ hash: t.hash, dir: t.dir, selected: t.selectedIndexes(), paused: t.userPaused || false }));
    try { fs.writeFileSync(path.join(this.dataDir, 'state.json'), JSON.stringify(list)); } catch {}
  }
  /** 启动时恢复上次的任务；没暂停的自动继续 */
  load() {
    let list = []; try { list = JSON.parse(fs.readFileSync(path.join(this.dataDir, 'state.json'), 'utf8')); } catch {}
    for (const x of list) {
      try {
        const t = this._make(fs.readFileSync(this._tfile(x.hash)), x.dir, x.selected);
        t.userPaused = !!x.paused; if (!t.userPaused) t.start();
      } catch {}
    }
    return this.list();
  }
  _make(torrentBuf, dir, selected) {
    const t = new Torrent({ ...this.torrentOpts, torrent: torrentBuf, dir, selected, resumeFile: path.join(this.dataDir, 'resume', parseTorrent(torrentBuf).hash + '.json') });
    t.on('state', () => { this.emit('change', t.hash); this._save(); }); t.on('error', () => this.emit('change', t.hash)); t.on('done', () => { this.emit('done', t.hash); this.emit('change', t.hash); });
    this.tasks.set(t.hash, t); this._save(); return t;
  }
  /** 添加下载。torrent 是 resolveMagnet 返回的 .torrent Buffer；已存在则只更新选择的文件 */
  add({ torrent, dir, selected, start = true }) {
    const h = parseTorrent(torrent).hash;
    let t = this.tasks.get(h);
    if (t) { if (selected) t.setSelected([...new Set([...t.selectedIndexes(), ...selected])]); t.userPaused = false; if (start) t.resume(); this._save(); return t; }
    fs.writeFileSync(this._tfile(h), torrent);
    t = this._make(torrent, dir || this.defaultDir, selected || null);
    if (start) t.start();
    return t;
  }
  get(hash) { return this.tasks.get(hash); }
  list() { return [...this.tasks.values()].map(t => t.status()); }
  pause(hash) { const t = this.tasks.get(hash); if (t) { t.userPaused = true; t.pause(); this._save(); } }
  resume(hash) { const t = this.tasks.get(hash); if (t) { t.userPaused = false; t.resume(); this._save(); } }
  /** 移除任务；deleteFiles=true 时只删除种子里列出的文件（以及因此变空的目录），不会递归删整个目录 */
  remove(hash, deleteFiles) {
    const t = this.tasks.get(hash); if (!t) return;
    t.destroy(); this.tasks.delete(hash);
    for (const f of [this._tfile(hash), path.join(this.dataDir, 'resume', hash + '.json')]) { try { fs.unlinkSync(f); } catch {} }
    if (deleteFiles) {
      const dirs = new Set();
      for (const e of t.layout) if (!e.pad) { try { fs.unlinkSync(e.abs); } catch {} let d = path.dirname(e.abs); while (d.length > t.dir.length && d.startsWith(t.dir)) { dirs.add(d); d = path.dirname(d); } }
      [...dirs].sort((a, b) => b.length - a.length).forEach(d => { try { fs.rmdirSync(d); } catch {} });
    }
    this._save(); this.emit('change', hash);
  }
  destroy() { this._flush(); for (const t of this.tasks.values()) t.destroy(); this.tasks.clear(); if (this.server) { this.server.close(); this.server = null; } }

  /** 返回可直接给播放器的本地地址（自动准备文件头尾分片、自动加入下载） */
  async streamUrl(hash, fileIndex) {
    const t = this.tasks.get(hash); if (!t) throw new Error('任务不存在');
    const f = t.files[fileIndex]; if (!f) throw new Error('文件不存在');
    t.userPaused = false; t.prefetch(fileIndex); this._save();
    await this._ensureServer();
    return `http://127.0.0.1:${this.port}/${hash}/${fileIndex}/${encodeURIComponent(f.path.split('/').pop())}`;
  }
  _ensureServer() {
    if (this.server) return Promise.resolve();
    return new Promise((res, rej) => {
      const srv = http.createServer((req, resp) => this._serve(req, resp));
      srv.on('error', rej);
      srv.listen(0, '127.0.0.1', () => { this.server = srv; this.port = srv.address().port; res(); });
    });
  }
  _serve(req, res) {
    const m = /^\/([0-9a-f]{40})\/(\d+)(?:\/|$)/.exec(req.url.split('?')[0]);
    const t = m && this.tasks.get(m[1]), f = t && t.files[Number(m[2])];
    if (!f) { res.writeHead(404); return res.end(); }
    const rg = parseRange(req.headers.range, f.size);
    if (rg === 'bad') { res.writeHead(416, { 'Content-Range': `bytes */${f.size}` }); return res.end(); }
    const range = rg || { start: 0, end: f.size - 1 };
    const headers = {
      'Content-Type': MIME[extOf(f.path)] || 'application/octet-stream', 'Accept-Ranges': 'bytes', 'Cache-Control': 'no-store',
      'Access-Control-Allow-Origin': '*', 'Content-Length': f.size ? range.end - range.start + 1 : 0
    };
    if (rg) headers['Content-Range'] = `bytes ${range.start}-${range.end}/${f.size}`;
    res.writeHead(rg ? 206 : 200, headers);
    if (req.method === 'HEAD' || !f.size) return res.end();
    let rs; try { rs = t.createReadStream(f.index, range); } catch { return res.end(); }
    res.on('close', () => rs.destroy());
    rs.on('error', () => res.destroy());
    rs.pipe(res);
  }
}

module.exports = { Torrent, BtManager, mediaKind, parseRange, MIME };
