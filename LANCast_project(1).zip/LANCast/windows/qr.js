'use strict';
/* 极简二维码生成器：字节模式（UTF-8）、纠错等级 M、自动选版本（1–15）。
 * 不依赖任何第三方包，打包时不需要额外安装东西。
 * 算法依据 ISO/IEC 18004，写法参考 Nayuki 的公开实现（MIT 许可）。
 * 用法：QR.encode(text) → { size, get(x, y) }；QR.toCanvas(canvas, text, { scale, margin })
 */
(function (root) {
  const MAXV = 15;
  // 纠错等级 M：每个分块的纠错码字数、分块数（下标 = 版本号）
  const ECC_PER_BLOCK = [-1, 10, 16, 26, 18, 24, 16, 18, 22, 22, 26, 30, 22, 22, 24, 24];
  const NUM_BLOCKS    = [-1, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5, 5, 8, 9, 9, 10];

  function rawModules(ver) {
    let r = (16 * ver + 128) * ver + 64;
    if (ver >= 2) {
      const n = Math.floor(ver / 7) + 2;
      r -= (25 * n - 10) * n - 55;
      if (ver >= 7) r -= 36;
    }
    return r;
  }
  const dataCodewords = ver => Math.floor(rawModules(ver) / 8) - ECC_PER_BLOCK[ver] * NUM_BLOCKS[ver];

  function rsMul(x, y) {                       // GF(256)，多项式 0x11D
    let z = 0;
    for (let i = 7; i >= 0; i--) { z = (z << 1) ^ ((z >>> 7) * 0x11D); z ^= ((y >>> i) & 1) * x; }
    return z;
  }
  function rsDivisor(degree) {
    const r = new Array(degree).fill(0); r[degree - 1] = 1;
    let root = 1;
    for (let i = 0; i < degree; i++) {
      for (let j = 0; j < r.length; j++) { r[j] = rsMul(r[j], root); if (j + 1 < r.length) r[j] ^= r[j + 1]; }
      root = rsMul(root, 2);
    }
    return r;
  }
  function rsRemainder(data, div) {
    const r = div.map(() => 0);
    for (const b of data) {
      const f = b ^ r.shift(); r.push(0);
      for (let i = 0; i < div.length; i++) r[i] ^= rsMul(div[i], f);
    }
    return r;
  }

  function addEcc(data, ver) {                 // 分块 + 纠错 + 交织
    const nb = NUM_BLOCKS[ver], eccLen = ECC_PER_BLOCK[ver];
    const raw = Math.floor(rawModules(ver) / 8);
    const nShort = nb - raw % nb, shortLen = Math.floor(raw / nb);
    const div = rsDivisor(eccLen), blocks = [];
    for (let i = 0, k = 0; i < nb; i++) {
      const dat = data.slice(k, k + shortLen - eccLen + (i < nShort ? 0 : 1));
      k += dat.length;
      const ecc = rsRemainder(dat, div);
      if (i < nShort) dat.push(0);
      blocks.push(dat.concat(ecc));
    }
    const out = [];
    for (let i = 0; i < blocks[0].length; i++)
      blocks.forEach((b, j) => { if (i !== shortLen - eccLen || j >= nShort) out.push(b[i]); });
    return out;
  }

  function alignPositions(ver) {
    if (ver === 1) return [];
    const n = Math.floor(ver / 7) + 2;
    const step = ver === 32 ? 26 : Math.ceil((ver * 4 + 4) / (n * 2 - 2)) * 2;
    const r = [6];
    for (let pos = ver * 4 + 10; r.length < n; pos -= step) r.splice(1, 0, pos);
    return r;
  }

  const bit = (x, i) => ((x >>> i) & 1) !== 0;

  function build(bytes, forceMask) {
    // 选最小版本
    let ver = 0, bits = [];
    const push = (val, len) => { for (let i = len - 1; i >= 0; i--) bits.push((val >>> i) & 1); };
    for (let v = 1; v <= MAXV; v++) {
      const ccBits = v <= 9 ? 8 : 16, cap = dataCodewords(v) * 8;
      if (4 + ccBits + bytes.length * 8 <= cap) { ver = v; break; }
    }
    if (!ver) throw new Error('二维码内容太长');
    push(4, 4); push(bytes.length, ver <= 9 ? 8 : 16);
    for (const b of bytes) push(b, 8);
    const cap = dataCodewords(ver) * 8;
    push(0, Math.min(4, cap - bits.length));
    while (bits.length % 8) bits.push(0);
    for (let pad = 0xEC; bits.length < cap; pad ^= 0xEC ^ 0x11) push(pad, 8);
    const data = [];
    for (let i = 0; i < bits.length; i += 8) { let v = 0; for (let j = 0; j < 8; j++) v = (v << 1) | bits[i + j]; data.push(v); }
    const all = addEcc(data, ver);

    const size = ver * 4 + 17;
    const mod = Array.from({ length: size }, () => new Array(size).fill(false));
    const fn = Array.from({ length: size }, () => new Array(size).fill(false));
    const setF = (x, y, d) => { mod[y][x] = d; fn[y][x] = true; };

    for (let i = 0; i < size; i++) { setF(6, i, i % 2 === 0); setF(i, 6, i % 2 === 0); }
    const finder = (cx, cy) => {
      for (let dy = -4; dy <= 4; dy++) for (let dx = -4; dx <= 4; dx++) {
        const d = Math.max(Math.abs(dx), Math.abs(dy)), x = cx + dx, y = cy + dy;
        if (x >= 0 && x < size && y >= 0 && y < size) setF(x, y, d !== 2 && d !== 4);
      }
    };
    finder(3, 3); finder(size - 4, 3); finder(3, size - 4);
    const ap = alignPositions(ver), na = ap.length;
    for (let i = 0; i < na; i++) for (let j = 0; j < na; j++) {
      if ((i === 0 && j === 0) || (i === 0 && j === na - 1) || (i === na - 1 && j === 0)) continue;
      for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++)
        setF(ap[i] + dx, ap[j] + dy, Math.max(Math.abs(dx), Math.abs(dy)) !== 1);
    }
    const drawFormat = mask => {
      const d = (0 << 3) | mask;               // 纠错等级 M 的格式位 = 0
      let rem = d;
      for (let i = 0; i < 10; i++) rem = (rem << 1) ^ ((rem >>> 9) * 0x537);
      const b = ((d << 10) | rem) ^ 0x5412;
      for (let i = 0; i <= 5; i++) setF(8, i, bit(b, i));
      setF(8, 7, bit(b, 6)); setF(8, 8, bit(b, 7)); setF(7, 8, bit(b, 8));
      for (let i = 9; i < 15; i++) setF(14 - i, 8, bit(b, i));
      for (let i = 0; i < 8; i++) setF(size - 1 - i, 8, bit(b, i));
      for (let i = 8; i < 15; i++) setF(8, size - 15 + i, bit(b, i));
      setF(8, size - 8, true);
    };
    drawFormat(0);
    if (ver >= 7) {
      let rem = ver;
      for (let i = 0; i < 12; i++) rem = (rem << 1) ^ ((rem >>> 11) * 0x1F25);
      const b = (ver << 12) | rem;
      for (let i = 0; i < 18; i++) {
        const c = bit(b, i), a = size - 11 + i % 3, d = Math.floor(i / 3);
        setF(a, d, c); setF(d, a, c);
      }
    }
    // 摆放数据（之字形）
    let k = 0;
    for (let right = size - 1; right >= 1; right -= 2) {
      if (right === 6) right = 5;
      for (let vert = 0; vert < size; vert++) for (let j = 0; j < 2; j++) {
        const x = right - j, up = ((right + 1) & 2) === 0, y = up ? size - 1 - vert : vert;
        if (!fn[y][x] && k < all.length * 8) { mod[y][x] = bit(all[k >>> 3], 7 - (k & 7)); k++; }
      }
    }
    const applyMask = m => {
      for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
        let inv;
        switch (m) {
          case 0: inv = (x + y) % 2 === 0; break;
          case 1: inv = y % 2 === 0; break;
          case 2: inv = x % 3 === 0; break;
          case 3: inv = (x + y) % 3 === 0; break;
          case 4: inv = (Math.floor(x / 3) + Math.floor(y / 2)) % 2 === 0; break;
          case 5: inv = x * y % 2 + x * y % 3 === 0; break;
          case 6: inv = (x * y % 2 + x * y % 3) % 2 === 0; break;
          default: inv = ((x + y) % 2 + x * y % 3) % 2 === 0;
        }
        if (!fn[y][x] && inv) mod[y][x] = !mod[y][x];
      }
    };
    const penalty = () => {
      let p = 0;
      const line = get => {                    // 规则 1（连续同色）和规则 3（类定位图案）
        for (let a = 0; a < size; a++) {
          let run = 1;
          for (let b = 1; b < size; b++) {
            if (get(a, b) === get(a, b - 1)) { run++; if (run === 5) p += 3; else if (run > 5) p++; } else run = 1;
          }
          for (let b = 0; b + 11 <= size; b++) {
            const s = []; for (let t = 0; t < 11; t++) s.push(get(a, b + t) ? 1 : 0);
            const str = s.join('');
            if (str === '10111010000' || str === '00001011101') p += 40;
          }
        }
      };
      line((a, b) => mod[a][b]); line((a, b) => mod[b][a]);
      for (let y = 0; y < size - 1; y++) for (let x = 0; x < size - 1; x++) {   // 规则 2（2×2 同色块）
        const c = mod[y][x];
        if (c === mod[y][x + 1] && c === mod[y + 1][x] && c === mod[y + 1][x + 1]) p += 3;
      }
      let dark = 0; for (const r of mod) for (const c of r) if (c) dark++;       // 规则 4（黑白比例）
      p += (Math.ceil(Math.abs(dark * 20 - size * size * 10) / (size * size)) - 1) * 10;
      return p;
    };
    let best = forceMask, bestP = Infinity;
    if (best === undefined) {
      for (let m = 0; m < 8; m++) {
        applyMask(m); drawFormat(m);
        const p = penalty();
        if (p < bestP) { bestP = p; best = m; }
        applyMask(m);
      }
    }
    applyMask(best); drawFormat(best);
    return { size, version: ver, mask: best, get: (x, y) => x >= 0 && y >= 0 && x < size && y < size && mod[y][x] };
  }

  function utf8(text) {
    if (typeof Buffer !== 'undefined') return Array.from(Buffer.from(text, 'utf8'));
    return Array.from(new TextEncoder().encode(text));
  }
  const QR = {
    encode: (text, forceMask) => build(utf8(String(text)), forceMask),
    toCanvas(canvas, text, opt) {
      opt = opt || {};
      const q = QR.encode(text), margin = opt.margin === undefined ? 4 : opt.margin;
      const scale = opt.scale || Math.max(2, Math.floor((opt.target || 280) / (q.size + margin * 2)));   // 整数倍缩放，边缘保持锐利
      const n = (q.size + margin * 2) * scale;
      canvas.width = n; canvas.height = n;
      const c = canvas.getContext('2d');
      c.fillStyle = '#fff'; c.fillRect(0, 0, n, n);
      c.fillStyle = '#000';
      for (let y = 0; y < q.size; y++) for (let x = 0; x < q.size; x++)
        if (q.get(x, y)) c.fillRect((x + margin) * scale, (y + margin) * scale, scale, scale);
      return q;
    }
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = QR;
  root.QR = QR;
})(typeof window !== 'undefined' ? window : globalThis);
