'use strict';
/* 电脑 ↔ 电脑「匹配码」配对（Windows 端）—— 纯逻辑，不碰 DOM / socket，方便单元测试。规范见 docs/PROTOCOL.md 第 13 节。
 *
 * 为什么需要：扫码配对要一台设备有摄像头；两台电脑之间更方便的是「一边显示一串数字，另一边输入」。
 *
 * 匹配码 = 10 位数字 = 3 位「房间号」(tag) + 7 位「口令」(secret)，显示成 123-456-7890。
 *   · 房间号是公开的：显示匹配码的电脑会把它放进 UDP 发现广播（字段 t），输入方据此在局域网里找到对应的电脑，
 *     不用输 IP，也不会误拿别人电脑的匹配码去试。它不含口令的任何信息。
 *   · 口令不直接上线：双方先做一次 X25519 临时密钥交换，口令只参与密钥派生，
 *     所以被动旁听局域网的人看不到足够离线穷举口令的材料（HELLO 里没有 HMAC(口令, nonce) 这类东西）。
 *   · 一次性：配对成功即作废；5 分钟过期；错误 5 次作废（防在线暴力猜测）。
 *   · 配对成功后双方互换各自的「长期配对密钥」(pin)，之后的文件互传 / 投屏 / 控制和扫码配对完全一样，不再需要匹配码。
 *
 * 握手（mode = "code"），在 v2 的 CHALLENGE / HELLO / ACCEPT 上做增量：
 *   服务端 CHALLENGE 多一个 epk（服务端临时公钥，hex）——只有「匹配码开着」时才带
 *   客户端 HELLO { mode:"code", epk, cn, id, name, platform, port, auth, pk }
 *   服务端 ACCEPT { ok, ver:2, proof, pk }
 *   K     = HMAC-SHA256(key = 口令, msg = "lancast-code-v1|nonce|cn|客户端epk|服务端epk|X25519共享密钥hex")
 *   auth  = HMAC(K, "cli")          客户端证明自己知道口令
 *   proof = HMAC(K, "srv")          服务端证明自己知道口令（防冒充）
 *   pk    = hex( 本机pin  XOR  HMAC(K, "enc-c" 或 "enc-s") )      互换各自的长期密钥
 */
const crypto = require('crypto');
const proto = require('./proto');

const CODE_TTL_MS = 5 * 60 * 1000;
const MAX_TRIES = 5;
const TAG_LEN = 3, SECRET_LEN = 7, CODE_LEN = TAG_LEN + SECRET_LEN;
const EPK_RE = /^[0-9a-f]{64}$/;
const ID_RE = /^[0-9a-zA-Z]{4,64}$/;
const PIN_RE = /^\d{4,12}$/;
const SPKI_X25519 = Buffer.from('302a300506032b656e032100', 'hex');   // X25519 公钥的 SPKI 前缀，后面接 32 字节原始公钥

/* ───────── 匹配码本身 ───────── */
const digits = len => String(crypto.randomInt(0, Math.pow(10, len))).padStart(len, '0');
function genCode() { const tag = digits(TAG_LEN), secret = digits(SECRET_LEN); return { tag, secret, code: tag + secret }; }
function formatCode(code) { const c = String(code); return c.slice(0, 3) + '-' + c.slice(3, 6) + '-' + c.slice(6); }
/* 用户输入 → { tag, secret }；容忍空格 / 横杠 / 全角数字；不是 10 位数字返回 null */
function parseCode(text) {
  const d = String(text || '').replace(/[\uFF10-\uFF19]/g, c => String.fromCharCode(c.charCodeAt(0) - 0xFF10 + 48)).replace(/\D/g, '');
  return d.length === CODE_LEN ? { tag: d.slice(0, TAG_LEN), secret: d.slice(TAG_LEN) } : null;
}

/* ───────── X25519 + 密钥派生 ───────── */
function newEph() {
  const { publicKey, privateKey } = crypto.generateKeyPairSync('x25519');
  const der = publicKey.export({ type: 'spki', format: 'der' });
  return { priv: privateKey, pub: der.subarray(der.length - 32).toString('hex') };
}
function dh(priv, peerPubHex) {                  // 失败（非法 / 低阶点）抛异常
  const pub = crypto.createPublicKey({ key: Buffer.concat([SPKI_X25519, Buffer.from(peerPubHex, 'hex')]), format: 'der', type: 'spki' });
  const z = crypto.diffieHellman({ privateKey: priv, publicKey: pub });
  if (z.every(b => b === 0)) throw new Error('bad point');
  return z;
}
function deriveK(secret, nonce, cn, cEpk, sEpk, shared) {
  return crypto.createHmac('sha256', secret).update(['lancast-code-v1', nonce, cn, cEpk, sEpk, shared.toString('hex')].join('|')).digest();
}
const sub = (K, label) => crypto.createHmac('sha256', K).update(label).digest();
const xorHex = (str, key) => Buffer.from(Buffer.from(String(str), 'utf8').map((b, i) => b ^ key[i % key.length])).toString('hex');
function unxorHex(hex, key) {
  if (typeof hex !== 'string' || !/^[0-9a-f]{2,64}$/.test(hex) || hex.length % 2) return '';
  return Buffer.from(Buffer.from(hex, 'hex').map((b, i) => b ^ key[i % key.length])).toString('utf8');
}

/* ───────── 服务端：显示匹配码的那台电脑 ───────── */
class CodeHost {
  constructor(opt = {}) { this.now = opt.now || Date.now; this.ttl = opt.ttl || CODE_TTL_MS; this.maxTries = opt.maxTries || MAX_TRIES; this.cur = null; }
  start() { const c = genCode(); this.cur = { tag: c.tag, secret: c.secret, exp: this.now() + this.ttl, tries: 0 }; return this.code; }
  get active() { if (this.cur && this.now() >= this.cur.exp) this.cur = null; return !!this.cur; }
  get tag() { return this.active ? this.cur.tag : ''; }
  get code() { return this.active ? formatCode(this.cur.tag + this.cur.secret) : ''; }
  get remainingMs() { return this.active ? Math.max(0, this.cur.exp - this.now()) : 0; }
  cancel() { this.cur = null; }
}
/* 每个进来的连接发 CHALLENGE 时调用：匹配码开着就生成这条连接专用的临时密钥，其公钥放进 CHALLENGE.epk；没开返回 null */
function serverBegin(host) { return host.active ? newEph() : null; }
/* 校验 HELLO(mode:"code")。成功：匹配码立刻作废，返回 { ok:true, peer, accept }；失败：{ ok:false, reason, burned? } */
function serverVerify(host, eph, j, nonce, myPin, myId) {
  if (!host.active) return { ok: false, reason: '对方没有开启匹配码，或匹配码已过期，请重新生成' };
  if (!eph) return { ok: false, reason: '匹配码刚刚才生成，请重试一次' };
  const cn = typeof j.cn === 'string' ? j.cn : '', epk = typeof j.epk === 'string' ? j.epk : '';
  if (!proto.CN_RE.test(cn) || !EPK_RE.test(epk) || !ID_RE.test(String(j.id || ''))) return { ok: false, reason: '配对信息不完整，请重试' };
  if (j.id === myId) return { ok: false, reason: '不能和本机自己配对' };
  let K;
  try { K = deriveK(host.cur.secret, nonce, cn, epk, eph.pub, dh(eph.priv, epk)); } catch { return { ok: false, reason: '密钥交换失败，请重试' }; }
  if (!proto.constEq(typeof j.auth === 'string' ? j.auth : '', sub(K, 'cli').toString('hex'))) {
    host.cur.tries++;
    if (host.cur.tries >= host.maxTries) { host.cancel(); return { ok: false, burned: true, reason: '匹配码错误次数过多，已失效，请在对方电脑上重新生成' }; }
    return { ok: false, reason: '匹配码不正确' };
  }
  const peerPin = unxorHex(j.pk, sub(K, 'enc-c'));
  if (!PIN_RE.test(peerPin)) return { ok: false, reason: '配对信息不完整，请重试' };
  host.cancel();                                           // 一次性
  return {
    ok: true,
    peer: { id: j.id, name: String(j.name || '未知设备').slice(0, 64), platform: String(j.platform || 'windows').slice(0, 16), port: Number(j.port) || 47800, pin: peerPin, ver: 2 },
    accept: { ok: true, ver: proto.VER, proof: sub(K, 'srv').toString('hex'), pk: xorHex(myPin, sub(K, 'enc-s')) }
  };
}

/* ───────── 客户端：输入匹配码的那台电脑 ───────── */
/* 收到 CHALLENGE 后调用。返回 { hello, st }（hello 发给对方，st 留着校验 ACCEPT）或 { error } */
function clientHello(ch, o) {
  if (!ch || typeof ch.nonce !== 'string' || !EPK_RE.test(String(ch.epk || ''))) return { error: '对方当前没有开启匹配码（请在对方电脑上点「生成匹配码」）' };
  const cn = crypto.randomBytes(16).toString('hex'), e = newEph();
  let K;
  try { K = deriveK(o.secret, ch.nonce, cn, e.pub, ch.epk, dh(e.priv, ch.epk)); } catch { return { error: '密钥交换失败，请重试' }; }
  return {
    st: { K },
    hello: { ver: proto.VER, name: o.name, platform: 'windows', mode: 'code', id: o.id, caps: proto.CAPS, cn, epk: e.pub, port: o.port,
             auth: sub(K, 'cli').toString('hex'), pk: xorHex(o.pin, sub(K, 'enc-c')) }
  };
}
/* 校验 ACCEPT：proof 必须正确（否则对方不知道口令 = 不是要找的设备），并解出对方的长期密钥 */
function clientFinish(st, ch, accept) {
  if (!st || !accept || !proto.constEq(accept.proof || '', sub(st.K, 'srv').toString('hex'))) return { ok: false, error: '对方未通过身份校验，已断开（可能不是你要连接的设备）' };
  const pin = unxorHex(accept.pk, sub(st.K, 'enc-s'));
  if (!PIN_RE.test(pin) || !ID_RE.test(String(ch.id || ''))) return { ok: false, error: '对方返回的配对信息不完整，请重试' };
  return { ok: true, peer: { id: ch.id, name: String(ch.name || '未知设备').slice(0, 64), platform: String(ch.platform || 'windows').slice(0, 16), pin, ver: proto.VER } };
}

module.exports = {
  CODE_TTL_MS, MAX_TRIES, TAG_LEN, SECRET_LEN, CODE_LEN,
  genCode, formatCode, parseCode, newEph, dh, deriveK, sub, xorHex, unxorHex,
  CodeHost, serverBegin, serverVerify, clientHello, clientFinish
};
