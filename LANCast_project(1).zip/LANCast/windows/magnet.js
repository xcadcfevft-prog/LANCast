// 磁力解析：本地解析 magnet URI + aria2c sidecar 拉取元数据(.torrent)并解析文件列表
const { spawn } = require('child_process');
const fs = require('fs'), os = require('os'), path = require('path');

function parseMagnet(uri) {
  if (!/^magnet:\?/i.test(uri)) throw new Error('不是磁力链接');
  const q = new URLSearchParams(uri.slice(uri.indexOf('?') + 1));
  const xt = (q.getAll('xt').find(x => /^urn:btih:/i.test(x)) || '').slice(9);
  if (!xt) throw new Error('缺少 btih');
  let hash = xt;
  if (xt.length === 32) { // base32 -> hex
    const A = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'; let bits = '';
    for (const c of xt.toUpperCase()) bits += A.indexOf(c).toString(2).padStart(5, '0');
    hash = bits.match(/.{4}/g).map(b => parseInt(b, 2).toString(16)).join('').slice(0, 40);
  }
  return { hash: hash.toLowerCase(), name: q.get('dn') || '', trackers: q.getAll('tr') };
}

function bdecode(buf) {
  let i = 0;
  const val = () => {
    const c = String.fromCharCode(buf[i]);
    if (c === 'i') { const e = buf.indexOf(0x65, i); const n = Number(buf.toString('latin1', i + 1, e)); i = e + 1; return n; }
    if (c === 'l') { i++; const a = []; while (buf[i] !== 0x65) a.push(val()); i++; return a; }
    if (c === 'd') { i++; const o = {}; while (buf[i] !== 0x65) { const k = val().toString(); o[k] = val(); } i++; return o; }
    const col = buf.indexOf(0x3a, i), len = Number(buf.toString('latin1', i, col));
    const s = buf.slice(col + 1, col + 1 + len); i = col + 1 + len; return s;
  };
  return val();
}

function parseTorrent(buf) {
  const t = bdecode(buf), info = t.info || t;
  const s = b => (b ? b.toString('utf8') : '');
  const name = s(info.name);
  const files = info.files
    ? info.files.map(f => ({ path: [name, ...f.path.map(s)].join('/'), size: f.length }))
    : [{ path: name, size: info.length }];
  return { name, files, total: files.reduce((a, f) => a + f.size, 0) };
}

function findAria2() {
  const c = [path.join(process.resourcesPath || '', 'bin', 'aria2c.exe'), path.join(__dirname, 'bin', 'aria2c.exe')];
  return c.find(p => fs.existsSync(p)) || 'aria2c';
}

// 返回 {hash,name,trackers,files,total}；超时/无 aria2c 时仅返回 URI 里的信息(files=null)
function resolveMagnet(uri, { timeout = 60, aria2 = findAria2() } = {}) {
  return new Promise((resolve) => {
    let base; try { base = parseMagnet(uri); } catch (e) { return resolve({ error: e.message }); }
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'magnet-'));
    const p = spawn(aria2, ['--bt-metadata-only=true', '--bt-save-metadata=true', '--follow-torrent=false',
      '--enable-dht=true', '--bt-stop-timeout=' + timeout, '-d', dir, uri], { windowsHide: true });
    let done = false;
    const fin = () => {
      if (done) return; done = true; clearTimeout(tm); try { p.kill(); } catch {}
      let r = { ...base, files: null, total: 0 };
      try {
        const f = fs.readdirSync(dir).find(n => n.endsWith('.torrent'));
        if (f) r = { ...base, ...parseTorrent(fs.readFileSync(path.join(dir, f))) };
        else r.error = '未获取到元数据(超时或未安装 aria2c)';
      } catch (e) { r.error = e.message; }
      try { fs.rmSync(dir, { recursive: true, force: true }); } catch {}
      resolve(r);
    };
    const tm = setTimeout(fin, (timeout + 5) * 1000);
    p.on('error', fin); p.on('close', fin);
  });
}

module.exports = { parseMagnet, parseTorrent, bdecode, resolveMagnet };
