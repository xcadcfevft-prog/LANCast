'use strict';
/*
 * 磁力解析（纯 Node 实现，不再依赖 aria2c）
 *
 *   parseMagnet(text)      解析 magnet / thunder:// / 纯哈希；容错：HTML 转义、全角、断行、base32、v2(btmh)、x.pe、tr.N
 *   extractMagnets(text)   从一大段文字里提取全部链接（去重）
 *   resolveMagnet(text,o)  联网取元数据（BEP 9），返回文件列表；Tracker(UDP/HTTP) + DHT + PEX + x.pe 并行找节点，
 *                          元数据 SHA-1/SHA-256 校验、坏节点拉黑、可取消、有进度回调、磁盘/内存缓存
 *   parseTorrent(buf)      解析 .torrent（或裸 info 字典），自动处理 GBK 等老编码、补位文件、v2 file tree
 *
 * 返回结构兼容旧版：{hash,name,trackers,files:[{path,size}],total,error}，另有 torrent(Buffer)/magnet/stats/code 等。
 */
const net = require('net'), dgram = require('dgram'), dns = require('dns'), http = require('http'), https = require('https');
const crypto = require('crypto'), fs = require('fs'), path = require('path');

const sha1 = b => crypto.createHash('sha1').update(b).digest();
const sha256 = b => crypto.createHash('sha256').update(b).digest();

/* ───────────── bencode ───────────── */
class Raw { constructor(buf) { this.buf = buf; } }

function bencode(v) {
  const out = [];
  const str = b => { out.push(Buffer.from(b.length + ':'), b); };
  const enc = x => {
    if (x instanceof Raw) out.push(x.buf);
    else if (Buffer.isBuffer(x) || x instanceof Uint8Array) str(Buffer.from(x));
    else if (typeof x === 'string') str(Buffer.from(x, 'utf8'));
    else if (typeof x === 'number') out.push(Buffer.from('i' + Math.trunc(x) + 'e'));
    else if (typeof x === 'bigint') out.push(Buffer.from('i' + x.toString() + 'e'));
    else if (Array.isArray(x)) { out.push(Buffer.from('l')); x.forEach(enc); out.push(Buffer.from('e')); }
    else if (x && typeof x === 'object') {
      out.push(Buffer.from('d'));
      Object.keys(x).filter(k => x[k] !== undefined).map(k => [Buffer.from(k, 'utf8'), x[k]])
        .sort((a, b) => Buffer.compare(a[0], b[0])).forEach(([k, val]) => { str(k); enc(val); });
      out.push(Buffer.from('e'));
    } else throw new Error('bencode: 不支持的类型');
  };
  enc(v);
  return Buffer.concat(out);
}

function decodeAt(buf, pos, depth, spans) {
  if (depth > 64) throw new Error('bencode 嵌套过深');
  if (pos >= buf.length) throw new Error('bencode 数据被截断');
  const c = buf[pos];
  if (c === 0x69) { // i
    const e = buf.indexOf(0x65, pos + 1);
    if (e < 0) throw new Error('bencode 整数未结束');
    const s = buf.toString('latin1', pos + 1, e);
    if (!/^-?\d+$/.test(s)) throw new Error('bencode 整数非法');
    return [Number(s), e + 1];
  }
  if (c === 0x6c) { // l
    const a = []; pos++;
    while (true) {
      if (pos >= buf.length) throw new Error('bencode 列表被截断');
      if (buf[pos] === 0x65) return [a, pos + 1];
      const [v, n] = decodeAt(buf, pos, depth + 1, spans); a.push(v); pos = n;
    }
  }
  if (c === 0x64) { // d
    const o = Object.create(null); pos++;
    while (true) {
      if (pos >= buf.length) throw new Error('bencode 字典被截断');
      if (buf[pos] === 0x65) return [o, pos + 1];
      const [k, n1] = decodeAt(buf, pos, depth + 1, spans);
      if (!Buffer.isBuffer(k)) throw new Error('bencode 字典键非法');
      const key = k.toString('latin1');
      const [v, n2] = decodeAt(buf, n1, depth + 1, spans);
      if (depth === 0 && spans && key === 'info') spans.info = [n1, n2];
      o[key] = v; pos = n2;
    }
  }
  if (c >= 0x30 && c <= 0x39) {
    const col = buf.indexOf(0x3a, pos);
    if (col < 0 || col - pos > 10) throw new Error('bencode 字符串长度非法');
    const s = buf.toString('latin1', pos, col);
    if (!/^\d+$/.test(s)) throw new Error('bencode 字符串长度非法');
    const end = col + 1 + Number(s);
    if (end > buf.length) throw new Error('bencode 字符串被截断');
    return [buf.subarray(col + 1, end), end];
  }
  throw new Error('bencode 非法字节 0x' + c.toString(16));
}
/** 解码；允许尾部多余数据。spans 传入对象时会写入 spans.info=[start,end]（顶层 info 字典的原始字节范围） */
function bdecode(buf, spans) { return decodeAt(Buffer.from(buf), 0, 0, spans)[0]; }

/* ───────────── 文本 / 哈希 / 链接解析 ───────────── */
const B32 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
function b32ToHex(s) {
  let bits = 0, val = 0; const out = [];
  for (const ch of s.toUpperCase()) {
    const i = B32.indexOf(ch);
    if (i < 0) throw new Error('哈希含有非法字符');
    val = ((val << 5) | i) & 0xfff; bits += 5;
    if (bits >= 8) { out.push((val >>> (bits - 8)) & 255); bits -= 8; val &= (1 << bits) - 1; }
  }
  return Buffer.from(out).toString('hex');
}
function normHash(s) {
  s = String(s || '').trim();
  if (/^[0-9a-f]{40}$/i.test(s)) return s.toLowerCase();
  if (/^[A-Z2-7]{32}$/i.test(s)) return b32ToHex(s);
  return '';
}
/** 全角 ASCII → 半角，HTML 转义还原，去零宽字符和换行 */
function tidy(s) {
  return String(s == null ? '' : s)
    .replace(/[！-～]/g, c => String.fromCharCode(c.charCodeAt(0) - 0xFEE0))
    .replace(/&amp;/gi, '&').replace(/&#38;/g, '&')
    .replace(/[​-‍﻿⁠]/g, '');
}
const dec = (s, plus = true) => {
  if (plus) s = s.replace(/\+/g, ' ');
  return s.replace(/(?:%[0-9a-fA-F]{2})+/g, m => Buffer.from(m.replace(/%/g, ''), 'hex').toString('utf8'));
};
const cleanTr = u => { u = String(u || '').trim(); return /^(udp|https?):\/\/[^\s/]+/i.test(u) ? u : ''; };
function uniq(arr, key = x => x) { const seen = new Set(); return arr.filter(x => { const k = key(x); if (!k || seen.has(k)) return false; seen.add(k); return true; }); }

function parseHostPort(s) {
  const m = /^\[?([^\]\s]+?)\]?:(\d{1,5})$/.exec(String(s).trim());
  if (!m || !+m[2] || +m[2] > 65535) return null;
  return { host: m[1], port: +m[2] };
}

function decodeThunder(s) {
  const b64 = s.replace(/^thunder:\/\//i, '').replace(/-/g, '+').replace(/_/g, '/');
  let t = Buffer.from(b64, 'base64').toString('utf8');
  if (/^AA/.test(t) && /ZZ$/.test(t)) t = t.slice(2, -2);
  return t;
}

function buildMagnet({ hash, hashV2, name, trackers = [] }) {
  let u = 'magnet:?xt=urn:btih:' + hash;
  if (hashV2) u += '&xt=urn:btmh:1220' + hashV2;
  if (name) u += '&dn=' + encodeURIComponent(name);
  for (const t of trackers) u += '&tr=' + encodeURIComponent(t);
  return u;
}

/** 解析单个 magnet:?… 链接（已清洗过的）；失败抛出带中文原因的 Error */
function parseOne(uri) {
  const m = /^magnet:\??(.*)$/is.exec(uri);
  if (!m) throw new Error('不是磁力链接');
  const hashes = [], trackers = [], peers = [], webseeds = [];
  let name = '', size = 0, v2 = '';
  for (const part of m[1].split('&')) {
    const eq = part.indexOf('=');
    if (eq < 0) continue;
    const k = part.slice(0, eq).toLowerCase().replace(/\.\d+$/, ''), raw = part.slice(eq + 1);
    if (k === 'xt') {
      const v = dec(raw, false);
      let x;
      if ((x = /^urn:btih:(.+)$/i.exec(v))) hashes.push(x[1]);
      else if ((x = /^urn:btmh:1220([0-9a-f]{64})$/i.exec(v))) v2 = x[1].toLowerCase();
    } else if (k === 'dn') { if (!name) name = dec(raw).trim(); }
    else if (k === 'tr') { const t = cleanTr(dec(raw, false)); if (t) trackers.push(t); }
    else if (k === 'x.pe') { const p = parseHostPort(dec(raw, false)); if (p) peers.push(p); }
    else if (k === 'ws') { const w = dec(raw, false).trim(); if (/^https?:\/\//i.test(w)) webseeds.push(w); }
    else if (k === 'xl') { size = Number(raw) || 0; }
  }
  let hash = '';
  for (const h of hashes) { hash = normHash(h); if (hash) break; }
  if (!hash && hashes.length) throw new Error('哈希格式不正确（应为 40 位十六进制或 32 位 base32）');
  let v2only = false;
  if (!hash && v2) { hash = v2.slice(0, 40); v2only = true; }
  if (!hash) throw new Error('缺少 btih 哈希');
  const link = { hash, hashV2: v2, v2only, name, size, trackers: uniq(trackers, t => t.toLowerCase()), peers, webseeds: uniq(webseeds) };
  link.magnet = buildMagnet(link);
  return link;
}

/** 从任意文字中提取全部磁力（magnet / thunder / 纯哈希），按哈希去重；无效项被跳过 */
function extractMagnets(text) {
  const t = tidy(text);
  const found = [];
  const push = s => { try { found.push(parseOne(s.replace(/[.,;:!?)\]}>。，；！？）】》”’"']+$/, ''))); } catch {} };
  for (const m of t.matchAll(/magnet:\??[^\s"'<>　「」]+/gi)) push(m[0].replace(/[\r\n\t]/g, ''));
  for (const m of t.matchAll(/thunder:\/\/[A-Za-z0-9+/=_-]+/gi)) { try { for (const l of extractMagnets(decodeThunder(m[0]))) found.push(l); } catch {} }
  if (!found.length) {
    const b = /^\s*(?:urn:)?(?:btih:)?([0-9a-f]{40}|[A-Z2-7]{32})\s*$/i.exec(t);
    if (b) { const h = normHash(b[1]); if (h) found.push(parseOne('magnet:?xt=urn:btih:' + h)); }
  }
  return uniq(found, l => l.hash);
}

/** 解析一条链接；输入可以是 magnet / thunder / 纯哈希 / 夹杂文字的内容；失败抛 Error */
function parseMagnet(input) {
  const t = tidy(input).trim().replace(/^[<"'「]+|[>"'」]+$/g, '');
  if (/^magnet:/i.test(t)) return parseOne(t.replace(/[\r\n\t]/g, ''));
  const all = extractMagnets(t);
  if (all.length) return all[0];
  if (/^thunder:/i.test(t)) throw new Error('迅雷链接里不是磁力链接');
  throw new Error('不是磁力链接');
}

/* ───────────── .torrent / info 字典解析 ───────────── */
function decodeText(buf, hint) {
  if (!buf) return '';
  if (!Buffer.isBuffer(buf)) return String(buf);
  const tryDec = enc => { try { return new TextDecoder(enc, { fatal: true }).decode(buf); } catch { return null; } };
  let r = tryDec('utf-8');
  if (r === null && hint) r = tryDec(String(hint).toLowerCase());
  if (r === null) r = tryDec('gb18030');
  return r === null ? buf.toString('utf8') : r;
}
const safeSeg = s => String(s).replace(/[\u0000-\u001f]/g, '').trim();

function walkTree(tree, prefix, out, enc) {
  for (const k of Object.keys(tree)) {
    const node = tree[k];
    if (k === '') { const len = Number(node && node.length) || 0; out.push({ path: prefix.join('/'), size: len }); continue; }
    const nm = safeSeg(decodeText(Buffer.from(k, 'latin1'), enc));
    if (!nm || nm === '.' || nm === '..' || !node || typeof node !== 'object') continue;
    walkTree(node, [...prefix, nm], out, enc);
  }
}

function parseTorrent(buf) {
  buf = Buffer.from(buf);
  const spans = {};
  const t = bdecode(buf, spans);
  if (!t || typeof t !== 'object' || Array.isArray(t) || Buffer.isBuffer(t)) throw new Error('不是有效的 torrent 数据');
  const info = t.info && !Buffer.isBuffer(t.info) ? t.info : t;
  const infoBuf = t.info && spans.info ? buf.subarray(spans.info[0], spans.info[1]) : buf;
  if (!info.name && !info.files && !info['file tree']) throw new Error('torrent 缺少 info 字典');
  const enc = info.encoding && info.encoding.toString();
  const name = safeSeg(decodeText(info['name.utf-8'] || info.name, enc)) || 'unnamed';
  let files = [], layout = [];
  if (Array.isArray(info.files)) {
    let off = 0;
    for (const f of info.files) {
      const len = Number(f && f.length) || 0;
      const pl = f && (f['path.utf-8'] || f.path);
      const segs = Array.isArray(pl) ? pl.map(x => safeSeg(decodeText(x, enc))).filter(x => x && x !== '.' && x !== '..') : [];
      const pad = !!(f && f.attr && f.attr.toString().includes('p')) || !segs.length;      // BEP 47 补位文件 / 无效路径：占位但不显示、不落盘
      layout.push({ path: pad ? '' : [name, ...segs].join('/'), size: len, offset: off, pad });
      off += len;
    }
    files = layout.filter(x => !x.pad).map(x => ({ path: x.path, size: x.size, offset: x.offset }));
  } else if (info.length !== undefined) {
    files = [{ path: name, size: Number(info.length) || 0, offset: 0 }];
    layout = [{ path: name, size: files[0].size, offset: 0, pad: false }];
  }
  const isV2 = Number(info['meta version']) === 2 && info['file tree'];
  if (!files.length && isV2) {
    const out = []; walkTree(info['file tree'], [], out, enc);
    let off = 0;
    files = out.map(f => { const x = { path: out.length === 1 && f.path === name ? name : name + '/' + f.path, size: f.size, offset: off }; off += f.size; return x; });
    layout = files.map(f => ({ ...f, pad: false }));
  }
  if (!files.length) throw new Error('torrent 中没有文件信息');
  files.forEach((f, i) => { f.index = i; });
  const trackers = [];
  if (t !== info) {
    if (t.announce) trackers.push(t.announce.toString());
    if (Array.isArray(t['announce-list'])) for (const tier of t['announce-list']) if (Array.isArray(tier)) for (const x of tier) trackers.push(x.toString());
  }
  const str = k => (t[k] && Buffer.isBuffer(t[k]) ? decodeText(t[k]) : '');
  return {
    name, files, total: files.reduce((a, f) => a + f.size, 0), fileCount: files.length,
    pieceLength: Number(info['piece length']) || 0,
    pieceCount: info.pieces ? Math.floor(info.pieces.length / 20) : 0,
    private: Number(info.private) === 1,
    comment: str('comment'), createdBy: str('created by'),
    creationDate: t['creation date'] ? Number(t['creation date']) * 1000 : 0,
    trackers: uniq(trackers.map(cleanTr), x => x.toLowerCase()),
    hash: info.pieces || Array.isArray(info.files) || info.length !== undefined ? sha1(infoBuf).toString('hex') : '',
    hashV2: isV2 ? sha256(infoBuf).toString('hex') : '',
    v2: !!isV2,
    layout, pieces: Buffer.isBuffer(info.pieces) ? info.pieces : null      // 下载引擎用：完整文件布局（含补位）与分片哈希
  };
}

function buildTorrent(info, link) {
  const d = { info: new Raw(info), 'created by': 'LANCast' };
  if (link.trackers && link.trackers.length) { d.announce = link.trackers[0]; d['announce-list'] = link.trackers.map(x => [x]); }
  if (link.webseeds && link.webseeds.length) d['url-list'] = link.webseeds;
  return bencode(d);
}

function fmtSize(n) {
  n = Number(n) || 0;
  const u = ['B', 'KB', 'MB', 'GB', 'TB']; let i = 0;
  while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
  return (i === 0 || n >= 100 ? n.toFixed(0) : n >= 10 ? n.toFixed(1) : n.toFixed(2)) + ' ' + u[i];
}

/* ───────────── 网络工具 ───────────── */
const DEFAULT_TRACKERS = [
  'udp://tracker.opentrackr.org:1337/announce', 'udp://open.stealth.si:80/announce',
  'udp://tracker.torrent.eu.org:451/announce', 'udp://exodus.desync.com:6969/announce',
  'udp://open.demonii.com:1337/announce', 'udp://explodie.org:6969/announce',
  'udp://tracker.tiny-vps.com:6969/announce', 'udp://tracker.dler.org:6969/announce',
  'udp://opentracker.io:6969/announce', 'udp://p4p.arenabg.com:1337/announce',
  'udp://open.tracker.cl:1337/announce', 'https://tracker.tamersunion.org:443/announce',
  'udp://tracker.theoks.net:6969/announce', 'udp://tracker.bittor.pw:1337/announce'
];
const DHT_BOOT = [['router.bittorrent.com', 6881], ['router.utorrent.com', 6881], ['dht.transmissionbt.com', 6881],
  ['dht.libtorrent.org', 25401], ['dht.aelitis.com', 6881]];
const MAX_META = 16 * 1024 * 1024, PIECE = 16384, LOCAL_PEX = 1, LOCAL_UT = 2;
const warmNodes = new Map();      // 本次运行中响应过的 DHT 节点，下次解析时直接用，起步更快

const withTimeout = (p, ms) => Promise.race([p, new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), ms))]);
const lookup4 = host => net.isIPv4(host) ? Promise.resolve(host) : withTimeout(dns.promises.lookup(host, { family: 4 }), 6000).then(r => r.address);
const pct = buf => Array.from(buf, b => '%' + b.toString(16).padStart(2, '0')).join('');
const rand32 = () => crypto.randomBytes(4).readUInt32BE(0);

function parseCompact(buf, v6) {
  const sz = v6 ? 18 : 6, out = [];
  if (!Buffer.isBuffer(buf)) return out;
  for (let i = 0; i + sz <= buf.length; i += sz) {
    const port = buf.readUInt16BE(i + sz - 2);
    if (!port) continue;
    let host;
    if (!v6) host = `${buf[i]}.${buf[i + 1]}.${buf[i + 2]}.${buf[i + 3]}`;
    else { const g = []; for (let k = 0; k < 8; k++) g.push(buf.readUInt16BE(i + k * 2).toString(16)); host = g.join(':'); }
    out.push({ host, port });
  }
  return out;
}
function peersFromDict(d) {
  const out = [];
  if (Buffer.isBuffer(d.peers)) out.push(...parseCompact(d.peers, false));
  else if (Array.isArray(d.peers)) for (const p of d.peers) { if (p && p.ip && p.port) out.push({ host: p.ip.toString(), port: Number(p.port) }); }
  if (Buffer.isBuffer(d.peers6)) out.push(...parseCompact(d.peers6, true));
  return out;
}

/* ───────────── Tracker ───────────── */
async function announceUdp(u, ctx) {
  const ip = await lookup4(u.hostname), port = Number(u.port) || 80;
  const sock = dgram.createSocket('udp4'); ctx.sockets.add(sock); sock.on('error', () => {});
  const rpc = (pkt, tid, minLen) => new Promise((res, rej) => {
    let n = 0, timer; const delays = [4000, 8000, 14000];
    const clean = () => { clearTimeout(timer); sock.off('message', onMsg); };
    const onMsg = m => {
      if (m.length < 8 || m.readUInt32BE(4) !== tid) return;
      clean();
      if (m.readUInt32BE(0) === 3) rej(new Error(m.toString('utf8', 8) || 'tracker error'));
      else if (m.length >= minLen) res(m);
    };
    const send = () => {
      if (ctx.done) { clean(); return rej(new Error('stopped')); }
      try { sock.send(pkt, port, ip); } catch (e) { clean(); return rej(e); }
      timer = setTimeout(() => { if (++n >= delays.length) { clean(); rej(new Error('timeout')); } else send(); }, delays[n]);
    };
    sock.on('message', onMsg); send();
  });
  let tid = rand32();
  const c = Buffer.alloc(16); c.writeBigUInt64BE(0x41727101980n, 0); c.writeUInt32BE(0, 8); c.writeUInt32BE(tid, 12);
  const cid = (await rpc(c, tid, 16)).subarray(8, 16);
  tid = rand32();
  const a = Buffer.alloc(98); cid.copy(a, 0); a.writeUInt32BE(1, 8); a.writeUInt32BE(tid, 12);
  ctx.ih.copy(a, 16); ctx.pid.copy(a, 36);
  a.writeBigUInt64BE(BigInt(ctx.left || 1), 64);               // left
  a.writeUInt32BE(2, 80);                   // event=started
  a.writeUInt32BE(rand32(), 88); a.writeInt32BE(200, 92); a.writeUInt16BE(6881, 96);
  const r = await rpc(a, tid, 20);
  const stop = Buffer.from(a); stop.writeUInt32BE(3, 80); stop.writeUInt32BE(rand32(), 12);
  try { sock.send(stop, port, ip); } catch {}
  const ct = setTimeout(() => { try { sock.close(); } catch {} ctx.sockets.delete(sock); }, 300); if (ct.unref) ct.unref();
  return parseCompact(r.subarray(20), false);
}

function announceHttp(u, ctx) {
  return new Promise((res, rej) => {
    const q = `info_hash=${pct(ctx.ih)}&peer_id=${pct(ctx.pid)}&port=6881&uploaded=0&downloaded=0&left=1&compact=1&numwant=200&event=started`;
    const lib = u.protocol === 'https:' ? https : http;
    let req;
    try {
      req = lib.get(u.href + (u.search ? '&' : '?') + q, { timeout: 12000, agent: false, headers: { 'User-Agent': 'LANCast/1.2' } }, r => {
        const chunks = []; let n = 0;
        r.on('data', d => { n += d.length; if (n > 2e6) req.destroy(new Error('响应过大')); else chunks.push(d); });
        r.on('end', () => {
          try {
            if (r.statusCode !== 200) throw new Error('HTTP ' + r.statusCode);
            const d = bdecode(Buffer.concat(chunks));
            if (d['failure reason']) throw new Error(d['failure reason'].toString());
            res(peersFromDict(d));
          } catch (e) { rej(e); }
        });
        r.on('error', rej);
      });
    } catch (e) { return rej(e); }
    ctx.reqs.add(req);
    req.on('timeout', () => req.destroy(new Error('timeout')));
    req.on('error', rej);
  });
}

async function runTracker(url, ctx) {
  let u; try { u = new URL(url); } catch { return; }
  let fails = 0;
  for (let round = 0; round < 3 && !ctx.done; round++) {
    try {
      const peers = u.protocol === 'udp:' ? await announceUdp(u, ctx) : await announceHttp(u, ctx);
      ctx.trackerOk.add(url);
      ctx.addPeers(peers);
      if (peers.length) return;
      await ctx.sleep(20000);
    } catch (e) {
      if (ctx.done || ++fails >= 2) return;
      await ctx.sleep(5000);
    }
  }
}

/* ───────────── DHT（只做 get_peers 查询，只读模式 BEP 43） ───────────── */
class Dht {
  constructor(ctx, boot) {
    this.ctx = ctx; this.boot = boot; this.id = crypto.randomBytes(20);
    this.cands = []; this.seen = new Set(); this.tx = new Map(); this.inflight = 0; this.queries = 0; this.n = 0;
  }
  dist(id) { const t = this.ctx.ih; return Buffer.from(id.map((b, i) => b ^ t[i])).toString('hex'); }
  addCand(id, ip, port) {
    const key = ip + ':' + port;
    if (this.seen.has(key) || !port || this.seen.size > 4000) return;
    this.seen.add(key);
    const c = { id, ip, port, state: 0, d: this.dist(id) };
    let lo = 0, hi = this.cands.length;
    while (lo < hi) { const mid = (lo + hi) >> 1; if (this.cands[mid].d < c.d) lo = mid + 1; else hi = mid; }
    this.cands.splice(lo, 0, c);
  }
  async start() {
    const s = this.sock = dgram.createSocket('udp4');
    this.ctx.sockets.add(s);
    s.on('error', () => {});
    s.on('message', (m, r) => this.onMsg(m, r));
    await new Promise((res, rej) => { s.once('error', rej); s.bind(0, () => { s.off('error', rej); res(); }); });
    const hosts = [...this.boot];
    for (const w of [...warmNodes.values()].slice(-30)) this.sendTo(w.ip, w.port, null);
    for (const [h, p] of hosts) lookup4(h).then(ip => this.sendTo(ip, p, null)).catch(() => {});
    this.timer = setInterval(() => this.pump(), 150);
    this.ctx.timers.add(this.timer);
  }
  sendTo(ip, port, cand) {
    if (this.ctx.done) return;
    const tid = Buffer.alloc(2); tid.writeUInt16BE(this.queries++ & 0xffff);
    const msg = bencode({ t: tid, y: 'q', q: 'get_peers', a: { id: this.id, info_hash: this.ctx.ih }, ro: 1 });
    this.tx.set(tid.toString('hex'), { cand, ts: Date.now() }); this.inflight++;
    try { this.sock.send(msg, port, ip); } catch {}
  }
  pump() {
    const now = Date.now();
    for (const [k, v] of this.tx) if (now - v.ts > 3000) { this.tx.delete(k); this.inflight--; if (v.cand) v.cand.state = 3; }
    while (this.inflight < 12 && this.queries < 2500) {
      const c = this.cands.find(x => x.state === 0);
      if (!c) break;
      c.state = 1; this.sendTo(c.ip, c.port, c);
    }
  }
  onMsg(m, rinfo) {
    let d; try { d = bdecode(m); } catch { return; }
    if (!d || !Buffer.isBuffer(d.t)) return;
    const k = d.t.toString('hex'), tx = this.tx.get(k);
    if (!tx) return;
    this.tx.delete(k); this.inflight--;
    if (d.y && d.y.toString() !== 'r' || !d.r) { if (tx.cand) tx.cand.state = 3; return; }
    if (tx.cand) tx.cand.state = 2;
    this.n++; this.ctx.stats.dhtReplies = this.n;
    warmNodes.set(rinfo.address + ':' + rinfo.port, { ip: rinfo.address, port: rinfo.port });
    if (warmNodes.size > 300) warmNodes.delete(warmNodes.keys().next().value);
    const r = d.r, peers = [];
    if (Array.isArray(r.values)) for (const v of r.values) if (Buffer.isBuffer(v)) peers.push(...parseCompact(v, v.length === 18));
    if (peers.length) this.ctx.addPeers(peers);
    if (Buffer.isBuffer(r.nodes)) {
      for (let i = 0; i + 26 <= r.nodes.length; i += 26) {
        this.addCand(r.nodes.subarray(i, i + 20), `${r.nodes[i + 20]}.${r.nodes[i + 21]}.${r.nodes[i + 22]}.${r.nodes[i + 23]}`, r.nodes.readUInt16BE(i + 24));
      }
    }
    this.pump();
  }
}

/* ───────────── 元数据下载（BEP 9 / BEP 10 / BEP 11） ───────────── */
function mkErr(msg, code, stats) { const e = new Error(msg); e.code = code; e.stats = stats; return e; }

function fetchMetadata(link, o) {
  return new Promise((resolve, reject) => {
    const t0 = Date.now();
    const ih = Buffer.from(link.hash, 'hex');
    const pid = Buffer.concat([Buffer.from('-LC0120-'), crypto.randomBytes(12)]);
    const stats = { peers: 0, tried: 0, connected: 0, withMeta: 0, dhtReplies: 0, badMeta: 0 };
    const active = new Set(), queue = [], seen = new Set(), banned = new Set();
    const ctx = { ih, pid, done: false, sockets: new Set(), reqs: new Set(), timers: new Set(), onStop: [], trackerOk: new Set(), stats };
    const meta = { size: 0, n: 0, buf: null, have: null, from: null, count: 0, flight: null, firstReq: null };
    const maxConns = o.maxConns || 40;
    let lastEmit = 0;

    ctx.sleep = ms => new Promise(res => { const t = setTimeout(res, ms); ctx.timers.add(t); });
    const trackers = uniq([...link.trackers, ...(o.extraTrackers || [])].map(cleanTr), t => t.toLowerCase()).slice(0, o.maxTrackers || 30);

    const snap = () => ({
      elapsed: Date.now() - t0, peers: stats.peers, tried: stats.tried, connected: stats.connected, active: active.size,
      withMeta: stats.withMeta, pieces: meta.count, totalPieces: meta.n, size: meta.size,
      trackers: trackers.length, trackersOk: ctx.trackerOk.size, dhtReplies: stats.dhtReplies,
      stage: meta.count > 0 || stats.withMeta > 0 ? 'metadata' : stats.connected > 0 || stats.peers > 0 ? 'connecting' : 'searching'
    });
    const emit = (force) => {
      if (!o.onProgress || ctx.done) return;
      const now = Date.now(); if (!force && now - lastEmit < 200) return;
      lastEmit = now; try { o.onProgress(snap()); } catch {}
    };

    function finish(err, info) {
      if (ctx.done) return;
      ctx.done = true;
      ctx.timers.forEach(t => { clearTimeout(t); clearInterval(t); });
      if (o.signal) o.signal.removeEventListener('abort', onAbort);
      for (const fn of ctx.onStop) { try { fn(); } catch {} }
      for (const p of [...active]) p.kill();
      for (const r of ctx.reqs) { try { r.destroy(); } catch {} }
      const t = setTimeout(() => ctx.sockets.forEach(s => { try { s.close(); } catch {} }), 300); if (t.unref) t.unref();
      const s = snap();
      if (err) { err.stats = s; reject(err); } else resolve({ info, stats: s });
    }
    const onAbort = () => finish(mkErr('已取消', 'ABORTED'));
    if (o.signal) { if (o.signal.aborted) return reject(mkErr('已取消', 'ABORTED')); o.signal.addEventListener('abort', onAbort); }

    const timeoutErr = () => {
      const s = snap();
      if (stats.badMeta) return mkErr('收到的元数据校验失败（节点返回了错误数据），请稍后重试', 'BAD_META');
      if (!s.peers) return mkErr(`没有找到任何节点（DHT 回应 ${s.dhtReplies} 个，Tracker 成功 ${s.trackersOk}/${s.trackers}）。请检查网络 / 防火墙 / 代理；也可能该资源已无人做种`, 'NO_PEERS');
      if (!s.connected) return mkErr(`找到 ${s.peers} 个节点，但都连不上（可能被防火墙拦截，或节点已离线）`, 'NO_CONNECT');
      if (!s.withMeta) return mkErr(`已连上 ${s.connected} 个节点，但它们都不提供元数据（对方可能强制加密或不支持磁力）`, 'NO_META');
      return mkErr(`元数据只下载了 ${s.pieces}/${s.totalPieces} 片就超时了，请重试`, 'INCOMPLETE');
    };
    ctx.timers.add(setTimeout(() => finish(timeoutErr()), o.timeoutMs));
    ctx.timers.add(setInterval(() => emit(true), 500));

    ctx.addPeers = list => {
      for (const p of list) {
        if (!p || !p.port || !p.host) continue;
        const key = p.host + ':' + p.port;
        if (seen.has(key) || banned.has(p.host) || seen.size >= 3000) continue;
        seen.add(key); queue.push(p); stats.peers++;
      }
      pumpPeers(); emit();
    };

    /* —— 元数据缓冲 —— */
    function initMeta(size) {
      meta.size = size; meta.n = Math.ceil(size / PIECE);
      meta.buf = Buffer.alloc(size); meta.have = new Uint8Array(meta.n); meta.from = new Array(meta.n);
      meta.flight = new Int16Array(meta.n); meta.firstReq = new Float64Array(meta.n);
    }
    const verify = info => {
      try {
        if (!link.v2only || !link.hashV2) { if (!sha1(info).equals(ih)) return false; }
        else if (sha256(info).toString('hex') !== link.hashV2) return false;
        const d = bdecode(info); return !!d && !Buffer.isBuffer(d) && !Array.isArray(d);
      } catch { return false; }
    };
    function finishMeta() {
      if (verify(meta.buf)) return finish(null, Buffer.from(meta.buf));
      stats.badMeta++;
      for (const h of new Set(meta.from)) if (h) banned.add(h);
      for (const p of [...active]) if (banned.has(p.addr.host)) p.kill();
      meta.have.fill(0); meta.count = 0; meta.flight.fill(0); meta.firstReq.fill(0); meta.from = new Array(meta.n);
      for (const p of active) p.inflight.clear();
      schedule();
    }

    /* —— 调度：给每个就绪节点分配还缺的分片 —— */
    const PIPE = 4;
    function pickPiece(peer) {
      let fb = -1; const now = Date.now();
      for (let i = 0; i < meta.n; i++) {
        if (meta.have[i] || peer.inflight.has(i) || peer.rejected.has(i)) continue;
        if (meta.flight[i] === 0) return i;
        if (fb < 0 && meta.flight[i] < 2 && now - meta.firstReq[i] > 3000) fb = i;   // 收尾阶段：慢分片换个节点再要一次
      }
      return fb;
    }
    function schedule() {
      if (!meta.size || ctx.done) return;
      const now = Date.now();
      for (const peer of [...active]) {
        if (!peer.ready || peer.dead) continue;
        for (const [p, ts] of peer.inflight) {
          if (now - ts > 10000) { peer.inflight.delete(p); meta.flight[p]--; if (++peer.stale >= 3) { peer.kill(); break; } }
        }
        if (peer.dead) continue;
        while (peer.inflight.size < PIPE) {
          const p = pickPiece(peer); if (p < 0) break;
          peer.inflight.set(p, now); if (meta.flight[p]++ === 0) meta.firstReq[p] = now;
          sendExt(peer, peer.utId, bencode({ msg_type: 0, piece: p }));
        }
      }
    }
    ctx.timers.add(setInterval(schedule, 1000));

    /* —— 节点连接 —— */
    function sendExt(peer, id, payload) {
      if (peer.dead) return;
      const body = Buffer.concat([Buffer.from([20, id]), payload]), hdr = Buffer.alloc(4);
      hdr.writeUInt32BE(body.length);
      try { peer.sock.write(Buffer.concat([hdr, body])); } catch {}
    }
    function pumpPeers() {
      while (!ctx.done && active.size < maxConns && queue.length) startPeer(queue.shift());
    }
    function startPeer(addr) {
      if (banned.has(addr.host)) return;
      stats.tried++;
      const sock = net.connect({ host: addr.host, port: addr.port });
      sock.setNoDelay(true);
      const peer = { addr, sock, buf: Buffer.alloc(0), shook: false, utId: 0, inflight: new Map(), rejected: new Set(), ready: false, dead: false, stale: 0, timer: null };
      active.add(peer);
      peer.kill = () => {
        if (peer.dead) return; peer.dead = true; clearTimeout(peer.timer);
        try { sock.destroy(); } catch {}
        active.delete(peer);
        if (peer.ready) stats.withMeta--;
        if (meta.flight) for (const p of peer.inflight.keys()) meta.flight[p]--;
        peer.inflight.clear();
        if (!ctx.done) { pumpPeers(); schedule(); emit(); }
      };
      const arm = (ms, why) => { clearTimeout(peer.timer); peer.timer = setTimeout(() => peer.kill(why), ms); };
      arm(7000);
      sock.once('connect', () => {
        stats.connected++; arm(10000);
        const hs = Buffer.alloc(68); hs[0] = 19; hs.write('BitTorrent protocol', 1, 'latin1'); hs[25] = 0x10;
        ih.copy(hs, 28); pid.copy(hs, 48); sock.write(hs);
        emit();
      });
      sock.on('data', d => {
        peer.buf = peer.buf.length ? Buffer.concat([peer.buf, d]) : d;
        try { onData(peer, arm); } catch { peer.kill(); }
      });
      sock.on('error', () => peer.kill()); sock.on('close', () => peer.kill());
    }
    function onData(peer, arm) {
      if (!peer.shook) {
        if (peer.buf.length < 68) return;
        if (peer.buf[0] !== 19 || peer.buf.toString('latin1', 1, 20) !== 'BitTorrent protocol') throw new Error('not bt');
        if (!peer.buf.subarray(28, 48).equals(ih)) throw new Error('infohash');
        if (!(peer.buf[25] & 0x10)) throw new Error('no ext');
        peer.buf = peer.buf.subarray(68); peer.shook = true;
        sendExt(peer, 0, bencode({ m: { ut_metadata: LOCAL_UT, ut_pex: LOCAL_PEX }, v: 'LANCast', reqq: 16 }));
        arm(12000);
      }
      while (peer.buf.length >= 4) {
        const len = peer.buf.readUInt32BE(0);
        if (len > 4 * 1024 * 1024) throw new Error('too big');
        if (peer.buf.length < 4 + len) break;
        const msg = peer.buf.subarray(4, 4 + len); peer.buf = peer.buf.subarray(4 + len);
        if (len > 1 && msg[0] === 20) onExt(peer, msg[1], msg.subarray(2), arm);
      }
    }
    function onExt(peer, id, payload, arm) {
      if (id === 0) {                                   // 对方的扩展握手
        const d = bdecode(payload), m = d.m || {};
        if (typeof m.ut_pex === 'number') peer.pexId = m.ut_pex;
        const ut = m.ut_metadata, size = Number(d.metadata_size);
        if (typeof ut === 'number' && ut > 0 && size > 0 && size <= MAX_META) {
          if (!meta.size) initMeta(size);
          if (size !== meta.size) throw new Error('size mismatch');
          peer.utId = ut;
          if (!peer.ready) { peer.ready = true; stats.withMeta++; }
          arm(30000); schedule(); emit();
        }
      } else if (id === LOCAL_UT) {
        const [h, end] = decodeAt(payload, 0, 0);
        const type = Number(h.msg_type), piece = Number(h.piece);
        if (type === 0) { if (peer.utId) sendExt(peer, peer.utId, bencode({ msg_type: 2, piece })); }
        else if (type === 1) {
          if (!meta.size || !Number.isInteger(piece) || piece < 0 || piece >= meta.n) throw new Error('bad piece');
          const data = payload.subarray(end), want = Math.min(PIECE, meta.size - piece * PIECE);
          if (data.length !== want) throw new Error('bad piece len');
          if (peer.inflight.delete(piece)) meta.flight[piece]--;
          arm(30000);
          if (!meta.have[piece]) {
            data.copy(meta.buf, piece * PIECE); meta.have[piece] = 1; meta.from[piece] = peer.addr.host;
            if (++meta.count === meta.n) return finishMeta();
          }
          schedule(); emit();
        } else if (type === 2) {
          peer.rejected.add(piece);
          if (peer.inflight.delete(piece)) meta.flight[piece]--;
          if (meta.n && peer.rejected.size >= meta.n) return peer.kill();
          schedule();
        }
      } else if (id === LOCAL_PEX) {
        const d = bdecode(payload), ps = [];
        if (Buffer.isBuffer(d.added)) ps.push(...parseCompact(d.added, false));
        if (Buffer.isBuffer(d.added6)) ps.push(...parseCompact(d.added6, true));
        if (ps.length) ctx.addPeers(ps);
      }
    }

    /* —— 启动各路寻址来源 —— */
    ctx.addPeers(link.peers);
    for (const tr of trackers) runTracker(tr, ctx).catch(() => {});
    if (o.dht !== false) {
      const dht = new Dht(ctx, o.dhtBootstrap || DHT_BOOT);
      dht.start().catch(() => {});
    }
    emit(true);
  });
}

/** 持续寻找节点（Tracker + DHT），durationMs 后自动停止。onPeers(list) 逐批回调；返回 {stop, stats}。下载引擎用 */
function discoverPeers({ hash, trackers = [], extraTrackers = DEFAULT_TRACKERS, dht = true, dhtBootstrap = DHT_BOOT, durationMs = 90000, left = 1, onPeers }) {
  const ih = Buffer.from(hash, 'hex'), stats = { dhtReplies: 0 };
  const ctx = { ih, pid: Buffer.concat([Buffer.from('-LC0120-'), crypto.randomBytes(12)]), done: false, sockets: new Set(), reqs: new Set(), timers: new Set(), onStop: [], trackerOk: new Set(), stats, left };
  ctx.sleep = ms => new Promise(res => { const t = setTimeout(res, ms); ctx.timers.add(t); });
  ctx.addPeers = list => { if (!ctx.done && list.length) onPeers(list.filter(p => p && p.port && p.host)); };
  const stop = () => {
    if (ctx.done) return; ctx.done = true;
    ctx.timers.forEach(t => { clearTimeout(t); clearInterval(t); });
    for (const r of ctx.reqs) { try { r.destroy(); } catch {} }
    ctx.sockets.forEach(s => { try { s.close(); } catch {} });
  };
  for (const tr of uniq([...trackers, ...(extraTrackers || [])].map(cleanTr), t => t.toLowerCase()).slice(0, 30)) runTracker(tr, ctx).catch(() => {});
  if (dht) new Dht(ctx, dhtBootstrap).start().catch(() => {});
  ctx.timers.add(setTimeout(stop, durationMs));
  return { stop, stats };
}

/* ───────────── 对外接口 ───────────── */
const memCache = new Map();
function cacheFile(dir, hash) { return path.join(dir, hash + '.torrent'); }
function cacheGet(dir, link) {
  try {
    const buf = fs.readFileSync(cacheFile(dir, link.hash));
    const m = parseTorrent(buf);
    if (link.v2only ? m.hashV2.slice(0, 40) === link.hash : m.hash === link.hash) return { buf, m };
  } catch {}
  return null;
}
function cachePut(dir, hash, buf) {
  try {
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(cacheFile(dir, hash), buf);
    const all = fs.readdirSync(dir).filter(n => n.endsWith('.torrent')).map(n => ({ n, t: fs.statSync(path.join(dir, n)).mtimeMs })).sort((a, b) => b.t - a.t);
    for (const x of all.slice(300)) { try { fs.unlinkSync(path.join(dir, x.n)); } catch {} }
  } catch {}
}

/**
 * 联网解析磁力。opts:
 *   timeout(秒,默认60)  onProgress(snap)  signal(AbortSignal)  cacheDir(磁盘缓存目录)  noCache
 *   extraTrackers(默认 DEFAULT_TRACKERS，传 [] 关闭)  dht(false 关闭)  dhtBootstrap  maxConns  maxTrackers
 */
async function resolveMagnet(input, opts = {}) {
  let link;
  try { link = parseMagnet(input); } catch (e) { return { error: e.message, code: 'INVALID' }; }
  const base = { hash: link.hash, hashV2: link.hashV2, name: link.name, trackers: link.trackers, magnet: link.magnet };
  const fromTorrent = (buf, m, extra) => ({
    ...base, ...m, hash: link.hash, hashV2: link.hashV2 || m.hashV2, name: m.name || link.name,
    trackers: uniq([...link.trackers, ...m.trackers], t => t.toLowerCase()), torrent: buf,
    magnet: buildMagnet({ hash: link.hash, hashV2: link.hashV2, name: m.name || link.name, trackers: uniq([...link.trackers, ...m.trackers], t => t.toLowerCase()).slice(0, 8) }), ...extra
  });
  if (!opts.noCache) {
    const mc = memCache.get(link.hash);
    if (mc) return { ...mc, fromCache: true, elapsedMs: 0 };
    if (opts.cacheDir) { const c = cacheGet(opts.cacheDir, link); if (c) { const r = fromTorrent(c.buf, c.m, { fromCache: true, elapsedMs: 0 }); memCache.set(link.hash, r); return r; } }
  }
  const t0 = Date.now();
  try {
    const { info, stats } = await fetchMetadata(link, {
      timeoutMs: (opts.timeout || 60) * 1000, onProgress: opts.onProgress, signal: opts.signal,
      extraTrackers: opts.extraTrackers === undefined ? DEFAULT_TRACKERS : opts.extraTrackers,
      dht: opts.dht, dhtBootstrap: opts.dhtBootstrap, maxConns: opts.maxConns, maxTrackers: opts.maxTrackers
    });
    const torrent = buildTorrent(info, link), m = parseTorrent(torrent);
    const r = fromTorrent(torrent, m, { stats, elapsedMs: Date.now() - t0, fromCache: false });
    if (!opts.noCache) { memCache.set(link.hash, r); if (memCache.size > 50) memCache.delete(memCache.keys().next().value); if (opts.cacheDir) cachePut(opts.cacheDir, link.hash, torrent); }
    return r;
  } catch (e) {
    return { ...base, files: null, total: 0, error: e.message, code: e.code || 'ERROR', stats: e.stats, elapsedMs: Date.now() - t0 };
  }
}
function clearCache() { memCache.clear(); }

module.exports = {
  parseMagnet, extractMagnets, parseTorrent, buildTorrent, buildMagnet, bdecode, bencode, resolveMagnet, clearCache, fmtSize,
  discoverPeers, DEFAULT_TRACKERS, _internal: { Raw, decodeAt, b32ToHex, normHash, parseCompact, warmNodes }
};
