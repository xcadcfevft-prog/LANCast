'use strict';
/* 瞬流「安全聊天」界面（Windows 端，渲染进程）。
 * 与 renderer.js / filexfer.js 一样是页面里的普通脚本，直接使用它们的全局：connectTo / pairedDevices / peerAction / ask / toast / myId / myName / myPin / PORT。
 * 连接管理、加密、消息状态都在 chathub.js（有单元测试）；这里只负责：把真实的 Session 接给它、画界面、通知。
 * 「联通」：聊天窗口里的 发文件 = 现成的文件互传（FX），屏幕共享 = 现成的投屏 / 远程控制（peerAction）；
 *           传输中的文件会作为卡片出现在对话里，投屏期间聊天照常可用（观看投屏时新消息以提示条出现）。 */
(function () {
  if (typeof document === 'undefined' || !document.querySelector('#chat')) return;
  const { createHub } = require('./chathub');
  const VC = require('./voice');
  const CC = require('./chatcrypto');
  const DATA = window.CHAT_DATA || require('./chatdata');
  const { ipcRenderer } = require('electron');

  const el = $('#chat'), listEl = $('#chatList'), msgsEl = $('#chatMsgs'), input = $('#chatInput'), panel = $('#chatPanel');
  const S = { open: false, cur: null, tab: 'e0', rows: new Map(), noteT: 0, lastSig: '' };
  const KEEP_UNREAD_KEY = 'chat:unread';

  /* ───────── 存储 / Hub ───────── */
  const store = {
    load: id => { try { const a = JSON.parse(LS.get('chat:' + id, '[]')); return Array.isArray(a) ? a : []; } catch { return []; } },
    save: (id, a) => LS.set('chat:' + id, JSON.stringify(a)),
    loadUnread: () => { try { return JSON.parse(LS.get(KEEP_UNREAD_KEY, '{}')) || {}; } catch { return {}; } },
    saveUnread: o => LS.set(KEEP_UNREAD_KEY, JSON.stringify(o))
  };
  const hub = createHub({
    myId, myName, myPin: () => myPin, store,
    peers: () => pairedDevices().map(p => ({ id: p.id, name: p.name, pin: p.pin, ip: p.ip, port: p.port, platform: p.platform, online: p.online })),
    dial: async p => {
      const s = await connectTo(p.ip, p.port || PORT, p.pin, 'chat');
      return { session: s, serverNonce: s.hsNonce, clientNonce: s.cn };
    },
    changed: () => schedule(),
    notify: onNotify
  });
  setInterval(() => {
    hub.tick();
    if (S.open && S.cur && !hub.isConnected(S.cur) && !hub.connections(S.cur)) { const p = peerOf(S.cur); if (p && p.online) hub.ensure(S.cur); }
    refreshHeader();
  }, 1000);

  const CH = window.CH = {
    unread: id => hub.unread(id),
    /* 对方（本机作服务端）以 mode = "chat" 连进来：必须是已配对设备、且是 v2（有 clientNonce）才接受 */
    check(s) {
      if (!s.peerId) return '对方没有提供设备 ID，请升级对方的瞬流';
      if (s.peerVer < 2 || !s.clientNonce) return '对方版本不支持安全聊天，请升级';
      if (!loadPairs().some(p => p.id === s.peerId)) return '本机没有和你配对，请先配对';
      return '';
    },
    onIncoming(s) {
      const pr = loadPairs().find(p => p.id === s.peerId);
      hub.attach(s, { peerId: s.peerId, isClient: false, serverNonce: s.nonce, clientNonce: s.clientNonce, pin: myPin + ':' + (pr ? pr.pin : ''), peerName: s.peerName });
    },
    forget(id) { call.peerGone(id); hub.dropPeer(id); if (S.cur === id) S.cur = null; schedule(); },
    open(id) { openChat(id); },
    hub
  };

/* ───────── 无损语音通话 ─────────
   信令 / 音频走同一条加密聊天连接（hub.sendSignal / hub.sendVoice），引擎和状态机在 voice.js。 */
  const callBar = $('#callBar'), callTx = callBar.querySelector('.tx');
  const call = VC.createCall({
    hub, makeEngine: VC.createBrowserEngine,
    onState: st => { onCallState(st); }
  });
  hub.voice = { onSignal: (id, m) => call.onSignal(id, m), onAudio: (id, b) => call.onAudio(id, b) };
  let lastPhase = 'idle', callTimer = 0;
  const mmss = ms => { const s = Math.max(0, Math.floor(ms / 1000)); return pad(Math.floor(s / 60)) + ':' + pad(s % 60); };
  function callName() { const p = call.state.peerId && peerOf(call.state.peerId); return p ? p.name : '对方'; }
  function paintCall() {
    const st = call.state;
    callBar.hidden = st.phase === 'idle';
    callBar.className = st.phase === 'ringing' ? 'ring' : '';
    $('#callAns').hidden = st.phase !== 'ringing';
    $('#callMute').hidden = st.phase !== 'active';
    $('#callMute').textContent = st.muted ? '🔇 取消静音' : '🎙 静音';
    $('#callEnd').textContent = st.phase === 'ringing' ? '拒绝' : st.phase === 'calling' ? '取消' : '挂断';
    callTx.textContent = st.phase === 'calling' ? '📞 正在呼叫「' + callName() + '」…'
      : st.phase === 'ringing' ? '📞「' + callName() + '」邀请你无损语音通话'
      : st.phase === 'active' ? '🎙 与「' + callName() + '」通话中 ' + mmss(Date.now() - st.since) + ' · 无损 PCM 48 kHz / 16 bit · 请戴耳机' : '';
    const b = $('#chatCall'); if (b) { b.classList.toggle('on', st.phase === 'active'); b.textContent = st.phase === 'idle' ? '📞 语音通话' : '📞 通话中'; }
    if (document.body) document.body.style.paddingTop = st.phase === 'idle' ? '' : '44px';
  }
  function onCallState(st) {
    paintCall();
    if (st.phase === 'ringing' && lastPhase !== 'ringing') {                  // 来电：弹到前台、切到对方的聊天
      const nm = callName();
      try { ipcRenderer.send('flash'); } catch {}
      if (!document.hasFocus()) { try { const n = new Notification(nm, { body: '邀请你无损语音通话', silent: false }); n.onclick = () => { ipcRenderer.send('focus'); }; } catch {} }
      if ($('#viewer').hidden) openChat(st.peerId);
    }
    if (st.phase === 'idle' && lastPhase !== 'idle' && st.reason) toast('📞 ' + st.reason);
    lastPhase = st.phase;
    clearInterval(callTimer); callTimer = st.phase === 'active' ? setInterval(paintCall, 1000) : 0;
  }
  setInterval(() => call.tick(), 1000);
  $('#callAns').onclick = () => call.answer();
  $('#callMute').onclick = () => call.mute(!call.state.muted);
  $('#callEnd').onclick = () => { const ph = call.state.phase; if (ph === 'ringing') call.decline(); else call.hangup(); };
  $('#chatCall').onclick = () => {
    const p = S.cur && peerOf(S.cur); if (!p) return;
    if (call.state.phase !== 'idle') { toast('已经有一通电话了'); return; }
    if (!p.online) { toast('对方当前不在线，无法通话'); return; }
    hub.ensure(p.id); call.start(p.id);
  };

  /* ───────── 工具 ───────── */
  const peerOf = id => pairedDevices().find(p => p.id === id) || null;
  const pad = n => String(n).padStart(2, '0');
  function fmtTime(ts) {
    const d = new Date(ts), now = new Date(), hm = pad(d.getHours()) + ':' + pad(d.getMinutes());
    if (d.toDateString() === now.toDateString()) return hm;
    const y = new Date(now - 86400000);
    return (d.toDateString() === y.toDateString() ? '昨天 ' : (d.getMonth() + 1) + '月' + d.getDate() + '日 ') + hm;
  }
  const preview = m => m.k === 's' ? '[表情包] ' + (m.c || m.e) : String(m.x || '').replace(/\s+/g, ' ').slice(0, 40);
  let rt = 0;
  function schedule() { if (rt) return; rt = setTimeout(() => { rt = 0; render(); }, 120); }

  /* ───────── 通知 ───────── */
  function onNotify({ peerId, name, msg }) {
    const looking = S.open && S.cur === peerId && document.hasFocus();
    if (looking) return;
    updateBadge();
    if (!$('#viewer').hidden) { toast('💬 ' + name + '：' + preview(msg)); return; }       // 正在看对方屏幕：用提示条
    try { ipcRenderer.send('flash'); } catch {}
    if (!document.hasFocus()) {
      try { const n = new Notification(name, { body: preview(msg), silent: false }); n.onclick = () => { ipcRenderer.send('focus'); openChat(peerId); }; } catch {}
    }
  }
  function updateBadge() {
    const n = hub.totalUnread(), b = $('#chatBadge');
    b.hidden = !n; b.textContent = n > 99 ? '99+' : n;
    document.title = n ? '（' + n + '）瞬流' : '瞬流';
  }

  /* ───────── 显示 / 隐藏 ───────── */
  function openChat(id) {
    const list = pairedDevices();
    S.open = true;
    S.cur = id && list.some(p => p.id === id) ? id : (S.cur && list.some(p => p.id === S.cur) ? S.cur : (list[0] && list[0].id) || null);
    $('#home').hidden = true; el.hidden = false; $('#viewer').hidden = true;
    hub.viewing = S.cur; if (S.cur) { hub.markRead(S.cur); hub.ensure(S.cur); }
    S.rows.clear(); msgsEl.innerHTML = ''; panel.hidden = true;
    render(true); input.focus();
  }
  function closeChat() {
    S.open = false; hub.viewing = null; el.hidden = true; $('#home').hidden = false; panel.hidden = true;
    renderPeers(); updateBadge();
  }
  /* 投屏（观看）会盖住整个窗口：开始时让位，结束后如果之前在聊天，回到聊天 */
  const origShowViewer = window.showViewer;
  window.showViewer = function (on) {
    origShowViewer(on);
    if (on) { el.hidden = true; if (S.open) hub.viewing = null; }
    else if (S.open) { $('#home').hidden = true; el.hidden = false; hub.viewing = S.cur; if (S.cur) hub.markRead(S.cur); render(true); }
  };
  /* 聊天窗口里也要看得到「连接中 / 正忙 / 失败」之类的状态提示（原来的状态栏在首页，聊天时看不到） */
  const origSetStatus = window.setStatus;
  window.setStatus = function (msg, err) {
    origSetStatus(msg, err);
    if (!S.open) return;
    const n = $('#chatNote'); n.textContent = msg; n.className = err ? 'err' : ''; n.hidden = !msg;
    clearTimeout(S.noteT); S.noteT = setTimeout(() => { n.hidden = true; }, 7000);
  };

  /* ───────── 渲染 ───────── */
  function refreshHeader() {
    if (!S.open) return;
    const p = S.cur ? peerOf(S.cur) : null;
    $('#chatTitle').textContent = p ? p.name : '选择一台设备开始聊天';
    const sub = $('#chatSub');
    if (!p) { sub.textContent = ''; sub.className = ''; }
    else if (hub.isConnected(p.id)) { sub.textContent = '🔒 端到端加密 · 已连接'; sub.className = 'up'; }
    else if (p.online) { sub.textContent = '🔒 端到端加密 · 对方在线，正在建立加密连接…'; sub.className = ''; }
    else { sub.textContent = '对方当前不在线（发出的消息在对方上线后无法补发，30 秒后会标记失败，可点击重试）'; sub.className = ''; }
    const pr = p ? hub.pendingRecalls(p.id) : 0;
    if (pr) sub.textContent += ' · 有 ' + pr + ' 条撤回等对方上线后生效';
    for (const id of ['#chatCall', '#chatFile', '#chatScreen', '#chatMore', '#chatSend', '#chatEmoji', '#chatStk']) $(id).disabled = !p;
    input.disabled = !p;
  }
  function renderList() {
    const list = pairedDevices().map(p => {
      const a = hub.messages(p.id), last = a.length ? a[a.length - 1] : null;
      return { p, last, ts: last ? last.ts : 0 };
    }).sort((a, b) => (b.p.online - a.p.online) || (b.ts - a.ts) || a.p.name.localeCompare(b.p.name));
    const sig = JSON.stringify(list.map(x => [x.p.id, x.p.name, x.p.online, hub.unread(x.p.id), x.last && x.last.id, x.last && x.last.st, x.p.id === S.cur]));
    if (sig === S.lastSig) return; S.lastSig = sig;
    listEl.innerHTML = '';
    if (!list.length) { const d = document.createElement('div'); d.className = 'empty'; d.style.padding = '14px'; d.textContent = '还没有配对的设备。先在首页配对（手机扫码 / 电脑匹配码）。'; listEl.appendChild(d); return; }
    for (const { p, last } of list) {
      const d = document.createElement('div'); d.className = 'ci' + (p.id === S.cur ? ' on' : '');
      d.innerHTML = '<span class="dot"></span><div class="nm"><b></b><span></span></div>';
      d.querySelector('.dot').classList.toggle('up', p.online);
      d.querySelector('b').textContent = p.name;
      d.querySelector('.nm span').textContent = last ? (last.from === 'me' ? '我：' : '') + preview(last) : (p.online ? '在线' : '离线');
      const n = hub.unread(p.id);
      if (n) { const b = document.createElement('span'); b.className = 'badge'; b.textContent = n > 99 ? '99+' : n; b.style.cssText = 'margin:0;font-size:11px;color:#fff'; d.appendChild(b); }
      d.onclick = () => { if (S.cur === p.id) return; S.cur = p.id; hub.viewing = p.id; hub.markRead(p.id); hub.ensure(p.id); S.rows.clear(); msgsEl.innerHTML = ''; render(true); input.focus(); };
      listEl.appendChild(d);
    }
  }
  function stickerEl(m) {
    const d = document.createElement('div'); d.className = 'stk';
    const bg = Array.isArray(m.bg) && m.bg.length === 2 ? m.bg : ['#fff3c4', '#ffd37a'];
    d.style.background = 'linear-gradient(160deg,' + bg[0] + ',' + bg[1] + ')';
    const e = document.createElement('div'); e.className = 'em'; e.textContent = m.e;
    const c = document.createElement('div'); c.className = 'cap'; c.textContent = m.c || '';
    d.appendChild(e); d.appendChild(c); return d;
  }
  function msgRow(m) {
    const box = document.createElement('div'); box.className = 'cm ' + (m.from === 'me' ? 'me' : 'peer');
    const t = document.createElement('div'); t.className = 't'; box.appendChild(t);
    const body = m.k === 's' ? stickerEl(m) : (() => { const b = document.createElement('div'); b.className = 'bub'; b.textContent = m.x; return b; })();
    box.appendChild(body);
    const line = document.createElement('div'); line.className = 'st'; box.appendChild(line);
    const st = document.createElement('span'); line.appendChild(st);
    let rc = null;
    if (m.from === 'me') {                                    // 撤回：只有自己发的消息有，没有时间限制，两边一起删
      rc = document.createElement('span'); rc.className = 'rc'; rc.textContent = '撤回'; rc.title = '从你和对方的聊天记录里一起删除这条消息';
      rc.onclick = () => recallMsg(m.id);
      line.appendChild(rc);
    }
    return { box, t, st, line, rc, kind: 'm' };
  }
  function fileRow() {
    const box = document.createElement('div'); box.className = 'cf';
    box.innerHTML = '<div class="ft"><b></b><span></span></div><progress max="1000" value="0"></progress><div class="fs"><span class="fi"></span><span class="fb"></span></div>';
    return { box, n: box.querySelector('b'), d: box.querySelector('.ft span'), p: box.querySelector('progress'), i: box.querySelector('.fi'), b: box.querySelector('.fb'), btn: '', kind: 'f' };
  }
  function updateMsg(r, m) {
    r.t.textContent = fmtTime(m.ts);
    if (m.from === 'me') {
      r.st.textContent = m.st === 'sent' ? '✓ 已送达' : m.st === 'failed' ? '❗ 发送失败，点击重试' : '发送中…';
      r.line.className = 'st' + (m.st === 'failed' ? ' bad' : '');
      r.st.onclick = m.st === 'failed' ? () => hub.retry(S.cur, m.id) : null;
    } else { r.st.textContent = ''; r.line.className = 'st'; }
  }
  function updateFile(r, x) {
    const active = FX.ACTIVE.has(x.state);
    r.box.className = 'cf ' + (x.dir === 'send' ? 'me' : 'peer');
    r.n.textContent = '📎 ' + x.name;
    r.d.textContent = x.dir === 'send' ? '发出的文件' : '收到的文件';
    r.p.value = x.size ? Math.min(1000, Math.round(x.done / x.size * 1000)) : (x.state === 'done' ? 1000 : 0);
    r.p.className = x.state;
    r.i.textContent = FX.stateText(x);
    r.i.style.color = x.state === 'failed' ? 'var(--warn)' : x.state === 'done' ? 'var(--ok)' : 'var(--muted)';
    const want = active ? 'cancel' : (x.state === 'done' && x.dir === 'recv' && x.saved ? 'show' : '');
    if (r.btn !== want) {
      r.btn = want; r.b.innerHTML = '';
      if (want) {
        const b = document.createElement('button'); b.textContent = want === 'cancel' ? '取消' : '在文件夹中显示';
        b.onclick = want === 'cancel' ? () => FX.cancelX(x) : () => ipcRenderer.send('show-item', x.saved);
        r.b.appendChild(b);
      }
    }
  }
  async function recallMsg(msgId) {
    const id = S.cur; if (!id) return;
    const p = peerOf(id), who = p ? '「' + p.name + '」' : '对方';
    const r = await ask('撤回这条消息？', '撤回后，这条消息会从你和' + who + '的聊天记录里一起删除，没有时间限制，对方看不到任何痕迹。\n\n（如果对方现在不在线，会在对方上线后自动撤回。已经被对方复制、截图的内容无法收回。）', { buttons: ['撤回', '取消'] });
    if (r.i === 0) { hub.recall(id, msgId); render(); }
  }
  function renderMsgs(force) {
    const id = S.cur;
    if (!id) { msgsEl.innerHTML = ''; S.rows.clear(); return; }
    const items = [];
    for (const m of hub.messages(id)) items.push({ key: 'm' + m.id, ts: m.ts, m });
    for (const x of FX.xfers || []) if (x.peerId === id) items.push({ key: 'x' + x.seq, ts: x.t0, x, seq: x.seq });
    items.sort((a, b) => (a.ts - b.ts) || ((b.seq | 0) - (a.seq | 0)));
    const near = msgsEl.scrollHeight - msgsEl.scrollTop - msgsEl.clientHeight < 80;
    const keep = new Set();
    for (const it of items) {
      keep.add(it.key);
      let r = S.rows.get(it.key);
      if (!r) { r = it.m ? msgRow(it.m) : fileRow(); S.rows.set(it.key, r); }
      if (it.m) updateMsg(r, it.m); else updateFile(r, it.x);
    }
    for (const [k, r] of [...S.rows]) if (!keep.has(k)) { r.box.remove(); S.rows.delete(k); }
    let i = 0;
    const empty = document.getElementById('chatEmpty');
    if (items.length && empty) empty.remove();
    for (const it of items) { const b = S.rows.get(it.key).box; if (msgsEl.children[i] !== b) msgsEl.insertBefore(b, msgsEl.children[i] || null); i++; }
    if (!items.length && !empty) {
      const d = document.createElement('div'); d.id = 'chatEmpty';
      d.innerHTML = '🔒 消息经过端到端加密，只有你们两台设备看得到<br>可以发文字、表情包，📎 传文件，🖥 随时开始屏幕共享<br>也可以把文件直接拖进这个窗口';
      msgsEl.appendChild(d);
    }
    if (force || near) msgsEl.scrollTop = msgsEl.scrollHeight;
  }
  function render(force) {
    if (!S.open) { updateBadge(); return; }
    if (S.cur && hub.viewing === S.cur && hub.unread(S.cur)) hub.markRead(S.cur);
    renderList(); refreshHeader(); renderMsgs(force); updateBadge();
  }
  FX.onChange = () => { if (S.open) schedule(); };

  /* ───────── 输入 / 表情面板 ───────── */
  function send() {
    const t = input.value;
    if (!S.cur || !t.trim()) return;
    hub.sendText(S.cur, t); input.value = ''; autoGrow(); render(true); input.focus();
  }
  function autoGrow() { input.style.height = 'auto'; input.style.height = Math.min(120, input.scrollHeight) + 'px'; }
  input.addEventListener('input', autoGrow);
  input.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey && !e.isComposing && e.keyCode !== 229) { e.preventDefault(); send(); } });
  $('#chatSend').onclick = send;

  function insertAtCursor(s) {
    const a = input.selectionStart, b = input.selectionEnd, v = input.value;
    input.value = v.slice(0, a) + s + v.slice(b); input.selectionStart = input.selectionEnd = a + s.length; autoGrow(); input.focus();
  }
  function buildPanel() {
    const tabs = $('#chatTabs'), grid = $('#chatGrid'); tabs.innerHTML = '';
    const defs = DATA.EMOJI_GROUPS.map((g, i) => ({ id: 'e' + i, name: g.name })).concat([{ id: 's', name: '🖼️ 表情包' }]);
    for (const d of defs) {
      const b = document.createElement('button'); b.textContent = d.name; b.className = S.tab === d.id ? 'on' : '';
      b.onclick = () => { S.tab = d.id; buildPanel(); };
      tabs.appendChild(b);
    }
    grid.innerHTML = '';
    if (S.tab === 's') {
      grid.className = 'stk';
      for (const st of DATA.STICKERS) {
        const b = document.createElement('button'); b.className = 's'; b.title = st.c;
        b.style.background = 'linear-gradient(160deg,' + st.bg[0] + ',' + st.bg[1] + ')';
        b.innerHTML = '<div class="em"></div><div class="cap"></div>';
        b.querySelector('.em').textContent = st.e; b.querySelector('.cap').textContent = st.c;
        b.onclick = () => { if (S.cur) { hub.sendSticker(S.cur, st); panel.hidden = true; render(true); input.focus(); } };
        grid.appendChild(b);
      }
    } else {
      grid.className = 'emo';
      const g = DATA.EMOJI_GROUPS[Number(S.tab.slice(1))] || DATA.EMOJI_GROUPS[0];
      for (const e of g.list) { const b = document.createElement('button'); b.className = 'e'; b.textContent = e; b.onclick = () => insertAtCursor(e); grid.appendChild(b); }
    }
  }
  function togglePanel(tab) {
    const same = !panel.hidden && ((tab === 's') === (S.tab === 's'));
    if (same) { panel.hidden = true; return; }
    if (tab === 's') S.tab = 's'; else if (S.tab === 's') S.tab = 'e0';
    buildPanel(); panel.hidden = false;
  }
  $('#chatEmoji').onclick = () => togglePanel('e');
  $('#chatStk').onclick = () => togglePanel('s');
  document.addEventListener('mousedown', e => {
    if (panel.hidden) return;
    if (!panel.contains(e.target) && e.target !== $('#chatEmoji') && e.target !== $('#chatStk')) panel.hidden = true;
  });

  /* ───────── 联通：文件 / 屏幕共享 / 更多 ───────── */
  $('#chatFile').onclick = () => { const p = S.cur && peerOf(S.cur); if (p) FX.pickAndSend(p); };
  $('#chatScreen').onclick = () => { const p = S.cur && peerOf(S.cur); if (p) peerAction(p); };       // 现成的「查看对方屏幕 / 投出我的屏幕」
  $('#chatMore').onclick = async () => {
    const p = S.cur && peerOf(S.cur); if (!p) return;
    const r = await ask(p.name, '聊天设置', { buttons: ['查看安全码', '清空聊天记录', '关闭'] });
    if (r.i === 0) {
      const sas = hub.sas(p.id);
      await ask('安全码', sas ? '安全码：' + sas + '\n\n两台设备上显示的安全码应当完全一致。聊天内容用本次连接的临时密钥加密（P-256 密钥交换 + AES-256-GCM），并且绑定了你们配对时交换的密钥，局域网里的其他人看不到、也改不了。'
        : '还没有建立加密连接（对方可能不在线）。', { buttons: ['知道了'] });
    } else if (r.i === 1) {
      const c = await ask('清空聊天记录', '只清空本机上和「' + p.name + '」的聊天记录，对方那边不受影响。', { buttons: ['清空', '取消'] });
      if (c.i === 0) hub.clear(p.id);
    }
  };
  /* 拖文件进聊天窗口：直接发给当前聊天对象（不再弹「发给哪台设备」） */
  let dd = 0;
  el.addEventListener('dragenter', e => { dd++; el.classList.add('dropping'); });
  el.addEventListener('dragleave', () => { dd = Math.max(0, dd - 1); if (!dd) el.classList.remove('dropping'); });
  el.addEventListener('drop', e => {
    e.preventDefault(); e.stopPropagation(); dd = 0; el.classList.remove('dropping');
    const p = S.cur && peerOf(S.cur); if (!p) return;
    const { webUtils } = require('electron');
    const files = [...(e.dataTransfer ? e.dataTransfer.files : [])].map(f => { try { return webUtils.getPathForFile(f) || f.path; } catch { return f.path; } }).filter(Boolean);
    if (files.length) FX.sendTo(p, files);
  });

  $('#chatBack').onclick = closeChat;
  $('#openChat').onclick = () => openChat(null);
  window.addEventListener('focus', () => { if (S.open && S.cur) { hub.markRead(S.cur); } });
  window.addEventListener('keydown', e => { if (e.key === 'Escape' && S.open && !panel.hidden) panel.hidden = true; });
  updateBadge(); refreshHeader();
})();
