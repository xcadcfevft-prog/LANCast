'use strict';
/* 瞬流「安全聊天」界面（Windows 端，渲染进程）。
 * 与 renderer.js / filexfer.js 一样是页面里的普通脚本，直接使用它们的全局：connectTo / pairedDevices / peerAction / ask / toast / myId / myName / myPin / PORT。
 * 连接管理、加密、消息状态都在 chathub.js（有单元测试）；这里只负责：把真实的 Session 接给它、画界面、通知。
 * 「联通」：聊天窗口里的 发文件 = 现成的文件互传（FX），屏幕共享 = 现成的投屏 / 远程控制（peerAction）；
 *           传输中的文件会作为卡片出现在对话里，投屏期间聊天照常可用（观看投屏时新消息以提示条出现）。 */
(function () {
  if (typeof document === 'undefined' || !document.querySelector('#chat')) return;
  const { createHub } = require('./chathub');
  const VC = require('./voice');
  const CC = require('./chatcrypto');
  const MP = require('./preview');
  const DATA = window.CHAT_DATA || require('./chatdata');
  const { ipcRenderer } = require('electron');

  const el = $('#chat'), listEl = $('#chatList'), msgsEl = $('#chatMsgs'), input = $('#chatInput'), panel = $('#chatPanel');
  const S = { open: false, cur: null, tab: 'e0', rows: new Map(), noteT: 0, lastSig: '' };
  const KEEP_UNREAD_KEY = 'chat:unread';

  /* ───────── 存储 / Hub ───────── */
  const store = {
    load: id => { try { const a = JSON.parse(LS.get('chat:' + id, '[]')); return Array.isArray(a) ? a : []; } catch { return []; } },
    save: (id, a) => LS.set('chat:' + id, JSON.stringify(a)),
    loadUnread: () => { try { return JSON.parse(LS.get(KEEP_UNREAD_KEY, '{}')) || {}; } catch { return {}; } },
    saveUnread: o => LS.set(KEEP_UNREAD_KEY, JSON.stringify(o))
  };
  const hub = createHub({
    myId, myName, myPin: () => myPin, store,
    peers: () => pairedDevices().map(p => ({ id: p.id, name: p.name, pin: p.pin, ip: p.ip, port: p.port, platform: p.platform, online: p.online })),
    dial: async p => {
      const s = await connectTo(p.ip, p.port || PORT, p.pin, 'chat');
      return { session: s, serverNonce: s.hsNonce, clientNonce: s.cn };
    },
    changed: () => schedule(),
    notify: onNotify
  });
  hub.onFileRecall = (peerId, fid) => FX.recallIncoming(peerId, fid);      // 对方撤回了他发来的文件：删掉本机保存的文件（与安卓端一致）
  setInterval(() => {
    hub.tick();
    if (S.open && S.cur && !hub.isConnected(S.cur) && !hub.connections(S.cur)) { const p = peerOf(S.cur); if (p && p.online) hub.ensure(S.cur); }
    refreshHeader();
  }, 1000);

  const CH = window.CH = {
    unread: id => hub.unread(id),
    /* 对方（本机作服务端）以 mode = "chat" 连进来：必须是已配对设备、且是 v2（有 clientNonce）才接受 */
    check(s) {
      if (!s.peerId) return '对方没有提供设备 ID，请升级对方的瞬流';
      if (s.peerVer < 2 || !s.clientNonce) return '对方版本不支持安全聊天，请升级';
      if (!loadPairs().some(p => p.id === s.peerId)) return '本机没有和你配对，请先配对';
      return '';
    },
    onIncoming(s) {
      const pr = loadPairs().find(p => p.id === s.peerId);
      hub.attach(s, { peerId: s.peerId, isClient: false, serverNonce: s.nonce, clientNonce: s.clientNonce, pin: myPin + ':' + (pr ? pr.pin : ''), peerName: s.peerName });
    },
    forget(id) { call.peerGone(id); game.peerGone(id); hub.dropPeer(id); if (S.cur === id) S.cur = null; schedule(); },
    open(id) { openChat(id); },
    hub
  };

/* ───────── 无损语音通话 ─────────
   信令 / 音频走同一条加密聊天连接（hub.sendSignal / hub.sendVoice），引擎和状态机在 voice.js。 */
  const callBar = $('#callBar'), callTx = callBar.querySelector('.tx');
  const call = VC.createCall({
    hub, makeEngine: VC.createBrowserEngine,
    makeVideo: o => VC.createBrowserVideo(Object.assign({ onLocalStream: s => { const v = $('#vidSelf'); v.srcObject = s; v.play().catch(() => {}); } }, o)),
    onVideo: (id, f) => showRemote(f),
    onState: st => { onCallState(st); }
  });
  hub.voice = { onSignal: (id, m) => call.onSignal(id, m), onAudio: (id, b) => call.onAudio(id, b), onVideo: (id, b) => call.onVideo(id, b) };

  /* 视频：只解码最新一帧（解码慢就自动跳帧）；旋转按帧头转正（安卓竖屏拍的画面带旋转） */
  const vidCv = $('#vidRemote');
  /* 画面比例：和投屏观看窗口同一套规则 —— 自动（被裁掉的面积 ≤ 22% 就铺满，否则完整显示）/ 完整显示 / 铺满；双击画面切换 */
  const VID = { mode: 0, cover: false };
  function applyVidFit() {
    const box = $('#videoBox'), W = box.clientWidth, H = box.clientHeight, w = vidCv.width, h = vidCv.height;
    if (!W || !H || !w || !h) return;
    const fit = Math.min(W / w, H / h), fill = Math.max(W / w, H / h), ratio = fill / fit;
    VID.cover = VID.mode === 1 ? false : VID.mode === 2 ? true : (1 - 1 / ratio) <= 0.22;
    vidCv.style.objectFit = VID.cover ? 'cover' : 'contain';
  }
  $('#videoBox').addEventListener('dblclick', e => { if (e.target.closest('#vidBtns')) return; VID.mode = VID.cover ? 1 : 2; applyVidFit(); });
  $('#vidSize').onclick = () => { const b = $('#videoBox'); b.classList.toggle('mini'); $('#vidSize').textContent = b.classList.contains('mini') ? '放大' : '缩小'; applyVidFit(); };
  window.addEventListener('resize', applyVidFit);
  /* 真全屏（对齐安卓端）：窗口进入系统级全屏（任务栏 / 标题栏都收起，和投屏观看的「全屏」同一套），通话条 / 聊天界面全部收起，
     视频独占整个屏幕；静音 / 挂断 / 通话时长浮在画面上（3 秒不动鼠标自动淡出）。Esc 或「退出全屏」恢复；通话结束自动退出；全屏期间屏幕常亮。 */
  let vidFull = false, vidIdleT = 0;
  function vidWake() {
    const b = $('#videoBox'); b.classList.remove('idle'); clearTimeout(vidIdleT);
    if (vidFull) vidIdleT = setTimeout(() => $('#videoBox').classList.add('idle'), 3000);
  }
  function setVidFull(on) {
    on = !!on && !$('#videoBox').hidden;
    if (on === vidFull) return;
    vidFull = on;
    if (document.body) document.body.classList.toggle('vfull', on);
    VID.mode = 0;                                       // 版面变了：画面比例回到自动（和安卓端一致）
    $('#vidFull').textContent = on ? '退出全屏' : '全屏';
    try { if (on) ipcRenderer.send('keep-awake', true); else if ($('#viewer').hidden) ipcRenderer.send('keep-awake', false); } catch {}
    if (on) { if (!document.fullscreenElement) document.documentElement.requestFullscreen().catch(() => setVidFull(false)); }
    else if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
    vidWake(); applyVidFit();
  }
  $('#vidFull').onclick = () => setVidFull(!vidFull);
  $('#vidMute').onclick = () => call.mute(!call.state.muted);
  $('#vidHang').onclick = () => call.hangup();
  $('#videoBox').addEventListener('mousemove', vidWake);
  $('#videoBox').addEventListener('mousedown', vidWake);
  document.addEventListener('fullscreenchange', () => { if (vidFull && !document.fullscreenElement) setVidFull(false); else applyVidFit(); });   // Esc 退出系统全屏 → 同步退出视频全屏
  let rxBusy = false, rxPending = null;
  async function showRemote(f) {
    if (rxBusy) { rxPending = f; return; }
    rxBusy = true;
    try {
      const bmp = await createImageBitmap(new Blob([f.jpeg], { type: 'image/jpeg' }));
      const sw = f.rot % 180 !== 0, W = sw ? bmp.height : bmp.width, H = sw ? bmp.width : bmp.height;
      if (vidCv.width !== W) vidCv.width = W; if (vidCv.height !== H) vidCv.height = H;
      const g = vidCv.getContext('2d'); g.save(); g.translate(W / 2, H / 2); g.rotate(f.rot * Math.PI / 180); g.drawImage(bmp, -bmp.width / 2, -bmp.height / 2); g.restore(); bmp.close();
      $('#vidHint').hidden = true;
      applyVidFit();
    } catch {}
    rxBusy = false;
    if (rxPending) { const p = rxPending; rxPending = null; showRemote(p); }
  }
  let lastPhase = 'idle', callTimer = 0;
  const mmss = ms => { const s = Math.max(0, Math.floor(ms / 1000)); return pad(Math.floor(s / 60)) + ':' + pad(s % 60); };
  function callName() { const p = call.state.peerId && peerOf(call.state.peerId); return p ? p.name : '对方'; }
  function paintCall() {
    const st = call.state;
    callBar.hidden = st.phase === 'idle';
    callBar.className = st.phase === 'ringing' ? 'ring' : '';
    $('#callAns').hidden = st.phase !== 'ringing';
    $('#callMute').hidden = st.phase !== 'active';
    $('#callMute').textContent = st.muted ? '🔇 取消静音' : '🎙 静音';
    $('#callEnd').textContent = st.phase === 'ringing' ? '拒绝' : st.phase === 'calling' ? '取消' : '挂断';
    callTx.textContent = st.phase === 'calling' ? (st.video ? '📹' : '📞') + ' 正在呼叫「' + callName() + '」…'
      : st.phase === 'ringing' ? (st.video ? '📹「' + callName() + '」邀请你视频通话' : '📞「' + callName() + '」邀请你无损语音通话')
      : st.phase === 'active' ? (st.video ? '📹 与「' + callName() + '」视频中 ' + mmss(Date.now() - st.since) + ' · 音频无损 PCM · 画质：' + VC.tierOf(st.tier).name + ' · 请戴耳机'
        : '🎙 与「' + callName() + '」通话中 ' + mmss(Date.now() - st.since) + ' · 无损 PCM 48 kHz / 16 bit · 请戴耳机') : '';
    const sb = $('#chatScreen'); if (sb) sb.classList.toggle('on', st.phase === 'active');
    // 视频悬浮窗：只有通话中的视频通话才显示
    const box = $('#videoBox'), showVid = st.phase === 'active' && st.video;
    box.hidden = !showVid;
    if (showVid) {
      $('#vidCam').textContent = st.camOn ? '关摄像头' : '开摄像头';
      $('#vidMute').textContent = st.muted ? '取消静音' : '静音';
      $('#vidInfo').textContent = '📹 ' + mmss(Date.now() - st.since) + ' · ' + VC.tierOf(st.tier).name + (st.muted ? ' · 已静音' : '');
      $('#vidSelf').hidden = !(st.camOk && st.camOn);
      const stale = !st.lastVideoRx || Date.now() - st.lastVideoRx > 3000;
      $('#vidHint').hidden = !stale; $('#vidHint').textContent = st.lastVideoRx ? '对方摄像头已关闭 / 画面中断' : '等待对方画面…';
      if (stale) vidCv.getContext('2d').clearRect(0, 0, vidCv.width, vidCv.height);
    } else { setVidFull(false); VID.mode = 0; const v = $('#vidSelf'); if (v.srcObject) v.srcObject = null; vidCv.getContext('2d').clearRect(0, 0, vidCv.width, vidCv.height); }
    if (document.body) document.body.style.paddingTop = st.phase === 'idle' ? '' : '44px';
  }
  function onCallState(st) {
    paintCall();
    if (st.phase === 'ringing' && lastPhase !== 'ringing') {                  // 来电：弹到前台、切到对方的聊天
      const nm = callName();
      try { ipcRenderer.send('flash'); } catch {}
      if (!document.hasFocus()) { try { const n = new Notification(nm, { body: st.video ? '邀请你视频通话' : '邀请你无损语音通话', silent: false }); n.onclick = () => { ipcRenderer.send('focus'); }; } catch {} }
      if ($('#viewer').hidden) openChat(st.peerId);
    }
    if (st.phase === 'idle' && lastPhase !== 'idle' && st.reason) toast('📞 ' + st.reason);
    lastPhase = st.phase;
    clearInterval(callTimer); callTimer = st.phase === 'active' ? setInterval(paintCall, 1000) : 0;
  }
  setInterval(() => call.tick(), 1000);
  $('#callAns').onclick = () => call.answer();
  $('#callMute').onclick = () => call.mute(!call.state.muted);
  $('#callEnd').onclick = () => { const ph = call.state.phase; if (ph === 'ringing') call.decline(); else call.hangup(); };
  const startVoice = () => {
    const p = S.cur && peerOf(S.cur); if (!p) return;
    if (call.state.phase !== 'idle') { toast('已经有一通电话了'); return; }
    if (!p.online) { toast('对方当前不在线，无法通话'); return; }
    hub.ensure(p.id); call.start(p.id);
  };
  /* 画质四档弹窗（和安卓端一致）。发起视频通话前选；通话中点「画质」也能改（立刻生效） */
  async function pickTier(cur) {
    const r = await ask('视频画质', '音频始终是无损 PCM，这里只选画面。\n当前：' + VC.tierOf(cur).name, { buttons: VC.TIERS.map(t => t.name).concat(['取消']) });
    if (r.i >= VC.TIERS.length) return -1;
    if (VC.TIERS[r.i].native) {                       // 超高画质（原生分辨率、JPEG q100）：和投屏的极致档一样，先讲清楚风险，确认了才选
      const c = await ask(VC.TIERS[r.i].name, QUALITY_HINT.extreme + '\n\n原生分辨率、不限帧率、JPEG 质量 100；画面细节最多，但对设备性能和网速要求极高。', { buttons: ['开启', '取消'] });
      if (c.i !== 0) return -1;
    }
    return r.i;
  }
  const savedTier = () => {                           // 没单独选过视频画质时，沿用投屏画质设置
    const n = parseInt(localStorage.getItem('video:tier'), 10);
    if (Number.isInteger(n) && n >= 0 && n < VC.TIERS.length) return n;
    const i = ['lossless', 'balanced', 'smooth', 'extreme'].indexOf(localStorage.getItem('quality'));
    return i >= 0 ? i : 0;
  };
  const startVideo = async () => {
    const p = S.cur && peerOf(S.cur); if (!p) return;
    if (call.state.phase !== 'idle') { toast('已经有一通电话了'); return; }
    if (!p.online) { toast('对方当前不在线，无法通话'); return; }
    const t = await pickTier(savedTier()); if (t < 0) return;
    localStorage.setItem('video:tier', String(t));
    if (call.state.phase !== 'idle') return;
    hub.ensure(p.id); call.start(p.id, { video: true, tier: t });
  };
  $('#vidTier').onclick = async () => { const t = await pickTier(call.state.tier); if (t >= 0) { localStorage.setItem('video:tier', String(t)); call.setTier(t); } };
  $('#vidCam').onclick = () => call.camera(!call.state.camOn);

  /* ───────── 工具 ───────── */
  const peerOf = id => pairedDevices().find(p => p.id === id) || null;
  const pad = n => String(n).padStart(2, '0');
  function fmtTime(ts) {
    const d = new Date(ts), now = new Date(), hm = pad(d.getHours()) + ':' + pad(d.getMinutes());
    if (d.toDateString() === now.toDateString()) return hm;
    const y = new Date(now - 86400000);
    return (d.toDateString() === y.toDateString() ? '昨天 ' : (d.getMonth() + 1) + '月' + d.getDate() + '日 ') + hm;
  }
  const preview = m => m.k === 's' ? '[表情包] ' + (m.c || m.e) : String(m.x || '').replace(/\s+/g, ' ').slice(0, 40);
  let rt = 0;
  function schedule() { if (rt) return; rt = setTimeout(() => { rt = 0; render(); }, 120); }

  /* ───────── 通知 ───────── */
  function onNotify({ peerId, name, msg }) {
    const looking = S.open && S.cur === peerId && document.hasFocus();
    if (looking) return;
    updateBadge();
    if (!$('#viewer').hidden) { toast('💬 ' + name + '：' + preview(msg)); return; }       // 正在看对方屏幕：用提示条
    try { ipcRenderer.send('flash'); } catch {}
    if (!document.hasFocus()) {
      try { const n = new Notification(name, { body: preview(msg), silent: false }); n.onclick = () => { ipcRenderer.send('focus'); openChat(peerId); }; } catch {}
    }
  }
  function updateBadge() {
    const n = hub.totalUnread(), b = $('#chatBadge');
    b.hidden = !n; b.textContent = n > 99 ? '99+' : n;
    document.title = n ? '（' + n + '）瞬流' : '瞬流';
  }

  /* ───────── 显示 / 隐藏 ───────── */
  function openChat(id) {
    const list = pairedDevices();
    S.open = true;
    S.cur = id && list.some(p => p.id === id) ? id : (S.cur && list.some(p => p.id === S.cur) ? S.cur : (list[0] && list[0].id) || null);
    $('#home').hidden = true; el.hidden = false; $('#viewer').hidden = true;
    hub.viewing = S.cur; if (S.cur) { hub.markRead(S.cur); hub.ensure(S.cur); }
    S.rows.clear(); msgsEl.innerHTML = ''; panel.hidden = true;
    render(true); input.focus();
  }
  function closeChat() {
    S.open = false; hub.viewing = null; el.hidden = true; $('#home').hidden = false; panel.hidden = true;
    renderPeers(); updateBadge();
  }
  /* 投屏（观看）会盖住整个窗口：开始时让位，结束后如果之前在聊天，回到聊天 */
  const origShowViewer = window.showViewer;
  window.showViewer = function (on) {
    origShowViewer(on);
    if (on) { el.hidden = true; if (S.open) hub.viewing = null; }
    else if (S.open) { $('#home').hidden = true; el.hidden = false; hub.viewing = S.cur; if (S.cur) hub.markRead(S.cur); render(true); }
  };
  /* 聊天窗口里也要看得到「连接中 / 正忙 / 失败」之类的状态提示（原来的状态栏在首页，聊天时看不到） */
  const origSetStatus = window.setStatus;
  window.setStatus = function (msg, err) {
    origSetStatus(msg, err);
    if (!S.open) return;
    const n = $('#chatNote'); n.textContent = msg; n.className = err ? 'err' : ''; n.hidden = !msg;
    clearTimeout(S.noteT); S.noteT = setTimeout(() => { n.hidden = true; }, 7000);
  };

  /* ───────── 渲染 ───────── */
  function refreshHeader() {
    if (!S.open) return;
    const p = S.cur ? peerOf(S.cur) : null;
    $('#chatTitle').textContent = p ? p.name : '选择一台设备开始聊天';
    const sub = $('#chatSub');
    if (!p) { sub.textContent = ''; sub.className = ''; }
    else if (hub.isConnected(p.id)) { sub.textContent = '🔒 端到端加密 · 已连接'; sub.className = 'up'; }
    else if (p.online) { sub.textContent = '🔒 端到端加密 · 对方在线，正在建立加密连接…'; sub.className = ''; }
    else { sub.textContent = '对方当前不在线（发出的消息在对方上线后无法补发，30 秒后会标记失败，可点击重试）'; sub.className = ''; }
    const pr = p ? hub.pendingRecalls(p.id) : 0;
    if (pr) sub.textContent += ' · 有 ' + pr + ' 条撤回等对方上线后生效';
    for (const id of ['#chatFile', '#chatScreen', '#chatMore', '#chatSend', '#chatEmoji', '#chatStk']) $(id).disabled = !p;
    input.disabled = !p;
  }
  function renderList() {
    const list = pairedDevices().map(p => {
      const a = hub.messages(p.id), last = a.length ? a[a.length - 1] : null;
      return { p, last, ts: last ? last.ts : 0 };
    }).sort((a, b) => (b.p.online - a.p.online) || (b.ts - a.ts) || a.p.name.localeCompare(b.p.name));
    const sig = JSON.stringify(list.map(x => [x.p.id, x.p.name, x.p.online, hub.unread(x.p.id), x.last && x.last.id, x.last && x.last.st, x.p.id === S.cur]));
    if (sig === S.lastSig) return; S.lastSig = sig;
    listEl.innerHTML = '';
    if (!list.length) { const d = document.createElement('div'); d.className = 'empty'; d.style.padding = '14px'; d.textContent = '还没有配对的设备。先在首页配对（手机扫码 / 电脑匹配码）。'; listEl.appendChild(d); return; }
    for (const { p, last } of list) {
      const d = document.createElement('div'); d.className = 'ci' + (p.id === S.cur ? ' on' : '');
      d.innerHTML = '<span class="dot"></span><div class="nm"><b></b><span></span></div>';
      d.querySelector('.dot').classList.toggle('up', p.online);
      d.querySelector('b').textContent = p.name;
      d.querySelector('.nm span').textContent = last ? (last.from === 'me' ? '我：' : '') + preview(last) : (p.online ? '在线' : '离线');
      const n = hub.unread(p.id);
      if (n) { const b = document.createElement('span'); b.className = 'badge'; b.textContent = n > 99 ? '99+' : n; b.style.cssText = 'margin:0;font-size:11px;color:#fff'; d.appendChild(b); }
      d.onclick = () => { if (S.cur === p.id) return; S.cur = p.id; hub.viewing = p.id; hub.markRead(p.id); hub.ensure(p.id); S.rows.clear(); msgsEl.innerHTML = ''; render(true); input.focus(); };
      listEl.appendChild(d);
    }
  }
  function stickerEl(m) {
    const d = document.createElement('div'); d.className = 'stk';
    const bg = Array.isArray(m.bg) && m.bg.length === 2 ? m.bg : ['#fff3c4', '#ffd37a'];
    d.style.background = 'linear-gradient(160deg,' + bg[0] + ',' + bg[1] + ')';
    const e = document.createElement('div'); e.className = 'em'; e.textContent = m.e;
    const c = document.createElement('div'); c.className = 'cap'; c.textContent = m.c || '';
    d.appendChild(e); d.appendChild(c); return d;
  }
  function msgRow(m) {
    const box = document.createElement('div'); box.className = 'cm ' + (m.from === 'me' ? 'me' : 'peer');
    const t = document.createElement('div'); t.className = 't'; box.appendChild(t);
    const body = m.k === 's' ? stickerEl(m) : (() => { const b = document.createElement('div'); b.className = 'bub'; b.textContent = m.x; return b; })();
    box.appendChild(body);
    const line = document.createElement('div'); line.className = 'st'; box.appendChild(line);
    const st = document.createElement('span'); line.appendChild(st);
    let rc = null;
    if (m.from === 'me') {                                    // 撤回：只有自己发的消息有，没有时间限制，两边一起删
      rc = document.createElement('span'); rc.className = 'rc'; rc.textContent = '撤回'; rc.title = '从你和对方的聊天记录里一起删除这条消息';
      rc.onclick = () => recallMsg(m.id);
      line.appendChild(rc);
    }
    return { box, t, st, line, rc, kind: 'm' };
  }
  function fileRow() {
    const box = document.createElement('div'); box.className = 'cf';
    box.innerHTML = '<div class="ft"><b></b><span></span></div><progress max="1000" value="0"></progress><div class="fs"><span class="fi"></span><span class="fb"></span></div>';
    return { box, n: box.querySelector('b'), d: box.querySelector('.ft span'), p: box.querySelector('progress'), i: box.querySelector('.fi'), b: box.querySelector('.fb'), btn: '', pv: null, pvKey: '', kind: 'f' };
  }
  function updateMsg(r, m) {
    r.t.textContent = fmtTime(m.ts);
    if (m.from === 'me') {
      r.st.textContent = m.st === 'sent' ? '✓ 已送达' : m.st === 'failed' ? '❗ 发送失败，点击重试' : '发送中…';
      r.line.className = 'st' + (m.st === 'failed' ? ' bad' : '');
      r.st.onclick = m.st === 'failed' ? () => hub.retry(S.cur, m.id) : null;
    } else { r.st.textContent = ''; r.line.className = 'st'; }
  }
  function openMedia(x, k, src) {
    MP.open({ path: src, name: x.name, size: x.size, kind: k, onRecall: x.dir === 'send' && x.state === 'done' ? () => recallFile(x) : null });
  }
  function updateFile(r, x) {
    const active = FX.ACTIVE.has(x.state);
    const k = MP.kind(x.name), src = FX.localPath(x);
    // 图片 / 视频：对方发来的要等校验通过（done）才有可预览的文件；我发的从一开始就能看到原文件
    const media = !!k && !!src && (x.state === 'done' || x.dir === 'send');
    r.box.className = 'cf ' + (x.dir === 'send' ? 'me' : 'peer') + (media ? ' media' : '');
    if (media) {
      const key = src + '|' + k;
      if (r.pvKey !== key) {
        if (r.pv) r.pv.el.remove();
        r.pv = MP.thumb(src, k, () => openMedia(x, k, src)); r.pvKey = key;
        r.box.insertBefore(r.pv.el, r.box.querySelector('.fs'));
      }
      r.pv.setOverlay(x.state === 'done' ? '' : FX.stateText(x));       // 发送中 / 等对方确认 / 失败：盖一层状态，缩略图依然能看
    } else if (r.pv) { r.pv.el.remove(); r.pv = null; r.pvKey = ''; }
    r.n.textContent = '📎 ' + x.name;
    r.d.textContent = x.dir === 'send' ? '发出的文件' : '收到的文件';
    r.p.value = x.size ? Math.min(1000, Math.round(x.done / x.size * 1000)) : (x.state === 'done' ? 1000 : 0);
    r.p.className = x.state;
    r.i.textContent = FX.stateText(x);
    r.i.style.color = x.state === 'failed' ? 'var(--warn)' : x.state === 'done' ? 'var(--ok)' : 'var(--muted)';
    const wants = active ? ['cancel'] : x.state === 'done' ? (x.dir === 'send' ? ['recall'] : (x.saved ? ['show'] : [])) : ['remove'];
    const key = wants.join(',');
    if (r.btn !== key) {
      r.btn = key; r.b.innerHTML = '';
      const defs = {
        cancel: ['取消', () => FX.cancelX(x)],
        show: ['在文件夹中显示', () => ipcRenderer.send('show-item', x.saved)],
        recall: ['撤回', () => recallFile(x)],
        remove: ['删除', () => FX.removeLocal(x)]
      };
      for (const w of wants) { const b = document.createElement('button'); b.textContent = defs[w][0]; b.onclick = defs[w][1]; r.b.appendChild(b); }
    }
  }
  /* 撤回自己发出的文件：本机立刻删掉；对方（新版本的安卓 / 电脑版）会把已保存的文件一并删除，对方不在线就等它上线 */
  async function recallFile(x) {
    const p = peerOf(x.peerId), who = p ? '「' + p.name + '」' : '对方';
    const r = await ask('撤回这个文件？', '撤回后，这个文件会从你和' + who + '的聊天里一起消失，没有时间限制。\n\n' +
      '对方使用新版本的瞬流（安卓版 / 电脑版）时，已经保存到对方设备里的文件也会被一并删除（对方现在不在线，会在上线后自动执行）；对方使用不认识文件撤回的旧版本时，只会撤掉聊天记录，已保存的文件不会被删除。已经被对方转发、另存或截图的内容无法收回。' +
      (FX.ACTIVE.has(x.state) ? '\n\n这个文件还在传输中，撤回会中止本批其余尚未完成的文件。' : ''), { buttons: ['撤回', '取消'] });
    if (r.i === 0) { FX.recallSent(x); render(); }
  }
  async function recallMsg(msgId) {
    const id = S.cur; if (!id) return;
    const p = peerOf(id), who = p ? '「' + p.name + '」' : '对方';
    const r = await ask('撤回这条消息？', '撤回后，这条消息会从你和' + who + '的聊天记录里一起删除，没有时间限制，对方看不到任何痕迹。\n\n（如果对方现在不在线，会在对方上线后自动撤回。已经被对方复制、截图的内容无法收回。）', { buttons: ['撤回', '取消'] });
    if (r.i === 0) { hub.recall(id, msgId); render(); }
  }
  function renderMsgs(force) {
    const id = S.cur;
    if (!id) { msgsEl.innerHTML = ''; S.rows.clear(); return; }
    const items = [];
    for (const m of hub.messages(id)) items.push({ key: 'm' + m.id, ts: m.ts, m });
    for (const x of FX.xfers || []) if (x.peerId === id) items.push({ key: 'x' + x.seq, ts: x.t0, x, seq: x.seq });
    items.sort((a, b) => (a.ts - b.ts) || ((b.seq | 0) - (a.seq | 0)));
    const near = msgsEl.scrollHeight - msgsEl.scrollTop - msgsEl.clientHeight < 80;
    const keep = new Set();
    for (const it of items) {
      keep.add(it.key);
      let r = S.rows.get(it.key);
      if (!r) { r = it.m ? msgRow(it.m) : fileRow(); S.rows.set(it.key, r); }
      if (it.m) updateMsg(r, it.m); else updateFile(r, it.x);
    }
    for (const [k, r] of [...S.rows]) if (!keep.has(k)) { r.box.remove(); S.rows.delete(k); }
    let i = 0;
    const empty = document.getElementById('chatEmpty');
    if (items.length && empty) empty.remove();
    for (const it of items) { const b = S.rows.get(it.key).box; if (msgsEl.children[i] !== b) msgsEl.insertBefore(b, msgsEl.children[i] || null); i++; }
    if (!items.length && !empty) {
      const d = document.createElement('div'); d.id = 'chatEmpty';
      d.innerHTML = '🔒 消息经过端到端加密，只有你们两台设备看得到<br>可以发文字、表情包，📎 传文件，🖥 随时开始屏幕共享<br>也可以把文件直接拖进这个窗口';
      msgsEl.appendChild(d);
    }
    if (force || near) msgsEl.scrollTop = msgsEl.scrollHeight;
  }
  function render(force) {
    if (!S.open) { updateBadge(); return; }
    if (S.cur && hub.viewing === S.cur && hub.unread(S.cur)) hub.markRead(S.cur);
    renderList(); refreshHeader(); renderMsgs(force); updateBadge();
  }
  FX.onChange = () => { if (S.open) schedule(); };

  /* ───────── 输入 / 表情面板 ───────── */
  function send() {
    const t = input.value;
    if (!S.cur || !t.trim()) return;
    const n = [...t].length;
    if (n > CC.MAX_TEXT) {                                    // 超长不再悄悄截断：明确提示，内容留在输入框里
      toast('这条消息有 ' + n + ' 字，超过单条上限 ' + CC.MAX_TEXT + ' 字。为避免内容被截断，没有发送，请拆成几条再发（内容还在输入框里）'); return;
    }
    hub.sendText(S.cur, t); input.value = ''; autoGrow(); render(true); input.focus();
  }
  function autoGrow() { input.style.height = 'auto'; input.style.height = Math.min(120, input.scrollHeight) + 'px'; }
  input.addEventListener('input', autoGrow);
  input.addEventListener('keydown', e => { if (e.key === 'Enter' && !e.shiftKey && !e.isComposing && e.keyCode !== 229) { e.preventDefault(); send(); } });
  $('#chatSend').onclick = send;

  function insertAtCursor(s) {
    const a = input.selectionStart, b = input.selectionEnd, v = input.value;
    input.value = v.slice(0, a) + s + v.slice(b); input.selectionStart = input.selectionEnd = a + s.length; autoGrow(); input.focus();
  }
  function buildPanel() {
    const tabs = $('#chatTabs'), grid = $('#chatGrid'); tabs.innerHTML = '';
    const defs = DATA.EMOJI_GROUPS.map((g, i) => ({ id: 'e' + i, name: g.name })).concat([{ id: 's', name: '🖼️ 表情包' }]);
    for (const d of defs) {
      const b = document.createElement('button'); b.textContent = d.name; b.className = S.tab === d.id ? 'on' : '';
      b.onclick = () => { S.tab = d.id; buildPanel(); };
      tabs.appendChild(b);
    }
    grid.innerHTML = '';
    if (S.tab === 's') {
      grid.className = 'stk';
      for (const st of DATA.STICKERS) {
        const b = document.createElement('button'); b.className = 's'; b.title = st.c;
        b.style.background = 'linear-gradient(160deg,' + st.bg[0] + ',' + st.bg[1] + ')';
        b.innerHTML = '<div class="em"></div><div class="cap"></div>';
        b.querySelector('.em').textContent = st.e; b.querySelector('.cap').textContent = st.c;
        b.onclick = () => { if (S.cur) { hub.sendSticker(S.cur, st); panel.hidden = true; render(true); input.focus(); } };
        grid.appendChild(b);
      }
    } else {
      grid.className = 'emo';
      const g = DATA.EMOJI_GROUPS[Number(S.tab.slice(1))] || DATA.EMOJI_GROUPS[0];
      for (const e of g.list) { const b = document.createElement('button'); b.className = 'e'; b.textContent = e; b.onclick = () => insertAtCursor(e); grid.appendChild(b); }
    }
  }
  function togglePanel(tab) {
    const same = !panel.hidden && ((tab === 's') === (S.tab === 's'));
    if (same) { panel.hidden = true; return; }
    if (tab === 's') S.tab = 's'; else if (S.tab === 's') S.tab = 'e0';
    buildPanel(); panel.hidden = false;
  }
  $('#chatEmoji').onclick = () => togglePanel('e');
  $('#chatStk').onclick = () => togglePanel('s');
  document.addEventListener('mousedown', e => {
    if (panel.hidden) return;
    if (!panel.contains(e.target) && e.target !== $('#chatEmoji') && e.target !== $('#chatStk')) panel.hidden = true;
  });

  /* ───────── 联通：文件 / 屏幕共享 / 更多 ───────── */
  $('#chatFile').onclick = () => { const p = S.cur && peerOf(S.cur); if (p) FX.pickAndSend(p); };
  /* 屏幕共享 / 语音通话 / 视频通话 合成一个入口：点开后用文字讲清楚三种功能再选 */
  /* ───────── 五子棋对战 ─────────
     邀请 / 同意走加密聊天连接（hub.sendGame），状态机在 gomoku.js；同意后主进程开一个独立的棋盘窗口（gomoku.html），
     落子 / 悔棋 / 聊天等对局消息：棋盘窗口 → 主进程 → 这里 → 对方，反方向同理。 */
  const GM = require('./gomoku');
  let gmLast = 'idle', gmAsking = false;
  const game = GM.createGame({
    hub, myId,
    peerName: id => { const p = peerOf(id); return p ? p.name : '对方'; },
    open: info => ipcRenderer.send('game-open', info),
    close: () => ipcRenderer.send('game-close'),
    deliver: d => ipcRenderer.send('game-in', d),
    onState: st => onGameState(st)
  });
  hub.game = { onSignal: (id, m) => game.onSignal(id, m) };
  ipcRenderer.on('game-out', (e, d) => game.fromWindow(CC.sanitizeGameData(d)));      // 棋盘窗口发出的消息也过一遍白名单清洗（与安卓端 Gomoku.fromWindow 一致；不合法的丢弃）
  ipcRenderer.on('game-closed', () => game.windowClosed());
  setInterval(() => game.tick(), 1000);
  function gameName() { const p = game.state.peerId && peerOf(game.state.peerId); return p ? p.name : '对方'; }
  async function onGameState(st) {
    const ph = st.phase;
    if (ph === 'invited' && gmLast !== 'invited') {                           // 对方邀请我
      gmLast = ph;
      const nm = gameName(), gid = st.gid;
      try { ipcRenderer.send('flash'); } catch {}
      if (!document.hasFocus()) { try { const n = new Notification(nm, { body: '邀请你来一局「智斗五子棋·文房雅趣」', silent: false }); n.onclick = () => { ipcRenderer.send('focus'); }; } catch {} }
      gmAsking = true;
      const r = await ask('智斗五子棋·文房雅趣', '「' + nm + '」邀请你来一局「智斗五子棋·文房雅趣」。\n\n同意后会各自弹出独立的棋盘窗口，黑白方已随机分好。', { buttons: ['接受', '拒绝'] });
      gmAsking = false;
      if (game.state.phase === 'invited' && game.state.gid === gid) { if (r.i === 0) game.accept(); else game.decline(); }
      return;
    }
    if (ph !== 'invited' && gmAsking) { $('#modal').hidden = true; gmAsking = false; }         // 对方撤回了邀请：把还开着的询问框收掉
    if (ph === 'inviting' && gmLast !== 'inviting') toast('🎮 已向「' + gameName() + '」发出「智斗五子棋·文房雅趣」邀请，等待对方同意…');
    if (ph === 'playing' && gmLast !== 'playing') toast('🎮 对局开始，棋盘已在新窗口打开');
    if ((ph === 'idle' || ph === 'ended') && gmLast !== ph && st.reason) toast('🎮 ' + st.reason);
    gmLast = ph;
  }
  const startGomoku = async () => {
    const p = S.cur && peerOf(S.cur); if (!p) return;
    const ph = game.state.phase;
    if (ph === 'playing') { ipcRenderer.send('game-focus'); return; }
    if (ph === 'inviting') {
      const r = await ask('智斗五子棋·文房雅趣', '已经向「' + gameName() + '」发出邀请，正在等待对方回应。', { buttons: ['继续等待', '取消邀请'] });
      if (r.i === 1) game.cancelInvite();
      return;
    }
    if (ph !== 'idle' && ph !== 'ended') { toast('已经有一个「智斗五子棋·文房雅趣」邀请 / 对局了'); return; }
    if (ph === 'ended') game.windowClosed();
    if (!p.online) { toast('对方当前不在线，无法邀请'); return; }
    hub.ensure(p.id); game.invite(p.id);
  };
  $('#chatScreen').onclick = async () => {
    const p = S.cur && peerOf(S.cur); if (!p) return;
    const r = await ask('选择一种连接方式', '点一行即可开始：', {
      choices: [
        { icon: '🖥', name: '屏幕共享', desc: '看对方的屏幕，或把我的屏幕投给对方；可以申请远程控制鼠标键盘。' },
        { icon: '🎮', name: '智斗五子棋·文房雅趣', desc: '向对方发起对战邀请，对方同意后各自弹出独立的棋盘窗口，黑白随机，落子 / 悔棋 / 聊天实时同步。' },
        { icon: '📞', name: '语音通话', desc: '无损音质（原始 PCM），不压缩，请戴耳机避免回声。' },
        { icon: '📹', name: '视频通话', desc: '音频同样无损，画面有四档画质可选，可开关摄像头。' }
      ],
      buttons: ['取消']
    });
    if (r.i === 0) peerAction(p);
    else if (r.i === 1) startGomoku();
    else if (r.i === 2) startVoice();
    else if (r.i === 3) startVideo();
  };
  $('#chatMore').onclick = async () => {
    const p = S.cur && peerOf(S.cur); if (!p) return;
    const r = await ask(p.name, '聊天设置', { buttons: ['查看安全码', '清空聊天记录', '关闭'] });
    if (r.i === 0) {
      const sas = hub.sas(p.id);
      await ask('安全码', sas ? '安全码：' + sas + '\n\n两台设备上显示的安全码应当完全一致。聊天内容用本次连接的临时密钥加密（P-256 密钥交换 + AES-256-GCM），并且绑定了你们配对时交换的密钥，局域网里的其他人看不到、也改不了。'
        : '还没有建立加密连接（对方可能不在线）。', { buttons: ['知道了'] });
    } else if (r.i === 1) {
      const c = await ask('清空聊天记录', '只清空本机上和「' + p.name + '」的聊天记录，对方那边不受影响。', { buttons: ['清空', '取消'] });
      if (c.i === 0) hub.clear(p.id);
    }
  };
  /* 拖文件进聊天窗口：直接发给当前聊天对象（不再弹「发给哪台设备」） */
  let dd = 0;
  el.addEventListener('dragenter', e => { dd++; el.classList.add('dropping'); });
  el.addEventListener('dragleave', () => { dd = Math.max(0, dd - 1); if (!dd) el.classList.remove('dropping'); });
  el.addEventListener('drop', e => {
    e.preventDefault(); e.stopPropagation(); dd = 0; el.classList.remove('dropping');
    const p = S.cur && peerOf(S.cur); if (!p) return;
    const { webUtils } = require('electron');
    const files = [...(e.dataTransfer ? e.dataTransfer.files : [])].map(f => { try { return webUtils.getPathForFile(f) || f.path; } catch { return f.path; } }).filter(Boolean);
    if (files.length) FX.sendTo(p, files);
  });

  $('#chatBack').onclick = closeChat;
  $('#openChat').onclick = () => openChat(null);
  window.addEventListener('focus', () => { if (S.open && S.cur) { hub.markRead(S.cur); } });
  window.addEventListener('keydown', e => { if (e.key === 'Escape' && S.open && !panel.hidden) panel.hidden = true; });
  updateBadge(); refreshHeader();
})();
