'use strict';
/* 瞬流「无损语音通话」（Windows 端）。安卓端对应 android/.../VoiceCall.kt，规范见 docs/PROTOCOL.md 第 16 节。
 *
 * 无损的做法（和 SonoBus 的「PCM」模式一样）：不经过任何有损编码器（不用 Opus / AAC），麦克风采到的采样点
 * 直接以 48 kHz / 16 bit 原始 PCM 发出，对方原样播放。传输走已有的 TCP 加密聊天连接（可靠、有序），
 * 所以网络层不会丢包、不会乱序；采集时关掉回声消除 / 降噪 / 自动增益（这些都会改动声音），
 * 因此请戴耳机通话，否则对方会听到自己的回声。
 *
 * 语音帧（T_CHAT_VOICE = 50，加密前的明文）：
 *   u8 ver(=1) | u8 声道数(=1) | u8 位深(=16) | u8 保留 | u32 采样率(=48000，大端) | u32 序号(大端) | 采样点(int16 小端)
 *   每帧 10 ms = 480 个采样点 = 960 字节，加上 12 字节头。
 * 信令（聊天加密通道里的 JSON）：{t:"vc", op:"invite"|"accept"|"reject"|"busy"|"end", rate, ch, bits}
 *
 * 视频通话（第 17 节）：信令多一个 vid:true；音频不变；视频帧走 T_CHAT_VIDEO = 51（JPEG，帧头见 packVideo），画质四档由发送方自选。
 *
 * 本文件前半部分是纯逻辑（帧打包 / 通话状态机），可以在 Node 里测试；后半部分是浏览器里的音频引擎（AudioWorklet）。 */

const RATE = 48000, CH = 1, BITS = 16, FRAME = 480;       // 10 ms
const HDR = 12;
const RING_TIMEOUT_MS = 40000;

/* ───────── 帧 ───────── */
function pack(seq, samples) {                              // samples: Int16Array（FRAME 个）
  const b = Buffer.allocUnsafe(HDR + samples.length * 2);
  b[0] = 1; b[1] = CH; b[2] = BITS; b[3] = 0; b.writeUInt32BE(RATE, 4); b.writeUInt32BE(seq >>> 0, 8);
  for (let i = 0; i < samples.length; i++) b.writeInt16LE(samples[i], HDR + i * 2);
  return b;
}
/* 返回 { seq, samples: Int16Array }；格式不对返回 null（调用方丢弃） */
function unpack(buf) {
  if (!buf || buf.length < HDR + 2 || (buf.length - HDR) % 2 || buf.length > HDR + 2 * RATE) return null;
  if (buf[0] !== 1 || buf[1] !== CH || buf[2] !== BITS || buf.readUInt32BE(4) !== RATE) return null;
  const n = (buf.length - HDR) / 2, s = new Int16Array(n);
  for (let i = 0; i < n; i++) s[i] = buf.readInt16LE(HDR + i * 2);
  return { seq: buf.readUInt32BE(8), samples: s };
}

/* ───────── 视频帧 / 画质四档（和安卓端 VideoCall.kt 一致）─────────
 * 帧：u8 ver(=1) | u8 画质档位 | u8 旋转（×90° 顺时针，接收方转正）| u8 保留 | u16 宽 | u16 高 | u32 序号（均大端）| JPEG */
const VHDR = 12, MAX_JPEG = 3 * 1024 * 1024;
const TIERS = [
  { name: '视觉无损（高码率）', w: 1280, h: 720, q: 95, fps: 30 },
  { name: '均衡', w: 960, h: 540, q: 80, fps: 24 },
  { name: '省流畅', w: 640, h: 360, q: 55, fps: 20 },
  { name: '极致无损 Beta', w: 0, h: 0, q: 100, fps: 60, native: true }   // 和投屏一样：原生分辨率（不缩放）、不限帧率
];
const tierOf = i => TIERS[Number.isInteger(i) && i >= 0 && i < TIERS.length ? i : 0];
function packVideo(seq, tier, rot, w, h, jpeg) {
  const b = Buffer.allocUnsafe(VHDR + jpeg.length);
  b[0] = 1; b[1] = tier & 255; b[2] = ((rot / 90) | 0) & 3; b[3] = 0; b.writeUInt16BE(w, 4); b.writeUInt16BE(h, 6); b.writeUInt32BE(seq >>> 0, 8);
  Buffer.from(jpeg.buffer, jpeg.byteOffset, jpeg.length).copy(b, VHDR);
  return b;
}
/* 返回 { seq, tier, rot（度）, w, h, jpeg }；格式不对 / 不是 JPEG / 尺寸离谱返回 null（调用方丢弃） */
function unpackVideo(buf) {
  if (!buf || buf.length <= VHDR + 4 || buf.length > VHDR + MAX_JPEG || buf[0] !== 1) return null;
  const w = buf.readUInt16BE(4), h = buf.readUInt16BE(6);
  if (!w || !h || w > 4096 || h > 4096) return null;
  if (buf[VHDR] !== 0xFF || buf[VHDR + 1] !== 0xD8) return null;
  return { seq: buf.readUInt32BE(8), tier: buf[1], rot: (buf[2] & 3) * 90, w, h, jpeg: buf.subarray(VHDR) };
}
const f2i = v => { v = v < -1 ? -1 : v > 1 ? 1 : v; return v < 0 ? Math.round(v * 32768) : Math.round(v * 32767); };

/* ───────── 通话状态机（纯逻辑：hub / 音频引擎 / 定时器都是注入的）─────────
 * phase: idle → calling（我呼出，等对方接）/ ringing（对方呼入，等我接）→ active（通话中）→ idle
 * 同一时刻只允许一通电话；通话中再有别人呼入，回「忙线」。双方同时互相呼叫时，各自把对方的呼叫当作接听。 */
function createCall(o) {
  const { hub, makeEngine, makeVideo = null, onVideo = () => {}, onState = () => {}, now = () => Date.now(), setT = setTimeout, clearT = clearTimeout } = o;
  const st = { phase: 'idle', peerId: null, since: 0, muted: false, reason: '', seq: 0, rx: 0, tx: 0, video: false, camOn: true, camOk: false, tier: 0, lastVideoRx: 0 };
  let engine = null, vengine = null, timer = 0, lost = 0;

  const emit = () => { try { onState(st); } catch {} };
  const sig = (id, op) => { try { return hub.sendSignal(id, st.video ? { op, rate: RATE, ch: CH, bits: BITS, vid: true } : { op, rate: RATE, ch: CH, bits: BITS }); } catch { return false; } };
  function reset(reason) {
    clearT(timer); timer = 0;
    if (engine) { try { engine.stop(); } catch {} engine = null; }
    if (vengine) { try { vengine.stop(); } catch {} vengine = null; }
    st.camOk = false; st.video = false; st.camOn = true;
    st.phase = 'idle'; st.peerId = null; st.muted = false; st.reason = reason || ''; st.seq = 0; lost = 0; emit();
  }
  function activate() {
    clearT(timer); timer = 0;
    st.phase = 'active'; st.since = now(); st.seq = 0; st.rx = 0; st.tx = 0; lost = 0; st.reason = '';
    const id = st.peerId;
    engine = makeEngine({ onFrame: samples => {
      if (st.phase !== 'active') return;
      const s = st.muted ? new Int16Array(samples.length) : samples;          // 静音 = 发全零（保持流不断，对方不会因为缺数据而反复重新缓冲）
      if (hub.sendVoice(id, pack(st.seq++, s))) st.tx++;
    } });
    if (st.video && makeVideo) {                                              // 视频通话：开摄像头（打不开就只收不发，通话照常）
      const ve = makeVideo({ tier: () => st.tier, onFrame: f => { if (st.phase === 'active' && st.camOn) hub.sendVideo(id, f); } });
      vengine = ve; st.camOk = true;
      Promise.resolve().then(() => ve.start()).catch(() => { if (vengine === ve) { try { ve.stop(); } catch {} vengine = null; st.camOk = false; emit(); } });
    }
    Promise.resolve().then(() => engine.start()).catch(e => { const m = (e && e.message) || String(e); sig(id, 'end'); reset('无法使用麦克风 / 扬声器：' + m); });
    emit();
  }

  const call = {
    state: st,
    /* 我呼出。信令发不出去（加密连接还没建好）就每秒重试，直到超时 */
    start(peerId, opt) {
      if (st.phase !== 'idle') return false;
      st.video = !!(opt && opt.video); st.tier = opt && Number.isInteger(opt.tier) ? Math.min(Math.max(opt.tier, 0), TIERS.length - 1) : 0; st.camOn = true;
      st.phase = 'calling'; st.peerId = peerId; st.since = now(); st.reason = '';
      const t0 = now();
      const tryInvite = () => {
        if (st.phase !== 'calling' || st.peerId !== peerId) return;
        if (now() - t0 > RING_TIMEOUT_MS) { sig(peerId, 'end'); reset('对方没有接听'); return; }
        if (!(call._sent) && sig(peerId, 'invite')) call._sent = true;
        timer = setT(tryInvite, 1000);
      };
      call._sent = false; emit(); tryInvite();
      return true;
    },
    answer() { if (st.phase !== 'ringing') return; sig(st.peerId, 'accept'); activate(); },
    decline() { if (st.phase !== 'ringing') return; sig(st.peerId, 'reject'); reset('已拒绝'); },
    hangup() {
      if (st.phase === 'idle') return;
      const id = st.peerId, was = st.phase;
      sig(id, 'end');
      reset(was === 'active' ? '通话已结束' : was === 'calling' ? '已取消呼叫' : '已拒绝');
    },
    mute(on) { st.muted = !!on; emit(); },
    onSignal(peerId, m) {
      if (m.op === 'invite') {
        if (st.phase === 'idle') {
          st.phase = 'ringing'; st.peerId = peerId; st.since = now(); st.reason = '';
          st.video = m.vid === true; st.camOn = true;
          clearT(timer); timer = setT(() => { if (st.phase === 'ringing') { sig(peerId, 'end'); reset('未接来电'); } }, RING_TIMEOUT_MS);
          emit();
        } else if (st.peerId === peerId && st.phase === 'calling') { sig(peerId, 'accept'); activate(); }      // 同时互相呼叫
        else if (st.peerId === peerId && st.phase === 'active') sig(peerId, 'accept');                           // 对方重复呼叫：重发接听
        else sig(peerId, 'busy');
        return;
      }
      if (st.peerId !== peerId) return;
      if (m.op === 'accept') { if (st.phase === 'calling') activate(); }
      else if (m.op === 'reject') { if (st.phase === 'calling') reset('对方拒绝了通话'); }
      else if (m.op === 'busy') { if (st.phase === 'calling') reset('对方正在通话中'); }
      else if (m.op === 'end') { if (st.phase !== 'idle') reset(st.phase === 'ringing' ? '对方取消了呼叫' : st.phase === 'calling' ? '对方没有接听' : '对方已挂断'); }
    },
    onAudio(peerId, buf) {
      if (st.phase !== 'active' || st.peerId !== peerId || !engine) return;
      const f = unpack(buf); if (!f) return;
      st.rx++; engine.play(f.samples);
    },
    onVideo(peerId, buf) {
      if (st.phase !== 'active' || st.peerId !== peerId || !st.video) return;
      const f = unpackVideo(buf); if (!f) return;
      st.lastVideoRx = now();
      try { onVideo(peerId, f); } catch {}
    },
    /* 通话中改画质档位（只影响我发出去的画面）；关 / 开摄像头 */
    setTier(i) { st.tier = Math.min(Math.max(i | 0, 0), TIERS.length - 1); if (vengine && vengine.retier) vengine.retier(); emit(); },
    camera(on) { st.camOn = !!on; if (vengine && vengine.setEnabled) vengine.setEnabled(!!on); emit(); },
    /* 每秒调用一次：通话中加密连接断了超过 6 秒就结束通话 */
    tick() {
      if (st.phase !== 'active') { lost = 0; return; }
      if (hub.isConnected(st.peerId)) { lost = 0; return; }
      if (++lost >= 6) reset('连接已断开');
    },
    peerGone(peerId) { if (st.peerId === peerId && st.phase !== 'idle') reset('已取消配对'); }
  };
  return call;
}

/* ───────── 浏览器里的音频引擎 ─────────
 * 采集：getUserMedia（关掉回声消除 / 降噪 / 自动增益）→ AudioWorklet 每 480 个采样点打一帧 int16 → onFrame
 * 播放：收到的 int16 → float → AudioWorklet 环形缓冲（先攒 60 ms 再开始播，缺数据时补静音；积压超过 400 ms 才丢旧数据追上进度）。
 *       正常网络下积压远小于 400 ms，所以一个采样点都不会丢。 */
const WORKLET_SRC = `
class Cap extends AudioWorkletProcessor {
  constructor() { super(); this.b = new Int16Array(${FRAME}); this.n = 0; }
  process(inputs) {
    const ch = inputs[0] && inputs[0][0]; if (!ch) return true;
    for (let i = 0; i < ch.length; i++) {
      let v = ch[i]; v = v < -1 ? -1 : v > 1 ? 1 : v;
      this.b[this.n++] = v < 0 ? Math.round(v * 32768) : Math.round(v * 32767);
      if (this.n === ${FRAME}) { this.port.postMessage(this.b.buffer, [this.b.buffer]); this.b = new Int16Array(${FRAME}); this.n = 0; }
    }
    return true;
  }
}
class Play extends AudioWorkletProcessor {
  constructor() {
    super(); this.r = new Float32Array(${RATE * 2}); this.w = 0; this.rd = 0; this.n = 0; this.primed = false; this.T = ${RATE * 0.06}; this.M = ${RATE * 0.4};
    this.port.onmessage = e => {
      const d = e.data, L = this.r.length;
      for (let i = 0; i < d.length; i++) { this.r[this.w] = d[i]; this.w = (this.w + 1) % L; }
      this.n += d.length;
      if (this.n > this.M) { const drop = this.n - this.T; this.rd = (this.rd + drop) % L; this.n -= drop; }
    };
  }
  process(inputs, outputs) {
    const o = outputs[0], out = o[0], L = this.r.length;
    for (let k = 0; k < out.length; k++) {
      if (!this.primed && this.n >= this.T) this.primed = true;
      if (this.primed && this.n > 0) { out[k] = this.r[this.rd]; this.rd = (this.rd + 1) % L; this.n--; }
      else { out[k] = 0; this.primed = false; }
    }
    for (let c = 1; c < o.length; c++) o[c].set(out);
    return true;
  }
}
registerProcessor('lancast-cap', Cap);
registerProcessor('lancast-play', Play);
`;

function createBrowserEngine({ onFrame }) {
  let ctx = null, stream = null, cap = null, play = null, dead = false;
  return {
    async start() {
      stream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false, channelCount: 1, sampleRate: RATE } });
      if (dead) { stream.getTracks().forEach(t => t.stop()); return; }
      ctx = new AudioContext({ sampleRate: RATE, latencyHint: 'interactive' });
      const url = URL.createObjectURL(new Blob([WORKLET_SRC], { type: 'application/javascript' }));
      try { await ctx.audioWorklet.addModule(url); } finally { URL.revokeObjectURL(url); }
      if (dead) { this.stop(); return; }
      cap = new AudioWorkletNode(ctx, 'lancast-cap', { numberOfInputs: 1, numberOfOutputs: 1, channelCount: 1, channelCountMode: 'explicit' });
      cap.port.onmessage = e => onFrame(new Int16Array(e.data));
      const mute = ctx.createGain(); mute.gain.value = 0;                       // 采集节点必须接到输出才会被驱动；音量 0，不会把自己的声音放出来
      ctx.createMediaStreamSource(stream).connect(cap); cap.connect(mute); mute.connect(ctx.destination);
      play = new AudioWorkletNode(ctx, 'lancast-play', { numberOfInputs: 0, numberOfOutputs: 1, outputChannelCount: [2] });
      play.connect(ctx.destination);
      await ctx.resume();
    },
    play(samples) {
      if (!play) return;
      const f = new Float32Array(samples.length);
      for (let i = 0; i < samples.length; i++) f[i] = samples[i] / 32768;
      play.port.postMessage(f, [f.buffer]);
    },
    stop() {
      dead = true;
      try { if (stream) stream.getTracks().forEach(t => t.stop()); } catch {}
      try { if (cap) { cap.port.onmessage = null; cap.disconnect(); } } catch {}
      try { if (play) play.disconnect(); } catch {}
      try { if (ctx) ctx.close(); } catch {}
      ctx = stream = cap = play = null;
    }
  };
}

/* ───────── 浏览器里的视频引擎 ─────────
 * getUserMedia（只要视频）→ 隐藏的 <video> → 按档位限帧画到 canvas → toBlob(JPEG, 档位质量) → onFrame(打好包的帧)。
 * 上一帧还没编完就跳过这一帧（自然降帧，不会越积越多）；onLocalStream 把摄像头流交给界面做自拍小窗。 */
function createBrowserVideo({ tier, onFrame, onLocalStream }) {
  let stream = null, vid = null, cv = null, timer = 0, dead = false, busy = false, enabled = true, seq = 0, cur = 0;
  const closeStream = () => { clearInterval(timer); timer = 0; try { if (stream) stream.getTracks().forEach(t => t.stop()); } catch {} try { if (vid) vid.srcObject = null; } catch {} stream = vid = null; };
  async function open() {
    cur = tier(); const t = tierOf(cur);
    const s = await navigator.mediaDevices.getUserMedia({ audio: false, video: t.native ? { width: { ideal: 7680 }, height: { ideal: 4320 }, frameRate: { ideal: t.fps } } : { width: { ideal: t.w }, height: { ideal: t.h }, frameRate: { ideal: t.fps, max: t.fps } } });
    if (dead) { s.getTracks().forEach(x => x.stop()); return; }
    stream = s; vid = document.createElement('video'); vid.muted = true; vid.playsInline = true; vid.srcObject = s;
    await vid.play();
    if (!cv) cv = document.createElement('canvas');
    if (onLocalStream) onLocalStream(s);
    timer = setInterval(grab, Math.max(10, Math.round(1000 / t.fps) - 4));
  }
  function grab() {
    if (dead || !enabled || busy || !vid || !vid.videoWidth) return;
    const t = tierOf(cur), k = t.native ? 1 : Math.min(1, t.w / vid.videoWidth, t.h / vid.videoHeight);
    const w = Math.max(2, Math.round(vid.videoWidth * k)), h = Math.max(2, Math.round(vid.videoHeight * k));
    if (cv.width !== w) cv.width = w; if (cv.height !== h) cv.height = h;
    cv.getContext('2d').drawImage(vid, 0, 0, w, h);
    busy = true;
    cv.toBlob(b => {
      if (!b || dead) { busy = false; return; }
      b.arrayBuffer().then(ab => { busy = false; if (!dead && enabled && ab.byteLength <= MAX_JPEG) onFrame(packVideo(seq++, cur, 0, w, h, new Uint8Array(ab))); }, () => { busy = false; });
    }, 'image/jpeg', t.q / 100);
  }
  return {
    start() { return open(); },
    stop() { dead = true; closeStream(); },
    async retier() { if (dead || cur === tier()) return; closeStream(); try { await open(); } catch {} },
    setEnabled(on) { enabled = !!on; }
  };
}

module.exports = { RATE, CH, BITS, FRAME, HDR, pack, unpack, f2i, createCall, createBrowserEngine, VHDR, MAX_JPEG, TIERS, tierOf, packVideo, unpackVideo, createBrowserVideo };
