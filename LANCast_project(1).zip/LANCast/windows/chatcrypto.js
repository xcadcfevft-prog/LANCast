'use strict';
/* 瞬流「安全聊天」——加密与消息校验（纯逻辑，不碰 DOM / socket，方便单元测试）。规范见 docs/PROTOCOL.md 第 14 节，
 * 安卓端对应 android/.../ChatCrypto.kt，两端逐字节一致（已互相对跑验证）。
 *
 * 会话密钥：
 *   1. 握手通过后（mode = "chat"），双方各发一个 T_CHAT_KEY 帧，里面是本连接专用的 P-256 临时公钥（65 字节未压缩点，hex）；
 *   2. Z    = ECDH(本端临时私钥, 对端临时公钥)                              （32 字节）
 *      prk  = HMAC-SHA256( key = utf8(服务端nonce + ":" + 客户端cn),  msg = Z ‖ utf8(服务端的配对密钥 + ":" + 客户端的配对密钥) )
 *      key_c2s = HMAC(prk, "lancast-chat-v1 c2s " + 客户端epk + " " + 服务端epk + 0x01)    客户端 → 服务端
 *      key_s2c = HMAC(prk, "lancast-chat-v1 s2c " + 客户端epk + " " + 服务端epk + 0x01)    服务端 → 客户端
 *      sas     = HMAC(prk, "lancast-chat-v1 sas" + 0x01) 前 6 字节 → 12 位数字「安全码」，两边应当一致
 *   3. 双方的配对密钥都参与了派生：不知道配对密钥的中间人即使替换了双方的公钥，也算不出任何一端的密钥，消息根本解不开；
 *      已配对的设备 X 想冒充另一台已配对设备 Y（HELLO 里的 id 是自报的），因为不知道 Y 自己的配对密钥，同样算不出同一把钥匙。
 *
 * 消息：T_CHAT_MSG 帧正文 = u64 计数器(大端) ‖ AES-256-GCM 密文 ‖ 16 字节标签
 *   IV = 4 个 0 字节 ‖ 计数器；AAD = 计数器的 8 个字节；两个方向各用各的密钥，所以 IV 不会重复。
 *   接收方要求计数器严格递增（防重放 / 乱序重放），解密失败就断开连接。
 */
const crypto = require('crypto');

const T_CHAT_KEY = 48, T_CHAT_MSG = 49, T_CHAT_VOICE = 50, T_CHAT_VIDEO = 51;     // T_CHAT_VOICE：语音通话的原始 PCM 帧（docs/PROTOCOL.md 第 16 节）
const MAX_TEXT = 4000;                         // 一条文字消息最多 4000 个字符
const MAX_VIDEO_FRAME = 4 * 1024 * 1024;       // 视频帧（JPEG）最大 4 MiB（docs/PROTOCOL.md 第 17 节）
const MAX_FRAME = 64 * 1024;                   // 一帧（密文）最大 64 KiB
const HEX_RE = /^[0-9a-f]+$/;
/* 头像同步（第 20 节）：头像缩略图（正方形 JPEG，≤ AV_MAX_BYTES）按块经加密聊天连接传输 */
const AV_MAX_BYTES = 30 * 1024 * 1024, AV_CHUNK = 24 * 1024, AV_MAX_CHUNKS = Math.ceil(AV_MAX_BYTES / AV_CHUNK);
const AV_HASH_RE = /^[0-9a-f]{32}$/, B64_RE = /^[A-Za-z0-9+/]*={0,2}$/;
const COLOR_RE = /^#[0-9a-fA-F]{6}$/;

const hmac = (key, msg) => crypto.createHmac('sha256', key).update(msg).digest();

/* ───────── 密钥交换 ───────── */
function genEphemeral() {
  const ecdh = crypto.createECDH('prime256v1');
  ecdh.generateKeys();
  return { ecdh, pub: ecdh.getPublicKey('hex') };          // 130 个 hex 字符，以 04 开头
}
function validPub(hex) { return typeof hex === 'string' && hex.length === 130 && hex.startsWith('04') && HEX_RE.test(hex); }

/* isClient：本端是否是发起连接的一方；serverNonce / clientNonce：握手里的两个随机数（hex 字符串）；pin：「服务端配对密钥:客户端配对密钥」（双方相同）。
 * 对端公钥不在曲线上时 computeSecret 会抛异常，调用方按「安全校验失败」处理。 */
function deriveSession({ eph, peerPub, isClient, serverNonce, clientNonce, pin }) {
  if (!validPub(peerPub)) throw new Error('对方的密钥格式不对');
  const z = eph.ecdh.computeSecret(Buffer.from(peerPub, 'hex'));
  const epkC = isClient ? eph.pub : peerPub, epkS = isClient ? peerPub : eph.pub;
  const prk = hmac(Buffer.from(serverNonce + ':' + clientNonce, 'utf8'), Buffer.concat([z, Buffer.from(String(pin), 'utf8')]));
  const kdf = label => hmac(prk, Buffer.concat([Buffer.from('lancast-chat-v1 ' + label + epkC + ' ' + epkS, 'utf8'), Buffer.from([1])]));
  const c2s = kdf('c2s '), s2c = kdf('s2c ');
  const sasRaw = hmac(prk, Buffer.concat([Buffer.from('lancast-chat-v1 sas', 'utf8'), Buffer.from([1])])).subarray(0, 6);
  const sasNum = (BigInt('0x' + sasRaw.toString('hex')) % 1000000000000n).toString().padStart(12, '0');
  return { txKey: isClient ? c2s : s2c, rxKey: isClient ? s2c : c2s, sas: sasNum.replace(/(\d{4})(?=\d)/g, '$1 ') };
}

/* ───────── 消息加解密 ───────── */
function ivOf(ctr) { const iv = Buffer.alloc(12); iv.writeBigUInt64BE(BigInt(ctr), 4); return iv; }
function ctrBytes(ctr) { const b = Buffer.alloc(8); b.writeBigUInt64BE(BigInt(ctr)); return b; }
function seal(key, ctr, obj) {
  const c = crypto.createCipheriv('aes-256-gcm', key, ivOf(ctr));
  c.setAAD(ctrBytes(ctr));
  const ct = Buffer.concat([c.update(Buffer.from(JSON.stringify(obj), 'utf8')), c.final()]);
  return Buffer.concat([ctrBytes(ctr), ct, c.getAuthTag()]);
}
/* 返回 { ctr, obj }；任何问题（太短、计数器不递增、标签不对、不是 JSON 对象）都抛异常 */
function open(key, buf, lastCtr) {
  if (buf.length < 8 + 16 + 2 || buf.length > MAX_FRAME) throw new Error('消息长度不对');
  const big = buf.readBigUInt64BE(0);
  if (big > BigInt(Number.MAX_SAFE_INTEGER)) throw new Error('计数器越界');
  const ctr = Number(big);
  if (ctr <= lastCtr) throw new Error('重复或过期的消息');
  const d = crypto.createDecipheriv('aes-256-gcm', key, ivOf(ctr));
  d.setAAD(ctrBytes(ctr));
  d.setAuthTag(buf.subarray(buf.length - 16));
  const pt = Buffer.concat([d.update(buf.subarray(8, buf.length - 16)), d.final()]);
  const obj = JSON.parse(pt.toString('utf8'));
  if (!obj || typeof obj !== 'object' || Array.isArray(obj)) throw new Error('消息格式不对');
  return { ctr, obj };
}

/* 二进制版（语音帧用）：和 seal / open 共用同一个计数器序列与同一把密钥，格式完全一样，只是明文是原始字节而不是 JSON */
function sealBin(key, ctr, plain) {
  const c = crypto.createCipheriv('aes-256-gcm', key, ivOf(ctr));
  c.setAAD(ctrBytes(ctr));
  const ct = Buffer.concat([c.update(plain), c.final()]);
  return Buffer.concat([ctrBytes(ctr), ct, c.getAuthTag()]);
}
function openBin(key, buf, lastCtr, maxLen = MAX_FRAME) {
  if (buf.length < 8 + 16 + 1 || buf.length > maxLen) throw new Error('消息长度不对');
  const big = buf.readBigUInt64BE(0);
  if (big > BigInt(Number.MAX_SAFE_INTEGER)) throw new Error('计数器越界');
  const ctr = Number(big);
  if (ctr <= lastCtr) throw new Error('重复或过期的消息');
  const d = crypto.createDecipheriv('aes-256-gcm', key, ivOf(ctr));
  d.setAAD(ctrBytes(ctr));
  d.setAuthTag(buf.subarray(buf.length - 16));
  return { ctr, buf: Buffer.concat([d.update(buf.subarray(8, buf.length - 16)), d.final()]) };
}

/* ───────── 消息内容 ───────── */
const newMsgId = () => crypto.randomBytes(8).toString('hex');
const ID_RE = /^[0-9a-f]{8,32}$/;
const clip = (s, n) => { s = String(s == null ? '' : s); const a = [...s]; return a.length > n ? a.slice(0, n).join('') : s; };


/* ───────── 五子棋对战（第 19 节）─────────
 * {t:"gm", op, gid}：op = invite（带 side=邀请方执哪色、turn=谁先手）| accept | reject | busy | end
 * {t:"gm", op:"g", gid, d}：对局里的一条消息，d.k 见下表。全部限长 / 限范围，不合法的丢弃。 */
const GM_OPS = ['invite', 'accept', 'reject', 'busy', 'end'];
function sanitizeGameData(d) {
  if (!d || typeof d.k !== 'string') return null;
  const int = (v, lo, hi) => Number.isInteger(v) && v >= lo && v <= hi;
  switch (d.k) {
    case 'mv': return int(d.x, 0, 14) && int(d.y, 0, 14) && int(d.n, 0, 225) ? { k: 'mv', x: d.x, y: d.y, n: d.n } : null;
    case 'ur': case 'ua': case 'fr': return int(d.n, 0, 225) ? { k: d.k, n: d.n } : null;
    case 'uc': case 'un': case 'fc': case 'fa': case 'fn': case 'sr': case 'sc': case 'sa': case 'sn': case 'rs': return { k: d.k };
    case 'ng': return int(d.t, 1, 2) && int(d.g, 0, 1000000) ? { k: 'ng', t: d.t, g: d.g } : null;
    case 'ch': { const x = clip(d.x, 200); return x.trim() ? { k: 'ch', x } : null; }
    case 'sy': return typeof d.s === 'string' && /^[0-9,]{1,80}$/.test(d.s) ? { k: 'sy', s: d.s } : null;
    case 'st': {
      if (!Array.isArray(d.m) || d.m.length > 225) return null;
      const m = [];
      for (const v of d.m) { if (!Array.isArray(v) || !int(v[0], 0, 14) || !int(v[1], 0, 14) || !int(v[2], 1, 2)) return null; m.push([v[0], v[1], v[2]]); }
      if (!int(d.g, 0, 1000000) || !int(d.t, 1, 2) || !int(d.w, 0, 2) || !int(d.a, 0, 100000) || !int(d.b, 0, 100000)) return null;
      return { k: 'st', g: d.g, m, t: d.t, o: d.o ? 1 : 0, w: d.w, a: d.a, b: d.b, u: int(d.u, 0, 2) ? d.u : 0, f: int(d.f, 0, 2) ? d.f : 0, r: int(d.r, 0, 2) ? d.r : 0 };
    }
    default: return null;
  }
}
function sanitizeGame(o) {
  if (!ID_RE.test(String(o.gid))) return null;
  const gid = String(o.gid);
  if (GM_OPS.includes(o.op)) {
    const r = { t: 'gm', op: o.op, gid };
    if (o.op === 'invite') { r.side = o.side === 2 ? 2 : 1; r.turn = o.turn === 2 ? 2 : 1; }
    return r;
  }
  if (o.op === 'g') { const d = sanitizeGameData(o.d); return d ? { t: 'gm', op: 'g', gid, d } : null; }
  return null;
}

/* 把对方发来的明文对象整理成本机可以直接显示的消息；不合法返回 null（调用方丢弃）。所有字段都限长，颜色只接受 #rrggbb。 */
function sanitizeIncoming(o) {
  if (!o || typeof o.t !== 'string') return null;
  if (o.t === 'a' || o.t === 'd' || o.t === 'da') return ID_RE.test(String(o.id)) ? { t: o.t, id: String(o.id) } : null;     // a 回执 | d 撤回 | da 撤回回执
  if (o.t === 'hi') return { t: 'hi', name: clip(o.name, 64), id: clip(o.id, 64) };
  if (o.t === 'vc') {                                     // 语音通话信令：invite 呼叫 | accept 接听 | reject 拒绝 | busy 忙线 | end 挂断
    if (!['invite', 'accept', 'reject', 'busy', 'end'].includes(o.op)) return null;
    const n = (v, d) => Number.isInteger(v) ? v : d;
    const r = { t: 'vc', op: o.op, rate: n(o.rate, 48000), ch: n(o.ch, 1), bits: n(o.bits, 16) };
    if (o.vid === true) r.vid = true;                       // 这通电话带视频（第 17 节）
    return r;
  }
  if (o.t === 'avh') return o.h === '' ? { t: 'avh', h: '' } : AV_HASH_RE.test(String(o.h)) ? { t: 'avh', h: String(o.h) } : null;   // 头像通告：h = 缩略图哈希，空串 = 没有头像
  if (o.t === 'avr') return AV_HASH_RE.test(String(o.h)) ? { t: 'avr', h: String(o.h) } : null;                                  // 头像请求
  if (o.t === 'avd') {                                    // 头像数据块
    const b = typeof o.b === 'string' ? o.b : '';
    if (!AV_HASH_RE.test(String(o.h)) || !Number.isInteger(o.i) || !Number.isInteger(o.n) || o.n < 1 || o.n > AV_MAX_CHUNKS || o.i < 0 || o.i >= o.n) return null;
    if (!b || b.length > Math.ceil(AV_CHUNK / 3) * 4 + 4 || !B64_RE.test(b)) return null;
    return { t: 'avd', h: String(o.h), i: o.i, n: o.n, b };
  }
  if (o.t === 'bio') return { t: 'bio', x: clip(typeof o.x === 'string' ? o.x.trim() : '', 200) };     // 主页介绍（docs/PROTOCOL.md 第 21 节）：空串 = 清除
  if (o.t === 'gm') return sanitizeGame(o);              // 五子棋对战信令 / 对局消息（docs/PROTOCOL.md 第 19 节）
  if (o.t !== 'm' && o.t !== 's') return null;
  if (!ID_RE.test(String(o.id))) return null;
  const ts = Number.isFinite(o.ts) ? Math.min(Math.max(0, Math.floor(o.ts)), Date.now() + 86400000) : Date.now();
  if (o.t === 'm') { const x = clip(o.x, MAX_TEXT); return x.trim() ? { t: 'm', id: String(o.id), ts, x } : null; }
  const e = clip(o.e, 16), c = clip(o.c, 16);
  if (!e) return null;
  const bg = Array.isArray(o.bg) ? o.bg.filter(v => COLOR_RE.test(String(v))).slice(0, 2).map(String) : [];
  return { t: 's', id: String(o.id), ts, e, c, bg: bg.length === 2 ? bg : ['#fff3c4', '#ffd37a'] };
}

module.exports = { T_CHAT_KEY, T_CHAT_MSG, T_CHAT_VOICE, T_CHAT_VIDEO, MAX_TEXT, MAX_FRAME, MAX_VIDEO_FRAME, AV_MAX_BYTES, AV_CHUNK, AV_MAX_CHUNKS, genEphemeral, validPub, deriveSession, seal, open, sealBin, openBin, newMsgId, sanitizeIncoming, sanitizeGameData, clip };
