'use strict';
/* 瞬流「安全聊天」——加密与消息校验（纯逻辑，不碰 DOM / socket，方便单元测试）。规范见 docs/PROTOCOL.md 第 14 节，
 * 安卓端对应 android/.../ChatCrypto.kt，两端逐字节一致（已互相对跑验证）。
 *
 * 会话密钥：
 *   1. 握手通过后（mode = "chat"），双方各发一个 T_CHAT_KEY 帧，里面是本连接专用的 P-256 临时公钥（65 字节未压缩点，hex）；
 *   2. Z    = ECDH(本端临时私钥, 对端临时公钥)                              （32 字节）
 *      prk  = HMAC-SHA256( key = utf8(服务端nonce + ":" + 客户端cn),  msg = Z ‖ utf8(服务端的配对密钥 + ":" + 客户端的配对密钥) )
 *      key_c2s = HMAC(prk, "lancast-chat-v1 c2s " + 客户端epk + " " + 服务端epk + 0x01)    客户端 → 服务端
 *      key_s2c = HMAC(prk, "lancast-chat-v1 s2c " + 客户端epk + " " + 服务端epk + 0x01)    服务端 → 客户端
 *      sas     = HMAC(prk, "lancast-chat-v1 sas" + 0x01) 前 6 字节 → 12 位数字「安全码」，两边应当一致
 *   3. 双方的配对密钥都参与了派生：不知道配对密钥的中间人即使替换了双方的公钥，也算不出任何一端的密钥，消息根本解不开；
 *      已配对的设备 X 想冒充另一台已配对设备 Y（HELLO 里的 id 是自报的），因为不知道 Y 自己的配对密钥，同样算不出同一把钥匙。
 *
 * 消息：T_CHAT_MSG 帧正文 = u64 计数器(大端) ‖ AES-256-GCM 密文 ‖ 16 字节标签
 *   IV = 4 个 0 字节 ‖ 计数器；AAD = 计数器的 8 个字节；两个方向各用各的密钥，所以 IV 不会重复。
 *   接收方要求计数器严格递增（防重放 / 乱序重放），解密失败就断开连接。
 */
const crypto = require('crypto');

const T_CHAT_KEY = 48, T_CHAT_MSG = 49;
const MAX_TEXT = 4000;                         // 一条文字消息最多 4000 个字符
const MAX_FRAME = 64 * 1024;                   // 一帧（密文）最大 64 KiB
const HEX_RE = /^[0-9a-f]+$/;
const COLOR_RE = /^#[0-9a-fA-F]{6}$/;

const hmac = (key, msg) => crypto.createHmac('sha256', key).update(msg).digest();

/* ───────── 密钥交换 ───────── */
function genEphemeral() {
  const ecdh = crypto.createECDH('prime256v1');
  ecdh.generateKeys();
  return { ecdh, pub: ecdh.getPublicKey('hex') };          // 130 个 hex 字符，以 04 开头
}
function validPub(hex) { return typeof hex === 'string' && hex.length === 130 && hex.startsWith('04') && HEX_RE.test(hex); }

/* isClient：本端是否是发起连接的一方；serverNonce / clientNonce：握手里的两个随机数（hex 字符串）；pin：「服务端配对密钥:客户端配对密钥」（双方相同）。
 * 对端公钥不在曲线上时 computeSecret 会抛异常，调用方按「安全校验失败」处理。 */
function deriveSession({ eph, peerPub, isClient, serverNonce, clientNonce, pin }) {
  if (!validPub(peerPub)) throw new Error('对方的密钥格式不对');
  const z = eph.ecdh.computeSecret(Buffer.from(peerPub, 'hex'));
  const epkC = isClient ? eph.pub : peerPub, epkS = isClient ? peerPub : eph.pub;
  const prk = hmac(Buffer.from(serverNonce + ':' + clientNonce, 'utf8'), Buffer.concat([z, Buffer.from(String(pin), 'utf8')]));
  const kdf = label => hmac(prk, Buffer.concat([Buffer.from('lancast-chat-v1 ' + label + epkC + ' ' + epkS, 'utf8'), Buffer.from([1])]));
  const c2s = kdf('c2s '), s2c = kdf('s2c ');
  const sasRaw = hmac(prk, Buffer.concat([Buffer.from('lancast-chat-v1 sas', 'utf8'), Buffer.from([1])])).subarray(0, 6);
  const sasNum = (BigInt('0x' + sasRaw.toString('hex')) % 1000000000000n).toString().padStart(12, '0');
  return { txKey: isClient ? c2s : s2c, rxKey: isClient ? s2c : c2s, sas: sasNum.replace(/(\d{4})(?=\d)/g, '$1 ') };
}

/* ───────── 消息加解密 ───────── */
function ivOf(ctr) { const iv = Buffer.alloc(12); iv.writeBigUInt64BE(BigInt(ctr), 4); return iv; }
function ctrBytes(ctr) { const b = Buffer.alloc(8); b.writeBigUInt64BE(BigInt(ctr)); return b; }
function seal(key, ctr, obj) {
  const c = crypto.createCipheriv('aes-256-gcm', key, ivOf(ctr));
  c.setAAD(ctrBytes(ctr));
  const ct = Buffer.concat([c.update(Buffer.from(JSON.stringify(obj), 'utf8')), c.final()]);
  return Buffer.concat([ctrBytes(ctr), ct, c.getAuthTag()]);
}
/* 返回 { ctr, obj }；任何问题（太短、计数器不递增、标签不对、不是 JSON 对象）都抛异常 */
function open(key, buf, lastCtr) {
  if (buf.length < 8 + 16 + 2 || buf.length > MAX_FRAME) throw new Error('消息长度不对');
  const big = buf.readBigUInt64BE(0);
  if (big > BigInt(Number.MAX_SAFE_INTEGER)) throw new Error('计数器越界');
  const ctr = Number(big);
  if (ctr <= lastCtr) throw new Error('重复或过期的消息');
  const d = crypto.createDecipheriv('aes-256-gcm', key, ivOf(ctr));
  d.setAAD(ctrBytes(ctr));
  d.setAuthTag(buf.subarray(buf.length - 16));
  const pt = Buffer.concat([d.update(buf.subarray(8, buf.length - 16)), d.final()]);
  const obj = JSON.parse(pt.toString('utf8'));
  if (!obj || typeof obj !== 'object' || Array.isArray(obj)) throw new Error('消息格式不对');
  return { ctr, obj };
}

/* ───────── 消息内容 ───────── */
const newMsgId = () => crypto.randomBytes(8).toString('hex');
const ID_RE = /^[0-9a-f]{8,32}$/;
const clip = (s, n) => { s = String(s == null ? '' : s); const a = [...s]; return a.length > n ? a.slice(0, n).join('') : s; };

/* 把对方发来的明文对象整理成本机可以直接显示的消息；不合法返回 null（调用方丢弃）。所有字段都限长，颜色只接受 #rrggbb。 */
function sanitizeIncoming(o) {
  if (!o || typeof o.t !== 'string') return null;
  if (o.t === 'a') return ID_RE.test(String(o.id)) ? { t: 'a', id: String(o.id) } : null;
  if (o.t === 'hi') return { t: 'hi', name: clip(o.name, 64), id: clip(o.id, 64) };
  if (o.t !== 'm' && o.t !== 's') return null;
  if (!ID_RE.test(String(o.id))) return null;
  const ts = Number.isFinite(o.ts) ? Math.min(Math.max(0, Math.floor(o.ts)), Date.now() + 86400000) : Date.now();
  if (o.t === 'm') { const x = clip(o.x, MAX_TEXT); return x.trim() ? { t: 'm', id: String(o.id), ts, x } : null; }
  const e = clip(o.e, 16), c = clip(o.c, 16);
  if (!e) return null;
  const bg = Array.isArray(o.bg) ? o.bg.filter(v => COLOR_RE.test(String(v))).slice(0, 2).map(String) : [];
  return { t: 's', id: String(o.id), ts, e, c, bg: bg.length === 2 ? bg : ['#fff3c4', '#ffd37a'] };
}

module.exports = { T_CHAT_KEY, T_CHAT_MSG, MAX_TEXT, MAX_FRAME, genEphemeral, validPub, deriveSession, seal, open, newMsgId, sanitizeIncoming, clip };
