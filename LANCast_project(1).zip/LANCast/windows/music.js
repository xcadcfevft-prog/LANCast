'use strict';
/* 瞬流「沉浸音乐」—— 纯逻辑（不碰 DOM / socket），方便单元测试。规范见 docs/PROTOCOL.md 第 23 节，手机端对应 android/.../MusicRing.kt、MusicService.kt。
 *
 * 一句话：手机把系统正在播放的声音（无损 PCM）+ 歌曲信息（歌名 / 歌手 / 封面 / 进度 / 状态）实时发给电脑，电脑渲染成播放器，
 * 并可把「播放 / 暂停 / 上一首 / 下一首 / 拖动进度」发回手机。全程没有屏幕采集，所以手机息屏不会终止它。
 *
 * 帧类型（与投屏共用 16 字节包头，大端）：
 *   18 ACONFIG   手机→电脑  JSON {rate, ch, fmt:"s16", music:1, sid}          音频格式（每次连接开头发一次）
 *   19 ADATA     手机→电脑  pts = 这块音频的起始「帧序号」（u64，从 0 起，一个声道样本组 = 1 帧）
 *                           flags bit0 = 0：载荷 = 交错 s16le PCM；
 *                           flags bit0 = 1：整块静音，载荷 = u32 帧数（BE），电脑自己补零（无损等价，静音时几乎不占带宽）
 *   60 META      手机→电脑  JSON，歌曲信息 / 进度 / 状态（有变化即发 + 每秒一次，兼作应用层心跳）
 *   61 COVER     手机→电脑  载荷 = 16 字节 ASCII 封面哈希 + 图片原字节（PNG；过大时 JPEG，按文件头识别）
 *   62 CMD       电脑→手机  JSON {cmd: play|pause|toggle|next|prev|seek|stop, pos?}
 *   5  CTRL      电脑→手机  {cmd:"mack", next:N, fresh?:true}   「N 之前的帧我都收到了」；每次连接开头必发一次（fresh = 电脑没有这个 sid 的状态，从实时开始）
 *
 * 断线不丢音：手机把最近 90 秒的音频放在环形缓冲里，连接断开后自动重连，电脑用 mack.next 告诉手机「从第 N 帧继续」，手机补发缺的部分；
 * 电脑端按帧序号去重 / 对齐，所以补发多少都不会重复、不会错位。
 */

const T = { CTRL: 5, ACONFIG: 18, ADATA: 19, META: 60, COVER: 61, CMD: 62 };
const FLAG_SILENT = 1;
const HASH_LEN = 16;
const CMDS = new Set(['play', 'pause', 'toggle', 'next', 'prev', 'seek', 'stop', 'pmute']);
const STATES = new Set(['playing', 'paused', 'stopped', 'buffering', 'none']);

/* 帧序号去重 / 对齐。accept() 返回要播放的部分（从 chunk 里第几帧开始），重复的返回 null。 */
class AudioRx {
  constructor() { this.next = 0; this.started = false; this.gapFrames = 0; this.dupFrames = 0; this.frames = 0; }
  accept(idx, frames) {
    if (!(frames > 0)) return null;
    if (!this.started) { this.started = true; this.next = idx; }
    if (idx + frames <= this.next) { this.dupFrames += frames; return null; }
    let off = 0;
    if (idx > this.next) this.gapFrames += idx - this.next;          // 手机缓冲已经装不下了：这一段丢了（只有断线超过缓存时长 90 秒才会发生）
    else if (idx < this.next) { off = this.next - idx; this.dupFrames += off; }
    this.next = idx + frames; this.frames += frames - off;
    return { off, frames: frames - off };
  }
}

/* ADATA 载荷 → { idx, frames, silent, off, pcm }；格式错误抛异常。ch：声道数。 */
function parseAudio(flags, pts, pl, ch) {
  if (flags & FLAG_SILENT) {
    if (pl.length < 4) throw new Error('bad silent block');
    const n = pl.readUInt32BE(0);
    if (n > 48000 * 60) throw new Error('silent block too long');
    return { idx: pts, frames: n, silent: true, pcm: null };
  }
  const fb = 2 * ch;
  if (pl.length === 0 || pl.length % fb) throw new Error('bad pcm length');
  return { idx: pts, frames: pl.length / fb, silent: false, pcm: pl };
}

/* 把交错 s16le 转成两个 Float32Array（单声道时 r === l）；off 帧起跳过。 */
function s16ToPlanar(pcm, ch, off, frames) {
  const v = new DataView(pcm.buffer, pcm.byteOffset, pcm.length);
  const l = new Float32Array(frames), r = ch > 1 ? new Float32Array(frames) : l;
  let p = off * ch * 2;
  for (let i = 0; i < frames; i++) {
    l[i] = v.getInt16(p, true) / 32768; p += 2;
    if (ch > 1) { r[i] = v.getInt16(p, true) / 32768; p += 2 * (ch - 1); }
  }
  return { l, r };
}

function parseConfig(j) {
  const rate = Number(j.rate), ch = Number(j.ch);
  if (!(rate >= 8000 && rate <= 384000) || !(ch === 1 || ch === 2) || j.fmt !== 's16') throw new Error('unsupported audio format');
  return { rate, ch, fmt: 's16', sid: typeof j.sid === 'string' ? j.sid.slice(0, 64) : '' };
}

/* 元数据清洗：来自对方的 JSON 不可信，限长、限类型。 */
const str = (v, n) => (typeof v === 'string' ? v.slice(0, n) : '');
const num = (v, lo, hi, d) => { v = Number(v); return Number.isFinite(v) ? Math.min(hi, Math.max(lo, v)) : d; };
function cleanMeta(j) {
  return {
    title: str(j.title, 300), artist: str(j.artist, 300), album: str(j.album, 300), app: str(j.app, 100),
    duration: num(j.duration, 0, 7 * 24 * 3600e3, 0), pos: num(j.pos, 0, 7 * 24 * 3600e3, 0), speed: num(j.speed, 0, 8, 1),
    state: STATES.has(j.state) ? j.state : 'none', cover: str(j.cover, HASH_LEN),
    can: Array.isArray(j.can) ? j.can.map(String).filter(c => CMDS.has(c)).slice(0, 8) : [],
    ctl: j.ctl === true,                       // 手机端能不能被远程控制（没给通知使用权就不能）
    sid: str(j.sid, 64),
    pmute: j.pmute === true                    // 手机本机是否已静音（电脑照常出声）
  };
}

/* 显示用的进度（毫秒）：手机报的位置 + 报告之后经过的时间，再减去电脑端还没播出去的缓冲（电脑播得比手机晚） */
function estimatePos(meta, recvAt, now, bufferedMs) {
  if (!meta) return 0;
  let p = meta.pos;
  if (meta.state === 'playing') p += (now - recvAt) * (meta.speed || 1);
  p -= meta.state === 'stopped' ? 0 : bufferedMs * (meta.speed || 1);
  p = Math.max(0, p);
  return meta.duration > 0 ? Math.min(p, meta.duration) : p;
}

/* 时钟漂移补偿：手机采集时钟与电脑声卡时钟不是同一个晶振，长时间播放缓冲会越积越多或越来越少。
 * 缓冲偏离目标不到 40 ms 时 ratio 恒为 1（逐位原样输出）；偏离更大才以 0.02%–0.2% 的极小倍率追回（≤3.5 音分，听不出），回到 10 ms 内即停止。
 * 返回播放倍率（>1 = 消耗得更快）。active：当前是否正在补偿（滞回，避免在阈值附近来回切）。注意：此函数会被 toString() 注入 AudioWorklet，必须自包含。 */
function driftRatio(level, target, rate, active) {
  const err = (level - target) / rate, a = Math.abs(err);
  if (a < (active ? 0.01 : 0.04)) return 1;
  const m = Math.min(0.002, Math.max(0.0002, a * 0.002));
  return err > 0 ? 1 + m : 1 - m;
}

function fmtTime(ms) {
  const s = Math.max(0, Math.floor(ms / 1000)), h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = s % 60;
  const p = n => String(n).padStart(2, '0');
  return h ? h + ':' + p(m) + ':' + p(x) : m + ':' + p(x);
}

function parseCover(pl) {
  if (pl.length <= HASH_LEN) throw new Error('bad cover');
  return { hash: pl.subarray(0, HASH_LEN).toString('latin1'), img: pl.subarray(HASH_LEN) };
}
function imageMime(b) {
  if (b[0] === 0x89 && b[1] === 0x50) return 'image/png';
  if (b[0] === 0xff && b[1] === 0xd8) return 'image/jpeg';
  if (b.length > 12 && b.subarray(0, 4).toString('latin1') === 'RIFF' && b.subarray(8, 12).toString('latin1') === 'WEBP') return 'image/webp';
  return '';
}

module.exports = { T, FLAG_SILENT, HASH_LEN, CMDS, AudioRx, parseAudio, s16ToPlanar, parseConfig, cleanMeta, estimatePos, driftRatio, fmtTime, parseCover, imageMime };
