'use strict';
/* LANCast Windows 端（渲染进程）
 * 传输：TCP 47800（视频/音频/控制复用一条连接）；发现：UDP 广播 47801
 * 视频：H.264 (Annex-B)，WebCodecs 硬件编解码，发送端拥塞时丢帧并等下一个关键帧（不花屏）
 * 音频：无损 PCM（Windows→手机为 float32，手机→Windows 为 int16），不经过任何有损编码
 */
const net = require('net');
const dgram = require('dgram');
const os = require('os');
const crypto = require('crypto');
const { ipcRenderer } = require('electron');

const PORT = 47800, DISC_PORT = 47801;
const T = { HELLO: 1, CHALLENGE: 2, ACCEPT: 3, REJECT: 4, CTRL: 5, VCONFIG: 16, VFRAME: 17, ACONFIG: 18, ADATA: 19, PING: 20, PONG: 21 };
const QUALITY = {
  lossless: { bpp: 0.30, max: 100e6, min: 10e6 },
  balanced: { bpp: 0.16, max: 50e6, min: 6e6 },
  smooth:   { bpp: 0.08, max: 25e6, min: 4e6 }
};
const $ = s => document.querySelector(s);
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const even = n => Math.max(2, Math.floor(n / 2) * 2);
const LS = {
  get(k, d) { try { const v = localStorage.getItem(k); return v === null ? d : v; } catch { return d; } },
  set(k, v) { try { localStorage.setItem(k, String(v)); } catch {} }
};

function newPin() { const p = String(crypto.randomInt(0, 1000000)).padStart(6, '0'); LS.set('pin', p); return p; }
let myId = LS.get('id', null);
if (!myId) { myId = crypto.randomBytes(8).toString('hex'); LS.set('id', myId); }
let myPin = LS.get('pin', null) || newPin();
const myName = os.hostname();

function avcCodec(w, h, fps) {            // 按分辨率*帧率选 H.264 High Profile 的 Level
  const mbps = Math.ceil(w / 16) * Math.ceil(h / 16) * fps;
  const lv = mbps <= 245760 ? 0x28 : mbps <= 522240 ? 0x2A : mbps <= 589824 ? 0x32 : mbps <= 983040 ? 0x33 : 0x34;
  return 'avc1.6400' + lv.toString(16).toUpperCase().padStart(2, '0');
}
function localIPs() {
  const r = [], ifs = os.networkInterfaces();
  for (const k in ifs) for (const a of ifs[k]) if ((a.family === 'IPv4' || a.family === 4) && !a.internal) r.push(a.address);
  return r;
}

/* ───────────────────────── 会话（TCP 封包） ─────────────────────────
 * 包头 16 字节(大端)：type u8 | flags u8 | reserved u16 | len u32 | pts u64(微秒)
 */
class Session {
  constructor(sock, isServer) {
    this.sock = sock; this.isServer = isServer; this.alive = true; this.state = 'init';
    this.chunks = []; this.have = 0;
    this.peerName = ''; this.peerPlatform = ''; this.mode = '';
    this.early = []; this.onPacket = (...a) => this.early.push(a);
    this.onClose = null; this.onCongestion = null;
    this.lastRx = Date.now(); this.rtt = 0; this.needKey = false; this.maxBacklog = 600000;
    sock.setNoDelay(true);
    sock.on('data', d => { this.lastRx = Date.now(); this._onData(d); });
    sock.on('error', e => this.close('连接错误: ' + e.message));
    sock.on('close', () => this.close('连接已断开'));
    this.timer = setInterval(() => {
      if (!this.alive || this.state !== 'ready') return;
      this._w(this._hdr(Buffer.allocUnsafe(16), T.PING, 0, performance.now() * 1000, 0));
      if (Date.now() - this.lastRx > 6000) this.close('连接超时');
    }, 1000);
  }
  attach(fn) { this.onPacket = fn; const e = this.early; this.early = []; for (const a of e) fn(...a); }
  _hdr(b, type, flags, pts, len) {
    b[0] = type; b[1] = flags; b.writeUInt16BE(0, 2); b.writeUInt32BE(len, 4);
    pts = Math.max(0, Math.floor(pts || 0));
    b.writeUInt32BE(Math.floor(pts / 4294967296) >>> 0, 8); b.writeUInt32BE(pts >>> 0, 12);
    return b;
  }
  _w(b) { if (this.alive) this.sock.write(b); }
  _merge() { if (this.chunks.length > 1) this.chunks = [Buffer.concat(this.chunks, this.have)]; }
  _onData(d) {
    this.chunks.push(d); this.have += d.length;
    for (;;) {
      if (this.have < 16) return;
      if (this.chunks[0].length < 16) this._merge();
      const len = this.chunks[0].readUInt32BE(4);
      if (len > 64 * 1024 * 1024) { this.close('收到非法数据'); return; }
      if (this.have < 16 + len) return;
      this._merge();
      const b = this.chunks[0];
      const type = b[0], flags = b[1];
      const pts = b.readUInt32BE(8) * 4294967296 + b.readUInt32BE(12);
      const payload = b.subarray(16, 16 + len);
      const rest = b.subarray(16 + len);
      this.chunks = rest.length ? [rest] : []; this.have = rest.length;
      this._dispatch(type, flags, pts, payload);
      if (!this.alive) return;
    }
  }
  _dispatch(t, f, pts, pl) {
    if (t === T.PING) { this._w(this._hdr(Buffer.allocUnsafe(16), T.PONG, 0, pts, 0)); return; }
    if (t === T.PONG) { this.rtt = (performance.now() * 1000 - pts) / 1000; return; }
    try { this.onPacket(t, f, pts, pl); } catch (e) { console.error('packet handler', e); }
  }
  sendJson(type, obj) {
    const body = Buffer.from(JSON.stringify(obj), 'utf8');
    const b = this._hdr(Buffer.allocUnsafe(16 + body.length), type, 0, 0, body.length);
    body.copy(b, 16); this._w(b);
  }
  sendCtrl(obj) { this.sendJson(T.CTRL, obj); }
  sendAudio(b) { if (this.alive && this.sock.writableLength < 2e6) this.sock.write(b); }
  /* 视频：发送队列超过阈值 = 网络跟不上 → 丢弃该帧，并且在下一个关键帧到来前丢弃所有后续帧 */
  sendVideo(chunk) {
    if (!this.alive) return;
    const key = chunk.type === 'key', size = chunk.byteLength;
    if (this.needKey && !key) return;
    const q = this.sock.writableLength;
    if (q > 0 && q + size > this.maxBacklog) {
      this.needKey = true;
      if (this.onCongestion) this.onCongestion();
      return;
    }
    if (key) this.needKey = false;
    const b = this._hdr(Buffer.allocUnsafe(16 + size), T.VFRAME, key ? 1 : 0, chunk.timestamp, size);
    chunk.copyTo(b.subarray(16));
    this.sock.write(b);
  }
  close(reason) {
    if (!this.alive) return;
    this.alive = false; clearInterval(this.timer);
    try { this.sock.destroy(); } catch {}
    if (this.onClose) { const f = this.onClose; this.onClose = null; f(reason); }
  }
}

/* ───────────────────────── 界面辅助 ───────────────────────── */
function setStatus(msg, err) { const e = $('#status'); e.textContent = msg; e.className = err ? 'err' : ''; }
function showViewer(on) { $('#home').hidden = on; $('#viewer').hidden = !on; V.dirty = true; }
function ask(title, msg, opts = {}) {
  return new Promise(res => {
    $('#mt').textContent = title; $('#mm').textContent = msg;
    const inp = $('#mi'); inp.hidden = !opts.input; inp.value = opts.value || ''; inp.placeholder = opts.placeholder || '';
    const box = $('#mb'); box.innerHTML = '';
    (opts.buttons || ['确定']).forEach((t, i) => {
      const b = document.createElement('button'); b.textContent = t; if (i === 0) b.className = 'primary';
      b.onclick = () => { $('#modal').hidden = true; res({ i, v: inp.value.trim() }); };
      box.appendChild(b);
    });
    $('#modal').hidden = false; if (opts.input) inp.focus();
  });
}

/* ───────────────────────── 设备发现 + 服务端 ───────────────────────── */
const peers = new Map();
let cur = null;            // 当前会话：{ stop(reason) }
let reserved = false;      // 正在连接/等待用户确认
const isBusy = () => !!cur || reserved;

function broadcastAddrs() {
  const set = new Set(['255.255.255.255']), ifs = os.networkInterfaces();
  for (const k in ifs) for (const a of ifs[k]) {
    if (!(a.family === 'IPv4' || a.family === 4) || a.internal) continue;
    const ip = a.address.split('.').map(Number), m = a.netmask.split('.').map(Number);
    set.add(ip.map((x, i) => (x & m[i]) | (~m[i] & 255)).join('.'));
  }
  return [...set];
}
const usock = dgram.createSocket({ type: 'udp4', reuseAddr: true });
usock.on('error', e => console.warn('udp', e.message));
usock.on('message', (msg, rinfo) => {
  try {
    const j = JSON.parse(msg.toString());
    if (j.a !== 'lancast' || j.id === myId) return;
    peers.set(j.id, { id: j.id, name: j.n, platform: j.p, ip: rinfo.address, port: j.port || PORT, seen: Date.now() });
  } catch {}
});
usock.bind(DISC_PORT, () => { try { usock.setBroadcast(true); } catch {} });
setInterval(() => {
  const msg = Buffer.from(JSON.stringify({ a: 'lancast', id: myId, n: myName, p: 'windows', port: PORT }));
  for (const ip of broadcastAddrs()) usock.send(msg, DISC_PORT, ip, () => {});
}, 1500);

const server = net.createServer(onIncoming);
server.on('error', e => setStatus('监听 ' + PORT + ' 端口失败: ' + e.message + '（是否已开了第二个 LANCast？）', true));
server.listen(PORT, '0.0.0.0');

function acceptSession(s) { s.sendJson(T.ACCEPT, { ok: true }); s.state = 'ready'; s.lastRx = Date.now(); }
function rejectAndClose(s, reason) { s.sendJson(T.REJECT, { reason }); setTimeout(() => s.close(reason), 300); }

function onIncoming(sock) {
  const s = new Session(sock, true);
  s.nonce = crypto.randomBytes(16).toString('hex');
  s.sendJson(T.CHALLENGE, { nonce: s.nonce, name: myName, platform: 'windows' });
  const hs = setTimeout(() => { if (s.state === 'init') s.close('握手超时'); }, 8000);
  s.onPacket = (t, f, pts, pl) => {
    if (t !== T.HELLO || s.state !== 'init') return;
    clearTimeout(hs);
    let j; try { j = JSON.parse(pl.toString('utf8')); } catch { s.close('协议错误'); return; }
    const expect = crypto.createHmac('sha256', myPin).update(s.nonce).digest('hex');
    if (j.auth !== expect) { s.sendJson(T.REJECT, { reason: 'PIN 错误' }); setTimeout(() => s.close('PIN 错误'), 1500); return; }
    s.peerName = j.name || '未知设备'; s.peerPlatform = j.platform || ''; s.mode = j.mode; s.state = 'auth';
    if (isBusy()) { rejectAndClose(s, '对方正忙'); return; }
    ipcRenderer.send('focus');
    if (j.mode === 'push') {                // 对方要把屏幕投到本机
      acceptSession(s); startViewer(s);
    } else if (j.mode === 'pull') {         // 对方要看本机屏幕：先征得本人同意
      reserved = true;
      ask('屏幕共享请求', '「' + s.peerName + '」请求查看本机屏幕，允许吗？', { buttons: ['允许', '拒绝'] }).then(r => {
        reserved = false;
        if (!s.alive) return;
        if (r.i === 0 && !cur) { acceptSession(s); startSource(s); } else rejectAndClose(s, '对方拒绝了请求');
      });
    } else rejectAndClose(s, '未知模式');
  };
}

/* 主动连接对方。mode: 'pull' = 我要看对方屏幕；'push' = 我把屏幕投给对方 */
function connectTo(host, port, pin, mode) {
  return new Promise((resolve, reject) => {
    const sock = net.connect({ host, port });
    const s = new Session(sock, false);
    let done = false;
    const fail = e => { if (done) return; done = true; clearTimeout(to); s.close(e.message); reject(e); };
    const to = setTimeout(() => fail(new Error('连接超时')), mode === 'pull' ? 70000 : 8000);
    sock.on('error', fail);
    s.onClose = r => fail(new Error(r));
    s.onPacket = (t, f, pts, pl) => {
      if (t === T.CHALLENGE) {
        const j = JSON.parse(pl.toString('utf8')); s.peerName = j.name; s.peerPlatform = j.platform;
        s.sendJson(T.HELLO, { ver: 1, name: myName, platform: 'windows', mode,
          auth: crypto.createHmac('sha256', pin).update(j.nonce).digest('hex') });
      } else if (t === T.ACCEPT) {
        done = true; clearTimeout(to); s.state = 'ready'; s.lastRx = Date.now();
        s.onClose = null; s.onPacket = (...a) => s.early.push(a); resolve(s);
      } else if (t === T.REJECT) {
        let r = '被拒绝'; try { r = JSON.parse(pl.toString('utf8')).reason || r; } catch {}
        fail(new Error(r));
      }
    };
  });
}

async function connect(host, port, pin, mode) {
  if (isBusy()) { setStatus('正忙，请先结束当前会话', true); return; }
  reserved = true;
  setStatus(mode === 'pull' ? '连接中，等待对方允许…' : '连接中…');
  try {
    const s = await connectTo(host, port, pin, mode);
    reserved = false;
    if (mode === 'pull') startViewer(s); else startSource(s);
  } catch (e) { reserved = false; setStatus('连接失败：' + e.message, true); }
}

/* ───────────────────────── 发送端：本机屏幕 + 系统声音 → 对方 ───────────────────────── */
window.__capture = async c => { window.__capStream = await navigator.mediaDevices.getDisplayMedia(c); };   // 由主进程以「用户手势」身份调用
async function startSource(s) {
  const q = QUALITY[$('#quality').value] || QUALITY.lossless;
  const maxRes = Number($('#maxres').value) || 0;
  const wantAudio = $('#audioOn').checked;
  const fps = 60;
  let running = true, stream = null, enc = null, encCfg = null, vReader = null, aReader = null;
  let cfgW = 0, cfgH = 0, bitrate = 0, target = 0, forceKey = true, frameNo = 0, lastEnc = 0, lastFrame = null, lastCong = 0;
  let ivRepeat = 0, ivRecover = 0;

  const stop = reason => {
    if (!running) return; running = false;
    clearInterval(ivRepeat); clearInterval(ivRecover);
    try { if (vReader) vReader.cancel().catch(() => {}); } catch {}
    try { if (aReader) aReader.cancel().catch(() => {}); } catch {}
    try { if (stream) stream.getTracks().forEach(t => t.stop()); } catch {}
    try { if (enc && enc.state !== 'closed') enc.close(); } catch {}
    if (lastFrame) { try { lastFrame.close(); } catch {} lastFrame = null; }
    try { if (s.alive) s.sendCtrl({ cmd: 'stop', reason }); } catch {}
    setTimeout(() => s.close(reason), 250);
    ipcRenderer.send('keep-awake', false);
    cur = null; $('#stopBtn').hidden = true; showViewer(false); setStatus('投屏已结束：' + reason);
  };
  cur = { stop };
  s.onClose = r => stop(r);
  $('#stopBtn').hidden = false; setStatus('正在把本机屏幕投给「' + s.peerName + '」…');
  ipcRenderer.send('keep-awake', true);
  s.attach((t, f, pts, pl) => {
    if (t !== T.CTRL) return;
    try { const j = JSON.parse(pl.toString('utf8')); if (j.cmd === 'keyframe') forceKey = true; else if (j.cmd === 'stop') stop('对方结束了投屏'); } catch {}
  });

  try {
    const vc = { frameRate: { ideal: fps, max: fps } };
    if (maxRes) { vc.width = { max: Math.round(maxRes * 16 / 9) }; vc.height = { max: maxRes }; }
    await ipcRenderer.invoke('capture', JSON.stringify({ video: vc, audio: wantAudio }));
    stream = window.__capStream; window.__capStream = null;
    if (!stream) throw new Error('没有拿到屏幕流');
  } catch (e) { stop('无法捕获本机屏幕: ' + e.message); return; }
  if (!running) { stream.getTracks().forEach(t => t.stop()); return; }
  stream.getVideoTracks()[0].onended = () => stop('屏幕捕获已结束');

  async function makeEncoder(w, h) {
    const base = { codec: avcCodec(w, h, fps), width: w, height: h, bitrate, framerate: fps, latencyMode: 'realtime', avc: { format: 'annexb' } };
    for (const bm of ['constant', undefined]) for (const hw of ['prefer-hardware', 'no-preference']) {
      const c = { ...base, hardwareAcceleration: hw }; if (bm) c.bitrateMode = bm;
      try { const r = await VideoEncoder.isConfigSupported(c); if (r.supported) return c; } catch {}
    }
    return null;
  }
  async function ensureEncoder(f) {
    const w = even(f.displayWidth), h = even(f.displayHeight);
    if (enc && enc.state === 'configured' && w === cfgW && h === cfgH) return true;
    if (enc) { try { enc.close(); } catch {} enc = null; }
    cfgW = w; cfgH = h;
    target = Math.round(clamp(w * h * fps * q.bpp, q.min, q.max)); bitrate = target;
    s.maxBacklog = Math.max(300000, bitrate / 8 * 0.15);
    encCfg = await makeEncoder(w, h);
    if (!encCfg) { stop('本机不支持 H.264 编码，请更新显卡驱动'); return false; }
    const e = new VideoEncoder({
      output: chunk => { if (enc === e) s.sendVideo(chunk); },
      error: err => { console.warn('encoder error', err); if (enc === e) { enc = null; forceKey = true; } }
    });
    e.configure(encCfg); enc = e; frameNo = 0; forceKey = true;
    s.sendJson(T.VCONFIG, { codec: 'h264', width: w, height: h, fps });
    return true;
  }
  function encodeFrame(f) {
    if (!enc || enc.state !== 'configured') return;
    if (enc.encodeQueueSize > 3) return;                 // 编码器来不及：丢输入帧（不影响参考链）
    const key = forceKey || frameNo % (fps * 2) === 0;   // 至少每 2 秒一个关键帧
    forceKey = false; frameNo++; lastEnc = performance.now();
    try { enc.encode(f, key ? { keyFrame: true } : undefined); } catch { forceKey = true; }
  }
  function reconfig() {
    if (!enc || enc.state !== 'configured') return;
    try { encCfg.bitrate = bitrate; enc.configure(encCfg); forceKey = true; } catch {}
  }
  s.onCongestion = () => {                               // 网络拥塞：降码率 25%，并请求新的关键帧
    const now = performance.now(); if (now - lastCong < 800) return; lastCong = now;
    bitrate = Math.max(q.min, Math.round(bitrate * 0.75)); s.maxBacklog = Math.max(300000, bitrate / 8 * 0.15);
    reconfig(); forceKey = true;
  };
  ivRecover = setInterval(() => {                        // 网络恢复：每 3 秒回升 12%
    if (performance.now() - lastCong < 4000 || bitrate >= target) return;
    bitrate = Math.min(target, Math.round(bitrate * 1.12)); s.maxBacklog = Math.max(300000, bitrate / 8 * 0.15); reconfig();
  }, 3000);
  ivRepeat = setInterval(() => {                         // 画面静止时每 ≥200ms 重发一帧，保证对方随时能拿到关键帧（防黑屏）
    if (!running || !lastFrame || !enc || enc.state !== 'configured' || performance.now() - lastEnc < 200) return;
    let c = null;
    try { c = new VideoFrame(lastFrame, { timestamp: Math.round(performance.now() * 1000) }); encodeFrame(c); } catch {} finally { if (c) c.close(); }
  }, 100);

  vReader = new MediaStreamTrackProcessor({ track: stream.getVideoTracks()[0] }).readable.getReader();
  (async () => {
    try {
      for (;;) {
        const { value: f, done } = await vReader.read();
        if (done || !running) { if (f) f.close(); break; }
        const ok = (enc && enc.state === 'configured' && even(f.displayWidth) === cfgW && even(f.displayHeight) === cfgH) || await ensureEncoder(f);
        if (!running) { f.close(); break; }
        if (ok) encodeFrame(f);
        if (lastFrame) lastFrame.close();
        lastFrame = f;
      }
    } catch (e) { if (running) stop('捕获中断: ' + e.message); }
  })();

  const at = stream.getAudioTracks()[0];
  if (at) {
    aReader = new MediaStreamTrackProcessor({ track: at }).readable.getReader();
    (async () => {
      let sent = null;
      try {
        for (;;) {
          const { value: ad, done } = await aReader.read();
          if (done || !running) { if (ad) ad.close(); break; }
          const ch = Math.min(ad.numberOfChannels, 2), n = ad.numberOfFrames, rate = ad.sampleRate;
          if (!sent || sent.rate !== rate || sent.ch !== ch) { sent = { rate, ch }; s.sendJson(T.ACONFIG, { rate, ch, fmt: 'f32' }); }
          const buf = Buffer.alloc(16 + n * ch * 4);
          s._hdr(buf, T.ADATA, 0, ad.timestamp, n * ch * 4);
          const f32 = new Float32Array(buf.buffer, buf.byteOffset + 16, n * ch);
          const tmp = new Float32Array(n);
          for (let p = 0; p < ch; p++) {
            ad.copyTo(tmp, { planeIndex: p, format: 'f32-planar' });
            for (let i = 0, k = p; i < n; i++, k += ch) f32[k] = tmp[i];
          }
          ad.close();
          s.sendAudio(buf);
        }
      } catch (e) { /* 音频出问题不影响画面 */ }
    })();
  }
}

/* ───────────────────────── 接收端：对方屏幕 → 本机窗口 ───────────────────────── */
const AUDIO_WORKLET = `
class PCM extends AudioWorkletProcessor {
  constructor() {
    super(); this.q = []; this.n = 0; this.off = 0; this.on = false; this.pre = 1920; this.max = 7680; this.trim = 3840;
    this.port.onmessage = e => {
      const d = e.data;
      if (d.cfg) { this.pre = d.cfg.pre; this.max = d.cfg.max; this.trim = d.cfg.trim; return; }
      this.q.push(d); this.n += d.l.length;
      if (this.n > this.max) {              // 积压过多（>160ms）：丢掉最旧的，把延迟拉回来
        while (this.n > this.trim && this.q.length > 1) { const x = this.q.shift(); this.n -= x.l.length - this.off; this.off = 0; }
      }
    };
  }
  process(inputs, outputs) {
    const o = outputs[0], L = o[0], R = o[1] || o[0], len = L.length;
    if (!this.on) { if (this.n >= this.pre) this.on = true; else return true; }
    let i = 0;
    while (i < len && this.q.length) {
      const c = this.q[0], take = Math.min(c.l.length - this.off, len - i);
      L.set(c.l.subarray(this.off, this.off + take), i);
      if (R !== L) R.set(c.r.subarray(this.off, this.off + take), i);
      i += take; this.off += take; this.n -= take;
      if (this.off >= c.l.length) { this.q.shift(); this.off = 0; }
    }
    if (i < len) { this.on = false; this.pre = Math.min(this.pre + 480, this.max >> 1); }   // 欠载：重新缓冲，并略增预缓冲
    return true;
  }
}
registerProcessor('pcm', PCM);`;

class AudioOut {
  constructor(cfg) {
    this.cfg = cfg; this.node = null; this.pendingMsgs = [];
    this.ctx = new AudioContext({ sampleRate: cfg.rate, latencyHint: 'interactive' });
    const url = URL.createObjectURL(new Blob([AUDIO_WORKLET], { type: 'application/javascript' }));
    this.ctx.audioWorklet.addModule(url).then(() => {
      URL.revokeObjectURL(url);
      this.node = new AudioWorkletNode(this.ctx, 'pcm', { outputChannelCount: [2] });
      const r = cfg.rate;
      this.node.port.postMessage({ cfg: { pre: Math.round(r * 0.04), max: Math.round(r * 0.16), trim: Math.round(r * 0.08) } });
      this.node.connect(this.ctx.destination);
      for (const m of this.pendingMsgs) this._post(m);
      this.pendingMsgs = []; this.ctx.resume();
    }).catch(e => console.warn('audio worklet', e));
  }
  _post(m) { this.node.port.postMessage(m, m.r === m.l ? [m.l.buffer] : [m.l.buffer, m.r.buffer]); }
  push(pl) {
    const ch = this.cfg.ch, ab = pl.buffer.slice(pl.byteOffset, pl.byteOffset + pl.length);   // 复制以保证对齐
    let n, l, r;
    if (this.cfg.fmt === 'f32') {
      const f = new Float32Array(ab); n = (f.length / ch) | 0;
      l = new Float32Array(n); r = ch > 1 ? new Float32Array(n) : l;
      for (let i = 0, k = 0; i < n; i++, k += ch) { l[i] = f[k]; if (ch > 1) r[i] = f[k + 1]; }
    } else {
      const f = new Int16Array(ab); n = (f.length / ch) | 0;
      l = new Float32Array(n); r = ch > 1 ? new Float32Array(n) : l;
      for (let i = 0, k = 0; i < n; i++, k += ch) { l[i] = f[k] / 32768; if (ch > 1) r[i] = f[k + 1] / 32768; }
    }
    const m = { l, r };
    if (this.node) this._post(m); else if (this.pendingMsgs.length < 100) this.pendingMsgs.push(m);
  }
  close() { try { this.ctx.close(); } catch {} }
}

/* 画面铺满策略（参考 YouTube）：
 *  - 完整显示(fit)：整幅画面可见，多余部分用画面自身的模糊色填充（不是死黑边）
 *  - 铺满裁剪(fill)：放大到填满窗口，裁掉超出的边缘，可拖动平移、滚轮缩放
 *  - 自动：被裁掉的面积 ≤ 阈值才铺满（例如 16:9 → 20:9 约裁 20%），否则完整显示（例如竖屏手机 → 横屏电脑）
 */
const V = { mode: 0, rel: 1, px: 0, py: 0, dirty: true, thr: Number(LS.get('thr', 22)) / 100 };   // mode: 0 自动 1 完整 2 铺满 3 手动
let lastL = null;
function layout(w, h, W, H) {
  const fit = Math.min(W / w, H / h), fill = Math.max(W / w, H / h), ratio = fill / fit;
  const rel = V.mode === 1 ? 1 : V.mode === 2 ? ratio : V.mode === 3 ? V.rel : ((1 - 1 / ratio) <= V.thr ? ratio : 1);
  const dw = w * fit * rel, dh = h * fit * rel;
  const mx = Math.max(0, (dw - W) / 2), my = Math.max(0, (dh - H) / 2);
  V.px = clamp(V.px, -mx, mx); V.py = clamp(V.py, -my, my);
  return (lastL = { dw, dh, dx: (W - dw) / 2 + V.px, dy: (H - dh) / 2 + V.py, rel, ratio });
}
const cv = $('#cv'), cctx = cv.getContext('2d', { alpha: false });
const amb = document.createElement('canvas'), actx = amb.getContext('2d'); let ambT = 0;
function paintAmbient(frame, W, H) {            // 用 48px 小图拉伸出柔和的环境色背景，成本极低
  const now = performance.now();
  if (now - ambT > 300) {
    ambT = now; amb.width = 48; amb.height = Math.max(2, Math.round(48 * H / W));
    const w = frame.displayWidth, h = frame.displayHeight, k = Math.max(amb.width / w, amb.height / h);
    actx.drawImage(frame, (amb.width - w * k) / 2, (amb.height - h * k) / 2, w * k, h * k);
  }
  cctx.imageSmoothingEnabled = true;
  cctx.drawImage(amb, 0, 0, W, H);
  cctx.fillStyle = 'rgba(0,0,0,.55)'; cctx.fillRect(0, 0, W, H);
}
function draw(frame) {
  const dpr = window.devicePixelRatio || 1, W = cv.clientWidth, H = cv.clientHeight;
  if (cv.width !== Math.round(W * dpr) || cv.height !== Math.round(H * dpr)) { cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr); }
  cctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  const L = layout(frame.displayWidth, frame.displayHeight, W, H);
  if (L.dw < W - 1 || L.dh < H - 1) paintAmbient(frame, W, H);
  cctx.imageSmoothingEnabled = true; cctx.imageSmoothingQuality = 'high';
  cctx.drawImage(frame, L.dx, L.dy, L.dw, L.dh);
}

class Viewer {
  constructor(s) {
    this.s = s; this.dec = null; this.gen = 0; this.cfg = null; this.waitKey = true; this.stopped = false;
    this.cur = null; this.pending = null; this.dirty = true; this.frames = 0; this.bytes = 0; this.lastStat = performance.now(); this.audio = null;
    this.raf = requestAnimationFrame(() => this.tick());
    this.statTimer = setInterval(() => this.updateStats(), 1000);
  }
  onPacket(t, f, pts, pl) {
    switch (t) {
      case T.VCONFIG: this.cfg = JSON.parse(pl.toString('utf8')); V.px = V.py = 0; this.initDecoder(); break;
      case T.VFRAME: this.bytes += pl.length; this.feed(f & 1, pts, pl); break;
      case T.ACONFIG: if (this.audio) this.audio.close(); this.audio = new AudioOut(JSON.parse(pl.toString('utf8'))); break;
      case T.ADATA: if (this.audio) this.audio.push(pl); break;
      case T.CTRL: { const j = JSON.parse(pl.toString('utf8')); if (j.cmd === 'stop') this.stop(j.reason || '对方结束了投屏'); break; }
    }
  }
  needKey() { this.waitKey = true; this.s.sendCtrl({ cmd: 'keyframe' }); }
  closeDecoder() { const d = this.dec; this.dec = null; try { if (d && d.state !== 'closed') d.close(); } catch {} }
  async initDecoder() {
    this.closeDecoder();
    const c = this.cfg, gen = ++this.gen;
    for (const hw of ['prefer-hardware', 'no-preference']) {
      const conf = { codec: avcCodec(c.width, c.height, c.fps || 60), codedWidth: c.width, codedHeight: c.height, optimizeForLatency: true, hardwareAcceleration: hw };
      try {
        const r = await VideoDecoder.isConfigSupported(conf);
        if (gen !== this.gen || this.stopped) return;
        if (!r.supported) continue;
        const d = new VideoDecoder({
          output: fr => this.onFrame(fr),
          error: e => { console.warn('decoder error', e); if (this.dec === d) { this.dec = null; setTimeout(() => { if (!this.stopped) this.initDecoder(); }, 50); } }
        });
        d.configure(conf); this.dec = d; this.needKey(); return;
      } catch (e) { /* 试下一种 */ }
    }
    this.stop('本机无法解码 H.264');
  }
  feed(key, pts, data) {
    const d = this.dec; if (!d || d.state !== 'configured') return;
    if (this.waitKey && !key) return;                                  // 未拿到关键帧前不送解码器 → 不会花屏
    if (d.decodeQueueSize > 4 && !key) { this.needKey(); return; }     // 解码跟不上：丢到下一个关键帧
    if (key) this.waitKey = false;
    try { d.decode(new EncodedVideoChunk({ type: key ? 'key' : 'delta', timestamp: pts, data })); } catch { this.needKey(); }
  }
  onFrame(f) { this.frames++; if (this.pending) this.pending.close(); this.pending = f; }
  tick() {
    if (this.stopped) return;
    this.raf = requestAnimationFrame(() => this.tick());
    if (this.pending) { if (this.cur) this.cur.close(); this.cur = this.pending; this.pending = null; this.dirty = true; }
    if (this.cur && (this.dirty || V.dirty)) { this.dirty = false; V.dirty = false; draw(this.cur); }
  }
  updateStats() {
    const now = performance.now(), dt = (now - this.lastStat) / 1000; this.lastStat = now;
    const fps = this.frames / dt, mbps = this.bytes * 8 / dt / 1e6; this.frames = 0; this.bytes = 0;
    const el = $('#stats');
    if (!el.hidden) el.textContent = fps.toFixed(0) + ' fps   ' + mbps.toFixed(1) + ' Mbps   往返 ' + Math.round(this.s.rtt) + ' ms   ' + (this.cfg ? this.cfg.width + '×' + this.cfg.height : '');
  }
  stop(reason) {
    if (this.stopped) return; this.stopped = true;
    cancelAnimationFrame(this.raf); clearInterval(this.statTimer);
    this.closeDecoder();
    if (this.cur) { this.cur.close(); this.cur = null; } if (this.pending) { this.pending.close(); this.pending = null; }
    if (this.audio) this.audio.close();
    try { if (this.s.alive) this.s.sendCtrl({ cmd: 'stop' }); } catch {}
    setTimeout(() => this.s.close(reason), 250);
    if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
    ipcRenderer.send('keep-awake', false);
    cur = null; $('#stopBtn').hidden = true; showViewer(false); setStatus('已断开：' + reason);
  }
}
function startViewer(s) {
  const v = new Viewer(s);
  cur = { stop: r => v.stop(r) };
  s.onClose = r => v.stop(r);
  V.px = V.py = 0; V.mode = 0; V.dirty = true;
  ipcRenderer.send('keep-awake', true);
  showViewer(true); syncBar(); $('#stopBtn').hidden = false; setStatus('正在查看「' + s.peerName + '」的屏幕');
  s.attach((t, f, pts, pl) => v.onPacket(t, f, pts, pl));
}

/* ───────────────────────── 查看窗口的交互 ───────────────────────── */
function syncBar() {
  document.querySelectorAll('#bar [data-act]').forEach(b => {
    const a = b.dataset.act;
    b.classList.toggle('on', (a === 'auto' && V.mode === 0) || (a === 'fit' && V.mode === 1) || (a === 'fill' && V.mode === 2) ||
      (a === 'stats' && !$('#stats').hidden) || (a === 'full' && !!document.fullscreenElement));
  });
}
function viewAct(a) {
  if (a === 'auto') V.mode = 0; else if (a === 'fit') V.mode = 1; else if (a === 'fill') V.mode = 2;
  else if (a === 'full') { if (document.fullscreenElement) document.exitFullscreen(); else document.documentElement.requestFullscreen().catch(() => {}); }
  else if (a === 'stats') $('#stats').hidden = !$('#stats').hidden;
  else if (a === 'quit') { if (cur) cur.stop('已断开'); return; }
  if (a === 'auto' || a === 'fit' || a === 'fill') V.px = V.py = 0;
  V.dirty = true; syncBar();
}
document.querySelectorAll('#bar [data-act]').forEach(b => b.onclick = () => viewAct(b.dataset.act));
window.addEventListener('keydown', e => {
  if ($('#viewer').hidden || e.target.tagName === 'INPUT') return;
  const k = e.key.toLowerCase();
  if (k === '1') viewAct('auto'); else if (k === '2') viewAct('fit'); else if (k === '3') viewAct('fill');
  else if (k === 'f') viewAct('full'); else if (k === 'i') viewAct('stats'); else if (k === 'q') viewAct('quit');
});
window.addEventListener('resize', () => { V.dirty = true; });
document.addEventListener('fullscreenchange', () => { V.dirty = true; syncBar(); });
let snapT = 0;
function snap() {                                // 缩放结束后吸附：接近完整显示/铺满时自动对齐，和 YouTube 捏合缩放一致
  if (!lastL) return;
  if (V.rel < 1.05) { V.mode = 1; V.px = V.py = 0; }
  else if (Math.abs(V.rel - lastL.ratio) / lastL.ratio < 0.05) { V.mode = 2; }
  V.dirty = true; syncBar();
}
cv.addEventListener('wheel', e => {
  e.preventDefault(); if (!lastL) return;
  V.rel = clamp(lastL.rel * Math.exp(-e.deltaY * 0.0015), 1, lastL.ratio * 4); V.mode = 3; V.dirty = true; syncBar();
  clearTimeout(snapT); snapT = setTimeout(snap, 180);
}, { passive: false });
let drag = null;
cv.addEventListener('mousedown', e => { drag = { x: e.clientX, y: e.clientY }; });
window.addEventListener('mouseup', () => { drag = null; });
window.addEventListener('mousemove', e => {
  const vw = $('#viewer'); vw.classList.remove('idle'); clearTimeout(vw._t); vw._t = setTimeout(() => vw.classList.add('idle'), 2500);
  if (!drag) return;
  V.px += e.clientX - drag.x; V.py += e.clientY - drag.y; drag = { x: e.clientX, y: e.clientY }; V.dirty = true;
});
cv.addEventListener('dblclick', () => { if (!lastL) return; V.mode = lastL.rel > 1.01 ? 1 : 2; V.px = V.py = 0; V.dirty = true; syncBar(); });

/* ───────────────────────── 主页 ───────────────────────── */
function renderPeers() {
  const now = Date.now(); for (const [k, p] of peers) if (now - p.seen > 6000) peers.delete(k);
  const box = $('#peers'); box.innerHTML = '';
  if (!peers.size) { box.innerHTML = '<div class="empty">还没有发现设备。请在手机上打开 LANCast，并连接同一个 Wi-Fi。</div>'; return; }
  for (const p of peers.values()) {
    const d = document.createElement('div'); d.className = 'peer';
    d.innerHTML = '<div class="nm"><b></b><span class="muted"></span></div>';
    d.querySelector('b').textContent = p.name;
    d.querySelector('span').textContent = (p.platform === 'android' ? '安卓 ' : p.platform === 'windows' ? 'Windows ' : '') + p.ip;
    const b = document.createElement('button'); b.textContent = '连接…'; b.className = 'primary'; b.onclick = () => peerAction(p.ip, p.port, p.id, p.name);
    d.appendChild(b); box.appendChild(d);
  }
}
async function peerAction(ip, port, key, name) {
  const r = await ask(name, ip + ' · 请输入对方屏幕上显示的 6 位 PIN', {
    input: true, value: LS.get('pin_' + key, ''), placeholder: 'PIN', buttons: ['查看对方屏幕', '投出我的屏幕', '取消'] });
  if (r.i === 2 || !r.v) return;
  LS.set('pin_' + key, r.v);
  connect(ip, port, r.v, r.i === 0 ? 'pull' : 'push');
}
function init() {
  $('#pin').textContent = myPin;
  $('#me').textContent = myName + '  ' + (localIPs().join(' / ') || '未连接网络');
  $('#resetPin').onclick = () => { myPin = newPin(); $('#pin').textContent = myPin; };
  for (const [id, key, def] of [['#quality', 'quality', 'lossless'], ['#maxres', 'maxres', '0']]) {
    const el = $(id); el.value = LS.get(key, def); el.onchange = () => LS.set(key, el.value);
  }
  const thr = $('#thr'); thr.value = Math.round(V.thr * 100); $('#thrv').textContent = thr.value + '%';
  thr.oninput = () => { V.thr = thr.value / 100; $('#thrv').textContent = thr.value + '%'; LS.set('thr', thr.value); };
  const au = $('#audioOn'); au.checked = LS.get('audio', '1') === '1'; au.onchange = () => LS.set('audio', au.checked ? '1' : '0');
  $('#manual').onclick = () => { const ip = $('#ip').value.trim(); if (ip) peerAction(ip, PORT, 'ip_' + ip, ip); };
  $('#stopBtn').onclick = () => { if (cur) cur.stop('已手动结束'); };
  setInterval(renderPeers, 1500); renderPeers();
}
window.addEventListener('beforeunload', () => { if (cur) cur.stop('窗口已关闭'); });
init();
