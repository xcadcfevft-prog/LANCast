'use strict';
/* 瞬流「五子棋对战」（Windows 端）：邀请 / 接受 / 拒绝 / 结束的会话状态机（纯逻辑，可在 Node 里测试）。
 * 安卓端对应 android/.../GomokuGame.kt；规范见 docs/PROTOCOL.md 第 19 节。
 *
 * 信令和对局消息都走已有的加密聊天连接（hub.sendGame → {t:"gm", ...}），不开新端口、不做新握手：
 *   invite  邀请方 → 对方：{op:"invite", gid, side, turn}  side = 邀请方执哪色（1 黑 2 白，随机），turn = 第一局谁先手
 *   accept  对方同意 → 双方各自打开独立的棋盘窗口（邀请方 = host，棋盘以它为准）
 *   reject / busy / end
 *   g       对局内消息 {op:"g", gid, d:{k:...}}，原样交给棋盘窗口（棋盘页面自己负责规则、同步和校验，见 gomoku.html）
 * 本模块不碰 DOM / Electron：窗口由外面注入的 open / close / deliver / link / gone 回调去开关。 */
const RING_TIMEOUT_MS = 40000;
const newGid = () => require('crypto').randomBytes(8).toString('hex');

function createGame(o) {
  const { hub, myId, peerName = () => '对方', open = () => {}, close = () => {}, deliver = () => {}, onState = () => {},
    now = () => Date.now(), setT = setTimeout, clearT = clearTimeout, rnd = Math.random } = o;
  const st = { phase: 'idle', peerId: null, gid: '', side: 1, turn: 1, host: false, since: 0, reason: '', up: true };
  let timer = 0, sent = false;
  const emit = () => { try { onState(st); } catch {} };
  const sig = (id, obj) => { try { return hub.sendGame(id, obj); } catch { return false; } };
  function reset(reason, closeWin) {
    clearT(timer); timer = 0; sent = false;
    const was = st.phase;
    st.phase = 'idle'; st.peerId = null; st.gid = ''; st.reason = reason || '';
    if (closeWin && was === 'playing') { try { close(); } catch {} }
    emit();
  }
  function begin(side, host) {                                // 双方同意：打开棋盘窗口
    clearT(timer); timer = 0;
    st.phase = 'playing'; st.since = now(); st.reason = ''; st.up = true; st.side = side; st.host = host;
    try { open({ peerId: st.peerId, gid: st.gid, side, turn: st.turn, host, peerName: peerName(st.peerId) }); } catch {}
    emit();
  }
  const game = {
    state: st,
    /* 我发起邀请。信令发不出去（加密连接还没建好）就每秒重试，直到超时 */
    invite(peerId) {
      if (st.phase !== 'idle') return false;
      st.phase = 'inviting'; st.peerId = peerId; st.gid = newGid(); st.since = now(); st.reason = '';
      st.side = rnd() < 0.5 ? 1 : 2; st.turn = rnd() < 0.5 ? 1 : 2; st.host = true;
      const t0 = now(), gid = st.gid;
      const tryInvite = () => {
        if (st.phase !== 'inviting' || st.gid !== gid) return;
        if (now() - t0 > RING_TIMEOUT_MS) { sig(peerId, { op: 'end', gid }); reset('对方没有回应邀请'); return; }
        if (!sent && sig(peerId, { op: 'invite', gid, side: st.side, turn: st.turn })) sent = true;
        timer = setT(tryInvite, 1000);
      };
      sent = false; emit(); tryInvite();
      return true;
    },
    cancelInvite() { if (st.phase === 'inviting') { sig(st.peerId, { op: 'end', gid: st.gid }); reset('已取消邀请'); } },
    accept() {
      if (st.phase !== 'invited') return;
      sig(st.peerId, { op: 'accept', gid: st.gid });
      begin(st.side === 1 ? 2 : 1, false);                    // st.side 是邀请方的颜色，我执另一色
    },
    decline() { if (st.phase !== 'invited') return; sig(st.peerId, { op: 'reject', gid: st.gid }); reset('已拒绝'); },
    /* 我这边关掉了棋盘窗口 / 主动离开 */
    leave() {
      if (st.phase === 'playing') { sig(st.peerId, { op: 'end', gid: st.gid }); reset('你已离开对局', false); }
    },
    onSignal(peerId, m) {
      if (m.op === 'invite') {
        if (st.phase === 'idle') {
          clearT(timer);
          st.phase = 'invited'; st.peerId = peerId; st.gid = m.gid; st.side = m.side; st.turn = m.turn; st.host = false; st.since = now(); st.reason = '';
          timer = setT(() => { if (st.phase === 'invited' && st.gid === m.gid) { sig(peerId, { op: 'end', gid: m.gid }); reset('邀请已过期'); } }, RING_TIMEOUT_MS);
          emit();
        } else if (st.phase === 'inviting' && st.peerId === peerId) {
          // 同时互相邀请：设备 ID 较小的一方的邀请有效，另一方改为接受它
          if (peerId < myId) {
            sig(peerId, { op: 'end', gid: st.gid });
            clearT(timer);
            st.phase = 'invited'; st.gid = m.gid; st.side = m.side; st.turn = m.turn; st.host = false; st.since = now();
            timer = setT(() => { if (st.phase === 'invited' && st.gid === m.gid) { sig(peerId, { op: 'end', gid: m.gid }); reset('邀请已过期'); } }, RING_TIMEOUT_MS);
            emit();
          }
        } else if (st.phase === 'playing' && st.peerId === peerId && st.gid === m.gid) {
          sig(peerId, { op: 'accept', gid: m.gid });          // 重复邀请：重发接受
        } else sig(peerId, { op: 'busy', gid: m.gid });
        return;
      }
      if (st.peerId !== peerId || st.gid !== m.gid) return;
      if (m.op === 'accept') { if (st.phase === 'inviting') begin(st.side, true); }
      else if (m.op === 'reject') { if (st.phase === 'inviting') reset('对方拒绝了「智斗五子棋·文房雅趣」邀请'); }
      else if (m.op === 'busy') { if (st.phase === 'inviting') reset('对方正忙（已有邀请或对局）'); }
      else if (m.op === 'end') {
        if (st.phase === 'inviting') reset('对方没有接受邀请');
        else if (st.phase === 'invited') reset('对方取消了邀请');
        else if (st.phase === 'playing') { try { deliver({ k: '_gone' }); } catch {} st.reason = '对方已离开对局'; st.phase = 'ended'; emit(); }
      }
      else if (m.op === 'g') { if (st.phase === 'playing') { try { deliver(m.d); } catch {} } }
    },
    /* 棋盘窗口发来的消息 → 对方 */
    fromWindow(d) {
      if (st.phase !== 'playing' || !d || typeof d.k !== 'string') return false;
      return sig(st.peerId, { op: 'g', gid: st.gid, d });
    },
    /* 窗口被关了之后，状态 ended → idle */
    windowClosed() { if (st.phase === 'playing') game.leave(); else if (st.phase === 'ended') reset(''); },
    /* 每秒一次：对局中把加密连接的通断告诉棋盘窗口（重连后棋盘会立刻校验状态） */
    tick() {
      if (st.phase !== 'playing') return;
      const up = !!hub.isConnected(st.peerId);
      if (up !== st.up) { st.up = up; try { deliver({ k: '_link', up }); } catch {} }
      if (!up) hub.ensure && hub.ensure(st.peerId);
    },
    peerGone(peerId) { if (st.peerId === peerId && st.phase !== 'idle') reset('已取消配对', true); }
  };
  return game;
}

module.exports = { createGame, RING_TIMEOUT_MS };
