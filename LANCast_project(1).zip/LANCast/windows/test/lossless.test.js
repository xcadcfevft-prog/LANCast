'use strict';
// node windows/test/lossless.test.js —— 「极致无损」编解码：任意画面经过 编码→解码 后逐像素完全一致
const assert = require('assert');
const L = require('../lossless');

let pass = 0, failed = false;
const ok = async (name, fn) => { try { await fn(); pass++; console.log('PASS ' + name); } catch (e) { failed = true; console.log('FAIL ' + name + '\n     ' + String(e.stack).split('\n').slice(0, 4).join('\n     ')); } };

let seed = 12345; const rnd = () => (seed = (seed * 1103515245 + 12345) >>> 0);
function frame(w, h, kind) {
  const a = new Uint32Array(w * h);
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    let r, g, b;
    if (kind === 'noise') { const v = rnd(); r = v & 255; g = (v >> 8) & 255; b = (v >> 16) & 255; }
    else if (kind === 'ui') { r = g = b = (x >> 5 ^ y >> 5) & 1 ? 240 : 20; }
    else { r = x & 255; g = y & 255; b = (x + y) & 255; }
    a[y * w + x] = (255 << 24 | b << 16 | g << 8 | r) >>> 0;
  }
  return a;
}
const same = (a, b) => { for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return false; return true; };

(async () => {
  for (const [w, h] of [[64, 64], [200, 130], [1080, 600], [7, 5]]) for (const kind of ['noise', 'ui', 'grad']) {
    await ok(`整幅 ${w}x${h} ${kind} 逐像素一致`, async () => {
      const f = frame(w, h, kind), d = new L.Decoder(w, h);
      const p = await L.encode(f, null, w, h, true);
      await d.apply(p, true);
      assert(same(d.px, f));
    });
  }
  await ok('差异帧：只改一小块，只发一小块，结果一致', async () => {
    const w = 500, h = 300, a = frame(w, h, 'grad'), d = new L.Decoder(w, h);
    await d.apply(await L.encode(a, null, w, h, true), true);
    const b = Uint32Array.from(a); for (let y = 100; y < 110; y++) for (let x = 300; x < 310; x++) b[y * w + x] = 0xFF123456;
    const p = await L.encode(b, a, w, h, false);
    assert(p.length < 30000, 'delta payload ' + p.length);   // 整幅约 450KB，只改一块时只发相关的块
    const r = await d.apply(p, false);
    assert(same(d.px, b)); assert(r.y0 <= 100 && r.y1 >= 110 && r.y1 - r.y0 <= 64);
  });
  await ok('画面没变化：返回 null（不发包）', async () => {
    const a = frame(130, 70, 'ui'); assert.strictEqual(await L.encode(a, Uint32Array.from(a), 130, 70, false), null);
  });
  await ok('连续 30 帧随机改动，解码端始终与源一致', async () => {
    const w = 333, h = 211; let cur = frame(w, h, 'ui'); const d = new L.Decoder(w, h);
    await d.apply(await L.encode(cur, null, w, h, true), true);
    for (let n = 0; n < 30; n++) {
      const nx = Uint32Array.from(cur);
      for (let k = 0; k < 200; k++) nx[rnd() % nx.length] = (0xFF000000 | rnd() & 0xFFFFFF) >>> 0;
      const p = await L.encode(nx, cur, w, h, false); if (p) await d.apply(p, false);
      assert(same(d.px, nx), 'frame ' + n); cur = nx;
    }
  });
  await ok('没收到整幅之前拒收差异帧', async () => {
    const w = 100, h = 100, a = frame(w, h, 'grad'), b = Uint32Array.from(a); b[5] = 0xFF000001;
    const p = await L.encode(b, a, w, h, false);
    await assert.rejects(() => new L.Decoder(w, h).apply(p, false));
  });
  await ok('损坏数据被拒绝而不是写乱画面', async () => {
    const w = 128, h = 128, a = frame(w, h, 'noise'), d = new L.Decoder(w, h);
    const p = await L.encode(a, null, w, h, true);
    const bad = Buffer.from(p); bad.writeUInt16BE(9999, 2);
    await assert.rejects(() => d.apply(bad, true));
    await assert.rejects(() => d.apply(p.subarray(0, p.length - 40), true));
  });
  console.log(failed ? 'FAILED' : 'ALL ' + pass + ' PASSED'); process.exit(failed ? 1 : 0);
})();
