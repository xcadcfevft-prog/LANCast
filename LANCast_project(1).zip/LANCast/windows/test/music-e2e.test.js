'use strict';
// node windows/test/music-e2e.test.js —— 沉浸音乐端到端：真实 TCP + 真实帧格式，多次强行断线，电脑端收到的音频必须与手机采集的逐字节一致（不丢、不重、不错位）
const assert = require('assert');
const net = require('net');
const M = require('../music');

const RATE = 48000, CH = 2, CHUNK = 1920, FB = 4;
const hdr = (type, flags, pts, len) => { const b = Buffer.alloc(16); b[0] = type; b[1] = flags; b.writeUInt32BE(len, 4); b.writeUInt32BE(Math.floor(pts / 4294967296), 8); b.writeUInt32BE(pts >>> 0, 12); return b; };
const frame = (type, flags, pts, body) => Buffer.concat([hdr(type, flags, pts, body.length), body]);
const jframe = (type, o) => frame(type, 0, 0, Buffer.from(JSON.stringify(o)));
class Parser {                                   // 与 Session._onData 相同的拆包
  constructor(cb) { this.buf = Buffer.alloc(0); this.cb = cb; }
  push(d) {
    this.buf = Buffer.concat([this.buf, d]);
    for (;;) {
      if (this.buf.length < 16) return;
      const len = this.buf.readUInt32BE(4); if (this.buf.length < 16 + len) return;
      const t = this.buf[0], f = this.buf[1], pts = this.buf.readUInt32BE(8) * 4294967296 + this.buf.readUInt32BE(12), pl = this.buf.subarray(16, 16 + len);
      this.buf = this.buf.subarray(16 + len); this.cb(t, f, pts, pl);
    }
  }
}

/* 手机端环形缓冲（与 MusicRing.kt 逐项对应） */
class Ring {
  constructor(cap) { this.cap = cap; this.q = []; this.next = 0; }
  oldest() { return this.q.length ? this.q[0].start : this.next; }
  append(data, frames) { this.q.push({ start: this.next, frames, data }); this.next += frames; while (this.q.length > 1 && this.next - this.q[0].start > this.cap) this.q.shift(); }
  trimTo(i) { while (this.q.length && this.q[0].start + this.q[0].frames <= i) this.q.shift(); }
  take(i) {
    for (const c of this.q) { if (c.start + c.frames <= i) continue; if (c.start >= i) return c; const skip = i - c.start; return { start: i, frames: c.frames - skip, data: c.data && c.data.subarray(skip * FB) }; }
    return null;
  }
}

function original(frames) {                        // 手机「采集」到的整条流：有声音 + 一段静音
  const b = Buffer.alloc(frames * FB); let seed = 99;
  for (let i = 0; i < frames; i++) {
    const silent = i >= 20 * CHUNK && i < 40 * CHUNK;
    if (!silent) { seed = (seed * 1103515245 + 12345) >>> 0; b.writeInt16LE(((seed >>> 8) & 0xffff) - 32768, i * FB); seed = (seed * 1103515245 + 12345) >>> 0; b.writeInt16LE(((seed >>> 8) & 0xffff) - 32768, i * FB + 2); }
  }
  return b;
}
function run({ chunks, cap, outageChunks }) {
  return new Promise(resolve => {
    const total = chunks * CHUNK, src = original(total);
    // ───── 电脑端（musicui.js 里的收包逻辑）─────
    const rx = new M.AudioRx(), out = Buffer.alloc(total * FB), seen = []; let cfg = null, sid = null, conns = 0, srvSock = null;
    const server = net.createServer(sock => {
      conns++; if (srvSock) srvSock.destroy(); srvSock = sock;
      const ps = new Parser((t, f, pts, pl) => {
        if (t === M.T.ACONFIG) cfg = M.parseConfig(JSON.parse(pl));
        else if (t === M.T.ADATA) {
          const a = M.parseAudio(f, pts, pl, CH), r = rx.accept(a.idx, a.frames);
          if (r) { if (!a.silent) a.pcm.copy(out, (a.idx + r.off) * FB, r.off * FB, (r.off + r.frames) * FB); }   // 静音 = out 里本来就是 0
        }
      });
      sock.on('data', d => ps.push(d)); sock.on('error', () => {});
      sock.write(jframe(M.T.CTRL, rx.started ? { cmd: 'mack', next: rx.next } : { cmd: 'mack', next: 0, fresh: true }));   // 每条连接的第一个确认
      sock.ack = setInterval(() => { try { sock.write(jframe(M.T.CTRL, { cmd: 'mack', next: rx.next })); } catch {} }, 20);
      sock.on('close', () => clearInterval(sock.ack));
    });
    server.listen(0, '127.0.0.1', () => {
      const port = server.address().port;
      // ───── 手机端（MusicService 的采集线程 + 重连循环 + 发送线程）─────
      const ring = new Ring(cap); let captured = 0, conn = null;
      const connect = () => {
        const s = net.connect(port, '127.0.0.1'); const c = { s, ready: false, sendIdx: 0, cfgSent: false };
        new Promise(r => s.once('connect', r)).then(() => { conn = c; });
        const ps = new Parser((t, f, pts, pl) => {
          if (t !== M.T.CTRL) return; const j = JSON.parse(pl);
          if (j.cmd === 'mack') {
            if (!c.ready) { c.sendIdx = j.fresh ? ring.next : Math.max(j.next, ring.oldest()); c.ready = true; }
            ring.trimTo(j.fresh ? c.sendIdx : j.next);
          }
        });
        s.on('data', d => ps.push(d)); s.on('error', () => {});
        s.on('close', () => { if (conn === c) conn = null; if (captured < total || ring.next > rx.next) setTimeout(connect, 30); });
      };
      connect();
      let dropPlan = [30, 55, 80, 81, 120].map(x => x * 1), outageUntil = 0;
      const timer = setInterval(() => {
        // 采集：不管有没有连接都照常采集（息屏时就是这样）
        if (captured < total) {
          const idx = captured, silent = idx >= 20 * CHUNK && idx < 40 * CHUNK;
          ring.append(silent ? null : Buffer.from(src.subarray(idx * FB, (idx + CHUNK) * FB)), CHUNK); captured += CHUNK;
          const n = captured / CHUNK;
          if (dropPlan.length && n >= dropPlan[0]) { dropPlan.shift(); if (conn) conn.s.destroy(); if (n >= 55 && outageChunks) { outageUntil = Date.now() + outageChunks * 8; } }   // 强行断线
        }
        // 发送：落后就补发，一次发一批
        const c = conn;
        if (c && c.ready && c.s.writable && Date.now() >= outageUntil) {
          if (!c.cfgSent) { c.s.write(jframe(M.T.ACONFIG, { rate: RATE, ch: CH, fmt: 's16', music: 1, sid: 'x' })); c.cfgSent = true; }
          for (let k = 0; k < 6; k++) {
            const ch = ring.take(c.sendIdx); if (!ch) break;
            if (!ch.data) { const b = Buffer.alloc(4); b.writeUInt32BE(ch.frames); c.s.write(frame(M.T.ADATA, 1, ch.start, b)); }
            else c.s.write(frame(M.T.ADATA, 0, ch.start, ch.data));
            c.sendIdx = ch.start + ch.frames;
          }
        } else if (c && Date.now() < outageUntil && c.ready) { /* 模拟网络黑洞：不发也不收，直到超时被判死 */ }
        if (captured >= total && rx.next >= total) {
          clearInterval(timer); setTimeout(() => { if (conn) conn.s.destroy(); if (srvSock) srvSock.destroy(); server.close(); resolve({ out, src, rx, conns, total }); }, 100);
        }
      }, 8);
      setTimeout(() => { clearInterval(timer); resolve({ timeout: true, rx, conns, total }); }, 20000).unref();
    });
  });
}

let pass = 0, failed = false;
const ok = async (name, fn) => { try { await fn(); pass++; console.log('PASS ' + name); } catch (e) { failed = true; console.log('FAIL ' + name + '\n     ' + String(e.stack).split('\n').slice(0, 5).join('\n     ')); } };
(async () => {
  await ok('5 次强行断线 + 自动重连：电脑端收到的整条音频与手机采集的逐字节一致', async () => {
    const r = await run({ chunks: 160, cap: RATE * 30, outageChunks: 0 });
    assert(!r.timeout, '超时：没有收齐');
    assert(r.conns >= 5, '应该发生过多次重连，实际连接数 ' + r.conns);
    assert.strictEqual(r.rx.gapFrames, 0, '不应该丢帧');
    assert(r.out.equals(r.src), '音频内容不一致');
    console.log('     连接 ' + r.conns + ' 次，补发去重 ' + r.rx.dupFrames + ' 帧');
  });
  await ok('断线期间手机继续采集，重连后补发（环形缓冲够大 → 零丢失）', async () => {
    const r = await run({ chunks: 160, cap: RATE * 30, outageChunks: 40 });
    assert(!r.timeout); assert.strictEqual(r.rx.gapFrames, 0); assert(r.out.equals(r.src));
  });
  await ok('缓冲装不下时：丢失被如实记录，其余部分仍然对齐', async () => {
    const r = await run({ chunks: 160, cap: CHUNK * 10, outageChunks: 120 });
    assert(!r.timeout);
    // 丢失的帧在输出里是 0；其余位置必须与原始逐字节一致
    let bad = 0; for (let i = 0; i < r.total; i++) { const a = r.out.readInt32LE(i * 4), b = r.src.readInt32LE(i * 4); if (a !== b && a !== 0) bad++; }
    assert.strictEqual(bad, 0, '有错位的帧');
    console.log('     如实记录丢失 ' + r.rx.gapFrames + ' 帧（' + (r.rx.gapFrames / RATE).toFixed(2) + ' 秒）');
  });
  console.log(failed ? 'FAILED' : 'ALL ' + pass + ' PASSED'); process.exit(failed ? 1 : 0);
})();
