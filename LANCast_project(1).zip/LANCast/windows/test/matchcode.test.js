'use strict';
// node windows/test/matchcode.test.js
// 电脑 ↔ 电脑「匹配码」配对：matchcode.js 的纯逻辑 + 真实 TCP 对跑（帧格式同 docs/PROTOCOL.md 1.1）。
const net = require('net'), crypto = require('crypto'), assert = require('assert');
const MC = require('../matchcode');
const proto = require('../proto');

const H = 16, T = { HELLO: 1, CHALLENGE: 2, ACCEPT: 3, REJECT: 4 };
const pkt = (type, o) => { const b = Buffer.from(JSON.stringify(o)), h = Buffer.alloc(H); h[0] = type; h.writeUInt32BE(b.length, 4); return Buffer.concat([h, b]); };
function reader(sock, cb) { let buf = Buffer.alloc(0); sock.on('data', d => { buf = Buffer.concat([buf, d]); while (buf.length >= H) { const n = buf.readUInt32BE(4); if (buf.length < H + n) break; cb(buf[0], JSON.parse(buf.slice(H, H + n).toString())); buf = buf.slice(H + n); } }); }

let pass = 0, failed = false;
const ok = async (name, fn) => { try { await fn(); pass++; console.log('PASS ' + name); } catch (e) { failed = true; console.log('FAIL ' + name + '\n     ' + String(e.stack).split('\n').slice(0, 4).join('\n     ')); } };

/* 服务端（renderer.js onIncoming + handleCodeHello 的等价流程）。log 记录线上出现的全部包，供「旁听者」测试使用 */
function host(codeHost, myPin, myId, log) {
  return new Promise(res => {
    const srv = net.createServer(sock => {
      const nonce = crypto.randomBytes(16).toString('hex'), eph = MC.serverBegin(codeHost);
      const ch = Object.assign(proto.buildChallenge(nonce, 'PC-A', myId), eph ? { epk: eph.pub } : {});
      log && log.push(['S', T.CHALLENGE, ch]); sock.write(pkt(T.CHALLENGE, ch));
      reader(sock, (t, j) => {
        if (t !== T.HELLO) return;
        log && log.push(['C', t, j]);
        const r = MC.serverVerify(codeHost, eph, j, nonce, myPin, myId);
        if (!r.ok) { log && log.push(['S', T.REJECT, r]); sock.write(pkt(T.REJECT, { reason: r.reason })); setTimeout(() => sock.end(), 20); return; }
        srv.saved = r.peer; log && log.push(['S', T.ACCEPT, r.accept]); sock.write(pkt(T.ACCEPT, r.accept)); setTimeout(() => sock.end(), 20);
      });
    }).listen(0, '127.0.0.1', () => res(srv));
  });
}
/* 客户端（renderer.js connectByCode 的等价流程） */
function client(port, secret, myPin, myId) {
  return new Promise((resolve, reject) => {
    const s = net.connect(port, '127.0.0.1'); let ch, st; s.on('error', reject);
    reader(s, (t, j) => {
      if (t === T.CHALLENGE) { ch = j; const r = MC.clientHello(j, { secret, pin: myPin, name: 'PC-B', id: myId, port: 47800 }); if (r.error) { s.destroy(); return reject(new Error(r.error)); } st = r.st; s.write(pkt(T.HELLO, r.hello)); }
      else if (t === T.REJECT) { s.destroy(); reject(new Error(j.reason)); }
      else if (t === T.ACCEPT) { const r = MC.clientFinish(st, ch, j); s.destroy(); r.ok ? resolve(r.peer) : reject(new Error(r.error)); }
    });
  });
}
const rejects = async (p, re) => { try { await p; } catch (e) { assert.match(e.message, re); return; } assert.fail('应当失败但成功了'); };

(async () => {
  await ok('匹配码：10 位数字，显示成 123-456-7890；解析容忍空格 / 横杠 / 全角数字，位数不对返回 null', () => {
    const c = MC.genCode();
    assert.match(c.code, /^\d{10}$/); assert.strictEqual(c.tag.length, 3); assert.strictEqual(c.secret.length, 7);
    assert.match(MC.formatCode(c.code), /^\d{3}-\d{3}-\d{4}$/);
    assert.deepStrictEqual(MC.parseCode('１２３ 456-7890'), { tag: '123', secret: '4567890' });
    assert.strictEqual(MC.parseCode('123-456-789'), null);
    assert.strictEqual(MC.parseCode('123-456-78901'), null);
    assert.strictEqual(MC.parseCode(''), null);
  });

  await ok('CodeHost：开 / 取消 / 过期（假时钟）', () => {
    let now = 1000; const h = new MC.CodeHost({ now: () => now, ttl: 5000 });
    assert.strictEqual(h.active, false); assert.strictEqual(h.tag, '');
    const code = h.start(); assert.ok(h.active); assert.strictEqual(h.code, code); assert.strictEqual(h.tag, code.slice(0, 3));
    now += 4999; assert.ok(h.active); assert.strictEqual(h.remainingMs, 1);
    now += 1; assert.strictEqual(h.active, false);
    h.start(); h.cancel(); assert.strictEqual(h.active, false);
  });

  await ok('正确匹配码：双方各自拿到对方的长期密钥、ID、名称（互相记住），之后和扫码配对出来的记录一样（ver=2）', async () => {
    const h = new MC.CodeHost(); const code = MC.parseCode(h.start());
    const srv = await host(h, '482913', 'aaaaaaaaaaaaaaaa');
    const peer = await client(srv.address().port, code.secret, '705518', 'bbbbbbbbbbbbbbbb');
    assert.deepStrictEqual({ id: peer.id, pin: peer.pin, ver: peer.ver, name: peer.name }, { id: 'aaaaaaaaaaaaaaaa', pin: '482913', ver: 2, name: 'PC-A' });
    assert.deepStrictEqual({ id: srv.saved.id, pin: srv.saved.pin, ver: srv.saved.ver, name: srv.saved.name, port: srv.saved.port }, { id: 'bbbbbbbbbbbbbbbb', pin: '705518', ver: 2, name: 'PC-B', port: 47800 });
    srv.close();
  });

  await ok('一次性：成功后匹配码作废，再用同一个码（哪怕是对的）连不上', async () => {
    const h = new MC.CodeHost(); const code = MC.parseCode(h.start());
    const srv = await host(h, '111111', 'aaaaaaaaaaaaaaaa');
    await client(srv.address().port, code.secret, '222222', 'bbbbbbbbbbbbbbbb');
    assert.strictEqual(h.active, false);
    await rejects(client(srv.address().port, code.secret, '222222', 'cccccccccccccccc'), /没有开启匹配码/);
    srv.close();
  });

  await ok('口令不对：被拒绝，不会留下配对记录；错 5 次后匹配码作废，之后连对的口令也不行', async () => {
    const h = new MC.CodeHost(); const code = MC.parseCode(h.start());
    const srv = await host(h, '111111', 'aaaaaaaaaaaaaaaa');
    const wrong = String((Number(code.secret) + 1) % 1e7).padStart(7, '0');
    for (let i = 1; i <= 4; i++) { await rejects(client(srv.address().port, wrong, '222222', 'bbbbbbbbbbbbbbbb'), /匹配码不正确/); assert.ok(h.active, '第 ' + i + ' 次错误后不应作废'); }
    await rejects(client(srv.address().port, wrong, '222222', 'bbbbbbbbbbbbbbbb'), /错误次数过多/);
    assert.strictEqual(h.active, false); assert.strictEqual(srv.saved, undefined);
    await rejects(client(srv.address().port, code.secret, '222222', 'bbbbbbbbbbbbbbbb'), /没有开启匹配码/);
    srv.close();
  });

  await ok('匹配码没开 / 已过期：CHALLENGE 不带 epk，客户端直接提示「对方没有开启匹配码」', async () => {
    let now = 0; const h = new MC.CodeHost({ now: () => now, ttl: 1000 }); const code = MC.parseCode(h.start());
    const srv = await host(h, '111111', 'aaaaaaaaaaaaaaaa');
    now = 1000;
    await rejects(client(srv.address().port, code.secret, '222222', 'bbbbbbbbbbbbbbbb'), /没有开启匹配码/);
    srv.close();
  });

  await ok('不知道口令的一方：当服务端验不过客户端的 auth；就算硬发一个假 ACCEPT，客户端也过不了 proof 校验', async () => {
    const real = new MC.CodeHost(); real.start();                                   // 冒充者自己随便开一个别的匹配码
    const fakeHost = new MC.CodeHost(); fakeHost.start();
    const srv = await host(fakeHost, '999999', 'ffffffffffffffff');
    const guess = MC.parseCode(real.code);                                          // 受害者输入的是真设备的码
    await rejects(client(srv.address().port, guess.secret, '222222', 'bbbbbbbbbbbbbbbb'), /匹配码不正确/);   // 冒充者连客户端的 auth 都验不过
    // 就算冒充者无视 auth 硬发一个 ACCEPT：proof 对不上
    const st = MC.clientHello({ nonce: 'a'.repeat(32), epk: MC.newEph().pub, id: 'x'.repeat(16) }, { secret: guess.secret, pin: '222222', name: 'n', id: 'bbbbbbbbbbbbbbbb', port: 1 }).st;
    assert.strictEqual(MC.clientFinish(st, { id: 'ffffffffffffffff' }, { ok: true, proof: '00'.repeat(32), pk: '00' }).ok, false);
    srv.close();
  });

  await ok('旁听者：线上抓到的全部包里没有口令，也没有 HMAC(口令, nonce)；知道了正确口令但没有任一方的临时私钥，也算不出 auth', async () => {
    const h = new MC.CodeHost(); const code = MC.parseCode(h.start()); const log = [];
    const srv = await host(h, '482913', 'aaaaaaaaaaaaaaaa', log);
    await client(srv.address().port, code.secret, '705518', 'bbbbbbbbbbbbbbbb'); srv.close();
    const wire = JSON.stringify(log);
    assert.ok(!wire.includes(code.secret), '口令不应出现在线上');
    assert.ok(!wire.includes('482913') && !wire.includes('705518'), '长期密钥不应明文出现在线上');
    const chal = log.find(x => x[0] === 'S' && x[1] === T.CHALLENGE)[2], hello = log.find(x => x[0] === 'C')[2];
    assert.notStrictEqual(hello.auth, crypto.createHmac('sha256', code.secret).update(chal.nonce).digest('hex'), 'auth 不能是 HMAC(口令, nonce)（否则旁听者可离线穷举）');
    const mine = MC.newEph();                                                       // 旁听者用自己的临时密钥去凑
    const K = MC.deriveK(code.secret, chal.nonce, hello.cn, hello.epk, chal.epk, MC.dh(mine.priv, chal.epk));
    assert.notStrictEqual(MC.sub(K, 'cli').toString('hex'), hello.auth);
  });

  await ok('篡改：epk / cn 非法、pk 被改坏、自己和自己配对，都被拒绝且不留记录', async () => {
    const h = new MC.CodeHost(); const code = MC.parseCode(h.start()); const eph = MC.serverBegin(h);
    const good = MC.clientHello({ nonce: 'n'.repeat(32), epk: eph.pub, id: 'a'.repeat(16) }, { secret: code.secret, pin: '222222', name: 'n', id: 'bbbbbbbbbbbbbbbb', port: 47800 }).hello;
    const v = j => MC.serverVerify(h, eph, j, 'n'.repeat(32), '111111', 'aaaaaaaaaaaaaaaa');
    assert.strictEqual(v({ ...good, epk: 'zz' }).ok, false);
    assert.strictEqual(v({ ...good, cn: 'short' }).ok, false);
    assert.strictEqual(v({ ...good, epk: '00'.repeat(32) }).ok, false);             // 低阶点
    assert.strictEqual(v({ ...good, id: 'aaaaaaaaaaaaaaaa' }).reason, '不能和本机自己配对');
    assert.ok(h.active, '格式非法不应消耗尝试次数 / 作废匹配码');
    assert.strictEqual(v({ ...good, pk: 'ab' }).ok, false);                         // 解出来不是数字 pin
    assert.ok(h.active && h.cur.tries === 0, '只有 auth 校验失败才计入错误次数');
    const r = MC.serverVerify(new MC.CodeHost(), null, good, 'n'.repeat(32), '1', 'a');   // 没开匹配码
    assert.strictEqual(r.ok, false);
  });

  console.log('\n' + (failed ? '有失败' : 'ALL ' + pass + ' PASSED'));
  process.exit(failed ? 1 : 0);
})();
