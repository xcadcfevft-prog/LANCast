'use strict';
// node windows/test/netutil.test.js
// 网络地址工具：网卡分类 / 二维码地址 / 对方地址排序 / 配对链接 / 并行探测 / 防火墙脚本 / 配对密钥交换（与安卓端 Net.kt 的 P.maskPin 对应）
const assert = require('assert'), net = require('net'), crypto = require('crypto');
const NU = require('../netutil'), proto = require('../proto');

let pass = 0, failed = false;
const queue = [];
const ok = (name, fn) => queue.push([name, fn]);
const sleep = ms => new Promise(r => setTimeout(r, ms));
const nic = (address, netmask = '255.255.255.0') => ({ family: 'IPv4', address, netmask, internal: false });

/* ───────── 网卡分类 / 二维码地址 ───────── */
ok('网卡分类：真实网卡 = lan；蒲公英 / ZeroTier / Tailscale / WireGuard / VPN = overlay；虚拟机 / Docker / WSL / 蓝牙 = junk', () => {
  for (const n of ['以太网', 'WLAN', 'Ethernet 3', 'Wi-Fi']) assert.strictEqual(NU.kindOfIface(n), 'lan', n);
  for (const n of ['蒲公英', 'PgyVPN', 'Oray Virtual Ethernet', 'ZeroTier One [8056c2e21c000001]', 'Tailscale', 'WireGuard Tunnel', 'OpenVPN TAP-Windows6', 'Meta Tunnel', 'Wintun', 'EasyTier'])
    assert.strictEqual(NU.kindOfIface(n), 'overlay', n);
  for (const n of ['vEthernet (Default Switch)', 'VMware Network Adapter VMnet8', 'VirtualBox Host-Only Network', 'WSL', 'docker0', '蓝牙网络连接 (Bluetooth)']) assert.strictEqual(NU.kindOfIface(n), 'junk', n);
});

ok('本机地址：丢掉回环 / 169.254 / 组播 / CLAT / Clash 假 IP 段；保留私有地址、100.64（Tailscale / 运营商 NAT）', () => {
  const ifs = {
    '以太网': [nic('192.168.1.5'), { family: 'IPv6', address: 'fe80::1', internal: false }],
    'Loopback': [{ family: 'IPv4', address: '127.0.0.1', netmask: '255.0.0.0', internal: true }],
    'Wi-Fi': [nic('169.254.7.7', '255.255.0.0')],
    'Meta': [nic('198.18.0.1', '255.254.0.0')],
    'Tailscale': [nic('100.101.102.103', '255.255.255.255')],
    '蒲公英': [nic('172.16.5.9', '255.255.0.0')]
  };
  const l = NU.localAddrs(ifs);
  assert.deepStrictEqual(l.map(x => x.ip), ['192.168.1.5', '100.101.102.103', '172.16.5.9']);
  assert.deepStrictEqual(l.map(x => x.kind), ['lan', 'overlay', 'overlay']);
  assert.deepStrictEqual(l.map(x => x.prefix), [24, 32, 16]);
});

ok('二维码地址：真实局域网在前、虚拟局域网在后；虚拟机网卡不放；只有虚拟机网卡时才退而求其次；最多 6 个', () => {
  const ifs = { 'WLAN': [nic('10.0.0.8')], '以太网': [nic('192.168.1.5')], '蒲公英': [nic('172.16.5.9', '255.255.0.0')], 'vEthernet (WSL)': [nic('172.28.0.1', '255.255.240.0')] };
  const l = NU.localAddrs(ifs);
  assert.deepStrictEqual(NU.qrAddrs(l), ['192.168.1.5', '10.0.0.8', '172.16.5.9']);
  assert.deepStrictEqual(NU.qrAddrs(NU.localAddrs({ 'vEthernet (WSL)': [nic('172.28.0.1')] })), ['172.28.0.1']);
  assert.deepStrictEqual(NU.qrAddrs([]), []);
  const many = NU.localAddrs(Object.fromEntries(Array.from({ length: 9 }, (_, i) => ['以太网 ' + i, [nic('192.168.' + i + '.5')]])));
  assert.strictEqual(NU.qrAddrs(many).length, 6);
  assert.strictEqual(NU.describeNet(l), '局域网 192.168.1.5 / 10.0.0.8 · 虚拟网络 172.16.5.9');
});

/* ───────── 对方地址排序 ───────── */
ok('对方地址排序：同一真实局域网 → 同一虚拟局域网 → 其他私有 → 其他；同级保持原顺序；去重、丢弃非法值', () => {
  const l = NU.localAddrs({ 'WLAN': [nic('192.168.1.7')], '蒲公英': [nic('172.16.5.9', '255.255.0.0')] });
  assert.deepStrictEqual(NU.order(['8.8.8.8', '10.1.1.1', '172.16.9.9', '192.168.1.5', 'abc', '192.168.1.5'], l), ['192.168.1.5', '172.16.9.9', '10.1.1.1', '8.8.8.8']);
  assert.deepStrictEqual(NU.order(['10.2.2.2', '10.1.1.1'], l), ['10.2.2.2', '10.1.1.1']);
  assert.strictEqual(NU.pathLabel('192.168.1.5', l), '局域网直连');
  assert.strictEqual(NU.pathLabel('172.16.0.1', l), '虚拟局域网');
  assert.strictEqual(NU.pathLabel('10.9.9.9', l), '远程连接');
});

ok('单播发现的对象：同网段 / 公网一律发；别的私有地址只有本机在虚拟局域网里才发（移动网络 / 别人的局域网里不把设备名发给不相干的私有地址）', () => {
  const home = NU.localAddrs({ 'WLAN': [nic('192.168.1.7')] }), vpn = NU.localAddrs({ 'WLAN': [nic('192.168.1.7')], '蒲公英': [nic('172.16.5.9', '255.255.0.0')] });
  assert.strictEqual(NU.shouldUnicast('192.168.1.5', home), true);
  assert.strictEqual(NU.shouldUnicast('172.16.0.1', home), false);
  assert.strictEqual(NU.shouldUnicast('203.0.113.9', home), true);
  assert.strictEqual(NU.shouldUnicast('172.16.0.1', vpn), true);
  assert.strictEqual(NU.shouldUnicast('10.9.9.9', vpn), true);
});

ok('心跳放宽依据：对方在本机真实局域网里 = LAN；在虚拟局域网 / 别处 = 非 LAN', () => {
  const l = NU.localAddrs({ 'WLAN': [nic('192.168.1.7')], '蒲公英': [nic('172.16.5.9', '255.255.0.0')] });
  assert.strictEqual(NU.isLanPeer('192.168.1.99', l), true);
  assert.strictEqual(NU.isLanPeer('172.16.0.1', l), false);
  assert.strictEqual(NU.isLanPeer('10.0.0.1', l), false);
});

ok('地址合并：新主地址排第一，备用地址去重、最多共 6 个，非法值丢弃', () => {
  assert.deepStrictEqual(NU.mergeAddrs('172.16.0.1', ['192.168.1.5'], ['192.168.1.5', '10.0.0.2', 'zzz']), { ip: '172.16.0.1', ips: ['192.168.1.5', '10.0.0.2'] });
  const m = NU.mergeAddrs('1.1.1.1', ['2.2.2.2', '3.3.3.3'], ['4.4.4.4', '5.5.5.5', '6.6.6.6', '7.7.7.7', '8.8.8.8']);
  assert.strictEqual(m.ip, '1.1.1.1'); assert.strictEqual(m.ips.length, 5);
  assert.deepStrictEqual(NU.mergeAddrs(undefined, undefined, ['10.0.0.9']), { ip: '10.0.0.9', ips: [] });
  assert.deepStrictEqual(NU.recAddrs({ ip: '1.2.3.4', ips: ['5.6.7.8', '1.2.3.4', 'x'] }), ['1.2.3.4', '5.6.7.8']);
});

/* ───────── 配对链接 ───────── */
ok('配对链接：生成 → 解析 往返一致（含中文设备名）；前后夹着别的文字、结尾有标点也能找出来', () => {
  const link = NU.buildPairLink({ id: 'abcd1234abcd1234', name: '张三的 PC & 手机', pin: '4815162342', port: 47800, ips: ['192.168.1.5', '172.16.0.1'] });
  assert.match(link, /^lancast:\/\/pair\?v=2&id=abcd1234abcd1234&n=/);
  const a = NU.parsePairLink(link);
  assert.deepStrictEqual(a, { id: 'abcd1234abcd1234', name: '张三的 PC & 手机', pin: '4815162342', port: 47800, ips: ['192.168.1.5', '172.16.0.1'] });
  assert.deepStrictEqual(NU.parsePairLink('我的配对链接：' + link + '，收到请回复。'), a);
  assert.deepStrictEqual(NU.parsePairLink('(' + link + ').'), a);
  assert.deepStrictEqual(NU.parsePairLink('请用 ' + link + ' 配对\n谢谢'), a);
});

ok('配对链接：安卓端 Net.kt 生成的格式（v=2，Uri.encode 的名字、逗号分隔 IP）也能解析', () => {
  const t = 'lancast://pair?v=2&id=1a2b3c4d5e6f7a8b&n=Pixel%209%20Pro&p=0123456789&port=47800&ip=192.168.43.1,100.64.0.8';
  assert.deepStrictEqual(NU.parsePairLink(t), { id: '1a2b3c4d5e6f7a8b', name: 'Pixel 9 Pro', pin: '0123456789', port: 47800, ips: ['192.168.43.1', '100.64.0.8'] });
});

ok('配对链接：缺字段 / 密钥格式不对 / 没有可用 IP / 不是瞬流Pro链接 → null；端口非法回落到 47800；非法 IP 被剔除', () => {
  assert.strictEqual(NU.parsePairLink(''), null);
  assert.strictEqual(NU.parsePairLink('https://example.com/?id=abcd&p=123456&ip=1.2.3.4'), null);
  assert.strictEqual(NU.parsePairLink('lancast://pair?v=2&id=abcd1234&p=12ab56&ip=192.168.1.5'), null);
  assert.strictEqual(NU.parsePairLink('lancast://pair?v=2&id=ab&p=123456&ip=192.168.1.5'), null);
  assert.strictEqual(NU.parsePairLink('lancast://pair?v=2&id=abcd1234&p=123456&ip='), null);
  assert.strictEqual(NU.parsePairLink('lancast://pair?v=2&id=abcd1234&p=123456&ip=127.0.0.1,169.254.1.1,224.0.0.1'), null);
  const r = NU.parsePairLink('lancast://pair?v=2&id=abcd1234&p=123456&port=99999&ip=192.168.1.5,nope,172.16.0.1,192.168.1.5');
  assert.strictEqual(r.port, 47800); assert.deepStrictEqual(r.ips, ['192.168.1.5', '172.16.0.1']); assert.strictEqual(r.name, '对方设备');
});

/* ───────── 并行探测 ───────── */
const listen = () => new Promise(res => { const s = net.createServer(c => c.destroy()); s.listen(0, '127.0.0.1', () => res(s)); });
const deadPort = async () => { const s = await listen(), p = s.address().port; await new Promise(r => s.close(r)); return p; };

ok('探测（真实 TCP）：连得通的返回，连不通的丢掉；全不通返回 []', async () => {
  const s = await listen(), port = s.address().port;
  assert.deepStrictEqual(await NU.probe(['127.0.0.1'], port, { connect: net.connect }), ['127.0.0.1']);
  const dead = await deadPort();
  assert.deepStrictEqual(await NU.probe(['127.0.0.1'], dead, { connect: net.connect, timeoutMs: 1000 }), []);
  assert.deepStrictEqual(await NU.probe([], port, { connect: net.connect }), []);
  assert.deepStrictEqual(await NU.probe(['not-an-ip'], port, { connect: net.connect }), []);
  s.close();
});

/* 假的 connect：按地址决定「几毫秒后连通 / 失败 / 永远不回应」，并记录有没有被销毁 */
function fakeConnect(plan, log) {
  return ({ host }) => {
    const { EventEmitter } = require('events'), e = new EventEmitter(); let dead = false;
    e.destroy = () => { if (dead) return; dead = true; log && log.push('destroy ' + host); setImmediate(() => e.emit('close')); };
    const p = plan[host] || { r: 'hang' };
    if (p.r === 'ok') setTimeout(() => { if (!dead) e.emit('connect'); }, p.ms || 0);
    else if (p.r === 'fail') setTimeout(() => { if (!dead) e.emit('error', new Error('refused')); }, p.ms || 0);
    return e;
  };
}
ok('探测（抢跑）：排第一的一连通就立刻返回，不等后面还没出结果的；多余的探测连接都被销毁', async () => {
  const log = [], t0 = Date.now();
  const r = await NU.probe(['10.0.0.1', '10.0.0.2', '10.0.0.3'], 1, { connect: fakeConnect({ '10.0.0.1': { r: 'ok', ms: 30 }, '10.0.0.2': { r: 'ok', ms: 5 } }, log), timeoutMs: 2000 });
  assert.deepStrictEqual(r, ['10.0.0.1', '10.0.0.2'].slice(0, r.length)); assert.strictEqual(r[0], '10.0.0.1');
  assert.ok(Date.now() - t0 < 600, '不该等到超时');
  await sleep(30); assert.ok(log.includes('destroy 10.0.0.3'));
});
ok('探测（抢跑）：排前面的失败、后面的连通 → 返回后面的；排前面的迟迟不回应 → 后面的连通后再宽限一小会儿就用它，不等超时', async () => {
  let t0 = Date.now();
  let r = await NU.probe(['10.0.0.1', '10.0.0.2'], 1, { connect: fakeConnect({ '10.0.0.1': { r: 'fail', ms: 10 }, '10.0.0.2': { r: 'ok', ms: 20 } }), timeoutMs: 2000 });
  assert.deepStrictEqual(r, ['10.0.0.2']); assert.ok(Date.now() - t0 < 400);
  t0 = Date.now();
  r = await NU.probe(['10.0.0.1', '10.0.0.2'], 1, { connect: fakeConnect({ '10.0.0.2': { r: 'ok', ms: 20 } }), timeoutMs: 3000, graceMs: 200 });
  assert.deepStrictEqual(r, ['10.0.0.2']); const dt = Date.now() - t0; assert.ok(dt >= 190 && dt < 900, '宽限期应约 200ms，实际 ' + dt);
});
ok('探测（all）：等全部出结果；返回按优先级排列的全部连得通的地址；超时的算不通', async () => {
  const t0 = Date.now();
  const r = await NU.probe(['10.0.0.1', '10.0.0.2', '10.0.0.3', '10.0.0.4'], 1, { connect: fakeConnect({ '10.0.0.1': { r: 'ok', ms: 80 }, '10.0.0.2': { r: 'fail', ms: 5 }, '10.0.0.3': { r: 'ok', ms: 10 } }), all: true, timeoutMs: 400 });
  assert.deepStrictEqual(r, ['10.0.0.1', '10.0.0.3']); assert.ok(Date.now() - t0 >= 380, 'all 模式要等到 10.0.0.4 超时');
});
ok('探测：connect 抛异常的候选被当作不通，不影响其他候选', async () => {
  const c = ({ host }) => { if (host === '10.0.0.1') throw new Error('boom'); return fakeConnect({ '10.0.0.2': { r: 'ok' } })({ host }); };
  assert.deepStrictEqual(await NU.probe(['10.0.0.1', '10.0.0.2'], 1, { connect: c, timeoutMs: 1000 }), ['10.0.0.2']);
});

/* ───────── 防火墙 ───────── */
ok('防火墙脚本：先删旧规则再加 TCP 47800 / UDP 47801 的入站放行（profile=any）；规则名只含 ASCII；PowerShell 包装里没有会截断字符串的单引号', () => {
  const sc = NU.firewallScript();
  assert.match(sc, /delete rule name=LANCast-TCP-47800/); assert.match(sc, /delete rule name=LANCast-UDP-47801/);
  assert.match(sc, /add rule name=LANCast-TCP-47800 dir=in action=allow protocol=TCP localport=47800 profile=any/);
  assert.match(sc, /add rule name=LANCast-UDP-47801 dir=in action=allow protocol=UDP localport=47801 profile=any/);
  assert.ok(sc.indexOf('delete') < sc.indexOf('add rule'));
  assert.ok(!/[^\x20-\x7E]/.test(sc)); assert.ok(!sc.includes("'"));
  const ps = NU.firewallPowerShell();
  assert.ok(ps.startsWith('Start-Process') && ps.includes('-Verb RunAs'));
  assert.strictEqual((ps.match(/'/g) || []).length, 2);
});

/* ───────── 连不上的提示 ───────── */
ok('连不上的提示：本机有虚拟局域网 → 提醒检查对方 / 防火墙；没有 → 提醒先加入蒲公英等虚拟网络', () => {
  const noOverlay = NU.localAddrs({ 'WLAN': [nic('192.168.1.7')] }), withOverlay = NU.localAddrs({ 'WLAN': [nic('192.168.1.7')], '蒲公英': [nic('172.16.5.9', '255.255.0.0')] });
  assert.match(NU.unreachableHint(noOverlay, ['192.168.1.5', '172.16.0.1']), /192\.168\.1\.5、172\.16\.0\.1[\s\S]*没有检测到虚拟局域网[\s\S]*蒲公英/);
  assert.match(NU.unreachableHint(withOverlay, ['172.16.0.1']), /同一个虚拟局域网[\s\S]*放行防火墙/);
});

/* ───────── 配对密钥交换 ───────── */
ok('配对密钥交换：mask → unmask 往返；密钥 / nonce 不对就解不出；非法输入返回空串；公式与安卓 P.maskPin 一致（HMAC(secret, nonce + ":pair") 异或）', () => {
  const secret = '4815162342', nonce = crypto.randomBytes(16).toString('hex'), mine = '123456';
  const hex = proto.maskPin(secret, nonce, mine);
  assert.strictEqual(proto.unmaskPin(secret, nonce, hex), mine);
  assert.notStrictEqual(proto.unmaskPin('0000000000', nonce, hex), mine);
  assert.notStrictEqual(proto.unmaskPin(secret, 'ff'.repeat(16), hex), mine);
  for (const bad of [undefined, 'xyz', 'abc', 'a'.repeat(66), 123]) assert.strictEqual(proto.unmaskPin(secret, nonce, bad), '');
  const ks = crypto.createHmac('sha256', secret).update(nonce + ':pair').digest();          // 安卓端的写法：逐字节异或
  const expect = Buffer.from(mine, 'utf8').map((b, i) => b ^ ks[i % ks.length]).toString('hex');
  assert.strictEqual(hex, expect);
});

ok('配对 HELLO：带 mode=pair / port / 加密后的密钥 / 备用地址；auth 用对方的密钥；备用地址最多 8 个、没有就不带这个字段', () => {
  const h = proto.buildPairHello({ name: 'PC', id: 'abcd1234abcd1234', pin: '4815162342', nonce: 'aa'.repeat(16), cn: 'bb'.repeat(16), myPin: '123456', port: 47800, ips: ['192.168.1.5', '172.16.0.1'] });
  assert.strictEqual(h.mode, 'pair'); assert.strictEqual(h.port, 47800); assert.deepStrictEqual(h.ips, ['192.168.1.5', '172.16.0.1']);
  assert.strictEqual(h.auth, proto.hmacHex('4815162342', 'aa'.repeat(16))); assert.strictEqual(proto.unmaskPin('4815162342', 'aa'.repeat(16), h.pk), '123456');
  assert.ok(!('ips' in proto.buildPairHello({ name: 'PC', id: 'abcd1234', pin: '1234', nonce: 'aa', cn: 'bb'.repeat(8), myPin: '1', port: 1, ips: [] })));
  assert.strictEqual(proto.buildPairHello({ name: 'PC', id: 'abcd1234', pin: '1234', nonce: 'aa', cn: 'bb'.repeat(8), myPin: '1', port: 1, ips: Array.from({ length: 20 }, (_, i) => '10.0.0.' + i) }).ips.length, 8);
});

(async () => {
  for (const [name, fn] of queue) {
    try { await fn(); pass++; console.log('PASS ' + name); }
    catch (e) { failed = true; console.log('FAIL ' + name + '\n     ' + String(e.stack).split('\n').slice(0, 6).join('\n     ')); }
  }
  console.log(failed ? '\n有失败项' : '\nALL ' + pass + ' PASSED');
  process.exit(failed ? 1 : 0);
})();
