'use strict';
// node windows/test/netpath-e2e.test.js
// 虚拟局域网（蒲公英 / ZeroTier 等）跨网络互联整链路：在几个独立的 vm 里各「真正执行」一份 renderer.js，
// 中间是一个会按「谁和谁在同一网段」决定能不能连通的内存网络（TCP 连接 / UDP 广播 / UDP 单播），然后像用户一样粘贴配对链接、点按钮，检查：
//   · 二维码 / 配对链接里同时有局域网地址和虚拟局域网地址
//   · 两台只共享虚拟局域网的电脑（局域网地址互相连不通）用配对链接配对成功，且双方记下了全部地址
//   · 记录里的主地址过期（连不通）时，连接自动改走备用的虚拟局域网地址，并把它记成新的主地址
//   · 对已配对设备的发现是「单播」的（虚拟局域网不转发广播）；同一台设备从两条路被听到时，显示的地址不会来回跳
//   · 配对链接的各种错误输入：不是链接 / 自己的链接 / 全部地址都连不通（给出该怎么办的提示）
const assert = require('assert'), fs = require('fs'), path = require('path'), vm = require('vm'), os = require('os');
const { Duplex, EventEmitter } = require('stream');
const dir = path.join(__dirname, '..');
const NU = require('../netutil');

let pass = 0, failed = false;
const ok = async (name, fn) => { try { await fn(); pass++; console.log('PASS ' + name); } catch (e) { failed = true; console.log('FAIL ' + name + '\n     ' + String(e.stack).split('\n').slice(0, 6).join('\n     ')); } };
const sleep = ms => new Promise(r => setTimeout(r, ms));

/* ───────── 内存网络：只有「在同一网段」的两个地址才通 ───────── */
const insts = [];                                    // 所有实例
const tcpLog = [];                                   // 每次 TCP 连接：{ from, host }
class Pipe extends Duplex {
  constructor(remoteAddress) { super(); this.peer = null; this.remoteAddress = remoteAddress; }
  _read() {}
  _write(chunk, enc, cb) { const p = this.peer; if (p && !p.destroyed) p.push(Buffer.from(chunk)); cb(); }
  _destroy(err, cb) { const p = this.peer; if (p && !p.destroyed) setImmediate(() => p.destroy()); cb(err); }
  setNoDelay() {}
}
const nicsOf = inst => Object.values(inst.nics).flat();
/* 从 from 到 toIp：找 from 的某块网卡和 toIp 同网段、且 toIp 确实属于另一台实例的某块网卡。返回 { target, srcIp } 或 null */
function route(from, toIp) {
  for (const o of insts) {
    if (o === from) continue;
    if (!nicsOf(o).some(n => n.address === toIp)) continue;
    const mine = nicsOf(from).find(n => NU.inRange(toIp, n.address, NU.prefixOfMask(n.netmask)));
    if (mine) return { target: o, srcIp: mine.address };
  }
  return null;
}

/* ───────── 假 DOM（和 matchcode-e2e.test.js 同一思路） ───────── */
function anything() {
  const f = function () {};
  return new Proxy(f, { get: (t, k) => (k === 'then' ? undefined : k === Symbol.toPrimitive ? () => 0 : (k in t ? t[k] : anything())), apply: () => anything(), construct: () => anything(), set: () => true });
}
function makeEl() {
  const l = {};
  const base = {
    hidden: false, value: '', textContent: '', innerHTML: '', style: {}, dataset: {}, className: '', disabled: false,
    classList: { add() {}, remove() {}, toggle() {}, contains() { return false; } },
    width: 0, height: 0, clientWidth: 1000, clientHeight: 600, offsetWidth: 100, offsetHeight: 40,
    addEventListener(type, fn) { (l[type] = l[type] || []).push(fn); }, removeEventListener() {},
    setPointerCapture() {}, releasePointerCapture() {}, focus() {}, blur() {}, appendChild() {},
    querySelector() { return makeEl(); }, getBoundingClientRect() { return { left: 0, top: 0, width: 100, height: 40 }; },
    getContext() { return anything(); }, closest() { return null; }, _l: l
  };
  return new Proxy(base, { get: (t, k) => (k in t ? t[k] : k === 'then' ? undefined : anything()), set: (t, k, v) => { t[k] = v; return true; } });
}

/* ───────── 一台「电脑」：一份真正的 renderer.js ───────── */
function makeInstance(name, nics) {
  const els = new Map(), store = new Map(), winL = {}, udpH = {};
  const el = sel => { if (!els.has(sel)) els.set(sel, makeEl()); return els.get(sel); };
  const inst = { name, nics, el, store, sentTo: new Set(), clip: '', fileIn: [] };
  const fakeNet = {
    createServer(handler) { return { on() {}, listen(port) { inst.tcpHandler = handler; inst.tcpPort = port; } }; },
    connect({ host, port }) {
      const a = new Pipe(host); a.setNoDelay = () => {};
      tcpLog.push({ from: name, host });
      const r = route(inst, host);
      setImmediate(() => {
        if (!r || !r.target.tcpHandler) { a.destroy(Object.assign(new Error('connect ENETUNREACH ' + host + ':' + port), { code: 'ENETUNREACH' })); return; }
        const b = new Pipe(r.srcIp); a.peer = b; b.peer = a;
        a.emit('connect'); r.target.tcpHandler(b);
      });
      return a;
    }
  };
  const fakeDgram = {
    createSocket() {
      const node = {
        on(ev, fn) { udpH[ev] = fn; }, bind(p, cb) { if (cb) cb(); }, setBroadcast() {}, h: udpH,
        send(msg, port, addr, cb) {
          inst.sentTo.add(addr);
          const bcast = addr === '255.255.255.255' || /\.255$/.test(addr);
          for (const o of insts) {
            if (o === inst || !o.udpNode.h.message) continue;
            let src = null;
            if (bcast) {                                    // 广播：只有和本机某块网卡同网段的实例收得到
              const shared = nicsOf(o).find(n => nicsOf(inst).some(m => NU.inRange(n.address, m.address, NU.prefixOfMask(m.netmask))));
              if (shared) src = nicsOf(inst).find(m => NU.inRange(shared.address, m.address, NU.prefixOfMask(m.netmask))).address;
            } else { const r = route(inst, addr); if (r && r.target === o) src = r.srcIp; }
            if (src) setImmediate(() => o.udpNode.h.message(Buffer.from(msg), { address: src }));
          }
          if (cb) cb();
        }
      };
      inst.udpNode = node; return node;
    }
  };
  const fakeOs = Object.assign({}, os, {
    hostname: () => name,
    networkInterfaces: () => Object.fromEntries(Object.entries(inst.nics).map(([k, v]) => [k, v.map(n => ({ family: 'IPv4', address: n.address, netmask: n.netmask, internal: false }))]))
  });
  const sandbox = {
    __isWindow: true, console, Buffer, performance, process: { platform: 'win32', env: {} },
    localStorage: { getItem: k => (store.has(k) ? store.get(k) : null), setItem: (k, v) => store.set(k, String(v)) },
    document: { querySelector: s => el(s), querySelectorAll: () => [], createElement: () => makeEl(), addEventListener() {}, fullscreenElement: null, documentElement: makeEl() },
    navigator: {}, QR: { toCanvas() {} }, innerWidth: 1000, innerHeight: 600, devicePixelRatio: 1,
    requestAnimationFrame: () => 1, cancelAnimationFrame() {},
    addEventListener(type, fn) { (winL[type] = winL[type] || []).push(fn); },
    setTimeout, clearTimeout, setInterval, clearInterval,
    FX: { onIncoming(s) { inst.fileIn.push(s.peerName); s.detach().destroy(); } }          // 收到文件传输连接：只记一笔，不真的收
  };
  sandbox.window = sandbox;
  const ctx = vm.createContext(sandbox);
  const loadInCtx = file => { const m = { exports: {} }; vm.runInContext('(function (module, exports, require) {' + fs.readFileSync(file, 'utf8') + '\n})', ctx, { filename: file })(m, m.exports, req); return m.exports; };
  function req(n) {
    if (n === 'electron') return { ipcRenderer: new Proxy({ invoke: async () => ({ ok: true }) }, { get: (t, k) => (k in t ? t[k] : () => {}) }), clipboard: { readText: () => inst.clip, writeText: t => { inst.clip = t; } } };
    if (n === 'net') return fakeNet;
    if (n === 'dgram') return fakeDgram;
    if (n === 'os') return fakeOs;
    if (['./proto', './controller', './lossless', './matchcode', './netutil', './inject', './inject-win'].includes(n)) return loadInCtx(path.join(dir, n + '.js'));
    return require(n);
  }
  sandbox.require = req;
  inst.run = code => vm.runInContext(code, ctx);
  insts.push(inst);
  vm.runInContext(fs.readFileSync(path.join(dir, 'renderer.js'), 'utf8'), ctx, { filename: 'renderer.js:' + name });
  inst.pairs = () => JSON.parse(store.get('pairs') || '[]');
  inst.setPairs = a => store.set('pairs', JSON.stringify(a));
  inst.id = () => inst.run('myId'); inst.pin = () => inst.run('myPin');
  inst.netMsg = () => el('#netMsg').textContent;
  inst.link = () => inst.run('pairText()');
  inst.paste = text => { el('#linkIn').value = text; return el('#linkGo').onclick(); };
  return inst;
}
const lan = (ip, mask = '255.255.255.0') => ({ address: ip, netmask: mask });

(async () => {
  /* A：家里的电脑（局域网 192.168.1.5 + 蒲公英 172.16.0.1）；B：公司的电脑（局域网 10.9.9.9 + 蒲公英 172.16.0.2）——局域网互相够不着，只有蒲公英是通的；
   * C：和 A 在同一个家庭局域网里（192.168.1.6），同时也在蒲公英里（172.16.0.3） */
  const A = makeInstance('PC-家', { '以太网': [lan('192.168.1.5')], '蒲公英': [lan('172.16.0.1', '255.255.0.0')], 'vEthernet (WSL)': [lan('172.28.0.1', '255.255.240.0')] });
  const B = makeInstance('PC-公司', { 'WLAN': [lan('10.9.9.9')], '蒲公英': [lan('172.16.0.2', '255.255.0.0')] });
  const C = makeInstance('PC-书房', { '以太网': [lan('192.168.1.6')], '蒲公英': [lan('172.16.0.3', '255.255.0.0')] });
  const linkOf = inst => NU.parsePairLink(inst.link());

  await ok('配对链接 / 二维码：同时带局域网地址和虚拟局域网地址（局域网在前），不带 WSL 虚拟网卡', () => {
    const l = linkOf(A);
    assert.deepStrictEqual(l.ips, ['192.168.1.5', '172.16.0.1']);
    assert.strictEqual(l.id, A.id()); assert.strictEqual(l.pin, A.pin()); assert.strictEqual(l.name, 'PC-家'); assert.strictEqual(l.port, 47800);
    assert.match(A.el('#me').textContent, /局域网 192\.168\.1\.5 · 虚拟网络 172\.16\.0\.1/);
    A.el('#copyLink').onclick(); assert.strictEqual(A.clip, A.link()); assert.match(A.netMsg(), /已复制/);
  });

  await ok('不是配对链接 / 是自己的链接：给出提示，不连接、不留记录', async () => {
    await B.paste('随便一段话'); assert.match(B.netMsg(), /不是瞬流的配对链接/); assert.strictEqual(B.pairs().length, 0);
    await B.paste(B.link()); assert.match(B.netMsg(), /本机自己的配对链接/);
  });

  await ok('B（只和 A 共享蒲公英）粘贴 A 的链接：局域网地址探测不通、虚拟局域网地址探测通 → 配对成功；双方记下全部地址', async () => {
    tcpLog.length = 0;
    await B.paste('这是我的瞬流配对链接：' + A.link() + ' 收到请回复');
    assert.match(B.netMsg(), /已与「PC-家」配对成功/, B.netMsg());
    const rb = B.pairs()[0], ra = A.pairs()[0];
    assert.strictEqual(rb.id, A.id()); assert.strictEqual(rb.pin, A.pin()); assert.strictEqual(rb.ip, '172.16.0.1', 'B 经由蒲公英连上，主地址就是虚拟 IP');
    assert.deepStrictEqual(rb.ips, ['192.168.1.5']); assert.strictEqual(rb.ver, 2);
    assert.strictEqual(ra.id, B.id()); assert.strictEqual(ra.pin, B.pin()); assert.strictEqual(ra.ip, '172.16.0.2', 'A 看到的来源地址是 B 的蒲公英 IP');
    assert.deepStrictEqual(ra.ips, ['10.9.9.9'], 'B 在配对 HELLO 里报的另一个地址（它的局域网地址）被记作备用');
    assert.ok(tcpLog.some(x => x.host === '192.168.1.5') && tcpLog.filter(x => x.host === '172.16.0.1').length >= 2, '探测了两个地址，握手只走通的那个');
  });

  await ok('用刚存下的密钥再握手：B 以 file 模式连 A（A 的 FX 收到连接）——配对真的可用', async () => {
    const s = await B.run("connectTo('172.16.0.1', 47800, loadPairs()[0].pin, 'file')");
    assert.strictEqual(s.peerName, 'PC-家'); s.close('done');
    assert.deepStrictEqual(A.fileIn, ['PC-公司']);
  });

  await ok('主地址过期：B 记录里的主地址是连不通的家里局域网 IP → 连接自动改走备用的蒲公英地址，并把它记成新的主地址', async () => {
    const rec = B.pairs()[0];
    B.setPairs([{ ...rec, ip: '192.168.1.5', ips: ['172.16.0.1'] }]);
    tcpLog.length = 0;
    const s = await B.run("connectTo('192.168.1.5', 47800, loadPairs()[0].pin, 'file')");
    assert.strictEqual(s.peerName, 'PC-家'); s.close('done');
    const hosts = tcpLog.map(x => x.host);
    assert.ok(hosts.includes('192.168.1.5') && hosts.filter(h => h === '172.16.0.1').length === 2, '两个都探测了，握手走 172.16.0.1：' + hosts);
    assert.strictEqual(B.pairs()[0].ip, '172.16.0.1'); assert.deepStrictEqual(B.pairs()[0].ips, ['192.168.1.5']);
  });

  await ok('只有一个地址时不探测（和原来一样直接连）；所有地址都不通 → 报正常的连接错误，不会卡住', async () => {
    const rec = B.pairs()[0];
    B.setPairs([{ ...rec, ip: '172.16.0.1', ips: [] }]);
    tcpLog.length = 0;
    const s = await B.run("connectTo('172.16.0.1', 47800, loadPairs()[0].pin, 'file')"); s.close('done');
    assert.strictEqual(tcpLog.length, 1, '单地址：只连一次');
    B.setPairs([{ ...rec, ip: '192.168.1.5', ips: ['10.1.2.3'] }]);
    await assert.rejects(B.run("connectTo('192.168.1.5', 47800, loadPairs()[0].pin, 'file')"), /ENETUNREACH|连接/);
    B.setPairs([{ ...rec, ip: '172.16.0.1', ips: ['192.168.1.5'] }]);
  });

  await ok('全部地址都连不通：提示该怎么办（B 有蒲公英：检查对方 / 防火墙；没有蒲公英：先加入虚拟网络）', async () => {
    const X = makeInstance('PC-X', { '以太网': [lan('192.168.77.7')] });                     // 谁都够不着的孤岛，也没有虚拟网卡
    await X.paste(A.link());
    assert.match(X.netMsg(), /配对失败：连不上对方（试过 192\.168\.1\.5、172\.16\.0\.1）[\s\S]*没有检测到虚拟局域网[\s\S]*蒲公英/, X.netMsg());
    assert.strictEqual(X.pairs().length, 0);
    const ghost = A.link().replace('192.168.1.5,172.16.0.1', '10.55.55.55');                 // B 有蒲公英，但链接里的地址不在任何网段
    await B.paste(ghost); assert.match(B.netMsg(), /连不上对方[\s\S]*同一个虚拟局域网[\s\S]*放行防火墙/, B.netMsg());
  });

  await ok('对方不是链接里的那台设备（地址被别人占用 / 链接过期）：拒绝配对', async () => {
    const forged = A.link().replace('id=' + A.id(), 'id=deadbeefdeadbeef');
    const before = B.pairs().length;
    await B.paste(forged);
    assert.match(B.netMsg(), /对方不是链接里的那台设备/, B.netMsg()); assert.strictEqual(B.pairs().length, before);
  });

  await ok('发现是单播的：A 对已配对的 B 的每个已知地址都发了发现包（虚拟局域网不转发广播）；B 因此看到 A 在线，地址是虚拟 IP，路径标注「虚拟局域网」', async () => {
    A.sentTo.clear(); B.sentTo.clear();
    await sleep(1800);
    assert.ok(A.sentTo.has('172.16.0.2') && A.sentTo.has('10.9.9.9'), 'A 发给：' + [...A.sentTo]);
    assert.ok(B.sentTo.has('172.16.0.1') && B.sentTo.has('192.168.1.5'), 'B 发给：' + [...B.sentTo]);
    const d = B.run('pairedDevices()')[0];
    assert.strictEqual(d.online, true); assert.strictEqual(d.ip, '172.16.0.1'); assert.strictEqual(d.via, '虚拟局域网');
    assert.deepStrictEqual([...d.ips].sort(), ['172.16.0.1', '192.168.1.5']);
  });

  await ok('同一台设备从两条路都被听到（局域网广播 + 蒲公英单播）：C 看 A 的地址固定为局域网（优先级最高），多轮发现后不会来回跳；路径标注「局域网直连」', async () => {
    await C.paste(A.link());
    assert.match(C.netMsg(), /已与「PC-家」配对成功/, C.netMsg());
    const seen = new Set();
    for (let i = 0; i < 6; i++) { await sleep(700); const d = C.run('pairedDevices()')[0]; if (d.online) seen.add(d.ip + '|' + d.via); }
    assert.deepStrictEqual([...seen], ['192.168.1.5|局域网直连']);
  });

  await ok('A 再次被另一台设备配对时，旧地址不丢（记录按设备 ID 合并，不会多出重复项）', async () => {
    await C.paste(A.link());
    assert.strictEqual(C.pairs().length, 1);
    const ra = A.pairs().find(p => p.id === C.id());
    assert.ok(ra && ra.ip && Array.isArray(ra.ips));
    assert.ok(A.pairs().length === 2, 'A 配对过 B 和 C');
  });

  await ok('心跳超时：同一局域网的对端 6 秒；经虚拟局域网 / 别的网络的对端 15 秒（蜂窝切换、中继抖动都很常见）', async () => {
    const lim = (inst, ip) => inst.run("(() => { const s = new Session({ remoteAddress: '" + ip + "', setNoDelay() {}, on() {} }, false); clearInterval(s.timer); return s.idleLimit(); })()");
    assert.strictEqual(lim(C, '192.168.1.5'), 6000);
    assert.strictEqual(lim(C, '172.16.0.1'), 15000);
    assert.strictEqual(lim(B, '8.8.8.8'), 15000);
  });

  console.log(failed ? '\n有失败项' : '\nALL ' + pass + ' PASSED');
  process.exit(failed ? 1 : 0);
})();
