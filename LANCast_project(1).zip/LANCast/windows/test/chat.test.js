'use strict';
// node windows/test/chat.test.js —— 安全聊天：加密（chatcrypto.js）+ 连接与消息状态机（chathub.js）
const assert = require('assert'), crypto = require('crypto');
const CC = require('../chatcrypto'), { createHub } = require('../chathub'), D = require('../chatdata');

let pass = 0, failed = false;
const ok = async (name, fn) => { try { await fn(); pass++; console.log('PASS ' + name); } catch (e) { failed = true; console.log('FAIL ' + name + '\n     ' + String(e.stack).split('\n').slice(0, 6).join('\n     ')); } };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const tick = () => new Promise(r => setImmediate(r));

/* ───────── 加密 ───────── */
function pair(pin = '1234567890', pinB = pin) {
  const sn = crypto.randomBytes(16).toString('hex'), cn = crypto.randomBytes(16).toString('hex');
  const a = CC.genEphemeral(), b = CC.genEphemeral();      // a = 客户端，b = 服务端
  const ka = CC.deriveSession({ eph: a, peerPub: b.pub, isClient: true, serverNonce: sn, clientNonce: cn, pin });
  const kb = CC.deriveSession({ eph: b, peerPub: a.pub, isClient: false, serverNonce: sn, clientNonce: cn, pin: pinB });
  return { a, b, ka, kb, sn, cn };
}

(async () => {
  await ok('密钥协商：两端算出同样的两个方向密钥和 12 位安全码；方向相反，收发密钥不同', async () => {
    const { ka, kb } = pair();
    assert.ok(ka.txKey.equals(kb.rxKey) && ka.rxKey.equals(kb.txKey));
    assert.ok(!ka.txKey.equals(ka.rxKey));
    assert.strictEqual(ka.sas, kb.sas); assert.match(ka.sas, /^\d{4} \d{4} \d{4}$/);
    assert.strictEqual(ka.txKey.length, 32);
  });
  await ok('加密 / 解密往返：中文、emoji、表情包都原样回来；密文里看不到明文', async () => {
    const { ka, kb } = pair();
    const m = { t: 'm', id: 'aabbccdd11223344', ts: 1, x: '你好 😀 hello' };
    const f = CC.seal(ka.txKey, 1, m);
    assert.ok(!f.includes(Buffer.from('hello')) && !f.includes(Buffer.from('你好')));
    const r = CC.open(kb.rxKey, f, 0);
    assert.deepStrictEqual(r.obj, m); assert.strictEqual(r.ctr, 1);
  });
  await ok('重放 / 乱序：计数器不大于已收到的最大值就拒绝；篡改任意一个字节（密文、标签、计数器）都解不开', async () => {
    const { ka, kb } = pair();
    const f1 = CC.seal(ka.txKey, 1, { t: 'a', id: '0011223344556677' }), f2 = CC.seal(ka.txKey, 2, { t: 'a', id: '0011223344556677' });
    assert.strictEqual(CC.open(kb.rxKey, f2, 0).ctr, 2);
    assert.throws(() => CC.open(kb.rxKey, f1, 2), /重复或过期/); assert.throws(() => CC.open(kb.rxKey, f2, 2), /重复或过期/);
    for (const i of [0, 7, 8, 12, f1.length - 1, f1.length - 16]) { const bad = Buffer.from(f1); bad[i] ^= 1; assert.throws(() => CC.open(kb.rxKey, bad, 0), undefined, '改第 ' + i + ' 字节应当失败'); }
    assert.throws(() => CC.open(ka.rxKey, f1, 0), undefined, '把自己发出的帧原样反射回来，用接收密钥解应当失败（反射攻击）');
  });
  await ok('配对密钥参与密钥派生：配对密钥不一致（中间人 / 假冒者）算出的密钥完全不同，消息解不开', async () => {
    const { ka, kb } = pair('1234567890', '1234567891');
    assert.ok(!ka.txKey.equals(kb.rxKey)); assert.notStrictEqual(ka.sas, kb.sas);
    assert.throws(() => CC.open(kb.rxKey, CC.seal(ka.txKey, 1, { t: 'a', id: '0011223344556677' }), 0));
  });
  await ok('中间人替换双方公钥：他和两边各做一次 ECDH，但不知道配对密钥，两边的密钥仍然对不上', async () => {
    const pin = '1234567890', sn = 'a'.repeat(32), cn = 'b'.repeat(32);
    const A = CC.genEphemeral(), B = CC.genEphemeral(), M1 = CC.genEphemeral(), M2 = CC.genEphemeral();
    const ka = CC.deriveSession({ eph: A, peerPub: M1.pub, isClient: true, serverNonce: sn, clientNonce: cn, pin });
    const kb = CC.deriveSession({ eph: B, peerPub: M2.pub, isClient: false, serverNonce: sn, clientNonce: cn, pin });
    // 中间人拿 M1 与 A 的公钥得到的 Z，但不知道 pin：他最好的猜测是用一个猜的 pin
    const guess = CC.deriveSession({ eph: M1, peerPub: A.pub, isClient: false, serverNonce: sn, clientNonce: cn, pin: '0000000000' });
    assert.ok(!guess.rxKey.equals(ka.txKey)); assert.ok(!ka.txKey.equals(kb.rxKey));
    assert.throws(() => CC.open(guess.rxKey, CC.seal(ka.txKey, 1, { t: 'm', id: '0011223344556677', ts: 1, x: 'secret' }), 0));
  });
  await ok('冒充：已配对的设备 X 知道服务端的密钥，但不知道被冒充设备 Y 的密钥——自报 Y 的 ID 也算不出同一把钥匙', async () => {
    const serverPin = '1111111111', yPin = '2222222222', xPin = '3333333333';
    const sn = 'a'.repeat(32), cn = 'b'.repeat(32), S = CC.genEphemeral(), X = CC.genEphemeral();
    const server = CC.deriveSession({ eph: S, peerPub: X.pub, isClient: false, serverNonce: sn, clientNonce: cn, pin: serverPin + ':' + yPin });   // 服务端以为对面是 Y
    const fake = CC.deriveSession({ eph: X, peerPub: S.pub, isClient: true, serverNonce: sn, clientNonce: cn, pin: serverPin + ':' + xPin });
    assert.ok(!fake.txKey.equals(server.rxKey));
    assert.throws(() => CC.open(server.rxKey, CC.seal(fake.txKey, 1, { t: 'm', id: '0011223344556677', ts: 1, x: '我是 Y' }), 0));
  });
  await ok('对端公钥非法（长度不对 / 不是 hex / 不在曲线上）一律拒绝', async () => {
    const e = CC.genEphemeral(), base = { eph: e, isClient: true, serverNonce: 'aa', clientNonce: 'bb', pin: '1' };
    for (const bad of ['', '04', 'zz'.repeat(65), '04' + '00'.repeat(64), '05' + e.pub.slice(2), 12345])
      assert.throws(() => CC.deriveSession({ ...base, peerPub: bad }), undefined, String(bad).slice(0, 12));
  });
  await ok('收到的消息整理：限长、限字段、颜色只认 #rrggbb；非法的丢弃', async () => {
    assert.strictEqual(CC.sanitizeIncoming({ t: 'm', id: 'xyz', x: 'a' }), null, 'ID 格式不对');
    assert.strictEqual(CC.sanitizeIncoming({ t: 'm', id: 'aabbccdd11223344', x: '   ' }), null, '空白消息');
    assert.strictEqual(CC.sanitizeIncoming({ t: 'zzz' }), null);
    const m = CC.sanitizeIncoming({ t: 'm', id: 'aabbccdd11223344', ts: 5, x: 'x'.repeat(9000) });
    assert.strictEqual(m.x.length, CC.MAX_TEXT);
    const s = CC.sanitizeIncoming({ t: 's', id: 'aabbccdd11223344', e: '😂', c: '很长很长很长很长很长很长很长很长很长很长', bg: ['red', 'url(javascript:1)'], evil: '<img src=x onerror=1>' });
    assert.strictEqual([...s.c].length, 16); assert.deepStrictEqual(s.bg, ['#fff3c4', '#ffd37a']); assert.ok(!('evil' in s));
    assert.deepStrictEqual(CC.sanitizeIncoming({ t: 's', id: 'aabbccdd11223344', e: '😂', c: 'ok', bg: ['#112233', '#AABBCC'] }).bg, ['#112233', '#AABBCC']);
    assert.ok(CC.sanitizeIncoming({ t: 'm', id: 'aabbccdd11223344', ts: 9e15, x: 'a' }).ts <= Date.now() + 86400000, '未来的时间戳被夹住');
  });
  await ok('内置数据：表情包 ≥ 40 个，每个都有 emoji / ≤16 字文字 / 合法的两个底色；表情分组非空', async () => {
    assert.ok(D.STICKERS.length >= 40);
    for (const s of D.STICKERS) { assert.ok(s.e && [...s.c].length >= 1 && [...s.c].length <= 16, s.c); assert.ok(s.bg.length === 2 && s.bg.every(v => /^#[0-9a-f]{6}$/i.test(v)), s.c); }
    assert.ok(D.EMOJI_GROUPS.length >= 4 && D.EMOJI_GROUPS.every(g => g.list.length >= 30));
  });

  /* ───────── Hub ───────── */
  class FS {                                          // 内存里的一对会话（接口同 renderer.js 的 Session）
    constructor() { this.peer = null; this.handler = null; this.early = []; this.closed = false; this.onClose = null; this.tap = null; }
    sendFrame(type, buf) { const p = this.peer; if (this.tap) buf = this.tap(type, Buffer.from(buf)); if (!buf || !p || p.closed) return; setImmediate(() => p._recv(type, Buffer.from(buf))); }
    _recv(t, b) { if (this.closed) return; if (this.handler) this.handler(t, 0, 0, b); else this.early.push([t, 0, 0, b]); }
    attach(fn) { this.handler = fn; for (const a of this.early.splice(0)) fn(...a); }
    close(r) { if (this.closed) return; this.closed = true; const oc = this.onClose; this.onClose = null; if (this.peer && !this.peer.closed) setImmediate(() => this.peer.close('对方断开')); if (oc) oc(r); }
  }
  function world() {
    const clock = { t: 1_000_000 };
    const mkStore = () => { const m = new Map(); let u = {}; return { m, load: id => JSON.parse(m.get(id) || '[]'), save: (id, a) => m.set(id, JSON.stringify(a)), loadUnread: () => u, saveUnread: o => { u = JSON.parse(JSON.stringify(o)); } }; };
    // pin.X = X 自己的配对密钥；known.XY = X 的配对记录里存的 Y 的密钥
    const W = { clock, A: null, B: null, dials: 0, notes: [], reachable: true, pin: { A: '1111111111', B: '2222222222' }, known: { AB: '2222222222', BA: '1111111111' } };
    const mk = (me, other) => createHub({
      myId: me === 'A' ? 'aaaa0001' : 'bbbb0002', myName: me === 'A' ? '电脑A' : '手机B', myPin: () => W.pin[me], store: mkStore(), now: () => clock.t,
      peers: () => [{ id: other === 'A' ? 'aaaa0001' : 'bbbb0002', name: other === 'A' ? '电脑A' : '手机B', pin: W.known[me + other], ip: '1.1.1.1', port: 47800, platform: 'windows', online: true }],
      dial: async () => {
        W.dials++;
        if (!W.reachable) throw new Error('unreachable');
        const cs = new FS(), ss = new FS(); cs.peer = ss; ss.peer = cs;
        const sn = crypto.randomBytes(16).toString('hex'), cn = crypto.randomBytes(16).toString('hex');
        // 对面（服务端）：自己的密钥 + 配对记录里存的「客户端的密钥」
        W[other].attach(ss, { peerId: me === 'A' ? 'aaaa0001' : 'bbbb0002', isClient: false, serverNonce: sn, clientNonce: cn, pin: W.pin[other] + ':' + W.known[other + me], peerName: me });
        W.lastClient = cs; W.lastServer = ss;
        return { session: cs, serverNonce: sn, clientNonce: cn };
      },
      notify: n => W.notes.push({ who: me, ...n })
    });
    W.A = mk('A', 'B'); W.B = mk('B', 'A');
    return W;
  }
  const settle = async (n = 6) => { for (let i = 0; i < n; i++) await tick(); await sleep(5); };

  await ok('A 发文字：自动建立加密连接；B 收到并存下，A 的消息变成「已送达」；B 记 1 条未读并触发通知', async () => {
    const W = world(); W.B.viewing = null;
    const m = W.A.sendText('bbbb0002', '你好 B！😀'); assert.strictEqual(m.st, 'sending');
    await settle();
    const a = W.A.messages('bbbb0002'), b = W.B.messages('aaaa0001');
    assert.strictEqual(a[0].st, 'sent'); assert.strictEqual(b.length, 1);
    assert.deepStrictEqual({ x: b[0].x, from: b[0].from, k: b[0].k }, { x: '你好 B！😀', from: 'peer', k: 'm' });
    assert.strictEqual(W.B.unread('aaaa0001'), 1); assert.strictEqual(W.notes.length, 1); assert.strictEqual(W.notes[0].name, '电脑A');
    assert.strictEqual(W.A.isConnected('bbbb0002'), true); assert.strictEqual(W.B.isConnected('aaaa0001'), true);
    assert.strictEqual(W.A.sas('bbbb0002'), W.B.sas('aaaa0001')); assert.ok(W.A.sas('bbbb0002'));
    W.B.markRead('aaaa0001'); assert.strictEqual(W.B.unread('aaaa0001'), 0);
  });
  await ok('反方向复用同一条连接（不会再拨号）；正在看这个聊天时不计未读；表情包原样到达', async () => {
    const W = world(); W.A.sendText('bbbb0002', 'hi'); await settle();
    const dials = W.dials; W.A.viewing = 'bbbb0002';
    W.B.sendSticker('aaaa0001', D.STICKERS[0]); await settle();
    assert.strictEqual(W.dials, dials, '不应重新拨号');
    const got = W.A.messages('bbbb0002').find(v => v.k === 's');
    assert.deepStrictEqual({ e: got.e, c: got.c, bg: got.bg }, { e: D.STICKERS[0].e, c: D.STICKERS[0].c, bg: D.STICKERS[0].bg });
    assert.strictEqual(W.A.unread('bbbb0002'), 0);
    assert.strictEqual(W.B.messages('aaaa0001').find(v => v.k === 's').st, 'sent');
  });
  await ok('对方不在线：持续补连；超过 30 秒还连不上就标「发送失败」；对方恢复后点重试能送达', async () => {
    const W = world(); W.reachable = false;
    const m = W.A.sendText('bbbb0002', '在吗'); await settle();
    for (let i = 0; i < 40; i++) { W.clock.t += 1000; W.A.tick(); await settle(1); }
    assert.ok(W.dials >= 5, '应该在重试拨号：' + W.dials);
    assert.strictEqual(W.A.messages('bbbb0002')[0].st, 'failed');
    W.reachable = true; W.A.retry('bbbb0002', m.id); await settle(); 
    assert.strictEqual(W.A.messages('bbbb0002')[0].st, 'sent'); assert.strictEqual(W.B.messages('aaaa0001')[0].x, '在吗');
  });
  await ok('回执丢了：A 会重发同一条（同一个 ID），B 只存一份并再回执', async () => {
    const W = world(); W.A.sendText('bbbb0002', 'once'); await settle();
    const m = W.A.messages('bbbb0002')[0]; m.st = 'sending'; m.lt = 0;            // 假装回执没收到
    W.clock.t += 5000; W.A.tick(); await settle();
    assert.strictEqual(W.B.messages('aaaa0001').length, 1); assert.strictEqual(W.A.messages('bbbb0002')[0].st, 'sent');
  });
  await ok('两边同时互相发起连接（glare）：消息一条不丢、不重；双方选同一条连接发送', async () => {
    const W = world();
    W.A.sendText('bbbb0002', 'from A'); W.B.sendText('aaaa0001', 'from B'); await settle(10);
    assert.strictEqual(W.A.messages('bbbb0002').length, 2); assert.strictEqual(W.B.messages('aaaa0001').length, 2);
    assert.ok(W.A.messages('bbbb0002').every(m => m.st === 'sent' || m.from === 'peer'));
    assert.ok(W.B.messages('aaaa0001').every(m => m.st === 'sent' || m.from === 'peer'));
    assert.strictEqual(W.A.connections('bbbb0002'), 2); assert.strictEqual(W.B.connections('aaaa0001'), 2);
    W.A.sendText('bbbb0002', 'again'); await settle();
    assert.strictEqual(W.B.messages('aaaa0001').filter(m => m.x === 'again').length, 1);
  });
  await ok('配对密钥不一致（假冒者）：互相解不开 hi 消息，连接被立刻断开，不留任何消息；发出的消息最终失败', async () => {
    const W = world(); W.known.BA = '9999999999';
    W.A.sendText('bbbb0002', 'secret'); await settle(10);
    assert.strictEqual(W.B.messages('aaaa0001').length, 0); assert.strictEqual(W.A.isConnected('bbbb0002'), false);
    assert.strictEqual(W.A.connections('bbbb0002'), 0);
    assert.strictEqual(W.notes.length, 0);
  });
  await ok('被篡改的消息：接收方断开连接，不显示；篡改前已收到的消息不受影响', async () => {
    const W = world(); W.A.sendText('bbbb0002', 'first'); await settle();
    assert.strictEqual(W.B.messages('aaaa0001').length, 1);
    W.lastClient.tap = (type, buf) => { if (type === CC.T_CHAT_MSG) buf[buf.length - 1] ^= 1; return buf; };   // 链路上有人改了密文最后一个字节
    W.A.sendText('bbbb0002', 'tampered'); await settle();
    assert.strictEqual(W.B.messages('aaaa0001').length, 1, '被改过的消息不能显示');
    assert.strictEqual(W.B.connections('aaaa0001'), 0, 'B 应当断开连接');
    assert.strictEqual(W.A.messages('bbbb0002')[1].st, 'sending', '没有回执，A 的这条保持待发送');
  });
  await ok('链路上有人重放旧帧：接收方断开连接', async () => {
    const W = world(); let saved = null;
    W.A.sendText('bbbb0002', 'one'); await settle();
    W.lastClient.tap = (type, buf) => { if (type === CC.T_CHAT_MSG && !saved) saved = Buffer.from(buf); return buf; };
    W.A.sendText('bbbb0002', 'two'); await settle();
    assert.ok(saved); assert.strictEqual(W.B.messages('aaaa0001').length, 2);
    W.lastServer._recv(CC.T_CHAT_MSG, saved); await settle();           // 把第二条原样再塞一遍
    assert.strictEqual(W.B.messages('aaaa0001').length, 2); assert.strictEqual(W.B.connections('aaaa0001'), 0);
  });
  await ok('取消配对：断开连接；清空聊天记录同时清掉未读', async () => {
    const W = world(); W.A.sendText('bbbb0002', 'x'); await settle();
    assert.strictEqual(W.B.unread('aaaa0001'), 1);
    W.B.clear('aaaa0001'); assert.strictEqual(W.B.messages('aaaa0001').length, 0); assert.strictEqual(W.B.unread('aaaa0001'), 0);
    W.A.dropPeer('bbbb0002'); await settle(); assert.strictEqual(W.A.isConnected('bbbb0002'), false);
  });

  console.log('\n' + (failed ? 'SOME FAILED' : 'ALL ' + pass + ' PASSED'));
  process.exit(failed ? 1 : 0);
})();
