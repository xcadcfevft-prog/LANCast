'use strict';
// node windows/test/chat.test.js —— 安全聊天：加密（chatcrypto.js）+ 连接与消息状态机（chathub.js）
const assert = require('assert'), crypto = require('crypto');
const CC = require('../chatcrypto'), { createHub } = require('../chathub'), D = require('../chatdata');

let pass = 0, failed = false;
const ok = async (name, fn) => { try { await fn(); pass++; console.log('PASS ' + name); } catch (e) { failed = true; console.log('FAIL ' + name + '\n     ' + String(e.stack).split('\n').slice(0, 6).join('\n     ')); } };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const tick = () => new Promise(r => setImmediate(r));

/* ───────── 加密 ───────── */
function pair(pin = '1234567890', pinB = pin) {
  const sn = crypto.randomBytes(16).toString('hex'), cn = crypto.randomBytes(16).toString('hex');
  const a = CC.genEphemeral(), b = CC.genEphemeral();      // a = 客户端，b = 服务端
  const ka = CC.deriveSession({ eph: a, peerPub: b.pub, isClient: true, serverNonce: sn, clientNonce: cn, pin });
  const kb = CC.deriveSession({ eph: b, peerPub: a.pub, isClient: false, serverNonce: sn, clientNonce: cn, pin: pinB });
  return { a, b, ka, kb, sn, cn };
}

(async () => {
  await ok('密钥协商：两端算出同样的两个方向密钥和 12 位安全码；方向相反，收发密钥不同', async () => {
    const { ka, kb } = pair();
    assert.ok(ka.txKey.equals(kb.rxKey) && ka.rxKey.equals(kb.txKey));
    assert.ok(!ka.txKey.equals(ka.rxKey));
    assert.strictEqual(ka.sas, kb.sas); assert.match(ka.sas, /^\d{4} \d{4} \d{4}$/);
    assert.strictEqual(ka.txKey.length, 32);
  });
  await ok('加密 / 解密往返：中文、emoji、表情包都原样回来；密文里看不到明文', async () => {
    const { ka, kb } = pair();
    const m = { t: 'm', id: 'aabbccdd11223344', ts: 1, x: '你好 😀 hello' };
    const f = CC.seal(ka.txKey, 1, m);
    assert.ok(!f.includes(Buffer.from('hello')) && !f.includes(Buffer.from('你好')));
    const r = CC.open(kb.rxKey, f, 0);
    assert.deepStrictEqual(r.obj, m); assert.strictEqual(r.ctr, 1);
  });
  await ok('重放 / 乱序：计数器不大于已收到的最大值就拒绝；篡改任意一个字节（密文、标签、计数器）都解不开', async () => {
    const { ka, kb } = pair();
    const f1 = CC.seal(ka.txKey, 1, { t: 'a', id: '0011223344556677' }), f2 = CC.seal(ka.txKey, 2, { t: 'a', id: '0011223344556677' });
    assert.strictEqual(CC.open(kb.rxKey, f2, 0).ctr, 2);
    assert.throws(() => CC.open(kb.rxKey, f1, 2), /重复或过期/); assert.throws(() => CC.open(kb.rxKey, f2, 2), /重复或过期/);
    for (const i of [0, 7, 8, 12, f1.length - 1, f1.length - 16]) { const bad = Buffer.from(f1); bad[i] ^= 1; assert.throws(() => CC.open(kb.rxKey, bad, 0), undefined, '改第 ' + i + ' 字节应当失败'); }
    assert.throws(() => CC.open(ka.rxKey, f1, 0), undefined, '把自己发出的帧原样反射回来，用接收密钥解应当失败（反射攻击）');
  });
  await ok('配对密钥参与密钥派生：配对密钥不一致（中间人 / 假冒者）算出的密钥完全不同，消息解不开', async () => {
    const { ka, kb } = pair('1234567890', '1234567891');
    assert.ok(!ka.txKey.equals(kb.rxKey)); assert.notStrictEqual(ka.sas, kb.sas);
    assert.throws(() => CC.open(kb.rxKey, CC.seal(ka.txKey, 1, { t: 'a', id: '0011223344556677' }), 0));
  });
  await ok('中间人替换双方公钥：他和两边各做一次 ECDH，但不知道配对密钥，两边的密钥仍然对不上', async () => {
    const pin = '1234567890', sn = 'a'.repeat(32), cn = 'b'.repeat(32);
    const A = CC.genEphemeral(), B = CC.genEphemeral(), M1 = CC.genEphemeral(), M2 = CC.genEphemeral();
    const ka = CC.deriveSession({ eph: A, peerPub: M1.pub, isClient: true, serverNonce: sn, clientNonce: cn, pin });
    const kb = CC.deriveSession({ eph: B, peerPub: M2.pub, isClient: false, serverNonce: sn, clientNonce: cn, pin });
    // 中间人拿 M1 与 A 的公钥得到的 Z，但不知道 pin：他最好的猜测是用一个猜的 pin
    const guess = CC.deriveSession({ eph: M1, peerPub: A.pub, isClient: false, serverNonce: sn, clientNonce: cn, pin: '0000000000' });
    assert.ok(!guess.rxKey.equals(ka.txKey)); assert.ok(!ka.txKey.equals(kb.rxKey));
    assert.throws(() => CC.open(guess.rxKey, CC.seal(ka.txKey, 1, { t: 'm', id: '0011223344556677', ts: 1, x: 'secret' }), 0));
  });
  await ok('冒充：已配对的设备 X 知道服务端的密钥，但不知道被冒充设备 Y 的密钥——自报 Y 的 ID 也算不出同一把钥匙', async () => {
    const serverPin = '1111111111', yPin = '2222222222', xPin = '3333333333';
    const sn = 'a'.repeat(32), cn = 'b'.repeat(32), S = CC.genEphemeral(), X = CC.genEphemeral();
    const server = CC.deriveSession({ eph: S, peerPub: X.pub, isClient: false, serverNonce: sn, clientNonce: cn, pin: serverPin + ':' + yPin });   // 服务端以为对面是 Y
    const fake = CC.deriveSession({ eph: X, peerPub: S.pub, isClient: true, serverNonce: sn, clientNonce: cn, pin: serverPin + ':' + xPin });
    assert.ok(!fake.txKey.equals(server.rxKey));
    assert.throws(() => CC.open(server.rxKey, CC.seal(fake.txKey, 1, { t: 'm', id: '0011223344556677', ts: 1, x: '我是 Y' }), 0));
  });
  await ok('对端公钥非法（长度不对 / 不是 hex / 不在曲线上）一律拒绝', async () => {
    const e = CC.genEphemeral(), base = { eph: e, isClient: true, serverNonce: 'aa', clientNonce: 'bb', pin: '1' };
    for (const bad of ['', '04', 'zz'.repeat(65), '04' + '00'.repeat(64), '05' + e.pub.slice(2), 12345])
      assert.throws(() => CC.deriveSession({ ...base, peerPub: bad }), undefined, String(bad).slice(0, 12));
  });
  await ok('收到的消息整理：限长、限字段、颜色只认 #rrggbb；非法的丢弃', async () => {
    assert.strictEqual(CC.sanitizeIncoming({ t: 'm', id: 'xyz', x: 'a' }), null, 'ID 格式不对');
    assert.strictEqual(CC.sanitizeIncoming({ t: 'm', id: 'aabbccdd11223344', x: '   ' }), null, '空白消息');
    assert.strictEqual(CC.sanitizeIncoming({ t: 'zzz' }), null);
    const m = CC.sanitizeIncoming({ t: 'm', id: 'aabbccdd11223344', ts: 5, x: 'x'.repeat(9000) });
    assert.strictEqual(m.x.length, CC.MAX_TEXT);
    const s = CC.sanitizeIncoming({ t: 's', id: 'aabbccdd11223344', e: '😂', c: '很长很长很长很长很长很长很长很长很长很长', bg: ['red', 'url(javascript:1)'], evil: '<img src=x onerror=1>' });
    assert.strictEqual([...s.c].length, 16); assert.deepStrictEqual(s.bg, ['#fff3c4', '#ffd37a']); assert.ok(!('evil' in s));
    assert.deepStrictEqual(CC.sanitizeIncoming({ t: 's', id: 'aabbccdd11223344', e: '😂', c: 'ok', bg: ['#112233', '#AABBCC'] }).bg, ['#112233', '#AABBCC']);
    assert.ok(CC.sanitizeIncoming({ t: 'm', id: 'aabbccdd11223344', ts: 9e15, x: 'a' }).ts <= Date.now() + 86400000, '未来的时间戳被夹住');
  });
  await ok('内置数据：表情包 ≥ 40 个，每个都有 emoji / ≤16 字文字 / 合法的两个底色；表情分组非空', async () => {
    assert.ok(D.STICKERS.length >= 40);
    for (const s of D.STICKERS) { assert.ok(s.e && [...s.c].length >= 1 && [...s.c].length <= 16, s.c); assert.ok(s.bg.length === 2 && s.bg.every(v => /^#[0-9a-f]{6}$/i.test(v)), s.c); }
    assert.ok(D.EMOJI_GROUPS.length >= 4 && D.EMOJI_GROUPS.every(g => g.list.length >= 30));
  });

  /* ───────── Hub ───────── */
  class FS {                                          // 内存里的一对会话（接口同 renderer.js 的 Session）
    constructor() { this.peer = null; this.handler = null; this.early = []; this.closed = false; this.onClose = null; this.tap = null; }
    sendFrame(type, buf) { const p = this.peer; if (this.tap) buf = this.tap(type, Buffer.from(buf)); if (!buf || !p || p.closed) return; setImmediate(() => p._recv(type, Buffer.from(buf))); }
    _recv(t, b) { if (this.closed) return; if (this.handler) this.handler(t, 0, 0, b); else this.early.push([t, 0, 0, b]); }
    attach(fn) { this.handler = fn; for (const a of this.early.splice(0)) fn(...a); }
    close(r) { if (this.closed) return; this.closed = true; const oc = this.onClose; this.onClose = null; if (this.peer && !this.peer.closed) setImmediate(() => this.peer.close('对方断开')); if (oc) oc(r); }
  }
  function world(avOpt) {
    const clock = { t: 1_000_000 };
    const mkStore = () => { const m = new Map(); let u = {}; return { m, load: id => JSON.parse(m.get(id) || '[]'), save: (id, a) => m.set(id, JSON.stringify(a)), loadUnread: () => u, saveUnread: o => { u = JSON.parse(JSON.stringify(o)); } }; };
    // pin.X = X 自己的配对密钥；known.XY = X 的配对记录里存的 Y 的密钥
    const W = { clock, A: null, B: null, dials: 0, notes: [], reachable: true, pin: { A: '1111111111', B: '2222222222' }, known: { AB: '2222222222', BA: '1111111111' } };
    const mk = (me, other) => createHub({
      myId: me === 'A' ? 'aaaa0001' : 'bbbb0002', myName: me === 'A' ? '电脑A' : '手机B', myPin: () => W.pin[me], store: (W.store = W.store || {}, W.store[me] = mkStore()), now: () => clock.t,
      peers: () => [{ id: other === 'A' ? 'aaaa0001' : 'bbbb0002', name: other === 'A' ? '电脑A' : '手机B', pin: W.known[me + other], ip: '1.1.1.1', port: 47800, platform: 'windows', online: true }],
      dial: async () => {
        W.dials++;
        if (!W.reachable) throw new Error('unreachable');
        const cs = new FS(), ss = new FS(); cs.peer = ss; ss.peer = cs;
        const sn = crypto.randomBytes(16).toString('hex'), cn = crypto.randomBytes(16).toString('hex');
        // 对面（服务端）：自己的密钥 + 配对记录里存的「客户端的密钥」
        W[other].attach(ss, { peerId: me === 'A' ? 'aaaa0001' : 'bbbb0002', isClient: false, serverNonce: sn, clientNonce: cn, pin: W.pin[other] + ':' + W.known[other + me], peerName: me });
        W.lastClient = cs; W.lastServer = ss;
        return { session: cs, serverNonce: sn, clientNonce: cn };
      },
      notify: n => W.notes.push({ who: me, ...n }),
      avatar: avOpt && avOpt[me]
    });
    W.A = mk('A', 'B'); W.B = mk('B', 'A');
    return W;
  }
  const settle = async (n = 6) => { for (let i = 0; i < n; i++) await tick(); await sleep(5); };

  await ok('A 发文字：自动建立加密连接；B 收到并存下，A 的消息变成「已送达」；B 记 1 条未读并触发通知', async () => {
    const W = world(); W.B.viewing = null;
    const m = W.A.sendText('bbbb0002', '你好 B！😀'); assert.strictEqual(m.st, 'sending');
    await settle();
    const a = W.A.messages('bbbb0002'), b = W.B.messages('aaaa0001');
    assert.strictEqual(a[0].st, 'sent'); assert.strictEqual(b.length, 1);
    assert.deepStrictEqual({ x: b[0].x, from: b[0].from, k: b[0].k }, { x: '你好 B！😀', from: 'peer', k: 'm' });
    assert.strictEqual(W.B.unread('aaaa0001'), 1); assert.strictEqual(W.notes.length, 1); assert.strictEqual(W.notes[0].name, '电脑A');
    assert.strictEqual(W.A.isConnected('bbbb0002'), true); assert.strictEqual(W.B.isConnected('aaaa0001'), true);
    assert.strictEqual(W.A.sas('bbbb0002'), W.B.sas('aaaa0001')); assert.ok(W.A.sas('bbbb0002'));
    W.B.markRead('aaaa0001'); assert.strictEqual(W.B.unread('aaaa0001'), 0);
  });
  await ok('反方向复用同一条连接（不会再拨号）；正在看这个聊天时不计未读；表情包原样到达', async () => {
    const W = world(); W.A.sendText('bbbb0002', 'hi'); await settle();
    const dials = W.dials; W.A.viewing = 'bbbb0002';
    W.B.sendSticker('aaaa0001', D.STICKERS[0]); await settle();
    assert.strictEqual(W.dials, dials, '不应重新拨号');
    const got = W.A.messages('bbbb0002').find(v => v.k === 's');
    assert.deepStrictEqual({ e: got.e, c: got.c, bg: got.bg }, { e: D.STICKERS[0].e, c: D.STICKERS[0].c, bg: D.STICKERS[0].bg });
    assert.strictEqual(W.A.unread('bbbb0002'), 0);
    assert.strictEqual(W.B.messages('aaaa0001').find(v => v.k === 's').st, 'sent');
  });
  await ok('对方不在线：持续补连；超过 30 秒还连不上就标「发送失败」；对方恢复后点重试能送达', async () => {
    const W = world(); W.reachable = false;
    const m = W.A.sendText('bbbb0002', '在吗'); await settle();
    for (let i = 0; i < 40; i++) { W.clock.t += 1000; W.A.tick(); await settle(1); }
    assert.ok(W.dials >= 5, '应该在重试拨号：' + W.dials);
    assert.strictEqual(W.A.messages('bbbb0002')[0].st, 'failed');
    W.reachable = true; W.A.retry('bbbb0002', m.id); await settle(); 
    assert.strictEqual(W.A.messages('bbbb0002')[0].st, 'sent'); assert.strictEqual(W.B.messages('aaaa0001')[0].x, '在吗');
  });
  await ok('回执丢了：A 会重发同一条（同一个 ID），B 只存一份并再回执', async () => {
    const W = world(); W.A.sendText('bbbb0002', 'once'); await settle();
    const m = W.A.messages('bbbb0002')[0]; m.st = 'sending'; m.lt = 0;            // 假装回执没收到
    W.clock.t += 5000; W.A.tick(); await settle();
    assert.strictEqual(W.B.messages('aaaa0001').length, 1); assert.strictEqual(W.A.messages('bbbb0002')[0].st, 'sent');
  });
  await ok('两边同时互相发起连接（glare）：消息一条不丢、不重；双方选同一条连接发送', async () => {
    const W = world();
    W.A.sendText('bbbb0002', 'from A'); W.B.sendText('aaaa0001', 'from B'); await settle(10);
    assert.strictEqual(W.A.messages('bbbb0002').length, 2); assert.strictEqual(W.B.messages('aaaa0001').length, 2);
    assert.ok(W.A.messages('bbbb0002').every(m => m.st === 'sent' || m.from === 'peer'));
    assert.ok(W.B.messages('aaaa0001').every(m => m.st === 'sent' || m.from === 'peer'));
    assert.strictEqual(W.A.connections('bbbb0002'), 2); assert.strictEqual(W.B.connections('aaaa0001'), 2);
    W.A.sendText('bbbb0002', 'again'); await settle();
    assert.strictEqual(W.B.messages('aaaa0001').filter(m => m.x === 'again').length, 1);
  });
  await ok('配对密钥不一致（假冒者）：互相解不开 hi 消息，连接被立刻断开，不留任何消息；发出的消息最终失败', async () => {
    const W = world(); W.known.BA = '9999999999';
    W.A.sendText('bbbb0002', 'secret'); await settle(10);
    assert.strictEqual(W.B.messages('aaaa0001').length, 0); assert.strictEqual(W.A.isConnected('bbbb0002'), false);
    assert.strictEqual(W.A.connections('bbbb0002'), 0);
    assert.strictEqual(W.notes.length, 0);
  });
  await ok('被篡改的消息：接收方断开连接，不显示；篡改前已收到的消息不受影响', async () => {
    const W = world(); W.A.sendText('bbbb0002', 'first'); await settle();
    assert.strictEqual(W.B.messages('aaaa0001').length, 1);
    W.lastClient.tap = (type, buf) => { if (type === CC.T_CHAT_MSG) buf[buf.length - 1] ^= 1; return buf; };   // 链路上有人改了密文最后一个字节
    W.A.sendText('bbbb0002', 'tampered'); await settle();
    assert.strictEqual(W.B.messages('aaaa0001').length, 1, '被改过的消息不能显示');
    assert.strictEqual(W.B.connections('aaaa0001'), 0, 'B 应当断开连接');
    assert.strictEqual(W.A.messages('bbbb0002')[1].st, 'sending', '没有回执，A 的这条保持待发送');
  });
  await ok('链路上有人重放旧帧：接收方断开连接', async () => {
    const W = world(); let saved = null;
    W.A.sendText('bbbb0002', 'one'); await settle();
    W.lastClient.tap = (type, buf) => { if (type === CC.T_CHAT_MSG && !saved) saved = Buffer.from(buf); return buf; };
    W.A.sendText('bbbb0002', 'two'); await settle();
    assert.ok(saved); assert.strictEqual(W.B.messages('aaaa0001').length, 2);
    W.lastServer._recv(CC.T_CHAT_MSG, saved); await settle();           // 把第二条原样再塞一遍
    assert.strictEqual(W.B.messages('aaaa0001').length, 2); assert.strictEqual(W.B.connections('aaaa0001'), 0);
  });
  await ok('取消配对：断开连接；清空聊天记录同时清掉未读', async () => {
    const W = world(); W.A.sendText('bbbb0002', 'x'); await settle();
    assert.strictEqual(W.B.unread('aaaa0001'), 1);
    W.B.clear('aaaa0001'); assert.strictEqual(W.B.messages('aaaa0001').length, 0); assert.strictEqual(W.B.unread('aaaa0001'), 0);
    W.A.dropPeer('bbbb0002'); await settle(); assert.strictEqual(W.A.isConnected('bbbb0002'), false);
  });

  /* ───────── 撤回（双向，像 Telegram 的「为所有人删除」） ───────── */
  await ok('撤回：A 撤回自己已送达的消息 → 两边都立刻看不到；B 的未读数回落；B 的存储里也没有内容残留', async () => {
    const W = world(); const m = W.A.sendText('bbbb0002', '发错了，绝密 123'); await settle();
    assert.strictEqual(W.B.unread('aaaa0001'), 1);
    assert.strictEqual(W.A.recall('bbbb0002', m.id), true); await settle();
    assert.strictEqual(W.A.messages('bbbb0002').length, 0); assert.strictEqual(W.B.messages('aaaa0001').length, 0);
    assert.strictEqual(W.B.unread('aaaa0001'), 0, '撤回的消息不再算未读');
    assert.strictEqual(W.A.pendingRecalls('bbbb0002'), 0, '对方回执后，A 这边的墓碑也清掉');
    const rawB = [...W.B.messages('aaaa0001')]; assert.strictEqual(rawB.length, 0);
  });
  await ok('撤回：表情包同样可以撤回；撤回后双方的持久化存储里都找不到原文（只剩没有内容的墓碑）', async () => {
    const W = world(); const st = W.A.sendSticker('bbbb0002', D.STICKERS[1]), tx = W.A.sendText('bbbb0002', '独一无二的暗号-xyz'); await settle();
    assert.ok(W.store.B.m.get('aaaa0001').includes('独一无二的暗号-xyz'), '撤回前对方确实存着');
    W.A.recall('bbbb0002', tx.id); W.A.recall('bbbb0002', st.id); await settle();
    assert.strictEqual(W.B.messages('aaaa0001').length, 0);
    for (const [who, peer] of [['A', 'bbbb0002'], ['B', 'aaaa0001']]) {
      const raw = W.store[who].m.get(peer) || '[]';
      assert.ok(!raw.includes('独一无二的暗号-xyz'), who + ' 存储里不应残留原文');
      assert.ok(!raw.includes(D.STICKERS[1].c), who + ' 存储里不应残留表情包文字');
    }
  });
  await ok('撤回：对方不在线时先在本机删掉，撤回指令排队；对方上线（连得上）后自动送达并生效，不需要用户再操作', async () => {
    const W = world(); const m = W.A.sendText('bbbb0002', '稍后撤回'); await settle();
    W.A.dropPeer('bbbb0002'); W.B.dropPeer('aaaa0001'); await settle();
    W.reachable = false;
    assert.strictEqual(W.A.recall('bbbb0002', m.id), true);
    assert.strictEqual(W.A.messages('bbbb0002').length, 0, 'A 本机立刻看不到');
    assert.strictEqual(W.B.messages('aaaa0001').length, 1, '对方还没上线，B 那边暂时还在');
    assert.strictEqual(W.A.pendingRecalls('bbbb0002'), 1);
    for (let i = 0; i < 10; i++) { W.clock.t += 1000; W.A.tick(); await settle(1); }
    assert.strictEqual(W.A.pendingRecalls('bbbb0002'), 1, '仍然排队，没有放弃');
    W.reachable = true;
    for (let i = 0; i < 8; i++) { W.clock.t += 1000; W.A.tick(); await settle(1); }
    assert.strictEqual(W.B.messages('aaaa0001').length, 0, '对方上线后撤回生效');
    assert.strictEqual(W.A.pendingRecalls('bbbb0002'), 0);
  });
  await ok('撤回指令丢了回执：重发是幂等的（B 已经撤回过，再收到不出错，仍然回执）', async () => {
    const W = world(); const m = W.A.sendText('bbbb0002', 'hello'); await settle();
    W.lastServer.tap = (type, buf) => (type === CC.T_CHAT_MSG ? null : buf);        // B → A 的所有加密帧（含回执）都丢掉
    W.A.recall('bbbb0002', m.id); await settle();
    assert.strictEqual(W.B.messages('aaaa0001').length, 0, 'B 已经撤回');
    assert.strictEqual(W.A.pendingRecalls('bbbb0002'), 1, 'A 没收到回执，继续等');
    W.lastServer.tap = null;
    W.clock.t += 5000; W.A.tick(); await settle();
    assert.strictEqual(W.A.pendingRecalls('bbbb0002'), 0); assert.strictEqual(W.B.messages('aaaa0001').length, 0);
  });
  await ok('撤回：发出去了但还没收到回执（对方其实已经收到了）的消息，也能撤回成功', async () => {
    const W = world(); W.A.sendText('bbbb0002', 'warm up'); await settle();
    W.lastServer.tap = (type, buf) => (type === CC.T_CHAT_MSG ? null : buf);        // B 的回执发不回来
    const m = W.A.sendText('bbbb0002', '回执丢了的消息'); await settle();
    assert.strictEqual(W.A.messages('bbbb0002').find(v => v.id === m.id).st, 'sending');
    assert.strictEqual(W.B.messages('aaaa0001').some(v => v.x === '回执丢了的消息'), true);
    W.lastServer.tap = null;
    W.A.recall('bbbb0002', m.id); await settle();
    assert.strictEqual(W.B.messages('aaaa0001').some(v => v.x === '回执丢了的消息'), false);
  });
  await ok('撤回：从没发出去过的消息（对方不可能见过）直接删掉，不留撤回指令', async () => {
    const W = world(); W.reachable = false;
    const m = W.A.sendText('bbbb0002', '没发出去'); await settle();
    assert.strictEqual(W.A.recall('bbbb0002', m.id), true);
    assert.strictEqual(W.A.messages('bbbb0002').length, 0); assert.strictEqual(W.A.pendingRecalls('bbbb0002'), 0);
  });
  await ok('撤回：只能撤回自己发的消息——B 想撤回 A 发的消息会被拒绝，A 的消息两边都还在；重复撤回 / 不存在的 ID 返回 false', async () => {
    const W = world(); const m = W.A.sendText('bbbb0002', 'A 说的话'); await settle();
    const idOnB = W.B.messages('aaaa0001')[0].id; assert.strictEqual(idOnB, m.id);
    assert.strictEqual(W.B.recall('aaaa0001', idOnB), false);
    await settle(); assert.strictEqual(W.A.messages('bbbb0002').length, 1); assert.strictEqual(W.B.messages('aaaa0001').length, 1);
    assert.strictEqual(W.A.recall('bbbb0002', 'ffffffffffffffff'), false);
    assert.strictEqual(W.A.recall('bbbb0002', m.id), true); await settle();
    assert.strictEqual(W.A.recall('bbbb0002', m.id), false, '已经撤回过');
  });
  await ok('撤回：双向——B 也能随时撤回自己发的消息，A 那边同样消失；其它消息不受影响', async () => {
    const W = world(); W.A.sendText('bbbb0002', 'a1'); await settle();
    const b1 = W.B.sendText('aaaa0001', 'b1'); W.B.sendText('aaaa0001', 'b2'); await settle();
    W.B.recall('aaaa0001', b1.id); await settle();
    assert.deepStrictEqual(W.A.messages('bbbb0002').map(v => v.x), ['a1', 'b2']);
    assert.deepStrictEqual(W.B.messages('aaaa0001').map(v => v.x), ['a1', 'b2']);
  });
  /* 一个「裸」的对端：自己做密钥交换、自己封包，用来精确构造「撤回先到、原消息后到」「别人撤回我的消息」这类顺序 */
  async function rawPeer(W) {
    const cs = new FS(), ss = new FS(); cs.peer = ss; ss.peer = cs;
    const sn = crypto.randomBytes(16).toString('hex'), cn = crypto.randomBytes(16).toString('hex'), pin = W.pin.B + ':' + W.known.BA;
    W.B.attach(ss, { peerId: 'aaaa0001', isClient: false, serverNonce: sn, clientNonce: cn, pin, peerName: 'raw' });
    const eph = CC.genEphemeral(); let k = null, ctr = 0; const got = [];
    cs.attach((type, f, p, pl) => {
      if (type === CC.T_CHAT_KEY) k = CC.deriveSession({ eph, peerPub: JSON.parse(pl.toString()).epk, isClient: true, serverNonce: sn, clientNonce: cn, pin });
      else if (k) got.push(CC.open(k.rxKey, pl, 0).obj);
    });
    cs.sendFrame(CC.T_CHAT_KEY, Buffer.from(JSON.stringify({ v: 1, epk: eph.pub }))); await settle();
    return { got, send: async o => { cs.sendFrame(CC.T_CHAT_MSG, CC.seal(k.txKey, ++ctr, o)); await settle(); } };
  }
  await ok('撤回：撤回指令先于原消息到达（对方还没见过原消息）→ 之后到的原消息被丢掉，不会重新冒出来，并且仍然回执', async () => {
    const W = world(); const r = await rawPeer(W); const id = '0123456789abcdef';
    await r.send({ t: 'd', id });
    assert.ok(r.got.some(o => o.t === 'da' && o.id === id), '撤回要回执');
    await r.send({ t: 'm', id, ts: 5, x: '迟到的原消息' });
    assert.strictEqual(W.B.messages('aaaa0001').length, 0, '原消息不能显示');
    assert.ok(r.got.some(o => o.t === 'a' && o.id === id), '原消息仍要回执，对方才不会一直重发');
    assert.strictEqual(W.B.unread('aaaa0001'), 0); assert.strictEqual(W.notes.length, 0, '不触发通知');
    assert.ok(!(W.store.B.m.get('aaaa0001') || '').includes('迟到'), '内容没有落盘');
  });
  await ok('撤回：对方不能撤回「我发的」消息（伪造 d 指令指向 B 自己发的 ID 无效），也不会留下墓碑', async () => {
    const W = world(); const mine = W.B.sendText('aaaa0001', 'B 自己的话'); await settle();
    const r = await rawPeer(W);
    await r.send({ t: 'd', id: mine.id });
    assert.strictEqual(W.B.messages('aaaa0001').length, 1); assert.strictEqual(W.B.messages('aaaa0001')[0].x, 'B 自己的话');
  });
  await ok('撤回：先到的是未读消息，对方撤回后未读数 -1；已读的消息被撤回，未读数不变', async () => {
    const W = world(); const r = await rawPeer(W);
    await r.send({ t: 'm', id: 'aa00000000000001', ts: 1, x: 'u1' }); await r.send({ t: 'm', id: 'aa00000000000002', ts: 2, x: 'u2' });
    assert.strictEqual(W.B.unread('aaaa0001'), 2);
    await r.send({ t: 'd', id: 'aa00000000000001' }); assert.strictEqual(W.B.unread('aaaa0001'), 1);
    W.B.markRead('aaaa0001'); await r.send({ t: 'd', id: 'aa00000000000002' });
    assert.strictEqual(W.B.unread('aaaa0001'), 0); assert.strictEqual(W.B.messages('aaaa0001').length, 0);
  });
  await ok('清空聊天记录：只清本机；但还没送到对方的撤回指令会保留，不然对方那边的消息就永远撤不掉了', async () => {
    const W = world(); const m = W.A.sendText('bbbb0002', 'x'); await settle();
    W.A.dropPeer('bbbb0002'); W.B.dropPeer('aaaa0001'); await settle();
    W.reachable = false; W.A.recall('bbbb0002', m.id);
    W.A.clear('bbbb0002'); assert.strictEqual(W.A.messages('bbbb0002').length, 0); assert.strictEqual(W.A.pendingRecalls('bbbb0002'), 1);
    W.reachable = true;
    for (let i = 0; i < 8; i++) { W.clock.t += 1000; W.A.tick(); await settle(1); }
    assert.strictEqual(W.B.messages('aaaa0001').length, 0); assert.strictEqual(W.A.pendingRecalls('bbbb0002'), 0);
  });
  await ok('撤回协议：d / da 只接受合法 ID；对方不认识撤回（旧版本）时连发多次无回执后放弃，不会无限重发', async () => {
    assert.deepStrictEqual(CC.sanitizeIncoming({ t: 'd', id: 'aabbccdd11223344' }), { t: 'd', id: 'aabbccdd11223344' });
    assert.deepStrictEqual(CC.sanitizeIncoming({ t: 'da', id: 'aabbccdd11223344' }), { t: 'da', id: 'aabbccdd11223344' });
    assert.strictEqual(CC.sanitizeIncoming({ t: 'd', id: 'zz' }), null); assert.strictEqual(CC.sanitizeIncoming({ t: 'd' }), null);
    const W = world(); const m = W.A.sendText('bbbb0002', 'old peer'); await settle();
    W.lastServer.tap = (type, buf) => (type === CC.T_CHAT_MSG ? null : buf);        // 对方永远不回执
    W.A.recall('bbbb0002', m.id); await settle();
    for (let i = 0; i < 40; i++) { W.clock.t += 5000; W.A.tick(); await settle(1); }
    assert.strictEqual(W.A.pendingRecalls('bbbb0002'), 0, '放弃后不再计为待撤回');
  });

  /* ───────── 撤回文件（用文件传输编号当消息编号；与安卓端 ChatHub.recallFile 对齐）+ 预览类型 ───────── */
  await ok('撤回文件：A 按文件编号撤回 → B 的 onFileRecall 收到同一个编号、聊天里不出现任何消息；A 的墓碑在对方回执后清掉', async () => {
    const W = world(); const got = []; W.B.onFileRecall = (pid, fid) => got.push([pid, fid]);
    W.A.sendText('bbbb0002', 'hi'); await settle();                         // 先把加密连接建好
    assert.strictEqual(W.A.recallFile('bbbb0002', '0123456789ab'), true); await settle();
    assert.deepStrictEqual(got, [['aaaa0001', '0123456789ab']]);
    assert.strictEqual(W.A.pendingRecalls('bbbb0002'), 0); assert.strictEqual(W.B.messages('aaaa0001').length, 1);
  });
  await ok('撤回文件：对方不在线时留墓碑，上线后自动送达并触发 onFileRecall；编号不合法 / 重复撤回被拒绝', async () => {
    const W = world(); const got = []; W.B.onFileRecall = (pid, fid) => got.push(fid);
    W.reachable = false;
    assert.strictEqual(W.A.recallFile('bbbb0002', 'zz'), false);
    assert.strictEqual(W.A.recallFile('bbbb0002', 'aabbccddeeff'), true);
    assert.strictEqual(W.A.recallFile('bbbb0002', 'aabbccddeeff'), false, '已经撤回过');
    assert.strictEqual(W.A.pendingRecalls('bbbb0002'), 1);
    W.reachable = true;
    for (let i = 0; i < 8; i++) { W.clock.t += 1000; W.A.tick(); await settle(1); }
    assert.deepStrictEqual(got, ['aabbccddeeff']); assert.strictEqual(W.A.pendingRecalls('bbbb0002'), 0);
  });
  await ok('撤回文件：对方只能撤回「自己的」编号，伪造撤回我发出的消息无效，也不会触发 onFileRecall', async () => {
    const W = world(); const got = []; W.A.onFileRecall = (pid, fid) => got.push(fid);
    const m = W.A.sendText('bbbb0002', 'mine'); await settle();
    W.B.recallFile('aaaa0001', m.id); await settle();
    assert.strictEqual(W.A.messages('bbbb0002').length, 1); assert.deepStrictEqual(got, []);
  });
  await ok('预览：按扩展名识别图片 / 视频，其它文件不预览', async () => {
    const MP = require('../preview');
    assert.strictEqual(MP.kind('IMG_0001.JPG'), 'image'); assert.strictEqual(MP.kind('a.b.png'), 'image'); assert.strictEqual(MP.kind('x.heic'), 'image');
    assert.strictEqual(MP.kind('clip.MP4'), 'video'); assert.strictEqual(MP.kind('m.mkv'), 'video');
    assert.strictEqual(MP.kind('doc.pdf'), ''); assert.strictEqual(MP.kind('noext'), ''); assert.strictEqual(MP.kind('.png'), 'image');
  });

  /* ───────── 头像互看（第 20 节）───────── */
  const jpegOf = n => Buffer.concat([Buffer.from([0xff, 0xd8, 0xff, 0xe0]), crypto.randomBytes(n)]);
  const hashOf = b => crypto.createHash('sha256').update(b).digest('hex').slice(0, 32);
  function avWorld(bufA, bufB) {
    const st = { A: { buf: bufA, got: null, peer: {} }, B: { buf: bufB, got: null, peer: {} } };
    const mkAv = (me, other) => ({
      mine: () => st[me].buf ? { h: hashOf(st[me].buf), buf: st[me].buf } : null,
      peerHash: id => st[me].peer[id] ? st[me].peer[id].h : '',
      onPeer: (id, h, buf) => { st[me].peer[id] = h ? { h, buf } : null; }
    });
    const W = world({ A: mkAv('A', 'B'), B: mkAv('B', 'A') }); W.st = st; return W;
  }
  await ok('头像：连接建立后双方自动互相同步（多块，约 70KB），收到的与原缩略图逐字节一致', async () => {
    const a = jpegOf(70 * 1024), b = jpegOf(5 * 1024), W = avWorld(a, b);
    W.A.sendText('bbbb0002', 'hi'); await settle(12);
    assert.ok(W.st.B.peer['aaaa0001'] && W.st.B.peer['aaaa0001'].buf.equals(a));
    assert.ok(W.st.A.peer['bbbb0002'] && W.st.A.peer['bbbb0002'].buf.equals(b));
  });
  await ok('头像：本机换头像后 announceAvatar 会推给对方；移除头像对方也会清掉；哈希相同不重复传', async () => {
    const a = jpegOf(3000), W = avWorld(a, null); W.A.sendText('bbbb0002', 'hi'); await settle(10);
    assert.ok(W.st.B.peer['aaaa0001'].buf.equals(a));
    const a2 = jpegOf(4000); W.st.A.buf = a2; W.A.announceAvatar(); await settle(10);
    assert.ok(W.st.B.peer['aaaa0001'].buf.equals(a2));
    W.st.A.buf = null; W.A.announceAvatar(); await settle(10);
    assert.strictEqual(W.st.B.peer['aaaa0001'], null);
  });
  await ok('头像：非法的头像消息（哈希 / 序号 / 块数 / base64 不合法）整条丢弃；对方没头像就什么都不传', async () => {
    assert.strictEqual(CC.sanitizeIncoming({ t: 'avh', h: 'zz' }), null);
    assert.strictEqual(CC.sanitizeIncoming({ t: 'avr', h: 'a'.repeat(31) }), null);
    assert.strictEqual(CC.sanitizeIncoming({ t: 'avd', h: 'a'.repeat(32), i: 5, n: 3, b: 'AAAA' }), null);
    assert.strictEqual(CC.sanitizeIncoming({ t: 'avd', h: 'a'.repeat(32), i: 0, n: CC.AV_MAX_CHUNKS + 1, b: 'AAAA' }), null);
    assert.strictEqual(CC.sanitizeIncoming({ t: 'avd', h: 'a'.repeat(32), i: 0, n: 1, b: '!!!!' }), null);
    assert.deepStrictEqual(CC.sanitizeIncoming({ t: 'avh', h: '' }), { t: 'avh', h: '' });
    // 没有头像的一方不会收到任何东西
    const got = [], W2 = world({ B: { mine: () => null, peerHash: () => '', onPeer: (id, h) => got.push(h) }, A: { mine: () => null, peerHash: () => '', onPeer: () => {} } });
    W2.A.sendText('bbbb0002', 'x'); await settle(8);
    assert.strictEqual(got.length, 0);
  });


  console.log('\n' + (failed ? 'SOME FAILED' : 'ALL ' + pass + ' PASSED'));
  process.exit(failed ? 1 : 0);
})();
