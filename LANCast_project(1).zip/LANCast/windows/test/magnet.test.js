'use strict';
// 磁力解析测试：纯本地回环，不访问外网。内含一个迷你 BT 环境（节点 / UDP Tracker / HTTP Tracker / DHT 节点）。
const assert = require('assert');
const net = require('net'), dgram = require('dgram'), http = require('http'), crypto = require('crypto'), fs = require('fs'), os = require('os'), path = require('path');
const M = require('../magnet');
const { bencode, bdecode } = M;
const sha1 = b => crypto.createHash('sha1').update(b).digest();
const sha256 = b => crypto.createHash('sha256').update(b).digest();

let passed = 0;
const tests = [];
const test = (name, fn) => tests.push([name, fn]);

/* ── 构造一个 400 个文件、约 3 片元数据的 info 字典 ── */
function makeInfo(n = 400) {
  const files = [];
  for (let i = 0; i < n; i++) files.push({ length: 1000 + i, path: ['季' + (i % 7), `第${i}集-一段很长的文件名用来撑大元数据-${'x'.repeat(30)}.mkv`] });
  files.push({ length: 4096, attr: Buffer.from('p'), path: ['.pad', '4096'] });
  return bencode({ name: '测试合集', 'piece length': 262144, pieces: crypto.randomBytes(20 * 5), files });
}
const info = makeInfo();
const IH = sha1(info);
const HEX = IH.toString('hex');
assert(info.length > 2 * 16384, 'info 应跨多个分片');

/* ── 迷你 BT 节点 ── */
function mockPeer({ data = info, ih = IH, mode = 'good' } = {}) {
  const srv = net.createServer(sock => {
    let buf = Buffer.alloc(0), shook = false, clientUt = 0;
    sock.on('error', () => {});
    sock.on('data', d => {
      buf = Buffer.concat([buf, d]);
      if (!shook) {
        if (buf.length < 68) return;
        shook = true; buf = buf.subarray(68);
        if (mode === 'silent') return;
        const hs = Buffer.alloc(68); hs[0] = 19; hs.write('BitTorrent protocol', 1, 'latin1');
        if (mode !== 'noext') hs[25] = 0x10;
        ih.copy(hs, 28); crypto.randomBytes(20).copy(hs, 48); sock.write(hs);
        if (mode === 'noext') return;
        sock.write(Buffer.from([0, 0, 0, 0]));                                   // keep-alive
        sock.write(Buffer.from([0, 0, 0, 2, 5, 0xff]));                          // bitfield（应被忽略）
        const hb = bencode({ m: { ut_metadata: 3, ut_pex: 4 }, metadata_size: data.length, v: 'mock' });
        const eb = Buffer.concat([Buffer.from([20, 0]), hb]), eh = Buffer.alloc(4); eh.writeUInt32BE(eb.length);
        sock.write(Buffer.concat([eh, eb]));
      }
      while (buf.length >= 4) {
        const len = buf.readUInt32BE(0); if (buf.length < 4 + len) break;
        const msg = buf.subarray(4, 4 + len); buf = buf.subarray(4 + len);
        if (len < 2 || msg[0] !== 20) continue;
        if (msg[1] === 0) clientUt = Number(bdecode(msg.subarray(2)).m.ut_metadata);
        else if (msg[1] === 3) {
          const h = bdecode(msg.subarray(2)), piece = Number(h.piece);
          let payload;
          if (mode === 'reject') payload = bencode({ msg_type: 2, piece });
          else {
            let chunk = Buffer.from(data.subarray(piece * 16384, (piece + 1) * 16384));
            if (mode === 'bad') chunk[0] ^= 0xff;
            payload = Buffer.concat([bencode({ msg_type: 1, piece, total_size: data.length }), chunk]);
          }
          const body = Buffer.concat([Buffer.from([20, clientUt]), payload]), hdr = Buffer.alloc(4); hdr.writeUInt32BE(body.length);
          sock.write(Buffer.concat([hdr, body]));
        }
      }
    });
  });
  return new Promise(res => srv.listen(0, '127.0.0.1', () => res({ srv, port: srv.address().port })));
}

function compact(ports) {
  return Buffer.concat(ports.map(p => { const b = Buffer.alloc(6); b[0] = 127; b[3] = 1; b.writeUInt16BE(p, 4); return b; }));
}
function mockUdpTracker(peerPorts, ih = IH) {
  const s = dgram.createSocket('udp4'); const cid = crypto.randomBytes(8);
  s.on('message', (m, r) => {
    const action = m.readUInt32BE(8), tid = m.readUInt32BE(12);
    if (action === 0 && m.length === 16 && m.readBigUInt64BE(0) === 0x41727101980n) {
      const o = Buffer.alloc(16); o.writeUInt32BE(0, 0); o.writeUInt32BE(tid, 4); cid.copy(o, 8); s.send(o, r.port, r.address);
    } else if (action === 1 && m.length >= 98 && m.subarray(0, 8).equals(cid) && m.subarray(16, 36).equals(ih)) {
      if (m.readUInt32BE(80) === 3) return;                                      // stopped
      const o = Buffer.concat([Buffer.alloc(20), compact(peerPorts)]);
      o.writeUInt32BE(1, 0); o.writeUInt32BE(tid, 4); o.writeUInt32BE(1800, 8); o.writeUInt32BE(0, 12); o.writeUInt32BE(1, 16);
      s.send(o, r.port, r.address);
    }
  });
  return new Promise(res => s.bind(0, '127.0.0.1', () => res({ s, port: s.address().port })));
}
function mockHttpTracker(peerPorts, ih = IH) {
  const srv = http.createServer((req, res) => {
    const qs = req.url.split('?')[1] || '';
    const raw = /info_hash=([^&]+)/.exec(qs)[1];
    const got = Buffer.from(raw.replace(/%([0-9a-f]{2})/gi, (m, h) => String.fromCharCode(parseInt(h, 16))), 'latin1');
    if (!got.equals(ih)) { res.end(bencode({ 'failure reason': 'bad hash' })); return; }
    res.end(bencode({ interval: 1800, peers: compact(peerPorts) }));
  });
  return new Promise(res => srv.listen(0, '127.0.0.1', () => res({ srv, port: srv.address().port })));
}
function mockDht(ih, { values = [], nodes = [] } = {}) {
  const s = dgram.createSocket('udp4'); const id = crypto.randomBytes(20);
  s.on('message', (m, r) => {
    const d = bdecode(m);
    if (d.q && d.q.toString() === 'get_peers' && d.a.info_hash.equals(ih) && d.ro === 1) {
      const rr = { id, token: Buffer.from('tk') };
      if (values.length) rr.values = values.map(p => compact([p]));
      if (nodes.length) rr.nodes = Buffer.concat(nodes.map(n => { const b = Buffer.alloc(26); crypto.randomBytes(20).copy(b); b[20] = 127; b[23] = 1; b.writeUInt16BE(n, 24); return b; }));
      s.send(bencode({ t: d.t, y: 'r', r: rr }), r.port, r.address);
    }
  });
  return new Promise(res => s.bind(0, '127.0.0.1', () => res({ s, port: s.address().port })));
}

const NOX = { extraTrackers: [], dht: false, noCache: true };
const check = (r, n = 400) => {
  assert(!r.error, 'resolve error: ' + r.error);
  assert.strictEqual(r.hash, HEX);
  assert.strictEqual(r.name, '测试合集');
  assert.strictEqual(r.fileCount, n);               // 补位文件被过滤
  assert.strictEqual(r.files[3].path, '测试合集/季3/第3集-一段很长的文件名用来撑大元数据-' + 'x'.repeat(30) + '.mkv');
  assert.strictEqual(r.total, Array.from({ length: n }, (_, i) => 1000 + i).reduce((a, b) => a + b, 0));
  assert(Buffer.isBuffer(r.torrent));
  assert.strictEqual(M.parseTorrent(r.torrent).hash, HEX);   // 生成的 .torrent 自洽
};

/* ───────────── 链接解析 ───────────── */
test('parseMagnet: 十六进制 / 大写 / base32 / 重复 xt', () => {
  const h = '0123456789abcdef0123456789abcdef01234567';
  assert.strictEqual(M.parseMagnet('magnet:?xt=urn:btih:' + h).hash, h);
  assert.strictEqual(M.parseMagnet('MAGNET:?XT=URN:BTIH:' + h.toUpperCase()).hash, h);
  const b32 = 'AERUKZ4JVPG66AJDIVTYTK6N54ASGRLH';       // = 0123456789abcdef0123456789abcdef01234567 的 base32
  assert.strictEqual(M.parseMagnet('magnet:?xt=urn:btih:' + b32).hash, h);
  assert.strictEqual(M.parseMagnet('magnet:?xt=urn:sha1:zzz&xt=urn:btih:' + h).hash, h);
});
test('parseMagnet: dn / tr / x.pe / tr.N / 编码', () => {
  const h = HEX;
  const l = M.parseMagnet(`magnet:?xt=urn:btih:${h}&dn=%E6%B5%8B%E8%AF%95+%E5%90%88%E9%9B%86&tr=udp%3A%2F%2Fa.com%3A80%2Fannounce&tr.1=http://b.com/announce&tr=udp://a.com:80/announce&x.pe=1.2.3.4:6881&x.pe=bad&tr=ftp://x`);
  assert.strictEqual(l.name, '测试 合集');
  assert.deepStrictEqual(l.trackers, ['udp://a.com:80/announce', 'http://b.com/announce']);
  assert.deepStrictEqual(l.peers, [{ host: '1.2.3.4', port: 6881 }]);
});
test('parseMagnet: HTML 转义 / 全角 / 断行 / 零宽 / 尖括号', () => {
  const h = HEX;
  assert.strictEqual(M.parseMagnet(`<magnet:?xt=urn:btih:${h}&amp;dn=abc>`).name, 'abc');
  assert.strictEqual(M.parseMagnet(`ｍａｇｎｅｔ：？ｘｔ＝ｕｒｎ：ｂｔｉｈ：${h}`).hash, h);
  assert.strictEqual(M.parseMagnet(`magnet:?xt=urn:btih:${h.slice(0, 20)}​\n${h.slice(20)}`).hash, h);
});
test('parseMagnet: 纯哈希 / btih: 前缀 / thunder / 夹在文字里', () => {
  assert.strictEqual(M.parseMagnet(HEX.toUpperCase()).hash, HEX);
  assert.strictEqual(M.parseMagnet('btih:' + HEX).hash, HEX);
  const th = 'thunder://' + Buffer.from('AAmagnet:?xt=urn:btih:' + HEX + 'ZZ').toString('base64');
  assert.strictEqual(M.parseMagnet(th).hash, HEX);
  assert.strictEqual(M.parseMagnet(`资源在这里：magnet:?xt=urn:btih:${HEX}&dn=a。 下载吧`).hash, HEX);
});
test('parseMagnet: 非法输入给出明确错误', () => {
  assert.throws(() => M.parseMagnet('hello'), /不是磁力链接/);
  assert.throws(() => M.parseMagnet('magnet:?dn=abc'), /缺少/);
  assert.throws(() => M.parseMagnet('magnet:?xt=urn:btih:xyz'), /哈希格式/);
  assert.throws(() => M.parseMagnet('magnet:?xt=urn:btih:' + '1'.repeat(31) + '!'), /哈希格式/);
  assert.throws(() => M.parseMagnet(''), /不是磁力链接/);
});
test('parseMagnet: BT v2 (btmh) 与混合链接', () => {
  const v2 = 'ab'.repeat(32);
  const l = M.parseMagnet('magnet:?xt=urn:btmh:1220' + v2);
  assert(l.v2only); assert.strictEqual(l.hash, v2.slice(0, 40));
  const hy = M.parseMagnet(`magnet:?xt=urn:btih:${HEX}&xt=urn:btmh:1220${v2}`);
  assert(!hy.v2only); assert.strictEqual(hy.hash, HEX); assert.strictEqual(hy.hashV2, v2);
});
test('extractMagnets: 多条去重', () => {
  const a = HEX, b = 'f'.repeat(40);
  const r = M.extractMagnets(`1) magnet:?xt=urn:btih:${a}&dn=A\n2) magnet:?xt=urn:btih:${b}\n3) magnet:?xt=urn:btih:${a.toUpperCase()}\n4) magnet:?xt=urn:btih:bad`);
  assert.deepStrictEqual(r.map(x => x.hash), [a, b]);
});

/* ───────────── bencode / torrent ───────────── */
test('bencode 往返与畸形数据', () => {
  const v = { a: 1, b: [1, 2, 'x'], c: { d: Buffer.from([0, 255]) } };
  const d = bdecode(bencode(v));
  assert.strictEqual(d.a, 1); assert.deepStrictEqual(d.b.slice(0, 2), [1, 2]); assert.deepStrictEqual([...d.c.d], [0, 255]);
  for (const bad of ['', 'i12', 'l', 'd1:a', '5:ab', 'x', 'i1xe', 'd1:a1:b', '99999999999:a']) assert.throws(() => bdecode(Buffer.from(bad)), undefined, bad);
  assert.throws(() => bdecode(Buffer.from('l'.repeat(100) + 'e'.repeat(100))), /嵌套/);
  assert.strictEqual(bdecode(Buffer.from('d9:__proto__i1ee'))['__proto__'], 1);   // 不污染原型
  assert.strictEqual({}.polluted, undefined);
});
test('parseTorrent: GBK / path.utf-8 / 单文件 / 补位 / hash', () => {
  const gbk = Buffer.from('b2e2cad4', 'hex');                               // 「测试」 GBK
  const t = M.parseTorrent(bencode({ announce: 'udp://t.com:1/announce', info: { name: gbk, 'piece length': 16384, pieces: Buffer.alloc(20), length: 5 } }));
  assert.strictEqual(t.name, '测试'); assert.strictEqual(t.files[0].path, '测试'); assert.strictEqual(t.total, 5);
  assert.deepStrictEqual(t.trackers, ['udp://t.com:1/announce']);
  const t2 = M.parseTorrent(bencode({ info: { name: Buffer.from([0xff]), 'name.utf-8': '好', 'piece length': 1, pieces: Buffer.alloc(20), files: [{ length: 1, path: [Buffer.from([0xff])], 'path.utf-8': ['..', 'a', 'b.txt'] }] } }));
  assert.strictEqual(t2.files[0].path, '好/a/b.txt');
  assert.strictEqual(M.parseTorrent(info).hash, HEX);                       // 裸 info 字典
  assert.throws(() => M.parseTorrent(Buffer.from('i1e')), /不是有效/);
  assert.throws(() => M.parseTorrent(bencode({ info: { name: 'x', files: [] } })), /没有文件/);
});
test('parseTorrent: v2 file tree', () => {
  const t = M.parseTorrent(bencode({ info: { name: 'root', 'meta version': 2, 'piece length': 16384, 'file tree': { 'a.txt': { '': { length: 10 } }, dir: { 'b.bin': { '': { length: 20 } } } } } }));
  assert.deepStrictEqual(t.files.map(f => f.path), ['root/a.txt', 'root/dir/b.bin']); assert.strictEqual(t.total, 30); assert(t.v2);
});

/* ───────────── 联网流程（本地模拟） ───────────── */
test('E2E: x.pe 直连（含坏节点 / 拒绝 / 无响应 / 不支持扩展的节点）', async () => {
  const good = await mockPeer(), bad = await mockPeer({ mode: 'bad' }), rej = await mockPeer({ mode: 'reject' });
  const silent = await mockPeer({ mode: 'silent' }), noext = await mockPeer({ mode: 'noext' });
  const ports = [silent, noext, rej, bad, good].map(p => p.port);
  const prog = []; let stage = '';
  const r = await M.resolveMagnet(`magnet:?xt=urn:btih:${HEX}&dn=x&` + ports.map(p => 'x.pe=127.0.0.1:' + p).join('&'),
    { ...NOX, timeout: 20, onProgress: s => { prog.push(s); stage = s.stage; } });
  check(r);
  assert(r.stats.connected >= 2 && r.stats.pieces === r.stats.totalPieces);
  assert(prog.length > 0 && stage);
  [good, bad, rej, silent, noext].forEach(p => p.srv.close());
});
test('E2E: 只有坏节点 → 校验失败并拉黑', async () => {
  const bad = await mockPeer({ mode: 'bad' });
  const r = await M.resolveMagnet(`magnet:?xt=urn:btih:${HEX}&x.pe=127.0.0.1:${bad.port}`, { ...NOX, timeout: 4 });
  assert.strictEqual(r.code, 'BAD_META'); assert(r.files === null);
  bad.srv.close();
});
test('E2E: UDP Tracker', async () => {
  const peer = await mockPeer(), tr = await mockUdpTracker([peer.port]);
  const r = await M.resolveMagnet(`magnet:?xt=urn:btih:${HEX}&tr=udp://127.0.0.1:${tr.port}/announce`, { ...NOX, timeout: 15 });
  check(r); assert.strictEqual(r.stats.trackersOk, 1);
  peer.srv.close(); tr.s.close();
});
test('E2E: HTTP Tracker（info_hash 原始字节编码）', async () => {
  const peer = await mockPeer(), tr = await mockHttpTracker([peer.port]);
  const r = await M.resolveMagnet(`magnet:?xt=urn:btih:${HEX}&tr=http://127.0.0.1:${tr.port}/announce`, { ...NOX, timeout: 15 });
  check(r);
  peer.srv.close(); tr.srv.close();
});
test('E2E: DHT 两跳（引导节点 → 返回新节点 → 返回 peers）', async () => {
  const peer = await mockPeer();
  const leaf = await mockDht(IH, { values: [peer.port] });
  const boot = await mockDht(IH, { nodes: [leaf.port] });
  const r = await M.resolveMagnet(`magnet:?xt=urn:btih:${HEX}`, { ...NOX, dht: true, dhtBootstrap: [['127.0.0.1', boot.port]], timeout: 15 });
  check(r); assert(r.stats.dhtReplies >= 2);
  peer.srv.close(); leaf.s.close(); boot.s.close();
});
test('E2E: 磁盘缓存命中（第二次不需要任何来源）', async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'mgcache-'));
  const peer = await mockPeer();
  const r1 = await M.resolveMagnet(`magnet:?xt=urn:btih:${HEX}&x.pe=127.0.0.1:${peer.port}`, { extraTrackers: [], dht: false, cacheDir: dir, timeout: 15 });
  check(r1); assert(!r1.fromCache);
  M.clearCache(); peer.srv.close();
  const r2 = await M.resolveMagnet(`magnet:?xt=urn:btih:${HEX}`, { extraTrackers: [], dht: false, cacheDir: dir, timeout: 2 });
  check(r2); assert(r2.fromCache);
  fs.writeFileSync(path.join(dir, HEX + '.torrent'), 'garbage');       // 损坏的缓存会被忽略
  M.clearCache();
  const r3 = await M.resolveMagnet(`magnet:?xt=urn:btih:${HEX}`, { extraTrackers: [], dht: false, cacheDir: dir, timeout: 1 });
  assert(r3.error); fs.rmSync(dir, { recursive: true, force: true });
});
test('E2E: BT v2 纯 btmh 链接', async () => {
  const v2info = bencode({ name: 'v2t', 'meta version': 2, 'piece length': 16384, 'file tree': { 'f.bin': { '': { length: 77 } } } });
  const h2 = sha256(v2info), trunc = h2.subarray(0, 20);
  const peer = await mockPeer({ data: v2info, ih: trunc });
  const r = await M.resolveMagnet(`magnet:?xt=urn:btmh:1220${h2.toString('hex')}&x.pe=127.0.0.1:${peer.port}`, { ...NOX, timeout: 10 });
  assert(!r.error, r.error); assert.strictEqual(r.files[0].path, 'v2t/f.bin'); assert.strictEqual(r.total, 77);
  peer.srv.close();
});
test('E2E: 取消 / 超时 / 无效输入', async () => {
  const ac = new AbortController(); setTimeout(() => ac.abort(), 200);
  const t0 = Date.now();
  const r = await M.resolveMagnet(`magnet:?xt=urn:btih:${HEX}`, { ...NOX, timeout: 30, signal: ac.signal });
  assert.strictEqual(r.code, 'ABORTED'); assert(Date.now() - t0 < 3000);
  const r2 = await M.resolveMagnet(`magnet:?xt=urn:btih:${'a'.repeat(40)}`, { ...NOX, timeout: 1 });
  assert.strictEqual(r2.code, 'NO_PEERS'); assert(/没有找到任何节点/.test(r2.error)); assert.strictEqual(r2.hash, 'a'.repeat(40));
  const dead = await new Promise(res => { const s = net.createServer().listen(0, '127.0.0.1', () => { const p = s.address().port; s.close(() => res(p)); }); });
  const r3 = await M.resolveMagnet(`magnet:?xt=urn:btih:${'b'.repeat(40)}&x.pe=127.0.0.1:${dead}`, { ...NOX, timeout: 2 });
  assert.strictEqual(r3.code, 'NO_CONNECT');
  const silent = await mockPeer({ mode: 'noext' });
  const r4 = await M.resolveMagnet(`magnet:?xt=urn:btih:${HEX}&x.pe=127.0.0.1:${silent.port}`, { ...NOX, timeout: 2 });
  assert(['NO_CONNECT', 'NO_META'].includes(r4.code), r4.code); silent.srv.close();
  const r5 = await M.resolveMagnet('nonsense'); assert.strictEqual(r5.code, 'INVALID'); assert(!r5.hash);
});

(async () => {
  for (const [name, fn] of tests) {
    try { await fn(); passed++; console.log('  ok  ' + name); }
    catch (e) { console.log('FAIL  ' + name + '\n      ' + (e && e.stack || e)); process.exitCode = 1; }
  }
  console.log(process.exitCode ? 'magnet: SOME FAILED' : `magnet: ALL ${passed} PASSED`);
  process.exit(process.exitCode || 0);
})();
