'use strict';
// node windows/test/chat-e2e.test.js
// 安全聊天整链路：在两 / 三个独立的 vm 里各「真正执行」一份 renderer.js + chatui.js（假 DOM / 假 Electron），
// 之间用内存里的 TCP 相连：先用匹配码配对，再通过真实的握手（mode = "chat"，含 proof 校验）建立加密连接，检查
//   · 文字 / 表情包双向送达、回执、未读数；两端的安全码一致
//   · 没配对的设备、知道本机密钥但本机没和它配对的设备，都连不上聊天
//   · 取消配对后连接断开
const assert = require('assert'), fs = require('fs'), path = require('path'), vm = require('vm'), os = require('os');
const { Duplex } = require('stream');
const dir = path.join(__dirname, '..');

let pass = 0, failed = false;
const ok = async (name, fn) => { try { await fn(); pass++; console.log('PASS ' + name); } catch (e) { failed = true; console.log('FAIL ' + name + '\n     ' + String(e.stack).split('\n').slice(0, 6).join('\n     ')); } };
const sleep = ms => new Promise(r => setTimeout(r, ms));

/* ───────── 内存网络 ───────── */
const tcpListeners = new Map();          // 'ip:port' → 连接处理函数
const udpNodes = [];                     // 所有实例的 UDP（广播投递给除自己以外的所有实例）
class Pipe extends Duplex {
  constructor(remoteAddress) { super(); this.peer = null; this.remoteAddress = remoteAddress; }
  _read() {}
  _write(chunk, enc, cb) { const p = this.peer, b = Buffer.from(chunk); setImmediate(() => { if (p && !p.destroyed) p.push(b); }); cb(); }   // 和真实 socket 一样异步送达（同步送达会让处理函数「重入」，真实网络里不会发生）
  _destroy(err, cb) { const p = this.peer; if (p && !p.destroyed) setImmediate(() => p.destroy()); cb(err); }
  setNoDelay() {}
}

/* ───────── 假 DOM（和 renderer-control.test.js 同一思路） ───────── */
function anything() {
  const f = function () {};
  return new Proxy(f, { get: (t, k) => (k === 'then' ? undefined : k === Symbol.toPrimitive ? () => 0 : (k in t ? t[k] : anything())), apply: () => anything(), construct: () => anything(), set: () => true });
}
function makeEl() {
  const l = {};
  const base = {
    hidden: false, value: '', textContent: '', innerHTML: '', style: {}, dataset: {}, className: '', disabled: false,
    classList: { add() {}, remove() {}, toggle() {}, contains() { return false; } },
    width: 0, height: 0, clientWidth: 1000, clientHeight: 600, offsetWidth: 100, offsetHeight: 40,
    addEventListener(type, fn) { (l[type] = l[type] || []).push(fn); }, removeEventListener() {},
    setPointerCapture() {}, releasePointerCapture() {}, focus() {}, blur() {}, appendChild() {},
    querySelector() { return makeEl(); }, getBoundingClientRect() { return { left: 0, top: 0, width: 100, height: 40 }; },
    getContext() { return anything(); }, closest() { return null; }, _l: l
  };
  return new Proxy(base, { get: (t, k) => (k in t ? t[k] : k === 'then' ? undefined : anything()), set: (t, k, v) => { t[k] = v; return true; } });
}

/* ───────── 一台「电脑」：一份真正的 renderer.js ───────── */
function makeInstance(name, ip) {
  const els = new Map(), store = new Map(), winL = {}, udpH = {};
  const el = sel => { if (!els.has(sel)) els.set(sel, makeEl()); return els.get(sel); };
  const inst = { name, ip, el, store, lastBeacon: null };
  const fakeNet = {
    createServer(handler) { return { on() {}, listen(port) { tcpListeners.set(ip + ':' + port, handler); } }; },
    connect({ host, port }) {
      const a = new Pipe(host), b = new Pipe(ip); a.peer = b; b.peer = a;
      const h = tcpListeners.get(host + ':' + port);
      setImmediate(() => { if (h) h(b); else a.destroy(Object.assign(new Error('connect ECONNREFUSED ' + host + ':' + port), { code: 'ECONNREFUSED' })); });
      return a;
    }
  };
  const fakeDgram = {
    createSocket() {
      const node = { on(ev, fn) { udpH[ev] = fn; }, bind(p, cb) { if (cb) cb(); }, setBroadcast() {},
        send(msg, port, addr, cb) { inst.lastBeacon = JSON.parse(msg.toString()); for (const o of udpNodes) if (o !== node && o.h.message) setImmediate(() => o.h.message(Buffer.from(msg), { address: ip })); if (cb) cb(); }, h: udpH };
      udpNodes.push(node); return node;
    }
  };
  const fakeOs = Object.assign({}, os, { hostname: () => name, networkInterfaces: () => ({ Ethernet: [{ family: 'IPv4', address: ip, internal: false, netmask: '255.255.255.0' }] }) });
  const sandbox = {
    __isWindow: true, console, Buffer, performance, process: { platform: 'win32', env: {} },
    localStorage: { getItem: k => (store.has(k) ? store.get(k) : null), setItem: (k, v) => store.set(k, String(v)) },
    document: { querySelector: s => el(s), getElementById: () => null, hasFocus: () => inst.focused !== false, title: '', querySelectorAll: () => [], createElement: () => makeEl(), addEventListener() {}, fullscreenElement: null, documentElement: makeEl() },
    FX: { ACTIVE: new Set(), xfers: [], stateText: () => '', cancelX() {}, sendTo() {}, pickAndSend() {} },
    navigator: {}, QR: { toCanvas() {} }, innerWidth: 1000, innerHeight: 600, devicePixelRatio: 1,
    requestAnimationFrame: () => 1, cancelAnimationFrame() {},
    addEventListener(type, fn) { (winL[type] = winL[type] || []).push(fn); },
    setTimeout, clearTimeout, setInterval, clearInterval
  };
  sandbox.window = sandbox;
  const ctx = vm.createContext(sandbox);
  const loadInCtx = file => { const m = { exports: {} }; vm.runInContext('(function (module, exports, require) {' + fs.readFileSync(file, 'utf8') + '\n})', ctx, { filename: file })(m, m.exports, req); return m.exports; };
  function req(n) {
    if (n === 'electron') return { ipcRenderer: new Proxy({ invoke: async () => ({ ok: true }) }, { get: (t, k) => (k in t ? t[k] : () => {}) }), clipboard: { readText: () => '' } };
    if (n === 'net') return fakeNet;
    if (n === 'dgram') return fakeDgram;
    if (n === 'os') return fakeOs;
    if (['./proto', './controller', './lossless', './matchcode', './chathub', './chatcrypto', './chatdata'].includes(n)) return loadInCtx(path.join(dir, n + '.js'));
    return require(n);
  }
  sandbox.require = req;
  inst.run = code => vm.runInContext(code, ctx);
  vm.runInContext(fs.readFileSync(path.join(dir, 'renderer.js'), 'utf8'), ctx, { filename: 'renderer.js:' + name });
  vm.runInContext(fs.readFileSync(path.join(dir, 'chatdata.js'), 'utf8'), ctx, { filename: 'chatdata.js' });
  vm.runInContext(fs.readFileSync(path.join(dir, 'chatui.js'), 'utf8'), ctx, { filename: 'chatui.js:' + name });
  inst.pairs = () => JSON.parse(store.get('pairs') || '[]');
  inst.id = () => inst.run('myId'); inst.pin = () => inst.run('myPin');
  inst.codeShown = () => (el('#codeShow').hidden ? '' : el('#codeText').textContent);
  inst.msg = () => el('#codeMsg').textContent;
  return inst;
}


(async () => {
  const A = makeInstance('PC-A', '10.0.0.1'), B = makeInstance('PC-B', '10.0.0.2'), C = makeInstance('PC-C', '10.0.0.3');
  const hubOf = inst => inst.run('CH.hub'), idOf = inst => inst.id();
  const msgs = (inst, peer) => inst.run('CH.hub').messages(idOf(peer));
  const waitFor = async (fn, ms = 4000) => { const t0 = Date.now(); while (Date.now() - t0 < ms) { try { if (fn()) return true; } catch {} await sleep(40); } return false; };

  await ok('先用匹配码把 A、B 配对（和平时一样）', async () => {
    A.el('#genCode').onclick(); await sleep(20);
    const code = A.codeShown(); assert.match(code, /^\d{3}-\d{3}-\d{4}$/);
    B.el('#codeIn').value = code; B.el('#codeIp').value = '10.0.0.1'; await B.el('#codeGo').onclick();
    assert.strictEqual(A.pairs().length, 1); assert.strictEqual(B.pairs().length, 1);
  });

  await ok('A → B 发文字：真实握手 + 加密连接建立；B 收到、A 显示已送达；B 记 1 条未读；两端安全码一致', async () => {
    hubOf(A).sendText(idOf(B), '你好 B 😀');
    assert.ok(await waitFor(() => msgs(B, A).length === 1 && msgs(A, B)[0].st === 'sent'), '消息应当送达并收到回执');
    assert.strictEqual(msgs(B, A)[0].x, '你好 B 😀'); assert.strictEqual(msgs(B, A)[0].from, 'peer');
    assert.strictEqual(hubOf(B).unread(idOf(A)), 1);
    assert.ok(hubOf(A).isConnected(idOf(B)) && hubOf(B).isConnected(idOf(A)));
    assert.match(hubOf(A).sas(idOf(B)), /^\d{4} \d{4} \d{4}$/); assert.strictEqual(hubOf(A).sas(idOf(B)), hubOf(B).sas(idOf(A)));
  });

  await ok('B → A 发表情包：复用同一条连接；A 收到完整的表情包（emoji / 文字 / 底色）', async () => {
    const st = { e: '🔥', c: '太强了', bg: ['#ffd9b8', '#ff8a3d'] };
    hubOf(B).sendSticker(idOf(A), st);
    assert.ok(await waitFor(() => msgs(A, B).some(m => m.k === 's') && msgs(B, A).find(m => m.k === 's').st === 'sent'));
    const got = msgs(A, B).find(m => m.k === 's');
    assert.strictEqual(JSON.stringify({ e: got.e, c: got.c, bg: got.bg, from: got.from }), JSON.stringify({ ...st, from: 'peer' }));
    assert.strictEqual(hubOf(A).connections(idOf(B)), 1, '不应当多出一条连接');
  });

  await ok('A 正在看这个聊天：新消息不计未读；退出聊天窗口后才计', async () => {
    A.run('CH.open(' + JSON.stringify(idOf(B)) + ')'); await sleep(50);
    hubOf(B).sendText(idOf(A), 'ping');
    assert.ok(await waitFor(() => msgs(A, B).some(m => m.x === 'ping')));
    assert.strictEqual(hubOf(A).unread(idOf(B)), 0);
    A.el('#chatBack').onclick(); await sleep(20);
    hubOf(B).sendText(idOf(A), 'pong');
    assert.ok(await waitFor(() => msgs(A, B).some(m => m.x === 'pong')));
    assert.strictEqual(hubOf(A).unread(idOf(B)), 1);
  });

  await ok('没配对的设备 C（猜了一个密钥）连 A 的聊天：被拒绝', async () => {
    let err = null; try { await C.run('connectTo("10.0.0.1",47800,"1234567890","chat")'); } catch (e) { err = e; }
    assert.ok(err && /配对已失效/.test(err.message), err && err.message);
  });

  await ok('C 知道 A 的密钥但 A 没有和 C 配对：握手通过后被拒绝「没有和你配对」，A 不会出现任何 C 的连接', async () => {
    C.store.set('pairs', JSON.stringify([{ id: idOf(A), name: 'PC-A', platform: 'windows', ip: '10.0.0.1', port: 47800, pin: A.pin(), ver: 2 }]));
    let err = null; try { await C.run('connectTo("10.0.0.1",47800,' + JSON.stringify(A.pin()) + ',"chat")'); } catch (e) { err = e; }
    assert.ok(err && /没有和你配对/.test(err.message), err && err.message);
    assert.strictEqual(hubOf(A).connections(idOf(C)), 0);
  });

  await ok('取消配对：本机断开聊天连接，对方那边也随之断开', async () => {
    A.run('CH.forget(' + JSON.stringify(idOf(B)) + ')'); await sleep(60);
    assert.strictEqual(hubOf(A).connections(idOf(B)), 0);
    assert.ok(await waitFor(() => hubOf(B).connections(idOf(A)) === 0), 'B 那边也应当断开');
  });

  console.log('\n' + (failed ? 'SOME FAILED' : 'ALL ' + pass + ' PASSED'));
  process.exit(failed ? 1 : 0);
})();
