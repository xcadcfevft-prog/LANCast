'use strict';
// node windows/test/controller.test.js   —— 用假时钟驱动，结果确定、不依赖机器快慢
const assert = require('assert');
const { RemoteControl } = require('../controller');
const { createPlanner } = require('../inject');

function fakeClock() {
  let now = 1000, id = 1; const timers = new Map();
  const c = {
    now: () => now,
    setTimeout: (fn, ms) => { timers.set(id, { at: now + ms, fn, every: 0 }); return id++; },
    clearTimeout: i => timers.delete(i),
    setInterval: (fn, ms) => { timers.set(id, { at: now + ms, fn, every: ms }); return id++; },
    clearInterval: i => timers.delete(i),
    advance(ms) {
      const end = now + ms;
      for (;;) {
        let best = null;
        for (const [k, t] of timers) if (t.at <= end && (!best || t.at < best[1].at)) best = [k, t];
        if (!best) break;
        now = best[1].at; if (best[1].every) best[1].at += best[1].every; else timers.delete(best[0]);
        best[1].fn();
      }
      now = end;
    }
  };
  return c;
}
let pass = 0;
const ok = (name, fn) => { try { fn(); pass++; console.log('PASS ' + name); } catch (e) { console.log('FAIL ' + name + '\n     ' + e.stack.split('\n').slice(0, 3).join('\n     ')); process.exitCode = 1; } };
const mk = platform => { const clk = fakeClock(), out = []; const rc = new RemoteControl(platform, c => out.push(c), clk); return { clk, out, rc }; };

/* ═══════ 控制安卓（触摸语义，对接 InputService.kt 已有的 d/m/u/h/k/e）═══════ */
ok('安卓：按下 → d；移动合并成 m（时间相对按下时刻）；抬起 → u（d = 按住毫秒）', () => {
  const { clk, out, rc } = mk('android');
  rc.buttonDown(0, 0.5, 0.5, 100);
  rc.move([[0.51, 0.5, 104], [0.52, 0.5, 108]]);
  clk.advance(20);
  rc.buttonUp(0, 0.53, 0.5, 130);
  assert.deepStrictEqual(out[0], { t: 'd', i: 1, x: 0.5, y: 0.5 });
  assert.deepStrictEqual(out[1], { t: 'm', i: 1, p: [[0.51, 0.5, 4], [0.52, 0.5, 8]] });
  assert.deepStrictEqual(out[2], { t: 'u', i: 1, x: 0.53, y: 0.5, d: 30 });
});
ok('安卓：每次按下序号 i 递增（Kotlin 端据此丢弃过期笔画）', () => {
  const { out, rc } = mk('android');
  rc.buttonDown(0, 0.1, 0.1, 0); rc.buttonUp(0, 0.1, 0.1, 50);
  rc.buttonDown(0, 0.2, 0.2, 200); rc.buttonUp(0, 0.2, 0.2, 240);
  assert.deepStrictEqual(out.filter(o => o.t === 'd').map(o => o.i), [1, 2]);
});
ok('安卓：没按下时的悬停不发任何东西；点按（不移动）只有 d + u', () => {
  const { clk, out, rc } = mk('android');
  rc.move([[0.3, 0.3, 5]]); clk.advance(50);
  assert.strictEqual(out.length, 0);
  rc.buttonDown(0, 0.3, 0.3, 10); rc.buttonUp(0, 0.3, 0.3, 60);
  assert.deepStrictEqual(out.map(o => o.t), ['d', 'u']);
});
ok('安卓：移动点的时间戳单调不减（乱序事件不会让对方的笔画时长变负）', () => {
  const { clk, out, rc } = mk('android');
  rc.buttonDown(0, 0, 0, 100); rc.move([[0.1, 0.1, 110], [0.2, 0.2, 105], [0.3, 0.3, 120]]); clk.advance(20);
  const ms = out.find(o => o.t === 'm').p.map(p => p[2]);
  assert.deepStrictEqual(ms, [10, 10, 20]);
});
ok('安卓：移动按 ~12ms 一包发出，不是每个鼠标事件一帧', () => {
  const { clk, out, rc } = mk('android');
  rc.buttonDown(0, 0.5, 0.5, 0);
  for (let i = 0; i < 10; i++) { rc.move([[0.5 + i / 100, 0.5, i]]); clk.advance(1); }
  clk.advance(30);
  const ms = out.filter(o => o.t === 'm');
  assert.ok(ms.length >= 1 && ms.length <= 2, '包数 ' + ms.length);
  assert.strictEqual(ms.reduce((n, o) => n + o.p.length, 0), 10);
});
ok('安卓：单包最多 64 个点（Kotlin 端 min(len, 64)）；积压 24 点立即冲出', () => {
  const { out, rc } = mk('android');
  rc.buttonDown(0, 0.5, 0.5, 0);
  rc.move(Array.from({ length: 150 }, (_, i) => [0.5, 0.5, i]));
  const ms = out.filter(o => o.t === 'm');
  assert.ok(ms.every(o => o.p.length <= 64));
  assert.strictEqual(ms.reduce((n, o) => n + o.p.length, 0), 150);
});
ok('安卓：按住不动 → 每 500ms 一个保活 h（Kotlin 端 2.5 秒没消息就松手）；抬起后停止', () => {
  const { clk, out, rc } = mk('android');
  rc.buttonDown(0, 0.5, 0.5, 0);
  clk.advance(2100);
  assert.strictEqual(out.filter(o => o.t === 'h').length, 4);
  rc.buttonUp(0, 0.5, 0.5, 2100);
  const n = out.length; clk.advance(3000);
  assert.strictEqual(out.length, n);
});
ok('安卓：右键 = 返回，中键 = 主页', () => {
  const { out, rc } = mk('android');
  rc.buttonDown(2, 0.5, 0.5, 0); rc.buttonDown(1, 0.5, 0.5, 0);
  assert.deepStrictEqual(out, [{ t: 'k', k: 'back' }, { t: 'k', k: 'home' }]);
});
ok('安卓：滚动约 16ms（一帧）一包，量不丢；首包不用等（前沿发送）', () => {
  const { clk, out, rc } = mk('android');
  for (let i = 0; i < 10; i++) { rc.wheel(0, 0.1, 0.5, 0.6, 0, -0.02); clk.advance(8); }     // 8ms 一个滚轮事件 = 80ms
  clk.advance(50);
  const w = out.filter(o => o.t === 'w');
  assert.ok(w.length >= 4 && w.length <= 7, '包数 ' + w.length);                                // 以前 160ms 才一包（整段只有 1 包）
  assert.ok(Math.abs(w.reduce((n, o) => n + o.dy, 0) - 1) < 0.01, 'dy 总量不对');
  assert.ok(Math.abs(w.reduce((n, o) => n + o.sy, 0) + 0.2) < 1e-4, 'sy 总量不对');
  assert.deepStrictEqual([w[0].x, w[0].y], [0.5, 0.6]);
});
ok('安卓：带像素量时发 sx / sy（手指位移占画面的比例）；没带的旧调用只发 dx / dy（Kotlin 端按格数估算）', () => {
  const a = mk('android');
  a.rc.wheel(0, 1, 0.5, 0.5, 0.01, -0.2); a.clk.advance(30);
  assert.deepStrictEqual([a.out[0].dx, a.out[0].dy, a.out[0].sx, a.out[0].sy], [0, 1, 0.01, -0.2]);
  const b = mk('android');
  b.rc.wheel(0, 1, 0.5, 0.5); b.clk.advance(30);
  assert.ok(!('sx' in b.out[0]) && !('sy' in b.out[0]), JSON.stringify(b.out[0]));
});
ok('安卓：滚动首包立即发出（不额外等一个周期），之后限速到每 16ms 一包', () => {
  const { clk, out, rc } = mk('android');
  rc.wheel(0, 0.1, 0.5, 0.5, 0, -0.01);
  clk.advance(1);
  assert.strictEqual(out.filter(o => o.t === 'w').length, 1);
  rc.wheel(0, 0.1, 0.5, 0.5, 0, -0.01); rc.wheel(0, 0.1, 0.5, 0.5, 0, -0.01);
  clk.advance(5);
  assert.strictEqual(out.filter(o => o.t === 'w').length, 1, '16ms 内不该再发');
  clk.advance(20);
  assert.strictEqual(out.filter(o => o.t === 'w').length, 2);
});
ok('安卓：release 会抬起还按着的手指（失焦 / 退出控制）', () => {
  const { out, rc } = mk('android');
  rc.buttonDown(0, 0.4, 0.4, 0); rc.move([[0.45, 0.45, 8]]);
  rc.release();
  assert.strictEqual(out[out.length - 1].t, 'u');
  assert.strictEqual(out[out.length - 1].x, 0.45);
});

/* ═══════ 控制电脑（鼠标键盘语义）═══════ */
ok('电脑：悬停只发最新位置（pm），不攒历史', () => {
  const { clk, out, rc } = mk('windows');
  rc.move([[0.1, 0.1, 1], [0.2, 0.2, 2], [0.3, 0.3, 3]]); clk.advance(20);
  assert.deepStrictEqual(out, [{ t: 'pm', p: [[0.3, 0.3]] }]);
});
ok('电脑：拖动时每个点都发（画图 / 选文字不走样）', () => {
  const { clk, out, rc } = mk('windows');
  rc.buttonDown(0, 0.1, 0.1, 0);
  rc.move([[0.1, 0.1, 1], [0.2, 0.2, 2], [0.3, 0.3, 3]]); clk.advance(20);
  rc.buttonUp(0, 0.3, 0.3, 30);
  assert.deepStrictEqual(out.map(o => o.t), ['pd', 'pm', 'pu']);
  assert.strictEqual(out[1].p.length, 3);
  assert.deepStrictEqual([out[0].b, out[2].b], ['l', 'l']);
});
ok('电脑：按下 / 抬起前先冲掉没发出去的移动 → 点击落在正确位置', () => {
  const { out, rc } = mk('windows');
  rc.move([[0.7, 0.7, 1]]);
  rc.buttonDown(0, 0.7, 0.7, 2);
  assert.deepStrictEqual(out.map(o => o.t), ['pm', 'pd']);
});
ok('电脑：左 / 中 / 右键映射 l m r', () => {
  const { out, rc } = mk('windows');
  rc.buttonDown(2, 0.5, 0.5, 0); rc.buttonUp(2, 0.5, 0.5, 1);
  rc.buttonDown(1, 0.5, 0.5, 2); rc.buttonUp(1, 0.5, 0.5, 3);
  assert.deepStrictEqual(out.map(o => o.t + (o.b || '')), ['pdr', 'pur', 'pdm', 'pum']);
});
ok('电脑：滚轮每 16ms 合并，带位置，量不丢；不带 sx / sy（电脑被控方只认格数）', () => {
  const { clk, out, rc } = mk('windows');
  for (let i = 0; i < 6; i++) { rc.wheel(0, 0.5, 0.4, 0.4, 0, -0.1); clk.advance(5); }
  clk.advance(50);
  const w = out.filter(o => o.t === 'w');
  assert.ok(Math.abs(w.reduce((n, o) => n + o.dy, 0) - 3) < 0.01);
  assert.ok(w.length <= 3, '包数 ' + w.length);
  assert.ok(w.every(o => !('sx' in o) && !('sy' in o)));
});
ok('电脑：键盘 kd / ku；按住的键在 release 时松开；按住期间有保活', () => {
  const { clk, out, rc } = mk('windows');
  rc.keyDown(17); rc.keyDown(67);
  clk.advance(1100);
  assert.ok(out.some(o => o.t === 'h'));
  rc.keyUp(67); rc.release();
  assert.deepStrictEqual(out.filter(o => o.t === 'kd' || o.t === 'ku').map(o => o.t + o.vk), ['kd17', 'kd67', 'ku67', 'ku17']);
});
ok('电脑：没按下过的键，keyUp 不会凭空发 ku', () => {
  const { out, rc } = mk('windows');
  rc.keyUp(65);
  assert.strictEqual(out.length, 0);
});
ok('文字：\\n 拆成「回车」指令；超长按 512 分段；del n', () => {
  const { out, rc } = mk('windows');
  rc.text('你好\nabc'); rc.text('x'.repeat(1100)); rc.del(1); rc.del(3);
  assert.deepStrictEqual(out.slice(0, 3), [{ t: 'e', op: 'append', s: '你好' }, { t: 'e', op: 'enter' }, { t: 'e', op: 'append', s: 'abc' }]);
  assert.deepStrictEqual(out.filter(o => o.s).slice(2).map(o => o.s.length), [512, 512, 76]);
  assert.deepStrictEqual(out.slice(-2), [{ t: 'e', op: 'del' }, { t: 'e', op: 'del', n: 3 }]);
});
ok('destroy 之后不再往外发任何东西', () => {
  const { clk, out, rc } = mk('windows');
  rc.buttonDown(0, 0.5, 0.5, 0); rc.destroy();
  const n = out.length; rc.move([[0.1, 0.1, 5]]); clk.advance(2000);
  assert.strictEqual(out.length, n);
});

/* ═══════ 端到端：观看方指令 → 注入规划器 ═══════ */
ok('端到端：「点一下」= 鼠标移到该点 + 左键按下 + 左键抬起，不留按着的键', () => {
  const { clk, out, rc } = mk('windows'); const pl = createPlanner(); const ops = [];
  rc.move([[0.25, 0.75, 1]]); rc.buttonDown(0, 0.25, 0.75, 2); rc.buttonUp(0, 0.25, 0.75, 40); clk.advance(30);
  for (const c of out) ops.push(...pl.plan(JSON.parse(JSON.stringify(c))));
  assert.ok(ops.length >= 3 && !pl.hasHeld());
  assert.deepStrictEqual([ops[0].x, ops[0].y], [16384, 49151]);
});
ok('端到端：Ctrl+C 经观看方 → 规划器后恰好是 4 个键事件且全部松开', () => {
  const { out, rc } = mk('windows'); const pl = createPlanner();
  rc.combo('ctrl+c');
  const ops = pl.plan(out[0]);
  assert.strictEqual(ops.length, 4); assert.ok(!pl.hasHeld());
});
ok('端到端：安卓语义的 d/m/u 发到 Windows 也能当鼠标拖动用（兼容旧版观看方）', () => {
  const { clk, out, rc } = mk('android'); const pl = createPlanner();
  rc.buttonDown(0, 0.5, 0.5, 0); rc.move([[0.6, 0.6, 10]]); clk.advance(20); rc.buttonUp(0, 0.6, 0.6, 30);
  let n = 0; for (const c of out) n += pl.plan(c).length;
  assert.strictEqual(n, 3); assert.ok(!pl.hasHeld());
});

/* ═══════ 回归：真实浏览器 / Electron 渲染进程里的 setTimeout 必须「无 this」调用 ═══════
 * Chromium 里 window.setTimeout 等被挂到别的对象上再调用会抛 Illegal invocation（Node 不会）。
 * 当年 renderer.js 不传时钟，默认时钟把它们挂在对象上 → 按下第一步就抛错 → 电脑控制手机时触屏 / 鼠标都发不出任何指令。 */
ok('回归：不传时钟（renderer.js 的用法）+ 严格的 Chromium 式计时器，按下 / 移动 / 抬起 / 滚轮 / 保活 / 释放都不抛错', () => {
  const names = ['setTimeout', 'clearTimeout', 'setInterval', 'clearInterval'], real = {};
  for (const n of names) {
    real[n] = globalThis[n];
    globalThis[n] = function (...a) {
      if (this !== undefined && this !== globalThis) throw new TypeError("Failed to execute '" + n + "' on 'Window': Illegal invocation");
      return real[n].apply(globalThis, a);
    };
  }
  try {
    for (const platform of ['android', 'windows']) {
      const out = [], rc = new RemoteControl(platform, c => out.push(c));
      rc.buttonDown(0, 0.5, 0.5, 100);
      rc.move([[0.51, 0.5, 104]]);
      rc.wheel(0, 1, 0.5, 0.5);
      rc.buttonUp(0, 0.52, 0.5, 140);
      rc.release(); rc.destroy();
      assert.ok(out.length >= 2, platform + '：至少要发出 按下 / 抬起');
    }
  } finally { for (const n of names) globalThis[n] = real[n]; }
});

console.log('\n' + pass + ' 项通过');
