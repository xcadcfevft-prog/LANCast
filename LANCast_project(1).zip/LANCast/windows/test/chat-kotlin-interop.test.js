'use strict';
// KT_CP=<含 ChatCrypto.kt 编译产物与 kotlin-stdlib 的 classpath> node test/chat-kotlin-interop.test.js
// 电脑端（chatcrypto.js）与安卓端（ChatCrypto.kt）互相对跑：同一组输入必须得到同样的密钥 / 安全码，互相能解对方加密的帧，清理规则一致。
// 没设置 KT_CP（没有 JVM / Kotlin 编译环境）时直接跳过。
const { spawn } = require('child_process'), assert = require('assert'), crypto = require('crypto');
const CC = require('../chatcrypto');
if (!process.env.KT_CP) { console.log('SKIP（没有设置 KT_CP）'); process.exit(0); }
const kt = spawn('java', ['-cp', process.env.KT_CP, 'InteropKt'], { stdio: ['pipe', 'pipe', 'inherit'] });
let buf = '', waiters = [];
kt.stdout.on('data', d => { buf += d; let i; while ((i = buf.indexOf('\n')) >= 0) { const l = buf.slice(0, i); buf = buf.slice(i + 1); const w = waiters.shift(); if (w) w(JSON.parse(l)); } });
const ask = o => new Promise(r => { waiters.push(r); kt.stdin.write(JSON.stringify(o) + '\n'); });
let pass = 0, failed = false;
const ok = async (n, f) => { try { await f(); pass++; console.log('PASS ' + n); } catch (e) { failed = true; console.log('FAIL ' + n + '\n     ' + String(e.stack).split('\n').slice(0, 6).join('\n     ')); } };

(async () => {
  const sn = crypto.randomBytes(16).toString('hex'), cn = crypto.randomBytes(16).toString('hex'), pin = '1234567890:0987654321';
  for (const ktIsClient of [false, true]) {
    const label = ktIsClient ? '安卓作客户端、电脑作服务端' : '安卓作服务端、电脑作客户端';
    await ok(label + '：两端算出同样的密钥和安全码；双向帧互相解得开', async () => {
      const eph = CC.genEphemeral();
      const r = await ask({ cmd: 'derive', epk: eph.pub, isClient: ktIsClient, sn, cn, pin });
      assert.ok(!r.error, r.error);
      const js = CC.deriveSession({ eph, peerPub: r.epk, isClient: !ktIsClient, serverNonce: sn, clientNonce: cn, pin });
      assert.strictEqual(r.tx, js.rxKey.toString('hex')); assert.strictEqual(r.rx, js.txKey.toString('hex')); assert.strictEqual(r.sas, js.sas);
      const m = { t: 'm', id: 'aabbccdd11223344', ts: 1700000000000, x: '你好 😀 \\ " / 换行\n' };
      const f = await ask({ cmd: 'seal', obj: m });                           // 安卓 → 电脑
      const o1 = CC.open(js.rxKey, Buffer.from(f.frame, 'hex'), 0);
      assert.deepStrictEqual(o1.obj, m); assert.strictEqual(o1.ctr, 1);
      const back = await ask({ cmd: 'open', frame: CC.seal(js.txKey, 1, m).toString('hex'), last: 0 });      // 电脑 → 安卓
      assert.ok(!back.error, back.error); assert.strictEqual(back.obj.x, m.x);
      const replay = await ask({ cmd: 'open', frame: CC.seal(js.txKey, 1, m).toString('hex'), last: 1 }); assert.match(replay.error, /重复|过期/);
      const bad = CC.seal(js.txKey, 2, m); bad[bad.length - 1] ^= 1;
      assert.ok((await ask({ cmd: 'open', frame: bad.toString('hex'), last: 1 })).error, '篡改要被拒绝');
    });
  }
  await ok('非法公钥（不在曲线上）安卓端拒绝', async () => {
    const e = CC.genEphemeral();
    const r = await ask({ cmd: 'derive', epk: '04' + '00'.repeat(64), isClient: true, sn, cn, pin }); assert.ok(r.error, JSON.stringify(r));
    void e;
  });
  await ok('配对密钥不一致：两端密钥不同', async () => {
    const eph = CC.genEphemeral();
    const r = await ask({ cmd: 'derive', epk: eph.pub, isClient: false, sn, cn, pin });
    const js = CC.deriveSession({ eph, peerPub: r.epk, isClient: true, serverNonce: sn, clientNonce: cn, pin: pin + 'x' });
    assert.notStrictEqual(r.tx, js.rxKey.toString('hex'));
  });
  await ok('消息清理规则一致（限长 / 非法颜色 / 非法 ID / 未来时间戳 / 按字符截断含 emoji）', async () => {
    const now = Date.now();
    const cases = [
      { t: 'm', id: 'aabbccdd11223344', ts: 5, x: 'x'.repeat(9000) },
      { t: 'm', id: 'bad', x: 'a' }, { t: 'm', id: 'aabbccdd11223344', x: '  ' },
      { t: 's', id: 'aabbccdd11223344', e: '😂', c: '很长很长很长很长很长很长很长很长很长很长😀😀', bg: ['red', 'url(x)'] },
      { t: 's', id: 'aabbccdd11223344', e: '😂', c: 'ok', bg: ['#112233', '#AABBCC'] },
      { t: 'a', id: 'aabbccdd11223344' }, { t: 'zzz' }
    ];
    for (const c of cases) {
      const j = CC.sanitizeIncoming(c), k = await ask({ cmd: 'sanitize', obj: c, now });
      if (!j) { assert.strictEqual(k.null, true, JSON.stringify(c).slice(0, 60)); continue; }
      assert.ok(!k.null, JSON.stringify(c).slice(0, 60));
      assert.strictEqual(k.t, j.t); assert.strictEqual(k.x, j.x || ''); assert.strictEqual(k.e, j.e || ''); assert.strictEqual(k.c, j.c || ''); assert.strictEqual(k.bg.length ? k.bg.join() : '', (j.bg || []).join());
    }
    const k = await ask({ cmd: 'clip', s: 'a😀b😀c', n: 3 }); assert.strictEqual(k.r, CC.clip('a😀b😀c', 3));
  });
  console.log('\n' + (failed ? 'SOME FAILED' : 'ALL ' + pass + ' PASSED')); kt.stdin.end(); process.exit(failed ? 1 : 0);
})();
