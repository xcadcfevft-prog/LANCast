'use strict';
// node windows/test/gomoku.test.js —— 五子棋对战：信令清洗、邀请 / 接受 / 拒绝 / 结束状态机、两个 Hub 之间端到端转发对局消息
const assert = require('assert'), crypto = require('crypto');
const CC = require('../chatcrypto'), { createHub } = require('../chathub'), { createGame } = require('../gomoku');

let pass = 0, failed = false;
const ok = async (name, fn) => { try { await fn(); pass++; console.log('PASS ' + name); } catch (e) { failed = true; console.log('FAIL ' + name + '\n     ' + String(e.stack).split('\n').slice(0, 6).join('\n     ')); } };
const tick = () => new Promise(r => setTimeout(r, 5));

function makePair() {
  const mk = (id, peerId, pinOfPeer, myPin) => {
    const mem = {};
    return createHub({ myId: id, myName: id, myPin: () => myPin, store: { load: k => mem[k] || [], save: (k, v) => { mem[k] = v; }, loadUnread: () => ({}), saveUnread: () => {} },
      peers: () => [{ id: peerId, name: peerId, pin: pinOfPeer, online: true }], dial: async () => { throw new Error('no dial'); } });
  };
  const hubA = mk('A', 'B', 'pinB', 'pinA'), hubB = mk('B', 'A', 'pinA', 'pinB');
  const sess = () => ({ early: [], cb: null, peer: null, sendFrame(t, b) { const p = this.peer; const buf = Buffer.from(b); queueMicrotask(() => p.deliver(t, buf)); }, deliver(t, b) { if (this.cb) this.cb(t, 0, 0, b); else this.early.push([t, 0, 0, b]); }, attach(fn) { this.cb = fn; const e = this.early; this.early = []; for (const a of e) fn(...a); }, close() {}, onClose: null });
  const sA = sess(), sB = sess(); sA.peer = sB; sB.peer = sA;
  const sn = crypto.randomBytes(16).toString('hex'), cn = crypto.randomBytes(16).toString('hex');
  hubA.attach(sA, { peerId: 'B', isClient: true, serverNonce: sn, clientNonce: cn, pin: 'pinB:pinA', peerName: 'B' });
  hubB.attach(sB, { peerId: 'A', isClient: false, serverNonce: sn, clientNonce: cn, pin: 'pinB:pinA', peerName: 'A' });
  return { hubA, hubB };
}
function side(hub, myId, peerId) {
  const log = { opened: [], closed: 0, delivered: [] };
  const g = createGame({ hub, myId, peerName: () => peerId, open: i => log.opened.push(i), close: () => log.closed++, deliver: d => log.delivered.push(d) });
  hub.game = { onSignal: (id, m) => g.onSignal(id, m) };
  return { g, log };
}

(async () => {
  await ok('清洗：合法的 gm 信令 / 对局消息保留，非法的（越界坐标、未知类型、坏 gid、超长文字）丢弃', () => {
    const gid = 'abcdef0123456789';
    assert.deepStrictEqual(CC.sanitizeIncoming({ t: 'gm', op: 'invite', gid, side: 2, turn: 1, evil: 1 }), { t: 'gm', op: 'invite', gid, side: 2, turn: 1 });
    assert.strictEqual(CC.sanitizeIncoming({ t: 'gm', op: 'invite', gid: 'zz' }), null);
    assert.strictEqual(CC.sanitizeIncoming({ t: 'gm', op: 'hack', gid }), null);
    assert.deepStrictEqual(CC.sanitizeIncoming({ t: 'gm', op: 'g', gid, d: { k: 'mv', x: 3, y: 4, n: 0, z: 9 } }).d, { k: 'mv', x: 3, y: 4, n: 0 });
    for (const bad of [{ k: 'mv', x: 15, y: 0, n: 0 }, { k: 'mv', x: 1.5, y: 0, n: 0 }, { k: '_link', up: true }, { k: '_gone' }, { k: 'st', m: [[0, 0, 3]], g: 1, t: 1, w: 0, a: 0, b: 0 }, { k: 'sy', s: '<script>' }, { k: 'ch', x: '   ' }])
      assert.strictEqual(CC.sanitizeIncoming({ t: 'gm', op: 'g', gid, d: bad }), null, JSON.stringify(bad));
    assert.strictEqual(CC.sanitizeIncoming({ t: 'gm', op: 'g', gid, d: { k: 'ch', x: 'a'.repeat(500) } }).d.x.length, 200);
    const st = CC.sanitizeIncoming({ t: 'gm', op: 'g', gid, d: { k: 'st', g: 2, m: [[7, 7, 1], [7, 8, 2]], t: 1, o: 0, w: 0, a: 1, b: 0, u: 2 } }).d;
    assert.deepStrictEqual(st.m, [[7, 7, 1], [7, 8, 2]]); assert.strictEqual(st.u, 2);
  });

  await ok('邀请 → 接受：双方各开一个窗口，颜色互补，host 是邀请方，先手一致；对局消息双向转发', async () => {
    const { hubA, hubB } = makePair();
    const A = side(hubA, 'A', 'B'), B = side(hubB, 'B', 'A');
    await tick();
    assert.ok(A.g.invite('B')); await tick();
    assert.strictEqual(B.g.state.phase, 'invited');
    B.g.accept(); await tick();
    assert.strictEqual(A.log.opened.length, 1); assert.strictEqual(B.log.opened.length, 1);
    const a = A.log.opened[0], b = B.log.opened[0];
    assert.strictEqual(a.host, true); assert.strictEqual(b.host, false);
    assert.strictEqual(a.side + b.side, 3); assert.strictEqual(a.turn, b.turn); assert.strictEqual(a.gid, b.gid);
    assert.ok(A.g.fromWindow({ k: 'mv', x: 7, y: 7, n: 0 })); await tick();
    assert.deepStrictEqual(B.log.delivered, [{ k: 'mv', x: 7, y: 7, n: 0 }]);
    assert.ok(B.g.fromWindow({ k: 'ch', x: '你好' })); await tick();
    assert.deepStrictEqual(A.log.delivered, [{ k: 'ch', x: '你好' }]);
    A.g.tick(); B.g.tick();
  });

  await ok('拒绝 / 忙线 / 取消 / 对方离开', async () => {
    const { hubA, hubB } = makePair();
    const A = side(hubA, 'A', 'B'), B = side(hubB, 'B', 'A');
    await tick();
    A.g.invite('B'); await tick(); B.g.decline(); await tick();
    assert.strictEqual(A.g.state.phase, 'idle'); assert.match(A.g.state.reason, /拒绝/);
    A.g.invite('B'); await tick(); A.g.cancelInvite(); await tick();
    assert.strictEqual(B.g.state.phase, 'idle'); assert.match(B.g.state.reason, /取消/);
    A.g.invite('B'); await tick(); B.g.accept(); await tick();           // 开局
    // 对局中又有新邀请 → busy
    B.g.leave(); await tick();
    assert.strictEqual(B.g.state.phase, 'idle');
    assert.strictEqual(A.g.state.phase, 'ended'); assert.deepStrictEqual(A.log.delivered.at(-1), { k: '_gone' });
    A.g.windowClosed(); assert.strictEqual(A.g.state.phase, 'idle');
    // 非 idle 时收到邀请 → busy
    B.g.invite('A'); await tick(); assert.strictEqual(A.g.state.phase, 'invited');
    const C = createGame({ hub: hubA, myId: 'A' });                      // 同一 hub 上第二个状态机不参与；直接用 A 自己验证 busy
    hubB.game.onSignal('A', { t: 'gm', op: 'invite', gid: crypto.randomBytes(8).toString('hex'), side: 1, turn: 1 });
  });

  await ok('同时互相邀请：设备 ID 较小的一方（A）的邀请生效，B 改为接受', async () => {
    const { hubA, hubB } = makePair();
    const A = side(hubA, 'A', 'B'), B = side(hubB, 'B', 'A');
    await tick();
    A.g.invite('B'); B.g.invite('A'); await tick();
    assert.strictEqual(A.g.state.phase, 'inviting'); assert.strictEqual(B.g.state.phase, 'invited');
    B.g.accept(); await tick();
    assert.strictEqual(A.log.opened.length, 1); assert.strictEqual(B.log.opened.length, 1);
    assert.strictEqual(A.log.opened[0].host, true);
  });

  await ok('伪造：gid 不对的消息、没开局时的对局消息都被忽略', async () => {
    const { hubA, hubB } = makePair();
    const A = side(hubA, 'A', 'B'), B = side(hubB, 'B', 'A');
    await tick();
    A.g.onSignal('B', { t: 'gm', op: 'g', gid: 'aaaaaaaaaaaaaaaa', d: { k: 'ch', x: 'x' } });
    assert.strictEqual(A.log.delivered.length, 0);
    assert.strictEqual(A.g.fromWindow({ k: 'mv', x: 1, y: 1, n: 0 }), false);
    A.g.invite('B'); await tick(); B.g.accept(); await tick();
    A.g.onSignal('B', { t: 'gm', op: 'g', gid: 'aaaaaaaaaaaaaaaa', d: { k: 'ch', x: 'x' } });
    A.g.onSignal('B', { t: 'gm', op: 'end', gid: 'aaaaaaaaaaaaaaaa' });
    assert.strictEqual(A.log.delivered.length, 0); assert.strictEqual(A.g.state.phase, 'playing');
  });

  console.log(`\n${pass} passed${failed ? ', 有失败' : ''}`); process.exit(failed ? 1 : 0);
})();
