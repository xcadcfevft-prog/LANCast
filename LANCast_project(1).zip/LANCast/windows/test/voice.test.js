'use strict';
// node windows/test/voice.test.js —— 无损语音通话：帧格式、加密往返、通话状态机、两个 Hub 之间端到端「逐采样点一致」
const assert = require('assert'), crypto = require('crypto');
const CC = require('../chatcrypto'), { createHub } = require('../chathub'), V = require('../voice');

let pass = 0, failed = false;
const ok = async (name, fn) => { try { await fn(); pass++; console.log('PASS ' + name); } catch (e) { failed = true; console.log('FAIL ' + name + '\n     ' + String(e.stack).split('\n').slice(0, 6).join('\n     ')); } };
const tick = () => new Promise(r => setImmediate(r));

function randFrame(n = V.FRAME) { const a = new Int16Array(n); const b = crypto.randomBytes(n * 2); for (let i = 0; i < n; i++) a[i] = b.readInt16LE(i * 2); return a; }

/* 两个 Hub，用内存里的假会话连起来（和真 Session 一样：先发密钥帧、attach 之前到的帧先缓存） */
function makePair() {
  const mk = (id, peerId, pinOfPeer, myPin) => {
    const mem = {};
    return createHub({ myId: id, myName: id, myPin: () => myPin, store: { load: k => mem[k] || [], save: (k, v) => { mem[k] = v; }, loadUnread: () => ({}), saveUnread: () => {} },
      peers: () => [{ id: peerId, name: peerId, pin: pinOfPeer, online: true }], dial: async () => { throw new Error('no dial'); } });
  };
  const hubA = mk('A', 'B', 'pinB', 'pinA'), hubB = mk('B', 'A', 'pinA', 'pinB');
  const sess = () => ({ early: [], cb: null, peer: null, sendFrame(t, b) { const p = this.peer; const buf = Buffer.from(b); queueMicrotask(() => p.deliver(t, buf)); }, deliver(t, b) { if (this.cb) this.cb(t, 0, 0, b); else this.early.push([t, 0, 0, b]); }, attach(fn) { this.cb = fn; const e = this.early; this.early = []; for (const a of e) fn(...a); }, close() {}, onClose: null });
  const sA = sess(), sB = sess(); sA.peer = sB; sB.peer = sA;
  const sn = crypto.randomBytes(16).toString('hex'), cn = crypto.randomBytes(16).toString('hex');
  hubA.attach(sA, { peerId: 'B', isClient: true, serverNonce: sn, clientNonce: cn, pin: 'pinB:pinA', peerName: 'B' });
  hubB.attach(sB, { peerId: 'A', isClient: false, serverNonce: sn, clientNonce: cn, pin: 'pinB:pinA', peerName: 'A' });
  return { hubA, hubB, sA, sB };
}
function fakeEngine(log) { const e = { played: [], started: 0, stopped: 0, onFrame: null }; return { e, make: o => { e.onFrame = o.onFrame; return { start: async () => { e.started++; }, stop: () => { e.stopped++; }, play: s => e.played.push(Int16Array.from(s)) }; } }; }

(async () => {
  await ok('帧格式：打包再解包，int16 采样点逐个相同（含 -32768 / 32767 极值）；头部字段正确', async () => {
    const s = randFrame(); s[0] = -32768; s[1] = 32767; s[2] = 0;
    const b = V.pack(7, s); assert.strictEqual(b.length, 12 + 960);
    assert.strictEqual(b[0], 1); assert.strictEqual(b[1], 1); assert.strictEqual(b[2], 16); assert.strictEqual(b.readUInt32BE(4), 48000); assert.strictEqual(b.readUInt32BE(8), 7);
    const r = V.unpack(b); assert.strictEqual(r.seq, 7); assert.deepStrictEqual(Array.from(r.samples), Array.from(s));
  });
  await ok('帧格式：版本 / 声道 / 位深 / 采样率不对、长度为奇数、太短都拒绝', async () => {
    const good = V.pack(1, randFrame());
    for (const [i, v] of [[0, 2], [1, 2], [2, 24], [4, 1]]) { const b = Buffer.from(good); b[i] = v; assert.strictEqual(V.unpack(b), null, '改第 ' + i + ' 字节'); }
    assert.strictEqual(V.unpack(good.subarray(0, good.length - 1)), null); assert.strictEqual(V.unpack(good.subarray(0, 12)), null); assert.strictEqual(V.unpack(null), null);
  });
  await ok('浮点 → int16：-1..1 映射到 -32768..32767，越界截断', async () => {
    assert.strictEqual(V.f2i(-1), -32768); assert.strictEqual(V.f2i(1), 32767); assert.strictEqual(V.f2i(0), 0); assert.strictEqual(V.f2i(5), 32767); assert.strictEqual(V.f2i(-5), -32768);
    for (const v of [-32768, -12345, -1, 0, 1, 12345, 32767]) assert.strictEqual(V.f2i(v < 0 ? v / 32768 : v / 32767), v, '往返 ' + v);
  });
  await ok('二进制加密：往返一致；篡改 / 重放 / 反射都被拒；与 JSON 消息共用计数器', async () => {
    const sn = 'a'.repeat(32), cn = 'b'.repeat(32), a = CC.genEphemeral(), b = CC.genEphemeral();
    const ka = CC.deriveSession({ eph: a, peerPub: b.pub, isClient: true, serverNonce: sn, clientNonce: cn, pin: 'x' }), kb = CC.deriveSession({ eph: b, peerPub: a.pub, isClient: false, serverNonce: sn, clientNonce: cn, pin: 'x' });
    const pcm = V.pack(1, randFrame()), f = CC.sealBin(ka.txKey, 2, pcm);
    assert.ok(!f.includes(pcm.subarray(20, 60)), '密文里不能出现明文');
    assert.ok(CC.openBin(kb.rxKey, f, 1).buf.equals(pcm));
    assert.throws(() => CC.openBin(kb.rxKey, f, 2), /重复或过期/);
    for (const i of [0, 9, 30, f.length - 1]) { const bad = Buffer.from(f); bad[i] ^= 1; assert.throws(() => CC.openBin(kb.rxKey, bad, 0)); }
    assert.throws(() => CC.openBin(ka.rxKey, f, 0), undefined, '反射');
    const j = CC.seal(ka.txKey, 1, { t: 'a', id: '0011223344556677' }); assert.strictEqual(CC.open(kb.rxKey, j, 0).ctr, 1);
  });
  await ok('信令整理：只认 invite/accept/reject/busy/end，其余丢弃；采样参数限整数', async () => {
    assert.deepStrictEqual(CC.sanitizeIncoming({ t: 'vc', op: 'invite', rate: 48000, ch: 1, bits: 16, x: 'evil' }), { t: 'vc', op: 'invite', rate: 48000, ch: 1, bits: 16 });
    assert.strictEqual(CC.sanitizeIncoming({ t: 'vc', op: 'hack' }), null);
    assert.strictEqual(CC.sanitizeIncoming({ t: 'vc' }), null);
  });

  await ok('端到端：A 呼叫 B，B 接听，A 说 3 秒随机 PCM，B 收到的每个采样点与发出的逐位一致（经过真实的加密 / 解密）', async () => {
    const { hubA, hubB } = makePair(); await tick(); await tick();
    assert.ok(hubA.isConnected('B') && hubB.isConnected('A'));
    const eA = fakeEngine(), eB = fakeEngine(); let phB = [];
    const callA = V.createCall({ hub: hubA, makeEngine: eA.make }), callB = V.createCall({ hub: hubB, makeEngine: eB.make, onState: s => phB.push(s.phase) });
    hubA.voice = { onSignal: (i, m) => callA.onSignal(i, m), onAudio: (i, b) => callA.onAudio(i, b) };
    hubB.voice = { onSignal: (i, m) => callB.onSignal(i, m), onAudio: (i, b) => callB.onAudio(i, b) };
    assert.ok(callA.start('B')); await tick(); await tick();
    assert.strictEqual(callB.state.phase, 'ringing'); assert.strictEqual(callA.state.phase, 'calling');
    callB.answer(); await tick(); await tick(); await tick();
    assert.strictEqual(callA.state.phase, 'active'); assert.strictEqual(callB.state.phase, 'active');
    assert.strictEqual(eA.e.started, 1); assert.strictEqual(eB.e.started, 1);
    const sent = []; for (let i = 0; i < 300; i++) { const f = randFrame(); sent.push(f); eA.e.onFrame(Int16Array.from(f)); }     // 300 × 10 ms = 3 秒
    await tick(); await tick(); await tick();
    assert.strictEqual(eB.e.played.length, 300, '一帧都不能少');
    for (let i = 0; i < 300; i++) assert.deepStrictEqual(Array.from(eB.e.played[i]), Array.from(sent[i]), '第 ' + i + ' 帧');
    // 反方向也通
    const back = randFrame(); eB.e.onFrame(Int16Array.from(back)); await tick(); await tick();
    assert.deepStrictEqual(Array.from(eA.e.played[0]), Array.from(back));
    // 静音：发出去的是全零，流不断
    callA.mute(true); eA.e.onFrame(randFrame()); await tick(); await tick();
    assert.ok(eB.e.played[300].every(v => v === 0), '静音时对方收到全零');
    callA.mute(false);
    // 挂断：两边都回到 idle、引擎都停了
    callB.hangup(); await tick(); await tick();
    assert.strictEqual(callA.state.phase, 'idle'); assert.strictEqual(callB.state.phase, 'idle'); assert.strictEqual(eA.e.stopped, 1); assert.strictEqual(eB.e.stopped, 1);
    assert.strictEqual(callA.state.reason, '对方已挂断');
    eA.e.onFrame(randFrame()); await tick();                  // 挂断后残留的帧不会再发出去
    assert.strictEqual(eB.e.played.length, 301);
  });
  await ok('拒绝 / 忙线 / 取消 / 同时互相呼叫', async () => {
    const { hubA, hubB } = makePair(); await tick(); await tick();
    const eA = fakeEngine(), eB = fakeEngine();
    const callA = V.createCall({ hub: hubA, makeEngine: eA.make }), callB = V.createCall({ hub: hubB, makeEngine: eB.make });
    hubA.voice = { onSignal: (i, m) => callA.onSignal(i, m), onAudio: (i, b) => callA.onAudio(i, b) };
    hubB.voice = { onSignal: (i, m) => callB.onSignal(i, m), onAudio: (i, b) => callB.onAudio(i, b) };
    callA.start('B'); await tick(); await tick(); callB.decline(); await tick(); await tick();
    assert.strictEqual(callA.state.phase, 'idle'); assert.strictEqual(callA.state.reason, '对方拒绝了通话'); assert.strictEqual(callB.state.phase, 'idle');
    callA.start('B'); await tick(); await tick(); callA.hangup(); await tick(); await tick();            // 取消
    assert.strictEqual(callB.state.phase, 'idle'); assert.strictEqual(callB.state.reason, '对方取消了呼叫');
    callA.start('B'); callB.start('A'); for (let i = 0; i < 6; i++) await tick();                          // 同时呼叫
    assert.strictEqual(callA.state.phase, 'active'); assert.strictEqual(callB.state.phase, 'active');
    callA.hangup(); await tick(); await tick();
    // 忙线：B 在通话中，来自别的设备的邀请回 busy（这里用同一个 Hub 模拟：B 正在 ringing 时再来一个 invite 不会换人）
    const sent = []; const fakeHub = { sendSignal: (id, o) => { sent.push([id, o.op]); return true; }, sendVoice: () => true, isConnected: () => true };
    const c = V.createCall({ hub: fakeHub, makeEngine: fakeEngine().make });
    c.onSignal('X', { op: 'invite' }); c.onSignal('Y', { op: 'invite' });
    assert.strictEqual(c.state.peerId, 'X'); assert.deepStrictEqual(sent, [['Y', 'busy']]);
    c.onSignal('Y', { op: 'end' }); assert.strictEqual(c.state.phase, 'ringing', '不是当前对象的信令不影响当前通话');
  });
  await ok('异常：麦克风打不开 → 通知对方并回到 idle；加密连接断了 6 秒 → 结束通话；来电 40 秒没人接 → 未接来电', async () => {
    const sent = []; let connected = true;
    const hub = { sendSignal: (id, o) => { sent.push(o.op); return true; }, sendVoice: () => true, isConnected: () => connected };
    const c1 = V.createCall({ hub, makeEngine: () => ({ start: async () => { throw new Error('拒绝访问'); }, stop() {}, play() {} }) });
    c1.onSignal('P', { op: 'invite' }); c1.answer(); await tick(); await tick();
    assert.strictEqual(c1.state.phase, 'idle'); assert.ok(c1.state.reason.includes('拒绝访问')); assert.deepStrictEqual(sent, ['accept', 'end']);
    const c2 = V.createCall({ hub, makeEngine: fakeEngine().make });
    c2.onSignal('P', { op: 'invite' }); c2.answer(); connected = false;
    for (let i = 0; i < 5; i++) c2.tick(); assert.strictEqual(c2.state.phase, 'active'); c2.tick(); assert.strictEqual(c2.state.phase, 'idle'); assert.strictEqual(c2.state.reason, '连接已断开');
    let fire = null; const c3 = V.createCall({ hub, makeEngine: fakeEngine().make, setT: f => { fire = f; return 1; }, clearT: () => {} });
    c3.onSignal('P', { op: 'invite' }); assert.strictEqual(c3.state.phase, 'ringing'); fire(); assert.strictEqual(c3.state.phase, 'idle'); assert.strictEqual(c3.state.reason, '未接来电');
  });

  console.log(failed ? '\nFAILED' : '\n全部通过：' + pass + ' 项');
  process.exit(failed ? 1 : 0);
})();
