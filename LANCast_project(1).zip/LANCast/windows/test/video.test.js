'use strict';
// node windows/test/video.test.js —— 视频通话：帧格式（含与安卓端帧布局互通）、大帧加密往返、信令 vid 标志、
// 两个 Hub 之间端到端「JPEG 字节逐位一致」、画质 / 摄像头控制、相机打不开时只收不发
const assert = require('assert'), crypto = require('crypto');
const CC = require('../chatcrypto'), { createHub } = require('../chathub'), V = require('../voice');

let pass = 0, failed = false;
const ok = async (name, fn) => { try { await fn(); pass++; console.log('PASS ' + name); } catch (e) { failed = true; console.log('FAIL ' + name + '\n     ' + String(e.stack).split('\n').slice(0, 6).join('\n     ')); } };
const tick = () => new Promise(r => setImmediate(r));
const ticks = async n => { for (let i = 0; i < n; i++) await tick(); };

const jpegOf = n => Buffer.concat([Buffer.from([0xFF, 0xD8, 0xFF, 0xE0]), crypto.randomBytes(n - 6), Buffer.from([0xFF, 0xD9])]);   // 假 JPEG：有 SOI 头即可

function makePair() {
  const mk = (id, peerId, pinOfPeer, myPin) => {
    const mem = {};
    return createHub({ myId: id, myName: id, myPin: () => myPin, store: { load: k => mem[k] || [], save: (k, v) => { mem[k] = v; }, loadUnread: () => ({}), saveUnread: () => {} },
      peers: () => [{ id: peerId, name: peerId, pin: pinOfPeer, online: true }], dial: async () => { throw new Error('no dial'); } });
  };
  const hubA = mk('A', 'B', 'pinB', 'pinA'), hubB = mk('B', 'A', 'pinA', 'pinB');
  const sess = () => ({ early: [], cb: null, peer: null, sendFrame(t, b) { const p = this.peer; const buf = Buffer.from(b); queueMicrotask(() => p.deliver(t, buf)); }, deliver(t, b) { if (this.cb) this.cb(t, 0, 0, b); else this.early.push([t, 0, 0, b]); }, attach(fn) { this.cb = fn; const e = this.early; this.early = []; for (const a of e) fn(...a); }, close() {}, onClose: null });
  const sA = sess(), sB = sess(); sA.peer = sB; sB.peer = sA;
  const sn = crypto.randomBytes(16).toString('hex'), cn = crypto.randomBytes(16).toString('hex');
  hubA.attach(sA, { peerId: 'B', isClient: true, serverNonce: sn, clientNonce: cn, pin: 'pinB:pinA', peerName: 'B' });
  hubB.attach(sB, { peerId: 'A', isClient: false, serverNonce: sn, clientNonce: cn, pin: 'pinB:pinA', peerName: 'A' });
  return { hubA, hubB };
}
function fakeAudio() { const e = { played: [] }; return { e, make: () => ({ start: async () => {}, stop: () => {}, play: s => e.played.push(Int16Array.from(s)) }) }; }
function fakeVideo(opt = {}) {
  const e = { started: 0, stopped: 0, retiers: 0, enabled: true, emit: null, tierAtStart: null };
  return { e, make: o => { e.emit = o.onFrame; e.tier = o.tier; return { start: async () => { e.started++; e.tierAtStart = o.tier(); if (opt.fail) throw new Error('相机被占用'); }, stop: () => { e.stopped++; }, retier: () => { e.retiers++; }, setEnabled: v => { e.enabled = v; } }; } };
}

(async () => {
  await ok('帧格式：打包再解包，字段与 JPEG 字节逐位一致；旋转按 ×90° 存取', async () => {
    const j = jpegOf(5000), b = V.packVideo(7, 3, 90, 1920, 1080, j);
    assert.strictEqual(b.length, 12 + 5000);
    assert.deepStrictEqual([b[0], b[1], b[2], b[3]], [1, 3, 1, 0]);
    const f = V.unpackVideo(b); assert.strictEqual(f.seq, 7); assert.strictEqual(f.tier, 3); assert.strictEqual(f.rot, 90); assert.strictEqual(f.w, 1920); assert.strictEqual(f.h, 1080);
    assert.ok(f.jpeg.equals(j));
    for (const r of [0, 90, 180, 270]) assert.strictEqual(V.unpackVideo(V.packVideo(1, 0, r, 640, 360, j)).rot, r);
  });
  await ok('与安卓端帧布局互通：按 VideoCall.kt 的字节布局手工拼一帧，Windows 能解出来', async () => {
    const j = jpegOf(300), b = Buffer.alloc(12 + j.length);
    b[0] = 1; b[1] = 2; b[2] = 3;                                         // ver, 档位=省流畅, 旋转 3×90°
    b[4] = 0x02; b[5] = 0x80; b[6] = 0x01; b[7] = 0x68;                   // 宽 640，高 360（u16 大端）
    b[8] = 0; b[9] = 0; b[10] = 1; b[11] = 0;                             // 序号 256
    j.copy(b, 12);
    const f = V.unpackVideo(b); assert.deepStrictEqual([f.tier, f.rot, f.w, f.h, f.seq], [2, 270, 640, 360, 256]); assert.ok(f.jpeg.equals(j));
  });
  await ok('帧格式：版本不对 / 不是 JPEG / 宽高为 0 或过大 / 太短 / 超长都拒绝', async () => {
    const good = V.packVideo(1, 0, 0, 1280, 720, jpegOf(100));
    const mut = (i, v) => { const b = Buffer.from(good); b[i] = v; return b; };
    assert.strictEqual(V.unpackVideo(mut(0, 2)), null); assert.strictEqual(V.unpackVideo(mut(12, 0x00)), null);
    assert.strictEqual(V.unpackVideo((() => { const b = Buffer.from(good); b.writeUInt16BE(0, 4); return b; })()), null);
    assert.strictEqual(V.unpackVideo((() => { const b = Buffer.from(good); b.writeUInt16BE(9000, 6); return b; })()), null);
    assert.strictEqual(V.unpackVideo(good.subarray(0, 14)), null); assert.strictEqual(V.unpackVideo(null), null);
    assert.strictEqual(V.unpackVideo(Buffer.concat([good.subarray(0, 12), jpegOf(V.MAX_JPEG + 10)])), null);
  });
  await ok('画质四档：名字 / 参数；档位越界回退到第 0 档', async () => {
    assert.deepStrictEqual(V.TIERS.map(t => t.name), ['视觉无损（高码率）', '均衡', '省流畅', '极致无损 Beta']);
    assert.deepStrictEqual(V.TIERS.map(t => [t.w, t.h, t.q, t.fps]), [[1280, 720, 95, 30], [960, 540, 80, 24], [640, 360, 55, 20], [0, 0, 100, 60]]);
    assert.strictEqual(V.tierOf(9), V.TIERS[0]); assert.strictEqual(V.tierOf(-1), V.TIERS[0]); assert.strictEqual(V.tierOf('x'), V.TIERS[0]);
  });
  await ok('视频帧加密：300 KB 往返一致；默认上限（64 KB）仍拒绝大帧；篡改 / 重放被拒；与 JSON、语音帧共用计数器', async () => {
    const sn = 'a'.repeat(32), cn = 'b'.repeat(32), a = CC.genEphemeral(), b = CC.genEphemeral();
    const ka = CC.deriveSession({ eph: a, peerPub: b.pub, isClient: true, serverNonce: sn, clientNonce: cn, pin: 'x' }), kb = CC.deriveSession({ eph: b, peerPub: a.pub, isClient: false, serverNonce: sn, clientNonce: cn, pin: 'x' });
    const fr = V.packVideo(1, 0, 0, 1280, 720, jpegOf(300 * 1024)), f = CC.sealBin(ka.txKey, 2, fr);
    assert.ok(CC.openBin(kb.rxKey, f, 1, CC.MAX_VIDEO_FRAME).buf.equals(fr));
    assert.throws(() => CC.openBin(kb.rxKey, f, 1), /消息长度不对/);
    assert.throws(() => CC.openBin(kb.rxKey, f, 2, CC.MAX_VIDEO_FRAME), /重复或过期/);
    const bad = Buffer.from(f); bad[100] ^= 1; assert.throws(() => CC.openBin(kb.rxKey, bad, 0, CC.MAX_VIDEO_FRAME));
    assert.strictEqual(CC.T_CHAT_VIDEO, 51);
  });
  await ok('信令：vid 只认布尔 true；没带 vid 时结果里没有这个字段（和旧版完全一样）', async () => {
    assert.deepStrictEqual(CC.sanitizeIncoming({ t: 'vc', op: 'invite', vid: true }), { t: 'vc', op: 'invite', rate: 48000, ch: 1, bits: 16, vid: true });
    assert.strictEqual('vid' in CC.sanitizeIncoming({ t: 'vc', op: 'invite', vid: 'yes' }), false);
    assert.strictEqual('vid' in CC.sanitizeIncoming({ t: 'vc', op: 'invite' }), false);
  });
  await ok('端到端：A 发起视频通话（选「均衡」），B 接听；A 的每一帧 JPEG 经加密后在 B 端逐位一致，音频同时正常', async () => {
    const { hubA, hubB } = makePair(); await ticks(4);
    const aa = fakeAudio(), ab = fakeAudio(), va = fakeVideo(), vb = fakeVideo(), got = [];
    const callA = V.createCall({ hub: hubA, makeEngine: aa.make, makeVideo: va.make, onVideo: (id, f) => got.push(['A', f]) });
    const callB = V.createCall({ hub: hubB, makeEngine: ab.make, makeVideo: vb.make, onVideo: (id, f) => got.push(['B', f]) });
    hubA.voice = { onSignal: (id, m) => callA.onSignal(id, m), onAudio: (id, b) => callA.onAudio(id, b), onVideo: (id, b) => callA.onVideo(id, b) };
    hubB.voice = { onSignal: (id, m) => callB.onSignal(id, m), onAudio: (id, b) => callB.onAudio(id, b), onVideo: (id, b) => callB.onVideo(id, b) };
    assert.ok(callA.start('B', { video: true, tier: 1 })); await ticks(4);
    assert.strictEqual(callB.state.phase, 'ringing'); assert.strictEqual(callB.state.video, true, '来电带视频标志');
    callB.answer(); await ticks(6);
    assert.strictEqual(callA.state.phase, 'active'); assert.strictEqual(callB.state.phase, 'active');
    assert.strictEqual(va.e.started, 1); assert.strictEqual(vb.e.started, 1); assert.strictEqual(va.e.tierAtStart, 1, '摄像头按选的档位启动');
    const sent = []; for (let i = 0; i < 5; i++) { const j = jpegOf(20000 + i * 50000); sent.push(j); va.e.emit(V.packVideo(i, 1, 0, 960, 540, j)); }
    sent.push(jpegOf(250000)); vb.e.emit(V.packVideo(9, 0, 90, 1280, 720, sent[5]));     // B 也发（双向）
    await ticks(8);
    const atB = got.filter(g => g[0] === 'B').map(g => g[1]), atA = got.filter(g => g[0] === 'A').map(g => g[1]);
    assert.strictEqual(atB.length, 5); assert.strictEqual(atA.length, 1);
    atB.forEach((f, i) => { assert.ok(f.jpeg.equals(sent[i]), '第 ' + i + ' 帧逐位一致'); assert.strictEqual(f.tier, 1); });
    assert.ok(atA[0].jpeg.equals(sent[5])); assert.strictEqual(atA[0].rot, 90);
    // 视频帧和音频帧共用计数器，互不影响
    const pcm = new Int16Array(480); for (let i = 0; i < 480; i++) pcm[i] = (i * 131) % 30000 - 15000;
    hubA.sendVoice('B', V.pack(1, pcm)); await ticks(4);
    assert.strictEqual(ab.e.played.length, 1); assert.deepStrictEqual(Array.from(ab.e.played[0]), Array.from(pcm));
    callA.hangup(); await ticks(4); assert.strictEqual(va.e.stopped, 1); assert.strictEqual(vb.e.stopped, 1); assert.strictEqual(callB.state.video, false);
  });
  await ok('通话中改画质 → 摄像头引擎重开；关摄像头 → 引擎被置为不发帧；收到的视频帧在没有 vid 的通话里被忽略', async () => {
    const { hubA, hubB } = makePair(); await ticks(4);
    const va = fakeVideo(), vb = fakeVideo(), seenB = [];
    const callA = V.createCall({ hub: hubA, makeEngine: fakeAudio().make, makeVideo: va.make });
    const callB = V.createCall({ hub: hubB, makeEngine: fakeAudio().make, makeVideo: vb.make, onVideo: (id, f) => seenB.push(f) });
    hubA.voice = { onSignal: (id, m) => callA.onSignal(id, m), onAudio: (id, b) => callA.onAudio(id, b), onVideo: (id, b) => callA.onVideo(id, b) };
    hubB.voice = { onSignal: (id, m) => callB.onSignal(id, m), onAudio: (id, b) => callB.onAudio(id, b), onVideo: (id, b) => callB.onVideo(id, b) };
    callA.start('B', { video: true, tier: 0 }); await ticks(4); callB.answer(); await ticks(6);
    callA.setTier(3); assert.strictEqual(callA.state.tier, 3); assert.strictEqual(va.e.retiers, 1); assert.strictEqual(va.e.tier(), 3);
    callA.setTier(99); assert.strictEqual(callA.state.tier, 3, '越界档位被限制在最高档');
    callA.camera(false); assert.strictEqual(va.e.enabled, false); assert.strictEqual(callA.state.camOn, false);
    callA.camera(true); assert.strictEqual(va.e.enabled, true);
    callA.camera(false); va.e.emit(V.packVideo(1, 0, 0, 640, 360, jpegOf(500))); await ticks(4);
    assert.strictEqual(seenB.length, 0, '摄像头关着时 onFrame 不会把帧发出去');
    callA.hangup(); await ticks(4);
    // 纯语音通话：对方发来的视频帧丢弃
    callA.start('B'); await ticks(4); callB.answer(); await ticks(6);
    assert.strictEqual(callB.state.video, false);
    hubA.sendVideo('B', V.packVideo(1, 0, 0, 640, 360, jpegOf(500))); await ticks(4);
    assert.strictEqual(seenB.length, 0); assert.strictEqual(vb.e.started, 1, '语音通话不开摄像头（只有第一通视频通话开过）');
  });
  await ok('相机打不开：通话照常（音频 active），只是 camOk=false；对方的画面照样能收', async () => {
    const { hubA, hubB } = makePair(); await ticks(4);
    const va = fakeVideo({ fail: true }), vb = fakeVideo(), seenA = [];
    const callA = V.createCall({ hub: hubA, makeEngine: fakeAudio().make, makeVideo: va.make, onVideo: (id, f) => seenA.push(f) });
    const callB = V.createCall({ hub: hubB, makeEngine: fakeAudio().make, makeVideo: vb.make });
    hubA.voice = { onSignal: (id, m) => callA.onSignal(id, m), onAudio: (id, b) => callA.onAudio(id, b), onVideo: (id, b) => callA.onVideo(id, b) };
    hubB.voice = { onSignal: (id, m) => callB.onSignal(id, m), onAudio: (id, b) => callB.onAudio(id, b), onVideo: (id, b) => callB.onVideo(id, b) };
    callA.start('B', { video: true }); await ticks(4); callB.answer(); await ticks(8);
    assert.strictEqual(callA.state.phase, 'active'); assert.strictEqual(callA.state.camOk, false); assert.strictEqual(va.e.stopped, 1);
    vb.e.emit(V.packVideo(1, 0, 0, 640, 360, jpegOf(900))); await ticks(4); assert.strictEqual(seenA.length, 1);
  });
  await ok('没有视频引擎的一方（如旧版）收到视频来电：当作语音接通，不崩', async () => {
    const { hubA, hubB } = makePair(); await ticks(4);
    const va = fakeVideo();
    const callA = V.createCall({ hub: hubA, makeEngine: fakeAudio().make, makeVideo: va.make });
    const callB = V.createCall({ hub: hubB, makeEngine: fakeAudio().make });                 // 没传 makeVideo
    hubA.voice = { onSignal: (id, m) => callA.onSignal(id, m), onAudio: (id, b) => callA.onAudio(id, b), onVideo: (id, b) => callA.onVideo(id, b) };
    hubB.voice = { onSignal: (id, m) => callB.onSignal(id, m), onAudio: (id, b) => callB.onAudio(id, b), onVideo: (id, b) => callB.onVideo(id, b) };
    callA.start('B', { video: true }); await ticks(4); callB.answer(); await ticks(6);
    assert.strictEqual(callA.state.phase, 'active'); assert.strictEqual(callB.state.phase, 'active');
    va.e.emit(V.packVideo(1, 0, 0, 640, 360, jpegOf(900))); await ticks(4);
  });

  console.log(failed ? '\n有失败' : '\n全部通过：' + pass + ' 项');
  process.exit(failed ? 1 : 0);
})();
