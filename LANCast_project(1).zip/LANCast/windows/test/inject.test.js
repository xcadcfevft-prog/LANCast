'use strict';
// node windows/test/inject.test.js      （无依赖，Linux / macOS / Windows 都能跑；不真正注入，只验证指令 → 事件的翻译与保护逻辑）
const assert = require('assert');
const { createPlanner, createInjector, MF, KF } = require('../inject');

let pass = 0;
const queue = [];
const ok = (name, fn) => queue.push([name, fn]);          // 顺序执行，支持 async 用例

ok('坐标 0..1 → SendInput 绝对坐标 0..65535，越界夹住', () => {
  const p = createPlanner();
  const [a, b, c] = p.plan({ t: 'pm', p: [[0, 0], [0.5, 0.25], [2, -1]] });
  assert.deepStrictEqual([a.x, a.y], [0, 0]);
  assert.deepStrictEqual([b.x, b.y], [32768, 16384]);
  assert.deepStrictEqual([c.x, c.y], [65535, 0]);
  assert.strictEqual(a.flags, MF.MOVE | MF.ABS);
});
ok('非法坐标（NaN / 字符串）整点丢弃，不会把光标甩到 (0,0)', () => {
  const p = createPlanner();
  assert.strictEqual(p.plan({ t: 'pm', p: [[NaN, 1], ['a', 'b'], [0.5]] }).length, 0);
  assert.strictEqual(p.plan({ t: 'pm', x: 'x', y: 1 }).length, 0);
  assert.strictEqual(p.plan(null).length, 0);
});
ok('左键按下 / 抬起：带位置时一条事件里同时移动', () => {
  const p = createPlanner();
  const [d] = p.plan({ t: 'pd', b: 'l', x: 0.5, y: 0.5 });
  assert.strictEqual(d.flags, MF.LDOWN | MF.MOVE | MF.ABS);
  assert.ok(p.hasHeld());
  const [u] = p.plan({ t: 'pu', b: 'l' });
  assert.strictEqual(u.flags, MF.LUP);
  assert.ok(!p.hasHeld());
});
ok('右键 / 中键', () => {
  const p = createPlanner();
  assert.strictEqual(p.plan({ t: 'pd', b: 'r' })[0].flags, MF.RDOWN);
  assert.strictEqual(p.plan({ t: 'pu', b: 'r' })[0].flags, MF.RUP);
  assert.strictEqual(p.plan({ t: 'pd', b: 'm' })[0].flags, MF.MDOWN);
  assert.strictEqual(p.plan({ t: 'pd', b: 'x' }).length, 0);
});
ok('滚轮：dy>0 向下滚 = 负的 WHEEL；dx>0 向右 = 正的 HWHEEL；1 格 = 120', () => {
  const p = createPlanner();
  assert.deepStrictEqual(p.plan({ t: 'w', dy: 1 }).map(o => [o.flags, o.data]), [[MF.WHEEL, -120]]);
  assert.deepStrictEqual(p.plan({ t: 'w', dy: -2 }).map(o => [o.flags, o.data]), [[MF.WHEEL, 240]]);
  assert.deepStrictEqual(p.plan({ t: 'w', dx: 1 }).map(o => [o.flags, o.data]), [[MF.HWHEEL, 120]]);
});
ok('滚轮：触控板的小数滚动按 1/120 格粒度累加，总量不丢不多（10 × 0.3 格 = 3 格）', () => {
  const p = createPlanner();
  let total = 0;
  for (let i = 0; i < 100; i++) for (const o of p.plan({ t: 'w', dy: 0.03 })) { assert.strictEqual(o.flags, MF.WHEEL); total += o.data; }
  assert.ok(Math.abs(total + 360) <= 1, '总量 ' + total);
  const q = createPlanner();
  assert.strictEqual(q.plan({ t: 'w', dy: 0.004 }).length, 0);     // 不足 1/120 格：先攒着，不发
});
ok('滚轮：带位置先移动光标；单次 |格数| 夹在 ±20', () => {
  const p = createPlanner();
  const ops = p.plan({ t: 'w', x: 0.1, y: 0.2, dy: 999 });
  assert.strictEqual(ops[0].flags, MF.MOVE | MF.ABS);
  assert.strictEqual(ops[1].data, -2400);
});
ok('组合键 ctrl+shift+esc：修饰键先按后松，顺序正确', () => {
  const p = createPlanner();
  const ops = p.plan({ t: 'key', k: 'Ctrl+Shift+Esc' }).map(o => (o.flags & KF.UP ? '-' : '+') + o.vk.toString(16));
  assert.deepStrictEqual(ops, ['+11', '+10', '+1b', '-1b', '-10', '-11']);
  assert.ok(!p.hasHeld());
});
ok('组合键 alt+tab / win+d / 单独 win / f5', () => {
  const p = createPlanner();
  assert.strictEqual(p.plan({ t: 'key', k: 'alt+tab' }).length, 4);
  assert.strictEqual(p.plan({ t: 'key', k: 'win+d' })[2].vk, 0x44);
  assert.deepStrictEqual(p.plan({ t: 'key', k: 'win' }).map(o => o.vk), [0x5B, 0x5B]);
  assert.strictEqual(p.plan({ t: 'key', k: 'f5' })[0].vk, 0x74);
});
ok('组合键：不认识的键 / 两个主键 → 整条丢弃，且不留下按着的修饰键', () => {
  const p = createPlanner();
  assert.strictEqual(p.plan({ t: 'key', k: 'ctrl+foo' }).length, 0);
  assert.strictEqual(p.plan({ t: 'key', k: 'ctrl+a+b' }).length, 0);
  assert.strictEqual(p.plan({ t: 'key', k: '' }).length, 0);
  assert.ok(!p.hasHeld());
});
ok('扩展键（方向键 / Delete / Win）带 EXTENDEDKEY，普通键不带', () => {
  const p = createPlanner();
  assert.strictEqual(p.plan({ t: 'kd', vk: 0x25 })[0].flags & KF.EXT, KF.EXT);
  assert.strictEqual(p.plan({ t: 'kd', vk: 0x41 })[0].flags & KF.EXT, 0);
  p.releaseAll();
});
ok('kd / ku：虚拟键码范围检查', () => {
  const p = createPlanner();
  assert.strictEqual(p.plan({ t: 'kd', vk: 0 }).length, 0);
  assert.strictEqual(p.plan({ t: 'kd', vk: 255 }).length, 0);
  assert.strictEqual(p.plan({ t: 'kd', vk: 65 }).length, 1);
});
ok('文字输入：Unicode 逐字注入（中文、emoji 代理对），换行 = Enter，制表 = Tab', () => {
  const p = createPlanner();
  const ops = p.plan({ t: 'e', op: 'append', s: '你A😀\n' });
  const uni = ops.filter(o => o.flags & KF.UNI);
  assert.deepStrictEqual(uni.filter(o => !(o.flags & KF.UP)).map(o => o.scan), [0x4F60, 0x41, 0xD83D, 0xDE00]);
  assert.strictEqual(ops[ops.length - 2].vk, 0x0D);
  assert.ok(uni.every(o => o.vk === 0));
});
ok('文字输入：del n 次退格；clear = Ctrl+A 再退格；replace；enter', () => {
  const p = createPlanner();
  assert.strictEqual(p.plan({ t: 'e', op: 'del', n: 3 }).filter(o => o.vk === 8 && !(o.flags & KF.UP)).length, 3);
  assert.strictEqual(p.plan({ t: 'e', op: 'del' }).length, 2);
  const c = p.plan({ t: 'e', op: 'clear' });
  assert.deepStrictEqual(c.filter(o => !(o.flags & KF.UP)).map(o => o.vk), [0x11, 0x41, 0x08]);
  const r = p.plan({ t: 'e', op: 'replace', s: 'x' });
  assert.ok(r.some(o => o.scan === 0x78));
  assert.deepStrictEqual(p.plan({ t: 'e', op: 'enter' }).map(o => o.vk), [0x0D, 0x0D]);
});
ok('文字输入：超长截断到 512；del 的 n 夹在 1..64', () => {
  const p = createPlanner();
  assert.strictEqual(p.plan({ t: 'e', op: 'append', s: 'a'.repeat(5000) }).length, 1024);
  assert.strictEqual(p.plan({ t: 'e', op: 'del', n: 9999 }).length, 128);
});
ok('手机触摸语义兼容：d/m/u = 左键拖动', () => {
  const p = createPlanner();
  assert.strictEqual(p.plan({ t: 'd', i: 1, x: 0.5, y: 0.5 })[0].flags, MF.LDOWN | MF.MOVE | MF.ABS);
  assert.strictEqual(p.plan({ t: 'm', i: 1, p: [[0.6, 0.6, 5], [0.7, 0.7, 9]] }).length, 2);
  assert.strictEqual(p.plan({ t: 'u', i: 1, x: 0.7, y: 0.7, d: 100 })[0].flags, MF.LUP | MF.MOVE | MF.ABS);
  assert.ok(!p.hasHeld());
});
ok('手机导航键兼容：home → Win，back → Alt+←', () => {
  const p = createPlanner();
  assert.deepStrictEqual(p.plan({ t: 'k', k: 'home' }).map(o => o.vk), [0x5B, 0x5B]);
  assert.deepStrictEqual(p.plan({ t: 'k', k: 'back' }).filter(o => !(o.flags & KF.UP)).map(o => o.vk), [0x12, 0x25]);
  assert.strictEqual(p.plan({ t: 'k', k: 'bogus' }).length, 0);
});
ok('releaseAll：松开所有还按着的鼠标键和按键', () => {
  const p = createPlanner();
  p.plan({ t: 'pd', b: 'l' }); p.plan({ t: 'kd', vk: 0x11 }); p.plan({ t: 'kd', vk: 0x43 });
  assert.ok(p.hasHeld());
  const ops = p.releaseAll();
  assert.strictEqual(ops.length, 3);
  assert.ok(ops.every(o => o.t === 'm' ? o.flags === MF.LUP : (o.flags & KF.UP)));
  assert.ok(!p.hasHeld());
  assert.strictEqual(p.releaseAll().length, 0);
});

/* ───── 注入器 ───── */
const mockBackend = (name, sent, failEvery = 0) => () => ({ name, send(ops) { sent.push(...ops); return failEvery ? ops.length : 0; }, close() {} });

ok('注入器：未授权（active=false）时一律不执行', () => {
  const sent = [], inj = createInjector({ factories: [mockBackend('a', sent)] });
  inj.handle({ t: 'pd', b: 'l' });
  assert.strictEqual(sent.length, 0);
  inj.setActive(true); inj.handle({ t: 'pd', b: 'l' });
  assert.strictEqual(sent.length, 1);
  inj.close();
});
ok('注入器：撤销授权 / 会话结束时自动松开按着的键', () => {
  const sent = [], inj = createInjector({ factories: [mockBackend('a', sent)] });
  inj.setActive(true); inj.handle({ t: 'pd', b: 'l' }); inj.handle({ t: 'kd', vk: 0x10 });
  sent.length = 0; inj.setActive(false);
  assert.strictEqual(sent.length, 2);
});
ok('注入器：按住不动且 2.5 秒没有任何消息 → 自动松开（防「卡住的鼠标键」）', async () => {
  const sent = [], inj = createInjector({ factories: [mockBackend('a', sent)], holdTimeoutMs: 600 });
  inj.setActive(true); inj.handle({ t: 'pd', b: 'l' }); sent.length = 0;
  await new Promise(r => setTimeout(r, 1500));
  assert.strictEqual(sent.length, 1); assert.strictEqual(sent[0].flags, MF.LUP);
  inj.close();
});
ok('注入器：保活消息 h 能续命（不会误松开）', async () => {
  const sent = [], inj = createInjector({ factories: [mockBackend('a', sent)], holdTimeoutMs: 700 });
  inj.setActive(true); inj.handle({ t: 'pd', b: 'l' }); sent.length = 0;
  for (let i = 0; i < 4; i++) { await new Promise(r => setTimeout(r, 400)); inj.handle({ t: 'h' }); }
  assert.strictEqual(sent.length, 0);
  inj.close();
});
ok('注入器：首选后端创建失败 → 自动用下一个；发送时抛异常 → 换下一个并重发', () => {
  const sent = [];
  const bad1 = () => { throw new Error('koffi 没装'); };
  const bad2 = () => ({ name: 'flaky', send() { throw new Error('boom'); }, close() {} });
  const inj = createInjector({ factories: [bad1, bad2, mockBackend('good', sent)] });
  const r = inj.init();
  assert.ok(r.ok && r.backend === 'flaky');
  inj.setActive(true); inj.handle({ t: 'pd', b: 'l' });
  assert.strictEqual(sent.length, 1);
  assert.strictEqual(inj.status().backend, 'good');
  inj.close();
});
ok('注入器：全部后端都不可用 → init 返回 ok=false 和原因', () => {
  const inj = createInjector({ factories: [() => { throw new Error('no koffi'); }, () => { throw new Error('no powershell'); }] });
  const r = inj.init();
  assert.ok(!r.ok); assert.ok(/no powershell/.test(r.error));
  inj.setActive(true); inj.handle({ t: 'pd', b: 'l' });          // 不应抛异常
  inj.close();
});
ok('注入器：连续被系统拦截（SendInput 返回 0）时通知一次', () => {
  const sent = []; let n = 0;
  const inj = createInjector({ factories: [mockBackend('a', sent, 1)], onBlocked: () => n++ });
  inj.setActive(true);
  for (let i = 0; i < 6; i++) inj.handle({ t: 'pd', b: 'l' });
  assert.strictEqual(n, 1);
  inj.close();
});

(async () => {
  for (const [name, fn] of queue) {
    try { await fn(); pass++; console.log('PASS ' + name); }
    catch (e) { console.log('FAIL ' + name + '\n     ' + e.message); process.exitCode = 1; }
  }
  console.log('\n' + pass + '/' + queue.length + ' 项通过');
  process.exit(process.exitCode || 0);
})();
