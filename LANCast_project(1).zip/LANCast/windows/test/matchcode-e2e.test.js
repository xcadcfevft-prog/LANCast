'use strict';
// node windows/test/matchcode-e2e.test.js
// 电脑 ↔ 电脑匹配码整链路：在两个独立的 vm 里各「真正执行」一份 renderer.js（假 DOM / 假 Electron），
// 两份之间用内存里的 TCP 与 UDP 广播相连，然后像用户一样点按钮、输匹配码，检查：
//   · 广播里带公开房间号；输入方不用 IP 就能找到对方；双方互相存下对方（ID / 长期密钥 / IP / ver=2）
//   · 错码被拒、错 5 次作废并在显示方提示；手动 IP 兜底；没开匹配码时的提示
//   · 配对后存下的密钥真的能通过后续的 v2 握手（含 proof）——这才是「配对成功」的真正含义
const assert = require('assert'), fs = require('fs'), path = require('path'), vm = require('vm'), os = require('os');
const { Duplex } = require('stream');
const dir = path.join(__dirname, '..');

let pass = 0, failed = false;
const ok = async (name, fn) => { try { await fn(); pass++; console.log('PASS ' + name); } catch (e) { failed = true; console.log('FAIL ' + name + '\n     ' + String(e.stack).split('\n').slice(0, 5).join('\n     ')); } };
const sleep = ms => new Promise(r => setTimeout(r, ms));

/* ───────── 内存网络 ───────── */
const tcpListeners = new Map();          // 'ip:port' → 连接处理函数
const udpNodes = [];                     // 所有实例的 UDP（广播投递给除自己以外的所有实例）
class Pipe extends Duplex {
  constructor(remoteAddress) { super(); this.peer = null; this.remoteAddress = remoteAddress; }
  _read() {}
  _write(chunk, enc, cb) { const p = this.peer; if (p && !p.destroyed) p.push(Buffer.from(chunk)); cb(); }
  _destroy(err, cb) { const p = this.peer; if (p && !p.destroyed) setImmediate(() => p.destroy()); cb(err); }
  setNoDelay() {}
}

/* ───────── 假 DOM（和 renderer-control.test.js 同一思路） ───────── */
function anything() {
  const f = function () {};
  return new Proxy(f, { get: (t, k) => (k === 'then' ? undefined : k === Symbol.toPrimitive ? () => 0 : (k in t ? t[k] : anything())), apply: () => anything(), construct: () => anything(), set: () => true });
}
function makeEl() {
  const l = {};
  const base = {
    hidden: false, value: '', textContent: '', innerHTML: '', style: {}, dataset: {}, className: '', disabled: false,
    classList: { add() {}, remove() {}, toggle() {}, contains() { return false; } },
    width: 0, height: 0, clientWidth: 1000, clientHeight: 600, offsetWidth: 100, offsetHeight: 40,
    addEventListener(type, fn) { (l[type] = l[type] || []).push(fn); }, removeEventListener() {},
    setPointerCapture() {}, releasePointerCapture() {}, focus() {}, blur() {}, appendChild() {},
    querySelector() { return makeEl(); }, getBoundingClientRect() { return { left: 0, top: 0, width: 100, height: 40 }; },
    getContext() { return anything(); }, closest() { return null; }, _l: l
  };
  return new Proxy(base, { get: (t, k) => (k in t ? t[k] : k === 'then' ? undefined : anything()), set: (t, k, v) => { t[k] = v; return true; } });
}

/* ───────── 一台「电脑」：一份真正的 renderer.js ───────── */
function makeInstance(name, ip) {
  const els = new Map(), store = new Map(), winL = {}, udpH = {};
  const el = sel => { if (!els.has(sel)) els.set(sel, makeEl()); return els.get(sel); };
  const inst = { name, ip, el, store, lastBeacon: null };
  const fakeNet = {
    createServer(handler) { return { on() {}, listen(port) { tcpListeners.set(ip + ':' + port, handler); } }; },
    connect({ host, port }) {
      const a = new Pipe(host), b = new Pipe(ip); a.peer = b; b.peer = a;
      const h = tcpListeners.get(host + ':' + port);
      setImmediate(() => { if (h) h(b); else a.destroy(Object.assign(new Error('connect ECONNREFUSED ' + host + ':' + port), { code: 'ECONNREFUSED' })); });
      return a;
    }
  };
  const fakeDgram = {
    createSocket() {
      const node = { on(ev, fn) { udpH[ev] = fn; }, bind(p, cb) { if (cb) cb(); }, setBroadcast() {},
        send(msg, port, addr, cb) { inst.lastBeacon = JSON.parse(msg.toString()); for (const o of udpNodes) if (o !== node && o.h.message) setImmediate(() => o.h.message(Buffer.from(msg), { address: ip })); if (cb) cb(); }, h: udpH };
      udpNodes.push(node); return node;
    }
  };
  const fakeOs = Object.assign({}, os, { hostname: () => name, networkInterfaces: () => ({ Ethernet: [{ family: 'IPv4', address: ip, internal: false, netmask: '255.255.255.0' }] }) });
  const sandbox = {
    __isWindow: true, console, Buffer, performance, process: { platform: 'win32', env: {} },
    localStorage: { getItem: k => (store.has(k) ? store.get(k) : null), setItem: (k, v) => store.set(k, String(v)) },
    document: { querySelector: s => el(s), querySelectorAll: () => [], createElement: () => makeEl(), addEventListener() {}, fullscreenElement: null, documentElement: makeEl() },
    navigator: {}, QR: { toCanvas() {} }, innerWidth: 1000, innerHeight: 600, devicePixelRatio: 1,
    requestAnimationFrame: () => 1, cancelAnimationFrame() {},
    addEventListener(type, fn) { (winL[type] = winL[type] || []).push(fn); },
    setTimeout, clearTimeout, setInterval, clearInterval
  };
  sandbox.window = sandbox;
  const ctx = vm.createContext(sandbox);
  const loadInCtx = file => { const m = { exports: {} }; vm.runInContext('(function (module, exports, require) {' + fs.readFileSync(file, 'utf8') + '\n})', ctx, { filename: file })(m, m.exports, req); return m.exports; };
  function req(n) {
    if (n === 'electron') return { ipcRenderer: new Proxy({ invoke: async () => ({ ok: true }) }, { get: (t, k) => (k in t ? t[k] : () => {}) }), clipboard: { readText: () => '' } };
    if (n === 'net') return fakeNet;
    if (n === 'dgram') return fakeDgram;
    if (n === 'os') return fakeOs;
    if (['./proto', './controller', './lossless', './matchcode'].includes(n)) return loadInCtx(path.join(dir, n + '.js'));
    return require(n);
  }
  sandbox.require = req;
  inst.run = code => vm.runInContext(code, ctx);
  vm.runInContext(fs.readFileSync(path.join(dir, 'renderer.js'), 'utf8'), ctx, { filename: 'renderer.js:' + name });
  inst.pairs = () => JSON.parse(store.get('pairs') || '[]');
  inst.id = () => inst.run('myId'); inst.pin = () => inst.run('myPin');
  inst.codeShown = () => (el('#codeShow').hidden ? '' : el('#codeText').textContent);
  inst.msg = () => el('#codeMsg').textContent;
  return inst;
}

(async () => {
  const A = makeInstance('PC-A', '10.0.0.1'), B = makeInstance('PC-B', '10.0.0.2');
  const gen = async inst => { inst.el('#genCode').onclick(); await sleep(20); return inst.codeShown(); };
  const enter = (inst, code, ip) => { inst.el('#codeIn').value = code; inst.el('#codeIp').value = ip || ''; return inst.el('#codeGo').onclick(); };

  await ok('A 点「生成匹配码」：显示 3-3-4 格式的 10 位码，按钮切换；广播里带公开房间号（前 3 位），不带口令', async () => {
    const code = await gen(A);
    assert.match(code, /^\d{3}-\d{3}-\d{4}$/);
    assert.strictEqual(A.el('#genCode').hidden, true); assert.strictEqual(A.el('#cancelCode').hidden, false);
    assert.match(A.el('#codeLeft').textContent, /有效期还剩 [0-5]:\d\d/);
    await sleep(1700);                                              // 等一次广播
    assert.strictEqual(A.lastBeacon.t, code.slice(0, 3));
    assert.ok(!JSON.stringify(A.lastBeacon).includes(code.replace(/-/g, '').slice(3)), '广播里不能有口令');
    A.el('#cancelCode').onclick(); await sleep(20);
    assert.strictEqual(A.codeShown(), ''); assert.strictEqual(A.el('#genCode').hidden, false);
    await sleep(1700); assert.strictEqual(A.lastBeacon.t, undefined, '取消后广播不再带房间号');
  });

  let codeA;
  await ok('B 输入匹配码（不填 IP）：按房间号在局域网里找到 A，配对成功；双方互相存下对方的 ID / 长期密钥 / IP / ver=2；A 的码作废', async () => {
    codeA = await gen(A);
    await enter(B, codeA);
    assert.match(B.msg(), /已与「PC-A」配对成功/, B.msg());
    const pa = A.pairs(), pb = B.pairs();
    assert.strictEqual(pa.length, 1); assert.strictEqual(pb.length, 1);
    assert.deepStrictEqual({ id: pa[0].id, pin: pa[0].pin, ip: pa[0].ip, ver: pa[0].ver, platform: pa[0].platform, name: pa[0].name }, { id: B.id(), pin: B.pin(), ip: '10.0.0.2', ver: 2, platform: 'windows', name: 'PC-B' });
    assert.deepStrictEqual({ id: pb[0].id, pin: pb[0].pin, ip: pb[0].ip, ver: pb[0].ver, platform: pb[0].platform, name: pb[0].name }, { id: A.id(), pin: A.pin(), ip: '10.0.0.1', ver: 2, platform: 'windows', name: 'PC-A' });
    assert.strictEqual(A.run('codeHost.active'), false);
    assert.strictEqual(A.codeShown(), ''); assert.match(A.msg(), /已与「PC-B」配对成功/);
    assert.strictEqual(B.el('#codeIn').value, '', '成功后清空输入框');
  });

  await ok('配对之后存下的密钥真的可用：双方互相用它做 v2 握手（含 proof 校验）都通过——对方只是因为本测试没加载文件模块而拒绝 file 模式', async () => {
    const pa = A.pairs()[0], pb = B.pairs()[0];
    for (const [inst, p] of [[B, pb], [A, pa]]) {
      let err = null;
      try { await inst.run('connectTo(' + JSON.stringify(p.ip) + ',47800,' + JSON.stringify(p.pin) + ',"file")'); } catch (e) { err = e; }
      assert.ok(err, '本测试没有 FX，对方应当拒绝 file 模式'); assert.match(err.message, /不支持文件传输/, '应当是通过了认证之后才被拒绝：' + err.message);
    }
  });

  await ok('错的匹配码：被拒绝并提示，A 的码还在；连错 5 次后 A 的码作废，A 界面提示，之后输对的也连不上', async () => {
    const code = await gen(A), tag = code.slice(0, 3), good = code.replace(/-/g, '').slice(3);
    const wrong = tag + String((Number(good) + 1) % 1e7).padStart(7, '0');
    for (let i = 0; i < 4; i++) { await enter(B, wrong); assert.match(B.msg(), /匹配码不正确/, B.msg()); assert.ok(A.run('codeHost.active')); }
    await enter(B, wrong); assert.match(B.msg(), /错误次数过多/, B.msg());
    assert.strictEqual(A.run('codeHost.active'), false); assert.strictEqual(A.codeShown(), '');
    assert.match(A.msg(), /连续输错/, A.msg());
    assert.strictEqual(A.pairs().length, 1, '没有新增配对记录');
    await sleep(1700);                                              // A 的广播不再带房间号：B 按房间号找不到
  });

  await ok('A 没开匹配码时，用手动 IP 连：直接提示「没有开启匹配码」；格式不对的 IP / 匹配码被提前拦下', async () => {
    await enter(B, '123-456-7890', '10.0.0.1'); assert.match(B.msg(), /没有开启匹配码/, B.msg());
    await enter(B, '123-456-7890', '1.2.3'); assert.match(B.msg(), /IP 地址格式不对/);
    await enter(B, '12345'); assert.match(B.msg(), /10 位数字/);
    await enter(B, '123-456-7890', '10.0.0.99'); assert.match(B.msg(), /ECONNREFUSED|无法|拒绝|断开/, B.msg());
  });

  await ok('按房间号找不到电脑：约 5 秒后给出排查提示（不会卡死，按钮恢复可用）', async () => {
    await enter(B, '999-111-2222');
    assert.match(B.msg(), /没找到这个匹配码对应的电脑/, B.msg()); assert.strictEqual(B.el('#codeGo').disabled, false);
  });

  await ok('手动 IP 兜底：A 重新生成匹配码，B 只填 IP + 匹配码也能配对；重复配对只会更新记录，不会多出一条', async () => {
    const code = await gen(A);
    await enter(B, code, '10.0.0.1');
    assert.match(B.msg(), /配对成功/, B.msg());
    assert.strictEqual(A.pairs().length, 1); assert.strictEqual(B.pairs().length, 1);
  });

  await ok('不能和自己配对（手动填本机 IP）', async () => {
    const code = await gen(A);
    await enter(A, code, '10.0.0.1');
    assert.match(A.msg(), /不能和自己配对|本机/, A.msg());
  });

  console.log('\n' + (failed ? '有失败' : 'ALL ' + pass + ' PASSED'));
  process.exit(failed ? 1 : 0);
})();
