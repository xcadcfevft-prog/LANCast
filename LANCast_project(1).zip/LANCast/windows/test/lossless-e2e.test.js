'use strict';
// node windows/test/lossless-e2e.test.js
// 把 renderer.js 真正「跑」一遍极致无损：假屏幕帧 → 发送端(startSource) → 假会话 → 接收端(Viewer) → 解出的像素必须与屏幕帧逐位一致。
// 同时覆盖：静止画面不发包、网络积压丢帧后差异链不断、对方要关键帧时重发整幅、对方是旧版时退回普通档。
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const dir = path.join(__dirname, '..');

let pass = 0, failed = false;
const ok = async (name, fn) => { try { await fn(); pass++; console.log('PASS ' + name); } catch (e) { failed = true; console.log('FAIL ' + name + '\n     ' + String(e.stack).split('\n').slice(0, 5).join('\n     ')); } };
function anything() {
  const f = function () {};
  return new Proxy(f, { get: (t, k) => (k === 'then' ? undefined : k === Symbol.toPrimitive ? () => 0 : (k in t ? t[k] : anything())), apply: () => anything(), construct: () => anything(), set: () => true });
}
const els = new Map();
function makeEl() {
  const base = { hidden: false, value: '', textContent: '', innerHTML: '', style: {}, dataset: {}, className: '', disabled: false,
    classList: { add() {}, remove() {}, toggle() {}, contains() { return false; } }, width: 0, height: 0, clientWidth: 1000, clientHeight: 600,
    offsetWidth: 100, offsetHeight: 40, addEventListener() {}, removeEventListener() {}, appendChild() {}, querySelector() { return makeEl(); },
    getBoundingClientRect() { return { left: 0, top: 0, width: 100, height: 40 }; }, getContext() { return anything(); } };
  return new Proxy(base, { get: (t, k) => (k in t ? t[k] : k === 'then' ? undefined : anything()), set: (t, k, v) => { t[k] = v; return true; } });
}
const $el = sel => { if (!els.has(sel)) els.set(sel, makeEl()); return els.get(sel); };

const sandbox = {
  console, Buffer, performance, process: { platform: 'win32', env: {} }, setTimeout, clearTimeout, setInterval, clearInterval,
  localStorage: { getItem: () => null, setItem() {} },
  document: { querySelector: s => $el(s), querySelectorAll: () => [], createElement: () => makeEl(), addEventListener() {}, fullscreenElement: null, documentElement: makeEl() },
  navigator: {}, QR: { toCanvas() {} }, innerWidth: 1000, innerHeight: 600, devicePixelRatio: 1,
  requestAnimationFrame: () => 1, cancelAnimationFrame() {}, addEventListener() {},
  ImageData: class { constructor(d, w, h) { this.data = d; this.width = w; this.height = h; } },
  OffscreenCanvas: class { constructor(w, h) { this.width = w; this.height = h; } getContext() { throw new Error('should not need fallback'); } }
};
sandbox.window = sandbox;
const ctx = vm.createContext(sandbox);
function loadInCtx(file) {
  const m = { exports: {} };
  vm.runInContext('(function (module, exports, require) {' + fs.readFileSync(file, 'utf8') + '\n})', ctx, { filename: file })(m, m.exports, req);
  return m.exports;
}
function req(name) {
  if (name === 'electron') return { ipcRenderer: new Proxy({ invoke: async () => ({ ok: true }) }, { get: (t, k) => (k in t ? t[k] : () => {}) }), clipboard: { readText: () => '' } };
  if (name === 'net') return { createServer: () => anything(), connect: () => anything() };
  if (name === 'dgram') return { createSocket: () => anything() };
  if (name === './proto' || name === './controller' || name === './lossless' || name === './matchcode') return loadInCtx(path.join(dir, name + '.js'));
  return require(name);
}
sandbox.require = req;
const run = code => vm.runInContext(code, ctx);
const sleep = ms => new Promise(r => setTimeout(r, ms));

/* 假屏幕：一块可以随时改像素的画面，每次 pushFrame 就产生一帧 VideoFrame */
const W = 300, H = 200;
const screen = new Uint32Array(W * H).map((_, i) => (0xFF000000 | ((i * 7) & 0xFF) << 16 | ((i >> 3) & 0xFF) << 8 | (i & 0xFF)) >>> 0);
const waiting = [], backlog = [];
function pushFrame() {
  const snap = Uint32Array.from(screen);
  const f = { displayWidth: W, displayHeight: H, visibleRect: { width: W, height: H },
    copyTo(dst, o) { assert.strictEqual(o.format, 'RGBA'); dst.set(snap); return Promise.resolve(); }, close() {} };
  const w = waiting.shift(); if (w) w({ value: f, done: false }); else backlog.push(f);
}
sandbox.MediaStreamTrackProcessor = class {
  constructor() { this.readable = { getReader: () => ({ read: () => (backlog.length ? Promise.resolve({ value: backlog.shift(), done: false }) : new Promise(r => waiting.push(r))), cancel() {} }) }; }
};
const newStream = () => ({ getVideoTracks: () => [{}], getAudioTracks: () => [], getTracks: () => [] });

(async () => {
  vm.runInContext(fs.readFileSync(path.join(dir, 'renderer.js'), 'utf8'), ctx, { filename: 'renderer.js' });
  $el('#quality').value = 'extreme'; $el('#maxres').value = '0'; $el('#audioOn').checked = false;

  const sent = [], json = [];
  const sess = { alive: true, peerName: 'phone', peerCaps: ['lossless'], ctlAllowed: false, sock: { writableLength: 0 },
    attach(fn) { this.fn = fn; }, sendJson(t, o) { json.push([t, o]); }, sendCtrl() {}, sendAudio() {},
    sendLossless(p) { sent.push({ p: Buffer.from(p), full: arguments[1] }); }, close() {}, _hdr: b => b };
  sandbox.__sess = sess; sandbox.__capStream = newStream();

  await ok('发送端：极致无损下发 VCONFIG(codec=lossless, 原生分辨率) 并发出整幅', async () => {
    run('startSource(__sess)'); await sleep(30);
    pushFrame(); await sleep(80);
    const vc = json.find(j => j[1].codec); assert.ok(vc, 'no VCONFIG');
    assert.strictEqual(vc[1].codec, 'lossless'); assert.strictEqual(vc[1].width, W); assert.strictEqual(vc[1].height, H);
    assert.strictEqual(sent.length, 1); assert.strictEqual(sent[0].full, true);
  });

  sandbox.__vs = { alive: true, peerName: 'pc', ctrl: [], sendCtrl(o) { this.ctrl.push(o); }, sendJson() {}, close() {} };
  run('var __v = new Viewer(__vs)');
  sandbox.__cfg = Buffer.from(JSON.stringify(json.find(j => j[1].codec)[1]));
  run('__v.onPacket(16, 0, 0, __cfg)');
  const px = () => run('__v.ll.dec.px');
  const same = (a, b) => { for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return false; return true; };
  const feedAll = async () => { for (const x of sent.splice(0)) { sandbox.__pl = x.p; run('__v.onPacket(17, ' + (x.full ? 1 : 0) + ', 0, __pl)'); } await sleep(50); };

  await ok('接收端：整幅解出来与屏幕逐像素一致，并产生可绘制的画面', async () => {
    await feedAll(); assert.ok(same(px(), screen)); assert.ok(run('!!__v.pending || !!__v.cur'));
  });
  await ok('画面静止：不发任何包', async () => { pushFrame(); pushFrame(); await sleep(80); assert.strictEqual(sent.length, 0); });
  await ok('局部变化：只发差异，接收端仍逐像素一致', async () => {
    for (let y = 20; y < 30; y++) for (let x = 100; x < 120; x++) screen[y * W + x] = 0xFFAA5511;
    pushFrame(); await sleep(80); assert.strictEqual(sent.length, 1); assert.strictEqual(sent[0].full, false); assert.ok(sent[0].p.length < 30000, 'delta ' + sent[0].p.length);   // 整幅约 180KB
    await feedAll(); assert.ok(same(px(), screen));
  });
  await ok('网络积压：整帧丢弃，恢复后下一帧把累计变化一起补上（差异链不断）', async () => {
    sess.sock.writableLength = 10 * 1024 * 1024;
    screen[5] = 0xFF010203; pushFrame(); await sleep(60); assert.strictEqual(sent.length, 0, '积压时不该发');
    screen[W * H - 1] = 0xFF040506; pushFrame(); await sleep(60); assert.strictEqual(sent.length, 0);
    sess.sock.writableLength = 0; screen[7] = 0xFF070809; pushFrame(); await sleep(80);
    assert.strictEqual(sent.length, 1); await feedAll(); assert.ok(same(px(), screen));
  });
  await ok('对方要关键帧：静止画面也立即重发整幅', async () => {
    sess.fn(5, 0, 0, Buffer.from(JSON.stringify({ cmd: 'keyframe' }))); await sleep(100);
    assert.strictEqual(sent.length, 1); assert.strictEqual(sent[0].full, true); await feedAll(); assert.ok(same(px(), screen));
  });
  await ok('接收端：没收到整幅之前的差异帧被忽略', async () => {
    run('var __v2 = new Viewer(__vs)'); run('__v2.onPacket(16, 0, 0, __cfg)');
    screen[9] = 0xFF999999; pushFrame(); await sleep(80); assert.strictEqual(sent.length, 1);
    sandbox.__pl = sent.splice(0)[0].p; run('__v2.onPacket(17, 0, 0, __pl)'); await sleep(50);
    assert.strictEqual(run('__v2.ll.dec.started'), false);
  });
  await ok('接收端：数据损坏 → 不崩溃，并向对方要整幅', async () => {
    const before = sandbox.__vs.ctrl.length;
    sandbox.__pl = Buffer.from([1, 1, 0, 0, 0, 3, 0, 0, 0, 5, 1, 2, 3, 4, 5]);
    run('__v.onPacket(17, 1, 0, __pl)'); await sleep(60);
    assert.ok(sandbox.__vs.ctrl.length > before && sandbox.__vs.ctrl.slice(-1)[0].cmd === 'keyframe');
  });
  await ok('对方版本不支持无损 → 退回视觉无损（不发 lossless 格式）', async () => {
    run('cur.stop("test")'); waiting.length = 0; backlog.length = 0;      // 先结束上一个会话，免得它抢走假屏幕帧
    const j2 = []; let enc = false;
    sandbox.__sess2 = { ...sess, peerCaps: [], sendJson: (t, o) => j2.push(o), sendLossless() { throw new Error('should not be called'); }, attach() {} };
    sandbox.__capStream = newStream();
    sandbox.VideoEncoder = class { static async isConfigSupported() { enc = true; return { supported: true }; } configure() {} close() {} };
    run('startSource(__sess2)'); await sleep(30); pushFrame(); await sleep(80);
    assert.ok(!j2.some(o => o.codec === 'lossless')); assert.ok(enc, '应该走 H.264 编码器');
  });
  console.log(failed ? 'FAILED' : 'ALL ' + pass + ' PASSED'); process.exit(failed ? 1 : 0);
})();
