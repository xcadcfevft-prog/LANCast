'use strict';
// 下载引擎测试：本地回环 + 真实数据（模拟做种节点），不访问外网。
const assert = require('assert');
const net = require('net'), http = require('http'), crypto = require('crypto'), fs = require('fs'), os = require('os'), path = require('path');
const M = require('../magnet'), { Torrent, BtManager, parseRange, mediaKind } = require('../btdl');
const { bencode, bdecode } = M;
const sha1 = b => crypto.createHash('sha1').update(b).digest();
const tmp = p => fs.mkdtempSync(path.join(os.tmpdir(), p));
const sleep = ms => new Promise(r => setTimeout(r, ms));
const until = async (fn, ms, what) => { const t0 = Date.now(); while (!fn()) { if (Date.now() - t0 > ms) throw new Error('timeout: ' + what); await sleep(20); } };

/* ── 造一个带补位文件的多文件种子 ── */
function makeTorrent(files, pl, name = 'Pack') {
  const entries = []; const chunks = []; let off = 0;
  files.forEach((f, i) => {
    entries.push({ length: f.data.length, path: f.path }); chunks.push(f.data); off += f.data.length;
    const pad = (pl - (off % pl)) % pl;
    if (pad && i < files.length - 1) { entries.push({ length: pad, attr: Buffer.from('p'), path: ['.pad', String(pad)] }); chunks.push(Buffer.alloc(pad)); off += pad; }
  });
  const data = Buffer.concat(chunks), hashes = [];
  for (let p = 0; p * pl < data.length; p++) hashes.push(sha1(data.subarray(p * pl, (p + 1) * pl)));
  const infoObj = { name, 'piece length': pl, pieces: Buffer.concat(hashes), files: entries };
  const info = bencode(infoObj);
  return { data, info, torrent: bencode({ info: infoObj }), hash: sha1(info).toString('hex'), pl, files };
}
const rnd = n => crypto.randomBytes(n);

/* ── 模拟做种 / 吸血节点 ── */
function seeder(T, { mode = 'good', delay = 0, host = '127.0.0.1', leech = false } = {}) {
  const st = { served: 0, uploaded: null, conns: 0 };
  const ih = Buffer.from(T.hash, 'hex'), n = Math.ceil(T.data.length / T.pl);
  const srv = net.createServer(sock => {
    let buf = Buffer.alloc(0), shook = false, ut = 0;
    st.conns++;
    sock.on('error', () => {});
    const send = (id, pl) => { const l = 1 + (pl ? pl.length : 0), b = Buffer.alloc(4 + l); b.writeUInt32BE(l, 0); b[4] = id; if (pl) pl.copy(b, 5); sock.write(b); };
    const ext = (id, pl) => send(20, Buffer.concat([Buffer.from([id]), pl]));
    sock.on('data', d => {
      buf = Buffer.concat([buf, d]);
      if (!shook) {
        if (buf.length < 68) return;
        shook = true; buf = buf.subarray(68);
        const hs = Buffer.alloc(68); hs[0] = 19; hs.write('BitTorrent protocol', 1, 'latin1'); hs[25] = 0x10; ih.copy(hs, 28); crypto.randomBytes(20).copy(hs, 48); sock.write(hs);
        ext(0, bencode({ m: { ut_metadata: 3 }, metadata_size: T.info.length }));
        const bf = Buffer.alloc(Math.ceil(n / 8)); if (!leech) for (let p = 0; p < n; p++) bf[p >> 3] |= 0x80 >> (p & 7);
        send(5, bf);
        if (leech) send(2);
      }
      while (buf.length >= 4) {
        const len = buf.readUInt32BE(0); if (buf.length < 4 + len) break;
        const msg = buf.subarray(4, 4 + len); buf = buf.subarray(4 + len);
        if (!len) continue;
        const id = msg[0], pl = msg.subarray(1);
        if (id === 2) send(1);
        else if (id === 1 && leech) { const r = Buffer.alloc(12); r.writeUInt32BE(1, 0); r.writeUInt32BE(0, 4); r.writeUInt32BE(16384, 8); send(6, r); }
        else if (id === 7 && leech) st.uploaded = Buffer.from(pl.subarray(8));
        else if (id === 6) {
          const p = pl.readUInt32BE(0), b = pl.readUInt32BE(4), l = pl.readUInt32BE(8);
          setTimeout(() => {
            const data = Buffer.from(T.data.subarray(p * T.pl + b, p * T.pl + b + l));
            if (mode === 'corrupt') data[0] ^= 0xff;
            const h = Buffer.alloc(8); h.writeUInt32BE(p, 0); h.writeUInt32BE(b, 4); st.served++;
            try { send(7, Buffer.concat([h, data])); } catch {}
          }, delay);
        } else if (id === 20 && pl[0] === 0) ut = Number(bdecode(pl.subarray(1)).m.ut_metadata);
        else if (id === 20 && pl[0] === 3) {
          const hd = bdecode(pl.subarray(1)), piece = Number(hd.piece);
          const chunk = T.info.subarray(piece * 16384, (piece + 1) * 16384);
          ext(ut, Buffer.concat([bencode({ msg_type: 1, piece, total_size: T.info.length }), chunk]));
        }
      }
    });
  });
  return new Promise(res => srv.listen(0, host, () => res({ srv, port: srv.address().port, host, st })));
}

const NODISC = { discovery: false };
const mk = (T, dir, extra = {}) => new Torrent({ ...NODISC, torrent: T.torrent, dir, resumeFile: path.join(dir, '..', path.basename(dir) + '.resume.json'), ...extra });
const read = (T, i, dir) => fs.readFileSync(path.join(dir, 'Pack', ...T.files[i].path));
const tests = []; const test = (n, f) => tests.push([n, f]);
const all = (Ts, dir) => Ts.files.forEach((f, i) => assert(read(Ts, i, dir).equals(f.data), 'file mismatch: ' + f.path.join('/')));

const T1 = makeTorrent([
  { path: ['a.bin'], data: rnd(700 * 1000 + 17) }, { path: ['dir', 'b.mkv'], data: rnd(1300 * 1000 + 3) }, { path: ['c.txt'], data: rnd(100 * 1000) }
], 65536);

test('parseTorrent: 补位文件不显示但偏移正确', () => {
  const m = M.parseTorrent(T1.torrent);
  assert.strictEqual(m.files.length, 3); assert(m.layout.length > 3 && m.layout.some(e => e.pad));
  assert.strictEqual(m.files[1].offset % 65536, 0); assert.strictEqual(m.pieces.length / 20, Math.ceil(T1.data.length / 65536));
});
test('parseRange / mediaKind', () => {
  assert.deepStrictEqual(parseRange('bytes=10-19', 100), { start: 10, end: 19 });
  assert.deepStrictEqual(parseRange('bytes=90-', 100), { start: 90, end: 99 });
  assert.deepStrictEqual(parseRange('bytes=-10', 100), { start: 90, end: 99 });
  assert.deepStrictEqual(parseRange('bytes=0-999', 100), { start: 0, end: 99 });
  assert.strictEqual(parseRange('bytes=100-', 100), 'bad'); assert.strictEqual(parseRange('bytes=5-2', 100), 'bad'); assert.strictEqual(parseRange('x', 100), 'bad');
  assert.strictEqual(parseRange(undefined, 100), null);
  assert.strictEqual(mediaKind('a/b.MKV'), 'video'); assert.strictEqual(mediaKind('x.flac'), 'audio'); assert.strictEqual(mediaKind('x.txt'), '');
});
test('完整下载：落盘内容与源文件逐字节一致', async () => {
  const sd = await seeder(T1), dir = tmp('btdl1-'), t = mk(T1, dir);
  let done = false; t.on('done', () => { done = true; });
  await t.start(); t._addPeers([{ host: '127.0.0.1', port: sd.port }]);
  await until(() => done, 20000, 'download');
  all(T1, dir); assert.strictEqual(t.status().progress, 1); assert.strictEqual(t.state, 'seeding');
  assert(t.status(true).files.every(f => f.done === f.size));
  t.destroy(); sd.srv.close();
});
test('只下选中的文件：其它文件不会产生', async () => {
  const sd = await seeder(T1), dir = tmp('btdl2-'), t = mk(T1, dir, { selected: [1] });
  let done = false; t.on('done', () => { done = true; });
  await t.start(); t._addPeers([{ host: '127.0.0.1', port: sd.port }]);
  await until(() => done, 20000, 'download');
  assert(read(T1, 1, dir).equals(T1.files[1].data));
  assert(!fs.existsSync(path.join(dir, 'Pack', 'a.bin')) && !fs.existsSync(path.join(dir, 'Pack', 'c.txt')));
  assert(t.status().progress === 1 && t.doneBytes < T1.data.length);
  t.setSelected([0, 1, 2]); assert.strictEqual(t.state, 'downloading');         // 追加选择会继续下载
  await until(() => t.state === 'seeding', 20000, 'second round');
  all(T1, dir); t.destroy(); sd.srv.close();
});
test('坏数据：校验失败的分片被丢弃、坏节点被拉黑，最终仍然正确', async () => {
  const bad = await seeder(T1, { mode: 'corrupt', host: '127.0.0.2' }), good = await seeder(T1, { delay: 5 }), dir = tmp('btdl3-'), t = mk(T1, dir);
  let done = false; t.on('done', () => { done = true; });
  await t.start(); t._addPeers([{ host: '127.0.0.2', port: bad.port }]); await sleep(150); t._addPeers([{ host: '127.0.0.1', port: good.port }]);
  await until(() => done, 25000, 'download with bad peer');
  all(T1, dir); assert(t.banned.has('127.0.0.2')); assert(!t.banned.has('127.0.0.1'));
  t.destroy(); bad.srv.close(); good.srv.close();
});
test('断点续传：暂停后重开保留进度；没有续传记录时自动校验已有文件', async () => {
  const sd = await seeder(T1, { delay: 25 }), dir = tmp('btdl4-'), t = mk(T1, dir);
  await t.start(); t._addPeers([{ host: '127.0.0.1', port: sd.port }]);
  await until(() => t.status().progress > 0.3, 20000, 'some progress');
  t.pause(); await sleep(100);
  const have1 = t.haveCount; assert(have1 > 0 && have1 < t.n && fs.existsSync(t.resumeFile));
  const t2 = mk(T1, dir); await t2.start();
  assert(t2.haveCount >= have1 - 1 && t2.haveCount > 0, 'resume restored ' + t2.haveCount);
  let done = false; t2.on('done', () => { done = true; }); t2._addPeers([{ host: '127.0.0.1', port: sd.port }]);
  await until(() => done, 25000, 'finish after resume'); all(T1, dir); t2.destroy();
  fs.unlinkSync(t2.resumeFile);                                                   // 记录丢了，文件还在
  const t3 = mk(T1, dir); await t3.start();
  assert.strictEqual(t3.state, 'seeding'); assert.strictEqual(t3.haveCount, t3.n); t3.destroy(); sd.srv.close();
});
test('上传：对方向我们要数据时，从磁盘读出来发给对方', async () => {
  const sd = await seeder(T1), dir = tmp('btdl5-'), t0 = mk(T1, dir);
  let done = false; t0.on('done', () => { done = true; }); await t0.start(); t0._addPeers([{ host: '127.0.0.1', port: sd.port }]);
  await until(() => done, 20000, 'download'); t0.destroy();
  const leech = await seeder(T1, { leech: true }), t = mk(T1, dir); await t.start();
  t._connect({ host: '127.0.0.1', port: leech.port, key: 'x', fails: 0, nextTry: 0 });
  await until(() => leech.st.uploaded, 5000, 'upload');
  assert(leech.st.uploaded.equals(T1.data.subarray(65536, 65536 + 16384)));
  t.destroy(); sd.srv.close(); leech.srv.close();
});

/* ── 边下边播 ── */
function get(url, headers, method = 'GET') {
  return new Promise((res, rej) => {
    const u = new URL(url);
    const r = http.request({ host: u.hostname, port: u.port, path: u.pathname, method, headers }, resp => {
      const ch = []; resp.on('data', d => ch.push(d)); resp.on('end', () => res({ status: resp.statusCode, headers: resp.headers, body: Buffer.concat(ch) }));
    });
    r.on('error', rej); r.end();
  });
}
const TV = makeTorrent([{ path: ['movie.mp4'], data: rnd(6 * 1024 * 1024 + 123) }, { path: ['sub.srt'], data: Buffer.from('1\n00:00:01,000 --> 00:00:02,000\n你好\n') }], 65536, 'Pack');
test('边下边播：HTTP Range 返回的字节全部正确；拖动到中间会优先下载该处', async () => {
  const sd = await seeder(TV, { delay: 150 }), dd = tmp('btdlm-'), mgr = new BtManager({ dataDir: path.join(dd, 'data'), defaultDir: path.join(dd, 'dl'), torrentOpts: { ...NODISC, hintHead: 128 * 1024, hintTail: 128 * 1024 } });
  const t = mgr.add({ torrent: TV.torrent, selected: [], start: false });
  const url = await mgr.streamUrl(t.hash, 0);
  await until(() => t.state === 'downloading', 5000, 'started'); t._addPeers([{ host: '127.0.0.1', port: sd.port }]);
  const src = TV.files[0].data, mid = 3 * 1024 * 1024;
  const t0 = Date.now();
  const r1 = await get(url, { Range: `bytes=${mid}-${mid + 999}` });
  assert.strictEqual(r1.status, 206); assert(r1.body.equals(src.subarray(mid, mid + 1000)));
  assert.strictEqual(r1.headers['content-range'], `bytes ${mid}-${mid + 999}/${src.length}`);
  assert(t.status().progress < 0.6, `seek should be served early, progress=${t.status().progress}`);
  const r2 = await get(url, { Range: 'bytes=0-4095' }); assert(r2.body.equals(src.subarray(0, 4096)));
  const r3 = await get(url, { Range: `bytes=${src.length - 500}-` }); assert(r3.body.equals(src.subarray(src.length - 500)));
  assert.strictEqual((await get(url, {}, 'HEAD')).headers['content-length'], String(src.length));
  assert.strictEqual((await get(url, { Range: 'bytes=99999999-' })).status, 416);
  const full = await get(url, {}); assert.strictEqual(full.status, 200); assert(full.body.equals(src));
  assert.strictEqual(full.headers['content-type'], 'video/mp4'); assert.strictEqual((await get(url.replace('/0/', '/9/'), {})).status, 404);
  await until(() => t.state === 'seeding', 30000, 'download completes while playing');
  assert(read(TV, 0, path.join(dd, 'dl')).equals(src)); assert(!fs.existsSync(path.join(dd, 'dl', 'Pack', 'sub.srt')) || true);
  mgr.destroy(); sd.srv.close();
});
test('磁力 → 解析元数据 → 下载（端到端）；移除任务只删种子里的文件', async () => {
  const sd = await seeder(T1), dd = tmp('btdle-');
  const r = await M.resolveMagnet(`magnet:?xt=urn:btih:${T1.hash}&x.pe=127.0.0.1:${sd.port}`, { extraTrackers: [], dht: false, noCache: true, timeout: 15 });
  assert(!r.error, r.error); assert.strictEqual(r.fileCount, 3);
  const mgr = new BtManager({ dataDir: path.join(dd, 'data'), defaultDir: path.join(dd, 'dl'), torrentOpts: NODISC });
  let done = false; mgr.on('done', () => { done = true; });
  const t = mgr.add({ torrent: r.torrent });
  await until(() => t.state === 'downloading', 5000, 'start'); t._addPeers([{ host: '127.0.0.1', port: sd.port }]);
  await until(() => done, 20000, 'e2e done'); all(T1, path.join(dd, 'dl'));
  assert.strictEqual(mgr.list().length, 1);
  const mine = path.join(dd, 'dl', 'Pack', 'my-own-file.txt'); fs.writeFileSync(mine, 'keep me');
  // 重启后任务列表可恢复
  await sleep(450);
  const mgr2 = new BtManager({ dataDir: path.join(dd, 'data'), defaultDir: path.join(dd, 'dl'), torrentOpts: NODISC });
  assert.strictEqual(mgr2.load().length, 1); mgr2.destroy();
  mgr.remove(t.hash, true);
  assert(fs.existsSync(mine), '用户自己的文件不能被删'); assert(!fs.existsSync(path.join(dd, 'dl', 'Pack', 'a.bin')) && !fs.existsSync(path.join(dd, 'dl', 'Pack', 'dir')));
  assert.strictEqual(mgr.list().length, 0); mgr.destroy(); sd.srv.close();
});

(async () => {
  let passed = 0;
  for (const [name, fn] of tests) {
    try { await fn(); passed++; console.log('  ok  ' + name); }
    catch (e) { console.log('FAIL  ' + name + '\n      ' + (e && e.stack || e)); process.exitCode = 1; }
  }
  console.log(process.exitCode ? 'btdl: SOME FAILED' : `btdl: ALL ${passed} PASSED`);
  process.exit(process.exitCode || 0);
})();
