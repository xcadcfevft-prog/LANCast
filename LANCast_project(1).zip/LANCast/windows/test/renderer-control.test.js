'use strict';
// node windows/test/renderer-control.test.js
// 把 renderer.js 真正「执行」一遍（假 DOM + 假 Electron + 像 Chromium 一样严格的计时器），再模拟手指 / 鼠标操作，
// 检查「电脑控制手机」时指令确实发得出去。node --check 只查语法，查不出「加载时就抛错」「Illegal invocation」这类问题。
const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const dir = path.join(__dirname, '..');

let pass = 0, failed = false;
const ok = (name, fn) => { try { fn(); pass++; console.log('PASS ' + name); } catch (e) { failed = true; console.log('FAIL ' + name + '\n     ' + String(e.stack).split('\n').slice(0, 4).join('\n     ')); } };

/* ───────── 假环境 ───────── */
function anything() {
  const f = function () {};
  return new Proxy(f, {
    get: (t, k) => (k === 'then' ? undefined : k === Symbol.toPrimitive ? () => 0 : (k in t ? t[k] : anything())),
    apply: () => anything(), construct: () => anything(), set: () => true
  });
}
const els = new Map();                       // 选择器 → 假元素
function makeEl() {
  const l = {};
  const base = {
    hidden: false, value: '', textContent: '', innerHTML: '', style: {}, dataset: {}, className: '',
    classList: { add() {}, remove() {}, toggle() {}, contains() { return false; } },
    width: 0, height: 0, clientWidth: 1000, clientHeight: 600, offsetWidth: 100, offsetHeight: 40,
    addEventListener(type, fn) { (l[type] = l[type] || []).push(fn); }, removeEventListener() {},
    setPointerCapture() {}, releasePointerCapture() {}, focus() { base.focused = true; }, blur() {}, appendChild() {},
    querySelector() { return makeEl(); }, getBoundingClientRect() { return { left: 0, top: 0, width: 100, height: 40 }; },
    getContext() { return anything(); }, closest() { return null; }, _l: l
  };
  return new Proxy(base, { get: (t, k) => (k in t ? t[k] : k === 'then' ? undefined : anything()), set: (t, k, v) => { t[k] = v; return true; } });
}
const $el = sel => { if (!els.has(sel)) els.set(sel, makeEl()); return els.get(sel); };

const store = new Map(), winL = {}, realTimers = {};
const sandbox = {
  __isWindow: true, console, Buffer, performance, process: { platform: 'win32', env: {} },
  localStorage: { getItem: k => (store.has(k) ? store.get(k) : null), setItem: (k, v) => store.set(k, String(v)) },
  document: {
    querySelector: s => $el(s), querySelectorAll: () => [], createElement: () => makeEl(), addEventListener() {},
    fullscreenElement: null, documentElement: makeEl()
  },
  navigator: {}, QR: { toCanvas() {} },
  innerWidth: 1000, innerHeight: 600, devicePixelRatio: 1.5,
  requestAnimationFrame: () => 1, cancelAnimationFrame() {},
  addEventListener(type, fn) { (winL[type] = winL[type] || []).push(fn); }
};
// 和 Chromium 一样：window.setTimeout 等只能「无 this / 以 window 为 this」调用，挂到别的对象上调用会抛 Illegal invocation
for (const n of ['setTimeout', 'clearTimeout', 'setInterval', 'clearInterval']) {
  realTimers[n] = globalThis[n];
  sandbox[n] = function (...a) {          // 文件顶部已是严格模式：普通调用时 this === undefined
    if (this !== undefined && this !== null && !this.__isWindow) throw new TypeError("Failed to execute '" + n + "' on 'Window': Illegal invocation");
    const r = realTimers[n](...a); if (r && r.unref) r.unref(); return r;
  };
}
sandbox.window = sandbox;                    // 浏览器里 window 就是全局对象
const ctx = vm.createContext(sandbox);
function loadInCtx(file) {                   // 模块也放进同一个上下文里执行，用的就是上面这套严格计时器
  const m = { exports: {} };
  vm.runInContext('(function (module, exports, require) {' + fs.readFileSync(file, 'utf8') + '\n})', ctx, { filename: file })(m, m.exports, req);
  return m.exports;
}
const ipcLog = [];                           // 渲染进程发给主进程的 IPC（send）
const injCalls = [];                         // 输入注入器（被控端）收到的调用
const injRec = { init: () => ({ ok: true, backend: 'fake' }), setActive: on => injCalls.push(['active', on]), handle: c => injCalls.push(['handle', c]), close: () => injCalls.push(['close']), releaseAll() {} };
function req(name) {
  if (name === 'electron') return { ipcRenderer: new Proxy({ invoke: async () => ({ ok: true }), send: (...a) => ipcLog.push(a) }, { get: (t, k) => (k in t ? t[k] : () => {}) }), clipboard: { readText: () => 'hello' } };
  if (name === 'net') return { createServer: () => anything(), connect: () => anything() };
  if (name === 'dgram') return { createSocket: () => anything() };
  if (name === './inject') return { createInjector: () => injRec };
  if (name === './inject-win') return { factories: [] };
  if (name === './proto' || name === './controller' || name === './lossless' || name === './matchcode' || name === './netutil') return loadInCtx(path.join(dir, name + '.js'));
  return require(name);
}
sandbox.require = req;
const run = code => vm.runInContext(code, ctx);

/* ───────── 1. renderer.js 能整个加载 ───────── */
ok('renderer.js 能在假环境里完整加载（不会在加载时抛「先使用后定义」之类的错）', () => {
  vm.runInContext(fs.readFileSync(path.join(dir, 'renderer.js'), 'utf8'), ctx, { filename: 'renderer.js' });
});

/* ───────── 2. 控制安卓：手指 / 鼠标 ───────── */
const sent = [];
function startControl(platform) {
  sent.length = 0;
  sandbox.__s = { alive: true, canControl: true, peerPlatform: platform, peerName: 'phone', sendJson: (t, o) => sent.push(o) };
  run('ctlSetup(__s); ctlEnable(true);');
  run('lastL = { dx: 100, dy: 50, dw: 400, dh: 500, rel: 1, ratio: 1.2 };');   // 手机画面显示在 (100,50)，大小 400×500
  assert.strictEqual(run('CTL.on'), true, '进入控制模式失败');
}
const cvL = type => $el('#cv')._l[type];
const fire = (type, ev) => { const base = { preventDefault() {}, button: 0, buttons: 1, getCoalescedEvents: () => [] }; const e = Object.assign(base, ev, { type }); for (const fn of cvL(type) || []) fn(e); return e; };
const tick = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  startControl('android');
  ok('手指点一下手机画面（触屏）→ 发出 pd + pu（鼠标键盘语义，手机端自己翻译成触摸），坐标换算成 0..1', () => {
    fire('pointerdown', { pointerType: 'touch', pointerId: 7, clientX: 300, clientY: 300, timeStamp: 1000 });
    fire('pointerup', { pointerType: 'touch', pointerId: 7, clientX: 300, clientY: 300, timeStamp: 1060, buttons: 0 });
    const d = sent.find(c => c.t === 'pd'), u = sent.find(c => c.t === 'pu');
    assert.ok(d && u, '没有发出 pd / pu：' + JSON.stringify(sent));
    assert.deepStrictEqual([d.x, d.y], [0.5, 0.5]);
    assert.deepStrictEqual([u.x, u.y], [0.5, 0.5]);
  });

  sent.length = 0;
  fire('pointerdown', { pointerType: 'touch', pointerId: 8, clientX: 200, clientY: 100, timeStamp: 2000 });
  fire('pointermove', { pointerType: 'touch', pointerId: 8, clientX: 200, clientY: 200, timeStamp: 2030 });
  fire('pointermove', { pointerType: 'touch', pointerId: 8, clientX: 200, clientY: 300, timeStamp: 2060 });
  await tick(40);
  fire('pointerup', { pointerType: 'touch', pointerId: 8, clientX: 200, clientY: 300, timeStamp: 2100, buttons: 0 });
  ok('手指在画面上拖动（触屏）→ pd、pm（连续轨迹）、pu 都发出', () => {
    assert.ok(sent.some(c => c.t === 'pd') && sent.some(c => c.t === 'pm') && sent.some(c => c.t === 'pu'), JSON.stringify(sent));
    const m = sent.filter(c => c.t === 'pm').flatMap(c => c.p);
    assert.ok(m.length >= 2 && m[m.length - 1][1] > m[0][1], '向下拖动的 y 应当递增');
  });

  sent.length = 0;
  fire('pointerdown', { pointerType: 'mouse', pointerId: 1, clientX: 300, clientY: 300, timeStamp: 3000 });
  fire('pointerup', { pointerType: 'mouse', pointerId: 1, clientX: 300, clientY: 300, timeStamp: 3040, buttons: 0 });
  ok('鼠标左键点一下 → pd + pu', () => assert.ok(sent.some(c => c.t === 'pd') && sent.some(c => c.t === 'pu'), JSON.stringify(sent)));

  sent.length = 0;
  fire('pointerdown', { pointerType: 'mouse', pointerId: 1, button: 2, buttons: 2, clientX: 300, clientY: 300, timeStamp: 3100 });
  ok('鼠标右键 → pd(r)（手机端无障碍服务把右键翻译成长按）', () => assert.strictEqual(JSON.stringify(sent), JSON.stringify([{ t: 'pd', b: 'r', x: 0.5, y: 0.5 }])));   // 跨运行域，按 JSON 比较

  sent.length = 0;
  const wheelFns = $el('#cv')._l.wheel || [];
  for (const fn of wheelFns) fn({ preventDefault() {}, clientX: 300, clientY: 300, deltaX: 0, deltaY: 100, deltaMode: 0 });
  await tick(200);
  ok('鼠标滚轮 → 一次滑动 w', () => assert.ok(sent.some(c => c.t === 'w' && c.dy > 0), JSON.stringify(sent)));
  ok('滚轮向下 100px（画面高 500px）→ 安卓端手指应向上移 20% 屏高：sy = -0.2', () => {
    const w = sent.find(c => c.t === 'w');
    assert.ok(Math.abs(w.sy + 0.2) < 1e-6 && Math.abs(w.sx) < 1e-9, JSON.stringify(w));
  });

  /* 贴边容差：鼠标滑出画面 14px 以内仍算「在边上」（夹到边缘），更远才算黑边——否则够不到对方画面最顶端的按钮 */
  sent.length = 0;
  fire('pointerdown', { pointerType: 'mouse', pointerId: 1, clientX: 300, clientY: 40, timeStamp: 3200 });       // 画面顶 y=50，上方 10px
  fire('pointerup', { pointerType: 'mouse', pointerId: 1, clientX: 300, clientY: 40, timeStamp: 3240, buttons: 0 });
  ok('鼠标按在画面上方 10px 的黑边里 → 夹到画面最上沿（y=0），不被忽略', () => {
    const d = sent.find(c => c.t === 'pd');
    assert.ok(d && d.y === 0 && d.x === 0.5, JSON.stringify(sent));
  });
  sent.length = 0;
  fire('pointerdown', { pointerType: 'mouse', pointerId: 1, clientX: 300, clientY: 10, timeStamp: 3300 });       // 上方 40px：真的在黑边里
  fire('pointerup', { pointerType: 'mouse', pointerId: 1, clientX: 300, clientY: 10, timeStamp: 3340, buttons: 0 });
  ok('离画面 40px 以外的黑边：仍然忽略', () => assert.ok(!sent.some(c => c.t === 'pd'), JSON.stringify(sent)));

  /* 残留触点：以前一个没收到 pointerup 的触点会让之后所有单指都被当成「两指」而忽略 */
  sent.length = 0;
  fire('pointerdown', { pointerType: 'touch', pointerId: 21, clientX: 300, clientY: 300, timeStamp: 4000 });   // 这个手指的 up 永远不来
  for (const fn of winL.blur || []) fn({});                                                                  // 窗口失焦（比如弹出屏幕键盘）
  sent.length = 0;
  fire('pointerdown', { pointerType: 'touch', pointerId: 22, clientX: 320, clientY: 320, timeStamp: 4500 });
  fire('pointerup', { pointerType: 'touch', pointerId: 22, clientX: 320, clientY: 320, timeStamp: 4550, buttons: 0 });
  ok('窗口失焦后残留触点被清掉，之后的单指点按仍然有效', () => assert.ok(sent.some(c => c.t === 'pd') && sent.some(c => c.t === 'pu'), JSON.stringify(sent)));

  /* 控制电脑（鼠标键盘语义）也要能发 */
  startControl('windows');
  fire('pointerdown', { pointerType: 'mouse', pointerId: 1, clientX: 300, clientY: 300, timeStamp: 5000 });
  fire('pointerup', { pointerType: 'mouse', pointerId: 1, clientX: 300, clientY: 300, timeStamp: 5040, buttons: 0 });
  ok('控制电脑：鼠标左键点一下 → pd + pu', () => assert.ok(sent.some(c => c.t === 'pd') && sent.some(c => c.t === 'pu'), JSON.stringify(sent)));

  /* 异常不再被悄悄吞掉：故意让发送函数抛错，应当出现在诊断里 */
  startControl('android');
  sandbox.__s.sendJson = () => { throw new Error('boom'); };
  fire('pointerdown', { pointerType: 'touch', pointerId: 31, clientX: 300, clientY: 300, timeStamp: 6000 });
  ok('事件处理里的异常会被提示并记入诊断（而不是静默失败）', () => assert.ok(/boom/.test(run('DIAG.err')), run('DIAG.err')));

  /* 被控端：手机发来的 T_INPUT 必须由「渲染进程里」的注入器执行，不能再转交主进程。
   * 主进程的线程同时是瞬流自己窗口的 UI 线程：对方点瞬流窗口的最小化 / 最大化 / 关闭时，Windows 在这个线程里进入按钮跟踪的模态循环，
   * 等鼠标抬起才返回；「抬起」指令若还排在主线程队列里就永远到不了，整个控制死锁。 */
  {
    let attach = null;
    ipcLog.length = 0; injCalls.length = 0;
    sandbox.__src = { alive: true, ctlAllowed: true, peerName: 'phone', peerPlatform: 'android', peerCaps: [], maxBacklog: 0,
      sendJson() {}, sendCtrl() {}, sendVideo() {}, sendLossless() {}, close() {}, attach(fn) { attach = fn; }, sock: { writableLength: 0 } };
    run('startSource(__src)');
    ok('被控会话开始 → 渲染进程里的注入器被激活', () => assert.ok(injCalls.some(c => c[0] === 'active' && c[1] === true), JSON.stringify(injCalls)));
    ok('被控会话开始 → 仍通知主进程（全局热键 / 被控期间关窗口 = 最小化）', () => assert.ok(ipcLog.some(a => a[0] === 'ctl-active' && a[1] && a[1].on === true), JSON.stringify(ipcLog)));
    assert.ok(attach, 'startSource 没有注册收包回调');
    for (const cmd of [{ t: 'pd', b: 'l', x: 0.99, y: 0.001 }, { t: 'pu', b: 'l' }]) attach(22, 0, 0, Buffer.from(JSON.stringify(cmd)));
    ok('T_INPUT（按下 + 抬起）→ 在渲染进程里直接交给注入器', () => {
      const h = injCalls.filter(c => c[0] === 'handle').map(c => JSON.stringify(c[1]));
      assert.deepStrictEqual(h, ['{"t":"pd","b":"l","x":0.99,"y":0.001}', '{"t":"pu","b":"l"}']);
    });
    ok('T_INPUT 不再经过主进程 IPC（不再有 inject 消息）', () => assert.ok(!ipcLog.some(a => a[0] === 'inject'), JSON.stringify(ipcLog)));
    await tick(60);                                   // 假环境里拿不到屏幕流 → 会话自行结束
    ok('会话结束 → 注入器停用（松开还按着的键）并通知主进程', () => {
      assert.ok(injCalls.some(c => c[0] === 'active' && c[1] === false), JSON.stringify(injCalls));
      assert.ok(ipcLog.some(a => a[0] === 'ctl-active' && a[1] && a[1].on === false), JSON.stringify(ipcLog));
    });
  }

  console.log('\n' + pass + ' 项通过');
  process.exit(failed ? 1 : 0);
})();
