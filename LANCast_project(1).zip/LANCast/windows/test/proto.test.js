'use strict';
// node windows/test/proto.test.js
// 左边：windows/proto.js（Windows 端实现）。右边：按 android/.../Net.kt 逐行翻译的「安卓对端」（独立实现，不 require proto.js），通过真实 TCP 对跑。
const net = require('net'), crypto = require('crypto'), assert = require('assert');
const proto = require('../proto');
const H = 16, T = { HELLO: 1, CHALLENGE: 2, ACCEPT: 3, REJECT: 4 };
const hmac = (k, m) => crypto.createHmac('sha256', k).update(m).digest('hex');
const pkt = (type, o) => { const b = Buffer.from(JSON.stringify(o)), h = Buffer.alloc(H); h[0] = type; h.writeUInt32BE(b.length, 4); return Buffer.concat([h, b]); };
function reader(sock, cb) { let buf = Buffer.alloc(0); sock.on('data', d => { buf = Buffer.concat([buf, d]); while (buf.length >= H) { const n = buf.readUInt32BE(4); if (buf.length < H + n) break; cb(buf[0], JSON.parse(buf.slice(H, H + n).toString())); buf = buf.slice(H + n); } }); }

/* Windows 服务端（renderer.js onIncoming + acceptSession 的等价流程）。decide(s) 决定 ctlAllowed */
function winServer(pin, decide, tamper) {
  return new Promise(res => {
    const srv = net.createServer(sock => {
      const nonce = crypto.randomBytes(16).toString('hex');
      sock.write(pkt(T.CHALLENGE, proto.buildChallenge(nonce, 'PC', 'winid0000000001')));
      reader(sock, (t, j) => {
        if (t !== T.HELLO) return;
        const h = proto.readHello(j, nonce, pin);
        if (!h) { sock.write(pkt(T.REJECT, { reason: 'bad auth' })); return; }
        const ctlAllowed = decide(h);
        let acc = proto.buildAccept({ ctlReq: h.ctlReq, ctlAllowed, clientNonce: h.clientNonce, nonce, pin });
        if (tamper) acc = tamper(acc);
        sock.write(pkt(T.ACCEPT, acc)); srv.lastHello = h; setTimeout(() => sock.end(), 30);
      });
    }).listen(0, '127.0.0.1', () => res(srv));
  });
}
/* 安卓客户端（Session.connect 的等价流程） */
function androidClient(port, pin, mode, ctl, requiresProof, verHello = 2) {
  return new Promise((resolve, reject) => {
    const s = net.connect(port, '127.0.0.1'), cn = crypto.randomBytes(16).toString('hex'); let ch;
    s.on('error', reject);
    reader(s, (t, j) => {
      if (t === T.CHALLENGE) { ch = j; const h = { ver: verHello, name: 'phone', platform: 'android', mode, id: 'andid00000000001', caps: ['file', 'ctl'], cn, auth: hmac(pin, j.nonce) }; if (ctl) h.ctl = ctl; s.write(pkt(T.HELLO, h)); }
      else if (t === T.REJECT) reject(new Error(j.reason));
      else if (t === T.ACCEPT) {
        const proofOk = j.proof === hmac(pin, 'srv:' + ch.nonce + ':' + cn);
        if (verHello >= 2 && ((ch.ver || 1) >= 2 || requiresProof) && !proofOk) { s.destroy(); return reject(new Error('对方未通过身份校验')); }
        resolve({ proofOk, peerVer: Math.max(ch.ver || 1, j.ver || 1), canControl: proofOk && ctl === 'req' && j.ctl === true, platform: ch.platform, name: ch.name }); s.destroy();
      }
    });
  });
}

let pass = 0; const queue = [];
const ok = (n, f) => queue.push([n, f]);
const PIN = '4815162342';

ok('安卓 pull + 请求控制 → Windows 用户同意 → 安卓拿到 canControl，且 proof 通过', async () => {
  const srv = await winServer(PIN, h => h.ctlReq);
  const r = await androidClient(srv.address().port, PIN, 'pull', 'req', false);
  assert.ok(r.proofOk && r.canControl && r.peerVer === 2 && r.platform === 'windows');
  assert.ok(srv.lastHello.ctlReq && srv.lastHello.peerVer === 2); srv.close();
});
ok('Windows 用户选「仅允许查看」→ 安卓 canControl = false（但仍然能看）', async () => {
  const srv = await winServer(PIN, () => false);
  const r = await androidClient(srv.address().port, PIN, 'pull', 'req', false);
  assert.ok(r.proofOk && !r.canControl); srv.close();
});
ok('安卓 push + grant → Windows 记下 ctlGrant（观看窗口出现「控制」）', async () => {
  const srv = await winServer(PIN, () => false);
  await androidClient(srv.address().port, PIN, 'push', 'grant', false);
  assert.ok(srv.lastHello.ctlGrant && !srv.lastHello.ctlReq); srv.close();
});
ok('不请求控制时，ACCEPT 里不带 ctl 字段', async () => {
  const srv = await winServer(PIN, () => true);
  const r = await androidClient(srv.address().port, PIN, 'pull', '', false);
  assert.ok(!r.canControl); srv.close();
});
ok('旧版（v1）安卓连新 Windows：照常成功，不带 proof，ctl 一律无效', async () => {
  const srv = await winServer(PIN, () => true);
  const r = await androidClient(srv.address().port, PIN, 'pull', 'req', false, 1);
  assert.ok(!r.canControl); assert.ok(!srv.lastHello.ctlReq && srv.lastHello.clientNonce === ''); srv.close();
});
ok('错误密钥被拒绝', async () => {
  const srv = await winServer(PIN, () => true);
  await assert.rejects(androidClient(srv.address().port, '0000000000', 'pull', 'req', false), /bad auth/); srv.close();
});
ok('冒充的 Windows（不知道密钥、给了错误 proof）→ 安卓拒绝，控制授权无效', async () => {
  const srv = await winServer(PIN, () => true, a => ({ ...a, proof: hmac('wrong', 'x') }));
  await assert.rejects(androidClient(srv.address().port, PIN, 'pull', 'req', false), /身份校验/); srv.close();
});
ok('防降级：中间人去掉 ver/proof，且安卓已知对方是 v2 → 拒绝', async () => {
  const srv = await winServer(PIN, () => true, a => ({ ok: true, ctl: true }));
  const bad = androidClient(srv.address().port, PIN, 'pull', 'req', true);
  await assert.rejects(bad, /身份校验/); srv.close();
});
ok('Windows 作客户端：checkAccept 的各种情形', () => {
  const nonce = 'ab'.repeat(16), cn = 'cd'.repeat(16), pin = PIN;
  const good = { ok: true, ver: 2, proof: proto.proofHex(pin, nonce, cn), ctl: true };
  let r = proto.checkAccept({ challenge: { nonce, ver: 2 }, accept: good, pin, cn, requiresProof: false, ctl: 'req' });
  assert.ok(r.ok && r.canControl && r.peerVer === 2);
  r = proto.checkAccept({ challenge: { nonce, ver: 2 }, accept: { ok: true, ctl: true }, pin, cn, requiresProof: false, ctl: 'req' });
  assert.ok(!r.ok && /身份校验/.test(r.error));                                   // 自称 v2 却没有 proof
  r = proto.checkAccept({ challenge: { nonce }, accept: { ok: true }, pin, cn, requiresProof: true, ctl: '' });
  assert.ok(!r.ok);                                                              // 防降级
  r = proto.checkAccept({ challenge: { nonce }, accept: { ok: true, ctl: true }, pin, cn, requiresProof: false, ctl: 'req' });
  assert.ok(r.ok && !r.canControl && r.peerVer === 1);                           // v1 对端：行为不变，ctl 无效
  r = proto.checkAccept({ challenge: { nonce, ver: 2 }, accept: { ...good, ctl: false }, pin, cn, requiresProof: false, ctl: 'req' });
  assert.ok(r.ok && !r.canControl);
  r = proto.checkAccept({ challenge: { nonce, ver: 2 }, accept: good, pin, cn, requiresProof: false, ctl: 'grant' });
  assert.ok(r.ok && !r.canControl);                                              // grant 方向本身不产生 canControl
});
ok('readHello：auth 不对 → null；非法 cn 不产生 proof；v1 的 ctl 字段被忽略', () => {
  const nonce = 'ee'.repeat(16);
  assert.strictEqual(proto.readHello({ auth: 'x' }, nonce, PIN), null);
  const a = proto.readHello({ auth: hmac(PIN, nonce), ver: 2, cn: 'ZZ', ctl: 'req' }, nonce, PIN);
  assert.ok(a.clientNonce === '' && a.ctlReq);
  const b = proto.readHello({ auth: hmac(PIN, nonce), ctl: 'req' }, nonce, PIN);
  assert.ok(!b.ctlReq && b.peerVer === 1);
});

(async () => {
  for (const [n, f] of queue) { try { await f(); pass++; console.log('PASS ' + n); } catch (e) { console.log('FAIL ' + n + '\n     ' + e.message); process.exitCode = 1; } }
  console.log('\n' + pass + '/' + queue.length + ' 项通过'); process.exit(process.exitCode || 0);
})();
