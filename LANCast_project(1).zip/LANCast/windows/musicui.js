'use strict';
/* 瞬流「沉浸音乐」电脑端：接收手机发来的无损音频流 + 歌曲信息，渲染成实时播放器，并把控制指令发回手机。
 * 协议与断线续传见 music.js 文件头 / docs/PROTOCOL.md 第 23 节。
 *
 * 保活要点（电脑端）：
 *  · 播放期间阻止系统「应用挂起」（屏幕仍可熄灭）；窗口最小化 / 被遮挡不降速（main.js 已关闭后台节流）。
 *  · 手机重连时（同一个 sid）直接接管新连接，播放器、已缓冲的音频、封面都保留，只是告诉手机「从第 N 帧继续」。
 *  · 每 500 ms 向手机确认已收到的帧序号（也是应用层心跳）；对方 8 秒没任何动静就判定断线，等手机自动重连。 */
(function () {
  const { ipcRenderer } = require('electron');
  const MT = require('./music');
  const $ = s => document.querySelector(s);
  const T_CTRL = 5;
  const LSget = (k, d) => { try { const v = localStorage.getItem(k); return v === null ? d : v; } catch { return d; } };
  const LSset = (k, v) => { try { localStorage.setItem(k, String(v)); } catch {} };

  /* AudioWorklet：连续环形缓冲 + 时钟漂移补偿。
   * 倍率 = 1 时逐样本原样输出（无任何运算，真无损）；仅当手机 / 电脑声卡时钟漂移让缓冲偏离目标 >40 ms 才用三次插值微调（≤0.2%，见 music.js driftRatio）。 */
  const WORKLET = `
${MT.driftRatio.toString()}
class MPCM extends AudioWorkletProcessor {
  constructor() {
    super();
    this.cap = 1 << 18; this.L = new Float32Array(this.cap); this.R = new Float32Array(this.cap);
    this.wp = 0; this.rp = 0; this.ph = 0; this.ratio = 1; this.on = false; this.pre = 96000; this.rate = sampleRate; this.drift = true;
    this.played = 0; this.tick = 0; this.tickP = 0; this.under = 0;
    this.port.onmessage = e => {
      const d = e.data;
      if (d.cfg) { if (d.cfg.pre) this.pre = d.cfg.pre; if (d.cfg.drift !== undefined) { this.drift = !!d.cfg.drift; if (!this.drift) { this.ratio = 1; this.ph = 0; } } return; }
      if (d.flush !== undefined) {                       // 跳到实时：只保留最新的 flush 帧（切歌 / 拖动进度时丢掉旧音频）
        this.rp = Math.max(this.rp, this.wp - d.flush); this.ph = 0; this.on = false; return;
      }
      this.push(d.l, d.r);                               // 无损：不丢任何音频，积压多少存多少（断线补发时会一次涌进来很多）
    };
  }
  grow(need) {
    let nc = this.cap; while (nc < need) nc <<= 1;
    const nl = new Float32Array(nc), nr = new Float32Array(nc), om = this.cap - 1, nm = nc - 1;
    for (let k = this.rp - 2; k < this.wp; k++) { nl[k & nm] = this.L[k & om]; nr[k & nm] = this.R[k & om]; }
    this.L = nl; this.R = nr; this.cap = nc;
  }
  push(l, r) {
    const n = l.length;
    if (this.wp - this.rp + n + 8 > this.cap) this.grow(this.wp - this.rp + n + 8);
    const m = this.cap - 1;
    for (let i = 0, w = this.wp; i < n; i++, w++) { this.L[w & m] = l[i]; this.R[w & m] = r[i]; }
    this.wp += n;
  }
  process(inputs, outputs) {
    const o = outputs[0], oL = o[0], oR = o[1] || o[0], len = oL.length, m = this.cap - 1, L = this.L, R = this.R;
    if (!this.on && this.wp - this.rp >= this.pre) this.on = true;
    let i = 0;
    if (this.on) {
      if (this.drift && ++this.tick % 50 === 0) {
        const r = driftRatio(this.wp - this.rp, this.pre, this.rate, this.ratio !== 1);
        if (r === 1 && this.ratio !== 1) this.ph = 0;
        this.ratio = r;
      }
      if (this.ratio === 1) {
        const n = Math.min(len, this.wp - this.rp);
        for (; i < n; i++, this.rp++) { const k = this.rp & m; oL[i] = L[k]; oR[i] = R[k]; }
      } else {
        const rt = this.ratio;
        for (; i < len && this.wp - this.rp >= 3; i++) {
          const t = this.ph, t2 = t * t, t3 = t2 * t, a = (this.rp - 1) & m, b = this.rp & m, c = (this.rp + 1) & m, d = (this.rp + 2) & m;
          const w0 = -0.5 * t3 + t2 - 0.5 * t, w1 = 1.5 * t3 - 2.5 * t2 + 1, w2 = -1.5 * t3 + 2 * t2 + 0.5 * t, w3 = 0.5 * t3 - 0.5 * t2;
          oL[i] = L[a] * w0 + L[b] * w1 + L[c] * w2 + L[d] * w3;
          oR[i] = R[a] * w0 + R[b] * w1 + R[c] * w2 + R[d] * w3;
          this.ph += rt; while (this.ph >= 1) { this.ph -= 1; this.rp++; }
        }
      }
      this.played += i;
      if (i < len) { this.on = false; this.under++; this.ph = 0; this.ratio = 1; }   // 欠载：重新缓冲到预缓冲量再放，避免断断续续
    }
    for (; i < len; i++) { oL[i] = 0; oR[i] = 0; }
    if (++this.tickP % 20 === 0) this.port.postMessage({ q: this.wp - this.rp, played: this.played, on: this.on, ratio: this.ratio, under: this.under });
    return true;
  }
}
registerProcessor('mpcm', MPCM);`;

  const CSS = `
#musicOv{--ac:255,255,255;position:fixed;inset:0;z-index:5;color:#fff;background:#0b0d12;overflow:hidden;user-select:none;font-family:"Segoe UI","Microsoft YaHei",system-ui,sans-serif}
#musicOv[hidden]{display:none}
#musicOv .mbg{position:absolute;inset:-80px;background-size:cover;background-position:center;filter:blur(64px) saturate(1.5) brightness(.5);transform:scale(1.2);opacity:0;transition:opacity .8s;will-change:opacity}
#musicOv .mbg.on{opacity:1}
#musicOv .mglow{position:absolute;inset:0;background:radial-gradient(ellipse at 30% 55%,rgba(var(--ac),.28),transparent 60%);opacity:var(--pulse,.4);will-change:opacity}
#musicOv .mshade{position:absolute;inset:0;background:linear-gradient(180deg,rgba(0,0,0,.25),rgba(0,0,0,.55))}
#musicOv .mtop{position:absolute;top:0;left:0;right:0;display:flex;align-items:center;gap:10px;padding:14px 20px;z-index:2;font-size:13px;color:rgba(255,255,255,.8)}
#musicOv .mtop .sp{flex:1}
#musicOv button{font:inherit;color:#fff;background:rgba(255,255,255,.14);border:0;border-radius:999px;padding:7px 16px;cursor:pointer;transition:background .15s,transform .12s}
#musicOv button:hover{background:rgba(255,255,255,.26)}
#musicOv button:active{transform:scale(.94)}
#musicOv button:disabled{opacity:.35;cursor:default;transform:none}
#musicOv button.on{background:rgba(var(--ac),.45)}
#musicOv .mmain{position:absolute;inset:56px 0 0;display:flex;align-items:center;justify-content:center;gap:clamp(24px,5vw,72px);padding:0 5vw 24px;z-index:1}
#musicOv .mcoverw{flex:none;width:min(42vh,360px,38vw);aspect-ratio:1;will-change:transform}
#musicOv .mcover{width:100%;height:100%;border-radius:18px;background:rgba(255,255,255,.08);box-shadow:0 24px 60px rgba(0,0,0,.55),0 0 var(--glow,30px) rgba(var(--ac),.35);overflow:hidden;display:flex;align-items:center;justify-content:center;font-size:84px;color:rgba(255,255,255,.35)}
#musicOv .mcover img{width:100%;height:100%;object-fit:cover;display:block;animation:mfade .5s}
#musicOv .mcover img[hidden]{display:none}
@keyframes mfade{from{opacity:0;filter:blur(8px)}to{opacity:1;filter:none}}
@keyframes mrise{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}
#musicOv .mtxt.swap{animation:mrise .45s}
#musicOv .mpanel{flex:1;min-width:0;max-width:520px;display:flex;flex-direction:column;gap:14px}
#musicOv .mtitle{font-size:clamp(22px,3.4vw,34px);font-weight:700;line-height:1.25;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}
#musicOv .msub{font-size:clamp(14px,1.6vw,18px);color:rgba(255,255,255,.75);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#musicOv .mapp{font-size:12px;color:rgba(255,255,255,.5)}
#musicOv canvas.mviz{width:100%;height:64px;display:block}
#musicOv .mprog{display:flex;align-items:center;gap:10px;font-size:12px;color:rgba(255,255,255,.7);font-variant-numeric:tabular-nums}
#musicOv .mbar{flex:1;height:22px;display:flex;align-items:center;cursor:pointer;position:relative;touch-action:none}
#musicOv .mbar i{display:block;width:100%;height:5px;border-radius:3px;background:rgba(255,255,255,.22);position:relative;transition:height .12s}
#musicOv .mbar:hover i,#musicOv .mbar.drag i{height:8px}
#musicOv .mbar b{position:absolute;left:0;top:0;bottom:0;width:100%;transform-origin:left;transform:scaleX(0);background:rgb(var(--ac));border-radius:3px;box-shadow:0 0 10px rgba(var(--ac),.7);will-change:transform}
#musicOv .mbar u{position:absolute;top:50%;left:0;width:13px;height:13px;margin:-6.5px 0 0 -6.5px;border-radius:50%;background:#fff;box-shadow:0 1px 6px rgba(0,0,0,.5);opacity:0;transition:opacity .12s;will-change:transform;pointer-events:none}
#musicOv .mbar:hover u,#musicOv .mbar.drag u{opacity:1}
#musicOv .mbar s{position:absolute;bottom:20px;left:0;padding:2px 7px;border-radius:6px;background:rgba(0,0,0,.75);font-size:11px;text-decoration:none;opacity:0;pointer-events:none;transform:translateX(-50%)}
#musicOv .mbar:hover s,#musicOv .mbar.drag s{opacity:1}
#musicOv .mctl{display:flex;align-items:center;justify-content:center;gap:18px}
#musicOv .mctl button{width:52px;height:52px;padding:0;font-size:20px;display:flex;align-items:center;justify-content:center}
#musicOv .mctl button.sm{width:40px;height:40px;font-size:15px}
#musicOv .mctl button.big{width:68px;height:68px;font-size:26px;background:#fff;color:#111}
#musicOv .mctl button.big:hover{background:#e8e8e8}
#musicOv .mrow{display:flex;align-items:center;gap:12px;flex-wrap:wrap;font-size:12.5px;color:rgba(255,255,255,.75)}
#musicOv .mrow input[type=range]{width:120px;accent-color:rgb(var(--ac))}
#musicOv .mrow button{padding:4px 11px;font-size:12.5px}
#musicOv .mrow select{background:rgba(255,255,255,.14);color:#fff;border:0;border-radius:6px;padding:4px 6px}
#musicOv .mrow select option{color:#111}
#musicOv .mstat{font-size:12px;color:rgba(255,255,255,.6);line-height:1.6}
#musicOv .mstat.warn{color:#ffd28a}
#musicOv .mstat.bad{color:#ff9d9d}
#musicOv .mkeys{font-size:11px;color:rgba(255,255,255,.38)}
@media (max-width:820px){#musicOv .mmain{flex-direction:column;gap:18px;overflow:auto;align-items:center;justify-content:flex-start;padding-top:8px}#musicOv .mcoverw{width:min(44vh,70vw)}#musicOv .mpanel{width:100%}}
#musicMini{position:fixed;right:16px;bottom:16px;z-index:6;max-width:360px;display:flex;align-items:center;gap:8px;padding:6px 8px 6px 6px;border-radius:999px;background:#12151c;color:#fff;font-size:13px;cursor:pointer;box-shadow:0 6px 24px rgba(0,0,0,.35)}
#musicMini[hidden]{display:none}
#musicMini img{width:34px;height:34px;border-radius:50%;object-fit:cover;flex:none;background:#2a2e38}
#musicMini .mt{min-width:0;flex:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;padding:0 4px}
#musicMini button{flex:none;width:30px;height:30px;border:0;border-radius:50%;background:rgba(255,255,255,.12);color:#fff;cursor:pointer;font-size:13px;padding:0}
#musicMini button:hover{background:rgba(255,255,255,.26)}
#musicMini button:disabled{opacity:.35}
`;

  const HTML = `
<div class="mbg"></div><div class="mglow"></div><div class="mshade"></div>
<div class="mtop"><span id="mHead">沉浸音乐</span><span class="sp"></span><button id="mFs" title="全屏（F）">全屏</button><button id="mHide" title="收起到右下角，音乐继续播放（Esc）">收起</button><button id="mEnd" title="结束并通知手机停止">断开</button></div>
<div class="mmain">
  <div class="mcoverw" id="mCoverW"><div class="mcover" id="mCover"><img id="mImg" hidden alt=""><span id="mPh">♪</span></div></div>
  <div class="mpanel">
    <div class="mtxt" id="mTxt"><div class="mtitle" id="mTitle">等待手机开始播放…</div><div class="msub" id="mSub"></div><div class="mapp" id="mApp"></div></div>
    <canvas class="mviz" id="mViz"></canvas>
    <div class="mprog"><span id="mCur">0:00</span><div class="mbar" id="mBar"><i><b id="mFill"></b></i><u id="mThumb"></u><s id="mTip">0:00</s></div><span id="mDur">0:00</span></div>
    <div class="mctl"><button id="mPrev" title="上一首（Ctrl+← / P）">⏮</button><button id="mBack" class="sm" title="后退 5 秒（←）">−5</button><button id="mPlay" class="big" title="播放 / 暂停（空格 / 键盘媒体键）">▶</button><button id="mFwd" class="sm" title="快进 5 秒（→）">+5</button><button id="mNext" title="下一首（Ctrl+→ / N）">⏭</button></div>
    <div class="mrow">
      <button id="mMute" title="静音（M）">🔊</button><input id="mVol" type="range" min="0" max="100" step="1" title="音量（↑ / ↓）">
      <label>缓冲 <select id="mBuf"><option value="0.5">0.5 秒</option><option value="1">1 秒</option><option value="2">2 秒</option><option value="5">5 秒</option><option value="10">10 秒</option></select></label>
      <label title="手机与电脑声卡时钟有微小差异，长时间播放缓冲会慢慢变多或变少。开启：偏差超过 40 ms 才以 ≤0.2% 倍率微调（听不出）；其余时间逐样本原样输出。关闭：绝不改动样本，但可能偶尔欠载重缓冲。">时钟同步 <select id="mDrift"><option value="1">开</option><option value="0">关</option></select></label>
      <button id="mPMute" title="让手机本机不出声（电脑照常播放，音量由电脑控制）">📱 手机静音</button>
      <button id="mLive" title="丢掉电脑端积压的音频，直接跟上手机当前播放的位置">跳到实时</button>
    </div>
    <div class="mstat" id="mStat"></div>
    <div class="mkeys">空格 播放/暂停 · ←/→ 快退/快进 5 秒 · Ctrl+←/→ 或 P/N 上/下一首 · ↑/↓ 音量 · M 静音 · F 全屏 · Esc 收起 · 键盘媒体键全局可用</div>
  </div>
</div>`;

  let ov = null, mini = null, M = null, tickT = 0, ackT = 0, raf = 0, shown = true, drag = null, hoverF = 0;
  let accent = '255,255,255', lastKey = '', vizW = 0, vizH = 0, dpr = 1, bass = 0, pulse = 0.4, scaleCur = 0.92;
  const bars = new Uint8Array(1024), BN = 56, hv = new Float32Array(BN), pk = new Float32Array(BN);

  function ensureDom() {
    if (ov) return;
    const st = document.createElement('style'); st.textContent = CSS; document.head.appendChild(st);
    ov = document.createElement('div'); ov.id = 'musicOv'; ov.hidden = true; ov.innerHTML = HTML; document.body.appendChild(ov);
    mini = document.createElement('div'); mini.id = 'musicMini'; mini.hidden = true;
    mini.innerHTML = '<img id="miImg" alt="" hidden><span class="mt" id="miTxt"></span><button data-c="prev" title="上一首">⏮</button><button data-c="toggle" id="miPlay" title="播放 / 暂停">▶</button><button data-c="next" title="下一首">⏭</button>';
    mini.onclick = e => { const b = e.target.closest && e.target.closest('button[data-c]'); if (b) { cmd(b.dataset.c); e.stopPropagation(); } else show(true); };
    document.body.appendChild(mini);
    $('#mHide').onclick = () => show(false);
    $('#mEnd').onclick = () => end('已断开', true);
    $('#mFs').onclick = toggleFs;
    $('#mCoverW').ondblclick = toggleFs;
    $('#mPrev').onclick = () => cmd('prev'); $('#mNext').onclick = () => cmd('next');
    $('#mPlay').onclick = () => cmd('toggle');
    $('#mBack').onclick = () => seekBy(-5000); $('#mFwd').onclick = () => seekBy(5000);
    $('#mPMute').onclick = () => { if (M && M.meta) cmd('pmute', { on: !M.meta.pmute }); };
    $('#mLive').onclick = () => { if (M && M.node) { M.node.port.postMessage({ flush: Math.round(M.cfg.rate * 0.3) }); } };
    const vol = $('#mVol'); vol.value = LSget('music:vol', '100');
    vol.oninput = () => { LSset('music:vol', vol.value); if (vol.value > 0) setMute(false); applyGain(); };
    vol.onwheel = e => { e.preventDefault(); stepVol(e.deltaY < 0 ? 5 : -5); };
    $('#mMute').onclick = () => setMute(!muted());
    const buf = $('#mBuf'); buf.value = LSget('music:buf', '2'); if (buf.value !== LSget('music:buf', '2')) buf.value = '2';
    buf.onchange = () => { LSset('music:buf', buf.value); applyBuf(); };
    const dr = $('#mDrift'); dr.value = LSget('music:drift', '1'); dr.onchange = () => { LSset('music:drift', dr.value); applyBuf(); };
    syncMuteBtn();
    // 进度条：悬停显示目标时间，按下拖动预览，松手才真正 seek
    const bar = $('#mBar');
    const frac = e => { const r = bar.getBoundingClientRect(); return Math.min(1, Math.max(0, (e.clientX - r.left) / r.width)); };
    const canSeek = () => M && M.meta && M.meta.duration > 0 && M.meta.can.includes('seek') && M.meta.ctl;
    bar.onpointermove = e => { hoverF = frac(e); if (drag) drag.f = hoverF; };
    bar.onpointerdown = e => { if (!canSeek()) return; drag = { f: frac(e) }; bar.classList.add('drag'); bar.setPointerCapture(e.pointerId); };
    bar.onpointerup = e => {
      if (!drag) return;
      const f = frac(e); drag = null; bar.classList.remove('drag');
      if (canSeek()) cmd('seek', { pos: Math.round(f * M.meta.duration) });
    };
    bar.onpointercancel = () => { drag = null; bar.classList.remove('drag'); };
    document.addEventListener('keydown', e => {
      if (!M || ov.hidden || e.target.closest && e.target.closest('input,textarea,select')) return;
      const k = e.code;
      if (e.altKey || ((e.ctrlKey || e.metaKey) && k !== 'ArrowLeft' && k !== 'ArrowRight')) return;   // 只有 Ctrl+←/→ 属于播放器，其余组合键留给系统 / 其它功能
      if (k === 'Space') cmd('toggle');
      else if (k === 'ArrowRight') { if (e.ctrlKey || e.metaKey) cmd('next'); else seekBy(5000); }
      else if (k === 'ArrowLeft') { if (e.ctrlKey || e.metaKey) cmd('prev'); else seekBy(-5000); }
      else if (k === 'KeyN' || k === 'PageDown') cmd('next');
      else if (k === 'KeyP' || k === 'PageUp') cmd('prev');
      else if (k === 'ArrowUp') stepVol(5); else if (k === 'ArrowDown') stepVol(-5);
      else if (k === 'KeyM') setMute(!muted());
      else if (k === 'KeyF') toggleFs();
      else if (k === 'Escape') { if (document.fullscreenElement) document.exitFullscreen(); else show(false); }
      else return;
      e.preventDefault();
    });
    ipcRenderer.on('music-key', (e, k) => { if (!M) return; if (k === 'toggle') cmd('toggle'); else if (k === 'next') cmd('next'); else if (k === 'prev') cmd('prev'); });
    // 保活：声卡 / 耳机切换、系统唤醒、窗口重新可见后，音频上下文可能被系统挂起，马上恢复
    const wake = () => { if (M && M.ctx && M.ctx.state !== 'running' && M.ctx.state !== 'closed') M.ctx.resume().catch(() => {}); };
    try { navigator.mediaDevices.addEventListener('devicechange', wake); } catch {}
    document.addEventListener('visibilitychange', wake); window.addEventListener('focus', wake);
    if (typeof ResizeObserver === 'function') new ResizeObserver(() => { vizW = 0; }).observe($('#mViz'));
    window.addEventListener('beforeunload', () => { if (M) { try { ipcRenderer.send('keep-awake-music', false); } catch {} } });   // 页面被刷新：别让主进程一直占着防挂起 / 媒体键
  }
  function show(on) { shown = on; if (ov) ov.hidden = !on; if (mini) mini.hidden = on || !M; if (on) { tick(); startViz(); } }
  function toggleFs() {
    try {
      const p = document.fullscreenElement ? document.exitFullscreen() : document.documentElement.requestFullscreen();
      if (p && p.catch) p.catch(() => {});
    } catch {}
  }
  function seekBy(d) {
    if (!M || !M.meta || !(M.meta.duration > 0) || !M.meta.can.includes('seek')) return;
    cmd('seek', { pos: Math.round(Math.min(M.meta.duration, Math.max(0, curPos() + d))) });
  }
  const muted = () => LSget('music:mute', '0') === '1';
  function setMute(v) { LSset('music:mute', v ? 1 : 0); syncMuteBtn(); applyGain(); }
  function syncMuteBtn() { const b = $('#mMute'); if (b) { b.textContent = muted() || Number($('#mVol').value) === 0 ? '🔇' : '🔊'; b.classList.toggle('on', muted()); } }
  function stepVol(d) { const v = $('#mVol'); v.value = Math.min(100, Math.max(0, Number(v.value) + d)); v.oninput(); syncMuteBtn(); }
  function applyGain() {
    syncMuteBtn();
    if (M && M.gain && M.ctx) M.gain.gain.setTargetAtTime(muted() ? 0 : $('#mVol').value / 100, M.ctx.currentTime, 0.03);   // 平滑过渡，拖音量不出“嚓嚓”声
  }

  /* ───────── 音频输出 ───────── */
  function applyBuf() { if (M && M.node && M.cfg) M.node.port.postMessage({ cfg: { pre: Math.round(M.cfg.rate * Number($('#mBuf').value || 2)), drift: $('#mDrift').value !== '0' } }); }
  function setupAudio(cfg) {
    if (M.cfg && M.cfg.rate === cfg.rate && M.cfg.ch === cfg.ch && M.ctx && M.ctx.state !== 'closed') { M.cfg = cfg; return; }
    teardownAudio();
    M.cfg = cfg;
    const ctx = M.ctx = new AudioContext({ sampleRate: cfg.rate, latencyHint: 'playback' });   // 音乐：用更大的输出缓冲换稳定，不追求低延迟
    ctx.onstatechange = () => { if (M && M.ctx === ctx && ctx.state === 'suspended') ctx.resume().catch(() => {}); };
    const url = URL.createObjectURL(new Blob([WORKLET], { type: 'application/javascript' }));
    const pend = M.pend = M.pend || [];
    ctx.audioWorklet.addModule(url).then(() => {
      URL.revokeObjectURL(url);
      if (M.ctx !== ctx) return;
      const node = M.node = new AudioWorkletNode(ctx, 'mpcm', { outputChannelCount: [2] });
      node.port.onmessage = e => { M.level = e.data.q; M.played = e.data.played; M.playing = e.data.on; M.ratio = e.data.ratio; M.under = e.data.under; M.levelAt = performance.now(); };
      const gain = M.gain = ctx.createGain(); gain.gain.value = muted() ? 0 : $('#mVol').value / 100;
      const an = M.an = ctx.createAnalyser(); an.fftSize = 2048; an.smoothingTimeConstant = 0.7; an.minDecibels = -85; an.maxDecibels = -20;
      node.connect(gain); gain.connect(an); an.connect(ctx.destination);
      applyBuf();
      for (const m of pend) node.port.postMessage(m, m.r === m.l ? [m.l.buffer] : [m.l.buffer, m.r.buffer]);
      M.pend = null; ctx.resume().catch(() => {});
    }).catch(e => { console.warn('music worklet', e); M.audioFail = Date.now(); });
  }
  function teardownAudio() { if (M && M.ctx) { try { M.ctx.close(); } catch {} } if (M) { M.ctx = M.node = M.gain = M.an = null; M.level = 0; M.playing = false; } }
  function post(m) {
    if (M.node) M.node.port.postMessage(m, m.r === m.l ? [m.l.buffer] : [m.l.buffer, m.r.buffer]);
    else if (M.pend && M.pend.length < 4000) M.pend.push(m);
  }
  function feed(f, pts, pl) {
    if (!M.cfg) return;
    const a = MT.parseAudio(f, pts, pl, M.cfg.ch);
    const r = M.rx.accept(a.idx, a.frames);
    if (!r) return;
    if (a.silent) {
      for (let left = r.frames; left > 0;) { const n = Math.min(left, M.cfg.rate), z = new Float32Array(n); post({ l: z, r: z }); left -= n; }
    } else {
      post(MT.s16ToPlanar(a.pcm, M.cfg.ch, r.off, r.frames));
    }
  }
  // 音频上下文看门狗：被系统挂起就恢复；上下文被关闭或 worklet 失联就重建（接着播，不丢后续帧）
  const GIVE_UP_MS = 10 * 60 * 1000;                              // 手机断线超过 10 分钟还没回来：结束会话（否则防挂起 / 全局媒体键 / 定时器会一直占着）
  function audioWatchdog() {
    if (M && !M.s && M.dropAt && Date.now() - M.dropAt > GIVE_UP_MS) { end('手机超过 10 分钟没有重连', false); return; }
    if (!M || !M.cfg) return;
    const c = M.ctx;
    if (!c || c.state === 'closed' || (M.audioFail && Date.now() - M.audioFail > 2000)) {
      const cfg = M.cfg; M.audioFail = 0; M.cfg = null; if (c) teardownAudio(); setupAudio(cfg); return;
    }
    if (c.state === 'suspended' || c.state === 'interrupted') c.resume().catch(() => {});
    if (M.node && M.levelAt && c.state === 'running' && performance.now() - M.levelAt > 4000) {   // worklet 4 秒没吭声
      const cfg = M.cfg; M.cfg = null; teardownAudio(); setupAudio(cfg);
    }
  }

  /* ───────── 会话 ───────── */
  function cmd(c, extra) {
    if (!M || !M.s || !M.s.alive || !M.meta || !M.meta.ctl) return;
    M.s.sendJson(MT.T.CMD, Object.assign({ cmd: c }, extra || {}));
    if (c === 'next' || c === 'prev' || c === 'seek') { if (M.node && M.cfg) M.node.port.postMessage({ flush: 0 }); }   // 切歌 / 拖动：旧音频马上丢掉，不要再播一两秒旧的
    if (c === 'seek' && extra) { M.meta = Object.assign({}, M.meta, { pos: extra.pos }); M.metaAt = performance.now(); }       // 先按目标位置显示，不等手机下一次回报，进度条不回弹
    if (c === 'pmute') { M.meta = Object.assign({}, M.meta, { pmute: !!extra.on }); updateMeta(); }
    if (c === 'toggle' || c === 'play' || c === 'pause') { M.meta = Object.assign({}, M.meta, { state: c === 'pause' || (c === 'toggle' && M.meta.state === 'playing') ? 'paused' : 'playing' }); M.metaAt = performance.now(); updateMeta(); }
    tick();
  }

  function sendAck(fresh) {
    if (!M || !M.s || !M.s.alive) return;
    const j = { cmd: 'mack', next: M.rx.started ? M.rx.next : 0 };
    if (fresh) j.fresh = true;
    M.s.sendJson(T_CTRL, j);
  }

  function onPacket(s, t, f, pts, pl) {
    if (!M || M.s !== s) return;
    try {
      if (t === MT.T.ADATA) { feed(f, pts, pl); }
      else if (t === MT.T.META) {
        M.meta = MT.cleanMeta(JSON.parse(pl.toString('utf8'))); M.metaAt = performance.now();
        updateMeta();
      } else if (t === MT.T.COVER) {
        const c = MT.parseCover(pl);
        if (c.hash !== M.coverHash) setCover(c.hash, c.img);
      } else if (t === MT.T.ACONFIG) {
        setupAudio(MT.parseConfig(JSON.parse(pl.toString('utf8'))));
      } else if (t === T_CTRL) {
        const j = JSON.parse(pl.toString('utf8'));
        if (j && j.cmd === 'mstop') end('手机端已结束沉浸音乐', false);
      }
    } catch (e) { console.warn('music packet', t, e.message); }
  }

  function attach(s) {
    s.mode = 'music'; s._lim = 8000;                              // 手机每秒都有心跳 / 进度，8 秒没动静就判定断线，等它重连
    s.onPacket = (t, f, pts, pl) => onPacket(s, t, f, pts, pl);
    s.onClose = reason => {
      if (!M || M.s !== s) return;
      M.s = null; M.dropAt = Date.now();
      M.lastReason = reason;
      tick();
    };
  }

  function onIncoming(s, hello) {
    ensureDom();
    const sid = String((hello && hello.sid) || '').slice(0, 64) || s.peerId || 'default';
    let resumed = false;
    if (M && M.sid === sid) {                                     // 同一次沉浸音乐：手机重连，接管新连接，播放器和缓冲都保留
      const old = M.s; M.s = s; resumed = true; M.dropAt = 0; M.reconnects++;
      if (old) { old.onClose = null; try { old.close('被新连接取代'); } catch {} }
    } else {
      if (M) end('手机开始了新的沉浸音乐', false);
      M = { sid, peerId: s.peerId, peerName: s.peerName, s, rx: new MT.AudioRx(), cfg: null, ctx: null, node: null, gain: null, an: null, pend: null,
            meta: null, metaAt: 0, coverHash: '', coverUrl: '', level: 0, levelAt: 0, played: 0, playing: false, ratio: 1, under: 0, reconnects: 0, dropAt: 0, lastReason: '', since: Date.now(), audioFail: 0 };
      lastKey = ''; accent = '255,255,255'; ov.style.setProperty('--ac', accent);
      ipcRenderer.send('keep-awake-music', true);                  // 播放期间阻止系统挂起应用（屏幕可以熄灭），并接管键盘媒体键
      tickT = setInterval(() => { tick(); audioWatchdog(); }, 250); ackT = setInterval(() => sendAck(false), 500);
      $('#mTitle').textContent = '等待手机开始播放…'; $('#mSub').textContent = ''; $('#mApp').textContent = '';
      $('#mImg').hidden = true; $('#mPh').hidden = false; $('#musicOv .mbg').classList.remove('on');
      show(true);
      try { ipcRenderer.send('focus'); } catch {}
    }
    M.peerName = s.peerName;
    attach(s);
    sendAck(!resumed);                                            // 告诉手机从哪一帧继续（全新会话 = 从实时开始）
    tick();
  }

  function end(reason, tellPhone) {
    if (!M) return;
    const m = M; M = null;
    clearInterval(tickT); clearInterval(ackT); cancelAnimationFrame(raf); raf = 0; drag = null;
    if (m.s) { try { if (tellPhone) m.s.sendJson(T_CTRL, { cmd: 'mstop' }); } catch {} const s = m.s; s.onClose = null; setTimeout(() => { try { s.close(reason); } catch {} }, tellPhone ? 300 : 0); }
    if (m.ctx) { try { m.ctx.close(); } catch {} }
    if (m.coverUrl) URL.revokeObjectURL(m.coverUrl);
    ipcRenderer.send('keep-awake-music', false);
    try { if (document.fullscreenElement) document.exitFullscreen(); } catch {}
    if (ov) ov.hidden = true; if (mini) mini.hidden = true;
    if (typeof setStatus === 'function') setStatus('沉浸音乐已结束：' + reason);
  }

  /* ───────── 界面 ───────── */
  function setCover(hash, img) {
    const mime = MT.imageMime(img);
    if (!mime) return;
    if (M.coverUrl) URL.revokeObjectURL(M.coverUrl);
    const blob = new Blob([Buffer.from(img)], { type: mime });
    M.coverHash = hash; M.coverUrl = URL.createObjectURL(blob);
    pickAccent(blob, hash);
    updateMeta();
  }
  // 从封面取主色：着色进度条 / 频谱 / 背景光晕
  function pickAccent(blob, hash) {
    if (typeof createImageBitmap !== 'function') return;
    createImageBitmap(blob).then(bm => {
      if (!M || M.coverHash !== hash) { try { bm.close(); } catch {} return; }   // 已经换成别的封面了
      const c = document.createElement('canvas'); c.width = c.height = 16;
      const g = c.getContext('2d', { willReadFrequently: true }); g.drawImage(bm, 0, 0, 16, 16);
      const d = g.getImageData(0, 0, 16, 16).data; let r = 0, gg = 0, b = 0, w = 0;
      for (let i = 0; i < d.length; i += 4) {
        const mx = Math.max(d[i], d[i + 1], d[i + 2]), mn = Math.min(d[i], d[i + 1], d[i + 2]), sat = mx ? (mx - mn) / mx : 0, wt = sat * sat * (mx / 255) + 0.01;
        r += d[i] * wt; gg += d[i + 1] * wt; b += d[i + 2] * wt; w += wt;
      }
      let R = r / w, G = gg / w, B = b / w; const mx = Math.max(R, G, B) || 1, k = 215 / mx;     // 提亮到深色背景上看得清
      R = Math.min(255, R * k); G = Math.min(255, G * k); B = Math.min(255, B * k);
      accent = Math.round(R) + ',' + Math.round(G) + ',' + Math.round(B); if (ov) ov.style.setProperty('--ac', accent);
      try { bm.close(); } catch {}
    }).catch(() => {});
  }
  function updateMeta() {
    const m = M.meta; if (!m) return;
    const title = m.title || (m.state === 'none' ? '手机上还没有在播放的音乐' : '未知歌曲'), sub = [m.artist, m.album].filter(Boolean).join(' · ');
    const key = title + '\n' + sub;
    if (key !== lastKey) {                                          // 换歌：文字淡入上浮
      if (lastKey) { const t = $('#mTxt'); t.classList.remove('swap'); void t.offsetWidth; t.classList.add('swap'); }
      lastKey = key;
    }
    $('#mTitle').textContent = title; $('#mSub').textContent = sub;
    $('#mApp').textContent = m.app ? '来自「' + m.app + '」' : '';
    if (!m.cover && M.coverUrl && M.coverFor !== key) {              // 换了一首没有封面的歌：丢掉上一首的封面和主色，别张冠李戴（同一首歌里封面短暂缺失则保留，不闪烁）
      URL.revokeObjectURL(M.coverUrl); M.coverUrl = ''; M.coverHash = '';
      accent = '255,255,255'; if (ov) ov.style.setProperty('--ac', accent);
    }
    const hasCover = !!(M.coverUrl && (m.cover ? m.cover === M.coverHash : M.coverFor === key));
    if (hasCover) M.coverFor = key;
    const img = $('#mImg'); img.hidden = !hasCover; $('#mPh').hidden = !!hasCover;
    if (hasCover && img.src !== M.coverUrl) img.src = M.coverUrl;
    const bg = $('#musicOv .mbg'); bg.classList.toggle('on', !!hasCover);
    if (hasCover) bg.style.backgroundImage = 'url(' + M.coverUrl + ')';
    const can = m.ctl, seek = can && m.can.includes('seek');
    for (const id of ['#mPrev', '#mNext', '#mPlay']) $(id).disabled = !can;
    for (const id of ['#mBack', '#mFwd']) $(id).disabled = !seek || !(m.duration > 0);
    const pb = $('#mPMute'); pb.disabled = !can; pb.classList.toggle('on', !!m.pmute);
    pb.textContent = m.pmute ? '📱 取消手机静音' : '📱 手机静音';
    pb.title = (m.app ? '「' + m.app + '」正在播放。' : '') + (m.pmute ? '手机现在是静音的，点击恢复手机出声' : '让手机本机不出声（电脑照常播放，音量由电脑控制；静音的是手机媒体音量，来电 / 闹钟不受影响）');
    const playing = m.state === 'playing';
    $('#mPlay').textContent = playing ? '⏸' : '▶';
    $('#mHead').textContent = '沉浸音乐 · ' + M.peerName;
    const mi = $('#miImg'); mi.hidden = !hasCover; if (hasCover && mi.src !== M.coverUrl) mi.src = M.coverUrl;
    $('#miTxt').textContent = (m.title || '沉浸音乐') + (m.artist ? ' — ' + m.artist : '');
    $('#miPlay').textContent = playing ? '⏸' : '▶';
    for (const b of mini.querySelectorAll('button')) b.disabled = !can;
  }
  function bufferedMs() { return M && M.cfg ? (M.level / M.cfg.rate) * 1000 : 0; }
  function curPos() {
    const m = M && M.meta; if (!m) return 0;
    return MT.estimatePos(m, M.metaAt ? M.metaAt : performance.now(), performance.now(), bufferedMs());
  }
  // 进度条 / 时间：每帧刷新，丝滑；文字只在秒数变化时改
  let lastSec = -1, lastDur = -1;
  function drawProgress() {
    const m = M.meta; if (!m) return;
    const hasDur = m.duration > 0;
    let f = 0, pos = curPos();
    if (drag && hasDur) { f = drag.f; pos = f * m.duration; }
    else f = hasDur ? Math.min(1, pos / m.duration) : 0;
    $('#mFill').style.transform = 'scaleX(' + f + ')';
    const bw = $('#mBar').clientWidth;
    $('#mThumb').style.transform = 'translateX(' + (f * bw) + 'px)';
    const sec = Math.floor(pos / 1000);
    if (sec !== lastSec) { lastSec = sec; $('#mCur').textContent = MT.fmtTime(pos); }
    const ds = hasDur ? Math.floor(m.duration / 1000) : -1;
    if (ds !== lastDur) { lastDur = ds; $('#mDur').textContent = hasDur ? MT.fmtTime(m.duration) : '--:--'; }
    if (hasDur) { const tip = $('#mTip'); tip.style.left = (hoverF * bw) + 'px'; tip.textContent = MT.fmtTime(hoverF * m.duration); }
  }
  function tick() {
    if (!M || !ov) return;
    mini.hidden = shown;
    const vw = $('#viewer'); ov.style.display = (vw && !vw.hidden) ? 'none' : '';            // 屏幕投屏窗口打开时让位
    const m = M.meta, buf = bufferedMs();
    if (!shown || ov.hidden) { /* 收起时不画动画；进度文字也无需刷新 */ }
    else drawProgress();
    const st = $('#mStat'); let cls = 'mstat', txt;
    const c = M.cfg;
    if (!M.s) {
      cls += ' warn';
      txt = '⟳ 与手机的连接中断了，正在等手机自动重连（此前已重连 ' + M.reconnects + ' 次，本次已等 ' + Math.round((Date.now() - M.dropAt) / 1000) + ' 秒）。\n已缓冲的 ' + (buf / 1000).toFixed(1) + ' 秒音乐会继续播放；手机端缓存了最近 90 秒，重连后会补发，不会丢音。';
    } else {
      txt = '● 已连接 ' + M.s.peerName + (M.s.sock && M.s.sock.remoteAddress ? '（' + String(M.s.sock.remoteAddress).replace(/^::ffff:/, '') + '）' : '') + ' · 往返 ' + Math.round(M.s.rtt || 0) + ' ms';
    }
    if (c) txt += '\n无损 PCM ' + (c.rate / 1000) + ' kHz · 16-bit · ' + (c.ch === 2 ? '立体声' : '单声道') + ' · 电脑端缓冲 ' + (buf / 1000).toFixed(1) + ' 秒' + (M.ratio && M.ratio !== 1 ? ' · 时钟同步 ' + ((M.ratio - 1) * 100).toFixed(2) + '%' : ' · 逐样本原样输出') + (M.under ? ' · 欠载重缓冲 ' + M.under + ' 次' : '') + (M.reconnects ? ' · 自动重连 ' + M.reconnects + ' 次' : '');
    if (M.rx.gapFrames > 0) { cls += ' bad'; txt += '\n⚠ 有 ' + (M.rx.gapFrames / (c ? c.rate : 48000)).toFixed(1) + ' 秒音频因断线超过缓存时长而丢失'; }
    if (m && !m.ctl) txt += '\n手机还没授予「通知使用权」：能听歌，但看不到歌名封面、也不能从电脑控制（手机端「沉浸音乐」里有开启入口）';
    if (txt !== M.lastTxt) { M.lastTxt = txt; st.className = cls; st.style.whiteSpace = 'pre-line'; st.textContent = txt; }
    startViz();
  }
  function startViz() { if (M && shown && ov && !ov.hidden && !raf) raf = requestAnimationFrame(viz); }

  // 频谱 + 节拍联动（封面随低频脉动、背景光晕呼吸、暂停时封面缩小）
  function viz() {
    raf = 0;
    if (!M || ov.hidden || ov.style.display === 'none' || !shown) return;
    const cv = $('#mViz');
    if (!vizW) {
      dpr = window.devicePixelRatio || 1; vizW = cv.clientWidth || 520; vizH = cv.clientHeight || 64;
      cv.width = Math.round(vizW * dpr); cv.height = Math.round(vizH * dpr);
    }
    const g = cv.getContext('2d'), W = vizW, H = vizH;
    g.setTransform(dpr, 0, 0, dpr, 0, 0); g.clearRect(0, 0, W, H);
    const playing = M.meta ? M.meta.state === 'playing' : false;
    let b = 0;
    if (M.an && M.cfg) {
      M.an.getByteFrequencyData(bars);
      const binHz = M.cfg.rate / M.an.fftSize, lo = 40, hi = Math.min(16000, M.cfg.rate / 2 - 100);
      const w = W / BN, ac = accent;
      const grad = g.createLinearGradient(0, H, 0, 0); grad.addColorStop(0, 'rgba(' + ac + ',.35)'); grad.addColorStop(1, 'rgba(' + ac + ',.95)');
      for (let i = 0; i < BN; i++) {
        const f0 = lo * Math.pow(hi / lo, i / BN), f1 = lo * Math.pow(hi / lo, (i + 1) / BN);
        let k0 = Math.floor(f0 / binHz), k1 = Math.max(k0 + 1, Math.ceil(f1 / binHz)), mx = 0;
        for (let k = k0; k < k1 && k < bars.length; k++) if (bars[k] > mx) mx = bars[k];
        const v = Math.pow(mx / 255, 1.15);
        hv[i] = v > hv[i] ? v : hv[i] * 0.86 + v * 0.14;                  // 起音快、回落柔和
        pk[i] = Math.max(hv[i], pk[i] - 0.008);                            // 峰值帽缓慢回落
        const h = Math.max(2, hv[i] * (H - 5)), x = i * w + 1, bw = Math.max(1, w - 3);
        g.fillStyle = grad; g.beginPath(); g.roundRect ? g.roundRect(x, H - h, bw, h, Math.min(3, bw / 2)) : g.rect(x, H - h, bw, h); g.fill();
        g.fillStyle = 'rgba(' + ac + ',.9)'; g.fillRect(x, Math.max(0, H - pk[i] * (H - 5) - 4), bw, 2);
      }
      let sum = 0, n = 0;
      for (let k = 1; k <= 6; k++) { sum += bars[k]; n++; }                // ≈ 23–140 Hz
      b = Math.pow(sum / n / 255, 2.2);
    }
    bass = b > bass ? b : bass * 0.9 + b * 0.1;
    const target = playing ? 1 + 0.045 * bass : 0.9;                        // 暂停：封面微微缩小；播放：随低频脉动
    scaleCur += (target - scaleCur) * (playing ? 0.35 : 0.12);
    $('#mCoverW').style.transform = 'scale(' + scaleCur.toFixed(4) + ')';
    $('#mCover').style.setProperty('--glow', (30 + bass * 70).toFixed(0) + 'px');
    pulse += ((playing ? 0.35 + bass * 0.6 : 0.2) - pulse) * 0.2;
    ov.style.setProperty('--pulse', pulse.toFixed(3));
    drawProgress();
    raf = requestAnimationFrame(viz);
  }

  window.MU = { onIncoming, end, active: () => !!M, _state: () => M };
})();
