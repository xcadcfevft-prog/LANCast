'use strict';
/* 瞬流「极致无损（Beta）」视频格式 —— 纯逻辑（不碰 DOM / socket），方便单元测试。
 * 与 android/.../Lossless.kt 逐字节对应，规范见 docs/PROTOCOL.md 第 6.1 节。
 *
 * 思路：不经过任何有损编码。画面以原生分辨率、源帧率取下来，按 64×64 分块和「上一次已发送的画面」比较，
 * 只发有变化的块（第一帧 / 对方请求关键帧时发整幅）；块里的像素是原始 RGB24，再用 DEFLATE(level 1) 做纯无损压缩。
 * 收到的每个像素都与发送端取到的像素逐位相同。
 *
 * 像素约定：Uint32 小端 = R | G<<8 | B<<16 | A<<24（即 RGBA 字节序；canvas 的 ImageData 也是这个布局）。
 *
 * VFRAME 载荷：
 *   u8 ver(=1) | u8 nStripes | { u16 firstTileRow | u16 tileRows | u32 compLen | compLen 字节 raw-DEFLATE } × nStripes   （全部大端）
 *   解压后 = 变化位图(ceil(tilesX*tileRows/8) 字节，bit i = 条带内第 i 个块，LSB 优先，按行优先) + 各变化块的像素
 *            （每块 tw*th*3 字节，行优先，R G B；边缘块按实际宽高裁剪）
 *   VFRAME.flags bit0 = 整幅画面（所有块都在，接收方可以从这里开始）。
 */
const zlib = require('zlib');
const { promisify } = require('util');
const deflateRaw = promisify(zlib.deflateRaw);
const inflateRaw = promisify(zlib.inflateRaw);

const TILE = 64;
const VER = 1;
const MAX_STRIPES = 8;
const LEVEL = 1;                                  // 速度优先：极致模式要的是不拖帧，压缩率其次

const tilesOf = (w, h) => ({ tx: Math.ceil(w / TILE), ty: Math.ceil(h / TILE) });

/* 条带划分：编码和解码两端都不需要协商，条带头里自带 firstTileRow / tileRows */
function stripeRanges(ty) {
  const n = Math.min(ty, MAX_STRIPES), per = Math.ceil(ty / n), r = [];
  for (let a = 0; a < ty; a += per) r.push([a, Math.min(ty, a + per)]);
  return r;
}

/* 找出相对 prev 有变化的块；prev 为 null 或 full 时全部算变化 */
function diffTiles(cur, prev, w, h, full) {
  const { tx, ty } = tilesOf(w, h), ch = new Uint8Array(tx * ty);
  if (full || !prev) { ch.fill(1); return ch; }
  for (let j = 0; j < ty; j++) {
    const y0 = j * TILE, y1 = Math.min(h, y0 + TILE);
    for (let y = y0; y < y1; y++) {
      const o = y * w;
      for (let i = 0; i < tx; i++) {
        if (ch[j * tx + i]) continue;
        const x0 = i * TILE, x1 = Math.min(w, x0 + TILE);
        for (let p = o + x0, e = o + x1; p < e; p++) if (cur[p] !== prev[p]) { ch[j * tx + i] = 1; break; }
      }
    }
  }
  return ch;
}

/* 编码一幅画面。返回 Buffer（VFRAME 载荷），没有任何变化且不是整幅时返回 null */
async function encode(cur, prev, w, h, full) {
  const { tx, ty } = tilesOf(w, h);
  const ch = diffTiles(cur, prev, w, h, full);
  const jobs = [];
  for (const [r0, r1] of stripeRanges(ty)) {
    const rows = r1 - r0, bm = Math.ceil(tx * rows / 8);
    let n = 0, bytes = 0;
    for (let j = r0; j < r1; j++) for (let i = 0; i < tx; i++) {
      if (!ch[j * tx + i]) continue;
      n++; bytes += Math.min(TILE, w - i * TILE) * Math.min(TILE, h - j * TILE) * 3;
    }
    if (!n) continue;
    const raw = Buffer.alloc(bm + bytes);
    let q = bm, k = 0;
    for (let j = r0; j < r1; j++) for (let i = 0; i < tx; i++, k++) {
      if (!ch[j * tx + i]) continue;
      raw[k >> 3] |= 1 << (k & 7);
      const x0 = i * TILE, x1 = Math.min(w, x0 + TILE), y0 = j * TILE, y1 = Math.min(h, y0 + TILE);
      for (let y = y0; y < y1; y++) for (let p = y * w + x0, e = y * w + x1; p < e; p++) {
        const v = cur[p]; raw[q++] = v & 255; raw[q++] = (v >> 8) & 255; raw[q++] = (v >> 16) & 255;
      }
    }
    jobs.push(deflateRaw(raw, { level: LEVEL }).then(c => ({ r0, rows, c })));
  }
  if (!jobs.length) return null;
  const parts = await Promise.all(jobs);
  let total = 2; for (const p of parts) total += 8 + p.c.length;
  const out = Buffer.allocUnsafe(total);
  out[0] = VER; out[1] = parts.length;
  let o = 2;
  for (const p of parts) {
    out.writeUInt16BE(p.r0, o); out.writeUInt16BE(p.rows, o + 2); out.writeUInt32BE(p.c.length, o + 4);
    p.c.copy(out, o + 8); o += 8 + p.c.length;
  }
  return out;
}

/* 解码端：维护一幅完整画面（px，Uint32 小端 RGBA，不透明），每次 apply 一帧并返回被改动的行区间 */
class Decoder {
  constructor(w, h) {
    this.w = w; this.h = h; this.px = new Uint32Array(w * h).fill(0xFF000000); this.started = false;
  }
  /* payload: Buffer；full: VFRAME.flags bit0。返回 {y0, y1}（改动行 [y0,y1)），格式错误则抛异常 */
  async apply(payload, full) {
    const { w, h } = this, { tx, ty } = tilesOf(w, h);
    if (!this.started && !full) throw new Error('need full frame');
    if (payload.length < 2 || payload[0] !== VER) throw new Error('bad ver');
    const n = payload[1];
    if (n < 1 || n > 255) throw new Error('bad stripes');
    let o = 2;
    const jobs = [];
    for (let s = 0; s < n; s++) {
      if (o + 8 > payload.length) throw new Error('truncated');
      const r0 = payload.readUInt16BE(o), rows = payload.readUInt16BE(o + 2), len = payload.readUInt32BE(o + 4);
      o += 8;
      if (!rows || r0 + rows > ty || o + len > payload.length) throw new Error('bad stripe');
      const maxOut = Math.ceil(tx * rows / 8) + (Math.min(h, (r0 + rows) * TILE) - r0 * TILE) * w * 3;
      jobs.push(inflateRaw(payload.subarray(o, o + len), { maxOutputLength: maxOut }).then(raw => ({ r0, rows, raw })));
      o += len;
    }
    const parts = await Promise.all(jobs);
    const px = this.px;
    let y0 = h, y1 = 0;
    for (const { r0, rows, raw } of parts) {
      const bm = Math.ceil(tx * rows / 8);
      if (raw.length < bm) throw new Error('short stripe');
      let q = bm, k = 0;
      for (let j = r0; j < r0 + rows; j++) for (let i = 0; i < tx; i++, k++) {
        if (!(raw[k >> 3] & (1 << (k & 7)))) continue;
        const x0 = i * TILE, x1 = Math.min(w, x0 + TILE), ya = j * TILE, yb = Math.min(h, ya + TILE);
        if (q + (x1 - x0) * (yb - ya) * 3 > raw.length) throw new Error('short tile data');
        for (let y = ya; y < yb; y++) for (let p = y * w + x0, e = y * w + x1; p < e; p++, q += 3) {
          px[p] = 0xFF000000 | (raw[q + 2] << 16) | (raw[q + 1] << 8) | raw[q];
        }
        if (ya < y0) y0 = ya; if (yb > y1) y1 = yb;
      }
      if (q !== raw.length) throw new Error('stripe size mismatch');
    }
    this.started = true;
    return { y0: Math.min(y0, y1), y1 };
  }
}

module.exports = { TILE, VER, encode, Decoder, diffTiles, stripeRanges };
