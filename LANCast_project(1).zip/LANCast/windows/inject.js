'use strict';
/* 屏幕控制的执行端（Windows 被控）：把观看方发来的 T_INPUT 指令变成真正的鼠标 / 键盘事件。
 * 在主进程里运行（renderer.js 通过 IPC 转交），分三层：
 *   createPlanner()   纯逻辑：指令 → 底层事件列表 [{t:'m',...} | {t:'k',...}]，并记住「按着没松」的键，方便强制松开。可直接在 Node 里测试。
 *   backend           真正调用 Win32 SendInput 的一层（inject-win.js：koffi，不行就退到常驻 PowerShell）。
 *   createInjector()  把两者接起来，管理「本次会话是否允许控制」「卡键保险」「后端自动降级」。
 *
 * 指令格式见 docs/PROTOCOL.md 第 12 节。坐标一律是 0..1 的归一化坐标（相对观看方看到的画面，即被捕获的主显示器）。
 *   pm  {p:[[x,y],...]}            指针移动（一批点）
 *   pd/pu {b:'l|r|m', x?, y?}      鼠标键按下 / 抬起（可带位置）
 *   w   {x?, y?, dx, dy}           滚轮，单位 = 「格」，dy>0 向下滚、dx>0 向右滚（与 DOM WheelEvent 的符号一致，可以是小数）
 *   kd/ku {vk}                     按下 / 抬起一个 Windows 虚拟键码
 *   key {k:'ctrl+shift+esc'}       组合键（修饰键 ctrl/shift/alt/win + 一个主键）
 *   e   {op:'append|del|clear|replace|enter', s?, n?}   文字输入（Unicode，中文 / emoji 都可以）
 *   d/m/u/k                        手机触摸语义的兼容映射：触摸 = 左键拖动；k back/home/recents/notif/quick → 常用快捷键
 *   h                              保活（按住不动时 500ms 一次）
 */

const MF = { MOVE: 0x0001, LDOWN: 0x0002, LUP: 0x0004, RDOWN: 0x0008, RUP: 0x0010, MDOWN: 0x0020, MUP: 0x0040, WHEEL: 0x0800, HWHEEL: 0x1000, ABS: 0x8000 };
const KF = { EXT: 0x0001, UP: 0x0002, UNI: 0x0004 };
const BTN = { l: [MF.LDOWN, MF.LUP], r: [MF.RDOWN, MF.RUP], m: [MF.MDOWN, MF.MUP] };

const VK = { ctrl: 0x11, control: 0x11, shift: 0x10, alt: 0x12, win: 0x5B, meta: 0x5B, cmd: 0x5B, super: 0x5B };
const VK_NAMED = {
  esc: 0x1B, escape: 0x1B, tab: 0x09, enter: 0x0D, return: 0x0D, space: 0x20, bs: 0x08, backspace: 0x08,
  del: 0x2E, delete: 0x2E, ins: 0x2D, insert: 0x2D, home: 0x24, end: 0x23, pgup: 0x21, pageup: 0x21, pgdn: 0x22, pagedown: 0x22,
  left: 0x25, up: 0x26, right: 0x27, down: 0x28, printscreen: 0x2C, prtsc: 0x2C, apps: 0x5D, menu: 0x5D
};
const EXTENDED = new Set([0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x2C, 0x2D, 0x2E, 0x5B, 0x5C, 0x5D, 0x6F, 0x90, 0xA3, 0xA5]);

function keyByName(n) {
  n = String(n || '').toLowerCase();
  if (VK_NAMED[n]) return VK_NAMED[n];
  let m = /^f(\d{1,2})$/.exec(n);
  if (m && +m[1] >= 1 && +m[1] <= 24) return 0x6F + +m[1];
  if (/^[a-z]$/.test(n)) return n.charCodeAt(0) - 32;          // 'a' → 0x41
  if (/^[0-9]$/.test(n)) return n.charCodeAt(0);               // '0' → 0x30
  return 0;
}

const finite = v => typeof v === 'number' && Number.isFinite(v);
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));
const toAbs = v => clamp(Math.round(clamp(Number(v), 0, 1) * 65535), 0, 65535);

function createPlanner() {
  const heldBtn = new Set(), heldKey = new Set();
  let accX = 0, accY = 0;

  const hasXY = c => finite(c.x) && finite(c.y);
  const mv = (x, y) => ({ t: 'm', x: toAbs(x), y: toAbs(y), data: 0, flags: MF.MOVE | MF.ABS });
  function btn(b, down, ops, x, y) {
    if (!BTN[b]) return;
    const f = BTN[b][down ? 0 : 1];
    if (finite(x) && finite(y)) ops.push({ t: 'm', x: toAbs(x), y: toAbs(y), data: 0, flags: f | MF.MOVE | MF.ABS });
    else ops.push({ t: 'm', x: 0, y: 0, data: 0, flags: f });
    if (down) heldBtn.add(b); else heldBtn.delete(b);
  }
  function key(vk, down, ops) {
    vk = vk | 0;
    if (vk < 1 || vk > 254) return;
    ops.push({ t: 'k', vk, scan: 0, flags: (EXTENDED.has(vk) ? KF.EXT : 0) | (down ? 0 : KF.UP) });
    if (down) heldKey.add(vk); else heldKey.delete(vk);
  }
  const tap = (vk, ops) => { key(vk, true, ops); key(vk, false, ops); };
  function combo(str, ops) {
    const mods = [];
    let main = 0;
    for (const raw of String(str || '').toLowerCase().split('+')) {
      const tok = raw.trim();
      if (!tok) continue;
      if (VK[tok]) { if (!mods.includes(VK[tok])) mods.push(VK[tok]); continue; }
      const k = keyByName(tok);
      if (!k || main) return;                                   // 不认识的键 / 两个主键：整条丢弃
      main = k;
    }
    if (!mods.length && !main) return;
    for (const m of mods) key(m, true, ops);
    if (main) tap(main, ops);
    for (let i = mods.length - 1; i >= 0; i--) key(mods[i], false, ops);
  }
  function typeText(s, ops) {
    s = String(s || '').slice(0, 512);
    for (let i = 0; i < s.length; i++) {
      const u = s.charCodeAt(i);
      if (u === 13) continue;                                   // \r
      if (u === 10) { tap(0x0D, ops); continue; }
      if (u === 9) { tap(0x09, ops); continue; }
      ops.push({ t: 'k', vk: 0, scan: u, flags: KF.UNI });
      ops.push({ t: 'k', vk: 0, scan: u, flags: KF.UNI | KF.UP });
    }
  }
  const NAV = { back: 'alt+left', home: 'win', recents: 'win+tab', notif: 'win+n', quick: 'win+a' };

  function plan(c) {
    const ops = [];
    if (!c || typeof c !== 'object') return ops;
    switch (c.t) {
      case 'pm': {
        const pts = Array.isArray(c.p) ? c.p.slice(0, 64) : (hasXY(c) ? [[c.x, c.y]] : []);
        for (const p of pts) if (Array.isArray(p) && finite(p[0]) && finite(p[1])) ops.push(mv(p[0], p[1]));
        break;
      }
      case 'pd': btn(c.b, true, ops, c.x, c.y); break;
      case 'pu': btn(c.b, false, ops, c.x, c.y); break;
      case 'w': {
        if (hasXY(c)) ops.push(mv(c.x, c.y));
        const dy = finite(c.dy) ? clamp(c.dy, -20, 20) : 0, dx = finite(c.dx) ? clamp(c.dx, -20, 20) : 0;
        accY += dy * 120; accX += dx * 120;                    // 触控板的小数滚动累加到整格再发（1 格 = 120）
        const ty = Math.trunc(accY), tx = Math.trunc(accX);
        accY -= ty; accX -= tx;
        if (ty) ops.push({ t: 'm', x: 0, y: 0, data: -ty, flags: MF.WHEEL });
        if (tx) ops.push({ t: 'm', x: 0, y: 0, data: tx, flags: MF.HWHEEL });
        break;
      }
      case 'kd': key(c.vk, true, ops); break;
      case 'ku': key(c.vk, false, ops); break;
      case 'key': combo(c.k, ops); break;
      case 'e': {
        const n = clamp(Number.isInteger(c.n) ? c.n : 1, 1, 64);
        if (c.op === 'append') typeText(c.s, ops);
        else if (c.op === 'del') for (let i = 0; i < n; i++) tap(0x08, ops);
        else if (c.op === 'enter') tap(0x0D, ops);
        else if (c.op === 'clear') { combo('ctrl+a', ops); tap(0x08, ops); }
        else if (c.op === 'replace') { combo('ctrl+a', ops); typeText(c.s, ops); }
        break;
      }
      /* —— 手机触摸语义的兼容映射（旧版 / 通用的观看方）：按下 = 左键按下，移动 = 拖动，抬起 = 左键抬起 —— */
      case 'd': btn('l', true, ops, c.x, c.y); break;
      case 'm': {
        const pts = Array.isArray(c.p) ? c.p.slice(0, 64) : [];
        for (const p of pts) if (Array.isArray(p) && finite(p[0]) && finite(p[1])) ops.push(mv(p[0], p[1]));
        break;
      }
      case 'u': btn('l', false, ops, c.x, c.y); break;
      case 'k': if (NAV[c.k]) combo(NAV[c.k], ops); break;
      default: break;                                          // 'h' 保活等：没有动作
    }
    return ops;
  }
  /* 强制松开所有还按着的键 / 鼠标键（会话结束、保活超时、撤销授权时） */
  function releaseAll() {
    const ops = [];
    for (const b of [...heldBtn]) btn(b, false, ops);
    for (const k of [...heldKey]) key(k, false, ops);
    accX = accY = 0;
    return ops;
  }
  return { plan, releaseAll, hasHeld: () => heldBtn.size > 0 || heldKey.size > 0 };
}

/* ───────────────────────── 注入器 ─────────────────────────
 * factories：后端工厂列表（按优先级）。某个后端创建失败 / 发送时抛异常 → 自动换下一个，所以 koffi 用法有问题时仍能靠 PowerShell 工作。 */
function createInjector({ factories, log = () => {}, onBlocked = () => {}, holdTimeoutMs = 2500 }) {
  const planner = createPlanner();
  let backend = null, idx = 0, lastError = '', active = false, lastCmd = 0, wd = 0, failStreak = 0, blockedNotified = false;

  function ensure() {
    while (!backend && idx < factories.length) {
      try { backend = factories[idx](); log('输入注入后端：' + backend.name); }
      catch (e) { lastError = (e && e.message) || String(e); log('后端 ' + idx + ' 不可用：' + lastError); idx++; }
    }
    return backend;
  }
  function deliver(ops) {
    for (let attempt = 0; attempt < factories.length + 1; attempt++) {
      if (!ensure()) return false;
      try {
        const failed = backend.send(ops) | 0;
        if (failed > 0) {
          failStreak += failed;
          if (failStreak >= 3 && !blockedNotified) { blockedNotified = true; onBlocked(); }
        } else { failStreak = 0; blockedNotified = false; }
        return true;
      } catch (e) {
        lastError = (e && e.message) || String(e);
        log('后端 ' + backend.name + ' 发送失败，换下一个：' + lastError);
        try { backend.close && backend.close(); } catch {}
        backend = null; idx++;
      }
    }
    return false;
  }
  function releaseAll() { const ops = planner.releaseAll(); if (ops.length) deliver(ops); }

  return {
    /* 授权前先确认能不能注入；返回 {ok, backend|error} */
    init() { return ensure() ? { ok: true, backend: backend.name } : { ok: false, error: lastError || '没有可用的输入注入后端' }; },
    setActive(on) {
      on = !!on;
      if (on === active) return;
      active = on; failStreak = 0; blockedNotified = false;
      clearInterval(wd);
      if (on) {
        lastCmd = Date.now();
        wd = setInterval(() => { if (planner.hasHeld() && Date.now() - lastCmd > holdTimeoutMs) { log('保活超时，松开按着的键'); releaseAll(); } }, 500);
      } else releaseAll();
    },
    handle(cmd) {
      if (!active) return;
      lastCmd = Date.now();
      const ops = planner.plan(cmd);
      if (ops.length) deliver(ops);
    },
    releaseAll,
    status: () => ({ active, backend: backend ? backend.name : '', error: lastError }),
    close() { clearInterval(wd); releaseAll(); if (backend && backend.close) { try { backend.close(); } catch {} } }
  };
}

module.exports = { createPlanner, createInjector, keyByName, MF, KF };
