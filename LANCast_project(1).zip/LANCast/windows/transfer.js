'use strict';
/* LANCast 文件互传（Windows 端传输模块）
 *
 * PIN 认证握手由 renderer.js 的 Session 完成（HELLO 里 mode = "file"），认证通过后，
 * 把「裸 socket」交给本模块。每个文件使用一条独立连接，握手之后的协议（所有整数大端）：
 *
 *   发送方 → 接收方   u32 头长度 | 头 JSON(UTF-8) {name, size, from}
 *   接收方 → 发送方   1 字节  0x01 同意 / 0x00 拒绝
 *   发送方 → 接收方   size 字节原始数据 | 32 字节 SHA-256(整个文件)
 *   接收方 → 发送方   1 字节  0x01 校验通过 / 0x00 失败（失败则接收方删除半成品）
 *
 * 无损：文件只当作字节流，不转码、不压缩；两端各自计算 SHA-256 并比对。
 * 不限大小：流式处理，每次 1 MiB，内存占用恒定；超时含义是「连续 30 秒没有任何数据」，不是总时长。
 * 安全落盘：先写 xxx.part，校验通过才改成正式文件名；重名自动加 (1)、(2)…，绝不覆盖。
 */
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const crypto = require('crypto');

const CHUNK = 1 << 20;                 // 1 MiB
const MAX_HEADER = 64 * 1024;
const HIGH_WATER = 4 * CHUNK;          // 接收缓冲超过 4 MiB 就暂停读 socket（背压）
const LOW_WATER = CHUNK;

function fmtSize(n) {
  n = Number(n) || 0;
  const u = ['B', 'KB', 'MB', 'GB', 'TB'];
  let i = 0;
  while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
  return i === 0 ? Math.round(n) + ' B' : n.toFixed(1) + ' ' + u[i];
}

/* ───────────── 文件名处理：只改名，不改内容 ───────────── */
const INVALID = /[<>:"/\\|?*\u0000-\u001f]/g;
const RESERVED = new Set(['CON', 'PRN', 'AUX', 'NUL']);
for (let i = 1; i <= 9; i++) { RESERVED.add('COM' + i); RESERVED.add('LPT' + i); }

function safeName(raw) {
  let name = String(raw).replace(/\\/g, '/').split('/').pop();          // 丢弃任何目录部分，防路径穿越
  name = name.replace(INVALID, '_').replace(/[ .]+$/, '');              // Windows 不允许的字符 / 结尾的点和空格
  if (!name) name = 'unnamed';
  if (RESERVED.has(name.split('.')[0].trim().toUpperCase())) name = '_' + name;   // CON、NUL、COM1…
  if (name.length > 200) {                                              // 太长则截断，保留扩展名
    const ext = path.extname(name);
    let base = name.slice(0, name.length - ext.length).slice(0, Math.max(1, 200 - ext.length));
    const last = base.charCodeAt(base.length - 1);
    if (last >= 0xD800 && last <= 0xDBFF) base = base.slice(0, -1);     // 别把 emoji 截成半个
    name = base + ext;
  }
  return name;
}

/* 在目录里「占位」一个不重名的文件：先以独占方式创建 xxx.part，成功即归我们所有。 */
async function reserve(dir, name) {
  const ext = path.extname(name);
  const base = name.slice(0, name.length - ext.length);
  for (let i = 0; i < 100000; i++) {
    const fn = i === 0 ? name : base + ' (' + i + ')' + ext;
    const p = path.join(dir, fn), part = p + '.part';
    if (fs.existsSync(p)) continue;
    try {
      const fh = await fsp.open(part, 'wx');
      return { path: p, part, fh };
    } catch (e) {
      if (e.code === 'EEXIST') continue;
      throw e;
    }
  }
  throw new Error('无法为文件找到可用的名字');
}

async function writeAll(fh, b) {
  let off = 0;
  while (off < b.length) {
    const { bytesWritten } = await fh.write(b, off, b.length - off, null);
    off += bytesWritten;
  }
}

function sockWrite(sock, buf) {
  return new Promise((resolve, reject) => {
    if (sock.destroyed) { reject(new Error('连接中断')); return; }
    sock.write(buf, err => (err ? reject(err) : resolve()));            // 回调 = 已交给系统，天然带背压
  });
}

/* ───────────── socket 读取器：按需取字节，带背压 ───────────── */
class Reader {
  constructor(sock, first) {
    this.sock = sock;
    this.q = first && first.length ? [first] : [];
    this.n = first && first.length ? first.length : 0;
    this.end = null;
    this.w = null;
    sock.on('data', d => {
      this.q.push(d); this.n += d.length;
      if (this.n >= HIGH_WATER) sock.pause();
      this._wake();
    });
    const fin = e => { if (!this.end) this.end = e || new Error('连接中断'); this._wake(); };
    sock.on('end', () => fin());
    sock.on('close', () => fin());
    sock.on('error', e => fin(e));
  }
  _wake() { const w = this.w; if (w) { this.w = null; w(); } }
  _more() { return new Promise(res => { this.w = res; }); }
  /* 取最多 max 字节（至少 1 字节）；没有数据就等 */
  async take(max) {
    while (this.n === 0) {
      if (this.end) throw this.end;
      await this._more();
    }
    const want = Math.min(max, this.n), parts = [];
    let got = 0;
    while (got < want) {
      const b = this.q[0], need = want - got;
      if (b.length > need) { parts.push(b.subarray(0, need)); this.q[0] = b.subarray(need); got += need; }
      else { parts.push(b); this.q.shift(); got += b.length; }
    }
    this.n -= got;
    if (this.n < LOW_WATER && this.sock.isPaused()) this.sock.resume();
    return parts.length === 1 ? parts[0] : Buffer.concat(parts, got);
  }
  async exact(n) {
    const out = Buffer.allocUnsafe(n);
    let off = 0;
    while (off < n) { const b = await this.take(n - off); b.copy(out, off); off += b.length; }
    return out;
  }
}

/* ───────────── 接收一个文件 ─────────────
 * sock/first：握手完成后的裸 socket 与已读入的多余字节
 * ctx：{ dir(): 保存目录, log(msg), row(kind, label) → {update(done,total,speed), remove()}, done(name, from) }
 */
async function receiveFile(sock, first, ctx) {
  const rd = new Reader(sock, first);                                   // 必须同步创建，别丢数据
  sock.setTimeout(30000, () => sock.destroy(new Error('30 秒没有收到任何数据')));
  let f = null, row = null, reply = -1;
  try {
    const hlen = (await rd.exact(4)).readUInt32BE(0);
    if (hlen === 0 || hlen > MAX_HEADER) throw new Error('文件头非法');
    const hdr = JSON.parse((await rd.exact(hlen)).toString('utf8'));
    const size = Number(hdr.size);
    if (!Number.isSafeInteger(size) || size < 0) throw new Error('文件大小非法');
    const from = String(hdr.from || sock.remoteAddress || '?');
    const raw = String(hdr.name);
    const dir = ctx.dir();
    await fsp.mkdir(dir, { recursive: true });
    f = await reserve(dir, safeName(raw));
    const name = path.basename(f.path);
    if (name !== raw) ctx.log('文件名已调整：' + raw + ' → ' + name);
    await sockWrite(sock, Buffer.from([1]));                            // 同意接收

    row = ctx.row('recv', name + '（来自 ' + from + '）');
    const h = crypto.createHash('sha256');
    const t0 = Date.now();
    let done = 0;
    while (done < size) {
      const b = await rd.take(Math.min(CHUNK, size - done));
      h.update(b);
      await writeAll(f.fh, b);
      done += b.length;
      row.update(done, size, done / Math.max((Date.now() - t0) / 1000, 0.001));
    }
    row.update(size, size, size / Math.max((Date.now() - t0) / 1000, 0.001));

    const theirs = await rd.exact(32);
    await f.fh.close(); f.fh = null;
    if (crypto.timingSafeEqual(h.digest(), theirs)) {
      await fsp.rename(f.part, f.path);                                 // 校验通过才变成正式文件
      f.part = null; reply = 1;
      ctx.log('✔ 已接收 ' + name + '（' + fmtSize(size) + '，SHA-256 校验通过）来自 ' + from);
      if (ctx.done) ctx.done(name, from);
    } else {
      reply = 0;
      ctx.log('✘ ' + name + ' 校验不一致，已丢弃');
    }
  } catch (e) {
    ctx.log('✘ 接收出错：' + (e && e.message ? e.message : e));
  } finally {
    if (f) {
      try { if (f.fh) await f.fh.close(); } catch { /* ignore */ }
      if (f.part) { try { await fsp.unlink(f.part); } catch { /* ignore */ } }   // 绝不留下半成品
    }
    if (row) row.remove();
    if (reply >= 0) sock.end(Buffer.from([reply])); else sock.destroy();
  }
}

/* ───────────── 发送一个文件 ─────────────
 * 失败时抛出异常；成功返回文件大小。ctx：{ from: 本机名, row(kind, label) }
 */
async function sendFile(sock, first, filePath, ctx) {
  const rd = new Reader(sock, first);
  sock.setTimeout(60000, () => sock.destroy(new Error('60 秒没有响应')));
  let fh = null, row = null;
  try {
    const st = await fsp.stat(filePath);
    if (st.isDirectory()) throw new Error('暂不支持直接发送文件夹，请先压缩成 zip');
    if (!st.isFile()) throw new Error('不是普通文件');
    const size = st.size, name = path.basename(filePath);
    const hdr = Buffer.from(JSON.stringify({ name, size, from: ctx.from }), 'utf8');
    const pre = Buffer.alloc(4); pre.writeUInt32BE(hdr.length, 0);
    await sockWrite(sock, Buffer.concat([pre, hdr]));
    if ((await rd.exact(1))[0] !== 1) throw new Error('对方拒绝接收「' + name + '」');

    fh = await fsp.open(filePath, 'r');
    row = ctx.row('send', name);
    const h = crypto.createHash('sha256');
    const bufs = [Buffer.allocUnsafe(CHUNK), Buffer.allocUnsafe(CHUNK)];   // 双缓冲：发上一块的同时读下一块
    const t0 = Date.now();
    let cur = 0, sent = 0;
    let pend = null;
    if (size > 0) { pend = fh.read(bufs[0], 0, Math.min(CHUNK, size), null); pend.catch(() => {}); }
    while (sent < size) {
      const { bytesRead: n } = await pend;
      if (n === 0) throw new Error('「' + name + '」在发送过程中被截断');
      const chunk = bufs[cur].subarray(0, n);
      h.update(chunk);
      const left = size - sent - n, nx = 1 - cur;
      pend = null;
      if (left > 0) { pend = fh.read(bufs[nx], 0, Math.min(CHUNK, left), null); pend.catch(() => {}); }
      await sockWrite(sock, chunk);
      sent += n; cur = nx;
      row.update(sent, size, sent / Math.max((Date.now() - t0) / 1000, 0.001));
    }
    const extra = await fh.read(Buffer.alloc(1), 0, 1, null);
    if (extra.bytesRead > 0) throw new Error('「' + name + '」在发送过程中变大了，已中止');

    await sockWrite(sock, h.digest());
    sock.setTimeout(300000);                                            // 等对方落盘 + 校验
    if ((await rd.exact(1))[0] !== 1) throw new Error('对方校验失败「' + name + '」（数据不一致）');
    row.update(size, size, size / Math.max((Date.now() - t0) / 1000, 0.001));
    return size;
  } finally {
    if (fh) { try { await fh.close(); } catch { /* ignore */ } }
    if (row) row.remove();
    sock.destroy();
  }
}

module.exports = { receiveFile, sendFile, safeName, fmtSize, Reader };
