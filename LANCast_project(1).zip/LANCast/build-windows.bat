@echo off
cd /d %~dp0windows
call npm install
call npm run dist
echo.
echo 完成：安装包和便携版 exe 在 windows\dist 目录
pause
