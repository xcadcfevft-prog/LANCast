// 版本号可按 Android Studio 的升级提示调整（AGP / Kotlin 要互相兼容）
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
