// 版本号可按 Android Studio 的升级提示调整（AGP / Kotlin 要互相兼容）
plugins {
    id("com.android.application") version "8.7.3" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
}
