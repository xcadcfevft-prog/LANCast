import com.lancast.app.*
import org.json.*

fun interopMain() {
    val rd = java.io.BufferedReader(java.io.InputStreamReader(System.`in`, Charsets.UTF_8))
    val wr = java.io.PrintStream(System.out, true, "UTF-8")
    var eph: ChatCrypto.Eph? = null
    var keys: ChatCrypto.Keys? = null
    var ctr = 0L
    while (true) {
        val line = rd.readLine() ?: break
        val j = JSONObject(line)
        val out = JSONObject()
        try {
            when (j.optString("cmd")) {
                "derive" -> {
                    eph = ChatCrypto.genEphemeral(); ctr = 0L
                    keys = ChatCrypto.deriveSession(eph, j.optString("epk"), j.optBoolean("isClient"), j.optString("sn"), j.optString("cn"), j.optString("pin"))
                    out.put("epk", eph.pub).put("sas", keys.sas).put("tx", ChatCrypto.hex(keys.txKey)).put("rx", ChatCrypto.hex(keys.rxKey))
                }
                "seal" -> { ctr += 1; out.put("frame", ChatCrypto.hex(ChatCrypto.seal(keys!!.txKey, ctr, j.map["obj"] as JSONObject))) }
                "open" -> { val r = ChatCrypto.open(keys!!.rxKey, ChatCrypto.unhex(j.optString("frame")), j.optLong("last")); out.put("ctr", r.ctr).put("obj", r.obj) }
                "sanitize" -> { val p = ChatCrypto.sanitize(j.map["obj"] as JSONObject, j.optLong("now")); if (p == null) out.put("null", true) else out.put("t", p.t).put("id", p.id).put("x", p.x).put("e", p.e).put("c", p.c).put("bg", JSONArray().also { a -> p.bg.forEach { a.put(it) } }) }
                "clip" -> out.put("r", ChatCrypto.clip(j.optString("s"), j.optInt("n")))
            }
        } catch (e: Exception) { out.put("error", e.message ?: e.javaClass.simpleName) }
        wr.println(out.toString())
    }
}
