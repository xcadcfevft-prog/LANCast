# 安卓聊天核心的 JVM 测试

`ChatCrypto.kt` / `ChatHub.kt` / `ChatData.kt` 不依赖 Android API，可以用 kotlinc 直接在电脑上编译、测试（不需要 Android SDK）。

```bash
A=../app/src/main/java/com/lancast/app
kotlinc -nowarn -d hubtest.jar org/json/Json.kt $A/ChatCrypto.kt $A/ChatHub.kt $A/ChatData.kt ChatHubTest.kt
java -Dfile.encoding=UTF-8 -cp hubtest.jar:<kotlinc>/lib/kotlin-stdlib.jar ChatHubTestKt     # 应输出 ALL PASSED
```

`org/json/Json.kt` 是一个很小的 org.json 替身（Android 上用系统自带的）。`InteropMain.kt` 是和电脑端 `windows/test/chat-kotlin-interop.test.js` 对跑用的（设环境变量 `KT_CP` 指向编译产物）。
