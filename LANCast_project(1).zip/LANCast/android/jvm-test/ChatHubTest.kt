import com.lancast.app.*
import java.util.concurrent.Executors

/** 安卓端 ChatHub 的 JVM 单元测试（不需要 Android SDK）。运行方法见同目录 README.md。 */
class Pair2 { var a: Link2? = null; var b: Link2? = null }

class Link2(val pool: java.util.concurrent.ExecutorService) : ChatLink {
    var peer: Link2? = null
    var hub: ChatHub? = null
    var conn: ChatHub.Conn? = null
    @Volatile var closed = false
    val inbox = java.util.concurrent.Executors.newSingleThreadExecutor { r -> Thread(r).also { it.isDaemon = true } }
    @Volatile var tap: ((Int, ByteArray) -> ByteArray?)? = null
    override fun send(type: Int, payload: ByteArray) {
        val p = peer ?: return
        val data = tap?.invoke(type, payload.copyOf()) ?: if (tap == null) payload.copyOf() else return
        if (p.closed) return
        p.inbox.execute { p.deliver(type, data) }
    }
    fun deliver(type: Int, data: ByteArray) {
        var tries = 0
        while (conn == null && tries++ < 200) Thread.sleep(5)       // 接收方还没 attach：等一下（真实网络里读线程在 attach 之后才启动）
        val c = conn ?: return
        if (!closed) hub!!.onFrame(c, type, data)
    }
    override fun close(reason: String) {
        if (closed) return
        closed = true
        val p = peer
        if (p != null && !p.closed) p.inbox.execute { p.closed = true; p.conn?.let { p.hub!!.onClosed(it) } }
    }
}

class Env(override val myId: String, override val myName: String, val world: World, val me: String, val other: String) : ChatEnv {
    val store = HashMap<String, String>()
    var unread: String? = null
    val notes = ArrayList<String>()
    override fun myPin() = world.pin[me]!!
    override fun peers() = listOf(ChatPeer(if (other == "A") "aaaa0001" else "bbbb0002", if (other == "A") "电脑A" else "手机B", world.known[me + other]!!, "1.1.1.1", 47800, true))
    override fun load(peerId: String) = synchronized(store) { store[peerId] }
    override fun save(peerId: String, json: String) { synchronized(store) { store[peerId] = json } }
    override fun loadUnread() = unread
    override fun saveUnread(json: String) { unread = json }
    override fun dial(p: ChatPeer): ChatDial {
        world.dials++
        if (!world.reachable) throw RuntimeException("unreachable")
        val cl = Link2(world.pool); val sl = Link2(world.pool); cl.peer = sl; sl.peer = cl
        val sn = ChatCrypto.hex(ByteArray(16).also { java.security.SecureRandom().nextBytes(it) })
        val cn = ChatCrypto.hex(ByteArray(16).also { java.security.SecureRandom().nextBytes(it) })
        val oh = world.hub[other]!!
        sl.hub = oh; cl.hub = world.hub[me]!!
        sl.conn = oh.attach(sl, ChatHub.Meta(myId, false, sn, cn, world.pin[other] + ":" + world.known[other + me], myName))
        world.lastClient = cl
        // 客户端侧：hub.onAttached 里把 conn 交给 link（相当于启动读线程）
        return ChatDial(cl, sn, cn)
    }
    override fun changed(peerId: String) {}
    override fun notify(peerId: String, name: String, msg: ChatMsg) { synchronized(notes) { notes.add(name + ":" + msg.x) } }
    var clock = 1_000_000L
    override fun now() = world.clock
}

class World {
    val pool = Executors.newCachedThreadPool { r -> Thread(r).also { it.isDaemon = true } }
    val pin = hashMapOf("A" to "1111111111", "B" to "2222222222")
    val known = hashMapOf("AB" to "2222222222", "BA" to "1111111111")
    val hub = HashMap<String, ChatHub>()
    @Volatile var reachable = true
    @Volatile var dials = 0
    @Volatile var clock = 1_000_000L
    var lastClient: Link2? = null
    lateinit var envA: Env
    lateinit var envB: Env
    init {
        envA = Env("aaaa0001", "电脑A", this, "A", "B"); envB = Env("bbbb0002", "手机B", this, "B", "A")
        hub["A"] = ChatHub(envA); hub["B"] = ChatHub(envB)
        for (k in listOf("A", "B")) hub[k]!!.onAttached = { c -> val l = c.link as Link2; l.conn = c }
    }
    val A get() = hub["A"]!!
    val B get() = hub["B"]!!
}

var fails = 0
fun check(name: String, ok: Boolean) { println((if (ok) "PASS " else "FAIL ") + name); if (!ok) fails++ }
fun waitFor(ms: Long = 4000, f: () -> Boolean): Boolean { val t = System.currentTimeMillis(); while (System.currentTimeMillis() - t < ms) { try { if (f()) return true } catch (e: Exception) {} ; Thread.sleep(20) }; return false }

fun main() {
    run {
        val w = World()
        w.A.sendText("bbbb0002", "你好 B 😀")
        val ok = waitFor { w.B.messages("aaaa0001").size == 1 && w.A.messages("bbbb0002")[0].st == "sent" }
        check("A 发文字：B 收到、A 显示已送达", ok)
        check("B 记 1 条未读并通知；内容一致", w.B.unread("aaaa0001") == 1 && w.envB.notes.size == 1 && w.B.messages("aaaa0001")[0].x == "你好 B 😀")
        check("两端安全码一致且非空", w.A.sas("bbbb0002").isNotEmpty() && w.A.sas("bbbb0002") == w.B.sas("aaaa0001"))
        val d = w.dials
        w.B.sendSticker("aaaa0001", ChatData.STICKERS[0])
        check("B 回发表情包：复用连接，A 收到完整表情包并回执", waitFor { w.A.messages("bbbb0002").any { it.k == "s" && it.e == ChatData.STICKERS[0].e && it.bg == listOf(ChatData.STICKERS[0].bg1, ChatData.STICKERS[0].bg2) } && w.B.messages("aaaa0001").first { it.k == "s" }.st == "sent" } && w.dials == d)
        w.A.markRead("bbbb0002"); check("markRead", w.A.unread("bbbb0002") == 0)
    }
    run {
        val w = World(); w.reachable = false
        val m = w.A.sendText("bbbb0002", "在吗")!!
        for (i in 0 until 40) { w.clock += 1000; w.A.tick(); Thread.sleep(5) }
        check("对方不在线：补连并最终标记失败", w.dials >= 5 && w.A.messages("bbbb0002")[0].st == "failed")
        w.reachable = true; w.A.retry("bbbb0002", m.id)
        check("恢复后重试送达", waitFor { w.A.messages("bbbb0002")[0].st == "sent" && w.B.messages("aaaa0001").size == 1 })
    }
    run {
        val w = World()
        w.A.sendText("bbbb0002", "from A"); w.B.sendText("aaaa0001", "from B")
        check("两边同时发起连接：消息一条不丢不重", waitFor { w.A.messages("bbbb0002").size == 2 && w.B.messages("aaaa0001").size == 2 && w.A.messages("bbbb0002").all { it.st == "sent" || !it.mine } && w.B.messages("aaaa0001").all { it.st == "sent" || !it.mine } })
        w.A.sendText("bbbb0002", "again")
        check("之后只收一份", waitFor { w.B.messages("aaaa0001").count { it.x == "again" } == 1 })
    }
    run {
        val w = World(); w.known["BA"] = "9999999999"
        w.A.sendText("bbbb0002", "secret"); Thread.sleep(800)
        check("配对密钥不一致：连接被断开，对方没有任何消息", w.B.messages("aaaa0001").isEmpty() && !w.A.isConnected("bbbb0002"))
    }
    run {
        val w = World()
        w.A.sendText("bbbb0002", "first"); waitFor { w.B.messages("aaaa0001").size == 1 }
        w.lastClient!!.tap = { type, b -> if (type == ChatCrypto.T_CHAT_MSG) b[b.size - 1] = (b[b.size - 1].toInt() xor 1).toByte(); b }
        w.A.sendText("bbbb0002", "tampered"); Thread.sleep(600)
        check("被篡改的消息：不显示且 B 断开连接", w.B.messages("aaaa0001").size == 1 && w.B.connections("aaaa0001") == 0)
    }
    run {
        val w = World(); w.A.sendText("bbbb0002", "x"); waitFor { w.B.messages("aaaa0001").size == 1 }
        w.B.clear("aaaa0001"); w.A.dropPeer("bbbb0002"); Thread.sleep(200)
        check("清空记录清未读；取消配对断开连接", w.B.messages("aaaa0001").isEmpty() && w.B.unread("aaaa0001") == 0 && !w.A.isConnected("bbbb0002"))
    }
    println(if (fails == 0) "ALL PASSED" else "SOME FAILED"); System.exit(if (fails == 0) 0 else 1)
}
