import com.lancast.app.*
import java.io.File
import java.net.HttpURLConnection
import java.net.Socket
import java.net.URL
import java.util.Random
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

var fails = 0
fun check(name: String, ok: Boolean) { println((if (ok) "PASS " else "FAIL ") + name); if (!ok) fails++ }

/** 模拟 libtorrent：按截止时间最小的分片优先“下载”，没有截止时间的分片按倒序下（故意和播放顺序相反） */
class FakeSwarm(val pl: Int, val data: ByteArray, val file: File, val delayMs: Long, val prefix: Long = 0) : PieceSource {
    override val pieceLength = pl
    val total = data.size + prefix.toInt()
    override val numPieces = (total + pl - 1) / pl
    val haveSet = ConcurrentHashMap.newKeySet<Int>()
    val deadlines = ConcurrentHashMap<Int, Long>()
    val order = java.util.Collections.synchronizedList(ArrayList<Int>())
    @Volatile var run = true
    init {
        java.io.RandomAccessFile(file, "rw").use { it.setLength(data.size.toLong()) }
        Thread {
            val raf = java.io.RandomAccessFile(file, "rw")
            while (run) {
                val dl = deadlines.entries.filter { it.key !in haveSet }.minByOrNull { it.value }?.key
                val p = dl ?: (numPieces - 1 downTo 0).firstOrNull { it !in haveSet }
                if (p == null) { Thread.sleep(20); continue }
                Thread.sleep(delayMs)
                val absS = p.toLong() * pl; val absE = minOf(absS + pl, total.toLong())
                val fs = maxOf(0L, absS - prefix); val fe = absE - prefix
                if (fe > fs) { raf.seek(fs); raf.write(data, fs.toInt(), (fe - fs).toInt()) }
                order.add(p); haveSet.add(p); deadlines.remove(p)
            }
            raf.close()
        }.apply { isDaemon = true; start() }
    }
    override fun have(piece: Int) = piece in haveSet
    override fun setDeadline(piece: Int, ms: Int) { deadlines[piece] = System.nanoTime() / 1000 + ms * 1000L }
    override fun resetDeadline(piece: Int) { deadlines.remove(piece) }
}

fun get(url: String, range: String? = null, method: String = "GET"): Triple<Int, Map<String, String>, ByteArray> {
    val c = URL(url).openConnection() as HttpURLConnection
    c.requestMethod = method
    if (range != null) c.setRequestProperty("Range", range)
    c.connectTimeout = 5000; c.readTimeout = 20000
    val code = c.responseCode
    val hs = c.headerFields.filterKeys { it != null }.mapKeys { it.key.lowercase() }.mapValues { it.value.first() }
    val body = if (method == "HEAD") ByteArray(0) else (if (code < 400) c.inputStream else c.errorStream)?.readBytes() ?: ByteArray(0)
    return Triple(code, hs, body)
}

fun main() {
    // ── Range 解析
    check("range a-b", Http.parseRange("bytes=0-99", 1000)!!.toList() == listOf(0L, 99L))
    check("range open-ended", Http.parseRange("bytes=900-", 1000)!!.toList() == listOf(900L, 999L))
    check("range suffix", Http.parseRange("bytes=-100", 1000)!!.toList() == listOf(900L, 999L))
    check("range clamp end", Http.parseRange("bytes=0-99999", 1000)!!.toList() == listOf(0L, 999L))
    check("range past end → 416", Http.parseRange("bytes=1000-", 1000)!!.toList() == listOf(-1L, -1L))
    check("range none", Http.parseRange(null, 1000) == null && Http.parseRange("garbage", 1000) == null)
    check("range multi → first", Http.parseRange("bytes=0-9,20-29", 1000)!!.toList() == listOf(0L, 9L))
    check("mime/playable", Http.mime("a.MKV") == "video/x-matroska" && Http.isPlayable("x.flac") && !Http.isPlayable("a.nfo"))

    // ── 状态持久化
    val st = listOf(SavedTask("a".repeat(40), "/sdcard/磁力 下载\t(1)", true, listOf(0, 3)), SavedTask("b".repeat(40), "/x", false, null, true))
    val back = BtState.decode(BtState.encode(st))
    check("state roundtrip", back.size == 2 && back[0].dir == st[0].dir && back[0].paused && back[0].selected == listOf(0, 3) && back[1].selected == null && !back[1].paused && back[1].done && !back[0].done)
    check("state ignores junk", BtState.decode("junk\n\n1\t2").isEmpty())

    // ── 流服务：文件在种子里偏移 prefix（前面还有别的文件 / padding），分片大小 16000（故意和文件大小、读块大小都不对齐）
    val rnd = Random(7)
    val data = ByteArray(1_234_567).also { rnd.nextBytes(it) }
    val dir = File(System.getProperty("java.io.tmpdir"), "bt-test-" + System.nanoTime()).apply { mkdirs() }
    val prefix = 7_777L
    val pl = 16000
    var swarm = FakeSwarm(pl, data, File(dir, "f1.bin"), 25, prefix)
    val opened = AtomicInteger(); val closed = AtomicInteger()
    val srv = StreamServer({ h, i -> if (h == "h".repeat(40) && i == 0) StreamTarget("电影 1.mkv", data.size.toLong(), prefix, File(dir, "f1.bin"), swarm, 0, { opened.incrementAndGet() }, { closed.incrementAndGet() }) else null }, 1L shl 20)
    val base = srv.url("h".repeat(40), 0, "电影 1.mkv")
    check("url encoded", base.contains("%E7%94%B5") && !base.contains(" "))

    var r = get(base, "bytes=600000-700000")
    check("206 middle", r.first == 206 && r.second["content-range"] == "bytes 600000-700000/${data.size}" && r.third.contentEquals(data.copyOfRange(600000, 700001)))
    check("headers", r.second["accept-ranges"] == "bytes" && r.second["content-type"] == "video/x-matroska" && r.second["content-length"] == "100001")
    val firstOrder = swarm.order.take(4).toList()
    val mid = ((prefix + 600000) / pl).toInt()
    check("seek → 优先下载播放位置附近的分片 $firstOrder", firstOrder.isNotEmpty() && firstOrder.all { it in (mid - 1)..(mid + 12) || it >= swarm.numPieces - 2 })

    r = get(base, "bytes=-1000")
    check("206 suffix", r.first == 206 && r.third.contentEquals(data.copyOfRange(data.size - 1000, data.size)))
    r = get(base, "bytes=1200000-")
    check("206 open-ended", r.first == 206 && r.third.contentEquals(data.copyOfRange(1200000, data.size)))
    r = get(base, null, "HEAD")
    check("HEAD", r.first == 200 && r.second["content-length"] == data.size.toString() && r.third.isEmpty())
    r = get(base, "bytes=${data.size}-")
    check("416", r.first == 416 && r.second["content-range"] == "bytes */${data.size}")
    r = get(base.replace("/0/", "/9/"))
    check("404 unknown file", r.first == 404)
    r = get(base)
    check("200 full file byte-for-byte", r.first == 200 && r.third.contentEquals(data))

    // 一次性请求从头开始：首字节延迟不应该等整个文件
    swarm.run = false
    swarm = FakeSwarm(pl, data, File(dir, "f2.bin"), 25, prefix)
    val srv2 = StreamServer({ h, i -> if (i == 0) StreamTarget("a.mp4", data.size.toLong(), prefix, File(dir, "f2.bin"), swarm, 0) else null }, 1L shl 20)
    val t0 = System.currentTimeMillis()
    val s = Socket("127.0.0.1", srv2.start())
    s.getOutputStream().write("GET /${"h".repeat(40)}/0/a.mp4 HTTP/1.1\r\nHost: x\r\nRange: bytes=1000000-\r\n\r\n".toByteArray())
    val inp = s.getInputStream()
    val head = StringBuilder(); while (!head.endsWith("\r\n\r\n")) head.append(inp.read().toChar())
    val b0 = inp.read()
    val dt = System.currentTimeMillis() - t0
    check("seek 首字节 ${dt}ms（顺序下载整个文件需要 >2s）", b0 == (data[1000000].toInt() and 0xff) && dt < 1500)
    // 客户端中途断开：服务端应释放（不再占用连接，也撤销截止时间）
    s.close()
    Thread.sleep(1500)
    check("断开后撤销截止时间", swarm.deadlines.keys.none { it > ((prefix + 1000000) / pl).toInt() + 60 })

    // 并发两个连接 + onOpen/onClose 计数
    swarm.run = false
    swarm = FakeSwarm(pl, data, File(dir, "f3.bin"), 1, prefix)
    val srv3 = StreamServer({ _, i -> if (i == 0) StreamTarget("a.mp4", data.size.toLong(), prefix, File(dir, "f3.bin"), swarm, 0, { opened.incrementAndGet() }, { closed.incrementAndGet() }) else null }, 1L shl 20)
    val u3 = srv3.url("h".repeat(40), 0, "a.mp4")
    val o0 = opened.get(); val c0 = closed.get()
    val res = arrayOfNulls<ByteArray>(2)
    val th = (0..1).map { k -> Thread { res[k] = get(u3, "bytes=${k * 500000}-${k * 500000 + 99999}").third }.also { it.start() } }
    th.forEach { it.join() }
    check("并发 Range", res[0]!!.contentEquals(data.copyOfRange(0, 100000)) && res[1]!!.contentEquals(data.copyOfRange(500000, 600000)))
    Thread.sleep(200)
    check("onOpen/onClose 成对 (${opened.get() - o0}/${closed.get() - c0})", opened.get() - o0 == 2 && closed.get() - c0 == 2)

    // settle（眼看着下完的分片再等 settleMs 才读）不应破坏正确性
    swarm.run = false
    swarm = FakeSwarm(pl, data, File(dir, "f4.bin"), 2, prefix)
    val srv4 = StreamServer({ _, i -> if (i == 0) StreamTarget("a.mp4", data.size.toLong(), prefix, File(dir, "f4.bin"), swarm, 30) else null }, 1L shl 20)
    r = get(srv4.url("h".repeat(40), 0, "a.mp4"), "bytes=0-199999")
    check("settle 读取正确", r.third.contentEquals(data.copyOfRange(0, 200000)))

    swarm.run = false; srv.stop(); srv2.stop(); srv3.stop(); srv4.stop(); dir.deleteRecursively()
    println(if (fails == 0) "BtCore: ALL PASSED" else "BtCore: $fails FAILED")
    System.exit(if (fails == 0) 0 else 1)
}
