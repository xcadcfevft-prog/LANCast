import com.lancast.app.MusicRing

/* 沉浸音乐断线补发环形缓冲（MusicRing.kt）的 JVM 测试：不需要 Android SDK。编译 / 运行方法见 README.md。 */
var pass = 0
var fail = 0
fun check(name: String, cond: Boolean) {
    if (cond) { pass++; println("PASS $name") } else { fail++; println("FAIL $name") }
}

/** 第 i 帧的 4 个字节 = 确定性的伪随机，方便核对切片后内容没错位 */
fun frameBytes(i: Long): ByteArray {
    val v = (i * 2654435761L + 12345L)
    return byteArrayOf(((v shr 0) or 1).toByte(), (v shr 8).toByte(), (v shr 16).toByte(), (v shr 24).toByte())
}
fun pcm(start: Long, frames: Int): ByteArray {
    val b = ByteArray(frames * 4)
    for (i in 0 until frames) System.arraycopy(frameBytes(start + i), 0, b, i * 4, 4)
    return b
}

fun main() {
    // 1. 按序取回，内容逐字节一致
    run {
        val r = MusicRing(100000)
        var at = 0L
        for (n in listOf(1920, 1920, 500, 1920)) { r.append(pcm(at, n), n); at += n }
        check("next = 已采集总帧数", r.next() == at)
        check("oldest = 0", r.oldest() == 0L)
        var idx = 0L
        val out = java.io.ByteArrayOutputStream()
        while (true) { val c = r.take(idx) ?: break; check("块起点 == 请求位置", c.start == idx); out.write(c.data!!); idx = c.start + c.frames }
        check("取完整条流 == 原始流", out.toByteArray().contentEquals(pcm(0, at.toInt())))
    }
    // 2. 从块中间续传：切片对齐，不重不漏
    run {
        val r = MusicRing(100000)
        r.append(pcm(0, 1000), 1000); r.append(pcm(1000, 1000), 1000)
        val c = r.take(1337)!!
        check("中间切片起点和长度", c.start == 1337L && c.frames == 2000 - 1337)
        check("中间切片内容", c.data!!.contentEquals(pcm(1337, c.frames)))
        check("切片取完后没有更多数据", r.take(c.start + c.frames) == null)
    }
    // 3. 确认后裁剪：已确认的丢掉、未确认的保留（断线重连要用）
    run {
        val r = MusicRing(100000)
        for (k in 0 until 10) r.append(pcm(k * 100L, 100), 100)
        r.trimTo(450)
        check("裁到整块边界之前", r.oldest() == 400L)
        check("未确认部分仍在", r.take(450)!!.data!!.contentEquals(pcm(450, 50)))
        r.trimTo(10_000)
        check("全确认后为空", r.take(1000) == null && r.oldest() == r.next())
    }
    // 4. 容量上限：装不下时丢最老的，next 不受影响，取到的起点 > 请求位置（对端据此知道丢了多少）
    run {
        val r = MusicRing(1000)
        for (k in 0 until 20) r.append(pcm(k * 100L, 100), 100)
        check("容量封顶", r.bufferedFrames() <= 1000L + 100L)
        check("next 不受影响", r.next() == 2000L)
        val c = r.take(0)!!
        check("请求已被挤出的位置 → 返回最老可用块", c.start == r.oldest() && c.start > 0)
    }
    // 5. 静音块：只记帧数不占内存，切片后仍是静音
    run {
        val r = MusicRing(100000)
        r.append(pcm(0, 100), 100); r.append(null, 5000); r.append(pcm(5100, 100), 100)
        check("静音块", r.take(100)!!.data == null && r.take(100)!!.frames == 5000)
        val c = r.take(2000)!!
        check("静音块中间切片", c.data == null && c.start == 2000L && c.frames == 3100)
        check("静音后接上有声音", r.take(5100)!!.data!!.contentEquals(pcm(5100, 100)))
        check("isSilent", MusicRing.isSilent(ByteArray(64), 64) && !MusicRing.isSilent(byteArrayOf(0, 0, 1, 0), 4))
    }
    // 6. 模拟「发送 → 断线 → 按确认位置补发」：接收方收到的流与原始流逐字节一致
    run {
        val r = MusicRing(48000L * 30)
        val got = java.io.ByteArrayOutputStream()
        var rxNext = 0L
        var sendIdx = 0L
        var captured = 0L
        val rnd = java.util.Random(7)
        for (round in 0 until 400) {
            val n = 1920
            r.append(pcm(captured, n), n); captured += n
            // 每轮发 0..3 块；偶尔「断线」：已发出但没确认的包丢掉，重连后从接收方确认的位置继续
            repeat(rnd.nextInt(4)) {
                val c = r.take(sendIdx) ?: return@repeat
                if (rnd.nextInt(10) == 0) { sendIdx = rxNext; return@repeat }          // 这个包丢在路上
                if (c.start + c.frames <= rxNext) { sendIdx = c.start + c.frames; return@repeat }   // 对端按序号去重
                val off = (rxNext - c.start).coerceAtLeast(0).toInt()
                got.write(c.data!!, off * 4, (c.frames - off) * 4)
                rxNext = c.start + c.frames
                sendIdx = rxNext
                if (rnd.nextInt(3) == 0) r.trimTo(rxNext)
            }
            if (round % 50 == 49) sendIdx = rxNext                                      // 重连：电脑回报「从第 N 帧继续」
        }
        while (true) { val c = r.take(sendIdx) ?: break; got.write(c.data!!); sendIdx = c.start + c.frames; rxNext = sendIdx }
        check("断线补发后整条流逐字节一致（${got.size()} 字节）", got.toByteArray().contentEquals(pcm(0, captured.toInt())))
    }
    println(if (fail == 0) "ALL $pass PASSED" else "$fail FAILED")
    if (fail != 0) System.exit(1)
}
