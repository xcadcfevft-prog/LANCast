import com.lancast.app.NetX
import com.lancast.app.NetX.Addr
import com.lancast.app.NetX.Kind
import java.net.ServerSocket

/* 手机端网络地址工具（NetX.kt）的 JVM 测试：不需要 Android SDK。编译 / 运行方法见 README.md。 */
var pass = 0
var fail = 0
fun check(name: String, cond: Boolean) {
    if (cond) { pass++; println("PASS $name") } else { fail++; println("FAIL $name") }
}
fun <T> eq(name: String, a: T, b: T) {
    if (a == b) { pass++; println("PASS $name") } else { fail++; println("FAIL $name\n     actual:   $a\n     expected: $b") }
}

fun main() {
    // 一台手机：家里 Wi-Fi + 蒲公英（tun0）；另有移动数据
    val wifi = Addr("192.168.1.7", 24, "wlan0", Kind.LAN)
    val vpn = Addr("172.16.5.9", 16, "tun0", Kind.OVERLAY)
    val cell = Addr("10.88.1.2", 30, "rmnet_data1", Kind.CELL)

    /* 网卡分类 */
    eq("网卡名分类", listOf("wlan0", "eth0", "ap0", "swlan0", "tun0", "tap1", "wg0", "ppp0", "rmnet_data1", "ccmni0", "v4-rmnet_data1", "lo", "dummy0", "tunl0", "ip6tnl0", "xyz0")
        .map { NetX.kindOfIface(it, "192.168.1.1") },
        listOf(Kind.LAN, Kind.LAN, Kind.LAN, Kind.LAN, Kind.OVERLAY, Kind.OVERLAY, Kind.OVERLAY, Kind.OVERLAY, Kind.CELL, Kind.CELL, Kind.CELL, Kind.JUNK, Kind.JUNK, Kind.JUNK, Kind.JUNK, Kind.LAN))
    eq("不认识的网卡：公网地址当移动数据", NetX.kindOfIface("xyz0", "8.8.8.8"), Kind.CELL)

    /* 可用地址 */
    eq("usable", listOf("192.168.1.7", "127.0.0.1", "169.254.3.3", "224.0.0.1", "0.1.2.3", "192.0.0.4", "198.18.0.1", "100.101.1.1", "256.1.1.1", "abc", "1.2.3").map { NetX.usable(it) },
        listOf(true, false, false, false, false, false, false, true, false, false, false))
    eq("isPrivate", listOf("10.1.1.1", "172.16.0.1", "172.31.255.1", "172.32.0.1", "192.168.0.1", "100.64.0.1", "100.128.0.1", "8.8.8.8").map { NetX.isPrivate(it) },
        listOf(true, true, true, false, true, true, false, false))

    /* 二维码地址 */
    eq("二维码地址：局域网在前、虚拟局域网在后、移动数据不放", NetX.qrIps(listOf(cell, vpn, wifi)), listOf("192.168.1.7", "172.16.5.9"))
    eq("二维码地址：只有蒲公英（流量 + VPN）→ 放虚拟局域网地址", NetX.qrIps(listOf(cell, vpn)), listOf("172.16.5.9"))
    eq("二维码地址：只有移动数据 → 退而求其次放移动数据地址（二维码不是空的）", NetX.qrIps(listOf(cell)), listOf("10.88.1.2"))
    eq("二维码地址：完全没网 → 空", NetX.qrIps(emptyList()), emptyList<String>())
    eq("二维码地址：最多 6 个", NetX.qrIps((0 until 9).map { Addr("192.168.$it.5", 24, "eth$it", Kind.LAN) }).size, 6)

    /* 网络现状文字 */
    eq("现状：Wi-Fi + 蒲公英 + 移动数据", NetX.summary(NetX.state(listOf(wifi, vpn, cell))), "局域网 192.168.1.7 · 虚拟局域网 172.16.5.9 · 移动数据")
    eq("现状：流量 + 蒲公英", NetX.summary(NetX.state(listOf(cell, vpn))), "虚拟局域网 172.16.5.9 · 移动数据")
    check("现状：仅移动数据", NetX.summary(NetX.state(listOf(cell))).startsWith("仅移动数据") && NetX.state(listOf(cell)).onlyCell && !NetX.state(listOf(cell)).reachable)
    check("现状：没网", NetX.summary(NetX.state(emptyList())).startsWith("未联网") && NetX.state(emptyList()).none)

    /* 对方地址排序 */
    val locals = listOf(wifi, vpn, cell)
    eq("排序：同局域网 → 同虚拟局域网 → 其他私有 → 其他；同级保持顺序；去重丢非法", NetX.order(listOf("8.8.8.8", "10.1.1.1", "172.16.9.9", "192.168.1.5", "abc", "192.168.1.5"), locals),
        listOf("192.168.1.5", "172.16.9.9", "10.1.1.1", "8.8.8.8"))
    eq("排序：同级保持传入顺序", NetX.order(listOf("10.2.2.2", "10.1.1.1"), locals), listOf("10.2.2.2", "10.1.1.1"))
    eq("路径标注", listOf("192.168.1.5", "172.16.0.1", "10.9.9.9").map { NetX.pathLabel(it, locals) }, listOf("局域网直连", "虚拟局域网", "远程连接"))
    eq("心跳放宽依据", listOf("192.168.1.99", "172.16.0.1", "10.0.0.1").map { NetX.isLanPeer(it, locals) }, listOf(true, false, false))
    val home = listOf(wifi)
    eq("单播对象", listOf(NetX.shouldUnicast("192.168.1.5", home), NetX.shouldUnicast("172.16.0.1", home), NetX.shouldUnicast("203.0.113.9", home), NetX.shouldUnicast("172.16.0.1", locals), NetX.shouldUnicast("10.9.9.9", locals)),
        listOf(true, false, true, true, true))
    eq("地址合并", NetX.mergeAddrs("172.16.0.1", listOf("192.168.1.5"), listOf("192.168.1.5", "10.0.0.2", "zzz")), Pair("172.16.0.1", listOf("192.168.1.5", "10.0.0.2")))
    val mg = NetX.mergeAddrs("1.1.1.1", listOf("2.2.2.2", "3.3.3.3"), listOf("4.4.4.4", "5.5.5.5", "6.6.6.6", "7.7.7.7", "8.8.8.8"))
    check("地址合并：总数不超过 6", mg.first == "1.1.1.1" && mg.second.size == 5)
    eq("recAddrs", NetX.recAddrs("1.2.3.4", listOf("5.6.7.8", "1.2.3.4", "x")), listOf("1.2.3.4", "5.6.7.8"))

    /* 配对链接 */
    val link = NetX.buildLink("abcd1234abcd1234", "张三的 PC & 手机", "4815162342", 47800, listOf("192.168.1.5", "172.16.0.1"))
    check("链接格式", link.startsWith("lancast://pair?v=2&id=abcd1234abcd1234&n="))
    val q = NetX.parseLink(link)!!
    eq("链接往返", listOf(q.id, q.name, q.pin, q.port.toString(), q.ips.joinToString(",")), listOf("abcd1234abcd1234", "张三的 PC & 手机", "4815162342", "47800", "192.168.1.5,172.16.0.1"))
    eq("链接夹在整句话里", NetX.parseLink("我的配对链接：$link ，收到请回复。")?.id, "abcd1234abcd1234")
    eq("链接被括号包着", NetX.parseLink("($link).")?.ips, listOf("192.168.1.5", "172.16.0.1"))
    val win = NetX.parseLink("lancast://pair?v=2&id=0123456789abcdef&n=PC-%E5%85%AC%E5%8F%B8&p=123456&port=47800&ip=10.9.9.9,172.16.0.2")!!
    eq("电脑端（encodeURIComponent）生成的链接", listOf(win.name, win.pin, win.ips.joinToString(",")), listOf("PC-公司", "123456", "10.9.9.9,172.16.0.2"))
    eq("旧版电脑端的二维码（v=1）也能解析", NetX.parseLink("lancast://pair?v=1&id=abcd1234&n=PC&p=123456&port=47800&ip=192.168.1.5")?.ips, listOf("192.168.1.5"))
    check("非法链接都返回 null", listOf("", "https://x.com/?id=abcd&p=123456&ip=1.2.3.4", "lancast://pair?v=2&id=abcd1234&p=12ab56&ip=192.168.1.5", "lancast://pair?v=2&id=ab&p=123456&ip=192.168.1.5",
        "lancast://pair?v=2&id=abcd1234&p=123456&ip=", "lancast://pair?v=2&id=abcd1234&p=123456&ip=127.0.0.1,169.254.1.1,224.0.0.1").all { NetX.parseLink(it) == null })
    val odd = NetX.parseLink("lancast://pair?v=2&id=abcd1234&p=123456&port=99999&ip=192.168.1.5,nope,172.16.0.1,192.168.1.5")!!
    eq("非法端口回落、非法 IP 剔除、缺名字用默认名", listOf(odd.port, odd.ips, odd.name), listOf(47800, listOf("192.168.1.5", "172.16.0.1"), "对方设备"))

    /* 连不上的提示 */
    check("提示：没网", NetX.unreachableHint(NetX.state(emptyList()), listOf("1.2.3.4")).contains("没有网络"))
    check("提示：流量 + 蒲公英 → 检查对方 / 防火墙", NetX.unreachableHint(NetX.state(listOf(cell, vpn)), listOf("172.16.0.1")).let { it.contains("同一个虚拟局域网") && it.contains("放行防火墙") })
    check("提示：仅移动数据 → 先打开蒲公英", NetX.unreachableHint(NetX.state(listOf(cell)), listOf("192.168.1.5", "172.16.0.1")).let { it.contains("只有移动数据") && it.contains("蒲公英") && it.contains("192.168.1.5、172.16.0.1") })
    check("提示：只有 Wi-Fi → 先加入虚拟网络", NetX.unreachableHint(NetX.state(listOf(wifi)), listOf("172.16.0.1")).contains("没有检测到虚拟局域网"))

    /* 并行探测（真实 TCP，127.0.0.1） */
    val srv = ServerSocket(0, 50, java.net.InetAddress.getByName("127.0.0.1"))
    val port = srv.localPort
    Thread { while (true) { try { srv.accept().close() } catch (e: Exception) { break } } }.apply { isDaemon = true; start() }
    eq("探测：连得通的返回", NetX.probe(listOf("127.0.0.1"), port), listOf("127.0.0.1"))
    val dead = ServerSocket(0).use { it.localPort }
    eq("探测：端口没人听 → 空", NetX.probe(listOf("127.0.0.1"), dead, timeoutMs = 1000), emptyList<String>())
    eq("探测：空列表 / 非法地址 → 空", listOf(NetX.probe(emptyList(), port), NetX.probe(listOf("nope"), port)), listOf(emptyList<String>(), emptyList<String>()))
    val t0 = System.currentTimeMillis()
    eq("探测（all）：只返回连得通的，且按传入顺序", NetX.probe(listOf("127.0.0.1", "127.0.0.2"), dead, timeoutMs = 1000, all = true), emptyList<String>())
    val mixed = NetX.probe(listOf("127.0.0.1", "127.0.0.2"), port, all = true)
    check("探测（all）：127.0.0.1 与 127.0.0.2 都连得通（回环段）", mixed.isNotEmpty() && mixed[0] == "127.0.0.1")
    check("探测不会卡住（全部用时 < 6 秒）", System.currentTimeMillis() - t0 < 6000)
    srv.close()

    println(if (fail == 0) "\nALL $pass PASSED" else "\n$fail FAILED, $pass passed")
    System.exit(if (fail == 0) 0 else 1)
}
