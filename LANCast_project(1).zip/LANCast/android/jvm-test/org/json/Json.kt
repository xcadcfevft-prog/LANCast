package org.json

class JSONException(m: String) : Exception(m)

class JSONArray() {
    val list = ArrayList<Any?>()
    constructor(s: String) : this() { val p = Parser(s); val v = p.value(); if (v !is JSONArray) throw JSONException("not array"); list.addAll(v.list) }
    fun put(v: Any?): JSONArray { list.add(v); return this }
    fun length() = list.size
    fun optString(i: Int, d: String = ""): String = list.getOrNull(i)?.let { if (it is String) it else it.toString() } ?: d
    fun getJSONObject(i: Int): JSONObject = list[i] as? JSONObject ?: throw JSONException("not object")
    override fun toString(): String = "[" + list.joinToString(",") { Parser.enc(it) } + "]"
}

class JSONObject() {
    val map = LinkedHashMap<String, Any?>()
    constructor(s: String) : this() { val v = Parser(s).value(); if (v !is JSONObject) throw JSONException("not object"); map.putAll(v.map) }
    fun put(k: String, v: Any?): JSONObject { map[k] = v; return this }
    fun optString(k: String, d: String = ""): String { val v = map[k]; return if (v == null) d else if (v is String) v else v.toString() }
    fun optInt(k: String, d: Int = 0): Int = (map[k] as? Number)?.toInt() ?: d
    fun optLong(k: String, d: Long = 0L): Long = (map[k] as? Number)?.toLong() ?: d
    fun optBoolean(k: String, d: Boolean = false): Boolean = (map[k] as? Boolean) ?: d
    fun optJSONArray(k: String): JSONArray? = map[k] as? JSONArray
    fun optJSONObject(k: String): JSONObject? = map[k] as? JSONObject
    fun keys(): Iterator<String> = map.keys.toList().iterator()
    override fun toString(): String = "{" + map.entries.joinToString(",") { Parser.enc(it.key) + ":" + Parser.enc(it.value) } + "}"
}

class Parser(private val s: String) {
    private var i = 0
    companion object {
        fun enc(v: Any?): String = when (v) {
            null -> "null"
            is String -> { val sb = StringBuilder("\""); for (c in v) when (c) { '"' -> sb.append("\\\""); '\\' -> sb.append("\\\\"); '\n' -> sb.append("\\n"); '\r' -> sb.append("\\r"); '\t' -> sb.append("\\t"); else -> if (c < ' ') sb.append("\\u%04x".format(c.code)) else sb.append(c) }; sb.append('"').toString() }
            else -> v.toString()
        }
    }
    private fun ws() { while (i < s.length && s[i].isWhitespace()) i++ }
    fun value(): Any? {
        ws()
        val c = s[i]
        return when {
            c == '{' -> { i++; val o = JSONObject(); ws(); if (s[i] == '}') { i++; return o }
                while (true) { ws(); val k = str(); ws(); if (s[i++] != ':') throw JSONException("colon"); o.map[k] = value(); ws(); val d = s[i++]; if (d == '}') break; if (d != ',') throw JSONException("comma") }; o }
            c == '[' -> { i++; val a = JSONArray(); ws(); if (s[i] == ']') { i++; return a }
                while (true) { a.list.add(value()); ws(); val d = s[i++]; if (d == ']') break; if (d != ',') throw JSONException("comma") }; a }
            c == '"' -> str()
            s.startsWith("true", i) -> { i += 4; true }
            s.startsWith("false", i) -> { i += 5; false }
            s.startsWith("null", i) -> { i += 4; null }
            else -> { val st = i; while (i < s.length && (s[i].isDigit() || s[i] in "+-.eE")) i++; val t = s.substring(st, i); if (t.any { it in ".eE" }) t.toDouble() else t.toLong() }
        }
    }
    private fun str(): String {
        if (s[i++] != '"') throw JSONException("quote")
        val sb = StringBuilder()
        while (true) {
            val c = s[i++]
            if (c == '"') break
            if (c == '\\') { when (val e = s[i++]) { 'n' -> sb.append('\n'); 'r' -> sb.append('\r'); 't' -> sb.append('\t'); 'b' -> sb.append('\b'); 'f' -> sb.append('\u000c'); 'u' -> { sb.append(s.substring(i, i + 4).toInt(16).toChar()); i += 4 }; else -> sb.append(e) } } else sb.append(c)
        }
        return sb.toString()
    }
}
