import com.lancast.app.MagnetCore

private var n = 0
private fun check(name: String, ok: Boolean) { if (!ok) throw AssertionError("FAIL: $name"); n++ }
private fun fails(name: String, contains: String, f: () -> Unit) {
    try { f() } catch (e: IllegalArgumentException) { check(name, e.message!!.contains(contains)); return }
    throw AssertionError("FAIL(no throw): $name")
}

fun main() {
    val h = "0123456789abcdef0123456789abcdef01234567"
    // 十六进制 / 大写 / base32 / 多个 xt
    check("hex", MagnetCore.parse("magnet:?xt=urn:btih:$h").hash == h)
    check("upper", MagnetCore.parse("MAGNET:?XT=URN:BTIH:${h.uppercase()}").hash == h)
    check("base32", MagnetCore.parse("magnet:?xt=urn:btih:AERUKZ4JVPG66AJDIVTYTK6N54ASGRLH").hash == h)
    check("multi xt", MagnetCore.parse("magnet:?xt=urn:sha1:zzz&xt=urn:btih:$h").hash == h)
    // dn / tr / x.pe
    val l = MagnetCore.parse("magnet:?xt=urn:btih:$h&dn=%E6%B5%8B%E8%AF%95+%E5%90%88%E9%9B%86&tr=udp%3A%2F%2Fa.com%3A80%2Fannounce&tr.1=http://b.com/announce&tr=udp://a.com:80/announce&x.pe=1.2.3.4:6881&x.pe=bad&tr=ftp://x")
    check("dn", l.name == "测试 合集")
    check("trackers", l.trackers == listOf("udp://a.com:80/announce", "http://b.com/announce"))
    check("peers", l.peers == listOf("1.2.3.4:6881"))
    // 容错
    check("html", MagnetCore.parse("<magnet:?xt=urn:btih:$h&amp;dn=abc>").name == "abc")
    check("fullwidth", MagnetCore.parse("ｍａｇｎｅｔ：？ｘｔ＝ｕｒｎ：ｂｔｉｈ：$h").hash == h)
    check("linebreak", MagnetCore.parse("magnet:?xt=urn:btih:${h.take(20)}​\n${h.drop(20)}").hash == h)
    check("bare", MagnetCore.parse(h.uppercase()).hash == h)
    check("btih prefix", MagnetCore.parse("btih:$h").hash == h)
    val th = "thunder://" + java.util.Base64.getEncoder().encodeToString("AAmagnet:?xt=urn:btih:${h}ZZ".toByteArray())
    check("thunder", MagnetCore.parse(th).hash == h)
    check("in text", MagnetCore.parse("资源在这里：magnet:?xt=urn:btih:$h&dn=a。 下载吧").hash == h)
    // 错误提示
    fails("not magnet", "不是磁力链接") { MagnetCore.parse("hello") }
    fails("empty", "不是磁力链接") { MagnetCore.parse("") }
    fails("no xt", "缺少") { MagnetCore.parse("magnet:?dn=abc") }
    fails("bad hash", "哈希格式") { MagnetCore.parse("magnet:?xt=urn:btih:xyz") }
    fails("v2 only", "v2") { MagnetCore.parse("magnet:?xt=urn:btmh:1220" + "ab".repeat(32)) }
    // 多条去重
    val a = h; val b = "f".repeat(40)
    val all = MagnetCore.extract("1) magnet:?xt=urn:btih:$a&dn=A\n2) magnet:?xt=urn:btih:$b\n3) magnet:?xt=urn:btih:${a.uppercase()}\n4) magnet:?xt=urn:btih:bad")
    check("extract", all.map { it.hash } == listOf(a, b))
    // 生成
    val built = MagnetCore.build(l, listOf("udp://a.com:80/announce", "udp://c.com:1/announce"))
    check("build", built.startsWith("magnet:?xt=urn:btih:$h&dn=%E6%B5%8B%E8%AF%95%20%E5%90%88%E9%9B%86&tr=udp%3A%2F%2Fa.com%3A80%2Fannounce"))
    check("build dedupe", built.split("a.com%3A80").size == 2 && built.contains("c.com"))
    check("round trip", MagnetCore.parse(built).hash == h && MagnetCore.parse(built).name == "测试 合集")
    // 工具
    check("size", MagnetCore.formatSize(0) == "0 B" && MagnetCore.formatSize(1536) == "1.50 KB" && MagnetCore.formatSize(3L * 1024 * 1024 * 1024) == "3.00 GB")
    check("pad", MagnetCore.isPadding("x/.pad/123") && MagnetCore.isPadding("_____padding_file_0_x") && !MagnetCore.isPadding("x/a.mkv"))
    println("MagnetCoreTest: ALL $n PASSED")
}
