package com.lancast.app

import org.json.JSONArray
import org.json.JSONObject
import java.math.BigInteger
import java.security.AlgorithmParameters
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.PrivateKey
import java.security.SecureRandom
import java.security.interfaces.ECPublicKey
import java.security.spec.ECGenParameterSpec
import java.security.spec.ECParameterSpec
import java.security.spec.ECPoint
import java.security.spec.ECPublicKeySpec
import javax.crypto.Cipher
import javax.crypto.KeyAgreement
import javax.crypto.Mac
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

/**
 * 瞬流「安全聊天」——加密与消息校验。与 Windows 端 windows/chatcrypto.js 逐字节一致（两端已互相对跑验证），
 * 规范见 docs/PROTOCOL.md 第 14 节。
 *
 * 会话密钥：双方各发一个本连接专用的 P-256 临时公钥（65 字节未压缩点，hex）→ ECDH 得到 Z →
 *   prk     = HMAC-SHA256(key = utf8(服务端nonce + ":" + 客户端cn), msg = Z ‖ utf8(服务端配对密钥 + ":" + 客户端配对密钥))
 *   key_c2s = HMAC(prk, "lancast-chat-v1 c2s " + 客户端epk + " " + 服务端epk + 0x01)
 *   key_s2c = HMAC(prk, "lancast-chat-v1 s2c " + 客户端epk + " " + 服务端epk + 0x01)
 *   sas     = HMAC(prk, "lancast-chat-v1 sas" + 0x01) 前 6 字节 → 12 位数字「安全码」
 * 双方的配对密钥都参与派生：中间人（不知道配对密钥）、冒充别人 ID 的已配对设备（不知道对方自己的密钥）都算不出同一把钥匙。
 *
 * 消息帧正文 = u64 计数器(大端) ‖ AES-256-GCM 密文 ‖ 16 字节标签；IV = 4 个 0 字节 ‖ 计数器；AAD = 计数器的 8 个字节；
 * 两个方向各用各的密钥；接收方要求计数器严格递增（防重放），解密失败就断开。
 */
object ChatCrypto {
    const val T_CHAT_KEY = 48
    const val T_CHAT_MSG = 49
    const val MAX_TEXT = 4000
    const val MAX_FRAME = 64 * 1024

    private val rnd = SecureRandom()

    /** 一次连接专用的临时密钥对；pub = "04" + X + Y（130 个 hex 字符） */
    class Eph(val priv: PrivateKey, val pub: String)

    class Keys(val txKey: ByteArray, val rxKey: ByteArray, val sas: String)

    /** 解出来的明文消息（已按规则整理过，字段都限了长） */
    class Plain(
        val t: String,                       // m 文字 | s 表情包 | a 回执 | hi 问候
        val id: String = "",
        val ts: Long = 0L,
        val x: String = "",
        val e: String = "",
        val c: String = "",
        val bg: List<String> = emptyList(),
        val name: String = ""
    )

    class Opened(val ctr: Long, val obj: JSONObject)

    // ───────── 工具 ─────────
    fun hex(b: ByteArray): String {
        val sb = StringBuilder(b.size * 2)
        for (x in b) sb.append("%02x".format(x.toInt() and 0xFF))
        return sb.toString()
    }

    fun unhex(s: String): ByteArray {
        val r = ByteArray(s.length / 2)
        for (i in r.indices) r[i] = s.substring(i * 2, i * 2 + 2).toInt(16).toByte()
        return r
    }

    private fun hmac(key: ByteArray, msg: ByteArray): ByteArray {
        val m = Mac.getInstance("HmacSHA256")
        m.init(SecretKeySpec(key, "HmacSHA256"))
        return m.doFinal(msg)
    }

    private fun fixed32(v: BigInteger): ByteArray {
        val raw = v.toByteArray()
        val out = ByteArray(32)
        val n = minOf(raw.size, 32)
        System.arraycopy(raw, raw.size - n, out, 32 - n, n)
        return out
    }

    fun newMsgId(): String {
        val b = ByteArray(8)
        rnd.nextBytes(b)
        return hex(b)
    }

    /** 按「字符」（Unicode 码点，和电脑端的 [...s] 一致）截断 */
    fun clip(s: String, n: Int): String {
        val cp = s.codePointCount(0, s.length)
        if (cp <= n) return s
        return s.substring(0, s.offsetByCodePoints(0, n))
    }

    // ───────── P-256 ─────────
    private val P = BigInteger("FFFFFFFF00000001000000000000000000000000FFFFFFFFFFFFFFFFFFFFFFFF", 16)
    private val B = BigInteger("5AC635D8AA3A93E7B3EBBD55769886BC651D06B0CC53B0F63BCE3C3E27D2604B", 16)

    private val curve: ECParameterSpec by lazy {
        val ap = AlgorithmParameters.getInstance("EC")
        ap.init(ECGenParameterSpec("secp256r1"))
        ap.getParameterSpec(ECParameterSpec::class.java)
    }

    fun validPub(h: String): Boolean = h.length == 130 && h.startsWith("04") && h.all { (it in '0'..'9') || (it in 'a'..'f') }

    fun genEphemeral(): Eph {
        val kpg = KeyPairGenerator.getInstance("EC")
        kpg.initialize(ECGenParameterSpec("secp256r1"), rnd)
        val kp = kpg.generateKeyPair()
        val w = (kp.public as ECPublicKey).w
        return Eph(kp.private, "04" + hex(fixed32(w.affineX)) + hex(fixed32(w.affineY)))
    }

    private fun decodePub(h: String): java.security.PublicKey {
        if (!validPub(h)) throw IllegalArgumentException("对方的密钥格式不对")
        val raw = unhex(h)
        val x = BigInteger(1, raw.copyOfRange(1, 33))
        val y = BigInteger(1, raw.copyOfRange(33, 65))
        // 点必须在曲线上（y² = x³ − 3x + b mod p），否则一律拒绝（防「无效曲线」攻击）
        if (x >= P || y >= P) throw IllegalArgumentException("对方的密钥不在曲线上")
        val lhs = y.multiply(y).mod(P)
        val rhs = x.multiply(x).multiply(x).subtract(x.multiply(BigInteger.valueOf(3))).add(B).mod(P)
        if (lhs != rhs) throw IllegalArgumentException("对方的密钥不在曲线上")
        return KeyFactory.getInstance("EC").generatePublic(ECPublicKeySpec(ECPoint(x, y), curve))
    }

    /** isClient：本端是否发起连接的一方；pin = 「服务端配对密钥:客户端配对密钥」。对端公钥非法时抛异常，调用方按「安全校验失败」处理。 */
    fun deriveSession(eph: Eph, peerPub: String, isClient: Boolean, serverNonce: String, clientNonce: String, pin: String): Keys {
        val ka = KeyAgreement.getInstance("ECDH")
        ka.init(eph.priv)
        ka.doPhase(decodePub(peerPub), true)
        val z = ka.generateSecret()
        val zz = if (z.size == 32) z else fixed32(BigInteger(1, z))
        val epkC = if (isClient) eph.pub else peerPub
        val epkS = if (isClient) peerPub else eph.pub
        val prk = hmac((serverNonce + ":" + clientNonce).toByteArray(Charsets.UTF_8), zz + pin.toByteArray(Charsets.UTF_8))
        fun kdf(label: String): ByteArray = hmac(prk, ("lancast-chat-v1 $label$epkC $epkS").toByteArray(Charsets.UTF_8) + byteArrayOf(1))
        val c2s = kdf("c2s ")
        val s2c = kdf("s2c ")
        val sasRaw = hmac(prk, "lancast-chat-v1 sas".toByteArray(Charsets.UTF_8) + byteArrayOf(1)).copyOf(6)
        val num = BigInteger(1, sasRaw).mod(BigInteger.TEN.pow(12)).toString().padStart(12, '0')
        return Keys(if (isClient) c2s else s2c, if (isClient) s2c else c2s, num.chunked(4).joinToString(" "))
    }

    // ───────── 消息加解密 ─────────
    private fun ctrBytes(ctr: Long): ByteArray {
        val b = ByteArray(8)
        for (i in 0 until 8) b[7 - i] = ((ctr ushr (8 * i)) and 0xFF).toByte()
        return b
    }

    private fun ivOf(ctr: Long): ByteArray = ByteArray(4) + ctrBytes(ctr)

    fun seal(key: ByteArray, ctr: Long, obj: JSONObject): ByteArray {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, ivOf(ctr)))
        c.updateAAD(ctrBytes(ctr))
        return ctrBytes(ctr) + c.doFinal(obj.toString().toByteArray(Charsets.UTF_8))
    }

    /** 任何问题（太短、计数器不递增、标签不对、不是 JSON 对象）都抛异常 */
    fun open(key: ByteArray, buf: ByteArray, lastCtr: Long): Opened {
        if (buf.size < 8 + 16 + 2 || buf.size > MAX_FRAME) throw IllegalArgumentException("消息长度不对")
        var big = 0L
        for (i in 0 until 8) big = (big shl 8) or (buf[i].toLong() and 0xFF)
        if (big < 0L || big > 9007199254740991L) throw IllegalArgumentException("计数器越界")
        if (big <= lastCtr) throw IllegalArgumentException("重复或过期的消息")
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, SecretKeySpec(key, "AES"), GCMParameterSpec(128, ivOf(big)))
        c.updateAAD(ctrBytes(big))
        val pt = c.doFinal(buf, 8, buf.size - 8)
        return Opened(big, JSONObject(String(pt, Charsets.UTF_8)))
    }

    // ───────── 消息内容整理 ─────────
    private val ID_RE = Regex("^[0-9a-f]{8,32}$")
    private val COLOR_RE = Regex("^#[0-9a-fA-F]{6}$")
    val DEFAULT_BG = listOf("#fff3c4", "#ffd37a")

    /** 把对方发来的明文整理成本机可以直接显示的消息；不合法返回 null（调用方丢弃）。所有字段都限长，颜色只接受 #rrggbb。 */
    fun sanitize(o: JSONObject, now: Long): Plain? {
        val t = o.optString("t", "")
        if (t == "a") {
            val id = o.optString("id", "")
            return if (ID_RE.matches(id)) Plain("a", id = id) else null
        }
        if (t == "hi") return Plain("hi", name = clip(o.optString("name", ""), 64), id = clip(o.optString("id", ""), 64))
        if (t != "m" && t != "s") return null
        val id = o.optString("id", "")
        if (!ID_RE.matches(id)) return null
        val rawTs = o.optLong("ts", now)
        val ts = if (rawTs < 0L) now else minOf(rawTs, now + 86_400_000L)
        if (t == "m") {
            val x = clip(o.optString("x", ""), MAX_TEXT)
            return if (x.isBlank()) null else Plain("m", id = id, ts = ts, x = x)
        }
        val e = clip(o.optString("e", ""), 16)
        val c = clip(o.optString("c", ""), 16)
        if (e.isEmpty()) return null
        val bgArr: JSONArray? = o.optJSONArray("bg")
        val colors = ArrayList<String>()
        if (bgArr != null) for (i in 0 until bgArr.length()) {
            val v = bgArr.optString(i, "")
            if (COLOR_RE.matches(v)) colors.add(v)
            if (colors.size >= 2) break
        }
        return Plain("s", id = id, ts = ts, e = e, c = c, bg = if (colors.size == 2) colors else DEFAULT_BG)
    }
}
