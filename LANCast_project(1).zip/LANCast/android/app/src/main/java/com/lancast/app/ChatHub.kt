package com.lancast.app

import org.json.JSONArray
import org.json.JSONObject

/**
 * 瞬流「安全聊天」——连接管理与消息状态机（纯逻辑：不碰 Android API，网络 / 存储 / 通知都由 ChatEnv 注入，方便在 JVM 上单元测试）。
 * 与 Windows 端 windows/chathub.js 是同一套逻辑，规范见 docs/PROTOCOL.md 第 14 节。
 *
 * 消息状态：sending（还没收到对方的回执，会自动重发）→ sent（对方已收到）/ failed（对方不在线或多次重发失败，点一下可重试）。
 * 两台设备同时互相发起连接时会出现两条连接：双方用同一条规则（发起方设备 ID 较小的那条）选「发送用」的连接，
 * 接收则两条都收；每条消息有唯一 ID，重复的只存一份，所以不会丢也不会重。
 *
 * 线程：对外的方法都加了同一把锁；ChatEnv 的回调（changed / notify）在锁内同步调用，实现里请只做「投递到主线程」之类不阻塞的事。
 */
class ChatPeer(val id: String, val name: String, val pin: String, val ip: String, val port: Int, val online: Boolean)

/** 一条聊天记录（文字或表情包）。字段名与电脑端存储一致。 */
class ChatMsg(
    val id: String,
    var ts: Long,
    val from: String,            // me | peer
    val k: String,               // m 文字 | s 表情包
    val x: String = "",
    val e: String = "",
    val c: String = "",
    val bg: List<String> = emptyList(),
    var st: String = "sent",     // sending | sent | failed（只对 from = me 有意义）
    var tries: Int = 0,
    var lt: Long = 0L
) {
    val mine: Boolean get() = from == "me"

    fun toJson(): JSONObject {
        val o = JSONObject().put("id", id).put("ts", ts).put("from", from).put("k", k).put("st", st).put("tries", tries).put("lt", lt)
        if (k == "m") o.put("x", x) else {
            o.put("e", e).put("c", c)
            val a = JSONArray(); for (v in bg) a.put(v); o.put("bg", a)
        }
        return o
    }

    companion object {
        fun fromJson(o: JSONObject): ChatMsg? {
            val id = o.optString("id", ""); if (id.isEmpty()) return null
            val bgA = o.optJSONArray("bg")
            val bg = ArrayList<String>()
            if (bgA != null) for (i in 0 until bgA.length()) bg.add(bgA.optString(i))
            return ChatMsg(id, o.optLong("ts", 0L), o.optString("from", "peer"), o.optString("k", "m"), o.optString("x", ""),
                o.optString("e", ""), o.optString("c", ""), bg, o.optString("st", "sent"), o.optInt("tries", 0), o.optLong("lt", 0L))
        }
    }
}

/** 一条已建立的会话（握手已通过），由平台层实现：发帧 / 关闭。 */
interface ChatLink {
    fun send(type: Int, payload: ByteArray)
    fun close(reason: String)
}

class ChatDial(val link: ChatLink, val serverNonce: String, val clientNonce: String)

interface ChatEnv {
    val myId: String
    val myName: String
    fun myPin(): String
    fun peers(): List<ChatPeer>
    fun load(peerId: String): String?
    fun save(peerId: String, json: String)
    fun loadUnread(): String?
    fun saveUnread(json: String)
    /** 主动连对方（mode = "chat"）并完成握手；阻塞调用，失败抛异常。调用线程不持有 hub 的锁。 */
    fun dial(p: ChatPeer): ChatDial
    fun changed(peerId: String)
    fun notify(peerId: String, name: String, msg: ChatMsg)
    fun now(): Long = System.currentTimeMillis()
}

class ChatHub(private val env: ChatEnv) {
    companion object {
        const val MAX_KEEP = 500
        const val RESEND_MS = 4000L
        const val MAX_TRIES = 4
        const val FAIL_AFTER_MS = 30000L
        const val REDIAL_MS = 3000L
        const val KEY_TIMEOUT_MS = 8000L
    }

    class Meta(val peerId: String, val isClient: Boolean, val serverNonce: String, val clientNonce: String, val pin: String, val peerName: String)

    class Conn(val link: ChatLink, val meta: Meta, val eph: ChatCrypto.Eph, val t: Long) {
        val peerId: String get() = meta.peerId
        val isClient: Boolean get() = meta.isClient
        var tx: ByteArray? = null
        var rx: ByteArray? = null
        var txCtr = 0L
        var rxCtr = 0L
        var ready = false
        var closed = false
        var gotKey = false
    }

    private val lock = Any()
    private val cache = HashMap<String, ArrayList<ChatMsg>>()
    private val conns = HashMap<String, ArrayList<Conn>>()
    private val dialing = HashSet<String>()
    private val lastDial = HashMap<String, Long>()
    private val pending = HashSet<String>()
    private val sasOf = HashMap<String, String>()
    private val unread = HashMap<String, Int>()

    /** 界面正在显示的聊天（该聊天的新消息不计未读） */
    @Volatile var viewing: String? = null

    init {
        try {
            val o = JSONObject(env.loadUnread() ?: "{}")
            for (k in o.keys()) { val n = o.optInt(k, 0); if (n > 0) unread[k] = n }
        } catch (ignored: Exception) { }
        try { for (p in env.peers()) if (msgs(p.id).any { it.mine && it.st == "sending" }) pending.add(p.id) } catch (ignored: Exception) { }
    }

    // ───────── 存储 ─────────
    private fun msgs(id: String): ArrayList<ChatMsg> = cache.getOrPut(id) {
        val l = ArrayList<ChatMsg>()
        try {
            val a = JSONArray(env.load(id) ?: "[]")
            for (i in 0 until a.length()) ChatMsg.fromJson(a.getJSONObject(i))?.let { l.add(it) }
        } catch (ignored: Exception) { }
        l
    }

    private fun persist(id: String) {
        val a = msgs(id)
        while (a.size > MAX_KEEP) a.removeAt(0)
        val arr = JSONArray()
        for (m in a) arr.put(m.toJson())
        try { env.save(id, arr.toString()) } catch (ignored: Exception) { }
    }

    private fun setUnread(id: String, n: Int) {
        if (n > 0) unread[id] = n else unread.remove(id)
        val o = JSONObject()
        for ((k, v) in unread) o.put(k, v)
        try { env.saveUnread(o.toString()) } catch (ignored: Exception) { }
    }

    private fun peerInfo(id: String): ChatPeer? = env.peers().firstOrNull { it.id == id }

    // ───────── 连接 ─────────
    private fun liveConns(id: String): List<Conn> = (conns[id] ?: arrayListOf<Conn>()).filter { !it.closed }

    /** 双方一致的选择规则：发起方 ID 较小的那条优先；同一发起方取最新的 */
    private fun bestConn(id: String): Conn? {
        var best: Conn? = null
        var bestRank = ""
        for (c in liveConns(id)) {
            if (!c.ready) continue
            val rank = if (c.isClient) env.myId else id
            if (best == null || rank < bestRank || (rank == bestRank && c.t > best.t)) { best = c; bestRank = rank }
        }
        return best
    }

    private fun sendObj(c: Conn, obj: JSONObject) {
        c.txCtr += 1
        c.link.send(ChatCrypto.T_CHAT_MSG, ChatCrypto.seal(c.tx!!, c.txCtr, obj))
    }

    private fun killLocked(c: Conn, reason: String) {
        if (c.closed) return
        c.closed = true
        conns[c.peerId]?.remove(c)
        try { c.link.close(reason) } catch (ignored: Exception) { }
        env.changed(c.peerId)
    }

    /**
     * 把一条已建立（握手已通过）的会话接进来。**先**调用本方法（它会立刻把本端的临时公钥发出去），**再**让会话开始读数据。
     * 返回的 Conn 交给平台层，之后收到的帧调用 onFrame，会话断开调用 onClosed。
     */
    fun attach(link: ChatLink, meta: Meta): Conn = synchronized(lock) { newConn(link, meta) }

    private fun newConn(link: ChatLink, meta: Meta): Conn {
        val c = Conn(link, meta, ChatCrypto.genEphemeral(), env.now())
        conns.getOrPut(meta.peerId) { ArrayList() }.add(c)
        link.send(ChatCrypto.T_CHAT_KEY, JSONObject().put("v", 1).put("epk", c.eph.pub).toString().toByteArray(Charsets.UTF_8))
        return c
    }

    fun onClosed(c: Conn) {
        synchronized(lock) {
            if (c.closed) return@synchronized
            c.closed = true
            conns[c.peerId]?.remove(c)
            env.changed(c.peerId)
        }
    }

    fun onFrame(c: Conn, type: Int, payload: ByteArray) {
        synchronized(lock) { onFrameLocked(c, type, payload) }
    }

    private fun onFrameLocked(c: Conn, type: Int, payload: ByteArray) {
        if (c.closed) return
        try {
            if (type == ChatCrypto.T_CHAT_KEY) {
                if (c.gotKey) return
                c.gotKey = true
                val epk = try { JSONObject(String(payload, Charsets.UTF_8)).optString("epk", "") } catch (e: Exception) { killLocked(c, "协议错误"); return }
                val k = try {
                    ChatCrypto.deriveSession(c.eph, epk, c.isClient, c.meta.serverNonce, c.meta.clientNonce, c.meta.pin)
                } catch (e: Exception) { killLocked(c, "安全校验失败"); return }
                c.tx = k.txKey; c.rx = k.rxKey; c.ready = true
                sasOf[c.peerId] = k.sas
                sendObj(c, JSONObject().put("t", "hi").put("name", env.myName).put("id", env.myId))
                env.changed(c.peerId)
                flush(c.peerId)
            } else if (type == ChatCrypto.T_CHAT_MSG) {
                if (!c.ready) { killLocked(c, "协议错误"); return }
                val r = try { ChatCrypto.open(c.rx!!, payload, c.rxCtr) } catch (e: Exception) {
                    killLocked(c, "安全校验失败，已断开（消息被篡改，或对方密钥不对）"); return
                }
                c.rxCtr = r.ctr
                onPlain(c, ChatCrypto.sanitize(r.obj, env.now()))
            }
        } catch (e: Exception) {
            // 单个帧出问题不影响连接
        }
    }

    private fun onPlain(c: Conn, m: ChatCrypto.Plain?) {
        if (m == null) return
        val id = c.peerId
        if (m.t == "a") {
            val x = msgs(id).firstOrNull { it.id == m.id && it.mine }
            if (x != null && x.st != "sent") { x.st = "sent"; persist(id); env.changed(id) }
            return
        }
        if (m.t == "hi") return
        // 文字 / 表情包：先回执（不管是不是重复，回执丢了对方会重发），再存
        try { sendObj(c, JSONObject().put("t", "a").put("id", m.id)) } catch (ignored: Exception) { }
        val a = msgs(id)
        if (a.any { it.id == m.id }) return
        val rec = if (m.t == "s") ChatMsg(m.id, if (m.ts > 0) m.ts else env.now(), "peer", "s", e = m.e, c = m.c, bg = m.bg)
        else ChatMsg(m.id, if (m.ts > 0) m.ts else env.now(), "peer", "m", x = m.x)
        a.add(rec)
        a.sortBy { it.ts }
        persist(id)
        if (viewing != id) setUnread(id, (unread[id] ?: 0) + 1)
        val p = peerInfo(id)
        env.notify(id, p?.name ?: c.meta.peerName.ifEmpty { "对方" }, rec)
        env.changed(id)
    }

    // ───────── 发送 / 重发 ─────────
    private fun flush(id: String) {
        val a = msgs(id)
        val c = bestConn(id) ?: return
        var dirty = false
        val now = env.now()
        for (m in a) {
            if (!m.mine || m.st != "sending") continue
            if (m.lt != 0L && now - m.lt < RESEND_MS) continue
            if (m.tries >= MAX_TRIES) { m.st = "failed"; dirty = true; continue }
            m.tries += 1; m.lt = now; dirty = true
            val body = if (m.k == "s") {
                val bg = JSONArray(); for (v in m.bg) bg.put(v)
                JSONObject().put("t", "s").put("id", m.id).put("ts", m.ts).put("e", m.e).put("c", m.c).put("bg", bg)
            } else JSONObject().put("t", "m").put("id", m.id).put("ts", m.ts).put("x", m.x)
            try { sendObj(c, body) } catch (e: Exception) { m.st = "sending" }
        }
        if (dirty) { persist(id); env.changed(id) }
    }

    private fun ensureConnLocked(id: String) {
        if (bestConn(id) != null || liveConns(id).isNotEmpty() || dialing.contains(id)) return
        if (env.now() - (lastDial[id] ?: 0L) < REDIAL_MS) return
        val p = peerInfo(id) ?: return
        lastDial[id] = env.now()
        dialing.add(id)
        Thread {
            try {
                val d = env.dial(p)
                synchronized(lock) {
                    dialing.remove(id)
                    onDialed(id, p, d)
                }
            } catch (e: Exception) {
                synchronized(lock) { dialing.remove(id) }
            }
        }.also { it.isDaemon = true }.start()
    }

    /** dial 成功后（已在锁内）：把会话接进来。平台层需要在 attach 之后启动读线程，所以交给 env 的 onDialed 回调——这里直接用 ChatDial.link 的实现自行启动。 */
    var onAttached: ((Conn) -> Unit)? = null

    private fun onDialed(id: String, p: ChatPeer, d: ChatDial) {
        // 派生密钥用「服务端的配对密钥:客户端的配对密钥」：本端是客户端，服务端的密钥 = 记录里对方的 pin，客户端的 = 本机的
        val c = newConn(d.link, Meta(id, true, d.serverNonce, d.clientNonce, p.pin + ":" + env.myPin(), p.name))
        onAttached?.invoke(c)
    }

    private fun add(id: String, rec: ChatMsg): ChatMsg {
        msgs(id).add(rec); persist(id); pending.add(id); env.changed(id)
        ensureConnLocked(id); flush(id)
        return rec
    }

    fun sendText(id: String, text: String): ChatMsg? {
        val x = ChatCrypto.clip(text, ChatCrypto.MAX_TEXT)
        if (x.isBlank()) return null
        return synchronized(lock) { add(id, ChatMsg(ChatCrypto.newMsgId(), env.now(), "me", "m", x = x, st = "sending")) }
    }

    fun sendSticker(id: String, s: Sticker): ChatMsg? {
        val e = ChatCrypto.clip(s.e, 16)
        if (e.isEmpty()) return null
        return synchronized(lock) {
            add(id, ChatMsg(ChatCrypto.newMsgId(), env.now(), "me", "s", e = e, c = ChatCrypto.clip(s.c, 16), bg = listOf(s.bg1, s.bg2), st = "sending"))
        }
    }

    fun retry(id: String, msgId: String) {
        synchronized(lock) {
            val m = msgs(id).firstOrNull { it.id == msgId && it.mine } ?: return@synchronized
            if (m.st != "failed") return@synchronized
            m.st = "sending"; m.tries = 0; m.lt = 0L; m.ts = env.now()
            persist(id); pending.add(id); lastDial.remove(id)
            env.changed(id); ensureConnLocked(id); flush(id)
        }
    }

    /** 每秒调用一次：补连、重发、把等太久的标成失败、清理超时没完成密钥交换的连接 */
    fun tick() {
        synchronized(lock) {
            val now = env.now()
            for (list in conns.values.toList()) for (c in list.toList()) if (!c.ready && !c.closed && now - c.t > KEY_TIMEOUT_MS) killLocked(c, "安全校验超时")
            for (id in pending.toList()) {
                val waiting = msgs(id).filter { it.mine && it.st == "sending" }
                if (waiting.isEmpty()) { pending.remove(id); continue }
                if (peerInfo(id) == null) { for (m in waiting) m.st = "failed"; persist(id); env.changed(id); continue }
                if (bestConn(id) != null) { flush(id); continue }
                ensureConnLocked(id)
                var dirty = false
                for (m in waiting) if (now - m.ts > FAIL_AFTER_MS) { m.st = "failed"; dirty = true }
                if (dirty) { persist(id); env.changed(id) }
            }
        }
    }

    // ───────── 查询 / 管理 ─────────
    fun messages(id: String): List<ChatMsg> = synchronized(lock) { ArrayList(msgs(id)) }
    fun unread(id: String): Int = synchronized(lock) { unread[id] ?: 0 }
    fun totalUnread(): Int = synchronized(lock) { unread.values.sum() }
    fun markRead(id: String) { synchronized(lock) { if ((unread[id] ?: 0) > 0) { setUnread(id, 0); env.changed(id) } } }
    fun sas(id: String): String = synchronized(lock) { if (bestConn(id) != null) sasOf[id] ?: "" else "" }
    fun isConnected(id: String): Boolean = synchronized(lock) { bestConn(id) != null }
    fun connections(id: String): Int = synchronized(lock) { liveConns(id).size }
    fun ensure(id: String) { synchronized(lock) { ensureConnLocked(id) } }
    fun clear(id: String) {
        synchronized(lock) {
            cache[id] = ArrayList(); try { env.save(id, "[]") } catch (ignored: Exception) { }
            setUnread(id, 0); pending.remove(id); env.changed(id)
        }
    }
    fun dropPeer(id: String) { synchronized(lock) { for (c in liveConns(id)) killLocked(c, "已取消配对") } }
    fun dispose() { synchronized(lock) { for (l in conns.values.toList()) for (c in l.toList()) killLocked(c, "关闭") } }
}
