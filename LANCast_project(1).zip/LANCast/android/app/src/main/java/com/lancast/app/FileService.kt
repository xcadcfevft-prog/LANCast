package com.lancast.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.IBinder
import android.os.PowerManager
import androidx.core.content.ContextCompat

/**
 * 文件传输期间的前台服务：让系统在你切到别的应用、熄屏时不要冻结传输，
 * 同时持有 CPU 唤醒锁和 Wi-Fi 锁，并在通知栏显示总进度。
 * 由 FileXfer 在第一个传输开始时启动、全部结束后（延迟几秒）停止。
 */
class FileService : Service() {
    companion object {
        private const val CH = "lancast_files"
        private const val NID = 2

        @Volatile
        private var inst: FileService? = null

        fun start() {
            try {
                ContextCompat.startForegroundService(Link.app, Intent(Link.app, FileService::class.java))
            } catch (ignored: Exception) {
                // 应用在后台时系统可能不允许启动前台服务；传输本身仍会继续，只是后台保活较弱
            }
        }

        fun stop() {
            try {
                Link.app.stopService(Intent(Link.app, FileService::class.java))
            } catch (ignored: Exception) {
            }
        }

        fun refresh() {
            inst?.updateNotification()
        }
    }

    private var wake: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        inst = this
        goForeground()
        acquireLocks()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        goForeground()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        inst = null
        releaseLocks()
        super.onDestroy()
    }

    private fun build(text: String, percent: Int): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CH) == null) {
            nm.createNotificationChannel(NotificationChannel(CH, "文件传输", NotificationManager.IMPORTANCE_LOW))
        }
        val b = Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("瞬流 文件互传")
            .setContentText(text)
            .setOnlyAlertOnce(true)
            .setOngoing(true)
        if (percent >= 0) b.setProgress(100, percent, false) else b.setProgress(0, 0, true)
        return b.build()
    }

    private fun goForeground() {
        try {
            startForeground(NID, build("正在准备传输…", -1), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } catch (e: Exception) {
            stopSelf()
        }
    }

    fun updateNotification() {
        var n = 0
        var done = 0L
        var total = 0L
        for (x in FileXfer.list) {
            if (x.active) {
                n++
                done += x.done
                total += x.size
            }
        }
        if (n == 0) return
        val pct = if (total > 0L) (done * 100L / total).toInt() else -1
        val text = "正在传输 $n 个文件 · " + FileXfer.human(done) + " / " + FileXfer.human(total)
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(NID, build(text, pct))
        } catch (ignored: Exception) {
        }
    }

    @Suppress("DEPRECATION")
    private fun acquireLocks() {
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "lancast:files").apply {
                setReferenceCounted(false)
                acquire(12L * 60L * 60L * 1000L)
            }
            val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            wifi = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "lancast-files").apply {
                setReferenceCounted(false)
                acquire()
            }
        } catch (ignored: Exception) {
        }
    }

    private fun releaseLocks() {
        try { wake?.let { if (it.isHeld) it.release() } } catch (ignored: Exception) { }
        try { wifi?.let { if (it.isHeld) it.release() } } catch (ignored: Exception) { }
        wake = null
        wifi = null
    }
}
