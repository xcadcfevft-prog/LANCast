package com.lancast.app

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapRegionDecoder
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import android.media.ExifInterface
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.util.LruCache
import android.util.Size
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.webkit.MimeTypeMap
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.MediaController
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import java.io.InputStream
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

/**
 * 聊天里图片 / 视频文件的「严格无损」预览。
 *
 * 严格无损 = 预览不改动、不重新编码任何一个字节：
 *   · 预览直接读「原文件」（发送方 = 选的原文件，接收方 = 已通过 SHA-256 校验、保存下来的文件），不做任何压缩 / 转码 / 另存副本；
 *   · 聊天气泡里只是缩略图（必须缩小才能放进气泡），点开后是全分辨率查看：
 *       - 图片：按原始像素 1:1 解码（ARGB_8888，8 位通道一个不丢），放大到 100% 以上用最近邻插值，看到的就是文件里真实的像素；
 *         超大图（任意一边 > 4096 或超过 1600 万像素）用分块解码，放大到哪里就把那一块按 1:1 解出来，内存不会爆，也不降分辨率；
 *       - 视频：用系统播放器直接播放原文件，不转码。
 *   · 唯一的例外：带 EXIF 旋转的超大图，系统限制无法整图解码时才会缩小显示，界面会明确写出来（文件本身依然原封不动）。
 */
internal object MediaKind {
    const val NONE = 0
    const val IMAGE = 1
    const val VIDEO = 2

    private val IMG = setOf("jpg", "jpeg", "png", "webp", "gif", "bmp", "avif", "heic", "heif")
    private val VID = setOf("mp4", "m4v", "mov", "mkv", "webm", "3gp", "3g2", "ts", "avi")

    fun of(name: String): Int {
        val dot = name.lastIndexOf('.')
        if (dot < 0 || dot == name.length - 1) return NONE
        val ext = name.substring(dot + 1).lowercase()
        return when {
            ext in IMG -> IMAGE
            ext in VID -> VIDEO
            else -> NONE
        }
    }

    fun mime(name: String): String {
        val dot = name.lastIndexOf('.')
        if (dot < 0 || dot == name.length - 1) return "*/*"
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substring(dot + 1).lowercase()) ?: "*/*"
    }
}

/** 气泡缩略图：内存缓存 + 后台解码。缓存命中同步返回（聊天页每次刷新都会重建视图，必须很快）。 */
internal object Thumbs {
    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }
    private val durations = ConcurrentHashMap<String, Long>()
    private val waiters = ConcurrentHashMap<String, (Bitmap?) -> Unit>()
    private val pool = Executors.newFixedThreadPool(2)
    private val ui = Handler(Looper.getMainLooper())
    private const val MAX_PX = 512

    fun get(uri: Uri): Bitmap? = cache.get(uri.toString())
    fun duration(uri: Uri): Long = durations[uri.toString()] ?: 0L

    /** 异步加载；同一个 uri 正在加载时，回调换成最新的那个（旧视图可能已被刷新掉） */
    fun load(ctx: Context, uri: Uri, kind: Int, done: (Bitmap?) -> Unit) {
        val key = uri.toString()
        val running = waiters.put(key, done) != null
        if (running) return
        val app = ctx.applicationContext
        pool.execute {
            val b = try { make(app, uri, kind, key) } catch (e: Throwable) { null }
            if (b != null) cache.put(key, b)
            val cb = waiters.remove(key)
            ui.post { cb?.invoke(b) }
        }
    }

    private fun make(ctx: Context, uri: Uri, kind: Int, key: String): Bitmap? {
        val cr = ctx.contentResolver
        if (kind == MediaKind.VIDEO) durations[key] = videoInfo(ctx, uri).second
        try {
            return cr.loadThumbnail(uri, Size(MAX_PX, MAX_PX), null)
        } catch (ignored: Throwable) { }
        if (kind == MediaKind.IMAGE) {
            return ImageDecoder.decodeBitmap(ImageDecoder.createSource(cr, uri)) { dec, info, _ ->
                dec.setTargetSampleSize(maxOf(1, maxOf(info.size.width, info.size.height) / MAX_PX))
                dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            }
        }
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, uri)
            return r.getScaledFrameAtTime(-1L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, MAX_PX, MAX_PX)
        } finally {
            try { r.release() } catch (ignored: Throwable) { }
        }
    }

    /** 视频：返回 (宽 x 高 的文字, 时长毫秒) */
    fun videoInfo(ctx: Context, uri: Uri): Pair<String, Long> {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, uri)
            var w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            var h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) { val t = w; w = h; h = t }
            val d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            Pair(if (w > 0 && h > 0) "$w×$h" else "", d)
        } catch (e: Throwable) {
            Pair("", 0L)
        } finally {
            try { r.release() } catch (ignored: Throwable) { }
        }
    }

    fun clock(ms: Long): String {
        val s = ms / 1000
        return if (s >= 3600) "%d:%02d:%02d".format(s / 3600, (s / 60) % 60, s % 60) else "%d:%02d".format(s / 60, s % 60)
    }
}

/**
 * 全分辨率图片查看器：双指缩放、单指拖动、双击在「适应屏幕 / 原始像素 1:1」间切换。
 * 小图一次解码整图；超大图分块（BitmapRegionDecoder）：一张低倍率总览 + 当前可见区域按放大倍数解出来的高清块。
 */
internal class ZoomImageView(ctx: Context) : View(ctx) {
    var onTap: (() -> Unit)? = null
    var onInfo: ((String) -> Unit)? = null

    private val ui = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val m = Matrix()

    @Volatile private var closed = false
    private var overview: Bitmap? = null
    private var ovSample = 1                 // 总览相对原图缩小的倍数（整图模式 = 1）
    private var imgW = 0
    private var imgH = 0
    private var decoder: BitmapRegionDecoder? = null
    private var pfd: ParcelFileDescriptor? = null
    private var stream: InputStream? = null
    private var tile: Bitmap? = null
    private val tileRect = Rect()
    private var tileSample = 1
    @Volatile private var gen = 0

    private var scale = 1f
    private var fit = 1f
    private var tx = 0f
    private var ty = 0f
    private val maxScale get() = maxOf(16f, fit * 4f)

    private val sg = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean { zoomAt(scale * d.scaleFactor, d.focusX, d.focusY); return true }
    })
    private val gd = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true
        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
            if (sg.isInProgress) return false
            tx -= dx; ty -= dy; clamp(); invalidate(); scheduleTile()
            return true
        }
        override fun onDoubleTap(e: MotionEvent): Boolean {
            if (overview == null) return false
            // 已放大 → 回到适应屏幕；否则放大到原始像素 1:1（原图比屏幕还小就放大 2.5 倍）
            val target = if (scale > fit * 1.05f) fit else maxOf(1f, fit * 2.5f)
            zoomAt(target, e.x, e.y)
            return true
        }
        override fun onSingleTapConfirmed(e: MotionEvent): Boolean { onTap?.invoke(); return true }
    })

    override fun onTouchEvent(ev: MotionEvent): Boolean { sg.onTouchEvent(ev); gd.onTouchEvent(ev); return true }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { super.onSizeChanged(w, h, ow, oh); if (overview != null) { val keep = scale <= fit * 1.001f; computeFit(); if (keep) scale = fit; clamp(); scheduleTile() } }

    private fun computeFit() {
        if (imgW <= 0 || imgH <= 0 || width <= 0 || height <= 0) return
        fit = minOf(width.toFloat() / imgW, height.toFloat() / imgH)
    }

    private fun clamp() {
        val dw = imgW * scale
        val dh = imgH * scale
        tx = if (dw <= width) (width - dw) / 2f else tx.coerceIn(width - dw, 0f)
        ty = if (dh <= height) (height - dh) / 2f else ty.coerceIn(height - dh, 0f)
    }

    private fun zoomAt(target: Float, fx: Float, fy: Float) {
        val ns = target.coerceIn(fit, maxScale)
        tx = fx - (fx - tx) * ns / scale
        ty = fy - (fy - ty) * ns / scale
        scale = ns
        clamp(); invalidate(); scheduleTile()
    }

    private fun fmtSize(n: Long): String = FileXfer.human(n)

    /** 打开图片。结果通过 onInfo 回报一行说明文字（分辨率 / 是否分块 / 失败原因） */
    fun open(uri: Uri, fileSize: Long) {
        val cr = context.contentResolver
        worker.execute {
            try {
                val bo = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bo) }
                var w = bo.outWidth
                var h = bo.outHeight
                var orient = ExifInterface.ORIENTATION_NORMAL
                try { cr.openInputStream(uri)?.use { orient = ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL) } } catch (ignored: Throwable) { }
                val rotated = orient != ExifInterface.ORIENTATION_NORMAL && orient != ExifInterface.ORIENTATION_UNDEFINED
                val big = w > 4096 || h > 4096 || w.toLong() * h > 16_000_000L
                if (w > 0 && h > 0 && big && !rotated) {
                    // 分块模式：总览 + 按需高清块
                    val p = cr.openFileDescriptor(uri, "r") ?: throw java.io.IOException("无法读取")
                    val st = ParcelFileDescriptor.AutoCloseInputStream(p)
                    @Suppress("DEPRECATION")
                    val dec = BitmapRegionDecoder.newInstance(st, false) ?: throw java.io.IOException("无法解码")
                    var s = 1
                    while (maxOf(w, h) / s > 2048) s *= 2
                    val o = BitmapFactory.Options().apply { inSampleSize = s; inPreferredConfig = Bitmap.Config.ARGB_8888 }
                    val ov = dec.decodeRegion(Rect(0, 0, w, h), o) ?: throw java.io.IOException("无法解码")
                    ui.post {
                        if (closed) { try { dec.recycle(); st.close() } catch (ignored: Throwable) { }; return@post }
                        pfd = p; stream = st; decoder = dec
                        setSource(ov, s, w, h)
                        onInfo?.invoke("原始图片 · $w×$h 像素 · ${fmtSize(fileSize)} · 超大图分块无损查看：放大到哪，哪里就是 1:1 原始像素")
                    }
                } else {
                    // 整图模式：ImageDecoder 会按 EXIF 方向转正；超过 GPU 贴图上限的旋转超大图才不得不缩小
                    var lossy = false
                    val bmp = ImageDecoder.decodeBitmap(ImageDecoder.createSource(cr, uri)) { dec, info, _ ->
                        val iw = info.size.width
                        val ih = info.size.height
                        var s = 1
                        while (maxOf(iw, ih) / s > 4096 || iw.toLong() * ih / (s.toLong() * s) > 16_000_000L) s += 1
                        if (s > 1) { dec.setTargetSampleSize(s); lossy = true }
                        dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                    }
                    ui.post {
                        if (closed) return@post
                        val note = if (lossy) " · 带旋转信息的超大图，因设备显示上限已缩小显示（文件本身未改动，用其他应用打开可看全分辨率）" else " · 全分辨率 1:1 解码，未经压缩 / 重新编码"
                        setSource(bmp, 1, bmp.width, bmp.height)
                        onInfo?.invoke("原始图片 · ${bmp.width}×${bmp.height} 像素 · ${fmtSize(fileSize)}$note")
                    }
                }
            } catch (e: Throwable) {
                ui.post { if (!closed) onInfo?.invoke("无法解码这张图片（格式不支持或文件损坏）：" + (e.message ?: e.javaClass.simpleName) + " · 可点「其他应用打开」") }
            }
        }
    }

    private fun setSource(ov: Bitmap, sample: Int, w: Int, h: Int) {
        overview = ov; ovSample = sample; imgW = w; imgH = h
        tile = null
        computeFit(); scale = fit; clamp(); invalidate()
    }

    /** 视图停下来 120ms 后，按当前放大倍数把可见区域解成 1:1（或所需倍率）的高清块 */
    private fun scheduleTile() {
        if (decoder == null) return
        gen++
        removeCallbacks(tileJob)
        postDelayed(tileJob, 120)
    }

    private val tileJob = Runnable {
        val dec = decoder ?: return@Runnable
        if (closed || width <= 0) return@Runnable
        val g = gen
        // 当前画面对应的原图矩形（四周多留 25%，小幅拖动不用重新解）
        val l0 = (-tx / scale).toInt()
        val t0 = (-ty / scale).toInt()
        val r0 = ((width - tx) / scale).toInt()
        val b0 = ((height - ty) / scale).toInt()
        val mw = (r0 - l0) / 4
        val mh = (b0 - t0) / 4
        val rect = Rect(maxOf(0, l0 - mw), maxOf(0, t0 - mh), minOf(imgW, r0 + mw), minOf(imgH, b0 + mh))
        var sample = 1
        while (sample * 2 <= (1f / scale).toInt()) sample *= 2
        if (rect.isEmpty) return@Runnable
        if (sample >= ovSample) { tile = null; invalidate(); return@Runnable }     // 总览的清晰度已经够了
        worker.execute {
            try {
                val o = BitmapFactory.Options().apply { inSampleSize = sample; inPreferredConfig = Bitmap.Config.ARGB_8888 }
                val b = synchronized(dec) { if (closed) null else dec.decodeRegion(rect, o) }
                ui.post { if (!closed && g == gen && b != null) { tile = b; tileRect.set(rect); tileSample = sample; invalidate() } }
            } catch (ignored: Throwable) { }
        }
    }

    override fun onDraw(c: Canvas) {
        val ov = overview ?: return
        paint.isFilterBitmap = scale < 1f          // 放大超过 100% 用最近邻：看到的就是文件里真实的像素，不做插值美化
        m.reset(); m.postScale(scale * ovSample, scale * ovSample); m.postTranslate(tx, ty)
        c.drawBitmap(ov, m, paint)
        val t = tile
        if (t != null) {
            m.reset(); m.postScale(scale * tileSample, scale * tileSample)
            m.postTranslate(tx + tileRect.left * scale, ty + tileRect.top * scale)
            c.drawBitmap(t, m, paint)
        }
    }

    fun dispose() {
        closed = true
        removeCallbacks(tileJob)
        worker.execute {
            try { decoder?.let { synchronized(it) { it.recycle() } } } catch (ignored: Throwable) { }
            try { stream?.close() } catch (ignored: Throwable) { }
            try { pfd?.close() } catch (ignored: Throwable) { }
        }
        worker.shutdown()
    }
}

/** 全屏查看器（图片 / 视频）。onRecall 不为空时右上角有「撤回」（只有我发出的、已送达的文件有）。 */
internal object MediaViewer {
    fun show(ctx: Context, uri: Uri, name: String, size: Long, kind: Int, onRecall: (() -> Unit)?) {
        val dlg = Dialog(ctx, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        dlg.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val dp = ctx.resources.displayMetrics.density
        fun px(v: Int) = (v * dp).toInt()
        val root = FrameLayout(ctx).apply { setBackgroundColor(Color.BLACK) }
        val info = TextView(ctx).apply { setTextColor(Color.parseColor("#C9D3DC")); textSize = 11.5f; setLineSpacing(0f, 1.1f) }
        var zoom: ZoomImageView? = null
        var video: VideoView? = null
        val bar = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#99000000"))
            setPadding(px(12), px(10), px(12), px(10))
        }
        if (kind == MediaKind.IMAGE) {
            val z = ZoomImageView(ctx)
            zoom = z
            z.onInfo = { info.text = it }
            root.addView(z, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            info.text = "正在解码原图…"
            z.open(uri, size)
            z.onTap = { bar.visibility = if (bar.visibility == View.VISIBLE) View.GONE else View.VISIBLE }
        } else {
            val v = VideoView(ctx)
            video = v
            root.addView(v, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER))
            val mc = MediaController(ctx)
            mc.setAnchorView(v); v.setMediaController(mc)
            v.setOnPreparedListener { it.isLooping = false; v.start() }
            v.setOnErrorListener { _, _, _ ->
                Toast.makeText(ctx, "系统播放器无法播放这个视频（编码不支持），可点「其他应用打开」", Toast.LENGTH_LONG).show(); true
            }
            v.setVideoURI(uri)
            info.text = "原始视频 · ${FileXfer.human(size)} · 原文件直接播放，未经转码"
            Thread {
                val (res, dur) = Thumbs.videoInfo(ctx.applicationContext, uri)
                root.post {
                    info.text = "原始视频 · " + (if (res.isNotEmpty()) "$res · " else "") + (if (dur > 0) Thumbs.clock(dur) + " · " else "") +
                        FileXfer.human(size) + " · 原文件直接播放，未经转码"
                }
            }.also { it.isDaemon = true }.start()
        }
        // 顶部信息条：文件名 + 说明 + 按钮
        val top = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        fun pill(t: String, bg: Int, f: () -> Unit) = TextView(ctx).apply {
            text = t; textSize = 13f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            setPadding(px(12), px(6), px(12), px(6))
            background = android.graphics.drawable.GradientDrawable().apply { setColor(bg); cornerRadius = px(14).toFloat() }
            setOnClickListener { f() }
        }
        top.addView(pill("✕ 关闭", Color.parseColor("#55FFFFFF")) { dlg.dismiss() })
        top.addView(TextView(ctx).apply {
            text = name; textSize = 14f; setTextColor(Color.WHITE); maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
            setPadding(px(10), 0, px(10), 0)
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        top.addView(pill("其他应用打开", Color.parseColor("#55FFFFFF")) {
            try {
                ctx.startActivity(Intent.createChooser(Intent(Intent.ACTION_VIEW).setDataAndType(uri, MediaKind.mime(name)).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "打开方式"))
            } catch (e: Exception) { Toast.makeText(ctx, "没有可以打开它的应用", Toast.LENGTH_SHORT).show() }
        }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { marginEnd = px(6) })
        if (onRecall != null) top.addView(pill("撤回", Color.parseColor("#D9381E")) { dlg.dismiss(); onRecall() })
        bar.addView(top)
        bar.addView(info, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = px(6) })
        root.addView(bar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP))
        dlg.setContentView(root)
        dlg.window?.apply {
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        dlg.setOnDismissListener {
            zoom?.dispose()
            try { video?.stopPlayback() } catch (ignored: Exception) { }
        }
        dlg.show()
    }
}
