package com.lancast.app

import android.app.AlertDialog
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat

/** 磁力下载任务列表：进度 / 暂停继续 / 选择要下的文件 / 播放 / 删除 */
class DownloadsActivity : ComponentActivity() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var listBox: LinearLayout
    private lateinit var emptyTv: TextView
    private val cards = LinkedHashMap<String, Card>()
    private var running = false

    private inner class Card(val hash: String) {
        val root = LinearLayout(this@DownloadsActivity).apply {
            orientation = LinearLayout.VERTICAL
            background = shape(C.CARD, 16f, C.CARD_LINE, 1f)
            setPadding(px(14), px(12), px(14), px(12))
        }
        val nameTv = tv("", 15f, C.INK, true)
        val bar = ProgressBar(this@DownloadsActivity, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000
            progressTintList = ColorStateList.valueOf(C.PRIMARY)
        }
        val infoTv = tv("", 12f, C.SUB).apply { setLineSpacing(0f, 1.2f) }
        val pathTv = tv("", 11f, C.SUB)
        val pauseBtn = chip("暂停", false) { toggle() }
        val playBtn = chip("▶ 播放", true) { play() }

        init {
            root.addView(nameTv)
            root.addView(bar, lp(MATCH_PARENT, px(10), 0f, 8))
            root.addView(infoTv, lp(MATCH_PARENT, WRAP_CONTENT, 0f, 4))
            val row = LinearLayout(this@DownloadsActivity).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            row.addView(pauseBtn)
            row.addView(playBtn, lp(WRAP_CONTENT, WRAP_CONTENT, 0f, 0, 8))
            row.addView(chip("文件", false) { pickFiles() }, lp(WRAP_CONTENT, WRAP_CONTENT, 0f, 0, 8))
            row.addView(chip("删除", false) { confirmDelete() }, lp(WRAP_CONTENT, WRAP_CONTENT, 0f, 0, 8))
            root.addView(row, lp(MATCH_PARENT, WRAP_CONTENT, 0f, 10))
            root.addView(pathTv, lp(MATCH_PARENT, WRAP_CONTENT, 0f, 8))
        }

        private fun task() = BtEngine.get(hash)

        fun update(t: BtTask) {
            nameTv.text = t.name
            bar.progress = (t.progress * 1000).toInt()
            infoTv.text = describe(t)
            pauseBtn.text = if (t.done) "已完成" else if (t.paused || t.state == "error") "继续" else "暂停"
            pauseBtn.alpha = if (t.done) 0.45f else 1f
            playBtn.visibility = if (t.files.any { Http.isPlayable(it.name) }) View.VISIBLE else View.GONE
            pathTv.text = "保存位置：" + t.dir.absolutePath
        }

        private fun toggle() {
            val t = task() ?: return
            if (t.done) return
            BtEngine.post { if (t.paused || t.state == "error") BtEngine.resume(t) else BtEngine.pause(t); ui.post { refresh() } }
        }

        private fun play() {
            val t = task() ?: return
            val media = t.files.filter { Http.isPlayable(it.name) }.sortedBy { it.path }
            if (media.isEmpty()) return
            if (media.size == 1) { PlayerActivity.open(this@DownloadsActivity, t.hash, media[0].index); return }
            val big = media.maxByOrNull { it.size }!!
            AlertDialog.Builder(this@DownloadsActivity).setTitle("选择要播放的文件")
                .setItems((listOf("★ " + big.path) + media.map { it.path }).toTypedArray()) { _, i ->
                    PlayerActivity.open(this@DownloadsActivity, t.hash, if (i == 0) big.index else media[i - 1].index)
                }.show()
        }

        private fun pickFiles() {
            val t = task() ?: return
            val files = t.files
            val checked = BooleanArray(files.size) { files[it].index in t.selected }
            AlertDialog.Builder(this@DownloadsActivity).setTitle("选择要下载的文件")
                .setMultiChoiceItems(files.map { it.path + "  (" + MagnetCore.formatSize(it.size) + ")" }.toTypedArray(), checked) { _, i, on -> checked[i] = on }
                .setPositiveButton("确定") { _, _ ->
                    val sel = files.filterIndexed { i, _ -> checked[i] }.map { it.index }.toSet()
                    if (sel.isEmpty()) Toast.makeText(this@DownloadsActivity, "至少要选一个文件", Toast.LENGTH_SHORT).show()
                    else BtEngine.post { BtEngine.setSelected(t, sel); ui.post { refresh() } }
                }
                .setNegativeButton("取消", null).show()
        }

        private fun confirmDelete() {
            val t = task() ?: return
            AlertDialog.Builder(this@DownloadsActivity).setTitle("删除「${t.name}」")
                .setItems(arrayOf("仅移除任务（保留已下载的文件）", "移除任务并删除已下载的文件", "取消")) { _, i ->
                    if (i < 2) BtEngine.post { BtEngine.remove(t, i == 1); ui.post { refresh() } }
                }.show()
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = C.BG
        window.navigationBarColor = C.BG
        WindowCompat.getInsetsController(window, window.decorView).apply { isAppearanceLightStatusBars = true; isAppearanceLightNavigationBars = true }
        BtEngine.init(applicationContext)
        setContentView(buildUi())
    }

    override fun onResume() {
        super.onResume()
        running = true
        tickLoop()
    }

    override fun onPause() {
        running = false
        super.onPause()
    }

    private fun tickLoop() {
        if (!running) return
        refresh()
        ui.postDelayed({ tickLoop() }, 1000)
    }

    private fun refresh() {
        val list = BtEngine.list()
        val hashes = list.map { it.hash }.toSet()
        for (h in cards.keys.toList()) if (h !in hashes) { listBox.removeView(cards.remove(h)!!.root) }
        for (t in list.asReversed()) {
            val c = cards.getOrPut(t.hash) { Card(t.hash).also { listBox.addView(it.root, 0, lp(MATCH_PARENT, WRAP_CONTENT, 0f, 10)) } }
            c.update(t)
        }
        emptyTv.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun describe(t: BtTask): String {
        val pct = (t.progress * 100).toInt()
        val size = MagnetCore.formatSize(t.doneBytes) + " / " + MagnetCore.formatSize(if (t.wantedBytes > 0) t.wantedBytes else t.selectedBytes)
        return when {
            t.done -> "已完成 · " + MagnetCore.formatSize(t.selectedBytes)
            t.state == "error" -> "出错：" + t.error
            t.paused -> "已暂停 · $pct% · $size"
            t.state == "checking" -> "正在校验 / 启动…"
            else -> {
                val eta = if (t.down > 1024 && t.wantedBytes > t.doneBytes) {
                    val s = (t.wantedBytes - t.doneBytes) / t.down
                    " · 剩余 " + (if (s >= 3600) "${s / 3600} 小时 ${s % 3600 / 60} 分" else if (s >= 60) "${s / 60} 分 ${s % 60} 秒" else "$s 秒")
                } else ""
                "$pct% · $size · ↓ ${MagnetCore.formatSize(t.down.toLong())}/s ↑ ${MagnetCore.formatSize(t.up.toLong())}/s · ${t.peers} 个节点" +
                    (if (t.peers == 0) "（正在寻找…）" else "") + eta + (if (t.streams.get() > 0) " · 播放中" else "")
            }
        }
    }

    /* ───────────── 界面小工具 ───────────── */
    private fun tv(text: String, sp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun chip(text: String, primary: Boolean, onClick: () -> Unit) = TextView(this).apply {
        this.text = text
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setTextColor(if (primary) Color.WHITE else C.PRIMARY)
        background = shape(if (primary) C.PRIMARY else C.SOFT, 22f)
        setPadding(px(14), px(8), px(14), px(8))
        setOnClickListener { onClick() }
    }

    private fun lp(w: Int, h: Int, weight: Float = 0f, top: Int = 0, left: Int = 0) =
        LinearLayout.LayoutParams(w, h, weight).apply { topMargin = px(top); leftMargin = px(left) }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(C.BG)
            setPadding(px(16), px(12), px(16), px(8))
        }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        bar.addView(tv("‹ 返回", 15f, C.PRIMARY, true).apply { setPadding(0, px(6), px(14), px(6)); setOnClickListener { finish() } })
        bar.addView(tv("下载任务", 20f, C.INK, true))
        root.addView(bar, lp(MATCH_PARENT, WRAP_CONTENT))
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        emptyTv = tv("还没有下载任务。\n到「磁力解析」里解析链接，然后点「▶ 边下边播」或「下载全部」。", 14f, C.SUB).apply { setLineSpacing(0f, 1.3f); setPadding(px(4), px(24), px(4), 0) }
        listBox.addView(emptyTv)
        root.addView(ScrollView(this).apply { addView(listBox, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT)) }, lp(MATCH_PARENT, 0, 1f, 6))
        return root
    }
}
