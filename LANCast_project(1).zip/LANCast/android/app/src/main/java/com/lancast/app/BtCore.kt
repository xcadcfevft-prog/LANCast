package com.lancast.app

import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.SocketTimeoutException
import java.net.URLDecoder
import java.net.URLEncoder
import java.util.concurrent.Executors

/*
 * 边下边播的纯逻辑部分（不依赖 Android / jlibtorrent，能在 JVM 上直接测试）：
 *  - PieceSource：对 libtorrent 的最小抽象（有没有某个分片 / 给分片设“截止时间”让它优先下载）
 *  - StreamServer：本地 127.0.0.1 HTTP 服务，支持 Range（播放器拖进度条就是靠它），
 *    读取时如果分片还没下到就等，并且把当前播放位置之后的分片提到最高优先级
 *  - BtState：任务列表的持久化格式
 */

interface PieceSource {
    val pieceLength: Int
    val numPieces: Int
    fun have(piece: Int): Boolean
    /** 让该分片在 ms 毫秒内尽量下完（越小越优先）；分片下完后系统会自动清除 */
    fun setDeadline(piece: Int, ms: Int)
    fun resetDeadline(piece: Int)
}

class StreamTarget(
    val name: String,
    val size: Long,
    /** 文件起点在整个种子里的绝对偏移（含 padding 文件） */
    val absOffset: Long,
    val file: File,
    val src: PieceSource,
    /** 分片刚通过校验时，等这么久再读，避免底层缓存还没落盘（文件已完整时传 0） */
    val settleMs: Long = 200,
    val onOpen: () -> Unit = {},
    val onClose: () -> Unit = {}
)

object Http {
    val MIME = mapOf(
        "mp4" to "video/mp4", "m4v" to "video/mp4", "mkv" to "video/x-matroska", "webm" to "video/webm", "mov" to "video/quicktime",
        "avi" to "video/x-msvideo", "ts" to "video/mp2t", "m2ts" to "video/mp2t", "flv" to "video/x-flv", "wmv" to "video/x-ms-wmv",
        "rmvb" to "application/vnd.rn-realmedia-vbr", "mpg" to "video/mpeg", "mpeg" to "video/mpeg", "3gp" to "video/3gpp",
        "mp3" to "audio/mpeg", "flac" to "audio/flac", "m4a" to "audio/mp4", "aac" to "audio/aac", "ogg" to "audio/ogg",
        "opus" to "audio/ogg", "wav" to "audio/wav", "wma" to "audio/x-ms-wma", "ape" to "audio/x-ape",
        "jpg" to "image/jpeg", "jpeg" to "image/jpeg", "png" to "image/png", "gif" to "image/gif", "webp" to "image/webp",
        "srt" to "text/plain; charset=utf-8", "ass" to "text/plain; charset=utf-8", "txt" to "text/plain; charset=utf-8"
    )
    val VIDEO = setOf("mp4", "m4v", "mkv", "webm", "mov", "avi", "ts", "m2ts", "flv", "wmv", "rmvb", "mpg", "mpeg", "3gp")
    val AUDIO = setOf("mp3", "flac", "m4a", "aac", "ogg", "opus", "wav", "wma", "ape")

    fun ext(name: String): String = name.substringAfterLast('.', "").lowercase()
    fun mime(name: String): String = MIME[ext(name)] ?: "application/octet-stream"
    fun isPlayable(name: String): Boolean = ext(name).let { it in VIDEO || it in AUDIO }

    /** 解析 Range 头。返回 null = 没带 Range；LongRange.EMPTY 风格的 (-1,-1) = 无法满足(416) */
    fun parseRange(h: String?, size: Long): LongArray? {
        if (h == null) return null
        val m = Regex("^\\s*bytes\\s*=\\s*(\\d*)\\s*-\\s*(\\d*)").find(h) ?: return null      // 多段 Range 只取第一段
        val a = m.groupValues[1]; val b = m.groupValues[2]
        if (a.isEmpty() && b.isEmpty()) return null
        var s: Long; var e: Long
        if (a.isEmpty()) { val n = b.toLongOrNull() ?: return longArrayOf(-1, -1); if (n <= 0) return longArrayOf(-1, -1); s = maxOf(0L, size - n); e = size - 1 }
        else { s = a.toLongOrNull() ?: return longArrayOf(-1, -1); e = if (b.isEmpty()) size - 1 else (b.toLongOrNull() ?: return longArrayOf(-1, -1)) }
        if (e >= size) e = size - 1
        if (size <= 0 || s >= size || s > e) return longArrayOf(-1, -1)
        return longArrayOf(s, e)
    }
}

class StreamServer(
    private val find: (hash: String, index: Int) -> StreamTarget?,
    /** 预读窗口（字节），窗口内的分片都会被设为“马上要用” */
    private val readahead: Long = 24L shl 20
) {
    @Volatile var port = 0; private set
    @Volatile private var server: ServerSocket? = null
    @Volatile private var stopped = false
    private val pool = Executors.newCachedThreadPool { r -> Thread(r, "bt-stream").apply { isDaemon = true } }

    @Synchronized fun start(): Int {
        server?.let { return port }
        val ss = ServerSocket(0, 32, InetAddress.getByName("127.0.0.1"))
        server = ss; port = ss.localPort; stopped = false
        Thread({
            while (!stopped) {
                val c = try { ss.accept() } catch (e: IOException) { break }
                pool.execute { try { handle(c) } catch (_: Throwable) {} finally { try { c.close() } catch (_: Throwable) {} } }
            }
        }, "bt-accept").apply { isDaemon = true; start() }
        return port
    }

    @Synchronized fun stop() {
        stopped = true
        try { server?.close() } catch (_: Throwable) {}
        server = null
    }

    fun url(hash: String, index: Int, name: String): String =
        "http://127.0.0.1:${start()}/$hash/$index/" + URLEncoder.encode(name, "UTF-8").replace("+", "%20")

    private fun readHead(sock: Socket): List<String>? {
        val inp = sock.getInputStream()
        val sb = StringBuilder()
        var prev = 0
        while (sb.length < 16384) {
            val c = inp.read(); if (c < 0) return null
            sb.append(c.toChar())
            if (c == '\n'.code && prev == '\n'.code) break
            if (sb.endsWith("\r\n\r\n")) break
            prev = if (c == '\r'.code) prev else c
        }
        return sb.toString().split("\r\n", "\n").filter { it.isNotEmpty() }
    }

    private fun reply(out: java.io.OutputStream, code: Int, text: String, vararg headers: String) {
        val b = StringBuilder("HTTP/1.1 $code $text\r\n")
        for (h in headers) b.append(h).append("\r\n")
        b.append("Connection: close\r\nAccess-Control-Allow-Origin: *\r\n\r\n")
        out.write(b.toString().toByteArray(Charsets.ISO_8859_1)); out.flush()
    }

    private fun handle(sock: Socket) {
        sock.soTimeout = 15000
        sock.tcpNoDelay = true
        val lines = readHead(sock) ?: return
        val out = sock.getOutputStream()
        val parts = lines[0].split(' ')
        if (parts.size < 2) return
        val method = parts[0].uppercase()
        if (method != "GET" && method != "HEAD") { reply(out, 405, "Method Not Allowed", "Content-Length: 0"); return }
        val hdr = HashMap<String, String>()
        for (l in lines.drop(1)) { val i = l.indexOf(':'); if (i > 0) hdr[l.substring(0, i).trim().lowercase()] = l.substring(i + 1).trim() }
        val seg = parts[1].substringBefore('?').split('/').filter { it.isNotEmpty() }
        val idx = seg.getOrNull(1)?.toIntOrNull()
        val t = if (seg.size >= 2 && idx != null) find(seg[0], idx) else null
        if (t == null) { reply(out, 404, "Not Found", "Content-Length: 0"); return }
        val range = Http.parseRange(hdr["range"], t.size)
        val ctype = "Content-Type: " + Http.mime(t.name)
        if (range != null && range[0] < 0) { reply(out, 416, "Range Not Satisfiable", "Content-Range: bytes */${t.size}", "Content-Length: 0"); return }
        val s = range?.get(0) ?: 0L
        val e = range?.get(1) ?: (t.size - 1)
        val len = if (t.size == 0L) 0L else e - s + 1
        val common = arrayOf(ctype, "Accept-Ranges: bytes", "Cache-Control: no-store", "Content-Length: $len")
        if (range != null) reply(out, 206, "Partial Content", *common, "Content-Range: bytes $s-$e/${t.size}") else reply(out, 200, "OK", *common)
        if (method == "HEAD" || len == 0L) return
        t.onOpen()
        try { body(sock, out, t, s, e) } finally { t.onClose() }
    }

    /** 本连接正在“盯着”的分片：离开窗口就撤销它们的截止时间，别的连接 / 默认策略接管 */
    private class Prime { val set = HashSet<Int>(); var head = -1; var at = 0L }

    private fun prime(t: StreamTarget, pr: Prime, p: Int, lastPiece: Int) {
        val now = System.currentTimeMillis()
        if (p == pr.head && now - pr.at < 1500) return
        pr.head = p; pr.at = now
        val pl = t.src.pieceLength
        val w = (readahead / pl).toInt().coerceIn(3, 48)
        val want = HashSet<Int>()
        var k = 0
        for (q in p..minOf(p + w - 1, lastPiece)) {
            if (t.src.have(q)) continue
            want.add(q); t.src.setDeadline(q, 200 + k * 350); k++
        }
        for (old in pr.set) if (old !in want) t.src.resetDeadline(old)
        pr.set.clear(); pr.set.addAll(want)
    }

    private fun clientGone(sock: Socket): Boolean = try {
        sock.soTimeout = 1
        sock.getInputStream().read() == -1
    } catch (_: SocketTimeoutException) { false } catch (_: IOException) { true }

    private fun body(sock: Socket, out: java.io.OutputStream, t: StreamTarget, start: Long, end: Long) {
        val pl = t.src.pieceLength.toLong()
        val lastPiece = ((t.absOffset + t.size - 1) / pl).toInt().coerceAtMost(t.src.numPieces - 1)
        val pr = Prime()
        var raf: RandomAccessFile? = null
        val buf = ByteArray(256 * 1024)
        try {
            // 容器的“索引”常在文件尾（mp4 的 moov、mkv 的 Cues），顺手让最后两个分片也尽快下
            val endP = lastPiece
            for (q in maxOf(0, endP - 1)..endP) if (!t.src.have(q)) t.src.setDeadline(q, 6000)
            var pos = start
            var lastCheck = 0L
            while (pos <= end) {
                val abs = t.absOffset + pos
                val p = (abs / pl).toInt()
                prime(t, pr, p, lastPiece)
                // 等分片：如果是“眼看着刚下完”的，再等一小会儿让底层把数据落盘；早就下完的直接读
                var waited = false
                while (!t.src.have(p)) {
                    if (stopped) return
                    waited = true
                    val now = System.currentTimeMillis()
                    if (now - lastCheck > 400) { lastCheck = now; if (clientGone(sock)) return; prime(t, pr, p, lastPiece) }
                    Thread.sleep(40)
                }
                if (waited && t.settleMs > 0) Thread.sleep(t.settleMs)
                val n = minOf(end - pos + 1, (p + 1L) * pl - abs, buf.size.toLong()).toInt()
                if (raf == null) {
                    var tries = 0
                    while (raf == null) {
                        try { raf = RandomAccessFile(t.file, "r") } catch (e: IOException) { if (++tries > 100 || stopped) throw e; Thread.sleep(50) }
                    }
                }
                raf!!.seek(pos)
                var got = 0
                while (got < n) { val r = raf!!.read(buf, got, n - got); if (r < 0) break; got += r }
                if (got < n) { // 文件比预期短（底层还没把数据写出来）：等一下重试这一块
                    Thread.sleep(100); continue
                }
                out.write(buf, 0, n)
                pos += n
            }
            out.flush()
        } finally {
            for (q in pr.set) try { t.src.resetDeadline(q) } catch (_: Throwable) {}
            try { raf?.close() } catch (_: Throwable) {}
        }
    }
}

/** 任务列表的持久化：每行 hash \t 保存目录(URL编码) \t 暂停(0/1) \t 选中的文件下标（逗号分隔，* 表示全部） \t 已完成(0/1) */
class SavedTask(val hash: String, val dir: String, val paused: Boolean, val selected: List<Int>?, val done: Boolean = false)

object BtState {
    fun encode(list: List<SavedTask>): String = list.joinToString("\n") {
        listOf(it.hash, URLEncoder.encode(it.dir, "UTF-8"), if (it.paused) "1" else "0", it.selected?.joinToString(",") ?: "*", if (it.done) "1" else "0").joinToString("\t")
    }

    fun decode(text: String): List<SavedTask> = text.lineSequence().mapNotNull { l ->
        val p = l.split('\t')
        if (p.size < 4 || !Regex("[0-9a-f]{40}").matches(p[0])) return@mapNotNull null
        val sel = if (p[3] == "*") null else p[3].split(',').mapNotNull { it.toIntOrNull() }
        SavedTask(p[0], URLDecoder.decode(p[1], "UTF-8"), p[2] == "1", sel, p.getOrNull(4) == "1")
    }.toList()
}
