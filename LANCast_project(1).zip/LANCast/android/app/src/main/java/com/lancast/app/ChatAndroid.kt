package com.lancast.app

import android.os.Handler
import android.os.Looper
import kotlin.concurrent.thread

/**
 * 安全聊天的 Android 平台胶水：把 ChatHub（纯逻辑）接到真实的 Session / SharedPreferences / 通知上。
 * 聊天走独立的 TCP 连接（mode = "chat"），不占用投屏会话，也不影响文件互传。
 */
object ChatNet {
    private val ui = Handler(Looper.getMainLooper())
    @Volatile var onChange: ((String) -> Unit)? = null      // 界面刷新回调（主线程），参数 = 对方设备 ID
    private var started = false
    lateinit var hub: ChatHub
        private set

    private class SessLink(val se: Session) : ChatLink {
        override fun send(type: Int, payload: ByteArray) {
            val b = P.newPkt(type, 0, 0L, payload.size)
            System.arraycopy(payload, 0, b, P.HDR, payload.size)
            se.sendHi(b)
        }
        override fun close(reason: String) { se.close(reason) }
    }

    private class Handler2(val hubRef: () -> ChatHub) : SessionHandler {
        @Volatile var conn: ChatHub.Conn? = null
        override fun onPacket(s: Session, p: Pkt) { conn?.let { hubRef().onFrame(it, p.type, p.payload) } }
        override fun onClosed(s: Session, reason: String) { conn?.let { hubRef().onClosed(it) } }
    }

    private val handlers = java.util.concurrent.ConcurrentHashMap<ChatHub.Conn, Handler2>()

    private val env = object : ChatEnv {
        override val myId: String get() = Link.id
        override val myName: String get() = Link.name
        override fun myPin() = Link.pin
        override fun peers(): List<ChatPeer> = Link.pairs().map { pr ->
            val live = Link.peers[pr.id]
            ChatPeer(pr.id, pr.name, pr.pin, live?.ip ?: pr.ip, live?.port ?: pr.port, live != null)
        }
        override fun load(peerId: String): String? = Link.prefs.getString("chat_$peerId", null)
        override fun save(peerId: String, json: String) { Link.prefs.edit().putString("chat_$peerId", json).apply() }
        override fun loadUnread(): String? = Link.prefs.getString("chat_unread", null)
        override fun saveUnread(json: String) { Link.prefs.edit().putString("chat_unread", json).apply() }
        override fun dial(p: ChatPeer): ChatDial {
            val se = Session.connect(p.ip, p.port, p.pin, "chat", Link.name)
            if (se.peerVer < 2 || !se.peerCaps.contains("chat")) { se.close("对方版本不支持聊天"); throw java.io.IOException("对方版本不支持聊天") }
            if (se.peerId.isNotEmpty() && se.peerId != p.id) { se.close("设备不符"); throw java.io.IOException("设备不符") }
            return ChatDial(SessLink(se), se.hsNonce, se.hsCn).also { pendingDial[it.link] = se }
        }
        override fun changed(peerId: String) { ui.post { onChange?.invoke(peerId) } }
        override fun notify(peerId: String, name: String, msg: ChatMsg) {
            if (hub.viewing == peerId && Link.listener != null) return
            Notice.chat(peerId, name, if (msg.k == "s") "[表情包] " + msg.e + " " + msg.c else msg.x)
        }
    }

    private val pendingDial = java.util.concurrent.ConcurrentHashMap<ChatLink, Session>()

    @Synchronized fun start() {
        if (started) return
        started = true
        hub = ChatHub(env)
        // dial 成功、hub.attach 之后：启动读写线程（顺序不能反，否则对方的密钥帧会在我们的密钥发出前被处理）
        hub.onAttached = { c ->
            val se = pendingDial.remove(c.link)
            if (se != null) {
                val h = Handler2 { hub }
                h.conn = c
                handlers[c] = h
                se.start(h)
            }
        }
        thread(name = "chat-tick", isDaemon = true) {
            while (true) {
                try { Thread.sleep(1000) } catch (ignored: InterruptedException) { }
                try { hub.tick() } catch (ignored: Exception) { }
            }
        }
    }

    /** 服务端：对方连进来（mode = "chat"）。已通过 PIN 校验；这里再核对它是我配过对的设备 */
    fun onIncoming(se: Session) {
        try {
            start()
            val paired = Link.pairs().firstOrNull { it.id == se.peerId }
            if (se.peerVer < 2 || !se.peerCaps.contains("chat") || se.hsCn.isEmpty() || se.clientNonce.isEmpty() || paired == null) {
                se.reject("聊天需要双方已互相配对且使用新版"); return
            }
            se.accept()
            val link = SessLink(se)
            val h = Handler2 { hub }
            // 服务端：派生用「我的密钥:对方记录里的密钥」；attach 必须先于 start
            val c = hub.attach(link, ChatHub.Meta(paired.id, false, se.hsNonce, se.hsCn, Link.pin + ":" + paired.pin, paired.name))
            h.conn = c
            handlers[c] = h
            se.start(h)
        } catch (e: Exception) {
            try { se.close("聊天握手失败") } catch (ignored: Exception) { }
        }
    }
}
