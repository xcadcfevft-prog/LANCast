package com.lancast.app

import android.content.Context
import android.content.SharedPreferences
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.DataInputStream
import java.io.IOException
import java.io.OutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.nio.ByteBuffer
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Collections
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.locks.ReentrantLock
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import kotlin.concurrent.thread
import kotlin.concurrent.withLock

/** 协议常量。包头 16 字节(大端)：type u8 | flags u8 | reserved u16 | len u32 | pts u64(微秒) */
object P {
    const val PORT = 47800
    const val DISC_PORT = 47801
    const val T_HELLO = 1
    const val T_CHALLENGE = 2
    const val T_ACCEPT = 3
    const val T_REJECT = 4
    const val T_CTRL = 5
    const val T_VCONFIG = 16
    const val T_VFRAME = 17
    const val T_ACONFIG = 18
    const val T_ADATA = 19
    const val T_PING = 20
    const val T_PONG = 21
    /** 屏幕控制指令（观看方 → 被控方），JSON，见 InputService / docs/PROTOCOL.md 第 11 节 */
    const val T_INPUT = 22
    /** 安全聊天：密钥交换 / 加密消息，见 ChatCrypto / docs/PROTOCOL.md 第 14 节 */
    const val T_CHAT_KEY = 48
    const val T_CHAT_MSG = 49
    const val T_MUSIC_META = 60              // 沉浸音乐（docs/PROTOCOL.md 第 23 节）：歌曲信息 / 进度 / 状态
    const val T_MUSIC_COVER = 61             // 封面：16 字节哈希 + 图片原字节
    const val T_MUSIC_CMD = 62               // 电脑 → 手机：播放 / 暂停 / 上一首 / 下一首 / 拖动进度
    const val HDR = 16

    /** 握手协议版本。1 = 原版（与 Windows 端一致）；2 = 增加设备 ID、能力协商、服务端身份证明（安卓 ↔ 安卓）。详见 docs/PROTOCOL.md */
    const val VER = 2
    /** 本机能力：file 文件互传 | resume 断点续传 | push/pull 屏幕互投 | proof 服务端身份证明 | park 后台来电挂起 | ctl 屏幕控制 | lossless 看得懂「极致无损」视频 */
    val CAPS = listOf("file", "resume", "push", "pull", "proof", "park", "ctl", "lossless", "chat", "music")

    fun capsJson(): JSONArray = JSONArray().also { a -> for (c in CAPS) a.put(c) }

    fun parseCaps(a: JSONArray?): Set<String> {
        val r = HashSet<String>()
        if (a != null) for (i in 0 until minOf(a.length(), 32)) r.add(a.optString(i))
        return r
    }

    /** 服务端身份证明：只有知道配对密钥的一方才算得出来；绑定双方各自的随机数，不能被重放。 */
    fun proofHex(key: String, serverNonce: String, clientNonce: String): String =
        hmacHex(key, "srv:$serverNonce:$clientNonce")

    fun constEq(a: String, b: String): Boolean =
        MessageDigest.isEqual(a.toByteArray(Charsets.UTF_8), b.toByteArray(Charsets.UTF_8))

    fun newPkt(type: Int, flags: Int, pts: Long, len: Int): ByteArray {
        val b = ByteArray(HDR + len)
        val bb = ByteBuffer.wrap(b)
        bb.put(0, type.toByte())
        bb.put(1, flags.toByte())
        bb.putInt(4, len)
        bb.putLong(8, pts)
        return b
    }

    fun jsonPkt(type: Int, j: JSONObject): ByteArray {
        val body = j.toString().toByteArray(Charsets.UTF_8)
        val b = newPkt(type, 0, 0, body.size)
        System.arraycopy(body, 0, b, HDR, body.size)
        return b
    }

    fun hmacHex(key: String, msg: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(key.toByteArray(Charsets.UTF_8), "HmacSHA256"))
        return mac.doFinal(msg.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
    }

    /* 扫码配对：手机把「自己的密钥」交给对方时，用「对方密钥 + 一次性随机数」派生的密钥流做异或加密，
     * 这样旁听局域网流量的人拿不到。与电脑端 renderer.js 的 pairKey / handlePair 完全对应。 */
    private fun pairStream(secret: String, nonce: String): ByteArray {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(secret.toByteArray(Charsets.UTF_8), "HmacSHA256"))
        return mac.doFinal((nonce + ":pair").toByteArray(Charsets.UTF_8))
    }

    fun maskPin(secret: String, nonce: String, pin: String): String {
        val ks = pairStream(secret, nonce)
        val raw = pin.toByteArray(Charsets.UTF_8)
        val sb = StringBuilder()
        for (i in raw.indices) sb.append("%02x".format((raw[i].toInt() xor ks[i % ks.size].toInt()) and 0xFF))
        return sb.toString()
    }

    fun unmaskPin(secret: String, nonce: String, hex: String): String {
        if (hex.length % 2 != 0 || hex.length > 64) return ""
        val ks = pairStream(secret, nonce)
        val raw = ByteArray(hex.length / 2)
        for (i in raw.indices) {
            val b = hex.substring(i * 2, i * 2 + 2).toIntOrNull(16) ?: return ""
            raw[i] = (b xor ks[i % ks.size].toInt()).toByte()
        }
        return String(raw, Charsets.UTF_8)
    }

    fun randomHex(n: Int): String {
        val b = ByteArray(n)
        SecureRandom().nextBytes(b)
        return b.joinToString("") { "%02x".format(it) }
    }
}

class Pkt(val type: Int, val flags: Int, val pts: Long, val payload: ByteArray) {
    fun json(): JSONObject = JSONObject(String(payload, Charsets.UTF_8))
}

fun readPkt(din: DataInputStream): Pkt {
    val h = ByteArray(P.HDR)
    din.readFully(h)
    val bb = ByteBuffer.wrap(h)
    val len = bb.getInt(4)
    if (len < 0 || len > 64 * 1024 * 1024) throw IOException("bad length")
    val body = ByteArray(len)
    din.readFully(body)
    return Pkt(bb.get(0).toInt() and 0xFF, bb.get(1).toInt() and 0xFF, bb.getLong(8), body)
}

/** 会话事件回调（在 Session 的读线程上调用 onPacket）。 */
interface SessionHandler {
    fun onPacket(s: Session, p: Pkt)
    fun onClosed(s: Session, reason: String)
}

data class Peer(val id: String, val name: String, val platform: String, val ip: String, val port: Int, val seen: Long)

/** 已配对的设备：pin 是对方的配对密钥（连接对方时用它认证）。ip 是主地址，ips 是备用地址（局域网 / 虚拟局域网各记一个，连接时并行探测哪个通）。 */
data class Paired(val id: String, val name: String, val platform: String, val ip: String, val port: Int, val pin: String, val ver: Int = 1, val ips: List<String> = emptyList())

/**
 * 一条已认证的 TCP 会话。
 * 发送：音频/控制走高优先级队列；视频走单独队列，积压超过 maxBacklog 就清队列并丢弃后续帧直到下一个关键帧（宁可短暂停顿，也不花屏）。
 */
class Session private constructor(
    private val sock: Socket,
    private val din: DataInputStream,
    private val out: OutputStream,
    val isServer: Boolean
) {
    @Volatile var peerName = ""
    @Volatile var peerPlatform = ""
    @Volatile var mode = ""                    // 客户端请求的模式：push(客户端投屏给我) | pull(客户端要看我的屏幕) | file | pair
    @Volatile var hello: JSONObject? = null     // 服务端：对方的 HELLO 内容
    @Volatile var nonce = ""                    // 服务端：本次握手发出的随机数
    @Volatile var peerVer = 1                   // 对方的握手协议版本（Windows 端 = 1）
    @Volatile var peerId = ""                   // 对方的设备 ID（v2 起每次握手都带；v1 只在配对时带）
    @Volatile var peerCaps: Set<String> = emptySet()
    @Volatile var clientNonce = ""              // 服务端：客户端的随机数（v2），用于生成身份证明
    @Volatile var hsNonce = ""                  // 握手里服务端的随机数（两端都记下，聊天密钥派生用）
    @Volatile var hsCn = ""                     // 握手里客户端的随机数
    @Volatile var authPin = ""                  // 服务端：本次握手用的密钥
    @Volatile var ctlReq = false                // 服务端(pull)：对方请求控制本机
    @Volatile var ctlAllowed = false            // 被控方：本机用户同意了本次会话被控制（ScreenSource 据此才执行 T_INPUT）
    @Volatile var canControl = false            // 观看方：对方同意了我控制它（界面据此显示「控制」按钮）
    @Volatile var alive = true
    @Volatile var rttMs = 0L
    @Volatile var maxBacklog = 600_000
    @Volatile var fixedIdleMs = 0L              // >0：不看屏幕亮灭，固定用这个超时判定断线（沉浸音乐用：息屏也要尽快发现死链并重连，不能像投屏那样放宽到 30 秒）
    @Volatile var idleLimitMs = 6000L          // 多久没收到任何数据就判定断线：局域网 6 秒；经虚拟局域网 / 移动网络时放宽到 15 秒（蜂窝切换、中继抖动很常见）
    @Volatile private var lastRx = System.currentTimeMillis()
    var onCongestion: (() -> Unit)? = null

    private var handler: SessionHandler? = null
    private val closed = AtomicBoolean(false)
    private val lock = ReentrantLock()
    private val cond = lock.newCondition()
    private val hi = java.util.ArrayDeque<ByteArray>()
    private val vq = java.util.ArrayDeque<ByteArray>()
    private var vqBytes = 0
    private var needKey = false
    private var lastPing = 0L

    val remoteIp: String
        get() = (sock.remoteSocketAddress as? InetSocketAddress)?.address?.hostAddress ?: ""

    /** 文件互传直接使用底层连接（不调用 start()，因此没有读写线程和心跳）。din 已含握手时多读的缓冲数据。 */
    val rawSocket: Socket
        get() = sock
    val rawIn: DataInputStream
        get() = din
    val rawOut: OutputStream
        get() = out

    fun start(h: SessionHandler) {
        handler = h
        lastRx = System.currentTimeMillis()
        try { idleLimitMs = if (remoteIp.isEmpty() || Link.isLanPeer(remoteIp)) 6000L else 15000L } catch (ignored: Exception) { }
        try {
            sock.soTimeout = 0
            sock.keepAlive = true                    // 系统层的 TCP 保活：应用层心跳之外再加一道，NAT / 路由器不会因为长时间没流量而丢掉这条连接
            sock.sendBufferSize = 256 * 1024        // 内核发送缓冲别太大，否则会把延迟藏在里面
        } catch (ignored: Exception) {
        }
        thread(name = "sess-rd", isDaemon = true) { readLoop() }
        thread(name = "sess-wr", isDaemon = true) { writeLoop() }
        thread(name = "sess-wd", isDaemon = true) {
            while (alive) {
                try { Thread.sleep(1000) } catch (ignored: InterruptedException) { }
                val limit = if (fixedIdleMs > 0) fixedIdleMs else if (Link.screenOn()) idleLimitMs else maxOf(idleLimitMs, 30_000L)   // 息屏后系统会让 Wi-Fi 打盹、延迟收包，放宽超时，避免误判断线
                if (System.currentTimeMillis() - lastRx > limit) close("连接超时")
            }
        }
    }

    fun accept() {
        val j = JSONObject().put("ok", true)
        if (ctlReq) j.put("ctl", ctlAllowed)                // 回复「是否同意被控制」
        if (clientNonce.isNotEmpty()) {                    // v2：向客户端证明「我确实持有这个配对密钥」
            j.put("ver", P.VER).put("proof", P.proofHex(authPin, nonce, clientNonce))
        }
        out.write(P.jsonPkt(P.T_ACCEPT, j))
    }

    fun reject(reason: String) {
        try { out.write(P.jsonPkt(P.T_REJECT, JSONObject().put("reason", reason))) } catch (ignored: Exception) { }
        closed.set(true)
        alive = false
        try { sock.close() } catch (ignored: Exception) { }
    }

    fun sendHi(b: ByteArray) {
        lock.withLock {
            if (!alive) return
            hi.addLast(b)
            cond.signalAll()
        }
    }

    fun sendCtrl(j: JSONObject) = sendHi(P.jsonPkt(P.T_CTRL, j))

    fun resetVideo() {
        lock.withLock {
            vq.clear()
            vqBytes = 0
            needKey = true
        }
    }

    /** 返回 true 表示已入队。拥塞时返回 false，并触发 onCongestion（降码率 + 请求关键帧）。 */
    fun sendVideo(pkt: ByteArray, key: Boolean): Boolean {
        var congested = false
        var queued = false
        lock.withLock {
            if (!alive) return false
            if (needKey && !key) return false
            if (vqBytes > 0 && vqBytes + pkt.size > maxBacklog) {
                vq.clear()
                vqBytes = 0
                congested = true
                needKey = true
            }
            if (!(congested && !key)) {
                if (key) needKey = false
                vq.addLast(pkt)
                vqBytes += pkt.size
                queued = true
                cond.signalAll()
            }
        }
        if (congested) onCongestion?.invoke()
        return queued
    }

    /** 极致无损：一帧动辄几 MB，把内核发送缓冲放大到 1 MB，别让 Wi-Fi 在帧间空转（普通档保持 256 KB，免得把延迟藏进缓冲里） */
    fun tuneForBulk() {
        try { sock.sendBufferSize = 1 shl 20 } catch (ignored: Exception) { }
    }

    /** 极致无损：视频队列里还没写出去的字节数（调用方据此决定这一帧要不要丢，见 ScreenSource） */
    fun videoQueued(): Int = lock.withLock { vqBytes }

    /** 高优先级队列（聊天 / 语音帧走这里）里还没写出去的字节数 */
    fun hiQueued(): Long = lock.withLock { var n = 0L; for (b in hi) n += b.size; n }

    /** 极致无损：整帧入队，不清队列、不等关键帧（差异链不能带洞，所以丢不丢由调用方在「做差异之前」决定） */
    fun sendVideoRaw(pkt: ByteArray) {
        lock.withLock {
            if (!alive) return
            vq.addLast(pkt)
            vqBytes += pkt.size
            cond.signalAll()
        }
    }

    private fun nextPacket(): ByteArray? = lock.withLock {
        if (alive && hi.isEmpty() && vq.isEmpty()) cond.await(300, TimeUnit.MILLISECONDS)
        val h = hi.pollFirst()
        if (h != null) {
            h
        } else {
            val v = vq.pollFirst()
            if (v != null) vqBytes -= v.size
            v
        }
    }

    private fun writeLoop() {
        try {
            while (alive) {
                val now = System.currentTimeMillis()
                if (now - lastPing >= 1000) {
                    lastPing = now
                    sendHi(P.newPkt(P.T_PING, 0, System.nanoTime() / 1000, 0))
                }
                val b = nextPacket() ?: continue
                out.write(b)
            }
        } catch (e: Exception) {
            close("发送失败: ${e.message}")
        }
    }

    private fun readLoop() {
        try {
            while (alive) {
                val p = readPkt(din)
                lastRx = System.currentTimeMillis()
                when (p.type) {
                    P.T_PING -> sendHi(P.newPkt(P.T_PONG, 0, p.pts, 0))
                    P.T_PONG -> rttMs = (System.nanoTime() / 1000 - p.pts) / 1000
                    else -> handler?.onPacket(this, p)
                }
            }
        } catch (e: Exception) {
            close(if (alive) "连接断开: ${e.message}" else "已关闭")
        }
    }

    fun close(reason: String) {
        if (!closed.compareAndSet(false, true)) return
        alive = false
        lock.withLock { cond.signalAll() }
        try { sock.close() } catch (ignored: Exception) { }
        handler?.onClosed(this, reason)
    }

    companion object {
        /** 主动连接对方。mode: "push" = 把我的屏幕投给对方；"pull" = 我要看对方屏幕（对方需要用户确认，最长等 70 秒）。
         *  已配对的设备可能有几个地址（局域网 + 虚拟局域网）：先并行探测，走优先级最高且连得通的那个；通了就记成主地址。必须在后台线程调用。 */
        fun connect(host: String, port: Int, pin: String, mode: String, name: String, ctl: String = "", extra: JSONObject? = null): Session {
            val h = Link.resolveHost(host, port, pin)
            val se = connectHost(h, port, pin, mode, name, ctl, extra)
            Link.notePath(pin, h)
            return se
        }

        private fun connectHost(host: String, port: Int, pin: String, mode: String, name: String, ctl: String, extra: JSONObject? = null): Session {
            val s = Socket()
            s.tcpNoDelay = true
            try {
                s.connect(InetSocketAddress(host, port), 6000)
                s.soTimeout = 70_000
                val din = DataInputStream(BufferedInputStream(s.getInputStream(), 1 shl 16))
                val out = s.getOutputStream()
                val ch = readPkt(din)
                if (ch.type != P.T_CHALLENGE) throw IOException("协议不匹配")
                val cj = ch.json()
                val cn = P.randomHex(16)
                val hello = JSONObject()
                    .put("ver", P.VER).put("name", name).put("platform", "android").put("mode", mode)
                    .put("id", Link.id).put("caps", P.capsJson()).put("cn", cn)
                    .put("auth", P.hmacHex(pin, cj.getString("nonce")))
                if (extra != null) for (k in extra.keys()) hello.put(k, extra.get(k))        // 沉浸音乐：sid 等
                if (ctl.isNotEmpty()) hello.put("ctl", ctl)           // "req" = pull 时请求控制对方；"grant" = push 时允许对方控制我
                if (mode == "pair") {                    // 扫码配对：把本机的身份和（加密后的）密钥交给对方
                    hello.put("port", P.PORT)
                        .put("pk", P.maskPin(pin, cj.getString("nonce"), Link.pin))
                        .put("ips", JSONArray(Link.lanIps()))           // 本机的全部可连接地址（局域网 + 虚拟局域网），对方记作备用地址
                }
                out.write(P.jsonPkt(P.T_HELLO, hello))
                val r = readPkt(din)
                if (r.type == P.T_REJECT) throw IOException(r.json().optString("reason", "被拒绝"))
                if (r.type != P.T_ACCEPT) throw IOException("协议不匹配")
                // v2 身份校验：对方宣称 v2（或之前配对时确认过它是 v2），就必须给出正确的 proof；
                // 对 v1 对端（Windows 端）保持原行为，不做要求。
                val rj = try { r.json() } catch (e: Exception) { JSONObject() }
                val peerVer = maxOf(cj.optInt("ver", 1), rj.optInt("ver", 1))
                val proofOk = P.constEq(rj.optString("proof"), P.proofHex(pin, cj.getString("nonce"), cn))
                if ((cj.optInt("ver", 1) >= 2 || Link.requiresProof(pin)) && !proofOk) {
                    throw IOException("对方未通过身份校验，已断开（可能不是你要连接的设备）")
                }
                val se = Session(s, din, out, false)
                se.peerName = cj.optString("name")
                se.peerPlatform = cj.optString("platform")
                se.peerId = cj.optString("id")
                se.peerVer = if (proofOk) peerVer else 1
                se.peerCaps = P.parseCaps(cj.optJSONArray("caps"))
                se.mode = mode
                se.hsNonce = cj.getString("nonce"); se.hsCn = cn
                se.canControl = proofOk && ctl == "req" && rj.optBoolean("ctl", false)
                if (proofOk) Link.noteV2(pin)
                return se
            } catch (e: Exception) {
                try { s.close() } catch (ignored: Exception) { }
                throw e
            }
        }

        /** 服务端：发 challenge、校验 PIN。返回的会话尚未 accept()/reject()，由调用方决定。 */
        fun acceptClient(s: Socket, pin: String, name: String): Session {
            try {
                s.tcpNoDelay = true
                s.soTimeout = 5000
                val din = DataInputStream(BufferedInputStream(s.getInputStream(), 1 shl 16))
                val out = s.getOutputStream()
                val nonce = P.randomHex(16)
                out.write(P.jsonPkt(P.T_CHALLENGE, JSONObject().put("nonce", nonce).put("name", name).put("platform", "android")
                    .put("ver", P.VER).put("id", Link.id).put("caps", P.capsJson())))
                val h = readPkt(din)
                if (h.type != P.T_HELLO) throw IOException("bad hello")
                val hj = h.json()
                if (hj.optString("auth") != P.hmacHex(pin, nonce)) {
                    try { out.write(P.jsonPkt(P.T_REJECT, JSONObject().put("reason", "配对已失效，请用手机重新扫码配对"))) } catch (ignored: Exception) { }
                    Thread.sleep(1500)                       // 拖慢暴力猜密钥
                    throw IOException("auth failed")
                }
                s.soTimeout = 0
                val se = Session(s, din, out, true)
                se.peerName = hj.optString("name", "未知设备")
                se.peerPlatform = hj.optString("platform")
                se.mode = hj.optString("mode")
                se.hello = hj
                se.nonce = nonce
                se.hsNonce = nonce; se.hsCn = hj.optString("cn")
                se.authPin = pin
                se.peerVer = hj.optInt("ver", 1)
                se.peerId = hj.optString("id")
                se.peerCaps = P.parseCaps(hj.optJSONArray("caps"))
                val cn = hj.optString("cn")
                if (se.peerVer >= 2 && Regex("[0-9a-f]{16,64}").matches(cn)) se.clientNonce = cn
                if (se.peerVer >= 2) {
                    se.ctlReq = hj.optString("ctl") == "req"
                    se.canControl = hj.optString("ctl") == "grant"
                }
                return se
            } catch (e: Exception) {
                try { s.close() } catch (ignored: Exception) { }
                throw e
            }
        }
    }
}

/** 全局单例：本机身份(PIN)、监听、设备发现、Wi-Fi 低延迟锁。 */
object Link {
    interface Listener {
        fun onIncoming(s: Session): Boolean       // 在主线程回调；返回 true 表示接管了该会话
        fun onPeers()
        fun onStatus(msg: String)
        /** 本机网络变了（Wi-Fi / 移动数据 / VPN 开关）：界面据此刷新二维码和网络状态 */
        fun onNetwork() {}
    }

    lateinit var app: Context
    lateinit var prefs: SharedPreferences
    var pin = ""
    var id = ""
    var name = "Android"
    @Volatile var listener: Listener? = null
    @Volatile var busy = false
    @Volatile var pendingPull: Session? = null
    val peers = ConcurrentHashMap<String, Peer>()
    /** 每台设备最近 8 秒内被听到过的全部地址（地址 → 最后听到的时间） */
    private val peerAddrs = ConcurrentHashMap<String, ConcurrentHashMap<String, Long>>()
    val main = Handler(Looper.getMainLooper())

    private var started = false
    private var multicast: WifiManager.MulticastLock? = null
    private var wifiLock: WifiManager.WifiLock? = null
    private var wifiPerfLock: WifiManager.WifiLock? = null   // 息屏后低延迟锁不生效，另持一把高性能锁，避免息屏时 Wi-Fi 进入省电模式
    private var wakeLock: PowerManager.WakeLock? = null

    fun init(ctx: Context) {
        if (::app.isInitialized) return
        app = ctx.applicationContext
        prefs = app.getSharedPreferences("lancast", Context.MODE_PRIVATE)
        id = prefs.getString("id", null) ?: P.randomHex(8).also { prefs.edit().putString("id", it).apply() }
        pin = prefs.getString("pin", null) ?: newPin()
        name = prefs.getString("name", null)?.takeIf { it.isNotBlank() } ?: Build.MODEL ?: "Android"
    }

    /** 设置页保存设备名称：之后配对、设备发现里显示的都是这个名字 */
    fun updateName(n: String) {
        name = n
        prefs.edit().putString("name", n).apply()
        Thread {
            try { ChatNet.start(); ChatNet.hub.announceName() } catch (ignored: Exception) { }      // 实时推给所有已连上的对方
        }.start()
    }

    /** 对方改了名字：只改已配对记录里的名称 */
    fun renamePeer(id: String, n: String) {
        val p = pairs().firstOrNull { it.id == id } ?: return
        val nn = n.trim().take(64)
        if (nn.isNotEmpty() && nn != p.name) savePair(p.copy(name = nn))
    }

    /* ═════════════ 扫码配对 ═════════════
     * 二维码内容：lancast://pair?v=1&id=设备ID&n=名称&p=配对密钥&port=端口&ip=IP1,IP2（与电脑端格式一致）
     * 扫码的一方用对方的密钥连过去（mode = "pair"），同时把自己的密钥加密后交给对方，
     * 于是双方都记下了对方的密钥，之后文件互传、投屏都不用再输入任何东西。 */
    @Synchronized
    fun pairs(): List<Paired> {
        val out = ArrayList<Paired>()
        try {
            val arr = JSONArray(prefs.getString("pairs", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val ia = o.optJSONArray("ips")
                val extra = ArrayList<String>()
                if (ia != null) for (k in 0 until minOf(ia.length(), 16)) extra.add(ia.optString(k))
                out.add(Paired(o.getString("id"), o.optString("name", "未知设备"), o.optString("platform"), o.optString("ip"), o.optInt("port", P.PORT), o.getString("pin"), o.optInt("ver", 1), NetX.cleanIps(extra, NetX.MAX_ADDRS)))
            }
        } catch (ignored: Exception) { }
        return out
    }

    @Synchronized
    private fun writePairs(list: List<Paired>) {
        val arr = JSONArray()
        for (p in list) {
            arr.put(JSONObject().put("id", p.id).put("name", p.name).put("platform", p.platform).put("ip", p.ip).put("port", p.port).put("pin", p.pin).put("ver", p.ver).put("ips", JSONArray(p.ips)))
        }
        prefs.edit().putString("pairs", arr.toString()).apply()
    }

    /** 保存配对记录。同一台设备再次配对 / 换了地址时，旧地址不丢：并进备用地址列表（最多共 6 个）——
     *  在家里用局域网配对过、出门后用虚拟局域网（蒲公英）连的时候，两条路都还记得。 */
    @Synchronized
    fun savePair(p: Paired) {
        val list = ArrayList<Paired>()
        var old: Paired? = null
        for (x in pairs()) if (x.id != p.id) list.add(x) else old = x
        val m = NetX.mergeAddrs(p.ip, p.ips, if (old != null) NetX.recAddrs(old.ip, old.ips) else emptyList())
        list.add(p.copy(ip = m.first, ips = m.second))
        writePairs(list)
    }

    /** 刚刚经由 host 连通并通过了认证：把这个地址排到最前，下次直接用（旧地址仍留在备用列表里）。 */
    @Synchronized
    fun notePath(pin: String, host: String) {
        val p = pairs().firstOrNull { it.pin == pin } ?: return
        if (p.ip != host) savePair(p.copy(ip = host))
    }

    /** 这台设备最近 8 秒内被听到过的地址（发现包的来源地址） */
    fun liveAddrs(id: String): List<String> {
        val m = peerAddrs[id] ?: return emptyList()
        val now = System.currentTimeMillis()
        return m.entries.filter { now - it.value <= 8000 }.map { it.key }.sorted()
    }

    /** 已配对的设备可能有几个地址：把传入的 host 和这台设备的其他已知地址（含刚刚收到过发现包的地址）并行探测，
     *  返回优先级最高且连得通的那个。只有一个地址时不探测；全都探测不通就还用 host（之后报出正常的连接错误）。必须在后台线程调用。 */
    fun resolveHost(host: String, port: Int, pin: String): String {
        val rec = pairs().firstOrNull { it.pin == pin } ?: return host
        val cands = NetX.order(listOf(host) + liveAddrs(rec.id) + NetX.recAddrs(rec.ip, rec.ips), localAddrs())
        if (cands.size < 2) return host
        return NetX.probe(cands, port).firstOrNull() ?: host
    }

    @Synchronized
    fun forgetPair(id: String) {
        val list = ArrayList<Paired>()
        for (x in pairs()) if (x.id != id) list.add(x)
        writePairs(list)
    }

    /** 之前配对时确认过对方是 v2 设备：以后连它就必须带正确的 proof，防止被降级成无校验的 v1。 */
    fun requiresProof(pin: String): Boolean = pairs().any { it.pin == pin && it.ver >= 2 }

    /** 一次握手里验证了对方的 proof：把配对记录升级成 v2（旧版配对的设备首次连通后自动获得降级保护）。 */
    @Synchronized
    fun noteV2(pin: String) {
        val list = pairs()
        if (list.none { it.pin == pin && it.ver < 2 }) return
        writePairs(list.map { if (it.pin == pin && it.ver < 2) it.copy(ver = 2) else it })
    }

    /* ═════════════ 本机网络 ═════════════
     * 地址分三类：LAN（Wi-Fi / 以太网 / 热点）、OVERLAY（虚拟局域网 = 蒲公英 / ZeroTier / Tailscale 等 VPN 网卡）、CELL（移动数据）。
     * ConnectivityManager 给出的传输类型最准；它覆盖不到的网卡（比如本机开的热点 ap0 / swlan0）按网卡名判断。 */
    @Volatile private var addrCache: List<NetX.Addr> = emptyList()
    @Volatile private var addrCacheAt = 0L

    /** 本机当前所有可用的 IPv4 地址（1.5 秒内的重复调用直接用缓存；网络一变缓存立刻作废） */
    @Suppress("DEPRECATION")
    fun localAddrs(): List<NetX.Addr> {
        val now = SystemClock.elapsedRealtime()
        if (now - addrCacheAt < 1500L) return addrCache
        val out = ArrayList<NetX.Addr>()
        val seen = HashSet<String>()
        val kindByIface = HashMap<String, NetX.Kind>()
        try {
            val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            for (n in cm.allNetworks) {
                val caps = cm.getNetworkCapabilities(n) ?: continue
                val lp = cm.getLinkProperties(n) ?: continue
                val nm = lp.interfaceName ?: continue
                val k = when {
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN) -> NetX.Kind.OVERLAY
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> NetX.Kind.LAN
                    caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> NetX.Kind.CELL
                    else -> null
                } ?: continue
                kindByIface[nm] = k
                for (la in lp.linkAddresses) {
                    val a = la.address
                    if (a !is Inet4Address) continue
                    val ip = a.hostAddress ?: continue
                    if (NetX.usable(ip) && seen.add(ip)) out.add(NetX.Addr(ip, la.prefixLength, nm, k))
                }
            }
        } catch (ignored: Exception) { }
        try {
            for (ni in Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp || ni.isLoopback) continue
                val nm = ni.name ?: continue
                for (ia in ni.interfaceAddresses) {
                    val a = ia.address
                    if (a !is Inet4Address) continue
                    val ip = a.hostAddress ?: continue
                    if (!NetX.usable(ip) || !seen.add(ip)) continue
                    val k = kindByIface[nm] ?: NetX.kindOfIface(nm, ip)
                    if (k != NetX.Kind.JUNK) out.add(NetX.Addr(ip, ia.networkPrefixLength.toInt(), nm, k))
                }
            }
        } catch (ignored: Exception) { }
        addrCache = out
        addrCacheAt = now
        return out
    }

    /** 二维码 / 配对链接里放的本机地址：局域网在前、虚拟局域网在后；只有移动数据时放移动数据的地址（二维码不会是空的）。 */
    fun lanIps(): List<String> = NetX.qrIps(localAddrs())

    fun netState(): NetX.State = NetX.state(localAddrs())

    /** 对方是否就在本机的局域网里（不是 → 经虚拟局域网 / 移动网络，心跳超时要放宽） */
    fun isLanPeer(ip: String): Boolean = NetX.isLanPeer(ip, localAddrs())

    /** 这个对方地址走的是哪种链路：局域网直连 / 虚拟局域网 / 远程连接 */
    fun pathLabel(ip: String): String = NetX.pathLabel(ip, localAddrs())

    private var netCb: ConnectivityManager.NetworkCallback? = null

    /** 监听网络变化（Wi-Fi / 移动数据 / VPN 开关）：缓存作废，并通知界面马上刷新二维码。
     *  NetworkRequest 默认不含 VPN 网络，所以要显式去掉 NOT_VPN 限制，才能听到蒲公英连上 / 断开。 */
    private fun watchNetwork() {
        if (netCb != null) return
        try {
            val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val cb = object : ConnectivityManager.NetworkCallback() {
                private fun changed() { addrCacheAt = 0L; main.post { listener?.onNetwork() } }
                override fun onAvailable(network: Network) = changed()
                override fun onLost(network: Network) = changed()
                override fun onLinkPropertiesChanged(network: Network, linkProperties: android.net.LinkProperties) = changed()
            }
            val req = NetworkRequest.Builder().removeCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN).build()
            cm.registerNetworkCallback(req, cb)
            netCb = cb
        } catch (ignored: Exception) { }
    }

    /** 本机二维码的内容 */
    fun pairText(): String = NetX.buildLink(id, name, pin, P.PORT, lanIps())

    /** 解析扫到的二维码 / 粘贴的配对链接（前后有别的文字也行）；不是瞬流的配对码就返回 null。 */
    fun parseQr(text: String): QrInfo? = NetX.parseLink(text)

    /** 扫码 / 粘贴链接后调用（在后台线程）：对二维码里的全部地址并行探测（和本机同网段的优先），
     *  按优先级依次对连得通的地址做配对握手，第一个成功的算数；其余地址作为备用地址一并记下。 */
    fun pairWith(q: QrInfo): Paired {
        val locals = localAddrs()
        val ordered = NetX.order(q.ips, locals)
        val reach = NetX.probe(ordered, q.port, timeoutMs = 3500, all = true)
        if (reach.isEmpty()) throw IOException(NetX.unreachableHint(NetX.state(locals), ordered))
        var last: Exception? = null
        for (ip in reach) {
            try {
                val se = Session.connect(ip, q.port, q.pin, "pair", name)
                if (se.peerId.isNotEmpty() && se.peerId != q.id) {          // 地址被别的设备占用了（或链接里的身份对不上）
                    se.close("身份不符")
                    throw IOException("对方不是链接里的那台设备（可能链接已过期，或这个地址被别的设备占用了）")
                }
                val p = Paired(q.id, if (se.peerName.isEmpty()) q.name else se.peerName, if (se.peerPlatform.isEmpty()) "windows" else se.peerPlatform, ip, q.port, q.pin, se.peerVer, q.ips.filter { it != ip })
                se.close("配对完成")
                savePair(p)
                return p
            } catch (e: Exception) {
                last = e
                if ((e.message ?: "").contains("配对")) throw e      // 对方明确拒绝（二维码已过期等），换地址也没用
            }
        }
        throw (last ?: IOException("连接失败"))
    }

    /** 对方扫了本机的二维码：解出对方的密钥并记下来。 */
    private fun handlePair(se: Session) {
        val hj = se.hello
        val pid = hj?.optString("id") ?: ""
        val pk = P.unmaskPin(pin, se.nonce, hj?.optString("pk") ?: "")
        if (hj == null || pid.length < 4 || pid.length > 64 || !Regex("\\d{4,12}").matches(pk)) {
            se.reject("配对信息不完整，请重新扫码")
            return
        }
        val extra = ArrayList<String>()
        val ia = hj.optJSONArray("ips")                                   // 对方自己报的其他地址（局域网 + 虚拟局域网），记作备用
        if (ia != null) for (k in 0 until minOf(ia.length(), 16)) extra.add(ia.optString(k))
        val ips = NetX.cleanIps(extra, NetX.MAX_ADDRS).filter { it != se.remoteIp }
        savePair(Paired(pid, se.peerName, se.peerPlatform, se.remoteIp, hj.optInt("port", P.PORT), pk, se.peerVer, ips))
        se.accept()
        status("已与「" + se.peerName + "」配对成功")
        main.post { listener?.onPeers() }
        try { Thread.sleep(500) } catch (ignored: InterruptedException) { }      // 让对方先读到确认
        se.close("配对完成")
    }

    fun newPin(): String {
        val p = "%010d".format(SecureRandom().nextLong().and(Long.MAX_VALUE) % 10_000_000_000L)      // 10 位：旧版是 6 位，抓到握手包后离线猜解太容易
        pin = p
        prefs.edit().putString("pin", p).apply()
        return p
    }

    fun status(msg: String) {
        main.post { listener?.onStatus(msg) }
    }

    /** 手机屏幕是否亮着；查询失败当作亮着（保持原有的严格超时）。 */
    fun screenOn(): Boolean = try {
        (app.getSystemService(Context.POWER_SERVICE) as PowerManager).isInteractive
    } catch (e: Exception) { true }

    @Synchronized
    fun holdWifi(on: Boolean) {
        try {
            if (on) {
                if (wifiLock == null) {
                    val wm = app.getSystemService(Context.WIFI_SERVICE) as WifiManager
                    wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_LOW_LATENCY, "lancast-ll").apply { setReferenceCounted(false) }
                }
                if (wifiLock?.isHeld != true) wifiLock?.acquire()
                if (wifiPerfLock == null) {
                    val wm = app.getSystemService(Context.WIFI_SERVICE) as WifiManager
                    @Suppress("DEPRECATION")
                    wifiPerfLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "lancast-hp").apply { setReferenceCounted(false) }
                }
                if (wifiPerfLock?.isHeld != true) wifiPerfLock?.acquire()
                if (wakeLock == null) {
                    val pm = app.getSystemService(Context.POWER_SERVICE) as PowerManager
                    wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "lancast:session").apply { setReferenceCounted(false) }
                }
                if (wakeLock?.isHeld != true) wakeLock?.acquire(6 * 60 * 60 * 1000L)
            } else {
                if (wifiLock?.isHeld == true) wifiLock?.release()
                if (wifiPerfLock?.isHeld == true) wifiPerfLock?.release()
                if (wakeLock?.isHeld == true) wakeLock?.release()
            }
        } catch (ignored: Exception) { }
    }

    fun start() {
        if (started) return
        started = true
        try {
            val wm = app.getSystemService(Context.WIFI_SERVICE) as WifiManager
            multicast = wm.createMulticastLock("lancast").apply { setReferenceCounted(false); acquire() }
        } catch (ignored: Exception) { }
        thread(name = "link-srv", isDaemon = true) { serverLoop() }
        thread(name = "link-drx", isDaemon = true) { discRx() }
        thread(name = "link-dtx", isDaemon = true) { discTx() }
        watchNetwork()
        ChatNet.start()
    }

    private fun serverLoop() {
        while (true) {
            try {
                val ss = ServerSocket()
                ss.reuseAddress = true
                ss.bind(InetSocketAddress(P.PORT))
                while (true) {
                    val s = ss.accept()
                    thread(isDaemon = true) { handleIncoming(s) }
                }
            } catch (ignored: Exception) {
                try { Thread.sleep(2000) } catch (ignored: InterruptedException) { }
            }
        }
    }

    private fun handleIncoming(s: Socket) {
        try {
            val se = Session.acceptClient(s, pin, name)
            if (se.mode == "pair") {                  // 扫码配对：不占用投屏会话
                handlePair(se)
                return
            }
            if (se.mode == "chat") {                  // 安全聊天：不占用投屏会话
                ChatNet.onIncoming(se)
                return
            }
            if (se.mode == "file") {                  // 文件互传：不占用投屏会话，可与投屏同时进行
                se.accept()
                FileXfer.onIncoming(se)
                return
            }
            if (busy) {
                se.reject("对方正忙")
                return
            }
            val handled = AtomicBoolean(false)
            val latch = CountDownLatch(1)
            main.post {
                try { handled.set(listener?.onIncoming(se) ?: false) } finally { latch.countDown() }
            }
            latch.await(3, TimeUnit.SECONDS)
            if (!handled.get()) {
                if (listener == null && !busy && (se.mode == "push" || se.mode == "pull")) park(se)   // 应用在后台：挂起并通知用户
                else se.reject("手机上的瞬流Pro需要保持在前台")
            }
        } catch (ignored: Exception) {
            // PIN 错误或握手失败：连接已在 acceptClient 里关闭
        }
    }

    /* ═════════════ 后台来电挂起（安卓 ↔ 安卓） ═════════════
     * 对方要投屏 / 看屏幕，但本机瞬流在后台：录屏授权和观看窗口都必须由前台 Activity 完成，
     * 所以不能直接拒绝，而是把已认证的会话挂起最多 PARK_MS，同时弹出通知；用户点通知回到应用（onStart），
     * 由 deliverParked() 把挂起的会话交给界面。超时没人处理就礼貌地拒绝。
     * 对方（Android 客户端）握手后最多等 70 秒，所以挂起时间要明显小于它。 */
    private class Parked(val s: Session)

    private const val PARK_MS = 45_000L
    private val parked = ArrayList<Parked>()

    private fun park(se: Session) {
        val p = Parked(se)
        synchronized(parked) { parked.add(p) }
        val what = if (se.mode == "push") "想把屏幕投给你" else "想查看你的屏幕"
        Notice.incoming("「" + se.peerName + "」" + what, "点按打开瞬流Pro并处理（45 秒内有效）")
        if (listener != null) main.post { deliverParked() }          // 刚好在挂起的瞬间应用回到了前台
        val end = SystemClock.elapsedRealtime() + PARK_MS
        while (SystemClock.elapsedRealtime() < end) {
            if (synchronized(parked) { !parked.contains(p) }) return          // 已被 deliverParked 取走
            try { Thread.sleep(300) } catch (ignored: InterruptedException) { }
        }
        val mine = synchronized(parked) { parked.remove(p) }
        if (mine) {
            Notice.clearIncoming()
            se.reject("对方手机没有及时打开瞬流Pro，请让对方打开应用后再试")
        }
    }

    /** MainActivity.onStart 里调用（主线程，listener 已设置）：把后台期间挂起的会话交给界面。 */
    fun deliverParked() {
        val l = listener ?: return
        val list = synchronized(parked) { val c = ArrayList(parked); parked.clear(); c }
        if (list.isEmpty()) return
        Notice.clearIncoming()
        for (p in list) {
            val ok = try { l.onIncoming(p.s) } catch (e: Exception) { false }
            if (!ok) thread(isDaemon = true) { p.s.reject("对方正忙") }
        }
    }

    private fun discTx() {
        val sock = DatagramSocket()
        sock.broadcast = true
        while (true) {
            try {
                val msg = JSONObject().put("a", "lancast").put("id", id).put("n", name).put("p", "android").put("port", P.PORT)
                    .toString().toByteArray(Charsets.UTF_8)
                val targets = LinkedHashSet<String>()
                targets.add("255.255.255.255")
                for (ni in Collections.list(NetworkInterface.getNetworkInterfaces())) {
                    if (!ni.isUp || ni.isLoopback) continue
                    for (ia in ni.interfaceAddresses) ia.broadcast?.hostAddress?.let { targets.add(it) }
                }
                /* 对已配对设备的所有已知地址直接单播：虚拟局域网 / VPN 一般不转发广播，没有单播的话，跨网络时对方永远「不在线」 */
                val locals = localAddrs()
                for (p in pairs()) for (a in NetX.recAddrs(p.ip, p.ips)) if (NetX.shouldUnicast(a, locals)) targets.add(a)
                for (t in targets) {
                    try { sock.send(DatagramPacket(msg, msg.size, InetAddress.getByName(t), P.DISC_PORT)) } catch (ignored: Exception) { }
                }
            } catch (ignored: Exception) { }
            try { Thread.sleep(1500) } catch (ignored: InterruptedException) { }
        }
    }

    private fun discRx() {
        while (true) {
            try {
                val sock = DatagramSocket(null)
                sock.reuseAddress = true
                sock.bind(InetSocketAddress(P.DISC_PORT))
                val buf = ByteArray(1024)
                while (true) {
                    val pk = DatagramPacket(buf, buf.size)
                    sock.receive(pk)
                    val j = JSONObject(String(pk.data, 0, pk.length, Charsets.UTF_8))
                    if (j.optString("a") != "lancast") continue
                    val pid = j.optString("id")
                    if (pid.isEmpty() || pid == id) continue
                    val ip = pk.address.hostAddress ?: continue
                    /* 同一台设备可能同时从几条路被听到（局域网广播 + 虚拟局域网单播）：按优先级取一个地址，不要来回跳 */
                    val now = System.currentTimeMillis()
                    val addrs = peerAddrs.getOrPut(pid) { ConcurrentHashMap() }
                    addrs[ip] = now
                    addrs.entries.removeAll { now - it.value > 8000 }
                    val best = NetX.order(addrs.keys.sorted(), localAddrs()).firstOrNull() ?: ip
                    peers[pid] = Peer(pid, j.optString("n"), j.optString("p"), best, j.optInt("port", P.PORT), now)
                    main.post { listener?.onPeers() }
                }
            } catch (ignored: Exception) {
                try { Thread.sleep(2000) } catch (ignored: InterruptedException) { }
            }
        }
    }
}
