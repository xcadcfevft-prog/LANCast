package com.lancast.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

/**
 * 内置播放器（ExoPlayer）：播放本地流地址（边下边播）或已下完的本地文件。
 * 内置解码不了的格式（部分 HEVC / AC3 / DTS 等取决于手机），可以点右上角「外部播放器」交给 MX Player / VLC 等。
 */
class PlayerActivity : ComponentActivity() {
    companion object {
        fun open(ctx: Context, hash: String, index: Int) {
            ctx.startActivity(Intent(ctx, PlayerActivity::class.java).putExtra("hash", hash).putExtra("idx", index))
        }
    }

    private val ui = Handler(Looper.getMainLooper())
    private var player: ExoPlayer? = null
    private lateinit var view: PlayerView
    private lateinit var titleTv: TextView
    private lateinit var infoTv: TextView
    private var uri = ""
    private var hash = ""
    private var idx = -1
    private var failed = false
    private var running = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR
        setContentView(buildUi())
        hash = intent.getStringExtra("hash") ?: ""
        idx = intent.getIntExtra("idx", -1)
        infoTv.text = "正在准备…（首次需要先连上节点，通常几秒到几十秒）"
        BtEngine.post {
            try {
                BtEngine.init(applicationContext)
                val t = BtEngine.get(hash) ?: throw IllegalStateException("任务不存在，请回到磁力解析重新点播放")
                val f = t.file(idx) ?: throw IllegalStateException("文件不存在")
                val (u, _) = BtEngine.playUri(t, idx)
                ui.post { titleTv.text = f.name; uri = u; startPlayback() }
            } catch (e: Throwable) {
                ui.post { infoTv.text = e.message ?: e.javaClass.simpleName; failed = true }
            }
        }
    }

    private fun startPlayback() {
        if (isDestroyed || player != null) return
        // 比默认更保守的缓冲：先攒 2.5 秒就开播，卡了攒 5 秒再继续，最多预读 60 秒（预读也会带动后面分片的下载）
        val load = DefaultLoadControl.Builder().setBufferDurationsMs(15_000, 60_000, 2_500, 5_000).build()
        val p = ExoPlayer.Builder(this).setLoadControl(load).build()
        player = p
        view.player = p
        p.addListener(object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                failed = true
                infoTv.text = "内置播放器无法播放这个文件（${error.errorCodeName}）。可以点右上角「外部播放器」，或等下载完成后再试"
            }
        })
        p.setMediaItem(MediaItem.fromUri(Uri.parse(uri)))
        p.prepare()
        p.playWhenReady = true
    }

    override fun onStart() {
        super.onStart()
        running = true
        statLoop()
        if (player != null) player?.playWhenReady = true
    }

    override fun onStop() {
        running = false
        player?.playWhenReady = false
        super.onStop()
    }

    override fun onDestroy() {
        running = false
        view.player = null
        player?.release()
        player = null
        super.onDestroy()
    }

    private fun statLoop() {
        if (!running) return
        val t = BtEngine.get(hash)
        val p = player
        if (t != null && p != null && !failed) {
            val buffering = p.playbackState == Player.STATE_BUFFERING
            infoTv.text = (if (buffering) "缓冲中… · " else "") +
                if (t.done) "已下载完成" else "已下载 ${(t.progress * 100).toInt()}% · ↓ ${MagnetCore.formatSize(t.down.toLong())}/s · ${t.peers} 个节点"
        }
        ui.postDelayed({ statLoop() }, 1000)
    }

    private fun external() {
        // 外部播放器读不了本应用的私有目录，所以不管下没下完，都走本机 127.0.0.1 的 HTTP 地址
        val t = BtEngine.get(hash) ?: return
        val f = t.file(idx) ?: return
        val u = BtEngine.httpUrl(t, f)
        try {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(u), "video/*"), "选择播放器"))
        } catch (_: Throwable) {
            copy(u)
        }
    }

    private fun copy(text: String) {
        try {
            (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("url", text))
            Toast.makeText(this, "没有可用的外部播放器，地址已复制，可在播放器里「打开网络串流」粘贴", Toast.LENGTH_LONG).show()
        } catch (_: Throwable) {}
    }

    private fun tv(text: String, sp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.BLACK) }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(px(12), px(6), px(12), px(6)) }
        bar.addView(tv("‹ 返回", 15f, Color.WHITE, true).apply { setPadding(0, px(6), px(14), px(6)); setOnClickListener { finish() } })
        titleTv = tv("", 14f, Color.WHITE).apply { setSingleLine(); ellipsize = android.text.TextUtils.TruncateAt.END }
        bar.addView(titleTv, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        bar.addView(tv("外部播放器", 13f, Color.WHITE, true).apply { setPadding(px(12), px(6), 0, px(6)); setOnClickListener { external() } })
        root.addView(bar, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        view = PlayerView(this)
        root.addView(view, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        infoTv = tv("", 12f, Color.parseColor("#B8C4CE")).apply { setPadding(px(14), px(8), px(14), px(10)) }
        root.addView(infoTv, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
        return root
    }
}
