package com.lancast.app

import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.security.MessageDigest

/**
 * 沉浸音乐的「歌曲信息」来源：盯着系统里正在播放的那个媒体会话（网易云 / QQ 音乐 / Spotify / 系统播放器……），
 * 读歌名、歌手、专辑、封面、进度、状态，并把电脑发来的「播放 / 暂停 / 上一首 / 下一首 / 拖动进度」转给它。
 * 需要用户授予「通知使用权」（MusicListener），没授权时 granted() = false，其余方法都安全地什么也不做。
 */
class MusicMeta(private val ctx: Context, private val onChange: () -> Unit) {
    private val h = Handler(Looper.getMainLooper())
    private val comp = ComponentName(ctx, MusicListener::class.java)
    private var msm: MediaSessionManager? = null
    @Volatile private var ctl: MediaController? = null
    private var watching: MediaController? = null
    private var started = false

    private val cb = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) { changed() }
        override fun onMetadataChanged(metadata: MediaMetadata?) { changed() }
        override fun onSessionDestroyed() { h.post { pick(sessions()); onChange() } }
    }
    private val sl = MediaSessionManager.OnActiveSessionsChangedListener { list -> pick(list); onChange() }

    private fun changed() { onChange() }

    companion object {
        fun granted(ctx: Context): Boolean = try {
            (Settings.Secure.getString(ctx.contentResolver, "enabled_notification_listeners") ?: "").split(":")
                .any { ComponentName.unflattenFromString(it)?.packageName == ctx.packageName }
        } catch (e: Exception) { false }
    }

    fun granted(): Boolean = granted(ctx)

    fun start() {
        if (started || !granted()) return
        h.post {
            try {
                val m = ctx.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
                msm = m
                m.addOnActiveSessionsChangedListener(sl, comp, h)
                started = true
                pick(sessions())
                onChange()
            } catch (ignored: Exception) { }
        }
    }

    fun stop() {
        h.post {
            try { msm?.removeOnActiveSessionsChangedListener(sl) } catch (ignored: Exception) { }
            try { watching?.unregisterCallback(cb) } catch (ignored: Exception) { }
            watching = null; ctl = null; started = false
        }
    }

    private fun sessions(): List<MediaController> = try { msm?.getActiveSessions(comp) ?: emptyList() } catch (e: Exception) { emptyList() }

    /** 选一个：正在播放的优先；都没在播就保持当前那个（暂停的歌也要显示），再没有就取第一个 */
    private fun pick(list: List<MediaController>?) {
        val l = list ?: emptyList()
        var best: MediaController? = l.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
        if (best == null) best = l.firstOrNull { c -> ctl?.let { it.sessionToken == c.sessionToken } == true }
        if (best == null) best = l.firstOrNull()
        if (best?.sessionToken != watching?.sessionToken) {
            try { watching?.unregisterCallback(cb) } catch (ignored: Exception) { }
            watching = best
            try { best?.registerCallback(cb, h) } catch (ignored: Exception) { }
        }
        ctl = best
    }

    /** 周期性调用时也顺便重选一次（比如另一个 App 开始播放了，但没触发会话列表变化） */
    fun refresh() { if (started) h.post { pick(sessions()) } }

    class Snap(val json: JSONObject, val coverKey: String, val cover: Bitmap?)

    fun snapshot(): Snap {
        val j = JSONObject()
        val c = ctl
        if (c == null) {
            j.put("state", "none").put("title", "").put("ctl", granted())
            return Snap(j, "", null)
        }
        val md = try { c.metadata } catch (e: Exception) { null }
        val ps = try { c.playbackState } catch (e: Exception) { null }
        val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE) ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE) ?: ""
        val artist = md?.getString(MediaMetadata.METADATA_KEY_ARTIST) ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: md?.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE) ?: ""
        val album = md?.getString(MediaMetadata.METADATA_KEY_ALBUM) ?: ""
        val dur = md?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
        var pos = ps?.position ?: 0L
        val speed = ps?.playbackSpeed ?: 1f
        val state = when (ps?.state) {
            PlaybackState.STATE_PLAYING, PlaybackState.STATE_FAST_FORWARDING, PlaybackState.STATE_REWINDING -> "playing"
            PlaybackState.STATE_PAUSED -> "paused"
            PlaybackState.STATE_BUFFERING, PlaybackState.STATE_CONNECTING, PlaybackState.STATE_SKIPPING_TO_NEXT,
            PlaybackState.STATE_SKIPPING_TO_PREVIOUS, PlaybackState.STATE_SKIPPING_TO_QUEUE_ITEM -> "buffering"
            PlaybackState.STATE_STOPPED -> "stopped"
            else -> "none"
        }
        if (ps != null && state == "playing" && pos >= 0) pos += ((SystemClock.elapsedRealtime() - ps.lastPositionUpdateTime) * speed).toLong()
        if (pos < 0) pos = 0
        if (dur > 0 && pos > dur) pos = dur
        val acts = ps?.actions ?: 0L
        val can = JSONArray()
        if (acts and (PlaybackState.ACTION_PLAY or PlaybackState.ACTION_PLAY_PAUSE) != 0L) can.put("play")
        if (acts and (PlaybackState.ACTION_PAUSE or PlaybackState.ACTION_PLAY_PAUSE) != 0L) can.put("pause")
        if (acts and PlaybackState.ACTION_SKIP_TO_NEXT != 0L) can.put("next")
        if (acts and PlaybackState.ACTION_SKIP_TO_PREVIOUS != 0L) can.put("prev")
        if (acts and PlaybackState.ACTION_SEEK_TO != 0L) can.put("seek")
        val app = try {
            val pm = ctx.packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(c.packageName ?: "", 0)).toString()
        } catch (e: Exception) { c.packageName ?: "" }
        val bmp = md?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART) ?: md?.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        val key = if (bmp == null) "" else md5hex("$title|$artist|$album|${bmp.width}x${bmp.height}|${System.identityHashCode(bmp)}").substring(0, 16)
        j.put("title", title).put("artist", artist).put("album", album).put("app", app)
            .put("duration", if (dur > 0) dur else 0L).put("pos", pos).put("speed", speed.toDouble())
            .put("state", state).put("can", can).put("cover", key).put("ctl", true)
        return Snap(j, key, bmp)
    }

    /** 电脑发来的控制指令 → 当前媒体会话。返回是否执行 */
    fun command(cmd: String, pos: Long): Boolean {
        val c = ctl ?: return false
        return try {
            val t = c.transportControls
            when (cmd) {
                "play" -> t.play()
                "pause" -> t.pause()
                "toggle" -> if (c.playbackState?.state == PlaybackState.STATE_PLAYING) t.pause() else t.play()
                "next" -> t.skipToNext()
                "prev" -> t.skipToPrevious()
                "seek" -> t.seekTo(maxOf(0L, pos))
                "stop" -> t.stop()
                else -> return false
            }
            true
        } catch (e: Exception) { false }
    }

    private fun md5hex(s: String): String =
        MessageDigest.getInstance("MD5").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }
}

/** 封面编码成 PNG（无损）；太大的先等比缩到长边 ≤ 1600 */
fun encodeCover(b: Bitmap): ByteArray? = try {
    val m = maxOf(b.width, b.height)
    val src = if (m > 1600) Bitmap.createScaledBitmap(b, b.width * 1600 / m, b.height * 1600 / m, true) else b
    val o = ByteArrayOutputStream()
    src.compress(Bitmap.CompressFormat.PNG, 100, o)
    o.toByteArray()
} catch (e: Exception) { null }
