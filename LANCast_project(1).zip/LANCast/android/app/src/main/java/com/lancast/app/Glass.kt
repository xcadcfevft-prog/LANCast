package com.lancast.app

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.RuntimeShader
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.animation.ValueAnimator
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * 界面风格开关。默认 = 原来的「瞬流」扁平风格；liquid = 备用的「流光玻璃」风格。
 * 选择保存在 Link.prefs 的 ui_liquid 里，首页右上角「流光 / 默认」按钮（以及设置页第一张卡片）切换，切换后界面自动重建。
 * 两套风格共用同一套布局代码，只是 C / CC 里的配色和 shape() / circle() 画出来的底不同。
 */
object Theme {
    const val KEY = "ui_liquid"
    var liquid = false

    /** 流光风格下，状态栏 / 导航栏纯色要和极光底色的上下两端一致（极光上下各有一段渐变融入这两个颜色） */
    val BASE_TOP: Int = Color.parseColor("#090A20")
    val BASE_BOTTOM: Int = Color.parseColor("#0A0821")

    fun load(p: SharedPreferences) { liquid = p.getBoolean(KEY, false) }

    fun set(p: SharedPreferences, v: Boolean) {
        liquid = v
        p.edit().putBoolean(KEY, v).apply()
    }
}

internal fun mixColor(a: Int, b: Int, f: Float): Int = Color.argb(
    255,
    (Color.red(a) * (1f - f) + Color.red(b) * f).toInt(),
    (Color.green(a) * (1f - f) + Color.green(b) * f).toInt(),
    (Color.blue(a) * (1f - f) + Color.blue(b) * f).toInt()
)

internal fun withAlpha(c: Int, a: Float): Int =
    Color.argb((a * 255f).toInt().coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))

object Glass {
    /** 极光背景的低分辨率快照（供玻璃折射采样）。仅 Android 13+ 使用 */
    @Volatile var backdrop: Bitmap? = null
    var auroraW = 1f; var auroraH = 1f
    val auroraLoc = IntArray(2)
    var aurora: java.lang.ref.WeakReference<AuroraView>? = null
    private val live: MutableSet<GlassDrawable> = java.util.Collections.newSetFromMap(java.util.WeakHashMap())
    fun register(g: GlassDrawable) { live.add(g) }
    fun refresh() { for (g in live.toList()) g.invalidateSelf() }

    /**
     * Liquid Glass 折射着色器（AGSL）。清透玻璃，不再压暗：
     *  1. 边缘一圈「斜面」按圆角矩形 SDF 法线方向位移采样背景（凸透镜折射），三个通道位移量不同 → 色散彩边；
     *  2. 折射后再做轻微磨砂（4 点模糊，越靠中心越糊）、提饱和度、托起暗部（玻璃不是黑洞）；
     *  3. 打光：光从左上来，斜面上「迎光边」亮、「背光边」有一道弱的反弹光，同时背光侧斜面略暗 → 厚度感；
     *  4. inset=1 时（输入框）光照反向 + 压暗成凹陷；最后加极轻的抖动噪点消除暗部色带。
     */
    const val AGSL = """
uniform shader bg;
uniform float2 size;
uniform float2 origin;
uniform float2 scale;
uniform float radius;
uniform float bevel;
uniform float strength;
uniform float4 tintC;
uniform float lensK;
uniform float disp;
uniform float bright;
uniform float spec;
uniform float blurR;
uniform float sat;
uniform float inset;
float sdRound(float2 p, float2 hs, float r) {
    float2 q = abs(p) - (hs - float2(r));
    return length(max(q, 0.0)) + min(max(q.x, q.y), 0.0) - r;
}
float3 tap(float2 q) {
    return float3(bg.eval(q * scale).rgb);
}
half4 main(float2 fc) {
    float2 hs = size * 0.5;
    float2 p = fc - hs;
    float d = sdRound(p, hs, radius);
    float e = clamp(-d / bevel, 0.0, 1.0);
    float k = pow(1.0 - e, 2.4);
    float2 g = float2(sdRound(p + float2(1.0, 0.0), hs, radius) - sdRound(p - float2(1.0, 0.0), hs, radius),
                      sdRound(p + float2(0.0, 1.0), hs, radius) - sdRound(p - float2(0.0, 1.0), hs, radius));
    float2 n = g / max(length(g), 0.0001);
    float2 pos = origin + fc;
    float2 lens = (pos - (origin + hs)) * -lensK * strength;
    float amt = strength * bevel * 1.25;
    float2 o = lens - n * k * amt;
    float3 col = float3(tap(pos + o * (1.0 - disp)).r, tap(pos + o).g, tap(pos + o * (1.0 + disp)).b);
    float br = blurR * (0.4 + 0.6 * e);
    float3 bl = (tap(pos + o + float2(br, 0.0)) + tap(pos + o - float2(br, 0.0)) + tap(pos + o + float2(0.0, br)) + tap(pos + o - float2(0.0, br))) * 0.25;
    col = mix(col, bl, 0.6);
    float lum = dot(col, float3(0.299, 0.587, 0.114));
    col = mix(float3(lum), col, sat) * bright;
    col += float3(0.012, 0.016, 0.030);
    col += float3(0.030, 0.034, 0.055) * pow(clamp(1.0 - fc.y / size.y, 0.0, 1.0), 1.6);
    col = mix(col, float3(0.020, 0.028, 0.075), 0.42 * inset);
    col = mix(col, tintC.rgb, tintC.a);
    float2 L = float2(-0.55, -0.835);
    float nl = dot(n, L) * (1.0 - 2.0 * inset);
    float soft = pow(1.0 - e, 3.0);
    float lit = pow(max(nl, 0.0), 1.5) + 0.55 * pow(max(-nl, 0.0), 1.5);
    float fade = 1.0 - 0.6 * inset;
    col = mix(col, float3(0.88, 0.92, 1.0), 0.10 * soft * spec * fade);
    col += float3(0.80, 0.86, 1.0) * soft * (0.04 + 0.30 * lit) * spec * fade;
    col *= 1.0 - (0.14 + 0.08 * inset) * soft * clamp(0.5 - 0.5 * nl, 0.0, 1.0);
    col += (fract(sin(dot(fc, float2(12.9898, 78.233))) * 43758.5453) - 0.5) * 0.012;
    return half4(half3(clamp(col, 0.0, 1.0)), 1.0);
}
"""

    /** 磨砂颗粒：一小块随机白点（alpha 0~39）平铺，叠在玻璃上像蚀刻磨砂的细腻质感，也能打散渐变色带 */
    val grain: BitmapShader by lazy {
        val n = 96
        val px = IntArray(n * n)
        val rnd = java.util.Random(7L)
        for (i in px.indices) px[i] = Color.argb(rnd.nextInt(40), 255, 255, 255)
        BitmapShader(Bitmap.createBitmap(px, n, n, Bitmap.Config.ARGB_8888), Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
    }
    enum class Kind { SURFACE, SOFT, INSET, TINT }

    private val INSET_FILL = Color.parseColor("#FCFEFF")    // 设备名称输入框原来的底色

    /**
     * 流光风格下，原来要画成实心色块的几种「角色色」换成玻璃；其它颜色（深色悬浮条、警告底等）原样画。
     * 默认风格下永远返回 null，走原来的纯色圆角矩形。
     */
    internal fun kindOf(fill: Int, strokeDp: Float): Kind? {
        if (!Theme.liquid) return null
        if (fill == C.PRIMARY || fill == CC.BUBBLE || fill == CC.SEND) return Kind.TINT
        if (fill == CC.FIELD || fill == INSET_FILL) return Kind.INSET
        if (fill == Color.WHITE) return if (strokeDp > 0f) Kind.SURFACE else null
        val a = fill ushr 24
        if ((fill and 0xFFFFFF) == 0xFFFFFF && a in 0x30..0xFE) return if (a >= 0xB0) Kind.SURFACE else Kind.SOFT
        return null
    }
}

/**
 * 玻璃质感底（不依赖图片）。从下到上：半透明渐变底 → 底部折射光晕 → 顶部内缘高光 → 一圈带色散的边缘光
 * （左上亮白、偏青、中段几乎透明、偏暖、右下亮白）。没有塑料感的大块高光。
 * sheen=true 时（只给首页主按钮）每 6 秒有一道柔和的斜向光扫过，其余时间不重绘。
 */
class GlassDrawable(
    private val d: Float,
    private val kind: Glass.Kind,
    private val tint: Int,
    radiusDp: Float,
    private val round: Boolean,
    private val sheen: Boolean
) : Drawable(), Runnable {

    private val rad0 = radiusDp * d
    private var r = rad0
    private var alphaMul = 255
    private var rimW = 1f
    private var hiIn = 1f

    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG).apply { isDither = true }
    private val rimP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val hiP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val glowP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val loP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val glintP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pressP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val grainP = Paint().apply { shader = Glass.grain }
    private var rs: RuntimeShader? = null
    private val refrP = Paint(Paint.ANTI_ALIAS_FLAG)
    private var refrBmp: Bitmap? = null
    private val loc = IntArray(2)
    init { if (Build.VERSION.SDK_INT >= 33) Glass.register(this) }
    private var pAmt = 0f
    private var pSpread = 1f
    private var pX = 0f
    private var pY = 0f
    private var pAnim: ValueAnimator? = null
    private var pressR = 0f

    /** 手指按下：在触点处亮起一团柔光（像手指压进玻璃里）；松开后光向外扩散并淡出 */
    fun press(x: Float, y: Float) {
        pX = x + bounds.left; pY = y + bounds.top; pSpread = 1f
        pAnim?.cancel()
        pAnim = ValueAnimator.ofFloat(pAmt, 1f).apply {
            duration = 140
            addUpdateListener { pAmt = it.animatedValue as Float; invalidateSelf() }
            start()
        }
    }

    fun release() {
        pAnim?.cancel()
        val from = pAmt
        pAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 650
            interpolator = DecelerateInterpolator()
            addUpdateListener { val f = it.animatedFraction; pAmt = from * (1f - f); pSpread = 1f + 0.55f * f; invalidateSelf() }
            start()
        }
    }
    private val sheenP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val rimRect = RectF()
    private val hiRect = RectF()
    private val clip = Path()
    private var sheenW = 0f

    override fun onBoundsChange(b: android.graphics.Rect) {
        super.onBoundsChange(b)
        val w = b.width().toFloat()
        val h = b.height().toFloat()
        if (w <= 0f || h <= 0f) return
        val l = b.left.toFloat(); val t = b.top.toFloat(); val rr = b.right.toFloat(); val bb = b.bottom.toFloat()
        r = if (round) min(w, h) / 2f else min(rad0, min(w, h) / 2f)
        rimW = (if (kind == Glass.Kind.TINT) 1.0f else 1.1f) * d
        hiIn = rimW + 0.8f * d
        rect.set(l, t, rr, bb)
        rimRect.set(l + rimW / 2f, t + rimW / 2f, rr - rimW / 2f, bb - rimW / 2f)
        hiRect.set(l + hiIn, t + hiIn, rr - hiIn, bb - hiIn)
        hiP.strokeWidth = 1f * d
        rimP.strokeWidth = rimW
        clip.reset()
        clip.addRoundRect(rect, r, r, Path.Direction.CW)

        val white = Color.WHITE
        // 底
        // 底：几乎透明的冷白渐变（顶亮底淡）。有折射着色器时这层只当一层薄雾（强度由「磨砂雾面」决定），低版本则是玻璃本体
        val (top, bot) = when (kind) {
            Glass.Kind.SURFACE -> Pair(Color.argb(0x30, 238, 242, 255), Color.argb(0x10, 140, 150, 225))
            Glass.Kind.SOFT -> Pair(Color.argb(0x26, 238, 242, 255), Color.argb(0x0E, 140, 150, 225))
            Glass.Kind.INSET -> Pair(Color.argb(0x66, 2, 3, 16), Color.argb(0x2A, 120, 130, 220))
            Glass.Kind.TINT -> Pair(
                withAlpha(mixColor(tint, white, 0.25f), 0.68f),
                withAlpha(mixColor(tint, Color.rgb(8, 6, 40), 0.35f), 0.74f)
            )
        }
        fillP.shader = LinearGradient(0f, t, 0f, bb, top, bot, Shader.TileMode.CLAMP)

        // 边缘光：左上亮白 → 偏青 → 中段几乎透明 → 偏暖 → 右下亮白（更细、更克制，像真玻璃切边上的两道反光）
        val rimColors = if (kind == Glass.Kind.TINT)
            intArrayOf(Color.argb(0xCC, 255, 255, 255), Color.argb(0x66, 150, 190, 255), Color.argb(0x1E, 255, 255, 255), Color.argb(0x60, 255, 214, 170), Color.argb(0xA0, 255, 255, 255))
        else if (kind == Glass.Kind.INSET)
            intArrayOf(Color.argb(0x30, 255, 255, 255), Color.argb(0x28, 120, 170, 255), Color.argb(0x0C, 255, 255, 255), Color.argb(0x28, 255, 200, 160), Color.argb(0x80, 255, 255, 255))
        else
            intArrayOf(Color.argb(0xD8, 255, 255, 255), Color.argb(0x78, 120, 175, 255), Color.argb(0x12, 255, 255, 255), Color.argb(0x78, 255, 208, 160), Color.argb(0xC8, 255, 255, 255))
        rimP.shader = LinearGradient(l, t, rr, bb, rimColors, floatArrayOf(0f, 0.28f, 0.52f, 0.78f, 1f), Shader.TileMode.CLAMP)

        // 顶部内缘高光
        hiP.shader = LinearGradient(
            0f, t, 0f, t + h * 0.5f,
            Color.argb(if (kind == Glass.Kind.TINT) 0x55 else 0x98, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP
        )

        // 底部内缘折射光（玻璃厚度感：底边聚光，往上渐隐）
        loP.strokeWidth = 1.4f * d
        loP.shader = LinearGradient(
            0f, t + h * 0.55f, 0f, bb,
            Color.argb(0, 255, 255, 255), Color.argb(if (kind == Glass.Kind.TINT) 0x48 else 0x78, 255, 255, 255), Shader.TileMode.CLAMP
        )
        // 左上角柔和镜面反光（大范围、低强度，不做塑料感的硬高光）
        if (kind != Glass.Kind.INSET) {
            val gr = max(w, h) * 0.75f
            glintP.shader = RadialGradient(
                l + w * 0.12f, t - h * 0.1f, gr,
                Color.argb(if (kind == Glass.Kind.TINT) 0x34 else 0x3C, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP
            )
        }

        pressR = max(w, h) * 0.62f
        pressP.shader = RadialGradient(
            0f, 0f, pressR,
            Color.argb(if (kind == Glass.Kind.TINT) 0x80 else 0xB4, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP
        )

        // 内部光晕
        when (kind) {
            Glass.Kind.INSET ->           // 凹进去的感觉：顶部一点点内阴影
                glowP.shader = LinearGradient(0f, t, 0f, t + min(8f * d, h / 3f), Color.argb(0x50, 0, 0, 10), Color.argb(0, 0, 0, 10), Shader.TileMode.CLAMP)
            Glass.Kind.TINT ->
                glowP.shader = RadialGradient((l + rr) / 2f, bb, max(w * 0.7f, h), Color.argb(0x60, 150, 140, 255), Color.argb(0, 150, 140, 255), Shader.TileMode.CLAMP)
            else ->
                glowP.shader = RadialGradient((l + rr) / 2f, bb, max(w * 0.6f, h), Color.argb(0x30, 120, 140, 255), Color.argb(0, 120, 140, 255), Shader.TileMode.CLAMP)
        }

        if (Build.VERSION.SDK_INT >= 33) {
            // 着色器在设备上编译失败时不闪退，自动退回 Canvas 分层玻璃
            rs = try {
                RuntimeShader(Glass.AGSL).also {
                    it.setFloatUniform("size", w, h)
                    it.setFloatUniform("radius", r)
                }
            } catch (e: Throwable) { null }
            refrBmp = null
        }
        if (sheen) {
            sheenW = max(w * 0.30f, 36f * d)
            sheenP.shader = LinearGradient(
                -sheenW / 2f, 0f, sheenW / 2f, 0f,
                intArrayOf(Color.argb(0, 255, 255, 255), Color.argb(0x70, 255, 240, 222), Color.argb(0, 255, 255, 255)),
                floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
            )
        }
    }

    override fun draw(c: Canvas) {
        val b = bounds
        if (b.isEmpty || fillP.shader == null) return
        val a = alphaMul
        val sa = (a * GT.spec.v).toInt().coerceIn(0, 255)
        fillP.alpha = a; rimP.alpha = sa; hiP.alpha = sa; glowP.alpha = a; sheenP.alpha = a; loP.alpha = sa; glintP.alpha = sa

        val refr = drawRefraction(c)
        if (!refr) c.drawRoundRect(rect, r, r, fillP) else {
            val fm = when (kind) {
                Glass.Kind.INSET -> 0.6f
                Glass.Kind.TINT -> (GT.frost.v * 1.9f).coerceAtMost(1f)
                else -> GT.frost.v
            }
            fillP.alpha = (a * fm).toInt().coerceIn(0, 255)
            c.drawRoundRect(rect, r, r, fillP)
        }

        if (refr) {                       // 折射着色器已经负责打光，Canvas 上的大范围光晕只留 40%，否则玻璃会发白发雾
            glowP.alpha = (a * 0.4f).toInt(); glintP.alpha = (sa * 0.4f).toInt()
        }
        val sc = c.save()
        c.clipPath(clip)
        c.drawRect(rect, glowP)
        if (kind != Glass.Kind.INSET) c.drawRect(rect, glintP)
        grainP.alpha = (a * (if (kind == Glass.Kind.INSET) 0.20f else 0.30f)).toInt().coerceIn(0, 255)
        c.drawRect(rect, grainP)
        if (pAmt > 0.01f) {
            pressP.alpha = (pAmt * a).toInt().coerceIn(0, 255)
            c.save()
            c.translate(pX, pY)
            c.scale(pSpread, pSpread)
            c.drawCircle(0f, 0f, pressR, pressP)
            c.restore()
        }
        if (sheen) {
            val t = SystemClock.uptimeMillis() % CYCLE
            if (t < SWEEP) {
                val p = t.toFloat() / SWEEP
                val e = p * p * (3f - 2f * p)
                val w = rect.width()
                c.save()
                c.translate(rect.left + (-0.35f + 1.7f * e) * w, rect.centerY())
                c.rotate(16f)
                c.drawRect(-sheenW / 2f, -rect.height(), sheenW / 2f, rect.height(), sheenP)
                c.restore()
            }
        }
        c.restoreToCount(sc)

        if (kind != Glass.Kind.INSET) c.drawRoundRect(hiRect, max(r - hiIn, 0f), max(r - hiIn, 0f), hiP)
        if (kind != Glass.Kind.INSET) c.drawRoundRect(hiRect, max(r - hiIn, 0f), max(r - hiIn, 0f), loP)
        c.drawRoundRect(rimRect, max(r - rimW / 2f, 0f), max(r - rimW / 2f, 0f), rimP)
    }

    private fun drawRefraction(c: Canvas): Boolean {
        if (Build.VERSION.SDK_INT < 33) return false
        val shader = rs ?: return false
        val bmp = Glass.backdrop ?: return false
        val v = callback as? View ?: return false
        if (refrBmp !== bmp) {
            refrBmp = bmp
            shader.setInputShader("bg", BitmapShader(bmp, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP))
            shader.setFloatUniform("scale", bmp.width / Glass.auroraW, bmp.height / Glass.auroraH)
        }
        v.getLocationOnScreen(loc)
        val dd = v.resources.displayMetrics.density
        shader.setFloatUniform("bevel", min(GT.bevel.v * dd, min(bounds.width(), bounds.height()) / 2f))
        shader.setFloatUniform("strength", GT.strength.v * (when (kind) { Glass.Kind.INSET -> 0.35f; Glass.Kind.TINT -> 0.8f; else -> 1f }))
        shader.setFloatUniform("lensK", GT.lens.v)
        shader.setFloatUniform("disp", GT.disp.v)
        shader.setFloatUniform("bright", GT.bright.v)
        shader.setFloatUniform("spec", GT.spec.v)
        shader.setFloatUniform("blurR", GT.blur.v * 20f * dd)
        shader.setFloatUniform("sat", GT.sat.v)
        shader.setFloatUniform("inset", if (kind == Glass.Kind.INSET) 1f else 0f)
        if (kind == Glass.Kind.TINT) {   // 着色用压暗一点的主色，保证白色按钮文字的对比度
            val tc = mixColor(tint, Color.rgb(10, 8, 38), 0.38f)
            shader.setFloatUniform("tintC", Color.red(tc) / 255f, Color.green(tc) / 255f, Color.blue(tc) / 255f, GT.tint.v)
        }
        else shader.setFloatUniform("tintC", 0f, 0f, 0f, 0f)
        shader.setFloatUniform("origin", (loc[0] - Glass.auroraLoc[0]).toFloat() + bounds.left, (loc[1] - Glass.auroraLoc[1]).toFloat() + bounds.top)
        refrP.shader = shader
        refrP.alpha = alphaMul
        c.drawRoundRect(rect, r, r, refrP)
        return true
    }

    /* 光扫过时每帧刷新，其余时间睡到下一轮；不可见（页面隐藏 / 退到后台）时停掉 */
    override fun run() {
        invalidateSelf()
        val now = SystemClock.uptimeMillis()
        val t = now % CYCLE
        scheduleSelf(this, now + (if (t < SWEEP) 16L else CYCLE - t))
    }

    override fun setVisible(visible: Boolean, restart: Boolean): Boolean {
        val changed = super.setVisible(visible, restart)
        if (sheen) {
            if (visible) run() else unscheduleSelf(this)
        }
        return changed
    }

    override fun getOutline(outline: Outline) {
        outline.setRoundRect(bounds, r)
        outline.alpha = if (kind == Glass.Kind.TINT) 0.8f else 0.45f
    }

    override fun setAlpha(alpha: Int) { alphaMul = alpha; invalidateSelf() }
    override fun getAlpha(): Int = alphaMul
    override fun setColorFilter(cf: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT

    companion object {
        private const val CYCLE = 6000L
        private const val SWEEP = 1400L
    }
}

/**
 * 流光风格的背景：黑曜石深色底 + 五团叠加（SCREEN）发光的光斑（蓝宝石 / 紫水晶 / 翡翠青 / 玫瑰 / 香槟金）缓慢漂移，
 * 再有两道斜向「流光带」（冰蓝、香槟）从一侧缓缓扫到另一侧，最后压一层暗角让中心更通透。
 * 玻璃卡片叠在上面，透出的颜色和光带会随之流动。
 * 约 30 帧/秒；查看投屏画面时（active() 为 false）、退到后台、省电模式、系统关闭动画时都不动，只留静止的一帧。
 */
class AuroraView(ctx: Context, private val active: () -> Boolean) : View(ctx) {

    private class Blob(
        val color: Int, val a: Float, val rad: Float,
        val cx: Float, val cy: Float, val ax: Float, val ay: Float,
        val fx: Float, val fy: Float, val ph: Float
    ) {
        var shader: Shader? = null
        var r = 0f
    }

    /** 流光带：沿水平方向扫过整屏，周期 = 1 / speed 秒，两端淡入淡出 */
    private class Ribbon(
        val color: Int, val a: Float, val widthFrac: Float,
        val angle: Float, val speed: Float, val ph: Float
    ) {
        var shader: Shader? = null
        var bw = 0f
    }

    /** 丝绸：一条缓缓起伏的曲线，用 4 层由宽到窄的描边叠出柔和边缘的发光绸带；曲线本身提供可被玻璃折射弯曲的「结构」 */
    private class Silk(
        val color: Int, val a: Float, val wFrac: Float,
        val y0: Float, val amp: Float, val k: Float, val sp: Float, val ph: Float
    )

    // 深靛紫底上的宝石色光斑（蓝宝石 / 紫水晶 / 玫瑰 / 青 / 长春花蓝 / 香槟金），亮度克制，保证浅色文字对比度
    private val blobs = listOf(
        Blob(Color.parseColor("#3F5BFF"), 0.38f, 0.66f, 0.10f, 0.12f, 0.22f, 0.12f, 0.200f, 0.150f, 0.0f),   // 蓝宝石
        Blob(Color.parseColor("#9B5CFF"), 0.32f, 0.60f, 0.90f, 0.80f, 0.14f, 0.12f, 0.180f, 0.150f, 4.4f),   // 紫水晶
        Blob(Color.parseColor("#E04C92"), 0.16f, 0.48f, 0.94f, 0.30f, 0.14f, 0.14f, 0.170f, 0.220f, 1.7f),   // 玫瑰
        Blob(Color.parseColor("#17B7CE"), 0.22f, 0.56f, 0.06f, 0.66f, 0.18f, 0.12f, 0.150f, 0.190f, 3.1f),   // 青
        Blob(Color.parseColor("#7E78FF"), 0.16f, 0.42f, 0.46f, 0.38f, 0.20f, 0.14f, 0.120f, 0.160f, 2.4f),   // 长春花蓝
        Blob(Color.parseColor("#F0B67A"), 0.09f, 0.34f, 0.60f, 0.62f, 0.22f, 0.14f, 0.220f, 0.170f, 5.6f)    // 香槟金
    )
    private val silks = listOf(
        Silk(Color.parseColor("#9A8CFF"), 0.24f, 0.20f, 0.30f, 0.07f, 1.3f, 0.32f, 0.4f),
        Silk(Color.parseColor("#5FA8FF"), 0.19f, 0.16f, 0.66f, 0.06f, 1.7f, -0.26f, 2.2f),
        Silk(Color.parseColor("#FF9AD0"), 0.09f, 0.10f, 0.50f, 0.05f, 2.1f, 0.20f, 4.1f)
    )
    private val ribbons = listOf(
        Ribbon(Color.parseColor("#86AAFF"), 0.12f, 0.30f, 24f, 0.045f, 0.10f),   // 冰蓝
        Ribbon(Color.parseColor("#FFD9A8"), 0.07f, 0.18f, 18f, 0.030f, 0.62f),   // 香槟
        Ribbon(Color.parseColor("#B8A8FF"), 0.22f, 0.055f, 32f, 0.052f, 0.35f),  // 细光丝（被玻璃边缘折射时最明显）
        Ribbon(Color.parseColor("#9FE3FF"), 0.17f, 0.040f, 14f, 0.037f, 0.80f)
    )
    private val silkW = floatArrayOf(1f, 0.86f, 0.72f, 0.58f, 0.44f, 0.30f, 0.16f)   // 7 层由宽到窄，台阶足够细，看不出等高线
    private val silkPath = Path()
    private val silkPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        xfermode = android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.SCREEN)
    }
    private val edgePaint = Paint().apply { isDither = true }
    private val basePaint = Paint().apply { isDither = true }
    private val blobPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        isDither = true
        xfermode = android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.SCREEN)
    }
    private val ribbonPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        isDither = true
        xfermode = android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.SCREEN)
    }
    private val vigPaint = Paint().apply { isDither = true }
    private val t0 = SystemClock.uptimeMillis()
    private val animScale = try {
        Settings.Global.getFloat(ctx.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f)
    } catch (e: Exception) { 1f }
    private val pm = ctx.getSystemService(Context.POWER_SERVICE) as? PowerManager

    init { isClickable = false; isFocusable = false }

    private fun animating(): Boolean = animScale > 0f && pm?.isPowerSaveMode != true && active()

    private val tick = object : Runnable {
        override fun run() {
            if (!isAttachedToWindow) return
            if (animating()) { invalidate(); postDelayed(this, 33L) } else postDelayed(this, 500L)
        }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); snapBusy = false; Glass.aurora = java.lang.ref.WeakReference(this); removeCallbacks(tick); post(tick) }
    override fun onDetachedFromWindow() {
        removeCallbacks(tick)
        snapThread?.quitSafely(); snapThread = null; snapH = null; snapBusy = false
        super.onDetachedFromWindow()
    }
    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        removeCallbacks(tick)
        if (visibility == VISIBLE) post(tick)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        if (w <= 0 || h <= 0) return
        basePaint.shader = LinearGradient(
            0f, 0f, 0f, h.toFloat(),
            intArrayOf(Theme.BASE_TOP, Color.parseColor("#15103A"), Theme.BASE_BOTTOM),
            floatArrayOf(0f, 0.46f, 1f), Shader.TileMode.CLAMP
        )
        vigPaint.shader = RadialGradient(
            w / 2f, h * 0.42f, max(w, h) * 0.80f,
            intArrayOf(0x00000000, 0x00000000, Color.argb(0x78, 2, 3, 12)),
            floatArrayOf(0f, 0.52f, 1f), Shader.TileMode.CLAMP
        )
        topFade = LinearGradient(0f, 0f, 0f, h * 0.11f, Theme.BASE_TOP, withAlpha(Theme.BASE_TOP, 0f), Shader.TileMode.CLAMP)
        botFade = LinearGradient(0f, h * 0.90f, 0f, h.toFloat(), withAlpha(Theme.BASE_BOTTOM, 0f), Theme.BASE_BOTTOM, Shader.TileMode.CLAMP)
        rebuild()
    }

    fun rebuild() {
        val w = width; val h = height
        if (w <= 0 || h <= 0) return
        val big = max(w, h).toFloat()
        val am = GT.aurora.v
        for (b in blobs) {
            b.r = b.rad * big
            b.shader = RadialGradient(
                0f, 0f, b.r,
                intArrayOf(withAlpha(b.color, (b.a * am).coerceAtMost(1f)), withAlpha(b.color, (b.a * am * 0.42f).coerceAtMost(1f)), withAlpha(b.color, 0f)),
                floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
            )
        }
        for (rb in ribbons) {
            rb.bw = rb.widthFrac * big
            val a = (rb.a * am).coerceAtMost(1f)
            rb.shader = LinearGradient(
                -rb.bw / 2f, 0f, rb.bw / 2f, 0f,
                intArrayOf(withAlpha(rb.color, 0f), withAlpha(rb.color, a * 0.45f), withAlpha(rb.color, a), withAlpha(rb.color, a * 0.45f), withAlpha(rb.color, 0f)),
                floatArrayOf(0f, 0.30f, 0.5f, 0.70f, 1f), Shader.TileMode.CLAMP
            )
        }
    }

    /** 一次绘制用到的全套画笔 / 路径。快照在后台线程画，必须用各自的拷贝，不能和 onDraw 共用同一批可变对象。 */
    private class Pens(val base: Paint, val blob: Paint, val silk: Paint, val ribbon: Paint, val edge: Paint, val vig: Paint, val path: Path)
    private val livePens by lazy { Pens(basePaint, blobPaint, silkPaint, ribbonPaint, edgePaint, vigPaint, silkPath) }

    /*
     * 玻璃折射用的背景快照。两个问题都出在这里：
     *  1. 以前在 UI 线程里把整幅流光用软件画布重画一遍（每 200ms 一次）→ 周期性掉帧、玻璃区域卡顿；
     *  2. 以前每次都在「同一块」位图上原地重画，而渲染线程同时在读它 → 读到画了一半的位图，玻璃卡片上半部分黑闪一帧。
     * 现在：放到后台线程画；三块位图轮换，画完才交出去，已经交给渲染线程的位图绝不再改动。
     */
    private val snapBufs = arrayOfNulls<Bitmap>(3)
    private var snapIdx = 0
    @Volatile private var snapBusy = false
    private var snapThread: HandlerThread? = null
    private var snapH: Handler? = null
    private val mainH = Handler(Looper.getMainLooper())
    private var lastSnap = 0L

    private fun requestSnap() {
        if (Build.VERSION.SDK_INT < 33 || snapBusy) return
        val w = width; val h = height
        if (w <= 0 || h <= 0) return
        val sw = (w / 4).coerceAtLeast(8); val sh = (h / 4).coerceAtLeast(8)
        val k = snapIdx; snapIdx = (snapIdx + 1) % snapBufs.size
        val old = snapBufs[k]
        val bmp = if (old != null && old.width == sw && old.height == sh) old
                  else Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888).also { snapBufs[k] = it }
        val pens = Pens(Paint(basePaint), Paint(blobPaint), Paint(silkPaint), Paint(ribbonPaint), Paint(edgePaint), Paint(vigPaint), Path())
        var hd = snapH
        if (hd == null) {
            val t = HandlerThread("aurora-snap")
            t.start(); snapThread = t; hd = Handler(t.looper); snapH = hd
        }
        snapBusy = true
        lastSnap = SystemClock.uptimeMillis()
        hd.post {
            try {
                val c = Canvas(bmp)
                c.save(); c.scale(sw.toFloat() / w, sh.toFloat() / h)
                paintAll(c, pens, w.toFloat(), h.toFloat())
                c.restore()
                mainH.post { publish(bmp, w, h) }
            } catch (e: Throwable) { snapBusy = false }
        }
    }

    private fun publish(b: Bitmap, w: Int, h: Int) {
        snapBusy = false
        if (!isAttachedToWindow || width != w || height != h) return      // 期间尺寸变了 / 已离开窗口：这一张作废，下一次 onDraw 会重新要
        getLocationOnScreen(Glass.auroraLoc)
        Glass.auroraW = w.toFloat(); Glass.auroraH = h.toFloat()
        Glass.backdrop = b
        Glass.refresh()
    }

    fun snapNow() { lastSnap = 0L; requestSnap() }

    override fun onDraw(c: Canvas) {
        paintAll(c, livePens, width.toFloat(), height.toFloat())
        if (Build.VERSION.SDK_INT >= 33 && (Glass.backdrop == null || SystemClock.uptimeMillis() - lastSnap > SNAP_MS)) requestSnap()
    }

    private fun paintAll(c: Canvas, pens: Pens, w: Float, h: Float) {
        val basePaint = pens.base; val blobPaint = pens.blob; val silkPaint = pens.silk
        val ribbonPaint = pens.ribbon; val edgePaint = pens.edge; val vigPaint = pens.vig; val silkPath = pens.path
        c.drawRect(0f, 0f, w, h, basePaint)
        val t = if (animScale > 0f) (SystemClock.uptimeMillis() - t0) / 1000f else 0f
        for (b in blobs) {
            val sh = b.shader ?: continue
            val x = (b.cx + b.ax * sin(t * b.fx + b.ph)) * w
            val y = (b.cy + b.ay * cos(t * b.fy + b.ph * 1.3f)) * h
            blobPaint.shader = sh
            c.save()
            c.translate(x, y)
            c.drawCircle(0f, 0f, b.r, blobPaint)
            c.restore()
        }
        val big = max(w, h)
        val amul = GT.aurora.v
        val tau = (2.0 * Math.PI).toFloat()
        for (s in silks) {
            val n = 12
            silkPath.reset()
            var lx = 0f; var ly = 0f
            for (i in 0..n) {
                val fx = i / n.toFloat()
                val x = (-0.1f + 1.2f * fx) * w
                val y = (s.y0 + s.amp * (sin(s.k * tau * fx + t * s.sp + s.ph) + 0.45f * sin(s.k * 1.9f * tau * fx - t * s.sp * 1.3f + s.ph))) * h
                if (i == 0) silkPath.moveTo(x, y) else silkPath.quadTo(lx, ly, (lx + x) / 2f, (ly + y) / 2f)
                lx = x; ly = y
            }
            silkPath.lineTo(lx, ly)
            for (j in silkW.indices) {
                silkPaint.color = withAlpha(s.color, (s.a * amul * 0.15f).coerceAtMost(1f))
                silkPaint.strokeWidth = s.wFrac * big * silkW[j]
                c.drawPath(silkPath, silkPaint)
            }
        }
        for (rb in ribbons) {
            val sh = rb.shader ?: continue
            val frac = (t * rb.speed + rb.ph) % 1f
            val env = sin(Math.PI.toFloat() * frac)
            ribbonPaint.shader = sh
            ribbonPaint.alpha = (255f * env * env.coerceAtLeast(0f)).toInt().coerceIn(0, 255)
            c.save()
            c.translate(w * (-0.25f + 1.5f * frac), h * 0.5f)
            c.rotate(rb.angle)
            c.drawRect(-rb.bw / 2f, -big, rb.bw / 2f, big, ribbonPaint)
            c.restore()
        }
        c.drawRect(0f, 0f, w, h, vigPaint)
        // 顶 / 底各一段渐变融入状态栏 / 导航栏的纯色，避免出现色带
        edgePaint.shader = topFade
        c.drawRect(0f, 0f, w, h * 0.11f, edgePaint)
        edgePaint.shader = botFade
        c.drawRect(0f, h * 0.90f, w, h, edgePaint)
    }

    private var topFade: Shader? = null
    private var botFade: Shader? = null

    private companion object { const val SNAP_MS = 100L }      // 玻璃背景快照间隔（后台线程画，不占 UI 线程）
}

/**
 * 流动的按压手感（只在流光风格下生效）：按下时整个控件被「压进去」一点点（越大的控件压得越浅），
 * 触点处亮起柔光；松开时带一点回弹弹回原位，光向外散开淡出。不拦截触摸，原有点击 / 长按照常工作。
 */
object Fluid {
    fun touch(v: View, ev: MotionEvent) {
        if (!Theme.liquid) return
        val d = v.resources.displayMetrics.density
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val amt = (14f * d / max(max(v.width, v.height), 1)).coerceIn(0.012f, 0.05f)
                v.animate().cancel()
                v.animate().scaleX(1f - amt).scaleY(1f - amt).setDuration(130).setInterpolator(DecelerateInterpolator()).start()
                (v.background as? GlassDrawable)?.press(ev.x, ev.y)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                v.animate().cancel()
                v.animate().scaleX(1f).scaleY(1f).setDuration(480).setInterpolator(OvershootInterpolator(2.6f)).start()
                (v.background as? GlassDrawable)?.release()
            }
        }
    }

    /** 给已经设置过点击的控件加上流动手感 */
    fun on(v: View) {
        v.setOnTouchListener { view, ev -> touch(view, ev); false }
    }

    /** 页面切换：新页面从下方轻轻浮起并淡入 */
    fun enter(v: View) {
        if (!Theme.liquid) return
        val d = v.resources.displayMetrics.density
        v.alpha = 0f
        v.translationY = 14f * d
        v.animate().alpha(1f).translationY(0f).setDuration(380).setInterpolator(DecelerateInterpolator(1.8f)).start()
    }
}

fun View.fluid() = Fluid.on(this)
