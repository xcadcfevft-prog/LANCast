package com.lancast.app

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.animation.ValueAnimator
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * 界面风格开关。默认 = 原来的「瞬流」扁平风格；liquid = 备用的「流光玻璃」风格。
 * 选择保存在 Link.prefs 的 ui_liquid 里，首页右上角「流光 / 默认」按钮（以及设置页第一张卡片）切换，切换后界面自动重建。
 * 两套风格共用同一套布局代码，只是 C / CC 里的配色和 shape() / circle() 画出来的底不同。
 */
object Theme {
    const val KEY = "ui_liquid"
    var liquid = false

    /** 流光风格下，状态栏 / 导航栏纯色要和极光底色的上下两端一致 */
    val BASE_TOP: Int = Color.parseColor("#ECEEFB")
    val BASE_BOTTOM: Int = Color.parseColor("#F9EFEA")

    fun load(p: SharedPreferences) { liquid = p.getBoolean(KEY, false) }

    fun set(p: SharedPreferences, v: Boolean) {
        liquid = v
        p.edit().putBoolean(KEY, v).apply()
    }
}

internal fun mixColor(a: Int, b: Int, f: Float): Int = Color.argb(
    255,
    (Color.red(a) * (1f - f) + Color.red(b) * f).toInt(),
    (Color.green(a) * (1f - f) + Color.green(b) * f).toInt(),
    (Color.blue(a) * (1f - f) + Color.blue(b) * f).toInt()
)

internal fun withAlpha(c: Int, a: Float): Int =
    Color.argb((a * 255f).toInt().coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))

object Glass {
    enum class Kind { SURFACE, SOFT, INSET, TINT }

    private val INSET_FILL = Color.parseColor("#FCFEFF")    // 设备名称输入框原来的底色

    /**
     * 流光风格下，原来要画成实心色块的几种「角色色」换成玻璃；其它颜色（深色悬浮条、警告底等）原样画。
     * 默认风格下永远返回 null，走原来的纯色圆角矩形。
     */
    internal fun kindOf(fill: Int, strokeDp: Float): Kind? {
        if (!Theme.liquid) return null
        if (fill == C.PRIMARY || fill == CC.BUBBLE || fill == CC.SEND) return Kind.TINT
        if (fill == CC.FIELD || fill == INSET_FILL) return Kind.INSET
        if (fill == Color.WHITE) return if (strokeDp > 0f) Kind.SURFACE else null
        val a = fill ushr 24
        if ((fill and 0xFFFFFF) == 0xFFFFFF && a in 0x30..0xFE) return if (a >= 0xB0) Kind.SURFACE else Kind.SOFT
        return null
    }
}

/**
 * 玻璃质感底（不依赖图片）。从下到上：半透明渐变底 → 底部折射光晕 → 顶部内缘高光 → 一圈带色散的边缘光
 * （左上亮白、偏青、中段几乎透明、偏暖、右下亮白）。没有塑料感的大块高光。
 * sheen=true 时（只给首页主按钮）每 6 秒有一道柔和的斜向光扫过，其余时间不重绘。
 */
class GlassDrawable(
    private val d: Float,
    private val kind: Glass.Kind,
    private val tint: Int,
    radiusDp: Float,
    private val round: Boolean,
    private val sheen: Boolean
) : Drawable(), Runnable {

    private val rad0 = radiusDp * d
    private var r = rad0
    private var alphaMul = 255
    private var rimW = 1f
    private var hiIn = 1f

    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG).apply { isDither = true }
    private val rimP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val hiP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val glowP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val loP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val glintP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pressP = Paint(Paint.ANTI_ALIAS_FLAG)
    private var pAmt = 0f
    private var pSpread = 1f
    private var pX = 0f
    private var pY = 0f
    private var pAnim: ValueAnimator? = null
    private var pressR = 0f

    /** 手指按下：在触点处亮起一团柔光（像手指压进玻璃里）；松开后光向外扩散并淡出 */
    fun press(x: Float, y: Float) {
        pX = x + bounds.left; pY = y + bounds.top; pSpread = 1f
        pAnim?.cancel()
        pAnim = ValueAnimator.ofFloat(pAmt, 1f).apply {
            duration = 140
            addUpdateListener { pAmt = it.animatedValue as Float; invalidateSelf() }
            start()
        }
    }

    fun release() {
        pAnim?.cancel()
        val from = pAmt
        pAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 650
            interpolator = DecelerateInterpolator()
            addUpdateListener { val f = it.animatedFraction; pAmt = from * (1f - f); pSpread = 1f + 0.55f * f; invalidateSelf() }
            start()
        }
    }
    private val sheenP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private val rimRect = RectF()
    private val hiRect = RectF()
    private val clip = Path()
    private var sheenW = 0f

    override fun onBoundsChange(b: android.graphics.Rect) {
        super.onBoundsChange(b)
        val w = b.width().toFloat()
        val h = b.height().toFloat()
        if (w <= 0f || h <= 0f) return
        val l = b.left.toFloat(); val t = b.top.toFloat(); val rr = b.right.toFloat(); val bb = b.bottom.toFloat()
        r = if (round) min(w, h) / 2f else min(rad0, min(w, h) / 2f)
        rimW = (if (kind == Glass.Kind.TINT) 1.1f else 1.3f) * d
        hiIn = rimW + 0.8f * d
        rect.set(l, t, rr, bb)
        rimRect.set(l + rimW / 2f, t + rimW / 2f, rr - rimW / 2f, bb - rimW / 2f)
        hiRect.set(l + hiIn, t + hiIn, rr - hiIn, bb - hiIn)
        hiP.strokeWidth = 1f * d
        rimP.strokeWidth = rimW
        clip.reset()
        clip.addRoundRect(rect, r, r, Path.Direction.CW)

        val white = Color.WHITE
        // 底
        val (top, bot) = when (kind) {
            Glass.Kind.SURFACE -> Pair(Color.argb(0x8C, 255, 255, 255), Color.argb(0x4A, 244, 249, 255))
            Glass.Kind.SOFT -> Pair(Color.argb(0x78, 255, 255, 255), Color.argb(0x3A, 238, 246, 255))
            Glass.Kind.INSET -> Pair(Color.argb(0x70, 250, 252, 255), Color.argb(0x94, 255, 255, 255))
            Glass.Kind.TINT -> Pair(
                withAlpha(mixColor(tint, white, 0.22f), 0.96f),
                withAlpha(mixColor(tint, Color.BLACK, 0.10f), 0.97f)
            )
        }
        fillP.shader = LinearGradient(0f, t, 0f, bb, top, bot, Shader.TileMode.CLAMP)

        // 边缘光
        val rimColors = if (kind == Glass.Kind.TINT)
            intArrayOf(Color.argb(0xCC, 255, 255, 255), Color.argb(0x55, 170, 215, 255), Color.argb(0x22, 255, 255, 255), Color.argb(0x55, 255, 205, 190), Color.argb(0x99, 255, 255, 255))
        else if (kind == Glass.Kind.INSET)
            intArrayOf(Color.argb(0x66, 255, 255, 255), Color.argb(0x30, 150, 200, 255), Color.argb(0x18, 255, 255, 255), Color.argb(0x30, 255, 190, 170), Color.argb(0xCC, 255, 255, 255))
        else
            intArrayOf(Color.argb(0xF2, 255, 255, 255), Color.argb(0x8C, 150, 225, 255), Color.argb(0x1F, 255, 255, 255), Color.argb(0x8C, 255, 190, 170), Color.argb(0xE0, 255, 255, 255))
        rimP.shader = LinearGradient(l, t, rr, bb, rimColors, floatArrayOf(0f, 0.28f, 0.52f, 0.78f, 1f), Shader.TileMode.CLAMP)

        // 顶部内缘高光
        hiP.shader = LinearGradient(
            0f, t, 0f, t + h * 0.5f,
            Color.argb(if (kind == Glass.Kind.TINT) 0x66 else 0xB0, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP
        )

        // 底部内缘折射光（玻璃厚度感：底边聚光，往上渐隐）
        loP.strokeWidth = 1.4f * d
        loP.shader = LinearGradient(
            0f, t + h * 0.55f, 0f, bb,
            Color.argb(0, 255, 255, 255), Color.argb(if (kind == Glass.Kind.TINT) 0x55 else 0x8C, 255, 255, 255), Shader.TileMode.CLAMP
        )
        // 左上角柔和镜面反光（大范围、低强度，不做塑料感的硬高光）
        if (kind != Glass.Kind.INSET) {
            val gr = max(w, h) * 0.75f
            glintP.shader = RadialGradient(
                l + w * 0.12f, t - h * 0.1f, gr,
                Color.argb(if (kind == Glass.Kind.TINT) 0x40 else 0x55, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP
            )
        }

        pressR = max(w, h) * 0.62f
        pressP.shader = RadialGradient(
            0f, 0f, pressR,
            Color.argb(if (kind == Glass.Kind.TINT) 0x80 else 0xB4, 255, 255, 255), Color.argb(0, 255, 255, 255), Shader.TileMode.CLAMP
        )

        // 内部光晕
        when (kind) {
            Glass.Kind.INSET ->           // 凹进去的感觉：顶部一点点内阴影
                glowP.shader = LinearGradient(0f, t, 0f, t + min(8f * d, h / 3f), Color.argb(0x16, 20, 40, 90), Color.argb(0, 20, 40, 90), Shader.TileMode.CLAMP)
            Glass.Kind.TINT ->
                glowP.shader = RadialGradient((l + rr) / 2f, bb, max(w * 0.7f, h), Color.argb(0x5A, 175, 170, 255), Color.argb(0, 175, 170, 255), Shader.TileMode.CLAMP)
            else ->
                glowP.shader = RadialGradient((l + rr) / 2f, bb, max(w * 0.6f, h), Color.argb(0x40, 170, 165, 255), Color.argb(0, 170, 165, 255), Shader.TileMode.CLAMP)
        }

        if (sheen) {
            sheenW = max(w * 0.30f, 36f * d)
            sheenP.shader = LinearGradient(
                -sheenW / 2f, 0f, sheenW / 2f, 0f,
                intArrayOf(Color.argb(0, 255, 255, 255), Color.argb(0x5C, 255, 255, 255), Color.argb(0, 255, 255, 255)),
                floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
            )
        }
    }

    override fun draw(c: Canvas) {
        val b = bounds
        if (b.isEmpty || fillP.shader == null) return
        val a = alphaMul
        fillP.alpha = a; rimP.alpha = a; hiP.alpha = a; glowP.alpha = a; sheenP.alpha = a; loP.alpha = a; glintP.alpha = a

        c.drawRoundRect(rect, r, r, fillP)

        val sc = c.save()
        c.clipPath(clip)
        c.drawRect(rect, glowP)
        if (kind != Glass.Kind.INSET) c.drawRect(rect, glintP)
        if (pAmt > 0.01f) {
            pressP.alpha = (pAmt * a).toInt().coerceIn(0, 255)
            c.save()
            c.translate(pX, pY)
            c.scale(pSpread, pSpread)
            c.drawCircle(0f, 0f, pressR, pressP)
            c.restore()
        }
        if (sheen) {
            val t = SystemClock.uptimeMillis() % CYCLE
            if (t < SWEEP) {
                val p = t.toFloat() / SWEEP
                val e = p * p * (3f - 2f * p)
                val w = rect.width()
                c.save()
                c.translate(rect.left + (-0.35f + 1.7f * e) * w, rect.centerY())
                c.rotate(16f)
                c.drawRect(-sheenW / 2f, -rect.height(), sheenW / 2f, rect.height(), sheenP)
                c.restore()
            }
        }
        c.restoreToCount(sc)

        if (kind != Glass.Kind.INSET) c.drawRoundRect(hiRect, max(r - hiIn, 0f), max(r - hiIn, 0f), hiP)
        if (kind != Glass.Kind.INSET) c.drawRoundRect(hiRect, max(r - hiIn, 0f), max(r - hiIn, 0f), loP)
        c.drawRoundRect(rimRect, max(r - rimW / 2f, 0f), max(r - rimW / 2f, 0f), rimP)
    }

    /* 光扫过时每帧刷新，其余时间睡到下一轮；不可见（页面隐藏 / 退到后台）时停掉 */
    override fun run() {
        invalidateSelf()
        val now = SystemClock.uptimeMillis()
        val t = now % CYCLE
        scheduleSelf(this, now + (if (t < SWEEP) 16L else CYCLE - t))
    }

    override fun setVisible(visible: Boolean, restart: Boolean): Boolean {
        val changed = super.setVisible(visible, restart)
        if (sheen) {
            if (visible) run() else unscheduleSelf(this)
        }
        return changed
    }

    override fun getOutline(outline: Outline) {
        outline.setRoundRect(bounds, r)
        outline.alpha = if (kind == Glass.Kind.TINT) 0.8f else 0.45f
    }

    override fun setAlpha(alpha: Int) { alphaMul = alpha; invalidateSelf() }
    override fun getAlpha(): Int = alphaMul
    override fun setColorFilter(cf: ColorFilter?) {}
    @Suppress("OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT

    companion object {
        private const val CYCLE = 6000L
        private const val SWEEP = 1400L
    }
}

/**
 * 流光风格的背景：浅色底上几团柔和的彩色光斑（靛蓝 / 暖橘 / 青绿 / 淡紫 / 玫瑰）沿各自的轨道缓慢漂移，
 * 周期 40～70 秒；玻璃卡片叠在上面，透出的颜色会随之缓缓变化。
 * 约 30 帧/秒；查看投屏画面时（active() 为 false）、退到后台、省电模式、系统关闭动画时都不动，只留静止的一帧。
 */
class AuroraView(ctx: Context, private val active: () -> Boolean) : View(ctx) {

    private class Blob(
        val color: Int, val a: Float, val rad: Float,
        val cx: Float, val cy: Float, val ax: Float, val ay: Float,
        val fx: Float, val fy: Float, val ph: Float
    ) {
        var shader: Shader? = null
        var r = 0f
    }

    private val blobs = listOf(
        Blob(Color.parseColor("#4F5BFF"), 0.70f, 0.62f, 0.12f, 0.14f, 0.22f, 0.12f, 0.200f, 0.150f, 0.0f),   // 钴蓝
        Blob(Color.parseColor("#FF7A59"), 0.60f, 0.52f, 0.92f, 0.32f, 0.14f, 0.14f, 0.170f, 0.220f, 1.7f),   // 珊瑚橘
        Blob(Color.parseColor("#2FD3CC"), 0.56f, 0.60f, 0.08f, 0.64f, 0.18f, 0.12f, 0.150f, 0.190f, 3.1f),   // 电光青
        Blob(Color.parseColor("#B24DFF"), 0.62f, 0.58f, 0.88f, 0.80f, 0.14f, 0.12f, 0.180f, 0.150f, 4.4f),   // 紫罗兰
        Blob(Color.parseColor("#FFC46B"), 0.38f, 0.40f, 0.50f, 0.46f, 0.24f, 0.16f, 0.220f, 0.170f, 5.6f)    // 香槟金
    )
    private val basePaint = Paint().apply { isDither = true }
    private val blobPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { isDither = true }
    private val t0 = SystemClock.uptimeMillis()
    private val animScale = try {
        Settings.Global.getFloat(ctx.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f)
    } catch (e: Exception) { 1f }
    private val pm = ctx.getSystemService(Context.POWER_SERVICE) as? PowerManager

    init { isClickable = false; isFocusable = false }

    private fun animating(): Boolean = animScale > 0f && pm?.isPowerSaveMode != true && active()

    private val tick = object : Runnable {
        override fun run() {
            if (!isAttachedToWindow) return
            if (animating()) { invalidate(); postDelayed(this, 33L) } else postDelayed(this, 500L)
        }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); removeCallbacks(tick); post(tick) }
    override fun onDetachedFromWindow() { removeCallbacks(tick); super.onDetachedFromWindow() }
    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        removeCallbacks(tick)
        if (visibility == VISIBLE) post(tick)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        if (w <= 0 || h <= 0) return
        basePaint.shader = LinearGradient(0f, 0f, 0f, h.toFloat(), Theme.BASE_TOP, Theme.BASE_BOTTOM, Shader.TileMode.CLAMP)
        val big = max(w, h).toFloat()
        for (b in blobs) {
            b.r = b.rad * big
            b.shader = RadialGradient(
                0f, 0f, b.r,
                intArrayOf(withAlpha(b.color, b.a), withAlpha(b.color, b.a * 0.45f), withAlpha(b.color, 0f)),
                floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
            )
        }
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawRect(0f, 0f, w, h, basePaint)
        val t = if (animScale > 0f) (SystemClock.uptimeMillis() - t0) / 1000f else 0f
        for (b in blobs) {
            val sh = b.shader ?: continue
            val x = (b.cx + b.ax * sin(t * b.fx + b.ph)) * w
            val y = (b.cy + b.ay * cos(t * b.fy + b.ph * 1.3f)) * h
            blobPaint.shader = sh
            c.save()
            c.translate(x, y)
            c.drawCircle(0f, 0f, b.r, blobPaint)
            c.restore()
        }
    }
}

/**
 * 流动的按压手感（只在流光风格下生效）：按下时整个控件被「压进去」一点点（越大的控件压得越浅），
 * 触点处亮起柔光；松开时带一点回弹弹回原位，光向外散开淡出。不拦截触摸，原有点击 / 长按照常工作。
 */
object Fluid {
    fun touch(v: View, ev: MotionEvent) {
        if (!Theme.liquid) return
        val d = v.resources.displayMetrics.density
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val amt = (14f * d / max(max(v.width, v.height), 1)).coerceIn(0.012f, 0.05f)
                v.animate().cancel()
                v.animate().scaleX(1f - amt).scaleY(1f - amt).setDuration(130).setInterpolator(DecelerateInterpolator()).start()
                (v.background as? GlassDrawable)?.press(ev.x, ev.y)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                v.animate().cancel()
                v.animate().scaleX(1f).scaleY(1f).setDuration(480).setInterpolator(OvershootInterpolator(2.6f)).start()
                (v.background as? GlassDrawable)?.release()
            }
        }
    }

    /** 给已经设置过点击的控件加上流动手感 */
    fun on(v: View) {
        v.setOnTouchListener { view, ev -> touch(view, ev); false }
    }

    /** 页面切换：新页面从下方轻轻浮起并淡入 */
    fun enter(v: View) {
        if (!Theme.liquid) return
        val d = v.resources.displayMetrics.density
        v.alpha = 0f
        v.translationY = 14f * d
        v.animate().alpha(1f).translationY(0f).setDuration(380).setInterpolator(DecelerateInterpolator(1.8f)).start()
    }
}

fun View.fluid() = Fluid.on(this)
