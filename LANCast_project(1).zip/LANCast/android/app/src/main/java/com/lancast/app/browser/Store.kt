package com.lancast.app.browser

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** 书签与历史记录（SharedPreferences + JSON，主线程访问）。 */
object Store {
    class Entry(val title: String, val url: String, val time: Long)

    private lateinit var sp: android.content.SharedPreferences
    private var inited = false
    private val marks = ArrayList<Entry>()     // 新的在前
    private val hist = ArrayList<Entry>()      // 新的在前

    private const val MAX_HISTORY = 500

    fun init(ctx: Context) {
        if (inited) return
        inited = true
        sp = ctx.applicationContext.getSharedPreferences("browser_store", Context.MODE_PRIVATE)
        read("marks", marks)
        read("hist", hist)
        if (!sp.getBoolean("seeded", false)) {
            // 首次启动放几个常用站点，起始页不至于空着
            val seeds = listOf(
                "哔哩哔哩" to "https://m.bilibili.com",
                "知乎" to "https://www.zhihu.com",
                "微博" to "https://m.weibo.cn",
                "YouTube" to "https://m.youtube.com",
                "GitHub" to "https://github.com",
                "维基百科" to "https://zh.wikipedia.org",
                "豆瓣" to "https://m.douban.com",
                "淘宝" to "https://m.taobao.com"
            )
            val now = System.currentTimeMillis()
            seeds.forEachIndexed { i, p -> marks.add(Entry(p.first, p.second, now - i)) }
            sp.edit().putBoolean("seeded", true).apply()
            write("marks", marks)
        }
    }

    private fun read(key: String, out: ArrayList<Entry>) {
        val s = sp.getString(key, null) ?: return
        try {
            val a = JSONArray(s)
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out.add(Entry(o.optString("t"), o.getString("u"), o.optLong("ts")))
            }
        } catch (e: Exception) {
            out.clear()
        }
    }

    private fun write(key: String, list: List<Entry>) {
        val a = JSONArray()
        for (e in list) a.put(JSONObject().put("t", e.title).put("u", e.url).put("ts", e.time))
        sp.edit().putString(key, a.toString()).apply()
    }

    /** 去掉末尾斜杠和 #片段，让「同一个页面」判断更宽松。 */
    private fun norm(u: String) = u.substringBefore('#').trimEnd('/')

    fun bookmarks(): List<Entry> = ArrayList(marks)
    fun history(): List<Entry> = ArrayList(hist)

    fun isBookmarked(url: String?): Boolean = url != null && marks.any { norm(it.url) == norm(url) }

    /** 返回 true 表示现在已加入书签，false 表示已取消。 */
    fun toggleBookmark(title: String, url: String): Boolean {
        val i = marks.indexOfFirst { norm(it.url) == norm(url) }
        val added: Boolean
        if (i >= 0) {
            marks.removeAt(i)
            added = false
        } else {
            marks.add(0, Entry(title.ifBlank { url }, url, System.currentTimeMillis()))
            added = true
        }
        write("marks", marks)
        return added
    }

    fun removeBookmark(url: String) {
        marks.removeAll { it.url == url }
        write("marks", marks)
    }

    fun addHistory(title: String, url: String) {
        if (!url.startsWith("http")) return
        val now = System.currentTimeMillis()
        val first = hist.firstOrNull()
        if (first != null && norm(first.url) == norm(url)) {
            hist[0] = Entry(title.ifBlank { first.title }, url, now)
        } else {
            hist.add(0, Entry(title.ifBlank { url }, url, now))
            while (hist.size > MAX_HISTORY) hist.removeAt(hist.size - 1)
        }
        write("hist", hist)
    }

    fun removeHistory(e: Entry) {
        hist.remove(e)
        write("hist", hist)
    }

    fun clearHistory() {
        hist.clear()
        write("hist", hist)
    }

    /** 地址栏输入时的建议：书签优先，其次历史，按标题 / 网址包含关键字匹配，去重。 */
    fun suggest(q: String, limit: Int = 6): List<Entry> {
        val k = q.trim().lowercase()
        if (k.isEmpty()) return emptyList()
        val seen = HashSet<String>()
        val out = ArrayList<Entry>()
        for (e in marks + hist) {
            if (out.size >= limit) break
            if ((e.title.lowercase().contains(k) || e.url.lowercase().contains(k)) && seen.add(norm(e.url))) out.add(e)
        }
        return out
    }
}
