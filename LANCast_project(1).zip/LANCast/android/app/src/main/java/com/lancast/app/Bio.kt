package com.lancast.app

import android.content.Context

/**
 * 主页介绍：用户自己写的一小段文字，互联（已配对且聊天连接建立）后对方可以看到。
 * 本机介绍存 SharedPreferences 的 bio_mine；对方的介绍缓存在 pbio_<设备ID>。
 * 同步：聊天握手完成后以及本机修改后，发送 {t:"bio", x:"…"}（空串 = 没有介绍），对方直接覆盖缓存。
 */
object Bio {
    const val MAX_CHARS = 200

    private fun safeId(id: String) = id.filter { it.isLetterOrDigit() || it == '_' || it == '-' }.take(64)

    fun mine(): String = Link.prefs.getString("bio_mine", "") ?: ""

    /** 保存本机介绍并通知所有已连上的对方；返回清理后的文本 */
    fun setMine(text: String): String {
        val t = ChatCrypto.clip(text.trim(), MAX_CHARS)
        Link.prefs.edit().putString("bio_mine", t).apply()
        Thread {
            try { ChatNet.start(); ChatNet.hub.announceBio() } catch (ignored: Exception) { }
        }.start()
        return t
    }

    fun peer(id: String): String = Link.prefs.getString("pbio_" + safeId(id), "") ?: ""

    fun peerSave(id: String, text: String) {
        val e = Link.prefs.edit()
        if (text.isBlank()) e.remove("pbio_" + safeId(id)) else e.putString("pbio_" + safeId(id), ChatCrypto.clip(text.trim(), MAX_CHARS))
        e.apply()
    }
}
