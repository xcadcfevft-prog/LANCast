package com.lancast.app

import android.annotation.SuppressLint
import android.content.Context
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.projection.MediaProjection
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Display
import android.view.Surface
import android.view.TextureView
import android.graphics.SurfaceTexture
import org.json.JSONObject
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import kotlin.concurrent.thread
import kotlin.math.max
import kotlin.math.min

/** 画质预设：码率 = 像素 × 帧率 × bpp，夹在 [minBps, maxBps]；maxLong 是长边像素上限。 */
data class Preset(val label: String, val bpp: Double, val maxBps: Int, val minBps: Int, val maxLong: Int)

val PRESETS = listOf(
    Preset("视觉无损（高码率）", 0.30, 100_000_000, 10_000_000, 3200),
    Preset("均衡", 0.16, 50_000_000, 6_000_000, 2400),
    Preset("省流畅", 0.08, 25_000_000, 4_000_000, 1600)
)

/* ═══════════════════════════ 发送端：手机屏幕 + 系统声音 → 对方 ═══════════════════════════ */
class ScreenSource(
    private val ctx: Context,
    private val projection: MediaProjection,
    private val session: Session,
    private val preset: Preset,
    private val withAudio: Boolean,
    private val onEnded: (String) -> Unit
) : SessionHandler {

    private val main = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    @Volatile private var codec: MediaCodec? = null
    private var vd: VirtualDisplay? = null
    @Volatile private var gen = 0
    private var w = 0
    private var h = 0
    private var dpi = 320
    private val fps = 60
    @Volatile private var bitrate = 0
    private var targetBps = 0
    @Volatile private var csd: ByteArray? = null
    @Volatile private var lastCong = 0L
    private var rec: AudioRecord? = null
    private var dispListener: DisplayManager.DisplayListener? = null

    private val recoverTick = object : Runnable {
        override fun run() {
            if (!running) return
            if (SystemClock.elapsedRealtime() - lastCong > 4000 && bitrate < targetBps) {
                bitrate = min(targetBps, (bitrate * 1.12).toInt())
                session.maxBacklog = max(300_000, (bitrate / 8 * 0.15).toInt())
                applyBitrate()
            }
            main.postDelayed(this, 3000)
        }
    }

    fun start() {
        running = true
        projection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stop("投屏被系统停止")
            }
        }, main)
        computeSize()
        recomputeBitrate()
        session.onCongestion = { onCongestion() }
        session.start(this)
        startEncoder()
        if (withAudio) startAudio()
        val dm = ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val l = object : DisplayManager.DisplayListener {
            override fun onDisplayAdded(displayId: Int) {}
            override fun onDisplayRemoved(displayId: Int) {}
            override fun onDisplayChanged(displayId: Int) {
                if (displayId == Display.DEFAULT_DISPLAY) checkResize()
            }
        }
        dispListener = l
        dm.registerDisplayListener(l, main)
        main.postDelayed(recoverTick, 3000)
    }

    /* ---------- 尺寸 / 码率 ---------- */
    @Suppress("DEPRECATION")
    private fun realMetrics(): DisplayMetrics {
        val dm = ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val m = DisplayMetrics()
        dm.getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(m)
        return m
    }

    private fun align(v: Int): Int = max(16, v and 7.inv())

    private fun computeSize() {
        val m = realMetrics()
        dpi = m.densityDpi
        val s = min(1.0, preset.maxLong.toDouble() / max(m.widthPixels, m.heightPixels))
        w = align((m.widthPixels * s).toInt())
        h = align((m.heightPixels * s).toInt())
    }

    private fun recomputeBitrate() {
        val b = (w.toLong() * h * fps * preset.bpp).toLong().coerceIn(preset.minBps.toLong(), preset.maxBps.toLong())
        targetBps = b.toInt()
        bitrate = targetBps
        session.maxBacklog = max(300_000, (bitrate / 8 * 0.15).toInt())
    }

    private fun avcLevel(): Int {
        val mbps = ((w + 15) / 16) * ((h + 15) / 16) * fps
        return when {
            mbps <= 245760 -> MediaCodecInfo.CodecProfileLevel.AVCLevel4
            mbps <= 522240 -> MediaCodecInfo.CodecProfileLevel.AVCLevel42
            mbps <= 589824 -> MediaCodecInfo.CodecProfileLevel.AVCLevel5
            mbps <= 983040 -> MediaCodecInfo.CodecProfileLevel.AVCLevel51
            else -> MediaCodecInfo.CodecProfileLevel.AVCLevel52
        }
    }

    /* ---------- 编码器 ---------- */
    private fun buildFormat(withProfile: Boolean): MediaFormat {
        val f = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h)
        f.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
        f.setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
        f.setInteger(MediaFormat.KEY_FRAME_RATE, fps)
        f.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
        f.setInteger(MediaFormat.KEY_BITRATE_MODE, MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_CBR)
        f.setLong(MediaFormat.KEY_REPEAT_PREVIOUS_FRAME_AFTER, 100_000L)   // 画面静止时每 100ms 重复上一帧：保证新连接/关键帧请求不会等不到画面（防黑屏）
        f.setInteger(MediaFormat.KEY_PRIORITY, 0)                          // 实时
        f.setInteger(MediaFormat.KEY_MAX_B_FRAMES, 0)                      // 不用 B 帧 → 低延迟
        f.setInteger("max-fps-to-encoder", fps)                            // 120Hz 屏幕也只喂 60 帧
        if (Build.VERSION.SDK_INT >= 30) f.setInteger(MediaFormat.KEY_LATENCY, 1)
        f.setInteger(MediaFormat.KEY_COLOR_STANDARD, MediaFormat.COLOR_STANDARD_BT709)   // 颜色标签明确写成 BT.709，避免偏色
        f.setInteger(MediaFormat.KEY_COLOR_RANGE, MediaFormat.COLOR_RANGE_LIMITED)
        f.setInteger(MediaFormat.KEY_COLOR_TRANSFER, MediaFormat.COLOR_TRANSFER_SDR_VIDEO)
        if (withProfile) {
            f.setInteger(MediaFormat.KEY_PROFILE, MediaCodecInfo.CodecProfileLevel.AVCProfileHigh)
            f.setInteger(MediaFormat.KEY_LEVEL, avcLevel())
        }
        return f
    }

    private fun startEncoder() {
        var attempt = 0
        while (true) {
            val c = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            try {
                c.configure(buildFormat(attempt == 0), null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                val surf = c.createInputSurface()
                c.start()
                attach(c, surf)
                return
            } catch (e: Exception) {
                try { c.release() } catch (ignored: Exception) { }
                attempt++
                if (attempt >= 4) throw e
                if (attempt >= 2) {                         // 设备不支持这个分辨率：缩小 25% 再试
                    w = align(w * 3 / 4)
                    h = align(h * 3 / 4)
                    recomputeBitrate()
                }
            }
        }
    }

    private fun attach(c: MediaCodec, surf: Surface) {
        codec = c
        csd = null
        val myGen = ++gen
        val d = vd
        if (d == null) {
            vd = projection.createVirtualDisplay(
                "LANCast", w, h, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, surf, null, null
            )
        } else {
            d.resize(w, h, dpi)
            d.surface = surf
        }
        session.resetVideo()
        session.sendHi(P.jsonPkt(P.T_VCONFIG, JSONObject().put("codec", "h264").put("width", w).put("height", h).put("fps", fps)))
        thread(name = "enc-drain", isDaemon = true) { drain(c, myGen) }
    }

    private fun drain(c: MediaCodec, myGen: Int) {
        val info = MediaCodec.BufferInfo()
        try {
            while (running && gen == myGen) {
                val i = c.dequeueOutputBuffer(info, 100_000)
                if (i < 0) continue
                val buf = c.getOutputBuffer(i)
                if (buf != null && info.size > 0) {
                    buf.position(info.offset)
                    buf.limit(info.offset + info.size)
                    if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) {
                        val cs = ByteArray(info.size)
                        buf.get(cs)
                        csd = cs
                    } else {
                        val key = info.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME != 0
                        val cs = if (key) csd else null
                        val extra = cs?.size ?: 0
                        val pkt = P.newPkt(P.T_VFRAME, if (key) 1 else 0, info.presentationTimeUs, extra + info.size)
                        if (cs != null) System.arraycopy(cs, 0, pkt, P.HDR, extra)   // 每个关键帧前都带 SPS/PPS，接收端随时能从关键帧起步
                        buf.get(pkt, P.HDR + extra, info.size)
                        session.sendVideo(pkt, key)
                    }
                }
                c.releaseOutputBuffer(i, false)
            }
        } catch (e: Exception) {
            if (running && gen == myGen) main.post { stop("编码器错误: ${e.message}") }
        }
    }

    fun requestKey() {
        try {
            codec?.setParameters(Bundle().apply { putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0) })
        } catch (ignored: Exception) { }
    }

    private fun applyBitrate() {
        try {
            codec?.setParameters(Bundle().apply { putInt(MediaCodec.PARAMETER_KEY_VIDEO_BITRATE, bitrate) })
        } catch (ignored: Exception) { }
    }

    /** 网络拥塞：码率降 25% 并请求新关键帧；网络恢复后 recoverTick 每 3 秒回升 12%。 */
    private fun onCongestion() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastCong < 800) return
        lastCong = now
        bitrate = max(preset.minBps, (bitrate * 0.75).toInt())
        session.maxBacklog = max(300_000, (bitrate / 8 * 0.15).toInt())
        applyBitrate()
        requestKey()
    }

    /** 旋转屏幕/折叠屏切换：重建编码器与虚拟显示，并通知对方新的分辨率。 */
    private fun checkResize() {
        if (!running) return
        val m = realMetrics()
        val s = min(1.0, preset.maxLong.toDouble() / max(m.widthPixels, m.heightPixels))
        val nw = align((m.widthPixels * s).toInt())
        val nh = align((m.heightPixels * s).toInt())
        if (nw == w && nh == h) return
        w = nw
        h = nh
        dpi = m.densityDpi
        recomputeBitrate()
        gen++
        val old = codec
        codec = null
        try { old?.stop() } catch (ignored: Exception) { }
        try { old?.release() } catch (ignored: Exception) { }
        try {
            startEncoder()
        } catch (e: Exception) {
            stop("旋转后无法重建编码器: ${e.message}")
        }
    }

    /* ---------- 音频：系统播放声音的原始 PCM（无损） ---------- */
    @SuppressLint("MissingPermission")
    private fun startAudio() {
        try {
            val cfg = AudioPlaybackCaptureConfiguration.Builder(projection)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()
            val fmt = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(48000)
                .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                .build()
            val minBuf = AudioRecord.getMinBufferSize(48000, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
            val r = AudioRecord.Builder()
                .setAudioFormat(fmt)
                .setBufferSizeInBytes(max(minBuf * 2, 48000 / 10 * 4))
                .setAudioPlaybackCaptureConfig(cfg)
                .build()
            r.startRecording()
            rec = r
            session.sendHi(P.jsonPkt(P.T_ACONFIG, JSONObject().put("rate", 48000).put("ch", 2).put("fmt", "s16")))
            thread(name = "audio-cap", isDaemon = true) {
                val chunk = 48000 / 50 * 4                         // 20ms
                try {
                    while (running) {
                        val pkt = P.newPkt(P.T_ADATA, 0, System.nanoTime() / 1000, chunk)
                        val n = r.read(pkt, P.HDR, chunk, AudioRecord.READ_BLOCKING)
                        if (n <= 0) break
                        if (n < chunk) {
                            val p2 = pkt.copyOf(P.HDR + n)
                            ByteBuffer.wrap(p2).putInt(4, n)
                            session.sendHi(p2)
                        } else session.sendHi(pkt)
                    }
                } catch (ignored: Exception) { }
            }
        } catch (e: Exception) {
            Link.status("无法采集手机声音（只投画面）: ${e.message}")
        }
    }

    /* ---------- 会话回调 ---------- */
    private var ctlErrSent = false

    override fun onPacket(s: Session, p: Pkt) {
        if (p.type == P.T_INPUT) {                      // 屏幕控制：必须是本机用户同意过的会话
            if (!s.ctlAllowed || p.payload.size > 16 * 1024) return
            try {
                if (!InputService.handle(p.json()) && !ctlErrSent) {
                    ctlErrSent = true
                    s.sendCtrl(JSONObject().put("cmd", "ctl_err").put("reason", "no_service"))
                }
            } catch (ignored: Exception) { }
            return
        }
        if (p.type != P.T_CTRL) return
        try {
            when (p.json().optString("cmd")) {
                "keyframe" -> requestKey()
                "stop" -> main.post { stop("对方结束了投屏") }
            }
        } catch (ignored: Exception) { }
    }

    override fun onClosed(s: Session, reason: String) {
        main.post { stop(reason) }
    }

    @Synchronized
    fun stop(reason: String) {
        if (!running) return
        running = false
        InputService.reset()                            // 会话结束：松开对方还按着的「手指」
        main.removeCallbacks(recoverTick)
        try {
            val l = dispListener
            if (l != null) (ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).unregisterDisplayListener(l)
        } catch (ignored: Exception) { }
        try { rec?.stop() } catch (ignored: Exception) { }
        try { rec?.release() } catch (ignored: Exception) { }
        gen++
        try { codec?.stop() } catch (ignored: Exception) { }
        try { codec?.release() } catch (ignored: Exception) { }
        codec = null
        try { vd?.release() } catch (ignored: Exception) { }
        try { projection.stop() } catch (ignored: Exception) { }
        session.close(reason)
        onEnded(reason)
    }
}

/* ═══════════════════════════ 接收端：对方画面 → TextureView ═══════════════════════════ */
class ScreenSink(
    private val session: Session,
    private val tv: TextureView,
    private val onVideoSize: (Int, Int) -> Unit,
    private val onEnded: (String) -> Unit,
    private val onStats: (String) -> Unit
) : SessionHandler, TextureView.SurfaceTextureListener {

    private val main = Handler(Looper.getMainLooper())
    private val decLock = Any()
    @Volatile private var dec: MediaCodec? = null
    private var decSurface: Surface? = null
    @Volatile private var waitKey = true
    @Volatile private var surfaceReady = false
    @Volatile private var stopped = false
    private var vw = 0
    private var vh = 0
    private val rxBytes = AtomicLong(0)
    private val rxFrames = AtomicInteger(0)
    private var lastStatT = SystemClock.elapsedRealtime()
    private val player = PcmPlayer()

    private val statsTick = object : Runnable {
        override fun run() {
            if (stopped) return
            val now = SystemClock.elapsedRealtime()
            val dt = max(1L, now - lastStatT) / 1000.0
            lastStatT = now
            val fps = rxFrames.getAndSet(0) / dt
            val mbps = rxBytes.getAndSet(0) * 8 / dt / 1e6
            onStats("%.0f fps   %.1f Mbps   往返 %d ms   %dx%d".format(fps, mbps, session.rttMs, vw, vh))
            main.postDelayed(this, 1000)
        }
    }

    fun start() {
        tv.surfaceTextureListener = this
        if (tv.isAvailable) surfaceReady = true
        session.start(this)
        main.postDelayed(statsTick, 1000)
    }

    /* ---------- 解码 ---------- */
    private fun requestKey() {
        waitKey = true
        session.sendCtrl(JSONObject().put("cmd", "keyframe"))
    }

    private fun resetDecoder() {
        synchronized(decLock) {
            releaseDecoder()
            val st = tv.surfaceTexture
            if (vw <= 0 || !surfaceReady || st == null) return
            val surf = Surface(st)
            var d: MediaCodec? = null
            for (full in booleanArrayOf(true, false)) {          // 先带低延迟参数，不行就退回最小配置
                try {
                    val f = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, vw, vh)
                    f.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 2 * 1024 * 1024)
                    if (full) {
                        f.setInteger(MediaFormat.KEY_PRIORITY, 0)
                        f.setInteger(MediaFormat.KEY_OPERATING_RATE, Short.MAX_VALUE.toInt())
                        if (Build.VERSION.SDK_INT >= 30) f.setInteger(MediaFormat.KEY_LOW_LATENCY, 1)
                        f.setInteger("vendor.qti-ext-dec-low-latency.enable", 1)
                    }
                    val c = MediaCodec.createDecoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
                    try {
                        c.configure(f, surf, null, 0)
                        c.start()
                        d = c
                    } catch (e: Exception) {
                        try { c.release() } catch (ignored: Exception) { }
                        throw e
                    }
                    break
                } catch (e: Exception) {
                    d = null
                }
            }
            if (d == null) {
                try { surf.release() } catch (ignored: Exception) { }
                Link.status("解码器初始化失败")
                return
            }
            dec = d
            decSurface = surf
            val c2: MediaCodec = d
            thread(name = "dec-out", isDaemon = true) { outLoop(c2) }
            requestKey()
        }
    }

    private fun releaseDecoder() {
        val d = dec
        dec = null
        try { d?.stop() } catch (ignored: Exception) { }
        try { d?.release() } catch (ignored: Exception) { }
        try { decSurface?.release() } catch (ignored: Exception) { }
        decSurface = null
    }

    private fun outLoop(d: MediaCodec) {
        val info = MediaCodec.BufferInfo()
        try {
            while (dec === d) {
                val i = d.dequeueOutputBuffer(info, 50_000)
                if (i >= 0) d.releaseOutputBuffer(i, true)       // 解出来立刻上屏，不排队
            }
        } catch (ignored: Exception) { }
    }

    private fun feed(p: Pkt) {
        val key = p.flags and 1 != 0
        synchronized(decLock) {
            val d = dec ?: return
            if (waitKey && !key) return                           // 没拿到关键帧之前不喂解码器 → 不会花屏
            try {
                val idx = d.dequeueInputBuffer(20_000)
                if (idx < 0) {                                    // 解码器吃不下：丢到下一个关键帧
                    requestKey()
                    return
                }
                val ib = d.getInputBuffer(idx)
                if (ib == null || ib.capacity() < p.payload.size) {
                    d.queueInputBuffer(idx, 0, 0, 0, 0)
                    requestKey()
                    return
                }
                ib.clear()
                ib.put(p.payload)
                d.queueInputBuffer(idx, 0, p.payload.size, p.pts, 0)
                if (key) waitKey = false
                rxFrames.incrementAndGet()
            } catch (e: Exception) {
                resetDecoder()
            }
        }
    }

    /* ---------- 会话回调 ---------- */
    override fun onPacket(s: Session, p: Pkt) {
        try {
            when (p.type) {
                P.T_VCONFIG -> {
                    val j = p.json()
                    vw = j.getInt("width")
                    vh = j.getInt("height")
                    main.post { onVideoSize(vw, vh) }
                    resetDecoder()
                }
                P.T_VFRAME -> {
                    rxBytes.addAndGet(p.payload.size.toLong())
                    feed(p)
                }
                P.T_ACONFIG -> {
                    val j = p.json()
                    player.config(j.getInt("rate"), j.getInt("ch"), j.optString("fmt", "s16"))
                }
                P.T_ADATA -> player.push(p.payload)
                P.T_CTRL -> when (p.json().optString("cmd")) {
                    "stop" -> main.post { stop("对方结束了投屏") }
                    "ctl_err" -> main.post { android.widget.Toast.makeText(Link.app, "对方还没开启「屏幕控制」服务，暂时只能查看", android.widget.Toast.LENGTH_LONG).show() }
                }
            }
        } catch (e: Exception) {
            Link.status("数据处理出错: ${e.message}")
        }
    }

    override fun onClosed(s: Session, reason: String) {
        main.post { stop(reason) }
    }

    fun stop(reason: String) {
        if (stopped) return
        stopped = true
        main.removeCallbacks(statsTick)
        try { session.sendCtrl(JSONObject().put("cmd", "stop")) } catch (ignored: Exception) { }
        main.postDelayed({ session.close(reason) }, 200)
        synchronized(decLock) { releaseDecoder() }
        player.stop()
        tv.surfaceTextureListener = null
        onEnded(reason)
    }

    override fun onSurfaceTextureAvailable(st: SurfaceTexture, width: Int, height: Int) {
        surfaceReady = true
        if (vw > 0) resetDecoder()
    }

    override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, width: Int, height: Int) {}

    override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
        surfaceReady = false
        synchronized(decLock) { releaseDecoder() }
        return true
    }

    override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
}

/* ═══════════════════════════ 无损 PCM 播放 ═══════════════════════════ */
class PcmPlayer {
    private var track: AudioTrack? = null
    private var worker: Thread? = null
    private val q = LinkedBlockingQueue<ByteArray>()
    private val queued = AtomicInteger(0)
    @Volatile private var running = false
    private var bps = 192000                        // 每秒字节数
    private var isFloat = false

    @Synchronized
    fun config(rate: Int, ch: Int, fmt: String) {
        stop()
        isFloat = fmt == "f32"
        bps = rate * ch * (if (isFloat) 4 else 2)
        val enc = if (isFloat) AudioFormat.ENCODING_PCM_FLOAT else AudioFormat.ENCODING_PCM_16BIT
        val mask = if (ch == 1) AudioFormat.CHANNEL_OUT_MONO else AudioFormat.CHANNEL_OUT_STEREO
        val minBuf = AudioTrack.getMinBufferSize(rate, mask, enc)
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE)
                    .build()
            )
            .setAudioFormat(AudioFormat.Builder().setEncoding(enc).setSampleRate(rate).setChannelMask(mask).build())
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setBufferSizeInBytes(max(minBuf, (bps * 0.04).toInt()))
            .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
            .build()
        track = t
        running = true
        worker = thread(name = "pcm-out", isDaemon = true) { loop(t) }
    }

    private fun loop(t: AudioTrack) {
        try {
            while (running && queued.get() < bps * 0.04) Thread.sleep(5)      // 预缓冲 40ms，吸收网络抖动
            t.play()
            while (running) {
                val b = q.poll(100, TimeUnit.MILLISECONDS) ?: continue
                queued.addAndGet(-b.size)
                if (isFloat) {
                    val fa = FloatArray(b.size / 4)
                    ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN).asFloatBuffer().get(fa)
                    t.write(fa, 0, fa.size, AudioTrack.WRITE_BLOCKING)
                } else {
                    t.write(b, 0, b.size)
                }
            }
        } catch (ignored: Exception) { }
    }

    fun push(b: ByteArray) {
        if (!running) return
        q.offer(b)
        if (queued.addAndGet(b.size) > bps * 0.2) {              // 积压超过 200ms：丢最旧的，把延迟拉回 80ms
            while (queued.get() > bps * 0.08) {
                val x = q.poll() ?: break
                queued.addAndGet(-x.size)
            }
        }
    }

    @Synchronized
    fun stop() {
        running = false
        val t = track
        track = null
        try { t?.stop() } catch (ignored: Exception) { }
        try { t?.release() } catch (ignored: Exception) { }
        q.clear()
        queued.set(0)
    }
}
