package com.lancast.app

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.ImageReader
import android.media.MediaFormat
import android.media.projection.MediaProjection
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.Display
import android.view.Surface
import android.view.TextureView
import android.graphics.SurfaceTexture
import org.json.JSONObject
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import kotlin.concurrent.thread
import kotlin.math.max
import kotlin.math.min

/**
 * 画质预设：码率 = 像素 × 帧率 × bpp，夹在 [minBps, maxBps]；maxLong 是长边像素上限。
 * lossless = 「极致无损」：不走 H.264，原生分辨率、源帧率、原始像素差异块 + DEFLATE（见 Lossless.kt），码率不设上限。
 */
data class Preset(
    val label: String, val bpp: Double, val maxBps: Int, val minBps: Int, val maxLong: Int,
    val lossless: Boolean = false, val beta: Boolean = false, val desc: String = ""
)

const val EXTREME_DESC = "该模式为极致模式，对设备性能和网速要求极高，易出现黑屏、卡顿等问题，按需开启！"

val PRESETS = listOf(
    Preset("视觉无损（高码率）", 0.30, 100_000_000, 10_000_000, 3200),
    Preset("均衡", 0.16, 50_000_000, 6_000_000, 2400),
    Preset("省流畅", 0.08, 25_000_000, 4_000_000, 1600),
    Preset("极致无损 Beta", 0.0, 0, 0, Int.MAX_VALUE, lossless = true, beta = true, desc = EXTREME_DESC)
)

/** 极致无损：发送队列里压着超过这个字节数，说明网络还没写完上一帧，这一帧整帧丢弃（不动参考画面，差异链不会断） */
private const val LL_QUEUE_MAX = 128 * 1024

/* ═══════════════════════════ 发送端：手机屏幕 + 系统声音 → 对方 ═══════════════════════════ */
class ScreenSource(
    private val ctx: Context,
    private val projection: MediaProjection,
    private val session: Session,
    private val preset: Preset,
    private val withAudio: Boolean,
    private val onEnded: (String) -> Unit
) : SessionHandler {

    private val main = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    @Volatile private var codec: MediaCodec? = null
    private var vd: VirtualDisplay? = null
    @Volatile private var gen = 0
    private var w = 0
    private var h = 0
    private var dpi = 320
    private val fps = 60
    @Volatile private var bitrate = 0
    private var targetBps = 0
    @Volatile private var csd: ByteArray? = null
    @Volatile private var lastCong = 0L
    private var rec: AudioRecord? = null
    private var dispListener: DisplayManager.DisplayListener? = null

    /* ---- 极致无损（只在 llHandler 那一个线程上读写，requestKey 等外部调用都 post 过去） ---- */
    private val lossless = preset.lossless
    private var llReader: ImageReader? = null
    private var llThread: HandlerThread? = null
    private var llHandler: Handler? = null
    private var llPool: ExecutorService? = null
    private var llCur = IntArray(0)
    private var llPrev: IntArray? = null
    @Volatile private var llFull = true
    private var llNudges = 0

    private val recoverTick = object : Runnable {
        override fun run() {
            if (!running) return
            if (SystemClock.elapsedRealtime() - lastCong > 4000 && bitrate < targetBps) {
                bitrate = min(targetBps, (bitrate * 1.12).toInt())
                session.maxBacklog = max(300_000, (bitrate / 8 * 0.15).toInt())
                applyBitrate()
            }
            main.postDelayed(this, 3000)
        }
    }

    fun start() {
        running = true
        projection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stop("投屏被系统停止")
            }
        }, main)
        computeSize()
        if (!lossless) {
            recomputeBitrate()
            session.onCongestion = { onCongestion() }
        }
        InputService.onNoFocus = {
            val now = SystemClock.elapsedRealtime()
            if (now - lastNoFocus > 3000L) {
                lastNoFocus = now
                session.sendCtrl(JSONObject().put("cmd", "ctl_err").put("reason", "no_focus"))
            }
        }
        session.start(this)
        if (lossless) {
            session.tuneForBulk()
            startLossless()
        } else startEncoder()
        if (withAudio) startAudio()
        val dm = ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val l = object : DisplayManager.DisplayListener {
            override fun onDisplayAdded(displayId: Int) {}
            override fun onDisplayRemoved(displayId: Int) {}
            override fun onDisplayChanged(displayId: Int) {
                if (displayId == Display.DEFAULT_DISPLAY) checkResize()
            }
        }
        dispListener = l
        dm.registerDisplayListener(l, main)
        if (!lossless) main.postDelayed(recoverTick, 3000)
    }

    /* ---------- 尺寸 / 码率 ---------- */
    @Suppress("DEPRECATION")
    private fun realMetrics(): DisplayMetrics {
        val dm = ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        val m = DisplayMetrics()
        dm.getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(m)
        return m
    }

    private fun align(v: Int): Int = max(16, v and 7.inv())

    /** 采集尺寸。极致无损永远是屏幕的原生分辨率（不缩放、不对齐）；H.264 档按上限缩放并对齐到 8 */
    private fun targetSize(m: DisplayMetrics): IntArray {
        if (lossless) return intArrayOf(m.widthPixels, m.heightPixels)
        val s = min(1.0, preset.maxLong.toDouble() / max(m.widthPixels, m.heightPixels))
        return intArrayOf(align((m.widthPixels * s).toInt()), align((m.heightPixels * s).toInt()))
    }

    private fun computeSize() {
        val m = realMetrics()
        dpi = m.densityDpi
        val t = targetSize(m)
        w = t[0]
        h = t[1]
    }

    private fun recomputeBitrate() {
        val b = (w.toLong() * h * fps * preset.bpp).toLong().coerceIn(preset.minBps.toLong(), preset.maxBps.toLong())
        targetBps = b.toInt()
        bitrate = targetBps
        session.maxBacklog = max(300_000, (bitrate / 8 * 0.15).toInt())
    }

    private fun avcLevel(): Int {
        val mbps = ((w + 15) / 16) * ((h + 15) / 16) * fps
        return when {
            mbps <= 245760 -> MediaCodecInfo.CodecProfileLevel.AVCLevel4
            mbps <= 522240 -> MediaCodecInfo.CodecProfileLevel.AVCLevel42
            mbps <= 589824 -> MediaCodecInfo.CodecProfileLevel.AVCLevel5
            mbps <= 983040 -> MediaCodecInfo.CodecProfileLevel.AVCLevel51
            else -> MediaCodecInfo.CodecProfileLevel.AVCLevel52
        }
    }

    /* ---------- 编码器 ---------- */
    private fun buildFormat(withProfile: Boolean): MediaFormat {
        val f = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h)
        f.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
        f.setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
        f.setInteger(MediaFormat.KEY_FRAME_RATE, fps)
        f.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
        f.setInteger(MediaFormat.KEY_BITRATE_MODE, MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_CBR)
        f.setLong(MediaFormat.KEY_REPEAT_PREVIOUS_FRAME_AFTER, 100_000L)   // 画面静止时每 100ms 重复上一帧：保证新连接/关键帧请求不会等不到画面（防黑屏）
        f.setInteger(MediaFormat.KEY_PRIORITY, 0)                          // 实时
        f.setInteger(MediaFormat.KEY_MAX_B_FRAMES, 0)                      // 不用 B 帧 → 低延迟
        f.setInteger("max-fps-to-encoder", fps)                            // 120Hz 屏幕也只喂 60 帧
        if (Build.VERSION.SDK_INT >= 30) f.setInteger(MediaFormat.KEY_LATENCY, 1)
        f.setInteger(MediaFormat.KEY_COLOR_STANDARD, MediaFormat.COLOR_STANDARD_BT709)   // 颜色标签明确写成 BT.709，避免偏色
        f.setInteger(MediaFormat.KEY_COLOR_RANGE, MediaFormat.COLOR_RANGE_LIMITED)
        f.setInteger(MediaFormat.KEY_COLOR_TRANSFER, MediaFormat.COLOR_TRANSFER_SDR_VIDEO)
        if (withProfile) {
            f.setInteger(MediaFormat.KEY_PROFILE, MediaCodecInfo.CodecProfileLevel.AVCProfileHigh)
            f.setInteger(MediaFormat.KEY_LEVEL, avcLevel())
        }
        return f
    }

    private fun startEncoder() {
        var attempt = 0
        while (true) {
            val c = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            try {
                c.configure(buildFormat(attempt == 0), null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
                val surf = c.createInputSurface()
                c.start()
                attach(c, surf)
                return
            } catch (e: Exception) {
                try { c.release() } catch (ignored: Exception) { }
                attempt++
                if (attempt >= 4) throw e
                if (attempt >= 2) {                         // 设备不支持这个分辨率：缩小 25% 再试
                    w = align(w * 3 / 4)
                    h = align(h * 3 / 4)
                    recomputeBitrate()
                }
            }
        }
    }

    private fun attach(c: MediaCodec, surf: Surface) {
        codec = c
        csd = null
        val myGen = ++gen
        val d = vd
        if (d == null) {
            vd = projection.createVirtualDisplay(
                "LANCast", w, h, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, surf, null, null
            )
        } else {
            d.resize(w, h, dpi)
            d.surface = surf
        }
        session.resetVideo()
        session.sendHi(P.jsonPkt(P.T_VCONFIG, JSONObject().put("codec", "h264").put("width", w).put("height", h).put("fps", fps)))
        thread(name = "enc-drain", isDaemon = true) { drain(c, myGen) }
    }

    private fun drain(c: MediaCodec, myGen: Int) {
        val info = MediaCodec.BufferInfo()
        try {
            while (running && gen == myGen) {
                val i = c.dequeueOutputBuffer(info, 100_000)
                if (i < 0) continue
                val buf = c.getOutputBuffer(i)
                if (buf != null && info.size > 0) {
                    buf.position(info.offset)
                    buf.limit(info.offset + info.size)
                    if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) {
                        val cs = ByteArray(info.size)
                        buf.get(cs)
                        csd = cs
                    } else {
                        val key = info.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME != 0
                        val cs = if (key) csd else null
                        val extra = cs?.size ?: 0
                        val pkt = P.newPkt(P.T_VFRAME, if (key) 1 else 0, info.presentationTimeUs, extra + info.size)
                        if (cs != null) System.arraycopy(cs, 0, pkt, P.HDR, extra)   // 每个关键帧前都带 SPS/PPS，接收端随时能从关键帧起步
                        buf.get(pkt, P.HDR + extra, info.size)
                        session.sendVideo(pkt, key)
                    }
                }
                c.releaseOutputBuffer(i, false)
            }
        } catch (e: Exception) {
            if (running && gen == myGen) main.post { stop("编码器错误: ${e.message}") }
        }
    }

    fun requestKey() {
        if (lossless) {                                  // 无损档：对方要一幅整幅。静止画面上也要能发出去，所以用已发出的画面重发
            llFull = true
            llHandler?.post { llResendFull() }
            return
        }
        try {
            codec?.setParameters(Bundle().apply { putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0) })
        } catch (ignored: Exception) { }
    }

    private fun applyBitrate() {
        try {
            codec?.setParameters(Bundle().apply { putInt(MediaCodec.PARAMETER_KEY_VIDEO_BITRATE, bitrate) })
        } catch (ignored: Exception) { }
    }

    /** 网络拥塞：码率降 25% 并请求新关键帧；网络恢复后 recoverTick 每 3 秒回升 12%。 */
    private fun onCongestion() {
        val now = SystemClock.elapsedRealtime()
        if (now - lastCong < 800) return
        lastCong = now
        bitrate = max(preset.minBps, (bitrate * 0.75).toInt())
        session.maxBacklog = max(300_000, (bitrate / 8 * 0.15).toInt())
        applyBitrate()
        requestKey()
    }

    /** 旋转屏幕/折叠屏切换：重建编码器与虚拟显示，并通知对方新的分辨率。 */
    private fun checkResize() {
        if (!running) return
        val m = realMetrics()
        val t = targetSize(m)
        val nw = t[0]
        val nh = t[1]
        if (nw == w && nh == h) return
        if (lossless) {
            llHandler?.post {
                if (!running) return@post
                w = nw
                h = nh
                dpi = m.densityDpi
                try {
                    attachReader()
                } catch (e: Exception) {
                    main.post { stop("旋转后无法重建采集: ${e.message}") }
                }
            }
            return
        }
        w = nw
        h = nh
        dpi = m.densityDpi
        recomputeBitrate()
        gen++
        val old = codec
        codec = null
        try { old?.stop() } catch (ignored: Exception) { }
        try { old?.release() } catch (ignored: Exception) { }
        try {
            startEncoder()
        } catch (e: Exception) {
            stop("旋转后无法重建编码器: ${e.message}")
        }
    }

    /* ---------- 极致无损（Beta）：ImageReader 取原生分辨率的原始像素 → 差异块 + DEFLATE → 对方 ---------- */
    private fun startLossless() {
        val ht = HandlerThread("ll-cap", android.os.Process.THREAD_PRIORITY_DISPLAY)
        ht.start()
        llThread = ht
        val hd = Handler(ht.looper)
        llHandler = hd
        val n = max(2, min(4, Runtime.getRuntime().availableProcessors()))
        llPool = Executors.newFixedThreadPool(n) { r -> Thread(r, "ll-zip").also { it.isDaemon = true } }
        hd.post {
            try {
                attachReader()
            } catch (e: Exception) {
                main.post { stop("无法启动极致无损采集: ${e.message}") }
            }
        }
    }

    /** 在 llHandler 线程上调用：按当前 w×h 建新的 ImageReader，挂到虚拟显示上，并告诉对方新的分辨率与格式 */
    private fun attachReader() {
        val myGen = ++gen
        val ir = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 3)
        ir.setOnImageAvailableListener({ r -> onLlImage(r, myGen) }, llHandler)
        val d = vd
        if (d == null) {
            vd = projection.createVirtualDisplay(
                "LANCast", w, h, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, ir.surface, null, null
            )
        } else {
            d.resize(w, h, dpi)
            d.surface = ir.surface
        }
        val old = llReader
        llReader = ir
        try { old?.close() } catch (ignored: Exception) { }
        llCur = IntArray(w * h)
        llPrev = null
        llFull = true
        llNudges = 0
        session.resetVideo()
        session.sendHi(
            P.jsonPkt(
                P.T_VCONFIG,
                JSONObject().put("codec", "lossless").put("width", w).put("height", h).put("fps", 0)
                    .put("tile", LosslessCodec.TILE).put("pix", "rgb24")
            )
        )
        llHandler?.postDelayed(llWatchdog(myGen), 1000)
    }

    /** 屏幕一直没变化时 ImageReader 可能迟迟不出第一帧（对方会一直黑屏）：1 秒还没有画面就重新挂一次表面，催系统出一帧 */
    private fun llWatchdog(myGen: Int): Runnable = object : Runnable {
        override fun run() {
            if (!running || gen != myGen || llPrev != null || llNudges >= 5) return
            llNudges++
            try {
                val d = vd
                val ir = llReader
                if (d != null && ir != null) {
                    d.surface = null
                    d.surface = ir.surface
                }
            } catch (ignored: Exception) { }
            llHandler?.postDelayed(this, 1000)
        }
    }

    private fun onLlImage(r: ImageReader, myGen: Int) {
        val img = try { r.acquireLatestImage() } catch (e: Exception) { null } ?: return
        try {
            if (!running || gen != myGen || img.width != w || img.height != h) return
            // 网络还没写完上一帧：整帧丢弃。参考画面（llPrev）没动，下一帧会把累计的变化一起发出去
            if (!llFull && llPrev != null && session.videoQueued() > LL_QUEUE_MAX) return
            val pl = img.planes[0]
            val ib = pl.buffer.order(ByteOrder.LITTLE_ENDIAN).asIntBuffer()
            val stride = pl.rowStride / 4
            val cur = llCur
            for (y in 0 until h) {
                ib.position(y * stride)
                ib.get(cur, y * w, w)
            }
        } catch (e: Exception) {
            return
        } finally {
            img.close()
        }
        val prev = llPrev
        val full = llFull || prev == null
        if (llSend(llCur, if (full) null else prev, full)) {
            if (full) llFull = false                      // 只有发出去的是整幅才清标志：发差异帧期间收到的「要整幅」请求不能被吞掉
            llPrev = llCur
            llCur = prev ?: IntArray(w * h)
        }
    }

    /** 编码并整帧入队。没有变化返回 false（什么也不发） */
    private fun llSend(cur: IntArray, prev: IntArray?, full: Boolean): Boolean {
        val pool = llPool ?: return false
        val pkt = try {
            LosslessCodec.encode(cur, prev, w, h, full, pool, P.HDR)
        } catch (e: Exception) {
            null
        } ?: return false
        val bb = ByteBuffer.wrap(pkt)
        bb.put(0, P.T_VFRAME.toByte())
        bb.put(1, (if (full) 1 else 0).toByte())
        bb.putInt(4, pkt.size - P.HDR)
        bb.putLong(8, System.nanoTime() / 1000)
        session.sendVideoRaw(pkt)
        return true
    }

    /** 对方要整幅（刚连上 / 解码跟不上 / 出错）：用已经发出的画面重发，静止画面也不会黑屏 */
    private fun llResendFull() {
        if (!running || !llFull) return
        val p = llPrev ?: return                          // 还没有任何画面：第一帧图像来了自然会发整幅
        if (session.videoQueued() > LL_QUEUE_MAX) {
            llHandler?.postDelayed({ llResendFull() }, 150)
            return
        }
        if (llSend(p, null, true)) llFull = false
    }

    /* ---------- 音频：系统播放声音的原始 PCM（无损） ---------- */
    @SuppressLint("MissingPermission")
    private fun startAudio() {
        try {
            val cfg = AudioPlaybackCaptureConfiguration.Builder(projection)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()
            val fmt = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(48000)
                .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                .build()
            val minBuf = AudioRecord.getMinBufferSize(48000, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
            val r = AudioRecord.Builder()
                .setAudioFormat(fmt)
                .setBufferSizeInBytes(max(minBuf * 2, 48000 / 10 * 4))
                .setAudioPlaybackCaptureConfig(cfg)
                .build()
            r.startRecording()
            rec = r
            session.sendHi(P.jsonPkt(P.T_ACONFIG, JSONObject().put("rate", 48000).put("ch", 2).put("fmt", "s16")))
            thread(name = "audio-cap", isDaemon = true) {
                val chunk = 48000 / 50 * 4                         // 20ms
                try {
                    while (running) {
                        val pkt = P.newPkt(P.T_ADATA, 0, System.nanoTime() / 1000, chunk)
                        val n = r.read(pkt, P.HDR, chunk, AudioRecord.READ_BLOCKING)
                        if (n <= 0) break
                        if (n < chunk) {
                            val p2 = pkt.copyOf(P.HDR + n)
                            ByteBuffer.wrap(p2).putInt(4, n)
                            session.sendHi(p2)
                        } else session.sendHi(pkt)
                    }
                } catch (ignored: Exception) { }
            }
        } catch (e: Exception) {
            Link.status("无法采集手机声音（只投画面）: ${e.message}")
        }
    }

    /* ---------- 会话回调 ---------- */
    private var ctlErrSent = false
    private var lastNoFocus = 0L

    override fun onPacket(s: Session, p: Pkt) {
        if (p.type == P.T_INPUT) {                      // 屏幕控制：必须是本机用户同意过的会话
            if (!s.ctlAllowed || p.payload.size > 16 * 1024) return
            try {
                if (!InputService.handle(p.json()) && !ctlErrSent) {
                    ctlErrSent = true
                    s.sendCtrl(JSONObject().put("cmd", "ctl_err").put("reason", "no_service"))
                }
            } catch (ignored: Exception) { }
            return
        }
        if (p.type != P.T_CTRL) return
        try {
            when (p.json().optString("cmd")) {
                "keyframe" -> requestKey()
                "stop" -> main.post { stop("对方结束了投屏") }
            }
        } catch (ignored: Exception) { }
    }

    override fun onClosed(s: Session, reason: String) {
        main.post { stop(reason) }
    }

    @Synchronized
    fun stop(reason: String) {
        if (!running) return
        running = false
        InputService.reset()                            // 会话结束：松开对方还按着的「手指」
        InputService.onNoFocus = null
        main.removeCallbacks(recoverTick)
        try {
            val l = dispListener
            if (l != null) (ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager).unregisterDisplayListener(l)
        } catch (ignored: Exception) { }
        try { rec?.stop() } catch (ignored: Exception) { }
        try { rec?.release() } catch (ignored: Exception) { }
        gen++
        try { codec?.stop() } catch (ignored: Exception) { }
        try { codec?.release() } catch (ignored: Exception) { }
        codec = null
        try { vd?.release() } catch (ignored: Exception) { }
        try { llReader?.close() } catch (ignored: Exception) { }
        llReader = null
        llHandler?.removeCallbacksAndMessages(null)
        try { llThread?.quitSafely() } catch (ignored: Exception) { }
        try { llPool?.shutdownNow() } catch (ignored: Exception) { }
        try { projection.stop() } catch (ignored: Exception) { }
        session.close(reason)
        onEnded(reason)
    }
}

/* ═══════════════════════════ 接收端：对方画面 → TextureView ═══════════════════════════ */
class ScreenSink(
    private val session: Session,
    private val tv: TextureView,
    private val onVideoSize: (Int, Int) -> Unit,
    private val onEnded: (String) -> Unit,
    private val onStats: (String) -> Unit
) : SessionHandler, TextureView.SurfaceTextureListener {

    private val main = Handler(Looper.getMainLooper())
    private val decLock = Any()
    @Volatile private var dec: MediaCodec? = null
    private var decSurface: Surface? = null
    @Volatile private var waitKey = true
    @Volatile private var surfaceReady = false
    @Volatile private var stopped = false
    private var vw = 0
    private var vh = 0
    private val rxBytes = AtomicLong(0)
    private val rxFrames = AtomicInteger(0)
    private var lastStatT = SystemClock.elapsedRealtime()
    private val player = PcmPlayer()

    /* ---- 极致无损（Beta）接收：解出完整画面到 Bitmap，再画到 TextureView（不经过 MediaCodec） ---- */
    private inner class LlState(val w: Int, val h: Int) {
        val dec = LosslessCodec.Decoder(w, h)
        val bmp: Bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val q = LinkedBlockingQueue<Pkt>()
        val pool: ExecutorService = Executors.newFixedThreadPool(max(2, min(4, Runtime.getRuntime().availableProcessors()))) { r ->
            Thread(r, "ll-unzip").also { it.isDaemon = true }
        }
        @Volatile var wait = true                      // 没拿到整幅之前（或出错 / 积压后）丢弃差异帧
        @Volatile var dead = false
        var dirty = false
    }

    @Volatile private var ll: LlState? = null
    private val llPaint = Paint(Paint.FILTER_BITMAP_FLAG)

    private val statsTick = object : Runnable {
        override fun run() {
            if (stopped) return
            val now = SystemClock.elapsedRealtime()
            val dt = max(1L, now - lastStatT) / 1000.0
            lastStatT = now
            val fps = rxFrames.getAndSet(0) / dt
            val mbps = rxBytes.getAndSet(0) * 8 / dt / 1e6
            onStats("%.0f fps   %.1f Mbps   往返 %d ms   %dx%d".format(fps, mbps, session.rttMs, vw, vh))
            main.postDelayed(this, 1000)
        }
    }

    fun start() {
        tv.surfaceTextureListener = this
        if (tv.isAvailable) surfaceReady = true
        session.start(this)
        main.postDelayed(statsTick, 1000)
    }

    /* ---------- 解码 ---------- */
    private fun requestKey() {
        waitKey = true
        session.sendCtrl(JSONObject().put("cmd", "keyframe"))
    }

    private fun resetDecoder() {
        synchronized(decLock) {
            releaseDecoder()
            val st = tv.surfaceTexture
            if (vw <= 0 || !surfaceReady || st == null) return
            val surf = Surface(st)
            var d: MediaCodec? = null
            for (full in booleanArrayOf(true, false)) {          // 先带低延迟参数，不行就退回最小配置
                try {
                    val f = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, vw, vh)
                    f.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 2 * 1024 * 1024)
                    if (full) {
                        f.setInteger(MediaFormat.KEY_PRIORITY, 0)
                        f.setInteger(MediaFormat.KEY_OPERATING_RATE, Short.MAX_VALUE.toInt())
                        if (Build.VERSION.SDK_INT >= 30) f.setInteger(MediaFormat.KEY_LOW_LATENCY, 1)
                        f.setInteger("vendor.qti-ext-dec-low-latency.enable", 1)
                    }
                    val c = MediaCodec.createDecoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
                    try {
                        c.configure(f, surf, null, 0)
                        c.start()
                        d = c
                    } catch (e: Exception) {
                        try { c.release() } catch (ignored: Exception) { }
                        throw e
                    }
                    break
                } catch (e: Exception) {
                    d = null
                }
            }
            if (d == null) {
                try { surf.release() } catch (ignored: Exception) { }
                Link.status("解码器初始化失败")
                return
            }
            dec = d
            decSurface = surf
            val c2: MediaCodec = d
            thread(name = "dec-out", isDaemon = true) { outLoop(c2) }
            requestKey()
        }
    }

    private fun startLossless(w: Int, h: Int) {
        stopLossless()
        synchronized(decLock) { releaseDecoder() }       // 让出 TextureView：它同一时间只能接一个画面来源
        val st = try { LlState(w, h) } catch (e: Throwable) {
            main.post { stop("内存不足，无法接收「极致无损」画面（可让对方改用其他画质）") }
            return
        }
        ll = st
        thread(name = "ll-rx", isDaemon = true) {
            try {
                while (!st.dead) {
                    val p = st.q.poll(200, TimeUnit.MILLISECONDS) ?: continue
                    llProcess(st, p)
                }
            } catch (ignored: InterruptedException) { }
        }
    }

    private fun stopLossless() {
        val st = ll ?: return
        ll = null
        st.dead = true
        st.q.clear()
        st.pool.shutdownNow()
    }

    private fun llNeedFull(st: LlState) {
        if (!st.wait) {
            st.wait = true
            session.sendCtrl(JSONObject().put("cmd", "keyframe"))
        }
    }

    private fun llEnqueue(st: LlState, p: Pkt) {
        val full = p.flags and 1 != 0
        if (st.wait && !full) return
        if (!full && st.q.size > 8) {                    // 解码 / 绘制跟不上：丢掉后续差异帧，向对方要整幅（差异链不能带洞）
            llNeedFull(st)
            return
        }
        if (full) st.wait = false
        st.q.offer(p)
    }

    private fun llProcess(st: LlState, p: Pkt) {
        val full = p.flags and 1 != 0
        if (st.wait && !full) return
        try {
            val r = st.dec.apply(p.payload, full, st.pool)
            if (r[1] > r[0]) {
                st.bmp.setPixels(st.dec.px, r[0] * st.w, st.w, 0, r[0], st.w, r[1] - r[0])
                st.dirty = true
            }
            rxFrames.incrementAndGet()
        } catch (e: Exception) {
            if (st.dead) return
            llNeedFull(st)
            return
        }
        if (st.dirty && st.q.isEmpty()) {                // 队列里还有帧就先不画：追上来再画一次，延迟最低
            st.dirty = false
            llDraw(st)
        }
    }

    private fun llDraw(st: LlState) {
        if (!surfaceReady || st.dead) return
        try { tv.surfaceTexture?.setDefaultBufferSize(st.w, st.h) } catch (ignored: Exception) { }   // 缓冲区取画面原始大小，缩放交给显示层
        val c = try { tv.lockCanvas() } catch (e: Exception) { null } ?: return
        try {
            c.drawBitmap(st.bmp, null, Rect(0, 0, c.width, c.height), llPaint)
        } finally {
            try { tv.unlockCanvasAndPost(c) } catch (ignored: Exception) { }
        }
    }

    private fun releaseDecoder() {
        val d = dec
        dec = null
        try { d?.stop() } catch (ignored: Exception) { }
        try { d?.release() } catch (ignored: Exception) { }
        try { decSurface?.release() } catch (ignored: Exception) { }
        decSurface = null
    }

    private fun outLoop(d: MediaCodec) {
        val info = MediaCodec.BufferInfo()
        try {
            while (dec === d) {
                val i = d.dequeueOutputBuffer(info, 50_000)
                if (i >= 0) d.releaseOutputBuffer(i, true)       // 解出来立刻上屏，不排队
            }
        } catch (ignored: Exception) { }
    }

    private fun feed(p: Pkt) {
        val key = p.flags and 1 != 0
        synchronized(decLock) {
            val d = dec ?: return
            if (waitKey && !key) return                           // 没拿到关键帧之前不喂解码器 → 不会花屏
            try {
                val idx = d.dequeueInputBuffer(20_000)
                if (idx < 0) {                                    // 解码器吃不下：丢到下一个关键帧
                    requestKey()
                    return
                }
                val ib = d.getInputBuffer(idx)
                if (ib == null || ib.capacity() < p.payload.size) {
                    d.queueInputBuffer(idx, 0, 0, 0, 0)
                    requestKey()
                    return
                }
                ib.clear()
                ib.put(p.payload)
                d.queueInputBuffer(idx, 0, p.payload.size, p.pts, 0)
                if (key) waitKey = false
                rxFrames.incrementAndGet()
            } catch (e: Exception) {
                resetDecoder()
            }
        }
    }

    /* ---------- 会话回调 ---------- */
    override fun onPacket(s: Session, p: Pkt) {
        try {
            when (p.type) {
                P.T_VCONFIG -> {
                    val j = p.json()
                    vw = j.getInt("width")
                    vh = j.getInt("height")
                    main.post { onVideoSize(vw, vh) }
                    if (j.optString("codec", "h264") == "lossless") {
                        startLossless(vw, vh)
                    } else {
                        stopLossless()
                        resetDecoder()
                    }
                }
                P.T_VFRAME -> {
                    rxBytes.addAndGet(p.payload.size.toLong())
                    val st = ll
                    if (st != null) llEnqueue(st, p) else feed(p)
                }
                P.T_ACONFIG -> {
                    val j = p.json()
                    player.config(j.getInt("rate"), j.getInt("ch"), j.optString("fmt", "s16"))
                }
                P.T_ADATA -> player.push(p.payload)
                P.T_CTRL -> when (p.json().optString("cmd")) {
                    "stop" -> main.post { stop("对方结束了投屏") }
                    "ctl_err" -> {
                        val why = when (p.json().optString("reason")) {
                            "no_injector" -> "对方电脑的输入控制模块不可用，暂时只能查看"
                            "blocked" -> "对方电脑拦截了输入（正在操作以管理员身份运行的窗口？）"
                            else -> "对方还没开启「屏幕控制」服务，暂时只能查看"
                        }
                        main.post { android.widget.Toast.makeText(Link.app, why, android.widget.Toast.LENGTH_LONG).show() }
                    }
                }
            }
        } catch (e: Exception) {
            Link.status("数据处理出错: ${e.message}")
        }
    }

    override fun onClosed(s: Session, reason: String) {
        main.post { stop(reason) }
    }

    fun stop(reason: String) {
        if (stopped) return
        stopped = true
        main.removeCallbacks(statsTick)
        try { session.sendCtrl(JSONObject().put("cmd", "stop")) } catch (ignored: Exception) { }
        main.postDelayed({ session.close(reason) }, 200)
        stopLossless()
        synchronized(decLock) { releaseDecoder() }
        player.stop()
        tv.surfaceTextureListener = null
        onEnded(reason)
    }

    override fun onSurfaceTextureAvailable(st: SurfaceTexture, width: Int, height: Int) {
        surfaceReady = true
        val l = ll
        if (l != null) thread(isDaemon = true) { llDraw(l) } else if (vw > 0) resetDecoder()
    }

    override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, width: Int, height: Int) {
        val l = ll
        if (l != null) thread(isDaemon = true) { llDraw(l) }
    }

    override fun onSurfaceTextureDestroyed(st: SurfaceTexture): Boolean {
        surfaceReady = false
        synchronized(decLock) { releaseDecoder() }
        return true
    }

    override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
}

/* ═══════════════════════════ 无损 PCM 播放 ═══════════════════════════ */
class PcmPlayer {
    private var track: AudioTrack? = null
    private var worker: Thread? = null
    private val q = LinkedBlockingQueue<ByteArray>()
    private val queued = AtomicInteger(0)
    @Volatile private var running = false
    private var bps = 192000                        // 每秒字节数
    private var isFloat = false

    @Synchronized
    fun config(rate: Int, ch: Int, fmt: String) {
        stop()
        isFloat = fmt == "f32"
        bps = rate * ch * (if (isFloat) 4 else 2)
        val enc = if (isFloat) AudioFormat.ENCODING_PCM_FLOAT else AudioFormat.ENCODING_PCM_16BIT
        val mask = if (ch == 1) AudioFormat.CHANNEL_OUT_MONO else AudioFormat.CHANNEL_OUT_STEREO
        val minBuf = AudioTrack.getMinBufferSize(rate, mask, enc)
        val t = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE)
                    .build()
            )
            .setAudioFormat(AudioFormat.Builder().setEncoding(enc).setSampleRate(rate).setChannelMask(mask).build())
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setBufferSizeInBytes(max(minBuf, (bps * 0.04).toInt()))
            .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
            .build()
        track = t
        running = true
        worker = thread(name = "pcm-out", isDaemon = true) { loop(t) }
    }

    private fun loop(t: AudioTrack) {
        try {
            while (running && queued.get() < bps * 0.04) Thread.sleep(5)      // 预缓冲 40ms，吸收网络抖动
            t.play()
            while (running) {
                val b = q.poll(100, TimeUnit.MILLISECONDS) ?: continue
                queued.addAndGet(-b.size)
                if (isFloat) {
                    val fa = FloatArray(b.size / 4)
                    ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN).asFloatBuffer().get(fa)
                    t.write(fa, 0, fa.size, AudioTrack.WRITE_BLOCKING)
                } else {
                    t.write(b, 0, b.size)
                }
            }
        } catch (ignored: Exception) { }
    }

    fun push(b: ByteArray) {
        if (!running) return
        q.offer(b)
        if (queued.addAndGet(b.size) > bps * 0.2) {              // 积压超过 200ms：丢最旧的，把延迟拉回 80ms
            while (queued.get() > bps * 0.08) {
                val x = q.poll() ?: break
                queued.addAndGet(-x.size)
            }
        }
    }

    @Synchronized
    fun stop() {
        running = false
        val t = track
        track = null
        try { t?.stop() } catch (ignored: Exception) { }
        try { t?.release() } catch (ignored: Exception) { }
        q.clear()
        queued.set(0)
    }
}
