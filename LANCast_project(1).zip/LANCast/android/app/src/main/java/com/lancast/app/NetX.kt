package com.lancast.app

import java.net.InetSocketAddress
import java.net.Socket
import java.net.URLDecoder
import java.net.URLEncoder
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

/** 二维码 / 配对链接里解析出来的内容 */
class QrInfo(val id: String, val name: String, val pin: String, val port: Int, val ips: List<String>)

/**
 * 网络地址工具：网卡分类 / 二维码地址 / 对方地址排序 / 配对链接 / 并行探测。
 * 纯 Kotlin，不依赖 Android API，可以用 kotlinc 直接在电脑上编译测试（见 android/jvm-test/README.md）。
 * 与电脑端 windows/netutil.js 一一对应，规范见 docs/PROTOCOL.md 第 15 节。
 *
 * 为什么需要：原来「只认 Wi-Fi 局域网」——移动数据网卡、tun（VPN）网卡的地址一律不放进二维码，
 * 流量下二维码是空的；设备发现只靠 UDP 广播；已配对设备只记一个 IP。借助蒲公英、ZeroTier、Tailscale 等
 * 「虚拟局域网」跨网络互联时这三件事都会出问题。现在：
 *   · 地址分三类：LAN（Wi-Fi / 以太网 / 热点）/ OVERLAY（虚拟局域网 = VPN 网卡）/ CELL（移动数据）；
 *     二维码、配对链接里放 LAN + OVERLAY 的地址，只有移动数据时才放移动数据的地址（二维码不会是空的）
 *   · 已配对设备记「主地址 + 备用地址」，连接时并行探测，哪个通就走哪个
 *   · 配对链接 lancast://pair?...（和二维码内容完全一样），不在一起时复制粘贴就能配对
 */
object NetX {
    enum class Kind { LAN, OVERLAY, CELL, JUNK }

    class Addr(val ip: String, val prefix: Int, val iface: String, val kind: Kind)

    const val MAX_ADDRS = 6
    const val DEFAULT_PORT = 47800

    /* ───────── IPv4 小工具 ───────── */
    fun toLong(ip: String): Long? {
        val p = ip.trim().split('.')
        if (p.size != 4) return null
        var n = 0L
        for (s in p) {
            if (s.isEmpty() || s.length > 3 || !s.all { it in '0'..'9' }) return null
            val b = s.toInt()
            if (b > 255) return null
            n = n * 256 + b
        }
        return n
    }

    fun inRange(ip: String, base: String, prefix: Int): Boolean {
        val a = toLong(ip) ?: return false
        val b = toLong(base) ?: return false
        if (prefix <= 0) return true
        val mask = if (prefix >= 32) 0xFFFFFFFFL else (0xFFFFFFFFL shl (32 - prefix)) and 0xFFFFFFFFL
        return (a and mask) == (b and mask)
    }

    /** 能不能当作「别的设备可以连过来的本机地址」：排除 0.x / 回环 / 169.254 / 组播与保留 / CLAT(192.0.0.x) / 假 IP 段(198.18/15) */
    fun usable(ip: String): Boolean {
        val n = toLong(ip) ?: return false
        val a = (n / 16777216L).toInt()
        if (a == 0 || a == 127 || a >= 224) return false
        if (inRange(ip, "169.254.0.0", 16) || inRange(ip, "192.0.0.0", 29) || inRange(ip, "198.18.0.0", 15)) return false
        return true
    }

    /** 私有地址：10/8、172.16/12、192.168/16，以及 100.64/10（运营商 NAT / Tailscale） */
    fun isPrivate(ip: String): Boolean =
        inRange(ip, "10.0.0.0", 8) || inRange(ip, "172.16.0.0", 12) || inRange(ip, "192.168.0.0", 16) || inRange(ip, "100.64.0.0", 10)

    fun cleanIps(list: List<String>, max: Int = 8): List<String> = list.map { it.trim() }.filter { usable(it) }.distinct().take(max)

    /* ───────── 网卡分类（ConnectivityManager 给不出类型时按名字判断） ───────── */
    private val OVERLAY_PREFIX = listOf("tun", "tap", "ppp", "wg", "ipsec", "utun", "pgy", "zt", "tailscale", "vpn", "nordlynx", "oray")
    private val CELL_PREFIX = listOf("rmnet", "ccmni", "v4-", "pdp", "seth", "ccinet", "wwan", "rev_rmnet", "r_rmnet", "qmi")
    private val LAN_PREFIX = listOf("wlan", "eth", "en", "ap", "swlan", "softap", "p2p", "br", "usb", "rndis", "bt-pan", "wifi")
    private val JUNK_PREFIX = listOf("dummy", "sit", "ip6", "ifb", "bond", "veth", "docker", "tunl")

    fun kindOfIface(name: String, ip: String = ""): Kind {
        val n = name.lowercase()
        if (n == "lo" || JUNK_PREFIX.any { n.startsWith(it) }) return Kind.JUNK
        if (OVERLAY_PREFIX.any { n.startsWith(it) }) return Kind.OVERLAY
        if (CELL_PREFIX.any { n.startsWith(it) }) return Kind.CELL
        if (LAN_PREFIX.any { n.startsWith(it) }) return Kind.LAN
        return if (ip.isNotEmpty() && !isPrivate(ip)) Kind.CELL else Kind.LAN          // 不认识的网卡：私有地址当局域网，公网地址当移动数据
    }

    private fun homeRank(ip: String): Int = when {
        ip.startsWith("192.168.") -> 0
        ip.startsWith("10.") -> 1
        ip.startsWith("172.") -> 2
        isPrivate(ip) -> 3
        else -> 4
    }

    /** 二维码 / 配对链接里放的本机地址：局域网在前、虚拟局域网在后；都没有时才用移动数据的地址（所以二维码永远不是空的，除非完全没网）。 */
    fun qrIps(locals: List<Addr>, max: Int = MAX_ADDRS): List<String> {
        fun by(k: Kind) = locals.filter { it.kind == k }.map { it.ip }.sortedBy { homeRank(it) }
        var r = by(Kind.LAN) + by(Kind.OVERLAY)
        if (r.isEmpty()) r = by(Kind.CELL)
        return r.distinct().take(max)
    }

    /** 本机网络现状：给界面显示、给连不上时的提示用 */
    class State(val lan: List<String>, val overlay: List<String>, val cell: List<String>) {
        val none: Boolean get() = lan.isEmpty() && overlay.isEmpty() && cell.isEmpty()
        val onlyCell: Boolean get() = lan.isEmpty() && overlay.isEmpty() && cell.isNotEmpty()
        val reachable: Boolean get() = lan.isNotEmpty() || overlay.isNotEmpty()      // 别的设备有可能连得上本机
    }

    fun state(locals: List<Addr>): State {
        fun by(k: Kind) = locals.filter { it.kind == k }.map { it.ip }.sortedBy { homeRank(it) }.distinct()
        return State(by(Kind.LAN), by(Kind.OVERLAY), by(Kind.CELL))
    }

    /** 二维码下面那一行：当前用的是哪种网络 */
    fun summary(st: State): String = when {
        st.none -> "未联网 · 请连接 Wi-Fi 或打开移动数据"
        st.onlyCell -> "仅移动数据 · 开启蒲公英等虚拟局域网后，其他设备才连得上本机"
        else -> listOfNotNull(
            if (st.lan.isNotEmpty()) "局域网 " + st.lan.joinToString(" / ") else null,
            if (st.overlay.isNotEmpty()) "虚拟局域网 " + st.overlay.joinToString(" / ") else null,
            if (st.cell.isNotEmpty()) "移动数据" else null
        ).joinToString(" · ")
    }

    /* ───────── 对方地址：排序 / 分类 ───────── */
    /** 越小越优先：0 与本机某局域网地址同网段；1 与某虚拟局域网地址同网段；3 其他私有地址；4 其他 */
    fun rank(ip: String, locals: List<Addr>): Int {
        for (l in locals) if (l.kind == Kind.LAN && inRange(ip, l.ip, l.prefix)) return 0
        for (l in locals) if (l.kind == Kind.OVERLAY && inRange(ip, l.ip, l.prefix)) return 1
        return if (isPrivate(ip)) 3 else 4
    }

    /** 稳定排序：同一等级里保持传入顺序；去重、丢弃非法值 */
    fun order(cands: List<String>, locals: List<Addr>): List<String> =
        cands.map { it.trim() }.filter { toLong(it) != null }.distinct().withIndex()
            .sortedWith(compareBy({ rank(it.value, locals) }, { it.index })).map { it.value }

    fun pathLabel(ip: String, locals: List<Addr>): String = when (rank(ip, locals)) {
        0 -> "局域网直连"
        1 -> "虚拟局域网"
        else -> "远程连接"
    }

    /** 对方是否就在本机的局域网里（不是 → 链路可能是 VPN / 中继 / 移动网络，心跳超时要放宽） */
    fun isLanPeer(ip: String, locals: List<Addr>): Boolean = locals.any { it.kind == Kind.LAN && inRange(ip, it.ip, it.prefix) }

    /** 要不要向这个地址单播发现包：只给「本机真有路可走」的地址发——同网段的、公网的，或本机在虚拟局域网里时的其他私有地址；
     *  免得在移动网络 / 别人的局域网里把设备名发给不相干的私有地址。 */
    fun shouldUnicast(ip: String, locals: List<Addr>): Boolean {
        val r = rank(ip, locals)
        return if (r == 3) locals.any { it.kind == Kind.OVERLAY } else true
    }

    /** 把 extra 并进地址列表：primary 排第一，总数不超过 max；返回 主地址 to 备用地址 */
    fun mergeAddrs(primary: String, ips: List<String>, extra: List<String>, max: Int = MAX_ADDRS): Pair<String, List<String>> {
        val all = (listOf(primary) + ips + extra).filter { toLong(it) != null }.distinct()
        return Pair(all.firstOrNull() ?: primary, all.drop(1).take(max - 1))
    }

    /** 一条配对记录的全部已知地址（主地址在前） */
    fun recAddrs(ip: String, ips: List<String>): List<String> = (listOf(ip) + ips).filter { toLong(it) != null }.distinct()

    /* ───────── 配对链接 ───────── */
    private fun enc(s: String): String = URLEncoder.encode(s, "UTF-8").replace("+", "%20")

    fun buildLink(id: String, name: String, pin: String, port: Int, ips: List<String>): String =
        "lancast://pair?v=2&id=" + id + "&n=" + enc(name) + "&p=" + pin + "&port=" + port + "&ip=" + ips.joinToString(",")

    private fun parseQuery(qs: String): Map<String, String> {
        val out = HashMap<String, String>()
        for (kv in qs.split('&')) {
            val i = kv.indexOf('=')
            if (i <= 0) continue
            val k = kv.substring(0, i)
            val raw = kv.substring(i + 1)
            val v = try { URLDecoder.decode(raw, "UTF-8") } catch (e: Exception) { raw }
            if (!out.containsKey(k)) out[k] = v
        }
        return out
    }

    private val LINK_RE = Regex("lancast://pair\\?([\\x21-\\x7E]+)", RegexOption.IGNORE_CASE)
    private val ID_RE = Regex("[0-9a-zA-Z]{4,64}")
    private val PIN_RE = Regex("\\d{4,12}")

    /** 从一段文字里找出 lancast://pair?... 并解析（前后有别的字也行，比如微信里转发的整句话）；不是瞬流的配对链接返回 null */
    fun parseLink(text: String): QrInfo? {
        val m = LINK_RE.find(text) ?: return null
        val q = parseQuery(m.groupValues[1].trimEnd(')', '.', ',', ';', ']', '>', '"', '\''))
        val id = q["id"] ?: return null
        val pin = q["p"] ?: return null
        if (!ID_RE.matches(id) || !PIN_RE.matches(pin)) return null
        val ips = cleanIps((q["ip"] ?: "").split(','))
        if (ips.isEmpty()) return null
        val port = q["port"]?.toIntOrNull()?.takeIf { it in 1..65535 } ?: DEFAULT_PORT
        return QrInfo(id, (q["n"] ?: "对方设备").take(64), pin, port, ips)
    }

    /** 连不上对方时给用户的提示：按本机网络现状区分，直接告诉下一步该做什么 */
    fun unreachableHint(st: State, tried: List<String>): String {
        val head = "连不上对方（试过 " + tried.joinToString("、") + "）。"
        return head + when {
            st.none -> "本机现在没有网络，请先连接 Wi-Fi 或打开移动数据。"
            st.overlay.isNotEmpty() -> "请确认：对方已打开瞬流，并且和本机在同一个虚拟局域网里；对方是电脑的话，防火墙要放行（电脑端点「放行防火墙」）。"
            st.onlyCell -> "本机现在只有移动数据，连不到别人的局域网。请先打开蒲公英（或 ZeroTier / Tailscale）并确认对方也在同一个虚拟网络里，或者改连和对方同一个 Wi-Fi。"
            else -> "本机没有检测到虚拟局域网：两台设备不在同一个局域网时，请先在两边都登录蒲公英（或 ZeroTier / Tailscale）加入同一个虚拟网络，再重试。"
        }
    }

    /* ───────── 并行探测 ─────────
     * 对每个候选同时发起 TCP 连接（连上就立刻关掉，不做任何握手）。必须在后台线程调用。
     * 默认「抢跑」：排在最前的候选一连通就立刻返回；排在前面的还没出结果时，后面的连通了也最多再等 graceMs。
     * all = true：等全部候选出结果（或超时）再返回，用于配对（要依次尝试所有连得通的地址）。
     * 返回连得通的地址，按传入顺序（= 优先级）排列；一个都不通返回空列表。 */
    fun probe(cands0: List<String>, port: Int, timeoutMs: Int = 2500, graceMs: Long = 350, all: Boolean = false): List<String> {
        val cands = cands0.filter { toLong(it) != null }.distinct()
        if (cands.isEmpty()) return emptyList()
        val st = arrayOfNulls<Boolean>(cands.size)
        val socks = arrayOfNulls<Socket>(cands.size)
        val q = LinkedBlockingQueue<Int>()
        cands.forEachIndexed { i, ip ->
            thread(isDaemon = true, name = "probe") {
                val s = Socket()
                synchronized(socks) { socks[i] = s }
                var ok = false
                try {
                    s.connect(InetSocketAddress(ip, port), timeoutMs)
                    ok = true
                } catch (ignored: Exception) {
                }
                try { s.close() } catch (ignored: Exception) { }
                synchronized(st) { st[i] = ok }
                q.offer(i)
            }
        }
        fun snap(): List<Boolean?> = synchronized(st) { st.toList() }
        var firstOk = 0L
        val deadline = System.currentTimeMillis() + timeoutMs + 500
        while (true) {
            val s = snap()
            val now = System.currentTimeMillis()
            if (firstOk == 0L && s.any { it == true }) firstOk = now
            if (s.none { it == null }) break
            if (!all) {
                var decided = false
                for (v in s) {
                    if (v == true) { decided = true; break }
                    if (v == null) break
                }
                if (decided) break
                if (firstOk != 0L && now - firstOk >= graceMs) break
            }
            if (now >= deadline) break
            q.poll(50, TimeUnit.MILLISECONDS)
        }
        val fin = snap()
        synchronized(socks) { for (s in socks) try { s?.close() } catch (ignored: Exception) { } }     // 还没出结果的：直接掐掉
        return cands.filterIndexed { i, _ -> fin[i] == true }
    }
}
