package com.lancast.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import java.io.File

/**
 * 本机头像。
 * 严格无损：用户选的图片原文件逐字节保存（不重新编码、不压缩、不改尺寸），
 * 只在显示时按主流社交媒体的做法处理——按 EXIF 方向转正 → 居中裁成正方形 → 缩放到显示尺寸（圆形裁切由界面完成）。
 */
object Avatar {
    private const val MAX_BYTES = 30L * 1024 * 1024
    private fun file(ctx: Context) = File(ctx.filesDir, "avatar.orig")

    fun has(ctx: Context) = file(ctx).isFile

    /** 把所选图片原样复制保存；不是图片 / 太大返回 false */
    fun save(ctx: Context, uri: Uri): Boolean {
        val tmp = File(ctx.filesDir, "avatar.tmp")
        return try {
            ctx.contentResolver.openInputStream(uri)!!.use { ins ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024); var total = 0L
                    while (true) {
                        val n = ins.read(buf); if (n < 0) break
                        total += n; if (total > MAX_BYTES) throw IllegalStateException("too big")
                        out.write(buf, 0, n)
                    }
                }
            }
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(tmp.path, o)
            if (o.outWidth <= 0 || o.outHeight <= 0) { tmp.delete(); return false }
            val dst = file(ctx); dst.delete()
            tmp.renameTo(dst)
        } catch (e: Exception) { tmp.delete(); false }
    }

    fun clear(ctx: Context) { file(ctx).delete() }

    /** 取显示用的正方形位图（边长 sizePx）；没有头像返回 null */
    fun load(ctx: Context, sizePx: Int): Bitmap? {
        val f = file(ctx); if (!f.isFile) return null
        return try {
            val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.path, b)
            if (b.outWidth <= 0) return null
            val shortSide = minOf(b.outWidth, b.outHeight)
            var ss = 1
            while (shortSide / (ss * 2) >= sizePx) ss *= 2      // 只做 2 的幂次降采样，保证留有余量再精细缩放
            val o = BitmapFactory.Options().apply { inSampleSize = ss }
            var bmp = BitmapFactory.decodeFile(f.path, o) ?: return null
            val deg = when (ExifInterface(f.path).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            if (deg != 0f) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg) }, true)
            val side = minOf(bmp.width, bmp.height)                 // 居中裁成正方形
            val sq = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
            if (side == sizePx) sq else Bitmap.createScaledBitmap(sq, sizePx, sizePx, true)
        } catch (e: Exception) { null }
    }
}
