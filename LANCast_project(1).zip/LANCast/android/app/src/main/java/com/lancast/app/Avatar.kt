package com.lancast.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import java.io.File

/**
 * 本机头像。
 * 严格无损：用户选的图片原文件逐字节保存（不重新编码、不压缩、不改尺寸），
 * 只在显示时按主流社交媒体的做法处理——按 EXIF 方向转正 → 居中裁成正方形 → 缩放到显示尺寸（圆形裁切由界面完成）。
 */
object Avatar {
    private const val MAX_BYTES = 30L * 1024 * 1024
    private fun file(ctx: Context) = File(ctx.filesDir, "avatar.orig")

    fun has(ctx: Context) = file(ctx).isFile

    /** 把所选图片原样复制保存；不是图片 / 太大返回 false */
    fun save(ctx: Context, uri: Uri): Boolean {
        val tmp = File(ctx.filesDir, "avatar.tmp")
        return try {
            ctx.contentResolver.openInputStream(uri)!!.use { ins ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024); var total = 0L
                    while (true) {
                        val n = ins.read(buf); if (n < 0) break
                        total += n; if (total > MAX_BYTES) throw IllegalStateException("too big")
                        out.write(buf, 0, n)
                    }
                }
            }
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(tmp.path, o)
            if (o.outWidth <= 0 || o.outHeight <= 0) { tmp.delete(); return false }
            val dst = file(ctx); dst.delete()
            val ok = tmp.renameTo(dst)
            if (ok) afterChange(ctx)
            ok
        } catch (e: Exception) { tmp.delete(); false }
    }

    fun clear(ctx: Context) { file(ctx).delete(); afterChange(ctx) }

    /** 取显示用的正方形位图（边长 sizePx）；没有头像返回 null */
    fun load(ctx: Context, sizePx: Int): Bitmap? {
        val f = file(ctx); if (!f.isFile) return null
        return try {
            val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.path, b)
            if (b.outWidth <= 0) return null
            val shortSide = minOf(b.outWidth, b.outHeight)
            var ss = 1
            while (shortSide / (ss * 2) >= sizePx) ss *= 2      // 只做 2 的幂次降采样，保证留有余量再精细缩放
            val o = BitmapFactory.Options().apply { inSampleSize = ss }
            var bmp = BitmapFactory.decodeFile(f.path, o) ?: return null
            val deg = when (ExifInterface(f.path).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            if (deg != 0f) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg) }, true)
            val side = minOf(bmp.width, bmp.height)                 // 居中裁成正方形
            val sq = Bitmap.createBitmap(bmp, (bmp.width - side) / 2, (bmp.height - side) / 2, side, side)
            if (side == sizePx) sq else Bitmap.createScaledBitmap(sq, sizePx, sizePx, true)
        } catch (e: Exception) { null }
    }

    // ───────── 头像同步（docs/PROTOCOL.md 第 20 节）─────────
    // 本机原图仍逐字节无损保存；发给对方的是「分享用缩略图」：EXIF 转正 → 居中裁成正方形 → 最长 320px → JPEG（≤256KB）。
    // 对方头像缓存在 filesDir/peer-avatars/<设备ID>.jpg，哈希记在 SharedPreferences 的 pav_<设备ID>。
    private fun thumbFile(ctx: Context) = File(ctx.filesDir, "avatar.thumb")
    private fun safeId(id: String) = id.filter { it.isLetterOrDigit() || it == '_' || it == '-' }.take(64)
    private fun peerFile(ctx: Context, id: String): File {
        val d = File(ctx.filesDir, "peer-avatars"); d.mkdirs(); return File(d, safeId(id) + ".jpg")
    }
    @Volatile private var mineCache: Pair<String, ByteArray>? = null
    @Volatile private var mineStamp = 0L

    /** 重新生成缩略图（原图没了就删缩略图），然后通知所有已连上的对方；在后台线程做 */
    fun afterChange(ctx: Context) {
        val app = ctx.applicationContext
        Thread {
            try { rebuildThumb(app) } catch (ignored: Exception) { }
            try { ChatNet.start(); ChatNet.hub.announceAvatar() } catch (ignored: Exception) { }
        }.start()
    }

    @Synchronized fun rebuildThumb(ctx: Context) {
        // 无损模式：不再生成缩略图，直接分享 avatar.orig 原文件字节；这里只清理旧版遗留的缩略图和缓存
        thumbFile(ctx).delete(); mineCache = null
    }

    /** 给聊天 hub 用：(哈希, 原图字节)；没有头像返回 null。无损：直接分享原文件 */
    @Synchronized fun mine(ctx: Context): Pair<String, ByteArray>? {
        val f = file(ctx); if (!f.isFile) return null
        val stamp = f.lastModified() xor f.length()
        val c = mineCache
        if (c != null && mineStamp == stamp) return c
        val buf = try { f.readBytes() } catch (e: Throwable) { return null }
        if (buf.size > ChatCrypto.AV_MAX_BYTES) return null
        val h = java.security.MessageDigest.getInstance("SHA-256").digest(buf).joinToString("") { "%02x".format(it) }.substring(0, 32)
        mineStamp = stamp; mineCache = h to buf
        return mineCache
    }

    fun peerHash(ctx: Context, id: String): String =
        if (peerFile(ctx, id).let { it.isFile && it.length() > 0 }) (Link.prefs.getString("pav_" + safeId(id), "") ?: "") else ""

    fun peerSave(ctx: Context, id: String, hash: String, data: ByteArray?) {
        val pf = peerFile(ctx, id)
        if (data == null || hash.isEmpty()) { pf.delete(); Link.prefs.edit().remove("pav_" + safeId(id)).apply() }
        else {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(data, 0, data.size, o)
            if (o.outWidth <= 0 || o.outHeight <= 0) return          // 不是可解码的图片，丢弃
            pf.writeBytes(data); Link.prefs.edit().putString("pav_" + safeId(id), hash).apply() }
    }

    /** 按显示尺寸降采样解码（原图可能很大，避免 OOM），并按 EXIF 转正 */
    private fun decodeSampled(f: File, sizePx: Int): Bitmap? {
        val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(f.path, b)
        if (b.outWidth <= 0) return null
        val shortSide = minOf(b.outWidth, b.outHeight)
        var ss = 1
        while (shortSide / (ss * 2) >= sizePx) ss *= 2
        var bmp = BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = ss }) ?: return null
        val deg = when (try { ExifInterface(f.path).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1) } catch (e: Exception) { 1 }) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        if (deg != 0f) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg) }, true)
        return bmp
    }

    /** 对方头像的圆形位图（边长 sizePx）；对方没有头像 / 解码失败返回 null */
    fun peerCircle(ctx: Context, id: String, sizePx: Int): Bitmap? {
        val pf = peerFile(ctx, id); if (!pf.isFile) return null
        return try {
            val src = decodeSampled(pf, sizePx) ?: return null
            val side = minOf(src.width, src.height)
            val sq = Bitmap.createBitmap(src, (src.width - side) / 2, (src.height - side) / 2, side, side)
            val sc = Bitmap.createScaledBitmap(sq, sizePx, sizePx, true)
            val out = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
            Canvas(out).drawCircle(sizePx / 2f, sizePx / 2f, sizePx / 2f, Paint(Paint.ANTI_ALIAS_FLAG).apply { shader = BitmapShader(sc, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP) })
            out
        } catch (e: Exception) { null }
    }

    /** 对方头像的圆角方形位图（通话页用）；没有返回 null */
    fun peerRounded(ctx: Context, id: String, sizePx: Int, radiusPx: Float): Bitmap? {
        val pf = peerFile(ctx, id); if (!pf.isFile) return null
        return try {
            val src = decodeSampled(pf, sizePx) ?: return null
            val side = minOf(src.width, src.height)
            val sq = Bitmap.createBitmap(src, (src.width - side) / 2, (src.height - side) / 2, side, side)
            val sc = Bitmap.createScaledBitmap(sq, sizePx, sizePx, true)
            val out = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
            Canvas(out).drawRoundRect(android.graphics.RectF(0f, 0f, sizePx.toFloat(), sizePx.toFloat()), radiusPx, radiusPx, Paint(Paint.ANTI_ALIAS_FLAG).apply { shader = BitmapShader(sc, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP) })
            out
        } catch (e: Exception) { null }
    }

    // ───────── 点击查看大图 ─────────
    /** 解码文件为完整大图（按 EXIF 转正，最长边超过 maxPx 时才降采样，否则保持原像素）；不裁剪 */
    private fun decodeFull(f: File, maxPx: Int): Bitmap? {
        if (!f.isFile) return null
        return try {
            val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.path, b)
            if (b.outWidth <= 0) return null
            var ss = 1
            while (maxOf(b.outWidth, b.outHeight) / (ss * 2) >= maxPx) ss *= 2
            var bmp = BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = ss }) ?: return null
            val deg = when (try { ExifInterface(f.path).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1) } catch (e: Exception) { 1 }) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            if (deg != 0f) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg) }, true)
            bmp
        } catch (e: Throwable) { null }
    }

    /** 本机头像原图（无损，完整不裁剪） */
    fun viewMine(ctx: Context): Bitmap? = decodeFull(file(ctx), 4096)

    /** 对方头像（对方分享过来的那份） */
    fun viewPeer(ctx: Context, id: String): Bitmap? = decodeFull(peerFile(ctx, id), 4096)

    /** 全屏查看：黑底，双指缩放 / 拖动，点一下关闭；bmp 为 null 不弹 */
    fun show(ctx: Context, bmp: Bitmap?) {
        if (bmp == null) return
        val iv = android.widget.ImageView(ctx).apply {
            setImageBitmap(bmp); scaleType = android.widget.ImageView.ScaleType.MATRIX
            setBackgroundColor(android.graphics.Color.BLACK)
        }
        val dlg = android.app.Dialog(ctx, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        dlg.setContentView(iv)
        val m = Matrix(); val saved = Matrix()
        var base = 1f; var scale = 1f
        val start = android.graphics.PointF(); var mode = 0; var d0 = 1f; val mid = android.graphics.PointF(); var moved = false
        fun fit() {
            val vw = iv.width.toFloat(); val vh = iv.height.toFloat(); if (vw <= 0 || vh <= 0) return
            base = minOf(vw / bmp.width, vh / bmp.height); scale = 1f
            m.reset(); m.postScale(base, base); m.postTranslate((vw - bmp.width * base) / 2, (vh - bmp.height * base) / 2)
            iv.imageMatrix = m
        }
        iv.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> fit() }
        iv.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                android.view.MotionEvent.ACTION_DOWN -> { saved.set(m); start.set(e.x, e.y); mode = 1; moved = false }
                android.view.MotionEvent.ACTION_POINTER_DOWN -> if (e.pointerCount == 2) {
                    d0 = Math.hypot((e.getX(0) - e.getX(1)).toDouble(), (e.getY(0) - e.getY(1)).toDouble()).toFloat()
                    mid.set((e.getX(0) + e.getX(1)) / 2, (e.getY(0) + e.getY(1)) / 2); saved.set(m); mode = 2; moved = true
                }
                android.view.MotionEvent.ACTION_MOVE -> {
                    if (mode == 1 && scale > 1.01f) { m.set(saved); m.postTranslate(e.x - start.x, e.y - start.y); iv.imageMatrix = m }
                    if (mode == 1 && Math.hypot((e.x - start.x).toDouble(), (e.y - start.y).toDouble()) > 16) moved = true
                    if (mode == 2 && e.pointerCount >= 2) {
                        val d = Math.hypot((e.getX(0) - e.getX(1)).toDouble(), (e.getY(0) - e.getY(1)).toDouble()).toFloat()
                        var f = d / d0
                        f = (f * scale).coerceIn(1f, 8f) / scale
                        m.set(saved); m.postScale(f, f, mid.x, mid.y); iv.imageMatrix = m
                    }
                }
                android.view.MotionEvent.ACTION_POINTER_UP -> {
                    val v9 = FloatArray(9); m.getValues(v9); scale = (v9[Matrix.MSCALE_X] / base).coerceAtLeast(1f)
                    if (scale <= 1.02f) fit()
                    mode = 0
                }
                android.view.MotionEvent.ACTION_UP -> {
                    if (mode == 1 && !moved) dlg.dismiss()
                    mode = 0
                }
            }
            true
        }
        dlg.show()
    }
}
