package com.lancast.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import java.io.IOException
import kotlin.concurrent.thread

/** 前台服务：Android 10+ 要求屏幕采集必须跑在 mediaProjection 类型的前台服务里。 */
class CastService : Service() {

    companion object {
        @Volatile var current: CastService? = null
    }

    private var source: ScreenSource? = null
    private var finished = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        current = this
        finished = false
        startFg()
        val code = i.getIntExtra("code", 0)
        val data = readIntent(i)
        val mode = i.getStringExtra("mode") ?: "push"
        val host = i.getStringExtra("host") ?: ""
        val port = i.getIntExtra("port", P.PORT)
        val pin = i.getStringExtra("pin") ?: ""
        val audio = i.getBooleanExtra("audio", false)
        val preset = PRESETS[i.getIntExtra("preset", 0).coerceIn(0, PRESETS.size - 1)]
        Link.holdWifi(true)

        thread(name = "cast-start", isDaemon = true) {
            try {
                if (data == null) throw IOException("没有拿到屏幕录制授权")
                val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                val proj = mpm.getMediaProjection(code, data)
                val session: Session
                if (mode == "pull") {                                  // 电脑要看我的屏幕：会话已在 MainActivity 里认证并等待确认
                    session = Link.pendingPull ?: throw IOException("会话已失效，请让电脑重新发起")
                    Link.pendingPull = null
                    session.accept()
                } else {                                               // 我把屏幕投给电脑
                    session = Session.connect(host, port, pin, "push", Link.name)
                }
                val src = ScreenSource(applicationContext, proj, session, preset, audio) { reason -> finish(reason) }
                source = src
                src.start()
                Link.status("正在把屏幕投给「${session.peerName}」")
            } catch (e: Exception) {
                Link.pendingPull?.let { p -> Link.pendingPull = null; try { p.reject("手机端启动失败") } catch (ignored: Exception) { } }
                val s = source
                if (s != null) s.stop("投屏失败: ${e.message}") else finish("投屏失败: ${e.message}")
            }
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun readIntent(i: Intent): Intent? =
        if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra("data", Intent::class.java) else i.getParcelableExtra("data")

    fun shutdown(reason: String) {
        val s = source
        if (s != null) s.stop(reason) else finish(reason)
    }

    private fun finish(reason: String) {
        if (finished) return
        finished = true
        Link.busy = false
        Link.holdWifi(false)
        Link.status("投屏已结束：$reason")
        current = null
        source = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun startFg() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("cast", "投屏", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "cast")
            .setContentTitle("瞬流 正在投屏")
            .setContentText("点按回到应用，可在里面结束投屏")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    override fun onDestroy() {
        current = null
        super.onDestroy()
    }
}
