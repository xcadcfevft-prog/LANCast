package com.lancast.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import java.io.IOException
import kotlin.concurrent.thread

/** 前台服务：Android 10+ 要求屏幕采集必须跑在 mediaProjection 类型的前台服务里。 */
class CastService : Service() {

    companion object {
        @Volatile var current: CastService? = null
    }

    private var source: ScreenSource? = null
    private var finished = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (i.action == "stop") {                                  // 通知栏「结束」：被控制时的随时终止开关
            shutdown("已在通知栏结束")
            return START_NOT_STICKY
        }
        current = this
        finished = false
        startFg(false)
        val code = i.getIntExtra("code", 0)
        val data = readIntent(i)
        val mode = i.getStringExtra("mode") ?: "push"
        val host = i.getStringExtra("host") ?: ""
        val port = i.getIntExtra("port", P.PORT)
        val pin = i.getStringExtra("pin") ?: ""
        val audio = i.getBooleanExtra("audio", false)
        val ctl = i.getBooleanExtra("ctl", false)
        val preset = PRESETS[i.getIntExtra("preset", 0).coerceIn(0, PRESETS.size - 1)]
        Link.holdWifi(true)

        thread(name = "cast-start", isDaemon = true) {
            try {
                if (data == null) throw IOException("没有拿到屏幕录制授权")
                val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                val proj = mpm.getMediaProjection(code, data)
                val session: Session
                if (mode == "pull") {                                  // 电脑要看我的屏幕：会话已在 MainActivity 里认证并等待确认
                    session = Link.pendingPull ?: throw IOException("会话已失效，请让电脑重新发起")
                    Link.pendingPull = null
                    session.accept()
                } else {                                               // 我把屏幕投给电脑
                    session = Session.connect(host, port, pin, "push", Link.name, if (ctl) "grant" else "")
                    session.ctlAllowed = ctl
                }
                // 「极致无损」只有双方都是新版才能用；对方看不懂就退回第一档，别让对方对着乱码发愣
                var use = preset
                var note = ""
                if (use.lossless && !session.peerCaps.contains("lossless")) {
                    use = PRESETS[0]
                    note = "（对方版本不支持「极致无损」，已改用「${use.label}」）"
                }
                val src = ScreenSource(applicationContext, proj, session, use, audio) { reason -> finish(reason) }
                source = src
                src.start()
                if (session.ctlAllowed) startFg(true)
                Link.status("正在把屏幕投给「${session.peerName}」" + (if (use.lossless) "（极致无损 Beta）" else "") +
                    (if (session.ctlAllowed) "（允许对方控制）" else "") + note)
            } catch (e: Exception) {
                Link.pendingPull?.let { p -> Link.pendingPull = null; try { p.reject("手机端启动失败") } catch (ignored: Exception) { } }
                val s = source
                if (s != null) s.stop("投屏失败: ${e.message}") else finish("投屏失败: ${e.message}")
            }
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun readIntent(i: Intent): Intent? =
        if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra("data", Intent::class.java) else i.getParcelableExtra("data")

    fun shutdown(reason: String) {
        val s = source
        if (s != null) s.stop(reason) else finish(reason)
    }

    private fun finish(reason: String) {
        if (finished) return
        finished = true
        Link.busy = false
        Link.holdWifi(false)
        Link.status("投屏已结束：$reason")
        current = null
        source = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    @Suppress("DEPRECATION")
    private fun startFg(ctl: Boolean) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("cast", "投屏", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "cast")
            .setContentTitle("瞬流 正在投屏")
            .setContentText(if (ctl) "对方可以控制本机 · 点「结束」立即停止" else "点按回到应用，可在里面结束投屏")
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "结束",
                PendingIntent.getService(this, 1, Intent(this, CastService::class.java).setAction("stop"), PendingIntent.FLAG_IMMUTABLE))
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    override fun onDestroy() {
        current = null
        super.onDestroy()
    }
}
