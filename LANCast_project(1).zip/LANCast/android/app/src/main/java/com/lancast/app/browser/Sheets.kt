package com.lancast.app.browser

import android.annotation.SuppressLint
import android.content.Context
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewTreeObserver
import android.view.animation.AccelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/**
 * 底部弹出面板：半透明遮罩淡入 + 面板从底部滑入，关闭时反向；顶部有拖动条，往下拖可以收起。
 * 菜单、链接操作、确认框都用它，所以整个应用里弹出的东西动效和样子一致。
 * 用法：把 [layer] 加到页面最上层的 FrameLayout 里，再往 [panel] 里放内容并调用 [show]。
 */
class SheetLayer(private val ctx: Context, private val onChange: () -> Unit = {}) {

    class Action(val icon: IconView.Kind, val label: String, val danger: Boolean = false, val onClick: () -> Unit)

    private val scrim = View(ctx).apply {
        setBackgroundColor(0x66101218)
        setOnClickListener { hide() }
    }
    val panel = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        background = roundRect(Ui.WHITE, ctx.dp(24).toFloat(), topOnly = true)
        elevation = ctx.dp(16).toFloat()
        isClickable = true   // 点面板空白处不应落到遮罩上把面板关掉
    }
    val layer = FrameLayout(ctx).apply {
        visibility = View.GONE
        addView(scrim, FrameLayout.LayoutParams(-1, -1))
        addView(panel, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
    }
    private var closing = false

    /** 面板已打开（包括正在收起的那一小段时间）。 */
    val isShowing: Boolean get() = layer.visibility == View.VISIBLE

    fun show(heightPx: Int = FrameLayout.LayoutParams.WRAP_CONTENT) {
        val lp = panel.layoutParams as FrameLayout.LayoutParams
        if (lp.height != heightPx) {
            lp.height = heightPx
            panel.layoutParams = lp
        }
        closing = false
        panel.animate().cancel()
        scrim.animate().cancel()
        layer.visibility = View.VISIBLE
        scrim.alpha = 0f
        scrim.animate().alpha(1f).setDuration(220).start()
        // 先把面板放到屏幕外，等第一次布局完成、高度已知时再滑进来，避免闪一下
        panel.translationY = ctx.resources.displayMetrics.heightPixels.toFloat()
        panel.viewTreeObserver.addOnPreDrawListener(object : ViewTreeObserver.OnPreDrawListener {
            override fun onPreDraw(): Boolean {
                panel.viewTreeObserver.removeOnPreDrawListener(this)
                panel.translationY = panel.height.toFloat()
                panel.animate().translationY(0f).setDuration(260)
                    .setInterpolator(DecelerateInterpolator(1.8f)).start()
                return true
            }
        })
        onChange()
    }

    fun hide() {
        if (layer.visibility != View.VISIBLE || closing) return
        closing = true
        scrim.animate().cancel()
        scrim.animate().alpha(0f).setDuration(200).start()
        panel.animate().cancel()
        panel.animate().translationY(panel.height.toFloat()).setDuration(220)
            .setInterpolator(AccelerateInterpolator(1.5f))
            .withEndAction {
                layer.visibility = View.GONE
                closing = false
                panel.translationY = 0f
                onChange()
            }.start()
    }

    /** 面板顶部的拖动条：往下拖超过四分之一高度就收起，否则弹回去。 */
    @SuppressLint("ClickableViewAccessibility")
    fun grabber(): View {
        val bar = View(ctx).apply { background = roundRect(0xFFD3D6DF.toInt(), ctx.dp(2).toFloat()) }
        val box = FrameLayout(ctx)
        box.addView(bar, FrameLayout.LayoutParams(ctx.dp(36), ctx.dp(4), Gravity.CENTER))
        var downY = 0f
        box.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downY = e.rawY
                    panel.animate().cancel()
                }
                MotionEvent.ACTION_MOVE -> panel.translationY = maxOf(0f, e.rawY - downY)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (panel.translationY > panel.height * 0.25f) {
                        hide()
                    } else {
                        panel.animate().translationY(0f).setDuration(180)
                            .setInterpolator(DecelerateInterpolator()).start()
                    }
                }
            }
            true
        }
        return box
    }

    // ---------- 现成的两种内容：操作列表、确认框 ----------

    /** 标题（可空）+ 一列带图标的操作。点任意一项会先收起面板再执行。 */
    fun showActions(title: String?, sub: String?, actions: List<Action>) {
        panel.removeAllViews()
        panel.setPadding(0, 0, 0, ctx.dp(12))
        panel.addView(grabber(), LinearLayout.LayoutParams(-1, ctx.dp(24)))
        if (!title.isNullOrEmpty()) {
            val t = TextView(ctx).apply {
                text = title
                textSize = 16f
                typeface = Ui.MEDIUM
                setTextColor(Ui.TEXT)
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }
            val head = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(ctx.dp(24), ctx.dp(2), ctx.dp(24), ctx.dp(10))
                addView(t)
                if (!sub.isNullOrEmpty()) {
                    addView(TextView(ctx).apply {
                        text = sub
                        textSize = 12f
                        setTextColor(Ui.TEXT_SUB)
                        maxLines = 1
                        ellipsize = TextUtils.TruncateAt.MIDDLE
                    }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = ctx.dp(2) })
                }
            }
            panel.addView(head)
        }
        for (a in actions) panel.addView(actionRow(a), LinearLayout.LayoutParams(-1, ctx.dp(52)))
        show()
    }

    private fun actionRow(a: Action): View {
        val color = if (a.danger) Ui.RED else Ui.TEXT
        return LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(ctx.dp(24), 0, ctx.dp(24), 0)
            background = rippleOf(null)
            addView(IconView(ctx, a.icon, if (a.danger) Ui.RED else Ui.ICON), LinearLayout.LayoutParams(ctx.dp(22), ctx.dp(22)))
            addView(TextView(ctx).apply {
                text = a.label
                textSize = 15f
                setTextColor(color)
            }, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = ctx.dp(18) })
            setOnClickListener {
                hide()
                a.onClick()
            }
        }
    }

    /** 标题 + 说明 + 「取消 / 确认」两个按钮。[danger] 为真时确认按钮用红色。 */
    fun showConfirm(title: String, message: String?, ok: String, danger: Boolean, onOk: () -> Unit) {
        panel.removeAllViews()
        panel.setPadding(ctx.dp(20), 0, ctx.dp(20), ctx.dp(20))
        panel.addView(grabber(), LinearLayout.LayoutParams(-1, ctx.dp(24)))
        panel.addView(TextView(ctx).apply {
            text = title
            textSize = 18f
            typeface = Ui.MEDIUM
            setTextColor(Ui.TEXT)
            setPadding(ctx.dp(4), 0, ctx.dp(4), 0)
        })
        if (!message.isNullOrEmpty()) {
            panel.addView(TextView(ctx).apply {
                text = message
                textSize = 14f
                setLineSpacing(ctx.dp(3).toFloat(), 1f)
                setTextColor(Ui.TEXT_SUB)
                setPadding(ctx.dp(4), 0, ctx.dp(4), 0)
            }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = ctx.dp(8) })
        }
        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(button("取消", Ui.TEXT, Ui.SURFACE) { hide() }, LinearLayout.LayoutParams(0, ctx.dp(48), 1f))
            addView(
                button(ok, Ui.WHITE, if (danger) Ui.RED else Ui.PRIMARY) { hide(); onOk() },
                LinearLayout.LayoutParams(0, ctx.dp(48), 1f).apply { leftMargin = ctx.dp(12) }
            )
        }
        panel.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = ctx.dp(20) })
        show()
    }

    private fun button(label: String, fg: Int, bg: Int, action: () -> Unit): TextView = TextView(ctx).apply {
        text = label
        textSize = 15f
        typeface = Ui.MEDIUM
        gravity = Gravity.CENTER
        setTextColor(fg)
        background = rippleOf(roundRect(bg, ctx.dp(24).toFloat()), ctx.dp(24).toFloat())
        pressFeedback(0.96f)
        setOnClickListener { action() }
    }
}
