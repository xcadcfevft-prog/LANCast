package com.lancast.app

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.content.ContextCompat

/**
 * 瞬流「无损语音通话」（安卓端）。Windows 端对应 windows/voice.js，规范见 docs/PROTOCOL.md 第 16 节。
 *
 * 无损的做法（和 SonoBus 的「PCM」模式一样）：不经过任何有损编码器（不用 Opus / AAC），麦克风采到的采样点
 * 直接以 48 kHz / 16 bit 原始 PCM 发出，对方原样播放。传输走已有的 TCP 加密聊天连接（可靠、有序），
 * 网络层不会丢包、不会乱序；采集用 VOICE_COMMUNICATION 音频源 + 通话模式，并挂上系统回声消除 / 降噪，
 * 所以可以直接用扬声器外放，不必戴耳机（插了耳机 / 连了蓝牙耳机时自动走耳机）。
 *
 * 语音帧（T_CHAT_VOICE = 50，加密前的明文）：
 *   u8 ver(=1) | u8 声道数(=1) | u8 位深(=16) | u8 保留 | u32 采样率(=48000，大端) | u32 序号(大端) | 采样点(int16 小端)
 *   每帧 10 ms = 480 个采样点 = 960 字节，加上 12 字节头。
 * 信令（聊天加密通道里的 JSON）：{t:"vc", op:"invite"|"accept"|"reject"|"busy"|"end", rate, ch, bits, vid?:true（视频通话）}
 * 视频通话 = 同一套音频（仍是无损 PCM）+ 视频帧（T_CHAT_VIDEO = 51，见 VideoCall.kt），画质档位由发送方自己选。
 *
 * 线程：所有状态变化（呼叫 / 接听 / 挂断 / 收到信令 / 超时）都投递到主线程串行处理，不需要锁；
 * 采集线程只读 volatile 状态并调用 hub.sendVoice；收到的音频直接交给引擎的播放队列（自带锁）。
 */
object VoiceCall : ChatHub.VoiceSink {
    const val RATE = 48000
    const val CH = 1
    const val BITS = 16
    const val FRAME = 480            // 10 ms
    const val HDR = 12
    private const val RING_TIMEOUT_MS = 40_000L

    class State {
        @Volatile var phase = "idle"           // idle | calling（我呼出）| ringing（对方呼入）| active
        @Volatile var peerId: String? = null
        @Volatile var since = 0L
        @Volatile var muted = false
        @Volatile var speakerOn = true         // 扬声器外放（接通时有耳机就是 false）
        @Volatile var reason = ""              // 上一通电话结束的原因（界面提示用）
        @Volatile var rx = 0
        @Volatile var tx = 0
        @Volatile var video = false            // 这通电话带视频（呼叫时 / 来电时确定）
        @Volatile var camOn = true             // 我的摄像头开着（关了就只发音频）
        @Volatile var camOk = false            // 摄像头真的打开了（没授权 / 被占用就是 false，只收不发）
        @Volatile var tier = 0                 // 我发出的画质档位（VideoTiers）
        @Volatile var lastVideoRx = 0L         // 最近一次收到对方画面的时间
    }

    val st = State()

    /** 状态变化回调（主线程）：界面据此重画通话条 */
    @Volatile var onChange: (() -> Unit)? = null

    /** 视频画面回调（主线程）：对方的画面 / 我自己的小窗预览。界面不可见时设为 null，就不会白白解码 */
    @Volatile var onRemoteFrame: ((android.graphics.Bitmap) -> Unit)? = null
    @Volatile var onLocalFrame: ((android.graphics.Bitmap) -> Unit)? = null
    @Volatile private var cam: CameraEngine? = null
    @Volatile private var vrx: VideoRx? = null

    private val ui = Handler(Looper.getMainLooper())
    @Volatile private var engine: VoiceEngine? = null
    private var seq = 0
    private var lost = 0
    private var inviteSent = false
    private var timeoutRun: Runnable? = null
    private var inviteRun: Runnable? = null
    private var tickRun: Runnable? = null

    private fun hub() = ChatNet.hub
    private fun emit() { ui.post { onChange?.invoke() } }
    private fun sig(id: String, op: String): Boolean = try { hub().sendSignal(id, op, st.video) } catch (e: Exception) { false }
    private fun nameOf(id: String) = Link.pairs().firstOrNull { it.id == id }?.name ?: "对方"

    // ───────── 帧 ─────────
    fun pack(seq: Int, s: ShortArray): ByteArray {
        val b = ByteArray(HDR + s.size * 2)
        b[0] = 1; b[1] = CH.toByte(); b[2] = BITS.toByte(); b[3] = 0
        b[4] = (RATE ushr 24).toByte(); b[5] = (RATE ushr 16).toByte(); b[6] = (RATE ushr 8).toByte(); b[7] = RATE.toByte()
        b[8] = (seq ushr 24).toByte(); b[9] = (seq ushr 16).toByte(); b[10] = (seq ushr 8).toByte(); b[11] = seq.toByte()
        for (i in s.indices) {
            val v = s[i].toInt()
            b[HDR + i * 2] = v.toByte(); b[HDR + i * 2 + 1] = (v shr 8).toByte()
        }
        return b
    }

    /** 格式不对返回 null（调用方丢弃） */
    fun unpack(b: ByteArray): ShortArray? {
        if (b.size < HDR + 2 || (b.size - HDR) % 2 != 0 || b.size > HDR + 2 * RATE) return null
        if (b[0].toInt() != 1 || b[1].toInt() != CH || b[2].toInt() != BITS) return null
        val rate = ((b[4].toInt() and 0xFF) shl 24) or ((b[5].toInt() and 0xFF) shl 16) or ((b[6].toInt() and 0xFF) shl 8) or (b[7].toInt() and 0xFF)
        if (rate != RATE) return null
        val n = (b.size - HDR) / 2
        val s = ShortArray(n)
        for (i in 0 until n) s[i] = ((b[HDR + i * 2].toInt() and 0xFF) or (b[HDR + i * 2 + 1].toInt() shl 8)).toShort()
        return s
    }

    // ───────── 状态机（主线程）─────────
    private fun cancelTimers() {
        timeoutRun?.let { ui.removeCallbacks(it) }; timeoutRun = null
        inviteRun?.let { ui.removeCallbacks(it) }; inviteRun = null
        tickRun?.let { ui.removeCallbacks(it) }; tickRun = null
    }

    private fun stopVideo() {
        cam?.stop(); cam = null
        vrx?.stop(); vrx = null
        st.camOk = false
    }

    private fun reset(reason: String) {
        cancelTimers()
        stopVideo()
        engine?.stop(); engine = null
        CallService.stop()
        st.phase = "idle"; st.peerId = null; st.muted = false; st.video = false; st.camOn = true; st.reason = reason; seq = 0; lost = 0
        emit()
    }

    private fun activate() {
        cancelTimers()
        val id = st.peerId ?: return
        st.phase = "active"; st.since = System.currentTimeMillis(); st.reason = ""; st.rx = 0; st.tx = 0; seq = 0; lost = 0
        if (st.video) startVideo(id)
        CallService.start(st.video && st.camOk)
        val e = VoiceEngine { samples ->
            if (st.phase == "active") {
                val out = if (st.muted) ShortArray(samples.size) else samples      // 静音 = 发全零（保持流不断，对方不会因为缺数据而反复重新缓冲）
                if (hub().sendVoice(id, pack(seq++, out))) st.tx++
            }
        }
        engine = e
        Thread {
            try { e.start() } catch (ex: Throwable) {
                ui.post {
                    if (engine === e) { sig(id, "end"); reset("无法使用麦克风 / 扬声器：" + (ex.message ?: ex.javaClass.simpleName)) }
                }
            }
        }.also { it.isDaemon = true }.start()
        val tick = object : Runnable {
            override fun run() {
                if (st.phase != "active") return
                if (hub().isConnected(id)) lost = 0 else if (++lost >= 6) { reset("连接已断开"); return }      // 加密连接断了 6 秒就结束通话
                emit()                                                                                       // 顺便刷新通话时长
                ui.postDelayed(this, 1000)
            }
        }
        tickRun = tick; ui.postDelayed(tick, 1000)
        emit()
    }

    /** 视频通话激活：开解码线程 + 相机（没有相机权限 / 相机打不开就只收不发，通话照常） */
    private fun startVideo(id: String) {
        vrx = VideoRx { bmp -> if (onRemoteFrame != null) ui.post { onRemoteFrame?.invoke(bmp) } }
        st.camOk = false
        val granted = Link.app.checkSelfPermission(android.Manifest.permission.CAMERA) == android.content.pm.PackageManager.PERMISSION_GRANTED
        if (!granted) return
        val c = CameraEngine({ st.tier },
            { f -> if (st.phase == "active" && st.camOn) hub().sendVideo(id, f) },
            { b -> if (onLocalFrame != null) ui.post { onLocalFrame?.invoke(b) } },
            { ui.post { if (cam != null) { cam?.stop(); cam = null; st.camOk = false; emit() } } })      // 相机打不开 / 被占用：只收不发，通话照常
        cam = c; st.camOk = true
        c.start()
    }

    /** 通话中改画质档位（只影响我发出去的画面） */
    fun setTier(i: Int) {
        st.tier = i.coerceIn(0, VideoTiers.ALL.size - 1); VideoTiers.save(st.tier)
        val c = cam
        c?.retier()
        emit()
    }

    fun flipCamera() { cam?.flip() }

    fun camera(on: Boolean) { st.camOn = on; cam?.enabled = on; emit() }

    /** 我呼出（调用前界面要已经拿到麦克风权限；视频通话还要相机权限）。加密连接还没建好时每秒重试发信令，直到超时 */
    fun start(peerId: String, video: Boolean = false, tier: Int = VideoTiers.saved()): Boolean {
        if (st.phase != "idle") return false
        st.video = video; st.tier = tier.coerceIn(0, VideoTiers.ALL.size - 1); st.camOn = true
        st.phase = "calling"; st.peerId = peerId; st.since = System.currentTimeMillis(); st.reason = ""; inviteSent = false
        ChatNet.start()
        val t0 = System.currentTimeMillis()
        val r = object : Runnable {
            override fun run() {
                if (st.phase != "calling" || st.peerId != peerId) return
                if (System.currentTimeMillis() - t0 > RING_TIMEOUT_MS) { sig(peerId, "end"); reset("对方没有接听"); return }
                if (!inviteSent && sig(peerId, "invite")) inviteSent = true
                ui.postDelayed(this, 1000)
            }
        }
        inviteRun = r
        emit(); r.run()
        return true
    }

    fun answer() {
        if (st.phase != "ringing") return
        val id = st.peerId ?: return
        sig(id, "accept"); activate()
    }

    fun decline() {
        if (st.phase != "ringing") return
        st.peerId?.let { sig(it, "reject") }
        reset("已拒绝")
    }

    fun hangup() {
        val was = st.phase
        if (was == "idle") return
        st.peerId?.let { sig(it, "end") }
        reset(if (was == "active") "通话已结束" else if (was == "calling") "已取消呼叫" else "已拒绝")
    }

    fun mute(on: Boolean) { st.muted = on; emit() }

    fun peerGone(peerId: String) { ui.post { if (st.peerId == peerId && st.phase != "idle") reset("已取消配对") } }

    /** 读线程里调用：投递到主线程处理 */
    override fun onSignal(peerId: String, op: String, vid: Boolean) { ui.post { handleSignal(peerId, op, vid) } }

    private fun handleSignal(peerId: String, op: String, vid: Boolean) {
        if (op == "invite") {
            when {
                st.phase == "idle" -> {
                    st.phase = "ringing"; st.peerId = peerId; st.since = System.currentTimeMillis(); st.reason = ""
                    st.video = vid; st.camOn = true; st.tier = VideoTiers.saved()
                    val r = Runnable { if (st.phase == "ringing" && st.peerId == peerId) { sig(peerId, "end"); reset("未接来电") } }
                    timeoutRun = r; ui.postDelayed(r, RING_TIMEOUT_MS)
                    if (Link.listener == null) Notice.chat(peerId, nameOf(peerId), if (vid) "📹 邀请你视频通话（点开应用接听）" else "📞 邀请你无损语音通话（点开应用接听）")     // 应用在后台：弹通知
                    emit()
                }
                st.peerId == peerId && st.phase == "calling" -> { sig(peerId, "accept"); activate() }      // 双方同时互相呼叫：各自把对方的呼叫当作接听
                st.peerId == peerId && st.phase == "active" -> sig(peerId, "accept")                       // 对方重复呼叫：重发接听
                else -> sig(peerId, "busy")
            }
            return
        }
        if (st.peerId != peerId) return
        when (op) {
            "accept" -> if (st.phase == "calling") activate()
            "reject" -> if (st.phase == "calling") reset("对方拒绝了通话")
            "busy" -> if (st.phase == "calling") reset("对方正在通话中")
            "end" -> if (st.phase != "idle") reset(when (st.phase) { "ringing" -> "对方取消了呼叫"; "calling" -> "对方没有接听"; else -> "对方已挂断" })
        }
    }

    /** 读线程里调用：直接交给引擎的播放队列 */
    override fun onAudio(peerId: String, buf: ByteArray) {
        val e = engine ?: return
        if (st.phase != "active" || st.peerId != peerId) return
        val s = unpack(buf) ?: return
        st.rx++
        e.play(s)
    }

    /** 读线程里调用：只保留最新一帧，交给解码线程 */
    override fun onVideo(peerId: String, buf: ByteArray) {
        if (st.phase != "active" || st.peerId != peerId || !st.video) return
        st.lastVideoRx = System.currentTimeMillis()
        if (onRemoteFrame == null) return                      // 界面不可见：不解码
        vrx?.push(buf)
    }

    /** 启动时挂上：ChatNet.start() 之后调用一次 */
    fun install() { hub().voice = this }
}

/**
 * 音频引擎：AudioRecord 采集（48 kHz 单声道 16 bit，每 480 个采样点一帧）+ AudioTrack 播放。
 * 播放端有个小缓冲：先攒 60 ms 再开始播，缺数据时补静音；积压超过 400 ms 才丢旧数据追上进度。
 * 正常网络下积压远小于 400 ms，所以一个采样点都不会丢。
 */
class VoiceEngine(private val onFrame: (ShortArray) -> Unit) {
    @Volatile private var dead = false
    private var rec: AudioRecord? = null
    private var track: AudioTrack? = null
    private var capThread: Thread? = null
    private var playThread: Thread? = null
    private val q = java.util.ArrayDeque<ShortArray>()
    private var queued = 0
    private var primed = false
    private val target = VoiceCall.RATE * 60 / 1000          // 2880
    private val maxQueued = VoiceCall.RATE * 400 / 1000      // 19200

    @SuppressLint("MissingPermission")
    @Synchronized
    fun start() {
        if (dead) return
        val rate = VoiceCall.RATE
        val frame = VoiceCall.FRAME
        val minIn = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minIn <= 0) throw IllegalStateException("设备不支持 48 kHz 单声道采集")
        val am = Link.app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        enterCommMode(am)                                        // 通话模式 + 外放：系统回声消除才有参考信号
        val src = MediaRecorder.AudioSource.VOICE_COMMUNICATION  // 自带回声消除 / 降噪的通话音频源
        val r = AudioRecord(src, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minIn, frame * 2 * 4))
        if (r.state != AudioRecord.STATE_INITIALIZED) {
            r.release(); leaveCommMode()
            throw IllegalStateException("无法打开麦克风（没有授权，或被其他应用占用）")
        }
        val minOut = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val t = try {
            AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(rate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(maxOf(minOut, frame * 2 * 4))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
                .build()
        } catch (e: Throwable) { r.release(); leaveCommMode(); throw e }
        if (dead) { r.release(); t.release(); leaveCommMode(); return }
        rec = r; track = t
        attachEffects(r.audioSessionId)
        r.startRecording()
        t.play()
        capThread = Thread {
            val buf = ShortArray(frame)
            while (!dead) {
                var n = 0
                while (n < frame && !dead) {
                    val k = r.read(buf, n, frame - n)
                    if (k < 0) return@Thread                      // 设备出错（比如被别的应用抢走）
                    n += k
                }
                if (n == frame) onFrame(buf.copyOf())
            }
        }.also { it.name = "voice-cap"; it.isDaemon = true; it.priority = Thread.MAX_PRIORITY; it.start() }
        playThread = Thread {
            val silence = ShortArray(frame)
            while (!dead) {
                var f: ShortArray? = null
                synchronized(q) {
                    if (!primed && queued >= target) primed = true
                    if (primed) {
                        f = q.pollFirst()
                        val got = f
                        if (got != null) queued -= got.size else primed = false
                    }
                }
                val out = f ?: silence
                if (t.write(out, 0, out.size) < 0) return@Thread    // 阻塞写入，节奏由声卡决定
            }
        }.also { it.name = "voice-play"; it.isDaemon = true; it.priority = Thread.MAX_PRIORITY; it.start() }
    }

    private var prevMode = AudioManager.MODE_NORMAL
    private var prevSpeaker = false
    private var commOn = false
    private var aec: android.media.audiofx.AcousticEchoCanceler? = null
    private var ns: android.media.audiofx.NoiseSuppressor? = null

    /** 切到通话模式；没有耳机（有线 / 蓝牙 / USB）时打开扬声器外放 */
    @Suppress("DEPRECATION")
    private fun enterCommMode(am: AudioManager) {
        try {
            prevMode = am.mode; prevSpeaker = am.isSpeakerphoneOn
            am.mode = AudioManager.MODE_IN_COMMUNICATION
            commOn = true
            val outs = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
            val headset = outs.any {
                when (it.type) {
                    android.media.AudioDeviceInfo.TYPE_WIRED_HEADSET, android.media.AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
                    android.media.AudioDeviceInfo.TYPE_BLUETOOTH_SCO, android.media.AudioDeviceInfo.TYPE_BLUETOOTH_A2DP,
                    android.media.AudioDeviceInfo.TYPE_USB_HEADSET -> true
                    else -> false
                }
            }
            st.speakerOn = !headset
            if (Build.VERSION.SDK_INT >= 31) {
                if (!headset) outs.firstOrNull { it.type == android.media.AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }?.let { am.setCommunicationDevice(it) }
            } else {
                am.isSpeakerphoneOn = !headset
            }
        } catch (ignored: Exception) { }
    }

    /** 通话中切换扬声器 / 听筒 */
    @Suppress("DEPRECATION")
    fun speaker(on: Boolean) {
        st.speakerOn = on
        try {
            val am = Link.app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (commOn) {
                if (Build.VERSION.SDK_INT >= 31) {
                    val want = if (on) android.media.AudioDeviceInfo.TYPE_BUILTIN_SPEAKER else android.media.AudioDeviceInfo.TYPE_BUILTIN_EARPIECE
                    val d = am.availableCommunicationDevices.firstOrNull { it.type == want }
                    if (d != null) am.setCommunicationDevice(d) else if (!on) am.clearCommunicationDevice()
                } else am.isSpeakerphoneOn = on
            }
        } catch (ignored: Exception) { }
        emit()
    }

    /** 恢复通话前的音频模式 */
    @Suppress("DEPRECATION")
    private fun leaveCommMode() {
        if (!commOn) return
        commOn = false
        try {
            val am = Link.app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (Build.VERSION.SDK_INT >= 31) am.clearCommunicationDevice()
            else am.isSpeakerphoneOn = prevSpeaker
            am.mode = prevMode
        } catch (ignored: Exception) { }
    }

    /** 给采集会话挂上系统回声消除 / 降噪（机型支持才有；VOICE_COMMUNICATION 源本身通常已带） */
    private fun attachEffects(session: Int) {
        try {
            if (android.media.audiofx.AcousticEchoCanceler.isAvailable()) aec = android.media.audiofx.AcousticEchoCanceler.create(session)?.also { it.enabled = true }
        } catch (ignored: Throwable) { }
        try {
            if (android.media.audiofx.NoiseSuppressor.isAvailable()) ns = android.media.audiofx.NoiseSuppressor.create(session)?.also { it.enabled = true }
        } catch (ignored: Throwable) { }
    }

    fun play(s: ShortArray) {
        synchronized(q) {
            q.addLast(s); queued += s.size
            if (queued > maxQueued) {                              // 积压太多（网络卡了一阵又一下子涌过来）：丢最旧的，追到 60 ms
                while (queued > target && q.isNotEmpty()) queued -= q.pollFirst().size
            }
        }
    }

    @Synchronized
    fun stop() {
        dead = true
        try { rec?.stop() } catch (ignored: Exception) { }          // 先停采集，让阻塞的 read 返回
        capThread?.let { try { it.join(300) } catch (ignored: Exception) { } }
        playThread?.let { try { it.join(300) } catch (ignored: Exception) { } }
        try { rec?.release() } catch (ignored: Exception) { }
        try { track?.pause(); track?.flush(); track?.release() } catch (ignored: Exception) { }
        try { aec?.release() } catch (ignored: Throwable) { }
        try { ns?.release() } catch (ignored: Throwable) { }
        aec = null; ns = null
        leaveCommMode()
        rec = null; track = null
        synchronized(q) { q.clear(); queued = 0 }
    }
}

/**
 * 通话期间的前台服务（类型 microphone）：Android 11+ 不允许后台应用采集麦克风，
 * 有了它，通话中切到别的应用或锁屏，对方也能一直听到你。通话结束自动停止。
 */
class CallService : Service() {
    companion object {
        private const val CH = "lancast_call"
        private const val NID = 5

        fun start(camera: Boolean = false) {
            try { ContextCompat.startForegroundService(Link.app, Intent(Link.app, CallService::class.java).putExtra("cam", camera)) } catch (ignored: Exception) { }
        }

        fun stop() {
            try { Link.app.stopService(Intent(Link.app, CallService::class.java)) } catch (ignored: Exception) { }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CH, "语音通话", NotificationManager.IMPORTANCE_LOW))
            val pi = PendingIntent.getActivity(this, 5, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE)
            val cam = intent?.getBooleanExtra("cam", false) == true
            val n = Notification.Builder(this, CH)
                .setSmallIcon(android.R.drawable.stat_sys_phone_call)
                .setContentTitle(if (cam) "瞬流 视频通话中" else "瞬流 无损语音通话中")
                .setContentText("点按回到应用挂断")
                .setContentIntent(pi)
                .setOngoing(true)
                .build()
            if (Build.VERSION.SDK_INT >= 30) {
                val type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE or (if (cam) ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA else 0)
                startForeground(NID, n, type)
            } else startForeground(NID, n)
        } catch (e: Exception) {
            stopSelf()
        }
        return START_NOT_STICKY
    }
}
