package com.lancast.app.browser

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Bundle
import android.widget.Toast

/**
 * 查找手机上已安装的外部「播放器 / 下载器 / 浏览器」，并把资源链接交给它们。
 * - 播放器：系统里能处理 video 或 audio 类型（m3u8 还包括 application/x-mpegURL）的应用，如 MX Player、VLC；
 * - 下载器：内置的一份常见下载器包名清单（ADM、1DM、FDM、迅雷…），装了才会出现；
 * - 浏览器：系统里所有能打开 http 链接的浏览器。
 * Android 11+ 需要在 AndroidManifest 里用 <queries> 声明才能查到这些应用（已声明）。
 * 传给外部应用的请求头只有 User-Agent 和 Referer，不会把 Cookie 交给第三方应用。
 */
object ExternalApps {

    class App(
        val pkg: String,
        val label: String,
        val icon: Drawable,
        val component: ComponentName?,   // 播放器：具体的 Activity
        val mime: String?                // 播放器：匹配到的 MIME 类型
    )

    /** 常见下载器的包名（没安装的会被自动忽略）。 */
    private val DOWNLOADERS = listOf(
        "com.dv.adm",                           // ADM
        "com.dv.adm.pay",                       // ADM Pro
        "idm.internet.download.manager.plus",   // 1DM+
        "idm.internet.download.manager",        // 1DM
        "org.freedownloadmanager.fdm",          // Free Download Manager
        "com.xunlei.downloadprovider",          // 迅雷
        "com.gianlu.aria2app"                   // Aria2App
    )

    @Suppress("DEPRECATION")
    fun players(ctx: Context, url: String, audio: Boolean, hls: Boolean): List<App> {
        val pm = ctx.packageManager
        val mpd = (Uri.parse(url).path ?: "").endsWith(".mpd", ignoreCase = true)
        val mimes = when {
            audio -> listOf("audio/*")
            hls -> listOf("video/*", "application/x-mpegURL", "application/vnd.apple.mpegurl")
            mpd -> listOf("video/*", "application/dash+xml")   // 系统播放器不支持 DASH，靠外部播放器
            else -> listOf("video/*")
        }
        val out = LinkedHashMap<String, App>()
        for (m in mimes) {
            val probe = Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(url), m)
            val found = try {
                pm.queryIntentActivities(probe, PackageManager.MATCH_DEFAULT_ONLY)
            } catch (e: Exception) {
                emptyList<ResolveInfo>()
            }
            for (ri in found) {
                val ai = ri.activityInfo ?: continue
                val pkg = ai.packageName
                if (pkg == ctx.packageName || pkg in DOWNLOADERS || out.containsKey(pkg)) continue
                out[pkg] = App(pkg, ri.loadLabel(pm).toString(), ri.loadIcon(pm), ComponentName(pkg, ai.name), m)
            }
        }
        return out.values.toList()
    }

    @Suppress("DEPRECATION")
    fun browsers(ctx: Context): List<App> {
        val pm = ctx.packageManager
        // 只带 scheme、不带域名的链接，只有真正的浏览器会匹配（排除只认特定网站的应用）
        val probe = Intent(Intent.ACTION_VIEW, Uri.parse("http://")).addCategory(Intent.CATEGORY_BROWSABLE)
        val found = try {
            pm.queryIntentActivities(probe, PackageManager.MATCH_ALL)
        } catch (e: Exception) {
            emptyList<ResolveInfo>()
        }
        val out = LinkedHashMap<String, App>()
        for (ri in found) {
            val ai = ri.activityInfo ?: continue
            val pkg = ai.packageName
            if (pkg == ctx.packageName || pkg in DOWNLOADERS || out.containsKey(pkg)) continue
            out[pkg] = App(pkg, ri.loadLabel(pm).toString(), ri.loadIcon(pm), null, null)
        }
        return out.values.toList()
    }

    @Suppress("DEPRECATION")
    fun downloaders(ctx: Context): List<App> {
        val pm = ctx.packageManager
        val out = ArrayList<App>()
        for (pkg in DOWNLOADERS) {
            try {
                val ai = pm.getApplicationInfo(pkg, 0)
                out.add(App(pkg, pm.getApplicationLabel(ai).toString(), pm.getApplicationIcon(ai), null, null))
            } catch (e: PackageManager.NameNotFoundException) {
                // 没安装
            }
        }
        return out
    }

    // ---------- 调用 ----------

    private fun withHeaders(i: Intent, ua: String?, referer: String?, cookie: String? = null): Intent {
        val kv = ArrayList<String>()
        if (ua != null) { kv.add("User-Agent"); kv.add(ua) }
        if (referer != null) { kv.add("Referer"); kv.add(referer) }
        if (cookie != null) { kv.add("Cookie"); kv.add(cookie) }
        // MX Player 等读取 "headers"（键值交替的字符串数组）；传统浏览器 / 下载器读取下面的 Bundle
        i.putExtra("headers", kv.toTypedArray())
        i.putExtra("com.android.browser.headers", Bundle().apply {
            if (ua != null) putString("User-Agent", ua)
            if (referer != null) putString("Referer", referer)
            if (cookie != null) putString("Cookie", cookie)
        })
        return i
    }

    fun launchPlayer(act: Activity, app: App, url: String, title: String, ua: String?, referer: String?, cookie: String? = null): Boolean {
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(url), app.mime ?: "video/*")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        app.component?.let { i.component = it }
        i.putExtra("title", title)
        return safeStart(act, withHeaders(i, ua, referer, cookie))
    }

    /** “更多…”：让系统弹出所有能播放该资源的应用。 */
    fun chooseAnyPlayer(act: Activity, url: String, audio: Boolean, title: String, ua: String?, referer: String?, cookie: String? = null): Boolean {
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(url), if (audio) "audio/*" else "video/*")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        i.putExtra("title", title)
        return safeStart(act, Intent.createChooser(withHeaders(i, ua, referer, cookie), "选择播放器"))
    }

    fun launchBrowser(act: Activity, app: App, url: String) {
        safeStart(act, Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage(app.pkg))
    }

    fun launchDownloader(act: Activity, app: App, url: String, fileName: String, ua: String, referer: String?) {
        val view = Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage(app.pkg)
        view.putExtra("com.android.extra.filename", fileName)
        try {
            act.startActivity(withHeaders(view, ua, referer))
        } catch (e: ActivityNotFoundException) {
            // 个别下载器不认 VIEW，退一步用“分享文本”的方式把链接交给它
            val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, url).setPackage(app.pkg)
            safeStart(act, send)
        } catch (e: SecurityException) {
            toast(act, "无法打开 ${app.label}")
        }
    }

    /** “更多…”：用系统分享面板把链接发给任意应用（含没在清单里的下载器）。 */
    fun shareLink(act: Activity, url: String) {
        val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, url)
        safeStart(act, Intent.createChooser(send, "用其他应用下载 / 分享"))
    }

    private fun safeStart(act: Activity, i: Intent): Boolean {
        return try {
            act.startActivity(i)
            true
        } catch (e: ActivityNotFoundException) {
            toast(act, "没有可用的应用可以打开")
            false
        } catch (e: SecurityException) {
            toast(act, "无法打开该应用")
            false
        }
    }

    private fun toast(ctx: Context, s: String) = Toast.makeText(ctx, s, Toast.LENGTH_SHORT).show()
}
