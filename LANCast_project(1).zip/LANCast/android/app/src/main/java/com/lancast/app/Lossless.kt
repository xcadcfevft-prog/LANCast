package com.lancast.app

import java.util.concurrent.Callable
import java.util.concurrent.ExecutorService
import java.util.zip.Deflater
import java.util.zip.Inflater

/**
 * 「极致无损（Beta）」视频格式 —— 纯 JVM 逻辑（不依赖 Android API），与 windows/lossless.js 逐字节对应，
 * 规范见 docs/PROTOCOL.md 第 6.1 节。
 *
 * 画面以原生分辨率、源帧率取下来，按 64×64 分块与「上一次已发送的画面」比较，只发有变化的块（首帧 / 对方要关键帧时发整幅）；
 * 块内是原始 RGB24，再用 DEFLATE(level 1) 做纯无损压缩。没有任何有损环节。
 *
 * 像素约定：Int 小端 = R | G<<8 | B<<16 | A<<24（RGBA 字节序）。
 * VFRAME 载荷（大端）：u8 ver(=1) | u8 nStripes | { u16 firstTileRow | u16 tileRows | u32 compLen | compLen 字节 raw-DEFLATE } × n
 * 解压后 = 变化位图(ceil(tilesX*tileRows/8) 字节，LSB 优先，按行优先) + 各变化块像素（tw*th*3 字节，行优先，R G B）。
 */
object LosslessCodec {
    const val TILE = 64
    const val VER = 1
    private const val MAX_STRIPES = 8
    private const val LEVEL = 1

    fun tilesX(w: Int) = (w + TILE - 1) / TILE
    fun tilesY(h: Int) = (h + TILE - 1) / TILE

    private fun stripeRanges(ty: Int): List<IntArray> {
        val n = minOf(ty, MAX_STRIPES)
        val per = (ty + n - 1) / n
        val r = ArrayList<IntArray>()
        var a = 0
        while (a < ty) {
            r.add(intArrayOf(a, minOf(ty, a + per)))
            a += per
        }
        return r
    }

    /** 找出相对 prev 有变化的块；prev 为 null 或 full 时全部算变化 */
    fun diffTiles(cur: IntArray, prev: IntArray?, w: Int, h: Int, full: Boolean): BooleanArray {
        val tx = tilesX(w)
        val ty = tilesY(h)
        val ch = BooleanArray(tx * ty)
        if (full || prev == null) {
            ch.fill(true)
            return ch
        }
        for (j in 0 until ty) {
            val y0 = j * TILE
            val y1 = minOf(h, y0 + TILE)
            for (y in y0 until y1) {
                val o = y * w
                for (i in 0 until tx) {
                    if (ch[j * tx + i]) continue
                    val x0 = i * TILE
                    val x1 = minOf(w, x0 + TILE)
                    var p = o + x0
                    val e = o + x1
                    while (p < e) {
                        if (cur[p] != prev[p]) {
                            ch[j * tx + i] = true
                            break
                        }
                        p++
                    }
                }
            }
        }
        return ch
    }

    private fun deflate(raw: ByteArray, len: Int): ByteArray {
        val d = Deflater(LEVEL, true)
        try {
            d.setInput(raw, 0, len)
            d.finish()
            var buf = ByteArray(maxOf(256, len / 2 + 64))
            var n = 0
            while (!d.finished()) {
                if (n == buf.size) buf = buf.copyOf(buf.size * 2)
                n += d.deflate(buf, n, buf.size - n)
            }
            return buf.copyOf(n)
        } finally {
            d.end()
        }
    }

    /** 编码一幅画面。返回 VFRAME 载荷；没有任何变化且不是整幅时返回 null。pool 用来并行压缩各条带。
     *  reserve：在返回数组最前面留出的字节数（载荷从 reserve 处开始），调用方用来直接放 16 字节包头，省一次整帧拷贝。 */
    fun encode(cur: IntArray, prev: IntArray?, w: Int, h: Int, full: Boolean, pool: ExecutorService, reserve: Int = 0): ByteArray? {
        val tx = tilesX(w)
        val ch = diffTiles(cur, prev, w, h, full)
        val jobs = ArrayList<Pair<IntArray, java.util.concurrent.Future<ByteArray>>>()
        for (rg in stripeRanges(tilesY(h))) {
            val r0 = rg[0]
            val r1 = rg[1]
            var any = false
            for (j in r0 until r1) for (i in 0 until tx) if (ch[j * tx + i]) any = true
            if (!any) continue
            jobs.add(rg to pool.submit(Callable { packStripe(cur, ch, w, h, r0, r1) }))
        }
        if (jobs.isEmpty()) return null
        val parts = ArrayList<ByteArray>()
        var total = reserve + 2
        for ((_, f) in jobs) {
            val c = f.get()
            parts.add(c)
            total += 8 + c.size
        }
        val out = ByteArray(total)
        out[reserve] = VER.toByte()
        out[reserve + 1] = parts.size.toByte()
        var o = reserve + 2
        for (k in jobs.indices) {
            val rg = jobs[k].first
            val c = parts[k]
            putU16(out, o, rg[0])
            putU16(out, o + 2, rg[1] - rg[0])
            putU32(out, o + 4, c.size)
            System.arraycopy(c, 0, out, o + 8, c.size)
            o += 8 + c.size
        }
        return out
    }

    private fun packStripe(cur: IntArray, ch: BooleanArray, w: Int, h: Int, r0: Int, r1: Int): ByteArray {
        val tx = tilesX(w)
        val rows = r1 - r0
        val bm = (tx * rows + 7) / 8
        var bytes = 0
        for (j in r0 until r1) for (i in 0 until tx) {
            if (ch[j * tx + i]) bytes += minOf(TILE, w - i * TILE) * minOf(TILE, h - j * TILE) * 3
        }
        val raw = ByteArray(bm + bytes)
        var q = bm
        var k = 0
        for (j in r0 until r1) for (i in 0 until tx) {
            if (ch[j * tx + i]) {
                raw[k shr 3] = (raw[k shr 3].toInt() or (1 shl (k and 7))).toByte()
                val x0 = i * TILE
                val x1 = minOf(w, x0 + TILE)
                val y0 = j * TILE
                val y1 = minOf(h, y0 + TILE)
                for (y in y0 until y1) {
                    var p = y * w + x0
                    val e = y * w + x1
                    while (p < e) {
                        val v = cur[p]
                        raw[q] = v.toByte()
                        raw[q + 1] = (v shr 8).toByte()
                        raw[q + 2] = (v shr 16).toByte()
                        q += 3
                        p++
                    }
                }
            }
            k++
        }
        return deflate(raw, raw.size)
    }

    private fun putU16(b: ByteArray, o: Int, v: Int) {
        b[o] = (v shr 8).toByte()
        b[o + 1] = v.toByte()
    }

    private fun putU32(b: ByteArray, o: Int, v: Int) {
        b[o] = (v ushr 24).toByte()
        b[o + 1] = (v ushr 16).toByte()
        b[o + 2] = (v ushr 8).toByte()
        b[o + 3] = v.toByte()
    }

    private fun u16(b: ByteArray, o: Int) = ((b[o].toInt() and 0xFF) shl 8) or (b[o + 1].toInt() and 0xFF)
    private fun u32(b: ByteArray, o: Int): Long =
        ((b[o].toLong() and 0xFF) shl 24) or ((b[o + 1].toLong() and 0xFF) shl 16) or ((b[o + 2].toLong() and 0xFF) shl 8) or (b[o + 3].toLong() and 0xFF)

    /**
     * 解码端：维护一幅完整画面 px（ARGB，直接可给 Bitmap.setPixels，不透明）。
     * apply() 解一帧并返回被改动的行区间 [y0, y1)；数据有问题就抛异常（调用方据此向对方要整幅）。
     */
    class Decoder(val w: Int, val h: Int) {
        val px = IntArray(w * h).also { it.fill(0xFF000000.toInt()) }
        var started = false
            private set

        private class Stripe(val r0: Int, val rows: Int, val comp: ByteArray, val off: Int, val len: Int)

        fun apply(payload: ByteArray, full: Boolean, pool: ExecutorService): IntArray {
            val tx = tilesX(w)
            val ty = tilesY(h)
            if (!started && !full) throw IllegalStateException("need full frame")
            if (payload.size < 2 || payload[0].toInt() != VER) throw IllegalArgumentException("bad ver")
            val n = payload[1].toInt() and 0xFF
            if (n < 1) throw IllegalArgumentException("bad stripes")
            var o = 2
            val stripes = ArrayList<Stripe>()
            for (s in 0 until n) {
                if (o + 8 > payload.size) throw IllegalArgumentException("truncated")
                val r0 = u16(payload, o)
                val rows = u16(payload, o + 2)
                val len = u32(payload, o + 4)
                o += 8
                if (rows == 0 || r0 + rows > ty || len < 0 || o + len > payload.size) throw IllegalArgumentException("bad stripe")
                stripes.add(Stripe(r0, rows, payload, o, len.toInt()))
                o += len.toInt()
            }
            val futs = stripes.map { st -> pool.submit(Callable { inflate(st, tx) }) }
            val raws = futs.map { it.get() }
            var y0 = h
            var y1 = 0
            for (si in stripes.indices) {
                val st = stripes[si]
                val raw = raws[si]
                val bm = (tx * st.rows + 7) / 8
                if (raw.size < bm) throw IllegalArgumentException("short stripe")
                var q = bm
                var k = 0
                for (j in st.r0 until st.r0 + st.rows) for (i in 0 until tx) {
                    if ((raw[k shr 3].toInt() and (1 shl (k and 7))) != 0) {
                        val x0 = i * TILE
                        val x1 = minOf(w, x0 + TILE)
                        val ya = j * TILE
                        val yb = minOf(h, ya + TILE)
                        if (q + (x1 - x0) * (yb - ya) * 3 > raw.size) throw IllegalArgumentException("short tile data")
                        for (y in ya until yb) {
                            var p = y * w + x0
                            val e = y * w + x1
                            while (p < e) {
                                px[p] = (0xFF shl 24) or ((raw[q].toInt() and 0xFF) shl 16) or ((raw[q + 1].toInt() and 0xFF) shl 8) or (raw[q + 2].toInt() and 0xFF)
                                q += 3
                                p++
                            }
                        }
                        if (ya < y0) y0 = ya
                        if (yb > y1) y1 = yb
                    }
                    k++
                }
                if (q != raw.size) throw IllegalArgumentException("stripe size mismatch")
            }
            started = true
            return intArrayOf(minOf(y0, y1), y1)
        }

        private fun inflate(st: Stripe, tx: Int): ByteArray {
            val maxOut = (tx * st.rows + 7) / 8 + (minOf(h, (st.r0 + st.rows) * TILE) - st.r0 * TILE) * w * 3
            val inf = Inflater(true)
            try {
                inf.setInput(st.comp, st.off, st.len)
                val out = ByteArray(maxOut + 1)                 // 多留 1 字节：写满 maxOut 还没结束 = 数据比声明的大，直接拒绝
                var n = 0
                while (!inf.finished()) {
                    val r = inf.inflate(out, n, out.size - n)
                    n += r
                    if (n > maxOut) throw IllegalArgumentException("stripe too large")
                    if (r == 0 && (inf.needsInput() || inf.needsDictionary())) throw IllegalArgumentException("truncated deflate")
                }
                return out.copyOf(n)
            } finally {
                inf.end()
            }
        }
    }
}
