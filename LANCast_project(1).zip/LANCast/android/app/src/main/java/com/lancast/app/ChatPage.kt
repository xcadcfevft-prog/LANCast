package com.lancast.app

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 聊天页（纯代码布局，和应用其它页面同风格）。顶栏：返回 / 名字 + 🔒状态 / 发文件 / 屏幕 / 更多；
 * 中间：消息气泡、表情包卡片、文件卡片（复用文件互传的进度）；底部：表情按钮 + 输入框 + 发送，表情面板可切换。
 * 发文件 / 屏幕互投直接调用首页已有的功能（回调给 MainActivity）。
 */
class ChatPage(
    private val ctx: Context,
    private val onBack: () -> Unit,
    private val onSendFile: (Paired) -> Unit,
    private val onScreen: (Paired) -> Unit,
    private val onFocusInput: () -> Unit
) {
    val view: FrameLayout = FrameLayout(ctx)
    private val title: TextView
    private val status: TextView
    private val listBox: LinearLayout
    private val scroll: ScrollView
    private val input: EditText
    private val panel: LinearLayout
    private val panelBody: LinearLayout
    private var peer: Paired? = null
    private var panelOpen = false
    private var tab = 0
    private val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private fun px(v: Int) = ctx.px(v)

    val peerId: String? get() = peer?.id

    private fun tv(t: String, sp: Float, color: Int = C.INK, bold: Boolean = false) = TextView(ctx).apply {
        text = t; textSize = sp; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun barBtn(t: String, f: () -> Unit) = tv(t, 14f, C.PRIMARY, true).apply {
        gravity = Gravity.CENTER
        setPadding(px(10), px(8), px(10), px(8))
        background = ctx.shape(C.SOFT, 16f)
        setOnClickListener { f() }
    }

    init {
        view.setBackgroundColor(C.BG)
        view.visibility = View.GONE
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        // 顶栏
        val bar = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(px(12), px(10), px(12), px(10)); setBackgroundColor(C.CARD)
        }
        bar.addView(barBtn("‹") { onBack() }, LinearLayout.LayoutParams(px(40), px(36)))
        val mid = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(px(10), 0, px(6), 0) }
        title = tv("", 16f, C.INK, true).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        status = tv("", 11.5f, C.SUB).apply { setOnClickListener { showSas() } }
        mid.addView(title); mid.addView(status)
        bar.addView(mid, LinearLayout.LayoutParams(0, WRAP, 1f))
        bar.addView(barBtn("文件") { peer?.let(onSendFile) }, LinearLayout.LayoutParams(WRAP, px(36)).apply { marginEnd = px(6) })
        bar.addView(barBtn("屏幕") { peer?.let(onScreen) }, LinearLayout.LayoutParams(WRAP, px(36)).apply { marginEnd = px(6) })
        bar.addView(barBtn("⋯") { menu() }, LinearLayout.LayoutParams(px(40), px(36)))
        col.addView(bar, LinearLayout.LayoutParams(MATCH, WRAP))
        // 消息列表
        listBox = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(px(12), px(8), px(12), px(8)) }
        scroll = ScrollView(ctx).apply { addView(listBox, FrameLayout.LayoutParams(MATCH, WRAP)) }
        col.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        // 表情面板
        panel = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(C.CARD); visibility = View.GONE }
        val tabs = android.widget.HorizontalScrollView(ctx).apply { isHorizontalScrollBarEnabled = false }
        val tabRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; setPadding(px(8), px(6), px(8), px(6)) }
        val names = listOf("表情包") + ChatData.EMOJI_GROUPS.map { it.first }
        for ((i, n) in names.withIndex()) {
            tabRow.addView(tv(n, 13.5f, C.PRIMARY, true).apply {
                setPadding(px(12), px(6), px(12), px(6)); background = ctx.shape(C.SOFT, 14f)
                setOnClickListener { tab = i; renderPanel() }
            }, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginEnd = px(6) })
        }
        tabs.addView(tabRow)
        panel.addView(tabs, LinearLayout.LayoutParams(MATCH, WRAP))
        panelBody = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(px(8), px(4), px(8), px(8)) }
        val ps = ScrollView(ctx).apply { addView(panelBody, FrameLayout.LayoutParams(MATCH, WRAP)) }
        panel.addView(ps, LinearLayout.LayoutParams(MATCH, px(230)))
        col.addView(panel, LinearLayout.LayoutParams(MATCH, WRAP))
        // 输入栏
        val comp = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(px(10), px(8), px(10), px(8)); setBackgroundColor(C.CARD)
        }
        comp.addView(tv("😀", 24f).apply {
            gravity = Gravity.CENTER; setOnClickListener { togglePanel() }
        }, LinearLayout.LayoutParams(px(44), px(44)))
        input = EditText(ctx).apply {
            hint = "发消息…"; textSize = 15f; setTextColor(C.INK); maxLines = 4
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            background = ctx.shape(C.BG, 18f, C.INPUT_LINE, 1f)
            setPadding(px(14), px(8), px(14), px(8))
            setOnClickListener { closePanel(); onFocusInput() }
        }
        comp.addView(input, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = px(4); marginEnd = px(8) })
        comp.addView(tv("发送", 14f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER; background = ctx.shape(C.PRIMARY, 18f)
            setOnClickListener { send() }
        }, LinearLayout.LayoutParams(px(60), px(40)))
        col.addView(comp, LinearLayout.LayoutParams(MATCH, WRAP))
        view.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun hub() = ChatNet.hub

    fun open(p: Paired) {
        peer = p
        title.text = p.name
        view.visibility = View.VISIBLE
        hub().viewing = p.id
        hub().markRead(p.id)
        hub().ensure(p.id)
        closePanel()
        render(true)
    }

    fun close() {
        view.visibility = View.GONE
        hub().viewing = null
        closePanel()
        peer = null
    }

    /** 数据变化（消息 / 连接 / 文件进度）时由 MainActivity 调用 */
    fun refresh(id: String?) { if (view.visibility == View.VISIBLE && (id == null || id == peer?.id)) { peer?.let { hub().markRead(it.id) }; render(false) } }

    private fun send() {
        val p = peer ?: return
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        hub().sendText(p.id, t)
        input.setText("")
    }

    private fun togglePanel() { if (panelOpen) closePanel() else { panelOpen = true; panel.visibility = View.VISIBLE; renderPanel(); (ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager).hideSoftInputFromWindow(input.windowToken, 0) } }
    private fun closePanel() { panelOpen = false; panel.visibility = View.GONE }

    private fun renderPanel() {
        panelBody.removeAllViews()
        if (tab == 0) {
            val per = 3
            var row: LinearLayout? = null
            for ((i, s) in ChatData.STICKERS.withIndex()) {
                if (i % per == 0) { row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }; panelBody.addView(row, LinearLayout.LayoutParams(MATCH, WRAP)) }
                row!!.addView(stickerView(s.e, s.c, listOf(s.bg1, s.bg2), 30f, 12f).apply {
                    setOnClickListener { peer?.let { p -> hub().sendSticker(p.id, s) }; closePanel() }
                }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(px(3), px(3), px(3), px(3)) })
            }
        } else {
            val list = ChatData.EMOJI_GROUPS[tab - 1].second
            val per = 7
            var row: LinearLayout? = null
            for ((i, e) in list.withIndex()) {
                if (i % per == 0) { row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }; panelBody.addView(row, LinearLayout.LayoutParams(MATCH, WRAP)) }
                row!!.addView(tv(e, 24f).apply {
                    gravity = Gravity.CENTER; setPadding(0, px(6), 0, px(6))
                    setOnClickListener { input.append(e) }
                }, LinearLayout.LayoutParams(0, WRAP, 1f))
            }
        }
    }

    private fun color(s: String, d: Int) = try { Color.parseColor(s) } catch (e: Exception) { d }

    private fun stickerView(e: String, c: String, bg: List<String>, emojiSp: Float, capSp: Float): View {
        val b = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(px(8), px(10), px(8), px(8))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(color(bg.getOrNull(0) ?: "#fff3c4", Color.WHITE), color(bg.getOrNull(1) ?: "#ffd37a", Color.LTGRAY))).apply { cornerRadius = px(14).toFloat() }
        }
        b.addView(tv(e, emojiSp).apply { gravity = Gravity.CENTER })
        if (c.isNotEmpty()) b.addView(tv(c, capSp, Color.parseColor("#3A2E10"), true).apply { gravity = Gravity.CENTER; maxLines = 1 })
        return b
    }

    private fun render(toEnd: Boolean) {
        val p = peer ?: return
        val h = hub()
        val conn = h.isConnected(p.id)
        val sas = h.sas(p.id)
        status.text = if (conn) "🔒 端到端加密已连接" + (if (sas.isNotEmpty()) " · 点此核对安全码" else "")
        else if (Link.peers.containsKey(p.id)) "设备在线 · 正在建立加密连接…" else "设备离线 · 消息会在对方上线后自动送达"
        val nearEnd = scroll.getChildAt(0).let { it.bottom - (scroll.height + scroll.scrollY) < px(80) }
        listBox.removeAllViews()
        class Item(val ts: Long, val v: View)
        val items = ArrayList<Item>()
        val msgs = h.messages(p.id).takeLast(200)
        for (m in msgs) items.add(Item(m.ts, msgView(m, p)))
        val first = msgs.firstOrNull()?.ts ?: 0L
        for (x in FileXfer.list) if (x.peerId == p.id && x.t0 >= first) items.add(Item(x.t0, fileView(x)))
        items.sortBy { it.ts }
        if (items.isEmpty()) listBox.addView(tv("🔒 消息端到端加密，只在你们两台设备之间传递。\n打个招呼，或者发个表情包吧～", 13f, C.SUB).apply { gravity = Gravity.CENTER; setPadding(px(16), px(40), px(16), px(16)) })
        for (it in items) listBox.addView(it.v)
        if (toEnd || nearEnd) scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun row(mine: Boolean, content: View, meta: String, failedId: String? = null): View {
        val r = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; gravity = if (mine) Gravity.END else Gravity.START }
        val wrap = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; gravity = if (mine) Gravity.END else Gravity.START }
        wrap.addView(content, LinearLayout.LayoutParams(WRAP, WRAP))
        val m = tv(meta, 10.5f, if (failedId != null) C.BAD else C.SUB).apply { setPadding(px(4), px(2), px(4), 0) }
        if (failedId != null) m.setOnClickListener { peer?.let { hub().retry(it.id, failedId) } }
        wrap.addView(m)
        r.addView(wrap, LinearLayout.LayoutParams(WRAP, WRAP))
        return r.also { it.layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = px(6) } }
    }

    private fun msgView(m: ChatMsg, p: Paired): View {
        val mine = m.mine
        val content: View = if (m.k == "s") stickerView(m.e, m.c, m.bg, 54f, 14f).apply { minimumWidth = px(120) }
        else tv(m.x, 15.5f, if (mine) Color.WHITE else C.INK).apply {
            setPadding(px(14), px(9), px(14), px(9)); maxWidth = ctx.resources.displayMetrics.widthPixels * 7 / 10
            background = ctx.shape(if (mine) C.PRIMARY else C.CARD, 16f, if (mine) C.PRIMARY else C.CARD_LINE, 1f)
            setTextIsSelectable(true)
        }
        val time = fmt.format(Date(m.ts))
        val meta = if (!mine) time else when (m.st) { "sending" -> "$time · 发送中…"; "failed" -> "$time · ❗ 未送达，点此重试"; else -> "$time · 已送达" }
        return row(mine, content, meta, if (mine && m.st == "failed") m.id else null)
    }

    private fun fileView(x: Xfer): View {
        val c = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(px(14), px(10), px(14), px(10)); background = ctx.shape(C.SOFT, 14f, C.CARD_LINE, 1f) }
        c.addView(tv((if (x.send) "📤 " else "📥 ") + x.name, 14f, C.INK, true).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE })
        val pct = if (x.size > 0L) (x.done * 100 / x.size).toInt() else 0
        val s = when (x.state) {
            "sending", "receiving" -> "$pct% · ${FileXfer.human(x.done)} / ${FileXfer.human(x.size)}"
            "done" -> "已完成 · " + FileXfer.human(x.size)
            "failed" -> "失败：" + x.msg
            "cancelled" -> "已取消"
            "offering" -> "等待对方确认…"
            else -> x.state
        }
        c.addView(tv(s, 12f, C.SUB).apply { setPadding(0, px(4), 0, 0) })
        return row(x.send, c, fmt.format(Date(x.t0)))
    }

    private fun showSas() {
        val p = peer ?: return
        val sas = hub().sas(p.id)
        if (sas.isEmpty()) return
        AlertDialog.Builder(ctx).setTitle("🔒 安全码").setMessage(sas + "\n\n请和对方当面（或电话）核对：两台设备上显示的这串数字必须完全一样，才说明没有人在中间窃听。")
            .setPositiveButton("知道了", null).show()
    }

    private fun menu() {
        val p = peer ?: return
        AlertDialog.Builder(ctx).setItems(arrayOf("核对安全码", "清空聊天记录")) { _, i ->
            if (i == 0) { if (hub().sas(p.id).isEmpty()) android.widget.Toast.makeText(ctx, "还没建立加密连接", android.widget.Toast.LENGTH_SHORT).show() else showSas() }
            else AlertDialog.Builder(ctx).setMessage("清空与「" + p.name + "」的聊天记录？（只清本机）").setPositiveButton("清空") { _, _ -> hub().clear(p.id) }.setNegativeButton("取消", null).show()
        }.show()
    }
}
