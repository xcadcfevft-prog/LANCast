package com.lancast.app

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** 聊天页专用配色（取自聊天界面设计图） */
private object CC {
    val HEAD_BTN = Color.parseColor("#EEF3F8")    // 顶栏圆形按钮底
    val AVATAR_BG = Color.parseColor("#E2ECF6")   // 头像圆底
    val AVATAR_FG = Color.parseColor("#4A6783")   // 头像字母
    val LINE = Color.parseColor("#EAF1F6")        // 顶栏下分隔线
    val CHIP = Color.parseColor("#EAF2F7")        // 日期标签底
    val BUBBLE = Color.parseColor("#456A80")      // 我发的气泡
    val SEND = Color.parseColor("#4B768E")        // 发送按钮
    val FIELD = Color.parseColor("#F1F6FA")       // 输入框底
    val TOOL = Color.parseColor("#33414D")        // 输入栏图标（表情 / 回形针）
    val HINT = Color.parseColor("#8A9AA8")        // 输入框提示字
    val TICK = Color.parseColor("#7C909F")        // 「已送达」双勾
    val SHADOW = Color.parseColor("#3D6A85")      // 输入栏阴影
}

/**
 * 聊天页（纯代码布局，和应用其它页面同风格）。
 * 顶栏：圆形返回键 / 头像 + 名字 + 🔒状态 / 屏幕（听筒图标）/ 文件 / 更多，下面一条淡分隔线；
 * 中间：日期标签（今天 / 昨天 / 月日）、消息气泡（我发的深青色，带时间 + 双勾）、表情包卡片、文件卡片（复用文件互传的进度）；
 * 底部：悬浮的白色圆角输入栏 = 表情按钮 + 灰色输入框（右侧回形针 = 发文件）+ 圆形发送键，表情面板可切换。
 * 发文件 / 屏幕互投直接调用首页已有的功能（回调给 MainActivity）。
 */
class ChatPage(
    private val ctx: Context,
    private val onBack: () -> Unit,
    private val onSendFile: (Paired) -> Unit,
    private val onScreen: (Paired) -> Unit,
    private val onFocusInput: () -> Unit,
    private val withMic: (() -> Unit) -> Unit = { it() }      // 先确保有麦克风权限再执行（MainActivity 提供）
) {
    val view: FrameLayout = FrameLayout(ctx)
    private val avatar: TextView
    private val title: TextView
    private val status: TextView
    private val listBox: LinearLayout
    private val scroll: ScrollView
    private val input: EditText
    private val panel: LinearLayout
    private val panelBody: LinearLayout
    private val callBar: LinearLayout
    private val callText: TextView
    private val callAns: TextView
    private val callMute: TextView
    private val callEnd: TextView
    private val callBtn: TextView
    private var peer: Paired? = null
    private var panelOpen = false
    private var tab = 0
    private val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private fun px(v: Int) = ctx.px(v)

    val peerId: String? get() = peer?.id

    private fun tv(t: String, sp: Float, color: Int = C.INK, bold: Boolean = false) = TextView(ctx).apply {
        text = t; textSize = sp; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    /** 图标按钮：整个 FrameLayout 是点击区（大小由加进父布局时的 LayoutParams 决定），中间放 iconDp 大小的图标；bg 不为空时画圆形底（点击区要是正方形）。 */
    private fun iconBtn(
        kind: String, iconDp: Int, tint: Int, bg: Int?,
        stroke: Float = 2.0f, filled: Boolean = false, f: () -> Unit
    ): FrameLayout = FrameLayout(ctx).apply {
        if (bg != null) background = circle(bg)
        addView(IconView(ctx, kind, tint, filled, stroke), FrameLayout.LayoutParams(px(iconDp), px(iconDp), Gravity.CENTER))
        isClickable = true
        setOnClickListener { f() }
    }

    private fun mediumFont() = Typeface.create("sans-serif-medium", Typeface.NORMAL)

    /** 头像上显示的字：名字的第一个字（按码点取，不会把 emoji 劈成两半） */
    private fun initial(n: String): String {
        val t = n.trim()
        if (t.isEmpty()) return "?"
        return StringBuilder().appendCodePoint(t.codePointAt(0)).toString().uppercase(Locale.getDefault())
    }

    init {
        view.setBackgroundColor(C.BG)
        view.visibility = View.GONE
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        col.clipChildren = false          // 输入栏的阴影会画到自己的边距里，别被裁掉
        // 顶栏
        val bar = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(px(10), px(10), px(10), px(10)); setBackgroundColor(C.BG)
        }
        bar.addView(iconBtn("back", 20, C.INK, CC.HEAD_BTN) { onBack() }, LinearLayout.LayoutParams(px(36), px(36)))
        avatar = tv("", 18f, CC.AVATAR_FG).apply {
            gravity = Gravity.CENTER; typeface = mediumFont(); background = circle(CC.AVATAR_BG)
        }
        bar.addView(avatar, LinearLayout.LayoutParams(px(44), px(44)).apply { marginStart = px(9) })
        val mid = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
        title = tv("", 16.5f, C.INK).apply { typeface = mediumFont(); maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        status = tv("", 11f, C.SUB).apply {
            maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END
            setOnClickListener { showSas() }
        }
        mid.addView(title); mid.addView(status)
        bar.addView(mid, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = px(11); marginEnd = px(4) })
        callBtn = tv("📞", 17f, C.INK).apply {
            gravity = Gravity.CENTER; background = circle(CC.HEAD_BTN); isClickable = true
            setOnClickListener { toggleCall() }
        }
        bar.addView(callBtn, LinearLayout.LayoutParams(px(36), px(36)).apply { marginStart = px(6) })
        // 三个图标统一用深色（C.INK）、同样的线宽，听筒不会再比文件图标浅
        bar.addView(iconBtn("handset", 20, C.INK, CC.HEAD_BTN) { peer?.let(onScreen) },
            LinearLayout.LayoutParams(px(36), px(36)).apply { marginStart = px(6) })
        bar.addView(iconBtn("file", 20, C.INK, CC.HEAD_BTN) { peer?.let(onSendFile) },
            LinearLayout.LayoutParams(px(36), px(36)).apply { marginStart = px(6) })
        bar.addView(iconBtn("more", 20, C.INK, CC.HEAD_BTN) { menu() },
            LinearLayout.LayoutParams(px(36), px(36)).apply { marginStart = px(6) })
        col.addView(bar, LinearLayout.LayoutParams(MATCH, WRAP))
        col.addView(View(ctx).apply { setBackgroundColor(CC.LINE) },
            LinearLayout.LayoutParams(MATCH, px(1)).apply { marginStart = px(16); marginEnd = px(16) })
        // 语音通话条：呼叫中 / 来电 / 通话中（无损 PCM）
        callBar = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; visibility = View.GONE
            setPadding(px(14), px(8), px(10), px(8)); setBackgroundColor(Color.parseColor("#1F7A4D"))
        }
        callText = tv("", 13f, Color.WHITE).apply { maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END }
        callBar.addView(callText, LinearLayout.LayoutParams(0, WRAP, 1f))
        fun pill(label: String, bg: Int, fg: Int, f: () -> Unit) = tv(label, 13f, fg, true).apply {
            gravity = Gravity.CENTER; setPadding(px(12), px(6), px(12), px(6)); background = ctx.shape(bg, 14f)
            setOnClickListener { f() }
        }
        callAns = pill("接听", Color.WHITE, Color.parseColor("#1F7A4D")) { withMic { VoiceCall.answer() } }
        callMute = pill("静音", Color.WHITE, Color.parseColor("#222222")) { VoiceCall.mute(!VoiceCall.st.muted) }
        callEnd = pill("挂断", Color.parseColor("#D9381E"), Color.WHITE) { if (VoiceCall.st.phase == "ringing") VoiceCall.decline() else VoiceCall.hangup() }
        for (b in listOf(callAns, callMute, callEnd)) callBar.addView(b, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = px(6) })
        col.addView(callBar, LinearLayout.LayoutParams(MATCH, WRAP))
        // 消息列表
        listBox = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(px(14), px(6), px(14), px(12)) }
        scroll = ScrollView(ctx).apply { isVerticalScrollBarEnabled = false; addView(listBox, FrameLayout.LayoutParams(MATCH, WRAP)) }
        col.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        // 表情面板
        panel = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(C.CARD); visibility = View.GONE }
        val tabs = android.widget.HorizontalScrollView(ctx).apply { isHorizontalScrollBarEnabled = false }
        val tabRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; setPadding(px(8), px(6), px(8), px(6)) }
        val names = listOf("表情包") + ChatData.EMOJI_GROUPS.map { it.first }
        for ((i, n) in names.withIndex()) {
            tabRow.addView(tv(n, 13.5f, C.PRIMARY, true).apply {
                setPadding(px(12), px(6), px(12), px(6)); background = ctx.shape(C.SOFT, 14f)
                setOnClickListener { tab = i; renderPanel() }
            }, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginEnd = px(6) })
        }
        tabs.addView(tabRow)
        panel.addView(tabs, LinearLayout.LayoutParams(MATCH, WRAP))
        panelBody = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(px(8), px(4), px(8), px(8)) }
        val ps = ScrollView(ctx).apply { addView(panelBody, FrameLayout.LayoutParams(MATCH, WRAP)) }
        panel.addView(ps, LinearLayout.LayoutParams(MATCH, px(230)))
        col.addView(panel, LinearLayout.LayoutParams(MATCH, WRAP))
        // 输入栏：悬浮白色圆角条 = 表情 + 灰色输入框（右侧回形针）+ 圆形发送键
        val comp = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(px(8), px(8), px(8), px(8))
            background = ctx.shape(Color.WHITE, 32f, Color.parseColor("#F0F5F9"), 1f)
            elevation = px(4).toFloat()
            outlineSpotShadowColor = CC.SHADOW; outlineAmbientShadowColor = CC.SHADOW
        }
        comp.addView(iconBtn("smile", 26, CC.TOOL, null, 1.6f) { togglePanel() }, LinearLayout.LayoutParams(px(44), px(44)))
        val field = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = ctx.shape(CC.FIELD, 22f); minimumHeight = px(44)
        }
        input = EditText(ctx).apply {
            hint = "发消息…"; textSize = 15f; setTextColor(C.INK); setHintTextColor(CC.HINT); maxLines = 4
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            background = null
            gravity = Gravity.CENTER_VERTICAL
            setPadding(px(10), px(10), px(4), px(10))
            setOnClickListener { closePanel(); onFocusInput() }
        }
        field.addView(input, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = px(8) })
        field.addView(iconBtn("clip", 22, CC.TOOL, null, 1.6f) { peer?.let(onSendFile) },
            LinearLayout.LayoutParams(px(40), px(44)).apply { marginEnd = px(6) })
        comp.addView(field, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = px(2) })
        comp.addView(iconBtn("send", 22, Color.WHITE, CC.SEND, 1.2f, true) { send() },
            LinearLayout.LayoutParams(px(44), px(44)).apply { marginStart = px(8) })
        col.addView(comp, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(px(10), px(6), px(10), px(10)) })
        view.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun hub() = ChatNet.hub

    // ───────── 语音通话 ─────────
    private fun toggleCall() {
        val p = peer ?: return
        if (VoiceCall.st.phase != "idle") { android.widget.Toast.makeText(ctx, "已经有一通电话了", android.widget.Toast.LENGTH_SHORT).show(); return }
        if (!Link.peers.containsKey(p.id)) { android.widget.Toast.makeText(ctx, "对方当前不在线，无法通话", android.widget.Toast.LENGTH_SHORT).show(); return }
        withMic { hub().ensure(p.id); VoiceCall.start(p.id) }
    }

    /** 通话状态变化（含每秒刷新通话时长）时由 MainActivity 调用；通话条在聊天页顶部，无论看的是哪个聊天都显示 */
    fun refreshCall() {
        val st = VoiceCall.st
        val ph = st.phase
        callBar.visibility = if (ph == "idle") View.GONE else View.VISIBLE
        callBar.setBackgroundColor(Color.parseColor(if (ph == "ringing") "#456A80" else "#1F7A4D"))
        callAns.visibility = if (ph == "ringing") View.VISIBLE else View.GONE
        callMute.visibility = if (ph == "active") View.VISIBLE else View.GONE
        callMute.text = if (st.muted) "取消静音" else "静音"
        callEnd.text = when (ph) { "ringing" -> "拒绝"; "calling" -> "取消"; else -> "挂断" }
        val nm = Link.pairs().firstOrNull { it.id == st.peerId }?.name ?: "对方"
        val secs = ((System.currentTimeMillis() - st.since) / 1000).coerceAtLeast(0)
        callText.text = when (ph) {
            "calling" -> "📞 正在呼叫「$nm」…"
            "ringing" -> "📞「$nm」邀请你无损语音通话"
            "active" -> "🎙 与「$nm」通话中 %02d:%02d · 无损 PCM 48 kHz / 16 bit · 请戴耳机".format(secs / 60, secs % 60)
            else -> ""
        }
        callBtn.alpha = if (ph == "idle") 1f else 0.4f
    }

    fun open(p: Paired) {
        peer = p
        title.text = p.name
        avatar.text = initial(p.name)
        view.visibility = View.VISIBLE
        hub().viewing = p.id
        hub().markRead(p.id)
        hub().ensure(p.id)
        closePanel()
        render(true)
        refreshCall()
    }

    fun close() {
        view.visibility = View.GONE
        hub().viewing = null
        closePanel()
        peer = null
    }

    /** 数据变化（消息 / 连接 / 文件进度）时由 MainActivity 调用 */
    fun refresh(id: String?) { if (view.visibility == View.VISIBLE && (id == null || id == peer?.id)) { peer?.let { hub().markRead(it.id) }; render(false) } }

    private fun send() {
        val p = peer ?: return
        val t = input.text.toString().trim()
        if (t.isEmpty()) return
        hub().sendText(p.id, t)
        input.setText("")
    }

    private fun togglePanel() { if (panelOpen) closePanel() else { panelOpen = true; panel.visibility = View.VISIBLE; renderPanel(); (ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager).hideSoftInputFromWindow(input.windowToken, 0) } }
    private fun closePanel() { panelOpen = false; panel.visibility = View.GONE }

    private fun renderPanel() {
        panelBody.removeAllViews()
        if (tab == 0) {
            val per = 3
            var row: LinearLayout? = null
            for ((i, s) in ChatData.STICKERS.withIndex()) {
                if (i % per == 0) { row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }; panelBody.addView(row, LinearLayout.LayoutParams(MATCH, WRAP)) }
                row!!.addView(stickerView(s.e, s.c, listOf(s.bg1, s.bg2), 30f, 12f).apply {
                    setOnClickListener { peer?.let { p -> hub().sendSticker(p.id, s) }; closePanel() }
                }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(px(3), px(3), px(3), px(3)) })
            }
        } else {
            val list = ChatData.EMOJI_GROUPS[tab - 1].second
            val per = 7
            var row: LinearLayout? = null
            for ((i, e) in list.withIndex()) {
                if (i % per == 0) { row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }; panelBody.addView(row, LinearLayout.LayoutParams(MATCH, WRAP)) }
                row!!.addView(tv(e, 24f).apply {
                    gravity = Gravity.CENTER; setPadding(0, px(6), 0, px(6))
                    setOnClickListener { input.append(e) }
                }, LinearLayout.LayoutParams(0, WRAP, 1f))
            }
        }
    }

    private fun color(s: String, d: Int) = try { Color.parseColor(s) } catch (e: Exception) { d }

    private fun stickerView(e: String, c: String, bg: List<String>, emojiSp: Float, capSp: Float): View {
        val b = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(px(8), px(10), px(8), px(8))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(color(bg.getOrNull(0) ?: "#fff3c4", Color.WHITE), color(bg.getOrNull(1) ?: "#ffd37a", Color.LTGRAY))).apply { cornerRadius = px(14).toFloat() }
        }
        b.addView(tv(e, emojiSp).apply { gravity = Gravity.CENTER })
        if (c.isNotEmpty()) b.addView(tv(c, capSp, Color.parseColor("#3A2E10"), true).apply { gravity = Gravity.CENTER; maxLines = 1 })
        return b
    }

    private fun render(toEnd: Boolean) {
        val p = peer ?: return
        val h = hub()
        val conn = h.isConnected(p.id)
        val sas = h.sas(p.id)
        val pr = h.pendingRecalls(p.id)
        status.text = (if (conn) "🔒 端到端加密已连接" + (if (sas.isNotEmpty()) " · 点此核对安全码" else "")
        else if (Link.peers.containsKey(p.id)) "设备在线 · 正在建立加密连接…" else "设备离线 · 消息会在对方上线后自动送达") +
            (if (pr > 0) " · 有 $pr 条撤回等对方上线后生效" else "")
        val nearEnd = scroll.getChildAt(0).let { it.bottom - (scroll.height + scroll.scrollY) < px(80) }
        listBox.removeAllViews()
        class Item(val ts: Long, val v: View)
        val items = ArrayList<Item>()
        val msgs = h.messages(p.id).takeLast(200)
        for (m in msgs) items.add(Item(m.ts, msgView(m, p)))
        val first = msgs.firstOrNull()?.ts ?: 0L
        for (x in FileXfer.list) if (x.peerId == p.id && x.t0 >= first) items.add(Item(x.t0, fileView(x)))
        items.sortBy { it.ts }
        if (items.isEmpty()) listBox.addView(tv("🔒 消息端到端加密，只在你们两台设备之间传递。\n打个招呼，或者发个表情包吧～", 13f, C.SUB).apply { gravity = Gravity.CENTER; setPadding(px(16), px(40), px(16), px(16)) })
        var lastDay = -1
        for (item in items) {
            val dk = dayKey(item.ts)
            if (dk != lastDay) { listBox.addView(dateChip(item.ts)); lastDay = dk }
            listBox.addView(item.v)
        }
        if (toEnd || nearEnd) scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun dayKey(ts: Long): Int {
        val c = Calendar.getInstance().apply { timeInMillis = ts }
        return c.get(Calendar.YEAR) * 1000 + c.get(Calendar.DAY_OF_YEAR)
    }

    /** 今天 / 昨天 / 本年的「M月d日」/ 往年的「yyyy年M月d日」 */
    private fun dayLabel(ts: Long): String {
        val k = dayKey(ts)
        val now = Calendar.getInstance()
        if (k == now.get(Calendar.YEAR) * 1000 + now.get(Calendar.DAY_OF_YEAR)) return "今天"
        val y = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
        if (k == y.get(Calendar.YEAR) * 1000 + y.get(Calendar.DAY_OF_YEAR)) return "昨天"
        val pattern = if (k / 1000 == now.get(Calendar.YEAR)) "M月d日" else "yyyy年M月d日"
        return SimpleDateFormat(pattern, Locale.getDefault()).format(Date(ts))
    }

    private fun dateChip(ts: Long): View = LinearLayout(ctx).apply {
        gravity = Gravity.CENTER
        addView(tv(dayLabel(ts), 11f, C.SUB).apply {
            setPadding(px(12), px(4), px(12), px(4)); background = ctx.shape(CC.CHIP, 12f)
        })
        layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = px(14); bottomMargin = px(2) }
    }

    /** state：我发的消息的状态（sending / sent），sent 时在时间后面画双勾；文件卡片传空串。 */
    private fun row(mine: Boolean, content: View, time: String, state: String = "", failedId: String? = null, recallId: String? = null): View {
        val r = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; gravity = if (mine) Gravity.END else Gravity.START }
        val wrap = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; gravity = if (mine) Gravity.END else Gravity.START }
        wrap.addView(content, LinearLayout.LayoutParams(WRAP, WRAP))
        val meta = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(px(4), px(3), px(4), 0)
        }
        val label = when {
            failedId != null -> "$time · ❗ 未送达，点此重试"
            state == "sending" -> "$time · 发送中…"
            else -> time
        }
        meta.addView(tv(label, 10.5f, if (failedId != null) C.BAD else C.SUB))
        if (mine && state == "sent" && failedId == null) {
            meta.addView(IconView(ctx, "check2", CC.TICK, false, 2.0f), LinearLayout.LayoutParams(px(15), px(15)).apply { marginStart = px(3) })
        }
        if (mine && recallId != null) {                       // 撤回：只有自己发的消息有，没有时间限制，两边一起删
            meta.addView(tv("撤回", 10.5f, C.SUB).apply {
                paint.isUnderlineText = true
                setPadding(px(10), px(6), px(6), px(6))
                setOnClickListener { confirmRecall(recallId) }
            })
        }
        if (failedId != null) meta.setOnClickListener { peer?.let { hub().retry(it.id, failedId) } }
        wrap.addView(meta)
        r.addView(wrap, LinearLayout.LayoutParams(WRAP, WRAP))
        return r.also { it.layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = px(8) } }
    }

    private fun msgView(m: ChatMsg, p: Paired): View {
        val mine = m.mine
        val content: View = if (m.k == "s") stickerView(m.e, m.c, m.bg, 54f, 14f).apply { minimumWidth = px(120) }
        else tv(m.x, 15.5f, if (mine) Color.WHITE else C.INK).apply {
            setPadding(px(14), px(10), px(14), px(10)); maxWidth = ctx.resources.displayMetrics.widthPixels * 72 / 100
            setLineSpacing(0f, 1.1f)
            background = ctx.shape(if (mine) CC.BUBBLE else C.CARD, 20f, if (mine) CC.BUBBLE else C.CARD_LINE, 1f)
            setTextIsSelectable(true)
        }
        val time = fmt.format(Date(m.ts))
        return row(mine, content, time, if (mine) m.st else "", if (mine && m.st == "failed") m.id else null, if (mine) m.id else null)
    }

    private fun fileView(x: Xfer): View {
        val c = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(px(14), px(10), px(14), px(10)); background = ctx.shape(C.SOFT, 14f, C.CARD_LINE, 1f) }
        c.addView(tv((if (x.send) "📤 " else "📥 ") + x.name, 14f, C.INK, true).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE })
        val pct = if (x.size > 0L) (x.done * 100 / x.size).toInt() else 0
        val s = when (x.state) {
            "sending", "receiving" -> "$pct% · ${FileXfer.human(x.done)} / ${FileXfer.human(x.size)}"
            "done" -> "已完成 · " + FileXfer.human(x.size)
            "failed" -> "失败：" + x.msg
            "cancelled" -> "已取消"
            "offering" -> "等待对方确认…"
            else -> x.state
        }
        c.addView(tv(s, 12f, C.SUB).apply { setPadding(0, px(4), 0, 0) })
        return row(x.send, c, fmt.format(Date(x.t0)))
    }

    private fun confirmRecall(msgId: String) {
        val p = peer ?: return
        AlertDialog.Builder(ctx).setTitle("撤回这条消息？")
            .setMessage("撤回后，这条消息会从你和「" + p.name + "」的聊天记录里一起删除，没有时间限制，对方看不到任何痕迹。\n\n" +
                "如果对方现在不在线，会在对方上线后自动撤回。已经被对方复制、截图的内容无法收回。")
            .setPositiveButton("撤回") { _, _ -> hub().recall(p.id, msgId) }
            .setNegativeButton("取消", null).show()
    }

    private fun showSas() {
        val p = peer ?: return
        val sas = hub().sas(p.id)
        if (sas.isEmpty()) return
        AlertDialog.Builder(ctx).setTitle("🔒 安全码").setMessage(sas + "\n\n请和对方当面（或电话）核对：两台设备上显示的这串数字必须完全一样，才说明没有人在中间窃听。")
            .setPositiveButton("知道了", null).show()
    }

    private fun menu() {
        val p = peer ?: return
        AlertDialog.Builder(ctx).setItems(arrayOf("核对安全码", "清空聊天记录")) { _, i ->
            if (i == 0) { if (hub().sas(p.id).isEmpty()) android.widget.Toast.makeText(ctx, "还没建立加密连接", android.widget.Toast.LENGTH_SHORT).show() else showSas() }
            else AlertDialog.Builder(ctx).setMessage("清空与「" + p.name + "」的聊天记录？（只清本机）").setPositiveButton("清空") { _, _ -> hub().clear(p.id) }.setNegativeButton("取消", null).show()
        }.show()
    }
}
