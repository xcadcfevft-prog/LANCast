package com.lancast.app

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.view.WindowInsetsCompat
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** 聊天页专用配色（默认风格取自聊天界面设计图；流光风格换成玻璃配色，见 Glass.kt） */
internal object CC {
    private fun pick(d: String, l: Int) = if (Theme.liquid) l else Color.parseColor(d)
    val HEAD_BTN: Int get() = pick("#EEF3F8", 0x9AFFFFFF.toInt())      // 顶栏圆形按钮底
    val AVATAR_BG: Int get() = pick("#E2ECF6", 0x8FFFFFFF.toInt())     // 头像圆底
    val AVATAR_FG: Int get() = pick("#4A6783", Color.parseColor("#4338C8"))   // 头像字母
    val LINE: Int get() = pick("#EAF1F6", Color.parseColor("#142A2F66"))      // 顶栏下分隔线
    val CHIP: Int get() = pick("#EAF2F7", 0x80FFFFFF.toInt())          // 日期标签底
    val BUBBLE: Int get() = pick("#456A80", Color.parseColor("#3F3FE0"))      // 我发的气泡
    val SEND: Int get() = pick("#4B768E", Color.parseColor("#3F3FE0"))        // 发送按钮
    val FIELD: Int get() = pick("#F1F6FA", 0x66FFFFFF)                 // 输入框底
    val TOOL: Int get() = pick("#33414D", Color.parseColor("#2A2D55")) // 输入栏图标（表情 / 回形针）
    val HINT: Int get() = pick("#8A9AA8", Color.parseColor("#7E82A3")) // 输入框提示字
    val TICK: Int get() = pick("#7C909F", Color.parseColor("#7479A8")) // 「已送达」双勾
    val SHADOW: Int get() = pick("#3D6A85", Color.parseColor("#5B4FE0"))      // 输入栏阴影
}

/**
 * 聊天页（纯代码布局，和应用其它页面同风格）。
 * 顶栏：圆形返回键 / 头像 + 名字 + 🔒状态 / 屏幕（听筒图标）/ 文件 / 更多，下面一条淡分隔线；
 * 中间：日期标签（今天 / 昨天 / 月日）、消息气泡（我发的深青色，带时间 + 双勾）、表情包卡片、文件卡片（复用文件互传的进度）；
 * 底部：悬浮的白色圆角输入栏 = 表情按钮 + 灰色输入框（右侧回形针 = 发文件）+ 圆形发送键，表情面板可切换。
 * 发文件 / 屏幕互投直接调用首页已有的功能（回调给 MainActivity）。
 */
class ChatPage(
    private val ctx: Context,
    private val onBack: () -> Unit,
    private val onSendFile: (Paired) -> Unit,
    private val onScreen: (Paired) -> Unit,
    private val onFocusInput: () -> Unit,
    private val withMic: (() -> Unit) -> Unit = { it() },      // 先确保有麦克风权限再执行（MainActivity 提供）
    private val withMicCam: (() -> Unit) -> Unit = { it() },   // 视频通话：先确保麦克风 + 相机权限（相机可选）
    /* 视频通话「全屏」开 / 关：MainActivity 负责真正的全屏（隐藏状态栏 / 导航栏、刘海区铺满、横屏、屏幕常亮），和投屏观看窗口是同一套 */
    private val onVideoFull: (Boolean) -> Unit = { }
) {
    val view: FrameLayout = FrameLayout(ctx)
    /* 全屏通话页（仿微信）：盖在聊天页上；缩小后退回顶部通话条 */
    private val callScreen = CallScreen(ctx, { val run = if (VoiceCall.st.video) withMicCam else withMic; run { VoiceCall.answer() } }, { refreshCall() }, { pickTier(true) })
    private val avatar: TextView
    private val bioBar: TextView          // 对方的主页介绍：顶栏下方的醒目横幅
    private val title: TextView
    private val status: TextView
    private val listBox: LinearLayout
    private val scroll: ScrollView
    private val input: EditText
    private val panel: LinearLayout
    private val panelBody: LinearLayout
    private val callBar: LinearLayout
    private val callText: TextView
    private val callAns: TextView
    private val callMute: TextView
    private val callEnd: TextView
    private val videoBox: FrameLayout
    private val remoteImg: ImageView
    private val selfImg: ImageView
    private val vidHint: TextView
    private val vidCam: TextView
    private val vidFullBtn: TextView
    private val vidMute: TextView            // 全屏时通话条被收起，静音 / 挂断挪到画面上
    private val vidHang: TextView
    private val vidInfo: TextView            // 全屏时左上角的通话时长
    private val vidCtl: HorizontalScrollView
    private val topBar: LinearLayout         // 顶栏 / 分隔线 / 输入栏：全屏时整个收起
    private val topLine: View
    private val composer: LinearLayout
    /* 画面比例：和投屏观看窗口同一套规则 —— mode 0=自动（被裁掉的面积 ≤ 22% 就铺满，否则完整显示）1=完整显示 2=铺满裁剪 3=手动缩放；
     * 双击在完整显示 / 铺满间切换，双指捏合缩放（结束时吸附），单指拖动平移 */
    private var vidMode = 0
    private var vidManual = 1f
    private var vidPanX = 0f
    private var vidPanY = 0f
    private var vidFull = false              // 用户点了「全屏」
    private var fullApplied = false          // 全屏界面已经真正生效（只有通话中的视频通话才会）
    private var vidW = 0
    private var vidH = 0
    private var cutL = 0
    private var cutT = 0
    private var cutR = 0
    private var cutB = 0
    private var peer: Paired? = null
    private var panelOpen = false
    private var tab = 0
    private val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private fun px(v: Int) = ctx.px(v)

    val peerId: String? get() = peer?.id

    private fun tv(t: String, sp: Float, color: Int = C.INK, bold: Boolean = false) = TextView(ctx).apply {
        text = t; textSize = sp; setTextColor(color); if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    /** 图标按钮：整个 FrameLayout 是点击区（大小由加进父布局时的 LayoutParams 决定），中间放 iconDp 大小的图标；bg 不为空时画圆形底（点击区要是正方形）。 */
    private fun iconBtn(
        kind: String, iconDp: Int, tint: Int, bg: Int?,
        stroke: Float = 2.0f, filled: Boolean = false, f: () -> Unit
    ): FrameLayout = FrameLayout(ctx).apply {
        if (bg != null) background = circle(bg)
        addView(IconView(ctx, kind, tint, filled, stroke), FrameLayout.LayoutParams(px(iconDp), px(iconDp), Gravity.CENTER))
        isClickable = true
        setOnClickListener { f() }; fluid()
    }

    private fun mediumFont() = Typeface.create("sans-serif-medium", Typeface.NORMAL)

    /** 头像上显示的字：名字的第一个字（按码点取，不会把 emoji 劈成两半） */
    private fun initial(n: String): String {
        val t = n.trim()
        if (t.isEmpty()) return "?"
        return StringBuilder().appendCodePoint(t.codePointAt(0)).toString().uppercase(Locale.getDefault())
    }

    init {
        view.setBackgroundColor(C.BG)
        view.visibility = View.GONE
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        col.clipChildren = false          // 输入栏的阴影会画到自己的边距里，别被裁掉
        // 顶栏
        val bar = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(px(10), px(10), px(10), px(10)); setBackgroundColor(C.BG)
        }
        bar.addView(iconBtn("back", 20, C.INK, CC.HEAD_BTN) { onBack() }, LinearLayout.LayoutParams(px(36), px(36)))
        avatar = tv("", 18f, CC.AVATAR_FG).apply {
            gravity = Gravity.CENTER; typeface = mediumFont(); background = circle(CC.AVATAR_BG)
        }
        bar.addView(avatar, LinearLayout.LayoutParams(px(44), px(44)).apply { marginStart = px(9) })
        val mid = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
        title = tv("", 16.5f, C.INK).apply { typeface = mediumFont(); maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        status = tv("", 11f, C.SUB).apply {
            maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END
            setOnClickListener { showSas() }; fluid()
        }
        mid.addView(title); mid.addView(status)
        bar.addView(mid, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = px(11); marginEnd = px(4) })
        // 三个图标统一用深色（C.INK）、同样的线宽，听筒不会再比文件图标浅
        bar.addView(iconBtn("handset", 20, C.INK, CC.HEAD_BTN) { chooseLink() },
            LinearLayout.LayoutParams(px(36), px(36)).apply { marginStart = px(6) })
        bar.addView(iconBtn("file", 20, C.INK, CC.HEAD_BTN) { peer?.let(onSendFile) },
            LinearLayout.LayoutParams(px(36), px(36)).apply { marginStart = px(6) })
        bar.addView(iconBtn("more", 20, C.INK, CC.HEAD_BTN) { menu() },
            LinearLayout.LayoutParams(px(36), px(36)).apply { marginStart = px(6) })
        topBar = bar
        col.addView(bar, LinearLayout.LayoutParams(MATCH, WRAP))
        topLine = View(ctx).apply { setBackgroundColor(CC.LINE) }
        col.addView(topLine, LinearLayout.LayoutParams(MATCH, px(1)).apply { marginStart = px(16); marginEnd = px(16) })
        bioBar = tv("", 14f, C.INK).apply {
            visibility = View.GONE; maxLines = 3; ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding(px(16), px(10), px(16), px(10)); setBackgroundColor(Color.parseColor("#1A2F80B0"))
            setOnClickListener { peer?.let { p -> android.app.AlertDialog.Builder(ctx).setTitle(p.name + " 的主页介绍").setMessage(Bio.peer(p.id)).setPositiveButton("好", null).show() } }
        }
        col.addView(bioBar, LinearLayout.LayoutParams(MATCH, WRAP))
        // 语音通话条：呼叫中 / 来电 / 通话中（无损 PCM）
        callBar = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; visibility = View.GONE
            setPadding(px(14), px(8), px(10), px(8)); setBackgroundColor(Color.parseColor("#1F7A4D"))
        }
        callText = tv("", 13f, Color.WHITE).apply { maxLines = 2; ellipsize = android.text.TextUtils.TruncateAt.END }
        callBar.addView(callText, LinearLayout.LayoutParams(0, WRAP, 1f))
        fun pill(label: String, bg: Int, fg: Int, f: () -> Unit) = tv(label, 13f, fg, true).apply {
            gravity = Gravity.CENTER; setPadding(px(12), px(6), px(12), px(6)); background = ctx.shape(bg, 14f)
            setOnClickListener { f() }; fluid()
        }
        callAns = pill("接听", Color.WHITE, Color.parseColor("#1F7A4D")) { val run = if (VoiceCall.st.video) withMicCam else withMic; run { VoiceCall.answer() } }
        callMute = pill("静音", Color.WHITE, Color.parseColor("#222222")) { VoiceCall.mute(!VoiceCall.st.muted) }
        callEnd = pill("挂断", Color.parseColor("#D9381E"), Color.WHITE) { if (VoiceCall.st.phase == "ringing") VoiceCall.decline() else VoiceCall.hangup() }
        for (b in listOf(callAns, callMute, callEnd)) callBar.addView(b, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = px(6) })
        col.addView(callBar, LinearLayout.LayoutParams(MATCH, WRAP))
        // 视频区：对方画面（整块）+ 我自己的小窗（右下角）+ 左下角的 画质 / 翻转 / 摄像头 / 全屏 按钮（全屏时再多 静音 / 挂断，左上角是通话时长）
        videoBox = FrameLayout(ctx).apply {
            setBackgroundColor(Color.BLACK); visibility = View.GONE
            addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> applyVidLayout(); applyVidScale() }
            // 刘海 / 挖孔的安全区（横屏全屏时在左 / 右）：浮在画面上的按钮要躲开它；横屏转 180° 时画面尺寸不变、不会触发上面的布局回调，所以单独监听
            setOnApplyWindowInsetsListener { v, insets ->
                val c = WindowInsetsCompat.toWindowInsetsCompat(insets, v).getInsets(WindowInsetsCompat.Type.displayCutout())
                if (c.left != cutL || c.top != cutT || c.right != cutR || c.bottom != cutB) {
                    cutL = c.left; cutT = c.top; cutR = c.right; cutB = c.bottom
                    v.post { applyVidLayout() }
                }
                insets
            }
        }
        remoteImg = ImageView(ctx).apply { scaleType = ImageView.ScaleType.MATRIX }      // 缩放 / 平移由 applyVidScale 用矩阵算（和投屏观看窗口同一套）
        videoBox.addView(remoteImg, FrameLayout.LayoutParams(MATCH, MATCH))
        vidHint = tv("等待对方画面…", 13f, Color.parseColor("#9FB3C2")).apply { gravity = Gravity.CENTER }
        videoBox.addView(vidHint, FrameLayout.LayoutParams(MATCH, MATCH))
        selfImg = ImageView(ctx).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP; background = ctx.shape(Color.parseColor("#222222"), 10f, Color.WHITE, 1f); clipToOutline = true
        }
        videoBox.addView(selfImg, FrameLayout.LayoutParams(px(84), px(112), Gravity.END or Gravity.BOTTOM).apply { setMargins(px(10), px(10), px(10), px(10)) })
        vidInfo = tv("", 12.5f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER; setPadding(px(11), px(6), px(11), px(6)); background = ctx.shape(Color.parseColor("#99000000"), 14f)
            visibility = View.GONE
        }
        videoBox.addView(vidInfo, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.START or Gravity.TOP).apply { setMargins(px(10), px(10), px(10), px(10)) })
        fun vpill(label: String, bg: Int = Color.parseColor("#99000000"), f: () -> Unit) = tv(label, 12.5f, Color.WHITE, true).apply {
            gravity = Gravity.CENTER; setPadding(px(11), px(6), px(11), px(6)); background = ctx.shape(bg, 14f)
            setOnClickListener { f() }; fluid()
        }
        vidCam = vpill("关摄像头") { VoiceCall.camera(!VoiceCall.st.camOn) }
        vidMute = vpill("静音") { VoiceCall.mute(!VoiceCall.st.muted) }.apply { visibility = View.GONE }
        vidHang = vpill("挂断", Color.parseColor("#D9381E")) { VoiceCall.hangup() }.apply { visibility = View.GONE }
        vidFullBtn = vpill("全屏") { callScreen.expand() }      // 缩小成顶部通话条 + 内嵌视频后，点这里回到全屏通话页
        val vrow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
        vrow.addView(vpill("画质") { pickTier(true) }, LinearLayout.LayoutParams(WRAP, WRAP))
        vrow.addView(vpill("翻转") { VoiceCall.flipCamera() }, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = px(6) })
        vrow.addView(vidCam, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = px(6) })
        vrow.addView(vidMute, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = px(6) })
        vrow.addView(vidHang, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = px(6) })
        vrow.addView(vidFullBtn, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginStart = px(6) })
        // 按钮多、屏幕窄时（竖屏）这一排可以横向滑动，不会压到右下角的自拍小窗
        vidCtl = HorizontalScrollView(ctx).apply { isHorizontalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER }
        vidCtl.addView(vrow, FrameLayout.LayoutParams(WRAP, WRAP))
        videoBox.addView(vidCtl, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.START or Gravity.BOTTOM).apply { setMargins(px(10), px(10), px(104), px(10)) })
        // 手势和投屏观看窗口一致：双击 完整显示 ⇄ 铺满，双指捏合缩放，单指拖动平移（点在按钮上的触摸由按钮自己处理）
        videoBox.setOnTouchListener { _, ev -> vidScaleDet.onTouchEvent(ev); vidGest.onTouchEvent(ev); true }
        col.addView(videoBox, LinearLayout.LayoutParams(MATCH, 0, 3f))      // 视频占聊天页大部分高度；点「全屏」后其余界面全部收起，视频独占整个屏幕
        // 消息列表
        listBox = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(px(14), px(6), px(14), px(12)) }
        scroll = ScrollView(ctx).apply { isVerticalScrollBarEnabled = false; addView(listBox, FrameLayout.LayoutParams(MATCH, WRAP)) }
        col.addView(scroll, LinearLayout.LayoutParams(MATCH, 0, 1f))
        // 表情面板
        panel = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(C.CARD); visibility = View.GONE }
        val tabs = android.widget.HorizontalScrollView(ctx).apply { isHorizontalScrollBarEnabled = false }
        val tabRow = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; setPadding(px(8), px(6), px(8), px(6)) }
        val names = listOf("表情包") + ChatData.EMOJI_GROUPS.map { it.first }
        for ((i, n) in names.withIndex()) {
            tabRow.addView(tv(n, 13.5f, C.PRIMARY, true).apply {
                setPadding(px(12), px(6), px(12), px(6)); background = ctx.shape(C.SOFT, 14f)
                setOnClickListener { tab = i; renderPanel() }; fluid()
            }, LinearLayout.LayoutParams(WRAP, WRAP).apply { marginEnd = px(6) })
        }
        tabs.addView(tabRow)
        panel.addView(tabs, LinearLayout.LayoutParams(MATCH, WRAP))
        panelBody = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(px(8), px(4), px(8), px(8)) }
        val ps = ScrollView(ctx).apply { addView(panelBody, FrameLayout.LayoutParams(MATCH, WRAP)) }
        panel.addView(ps, LinearLayout.LayoutParams(MATCH, px(230)))
        col.addView(panel, LinearLayout.LayoutParams(MATCH, WRAP))
        // 输入栏：悬浮白色圆角条 = 表情 + 灰色输入框（右侧回形针）+ 圆形发送键
        val comp = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(px(8), px(8), px(8), px(8))
            background = ctx.shape(Color.WHITE, 32f, Color.parseColor("#F0F5F9"), 1f)
            elevation = px(4).toFloat()
            outlineSpotShadowColor = CC.SHADOW; outlineAmbientShadowColor = CC.SHADOW
        }
        comp.addView(iconBtn("smile", 26, CC.TOOL, null, 1.6f) { togglePanel() }, LinearLayout.LayoutParams(px(44), px(44)))
        val field = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = ctx.shape(CC.FIELD, 22f); minimumHeight = px(44)
        }
        input = EditText(ctx).apply {
            hint = "发消息…"; textSize = 15f; setTextColor(C.INK); setHintTextColor(CC.HINT); maxLines = 4
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            background = null
            gravity = Gravity.CENTER_VERTICAL
            setPadding(px(10), px(10), px(4), px(10))
            setOnClickListener { closePanel(); onFocusInput() }; fluid()
        }
        field.addView(input, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = px(8) })
        field.addView(iconBtn("clip", 22, CC.TOOL, null, 1.6f) { peer?.let(onSendFile) },
            LinearLayout.LayoutParams(px(40), px(44)).apply { marginEnd = px(6) })
        comp.addView(field, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = px(2) })
        comp.addView(iconBtn("send", 22, Color.WHITE, CC.SEND, 1.2f, true) { send() },
            LinearLayout.LayoutParams(px(44), px(44)).apply { marginStart = px(8) })
        composer = comp
        col.addView(comp, LinearLayout.LayoutParams(MATCH, WRAP).apply { setMargins(px(10), px(6), px(10), px(10)) })
        view.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
        view.addView(callScreen.view, FrameLayout.LayoutParams(MATCH, MATCH))
        callText.setOnClickListener { callScreen.expand() }
    }

    private fun hub() = ChatNet.hub

    // ───────── 语音通话 ─────────
    private fun toggleCall() {
        val p = peer ?: return
        if (VoiceCall.st.phase != "idle") { android.widget.Toast.makeText(ctx, "已经有一通电话了", android.widget.Toast.LENGTH_SHORT).show(); return }
        if (!Link.peers.containsKey(p.id)) { android.widget.Toast.makeText(ctx, "对方当前不在线，无法通话", android.widget.Toast.LENGTH_SHORT).show(); return }
        withMic { hub().ensure(p.id); VoiceCall.start(p.id) }
    }

    /** 画质四档弹窗（和投屏画质同款单选）。inCall = 通话中改档（立刻生效），否则是发起视频通话前选 */
    private fun pickTier(inCall: Boolean) {
        val cur = if (inCall) VoiceCall.st.tier else VideoTiers.saved()
        val names = VideoTiers.ALL.map { it.name }.toTypedArray()
        android.app.AlertDialog.Builder(ctx).setTitle("视频画质")
            .setSingleChoiceItems(names, cur.coerceIn(0, names.size - 1)) { d, which ->
                d.dismiss()
                val apply = {
                    if (inCall) VoiceCall.setTier(which)
                    else {
                        VideoTiers.save(which)
                        val p = peer
                        if (p != null) withMicCam { hub().ensure(p.id); VoiceCall.start(p.id, true, which) }
                    }
                }
                if (!VideoTiers.of(which).native) apply()
                else {                                    // 超高画质（原生分辨率、JPEG q100）：和投屏的极致档一样，先把风险讲清楚，用户确认了才切换
                    android.app.AlertDialog.Builder(ctx)
                        .setTitle(VideoTiers.of(which).name)
                        .setMessage(EXTREME_DESC + "\n\n原生分辨率、不限帧率、JPEG 质量 100；画面细节最多，但对设备性能和网速要求极高。")
                        .setPositiveButton("开启") { _, _ -> apply() }
                        .setNegativeButton("取消", null)
                        .show()
                }
            }
            .setNegativeButton("取消", null).show()
    }

    /** 屏幕共享 / 五子棋 / 语音通话 / 视频通话 合成一个入口：每个选项一行（图标 + 名称 + 说明 + ›），行与行之间用细线隔开，点哪行就走哪个功能 */
    private fun chooseLink() {
        val p = peer ?: return
        class Opt(val icon: String, val name: String, val desc: String, val run: () -> Unit)
        val opts = listOf(
            Opt("🖥", "屏幕共享", "看对方的屏幕，或把我的屏幕投给对方；可以申请远程控制。") { onScreen(p) },
            Opt("🎮", "智斗五子棋·文房雅趣", "向对方发起对战邀请，对方同意后各自打开独立的棋盘窗口，黑白随机，落子 / 悔棋 / 聊天实时同步。") { startGomoku() },
            Opt("📞", "语音通话", "无损音质（原始 PCM），不压缩，支持扬声器外放（已开启回声消除）。") { toggleCall() },
            Opt("📹", "视频通话", "音频同样无损，画面有四档画质可选，可开关摄像头。") { toggleVideoCall() }
        )
        var dlg: AlertDialog? = null
        val ripple = android.util.TypedValue().let { tvv ->
            if (ctx.theme.resolveAttribute(android.R.attr.selectableItemBackground, tvv, true) && tvv.resourceId != 0) ctx.getDrawable(tvv.resourceId) else null
        }
        val list = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(px(10), px(2), px(10), px(4)) }
        opts.forEachIndexed { i, o ->
            if (i > 0) {   // 选项之间的细线（左右各缩进一点，和文字对齐）
                list.addView(View(ctx).apply { setBackgroundColor(0x2E000000) },
                    LinearLayout.LayoutParams(MATCH, Math.max(1, px(1) / 2 + 1)).apply { marginStart = px(8); marginEnd = px(8) })
            }
            val row = LinearLayout(ctx).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(px(8), px(13), px(8), px(13))
                if (ripple != null) background = ripple.constantState?.newDrawable() ?: ripple
                isClickable = true
                setOnClickListener { dlg?.dismiss(); o.run() }
            }
            row.addView(tv(o.icon, 24f).apply { gravity = Gravity.CENTER }, LinearLayout.LayoutParams(px(40), WRAP))
            val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
            col.addView(tv(o.name, 16f, C.INK, true))
            col.addView(tv(o.desc, 13f, C.SUB).apply { setLineSpacing(0f, 1.1f) }, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = px(3) })
            row.addView(col, LinearLayout.LayoutParams(0, WRAP, 1f).apply { marginStart = px(4) })
            row.addView(IconView(ctx, "chev", C.SUB, false, 2f), LinearLayout.LayoutParams(px(16), px(16)).apply { marginStart = px(8) })
            list.addView(row, LinearLayout.LayoutParams(MATCH, WRAP))
        }
        val scroller = ScrollView(ctx).apply { addView(list, FrameLayout.LayoutParams(MATCH, WRAP)) }
        val d = AlertDialog.Builder(ctx).setTitle("选择一种连接方式")
            .setView(scroller)
            .setNegativeButton("取消", null)
            .create()
        dlg = d
        d.show()
    }

    /** 五子棋：向当前聊天的对方发起对战邀请（对方同意后双方各开一个独立的棋盘窗口） */
    private fun startGomoku() {
        val p = peer ?: return
        when (Gomoku.st.phase) {
            "playing" -> { Gomoku.showWindow(); return }
            "inviting" -> {
                AlertDialog.Builder(ctx).setTitle("智斗五子棋·文房雅趣")
                    .setMessage("已经发出邀请，正在等待对方回应。")
                    .setPositiveButton("继续等待", null)
                    .setNegativeButton("取消邀请") { _, _ -> Gomoku.cancelInvite() }
                    .show()
                return
            }
            "invited" -> { android.widget.Toast.makeText(ctx, "对方已经邀请你了，请先回应", android.widget.Toast.LENGTH_SHORT).show(); return }
        }
        if (!Link.peers.containsKey(p.id)) { android.widget.Toast.makeText(ctx, "对方当前不在线，无法邀请", android.widget.Toast.LENGTH_SHORT).show(); return }
        hub().ensure(p.id)
        Gomoku.invite(p.id)
    }

    private fun toggleVideoCall() {
        val p = peer ?: return
        if (VoiceCall.st.phase != "idle") { android.widget.Toast.makeText(ctx, "已经有一通电话了", android.widget.Toast.LENGTH_SHORT).show(); return }
        if (!Link.peers.containsKey(p.id)) { android.widget.Toast.makeText(ctx, "对方当前不在线，无法通话", android.widget.Toast.LENGTH_SHORT).show(); return }
        pickTier(false)
    }

    /* ═════════════ 画面铺满策略（和投屏观看窗口 MainActivity.geom / applyTransform 同一套） ═════════════
     * 完整显示：整幅画面可见（上下 / 左右留黑边）；铺满裁剪：放大到填满，裁掉超出部分，可拖动平移；
     * 自动：被裁掉的面积 ≤ 22% 才铺满，否则完整显示；捏合缩放结束后自动吸附到「完整显示 / 铺满」，双击在两者间切换。
     * 返回 [适配比例（完整显示时 1 个画面像素 = 几个屏幕像素）, 铺满 / 完整显示 的倍数, 当前相对完整显示的倍数] */
    private fun vidGeom(): FloatArray? {
        val w = videoBox.width.toFloat()
        val h = videoBox.height.toFloat()
        if (vidW <= 0 || vidH <= 0 || w <= 0f || h <= 0f) return null
        val fitS = Math.min(w / vidW, h / vidH)
        val fillS = Math.max(w / vidW, h / vidH)
        val ratio = fillS / fitS
        val rel = when (vidMode) {
            1 -> 1f
            2 -> ratio
            3 -> vidManual
            else -> if (1f - 1f / ratio <= 0.22f) ratio else 1f
        }
        return floatArrayOf(fitS, ratio, rel)
    }

    private fun applyVidScale() {
        val g = vidGeom() ?: return
        val w = videoBox.width.toFloat()
        val h = videoBox.height.toFloat()
        val s = g[0] * g[2]
        val dw = vidW * s
        val dh = vidH * s
        val mx = Math.max(0f, (dw - w) / 2f)
        val my = Math.max(0f, (dh - h) / 2f)
        vidPanX = vidPanX.coerceIn(-mx, mx)
        vidPanY = vidPanY.coerceIn(-my, my)
        val iw = remoteImg.drawable?.intrinsicWidth?.takeIf { it > 0 } ?: vidW      // 矩阵作用在 drawable 的固有尺寸上（和位图像素数一般相同，这里兜底按密度换算）
        val k = vidW.toFloat() / iw
        val m = Matrix()
        m.setScale(s * k, s * k)
        m.postTranslate((w - dw) / 2f + vidPanX, (h - dh) / 2f + vidPanY)
        remoteImg.imageMatrix = m
    }

    private val vidScaleDet by lazy {
        ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                val g = vidGeom() ?: return false
                vidManual = (g[2] * d.scaleFactor).coerceIn(1f, Math.max(1f, g[1] * 4f))
                vidMode = 3
                applyVidScale()
                return true
            }

            override fun onScaleEnd(d: ScaleGestureDetector) {
                val g = vidGeom() ?: return
                if (vidManual < 1.05f) {
                    vidMode = 1; vidPanX = 0f; vidPanY = 0f
                } else if (Math.abs(vidManual - g[1]) / g[1] < 0.05f) {
                    vidMode = 2
                }
                applyVidScale()
            }
        })
    }

    private val vidGest by lazy {
        GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onDoubleTap(e: MotionEvent): Boolean {        // 双击：完整显示 ⇄ 铺满（和投屏一致）
                val g = vidGeom() ?: return false
                vidMode = if (g[2] > 1.01f) 1 else 2
                vidPanX = 0f; vidPanY = 0f
                applyVidScale()
                android.widget.Toast.makeText(ctx, if (vidMode == 2) "铺满" else "完整显示", android.widget.Toast.LENGTH_SHORT).show()
                return true
            }

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
                if (vidScaleDet.isInProgress) return false
                vidPanX -= distanceX
                vidPanY -= distanceY
                applyVidScale()
                return true
            }
        })
    }

    /** 视频区里浮着的控件摆放：自拍小窗按横 / 竖屏换形状（横屏下的自拍是横的），全屏时躲开刘海 / 挖孔的安全区 */
    private fun applyVidLayout() {
        val land = videoBox.width > videoBox.height
        val m = px(10)
        val l = if (fullApplied) cutL else 0
        val t = if (fullApplied) cutT else 0
        val r = if (fullApplied) cutR else 0
        val b = if (fullApplied) cutB else 0
        val sw = px(if (land) 120 else 84)
        val sh = px(if (land) 90 else 112)
        // 全屏通话页：自拍小窗放右上角（在画质 / 翻转按钮下面），底部留给圆形按钮；内嵌时仍在右下角
        val slp = selfImg.layoutParams as? FrameLayout.LayoutParams
        val sg = if (fullApplied) Gravity.END or Gravity.TOP else Gravity.END or Gravity.BOTTOM
        if (slp != null && slp.gravity != sg) { slp.gravity = sg; selfImg.layoutParams = slp }
        placeVid(selfImg, sw, sh, m + l, m + t + (if (fullApplied) px(56) else 0), m + r, m + b)
        placeVid(vidCtl, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, m + l, m + t, sw + 2 * m + r, m + b)
        placeVid(vidInfo, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, m + l, m + t, m + r, m + b)
    }

    private fun placeVid(v: View, w: Int, h: Int, l: Int, t: Int, r: Int, b: Int) {
        val lp = v.layoutParams as? FrameLayout.LayoutParams ?: return
        if (lp.width == w && lp.height == h && lp.leftMargin == l && lp.topMargin == t && lp.rightMargin == r && lp.bottomMargin == b) return      // 没变就不动，免得反复触发布局
        lp.width = w; lp.height = h; lp.setMargins(l, t, r, b)
        v.layoutParams = lp
    }

    /** 点「全屏」/「退出全屏」：换了版面，画面比例回到自动、平移归零（和投屏切横屏一样，重新按新的屏幕尺寸适配） */
    private fun setVidFull(on: Boolean) {
        if (vidFull == on) return
        vidFull = on
        vidMode = 0; vidManual = 1f; vidPanX = 0f; vidPanY = 0f
        refreshCall()
    }

    /** 返回键：视频通话全屏中 → 先退出全屏（返回 true 表示已处理，不要再退出聊天页） */
    fun exitVideoFull(): Boolean {
        if (callScreen.view.visibility == View.VISIBLE && !callScreen.isEnded) { callScreen.minimize(); return true }   // 全屏通话页：返回键 = 缩小
        if (!vidFull) return false
        setVidFull(false)
        return true
    }

    /** 真全屏：顶栏 / 分隔线 / 通话条 / 消息列表 / 表情面板 / 输入栏全部收起，视频独占整个屏幕（状态栏 / 导航栏由 MainActivity 通过 onVideoFull 收起）；退出时一一还原 */
    private fun applyFull(full: Boolean) {
        val chrome = if (full) View.GONE else View.VISIBLE
        topBar.visibility = chrome
        topLine.visibility = chrome
        composer.visibility = chrome
        scroll.visibility = chrome
        vidInfo.visibility = View.GONE            // 全屏时 时长 / 静音 / 挂断 / 画质 / 翻转 / 摄像头 都在全屏通话页（CallScreen）里，和语音通话一致
        vidMute.visibility = View.GONE
        vidHang.visibility = View.GONE
        vidCtl.visibility = if (full) View.GONE else View.VISIBLE
        if (full == fullApplied) return
        fullApplied = full
        view.setBackgroundColor(if (full) Color.BLACK else C.BG)
        if (full) {
            closePanel()
            try { (ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager).hideSoftInputFromWindow(input.windowToken, 0) } catch (ignored: Exception) { }
            input.clearFocus()
        }
        applyVidLayout()
        onVideoFull(full)
    }

    /** 把视频画面回调挂到本页（MainActivity 回到前台时会调 refreshCall，顺带重新挂上） */
    private fun bindVideo() {
        VoiceCall.onRemoteFrame = { b -> vidW = b.width; vidH = b.height; remoteImg.setImageBitmap(b); applyVidScale(); vidHint.visibility = View.GONE }
        VoiceCall.onLocalFrame = { b -> selfImg.setImageBitmap(b) }
    }

    /** 通话状态变化（含每秒刷新通话时长）时由 MainActivity 调用；通话条在聊天页顶部，无论看的是哪个聊天都显示 */
    fun refreshCall() {
        val st = VoiceCall.st
        val ph = st.phase
        val showVid = ph == "active" && st.video                 // 视频区：只有通话中的视频通话才显示
        if (!showVid) vidFull = false                            // 通话结束 / 还没接通：一定不在全屏
        val cover = callScreen.refresh()                         // 全屏通话页盖着时，顶部通话条收起
        val full = showVid && cover                              // 视频通话接通后默认进入全屏通话页（和语音通话同一套界面）；缩小后退回内嵌视频
        callBar.visibility = if (ph == "idle" || full || cover) View.GONE else View.VISIBLE      // 全屏时通话条收起，静音 / 挂断在画面上
        callBar.setBackgroundColor(Color.parseColor(if (ph == "ringing") "#456A80" else "#1F7A4D"))
        callAns.visibility = if (ph == "ringing") View.VISIBLE else View.GONE
        callMute.visibility = if (ph == "active") View.VISIBLE else View.GONE
        callMute.text = if (st.muted) "取消静音" else "静音"
        callEnd.text = when (ph) { "ringing" -> "拒绝"; "calling" -> "取消"; else -> "挂断" }
        val nm = Link.pairs().firstOrNull { it.id == st.peerId }?.name ?: "对方"
        val secs = ((System.currentTimeMillis() - st.since) / 1000).coerceAtLeast(0)
        callText.text = when (ph) {
            "calling" -> (if (st.video) "📹" else "📞") + " 正在呼叫「$nm」…"
            "ringing" -> if (st.video) "📹「$nm」邀请你视频通话" else "📞「$nm」邀请你无损语音通话"
            "active" -> if (st.video) "📹 与「$nm」视频中 %02d:%02d · 音频无损 PCM · 画质：%s".format(secs / 60, secs % 60, VideoTiers.of(st.tier).name)
                else "🎙 与「$nm」通话中 %02d:%02d · 无损 PCM 48 kHz / 16 bit".format(secs / 60, secs % 60)
            else -> ""
        }
        videoBox.visibility = if (showVid) View.VISIBLE else View.GONE
        if (!showVid) { vidMode = 0; vidManual = 1f; vidPanX = 0f; vidPanY = 0f; vidW = 0; vidH = 0 }
        vidFullBtn.text = "全屏"
        vidMute.text = if (st.muted) "取消静音" else "静音"
        vidInfo.text = "📹 %02d:%02d · %s".format(secs / 60, secs % 60, VideoTiers.of(st.tier).name) + (if (st.muted) " · 已静音" else "")
        applyFull(full)
        if (showVid) {
            bindVideo()
            vidCam.text = if (st.camOn) "关摄像头" else "开摄像头"
            selfImg.visibility = if (st.camOk && st.camOn) View.VISIBLE else View.GONE
            val stale = System.currentTimeMillis() - st.lastVideoRx > 3000
            if (stale) { remoteImg.setImageDrawable(null); vidHint.visibility = View.VISIBLE }
            vidHint.text = if (st.lastVideoRx == 0L) "等待对方画面…" else "对方摄像头已关闭 / 画面中断"
        } else if (ph == "idle") { remoteImg.setImageDrawable(null); selfImg.setImageDrawable(null) }
    }

    fun open(p: Paired) {
        peer = p
        title.text = p.name
        applyAvatar(p)
        applyBio(p)
        view.visibility = View.VISIBLE
        hub().viewing = p.id
        hub().markRead(p.id)
        hub().ensure(p.id)
        closePanel()
        render(true)
        refreshCall()
    }

    fun close() {
        view.visibility = View.GONE
        hub().viewing = null
        closePanel()
        peer = null
        vidFull = false                  // 退出聊天页时一并退出视频全屏（还原系统栏 / 方向）
        applyFull(false)
    }

    /** 数据变化（消息 / 连接 / 文件进度）时由 MainActivity 调用 */
    /** 头像：对方发来了头像就显示圆形头像，否则显示名字首字 */
    private fun applyBio(p: Paired) {
        val t = Bio.peer(p.id)
        bioBar.text = t; bioBar.visibility = if (t.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun applyAvatar(p: Paired) {
        val bmp = Avatar.peerCircle(ctx, p.id, px(88))
        if (bmp != null) { avatar.text = ""; avatar.background = android.graphics.drawable.BitmapDrawable(ctx.resources, bmp); avatar.setOnClickListener { Avatar.show(ctx, Avatar.viewPeer(ctx, p.id)) } }
        else { avatar.text = initial(p.name); avatar.background = circle(CC.AVATAR_BG); avatar.setOnClickListener(null); avatar.isClickable = false }
    }

    fun refresh(id: String?) { if (view.visibility == View.VISIBLE && (id == null || id == peer?.id)) { peer?.let { applyAvatar(it); applyBio(it) }; if (VoiceCall.st.phase != "idle") refreshCall(); peer?.let { hub().markRead(it.id) }; render(false) } }

    private fun send() {
        val p = peer ?: return
        val t = input.text.toString()                 // 原样发送：不去掉首尾空格 / 换行（缩进、代码块不会被改动）
        if (t.isBlank()) return
        val n = t.codePointCount(0, t.length)
        if (n > ChatCrypto.MAX_TEXT) {                // 超长不再悄悄截断：明确提示，内容留在输入框里
            android.widget.Toast.makeText(ctx, "这条消息有 $n 字，超过单条上限 ${ChatCrypto.MAX_TEXT} 字。为避免内容被截断，没有发送，请拆成几条再发（内容还在输入框里）", android.widget.Toast.LENGTH_LONG).show()
            return
        }
        hub().sendText(p.id, t)
        input.setText("")
    }

    private fun togglePanel() { if (panelOpen) closePanel() else { panelOpen = true; panel.visibility = View.VISIBLE; renderPanel(); (ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager).hideSoftInputFromWindow(input.windowToken, 0) } }
    private fun closePanel() { panelOpen = false; panel.visibility = View.GONE }

    private fun renderPanel() {
        panelBody.removeAllViews()
        if (tab == 0) {
            val per = 3
            var row: LinearLayout? = null
            for ((i, s) in ChatData.STICKERS.withIndex()) {
                if (i % per == 0) { row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }; panelBody.addView(row, LinearLayout.LayoutParams(MATCH, WRAP)) }
                row!!.addView(stickerView(s.e, s.c, listOf(s.bg1, s.bg2), 30f, 12f).apply {
                    setOnClickListener { peer?.let { p -> hub().sendSticker(p.id, s) }; closePanel() }; fluid()
                }, LinearLayout.LayoutParams(0, WRAP, 1f).apply { setMargins(px(3), px(3), px(3), px(3)) })
            }
        } else {
            val list = ChatData.EMOJI_GROUPS[tab - 1].second
            val per = 7
            var row: LinearLayout? = null
            for ((i, e) in list.withIndex()) {
                if (i % per == 0) { row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }; panelBody.addView(row, LinearLayout.LayoutParams(MATCH, WRAP)) }
                row!!.addView(tv(e, 24f).apply {
                    gravity = Gravity.CENTER; setPadding(0, px(6), 0, px(6))
                    setOnClickListener { input.append(e) }; fluid()
                }, LinearLayout.LayoutParams(0, WRAP, 1f))
            }
        }
    }

    private fun color(s: String, d: Int) = try { Color.parseColor(s) } catch (e: Exception) { d }

    private fun stickerView(e: String, c: String, bg: List<String>, emojiSp: Float, capSp: Float): View {
        val b = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            setPadding(px(8), px(10), px(8), px(8))
            background = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(color(bg.getOrNull(0) ?: "#fff3c4", Color.WHITE), color(bg.getOrNull(1) ?: "#ffd37a", Color.LTGRAY))).apply { cornerRadius = px(14).toFloat() }
        }
        b.addView(tv(e, emojiSp).apply { gravity = Gravity.CENTER })
        if (c.isNotEmpty()) b.addView(tv(c, capSp, Color.parseColor("#3A2E10"), true).apply { gravity = Gravity.CENTER; maxLines = 1 })
        return b
    }

    private fun render(toEnd: Boolean) {
        val p = peer ?: return
        val h = hub()
        val conn = h.isConnected(p.id)
        val sas = h.sas(p.id)
        val pr = h.pendingRecalls(p.id)
        status.text = (if (conn) "🔒 端到端加密已连接" + (if (sas.isNotEmpty()) " · 点此核对安全码" else "")
        else if (Link.peers.containsKey(p.id)) "设备在线 · 正在建立加密连接…" else "设备离线 · 消息会在对方上线后自动送达") +
            (if (pr > 0) " · 有 $pr 条撤回等对方上线后生效" else "")
        val nearEnd = scroll.getChildAt(0).let { it.bottom - (scroll.height + scroll.scrollY) < px(80) }
        listBox.removeAllViews()
        class Item(val ts: Long, val v: View)
        val items = ArrayList<Item>()
        val msgs = h.messages(p.id).takeLast(200)
        for (m in msgs) items.add(Item(m.ts, msgView(m, p)))
        val first = msgs.firstOrNull()?.ts ?: 0L
        for (x in FileXfer.list) if (x.peerId == p.id && x.t0 >= first) items.add(Item(x.t0, fileView(x)))
        items.sortBy { it.ts }
        if (items.isEmpty()) listBox.addView(tv("🔒 消息端到端加密，只在你们两台设备之间传递。\n打个招呼，或者发个表情包吧～", 13f, C.SUB).apply { gravity = Gravity.CENTER; setPadding(px(16), px(40), px(16), px(16)) })
        var lastDay = -1
        for (item in items) {
            val dk = dayKey(item.ts)
            if (dk != lastDay) { listBox.addView(dateChip(item.ts)); lastDay = dk }
            listBox.addView(item.v)
        }
        if (toEnd || nearEnd) scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun dayKey(ts: Long): Int {
        val c = Calendar.getInstance().apply { timeInMillis = ts }
        return c.get(Calendar.YEAR) * 1000 + c.get(Calendar.DAY_OF_YEAR)
    }

    /** 今天 / 昨天 / 本年的「M月d日」/ 往年的「yyyy年M月d日」 */
    private fun dayLabel(ts: Long): String {
        val k = dayKey(ts)
        val now = Calendar.getInstance()
        if (k == now.get(Calendar.YEAR) * 1000 + now.get(Calendar.DAY_OF_YEAR)) return "今天"
        val y = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
        if (k == y.get(Calendar.YEAR) * 1000 + y.get(Calendar.DAY_OF_YEAR)) return "昨天"
        val pattern = if (k / 1000 == now.get(Calendar.YEAR)) "M月d日" else "yyyy年M月d日"
        return SimpleDateFormat(pattern, Locale.getDefault()).format(Date(ts))
    }

    private fun dateChip(ts: Long): View = LinearLayout(ctx).apply {
        gravity = Gravity.CENTER
        addView(tv(dayLabel(ts), 11f, C.SUB).apply {
            setPadding(px(12), px(4), px(12), px(4)); background = ctx.shape(CC.CHIP, 12f)
        })
        layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = px(14); bottomMargin = px(2) }
    }

    /** state：我发的消息的状态（sending / sent），sent 时在时间后面画双勾；文件卡片传空串。 */
    private fun row(mine: Boolean, content: View, time: String, state: String = "", failedId: String? = null, recallId: String? = null,
                    act: (() -> Unit)? = null, actLabel: String = "撤回"): View {
        val r = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; gravity = if (mine) Gravity.END else Gravity.START }
        val wrap = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; gravity = if (mine) Gravity.END else Gravity.START }
        wrap.addView(content, (content.layoutParams as? LinearLayout.LayoutParams) ?: LinearLayout.LayoutParams(WRAP, WRAP))      // 图片 / 视频气泡自带固定尺寸
        val meta = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(px(4), px(3), px(4), 0)
        }
        val label = when {
            failedId != null -> "$time · ❗ 未送达，点此重试"
            state == "sending" -> "$time · 发送中…"
            else -> time
        }
        meta.addView(tv(label, 10.5f, if (failedId != null) C.BAD else C.SUB))
        if (mine && state == "sent" && failedId == null) {
            meta.addView(IconView(ctx, "check2", CC.TICK, false, 2.0f), LinearLayout.LayoutParams(px(15), px(15)).apply { marginStart = px(3) })
        }
        if (mine && recallId != null) {                       // 撤回：只有自己发的消息有，没有时间限制，两边一起删
            meta.addView(tv("撤回", 10.5f, C.SUB).apply {
                paint.isUnderlineText = true
                setPadding(px(10), px(6), px(6), px(6))
                setOnClickListener { confirmRecall(recallId) }; fluid()
            })
        }
        if (mine && act != null) {                            // 文件卡片的「撤回 / 删除」
            meta.addView(tv(actLabel, 10.5f, C.SUB).apply {
                paint.isUnderlineText = true
                setPadding(px(10), px(6), px(6), px(6))
                setOnClickListener { act() }; fluid()
            })
        }
        if (failedId != null) { meta.setOnClickListener { peer?.let { hub().retry(it.id, failedId) } }; meta.fluid() }
        wrap.addView(meta, LinearLayout.LayoutParams(WRAP, WRAP))      // 必须 WRAP：默认的 MATCH 会把这行限制在气泡宽度内，短消息的「撤回」会被挤成 0 宽
        r.addView(wrap, LinearLayout.LayoutParams(WRAP, WRAP))
        return r.also { it.layoutParams = LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = px(8) } }
    }

    private fun msgView(m: ChatMsg, p: Paired): View {
        val mine = m.mine
        val content: View = if (m.k == "s") stickerView(m.e, m.c, m.bg, 54f, 14f).apply { minimumWidth = px(120) }
        else tv(m.x, 15.5f, if (mine) Color.WHITE else C.INK).apply {
            setPadding(px(14), px(10), px(14), px(10)); maxWidth = ctx.resources.displayMetrics.widthPixels * 72 / 100
            setLineSpacing(0f, 1.1f)
            background = ctx.shape(if (mine) CC.BUBBLE else C.CARD, 20f, if (mine) CC.BUBBLE else C.CARD_LINE, 1f)
            setTextIsSelectable(true)
        }
        val time = fmt.format(Date(m.ts))
        return row(mine, content, time, if (mine) m.st else "", if (mine && m.st == "failed") m.id else null, if (mine) m.id else null)
    }

    private fun fileView(x: Xfer): View {
        val kind = MediaKind.of(x.name)
        val uri = x.uri
        // 图片 / 视频：对方发来的要等校验通过（done）才有可预览的文件；我发的从一开始就能看到原文件
        val media = kind != MediaKind.NONE && uri != null && (x.state == "done" || x.send)
        val c: View = if (media && uri != null) mediaCard(x, kind, uri) else plainFileCard(x)
        val act: (() -> Unit)? = if (!x.send) null else if (x.state == "done" || x.active) ({ confirmRecallFile(x) }) else ({ FileXfer.removeLocal(x) })
        val label = if (x.send && x.state != "done" && !x.active) "删除" else "撤回"
        return row(x.send, c, fmt.format(Date(x.t0)), act = act, actLabel = label)
    }

    private fun plainFileCard(x: Xfer): View {
        val c = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(px(14), px(10), px(14), px(10)); background = ctx.shape(C.SOFT, 14f, C.CARD_LINE, 1f) }
        c.addView(tv((if (x.send) "📤 " else "📥 ") + x.name, 14f, C.INK, true).apply { maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE })
        c.addView(tv(xferStatus(x), 12f, C.SUB).apply { setPadding(0, px(4), 0, 0) })
        val u = x.uri
        if (x.state == "done" && u != null) {                  // 非图片 / 视频的文件：点一下用系统里的应用打开
            c.setOnClickListener {
                try {
                    ctx.startActivity(android.content.Intent.createChooser(android.content.Intent(android.content.Intent.ACTION_VIEW)
                        .setDataAndType(u, MediaKind.mime(x.name)).addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION), "打开方式"))
                } catch (e: Exception) { android.widget.Toast.makeText(ctx, "没有可以打开这个文件的应用", android.widget.Toast.LENGTH_SHORT).show() }
            }; c.fluid()
        }
        return c
    }

    private fun xferStatus(x: Xfer): String {
        val pct = if (x.size > 0L) (x.done * 100 / x.size).toInt() else 0
        return when (x.state) {
            "sending", "receiving" -> "$pct% · ${FileXfer.human(x.done)} / ${FileXfer.human(x.size)}"
            "verifying" -> "校验中…"
            "done" -> "已完成 · " + FileXfer.human(x.size)
            "failed" -> "失败：" + x.msg
            "cancelled" -> "已取消"
            "offering" -> "等待对方确认…"
            else -> x.state
        }
    }

    /** 图片 / 视频气泡：缩略图（点开是全分辨率的原文件预览）；视频带播放键和时长；传输中 / 失败时盖一层状态 */
    private fun mediaCard(x: Xfer, kind: Int, uri: android.net.Uri): View {
        val w = minOf(px(240), ctx.resources.displayMetrics.widthPixels * 62 / 100)
        val cached = Thumbs.get(uri)
        fun hOf(b: android.graphics.Bitmap?): Int =
            if (b == null || b.width <= 0) w * 3 / 4 else (w.toFloat() * (b.height.toFloat() / b.width).coerceIn(0.6f, 1.5f)).toInt()
        val radius = px(14).toFloat()
        val box = FrameLayout(ctx).apply {
            setBackgroundColor(Color.parseColor("#1F000000"))
            outlineProvider = object : android.view.ViewOutlineProvider() {         // 显式圆角轮廓（流光风格下 shape() 是玻璃背景，没有轮廓可裁）
                override fun getOutline(v: View, o: android.graphics.Outline) { o.setRoundRect(0, 0, v.width, v.height, radius) }
            }
            clipToOutline = true
            layoutParams = LinearLayout.LayoutParams(w, hOf(cached))
        }
        val iv = ImageView(ctx).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        box.addView(iv, FrameLayout.LayoutParams(MATCH, MATCH))
        if (cached != null) iv.setImageBitmap(cached)
        else Thumbs.load(ctx, uri, kind) { b ->
            if (b != null) {
                iv.setImageBitmap(b)
                (box.layoutParams as? LinearLayout.LayoutParams)?.let { lp -> lp.height = hOf(b); box.layoutParams = lp }
            }
        }
        if (kind == MediaKind.VIDEO) {
            box.addView(tv("▶", 20f, Color.WHITE, true).apply {
                gravity = Gravity.CENTER; background = circle(Color.parseColor("#88000000"))
            }, FrameLayout.LayoutParams(px(46), px(46), Gravity.CENTER))
            val d = Thumbs.duration(uri)
            if (d > 0) box.addView(tv(Thumbs.clock(d), 11f, Color.WHITE, true).apply {
                setPadding(px(7), px(2), px(7), px(2)); background = ctx.shape(Color.parseColor("#99000000"), 8f)
            }, FrameLayout.LayoutParams(WRAP, WRAP, Gravity.END or Gravity.BOTTOM).apply { setMargins(px(6), px(6), px(6), px(6)) })
        }
        if (x.state != "done") {                                // 发送中 / 等对方确认 / 失败：盖一层状态，缩略图依然能看
            box.addView(tv(xferStatus(x), 12.5f, Color.WHITE, true).apply {
                gravity = Gravity.CENTER; setPadding(px(10), px(10), px(10), px(10)); setBackgroundColor(Color.parseColor("#88000000"))
            }, FrameLayout.LayoutParams(MATCH, MATCH))
        }
        box.setOnClickListener { openViewer(x, kind, uri) }; box.fluid()
        return box
    }

    private fun openViewer(x: Xfer, kind: Int, uri: android.net.Uri) {
        if (x.state != "done" && !x.send) return
        MediaViewer.show(ctx, uri, x.name, x.size, kind, if (x.send && x.state == "done") ({ confirmRecallFile(x) }) else null)
    }

    private fun confirmRecallFile(x: Xfer) {
        val p = peer ?: return
        AlertDialog.Builder(ctx).setTitle("撤回这个文件？")
            .setMessage("撤回后，这个文件会从你和「" + p.name + "」的聊天里一起消失，没有时间限制。\n\n" +
                "对方使用新版本的瞬流（安卓版 / 电脑版）时，已经保存到对方设备里的文件也会被一并删除（对方不在线，会在上线后自动执行）；" +
                "对方使用不认识文件撤回的旧版本时，只会撤掉聊天记录，已保存的文件不会被删除。已经被对方转发、另存或截图的内容无法收回。" +
                (if (x.active) "\n\n这个文件还在传输中，撤回会中止本批其余尚未完成的文件。" else ""))
            .setPositiveButton("撤回") { _, _ -> FileXfer.recallSent(x) }
            .setNegativeButton("取消", null).show()
    }

    private fun confirmRecall(msgId: String) {
        val p = peer ?: return
        AlertDialog.Builder(ctx).setTitle("撤回这条消息？")
            .setMessage("撤回后，这条消息会从你和「" + p.name + "」的聊天记录里一起删除，没有时间限制，对方看不到任何痕迹。\n\n" +
                "如果对方现在不在线，会在对方上线后自动撤回。已经被对方复制、截图的内容无法收回。")
            .setPositiveButton("撤回") { _, _ -> hub().recall(p.id, msgId) }
            .setNegativeButton("取消", null).show()
    }

    private fun showSas() {
        val p = peer ?: return
        val sas = hub().sas(p.id)
        if (sas.isEmpty()) return
        AlertDialog.Builder(ctx).setTitle("🔒 安全码").setMessage(sas + "\n\n请和对方当面（或电话）核对：两台设备上显示的这串数字必须完全一样，才说明没有人在中间窃听。")
            .setPositiveButton("知道了", null).show()
    }

    private fun menu() {
        val p = peer ?: return
        AlertDialog.Builder(ctx).setItems(arrayOf("核对安全码", "清空聊天记录")) { _, i ->
            if (i == 0) { if (hub().sas(p.id).isEmpty()) android.widget.Toast.makeText(ctx, "还没建立加密连接", android.widget.Toast.LENGTH_SHORT).show() else showSas() }
            else AlertDialog.Builder(ctx).setMessage("清空与「" + p.name + "」的聊天记录？（只清本机）").setPositiveButton("清空") { _, _ -> hub().clear(p.id) }.setNegativeButton("取消", null).show()
        }.show()
    }
}
