package com.lancast.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.content.ContextCompat

/**
 * 后台常驻接收（可选，设置页里开关）。
 *
 * 瞬流的监听（TCP 47800 + 设备发现）跑在应用进程里。安卓 ↔ 安卓时，接收方手机通常揣在兜里、
 * 应用在后台甚至已被系统回收，对方就会「连接失败」。打开这个开关后，用一个低优先级前台服务把进程保活：
 *   · 对方发文件：直接在后台接收（FileService 会接着显示进度）；
 *   · 对方扫码配对：直接在后台完成；
 *   · 对方要投屏 / 看屏幕：弹出通知，点按后回到应用处理（见 Link.park）。
 * 前台服务类型用 connectedDevice（不像 dataSync 有 Android 15 的 6 小时限制）。
 */
class ListenService : Service() {
    companion object {
        private const val CH = "lancast_listen"
        private const val NID = 3

        fun enabled(): Boolean = Link.prefs.getBoolean("bg_listen", false)

        fun setEnabled(ctx: Context, on: Boolean) {
            Link.prefs.edit().putBoolean("bg_listen", on).apply()
            if (on) start(ctx) else stop(ctx)
        }

        fun start(ctx: Context) {
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, ListenService::class.java))
            } catch (ignored: Exception) {
                // 应用在后台时系统可能不允许启动前台服务；下次打开应用会再启动
            }
        }

        fun stop(ctx: Context) {
            try {
                ctx.stopService(Intent(ctx, ListenService::class.java))
            } catch (ignored: Exception) {
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Link.init(this)          // 服务可能在没有 Activity 的情况下被系统重新拉起
        Link.start()
        goForeground()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        goForeground()
        return START_STICKY
    }

    private fun goForeground() {
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CH, "后台接收", NotificationManager.IMPORTANCE_MIN))
            val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
            val n = Notification.Builder(this, CH)
                .setSmallIcon(android.R.drawable.stat_notify_sync)
                .setContentTitle("瞬流 正在后台等待连接")
                .setContentText("其他设备可以随时向本机发送文件；可在设置里关闭")
                .setContentIntent(pi)
                .setOngoing(true)
                .build()
            startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE)
        } catch (e: Exception) {
            stopSelf()
        }
    }
}

/** 「有人想连你」的通知（应用在后台时用）。 */
object Notice {
    private const val CH = "lancast_incoming"
    private const val NID = 4

    fun incoming(title: String, text: String) {
        try {
            val ctx = Link.app
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CH, "连接请求", NotificationManager.IMPORTANCE_HIGH))
            val open = Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            val pi = PendingIntent.getActivity(ctx, 1, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val n = Notification.Builder(ctx, CH)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle(title)
                .setContentText(text)
                .setContentIntent(pi)
                .setAutoCancel(true)
                .setTimeoutAfter(45_000L)
                .build()
            nm.notify(NID, n)
        } catch (ignored: Exception) {
            // 没有通知权限：只能等用户自己打开应用，挂起超时后对方会收到「没有及时打开」
        }
    }

    /** 聊天新消息通知；点开直接进入该设备的聊天页 */
    fun chat(peerId: String, name: String, text: String) {
        try {
            val ctx = Link.app
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel("lancast_chat", "聊天消息", NotificationManager.IMPORTANCE_HIGH))
            val open = Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("chatPeer", peerId)
            val pi = PendingIntent.getActivity(ctx, 100 + (peerId.hashCode() and 0xFFF), open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val n = Notification.Builder(ctx, "lancast_chat").setSmallIcon(android.R.drawable.stat_notify_chat)
                .setContentTitle(name).setContentText(text).setContentIntent(pi).setAutoCancel(true).build()
            nm.notify(1000 + (peerId.hashCode() and 0xFFF), n)
        } catch (ignored: Exception) { }
    }

    fun clearIncoming() {
        try {
            (Link.app.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).cancel(NID)
        } catch (ignored: Exception) {
        }
    }
}
