package com.lancast.app.browser

import android.content.Context
import android.graphics.Canvas
import android.graphics.Outline
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewOutlineProvider
import kotlin.math.hypot

/**
 * 嗅探到资源后出现的圆形悬浮球：
 * - 可以在整个页面上随意拖动，松手后自动吸附到左 / 右边缘，位置会记住（下次打开仍在原处）；
 * - 右上角红色角标显示资源数量；
 * - 点一下（没有拖动）触发 [onClick]；静止一会儿后变半透明，减少对网页的遮挡。
 * 视图本身比圆形大一圈（透明边），既给角标留出空间，也让手指更容易点中。
 */
class FloatingBall(ctx: Context) : View(ctx) {

    /** 视图边长（px）；圆本身直径为 [ballPx]。 */
    val sizePx: Int = ctx.dp(60)
    private val ballPx: Float = ctx.dp(48).toFloat()

    var onClick: (() -> Unit)? = null
    var count: Int = 0
        set(v) {
            field = v
            contentDescription = "发现 $v 个资源"
            invalidate()
        }

    private val prefs = ctx.getSharedPreferences("sniff_ui", Context.MODE_PRIVATE)
    private var snapRight = prefs.getBoolean("ball_right", true)
    private var yFrac = prefs.getFloat("ball_y", 0.78f)

    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private var downRawX = 0f
    private var downRawY = 0f
    private var startX = 0f
    private var startY = 0f
    private var dragging = false

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Ui.PRIMARY }
    private val glyph = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Ui.WHITE }
    private val badgeFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Ui.RED }
    private val badgeRing = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Ui.WHITE }
    private val badgeText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Ui.WHITE
        typeface = Typeface.DEFAULT_BOLD
        textAlign = Paint.Align.CENTER
        textSize = ctx.dp(10).toFloat()
    }
    private val path = Path()

    private val idleFade = Runnable { animate().alpha(0.72f).setDuration(300).start() }

    private val parentLayoutListener = View.OnLayoutChangeListener { _, l, t, r, b, ol, ot, or2, ob ->
        if ((r - l != or2 - ol || b - t != ob - ot) && !dragging) applyPosition(false)
    }

    init {
        visibility = GONE
        isClickable = true
        elevation = ctx.dp(6).toFloat()
        val inset = (sizePx - ballPx) / 2f
        outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setOval(inset.toInt(), inset.toInt(), (sizePx - inset).toInt(), (sizePx - inset).toInt())
                outline.alpha = 1f
            }
        }
    }

    // ---------- 显示 / 位置 ----------

    fun showBall(show: Boolean) {
        if (show) {
            if (visibility == VISIBLE) return
            visibility = VISIBLE
            applyPosition(false)
            alpha = 0f
            scaleX = 0.6f
            scaleY = 0.6f
            animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(180).start()
            scheduleIdle()
        } else {
            animate().cancel()
            removeCallbacks(idleFade)
            visibility = GONE
        }
    }

    /** 新资源出现时轻轻弹一下，并恢复不透明。 */
    fun pulse() {
        animate().cancel()
        alpha = 1f
        animate().scaleX(1.15f).scaleY(1.15f).setDuration(120).withEndAction {
            animate().scaleX(1f).scaleY(1f).setDuration(120).start()
        }.start()
        scheduleIdle()
    }

    private fun scheduleIdle() {
        removeCallbacks(idleFade)
        postDelayed(idleFade, 2500)
    }

    private fun maxX(p: View) = maxOf(0, p.width - sizePx).toFloat()
    private fun maxY(p: View) = maxOf(0, p.height - sizePx).toFloat()

    /** 按记住的“靠左/靠右 + 纵向比例”摆放；父容器尺寸变化（旋转、键盘）时也会重新摆放。 */
    private fun applyPosition(animated: Boolean) {
        val p = parent as? View ?: return
        if (p.width == 0 || p.height == 0) return
        val tx = if (snapRight) maxX(p) else 0f
        val ty = minOf(maxOf(yFrac * maxY(p), 0f), maxY(p))
        if (animated) animate().x(tx).y(ty).setDuration(180).start()
        else {
            x = tx
            y = ty
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        (parent as? View)?.addOnLayoutChangeListener(parentLayoutListener)
        post { applyPosition(false) }
    }

    override fun onDetachedFromWindow() {
        (parent as? View)?.removeOnLayoutChangeListener(parentLayoutListener)
        removeCallbacks(idleFade)
        super.onDetachedFromWindow()
    }

    // ---------- 触摸：拖动 / 点击 ----------

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val p = parent as? View ?: return false
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                removeCallbacks(idleFade)
                animate().cancel()
                alpha = 1f
                downRawX = e.rawX
                downRawY = e.rawY
                startX = x
                startY = y
                dragging = false
                parent.requestDisallowInterceptTouchEvent(true)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - downRawX
                val dy = e.rawY - downRawY
                if (!dragging && hypot(dx, dy) > slop) {
                    dragging = true
                    animate().scaleX(1.1f).scaleY(1.1f).setDuration(100).start()
                }
                if (dragging) {
                    x = minOf(maxOf(startX + dx, 0f), maxX(p))
                    y = minOf(maxOf(startY + dy, 0f), maxY(p))
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (dragging) {
                    dragging = false
                    snapToEdge(p)
                } else if (e.actionMasked == MotionEvent.ACTION_UP) {
                    performClick()
                }
                scheduleIdle()
                return true
            }
        }
        return super.onTouchEvent(e)
    }

    override fun performClick(): Boolean {
        super.performClick()
        onClick?.invoke()
        return true
    }

    /** 松手后吸附到离得近的一侧，并记住位置。 */
    private fun snapToEdge(p: View) {
        snapRight = x + sizePx / 2f > p.width / 2f
        val my = maxY(p)
        yFrac = if (my > 0f) minOf(maxOf(y / my, 0f), 1f) else 0f
        prefs.edit().putBoolean("ball_right", snapRight).putFloat("ball_y", yFrac).apply()
        animate().scaleX(1f).scaleY(1f).x(if (snapRight) maxX(p) else 0f).setDuration(180).start()
    }

    // ---------- 绘制 ----------

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = ballPx / 2f
        canvas.drawCircle(cx, cy, r, fill)

        // 播放三角（略向右偏，视觉上更居中）
        val s = r * 0.5f
        path.reset()
        path.moveTo(cx - s * 0.55f, cy - s)
        path.lineTo(cx - s * 0.55f, cy + s)
        path.lineTo(cx + s * 0.95f, cy)
        path.close()
        canvas.drawPath(path, glyph)

        // 右上角数量角标
        if (count > 0) {
            val br = context.dp(9).toFloat()
            val bx = cx + r * 0.72f
            val by = cy - r * 0.72f
            canvas.drawCircle(bx, by, br + context.dp(3) / 2f, badgeRing)
            canvas.drawCircle(bx, by, br, badgeFill)
            val text = if (count > 9) "9+" else count.toString()
            val fm = badgeText.fontMetrics
            canvas.drawText(text, bx, by - (fm.ascent + fm.descent) / 2f, badgeText)
        }
    }
}

/** 几个简单的线条图标，全部用 Canvas 绘制，不依赖资源文件。 */
class Glyph(ctx: Context, private val kind: Int, color: Int) : View(ctx) {
    companion object {
        const val FOLDER = 0
        const val DOWNLOAD = 1
        const val CHEVRON = 2   // 朝下；旋转 180° 即朝上
        const val PLAY = 3
        const val DOTS = 4
        const val CLOSE = 5
    }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        this.color = color
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val path = Path()

    override fun onDraw(canvas: Canvas) {
        val s = minOf(width, height) / 24f       // 把 24x24 的设计网格缩放到视图大小
        canvas.save()
        canvas.translate((width - 24f * s) / 2f, (height - 24f * s) / 2f)
        paint.strokeWidth = 2f * s
        paint.style = Paint.Style.STROKE
        path.reset()
        when (kind) {
            FOLDER -> {
                path.moveTo(3f * s, 7f * s); path.lineTo(9f * s, 7f * s); path.lineTo(11f * s, 9.5f * s)
                path.lineTo(21f * s, 9.5f * s); path.lineTo(21f * s, 19f * s); path.lineTo(3f * s, 19f * s)
                path.close()
                canvas.drawPath(path, paint)
            }
            DOWNLOAD -> {
                path.moveTo(12f * s, 4f * s); path.lineTo(12f * s, 15f * s)
                path.moveTo(7f * s, 10.5f * s); path.lineTo(12f * s, 15.5f * s); path.lineTo(17f * s, 10.5f * s)
                path.moveTo(5f * s, 20f * s); path.lineTo(19f * s, 20f * s)
                canvas.drawPath(path, paint)
            }
            CHEVRON -> {
                path.moveTo(6f * s, 9f * s); path.lineTo(12f * s, 15f * s); path.lineTo(18f * s, 9f * s)
                canvas.drawPath(path, paint)
            }
            PLAY -> {
                paint.style = Paint.Style.FILL
                path.moveTo(8f * s, 5f * s); path.lineTo(8f * s, 19f * s); path.lineTo(19f * s, 12f * s)
                path.close()
                canvas.drawPath(path, paint)
            }
            DOTS -> {
                paint.style = Paint.Style.FILL
                canvas.drawCircle(5f * s, 12f * s, 2f * s, paint)
                canvas.drawCircle(12f * s, 12f * s, 2f * s, paint)
                canvas.drawCircle(19f * s, 12f * s, 2f * s, paint)
            }
            CLOSE -> {
                path.moveTo(6f * s, 6f * s); path.lineTo(18f * s, 18f * s)
                path.moveTo(18f * s, 6f * s); path.lineTo(6f * s, 18f * s)
                canvas.drawPath(path, paint)
            }
        }
        canvas.restore()
    }
}
