package com.lancast.app

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Environment
import android.os.PowerManager
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import org.json.JSONObject
import java.io.DataInputStream
import java.io.IOException
import java.nio.ByteBuffer
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

/*
 * LANCast 文件互传（安卓端）
 *
 * 复用投屏的「设备发现 + PIN 认证」：连接 TCP 47800，HELLO 里 mode = "file"，对方 accept 之后，
 * 这条连接就不再按「包」解析，而是变成裸字节流。每个文件一条独立连接，握手之后的协议（所有整数大端）：
 *
 *   发送方 -> 接收方   u32 头长度 | 头 JSON(UTF-8) {name, size, from}
 *   接收方 -> 发送方   1 字节  0x01 同意 / 0x00 拒绝
 *   发送方 -> 接收方   size 字节原始数据 | 32 字节 SHA-256(整个文件)
 *   接收方 -> 发送方   1 字节  0x01 校验通过 / 0x00 失败（失败则接收方删除半成品）
 *
 * 无损：文件只当字节流，不转码、不压缩；两端各自算 SHA-256 并比对。
 * 不限大小：流式处理，每次 1 MiB；超时含义是「连续 30 秒没有任何数据」。
 * 安全落盘：先以 IS_PENDING 写入 下载/LANCast，校验通过才对其他应用可见；失败则删除。
 */

fun fmtSize(bytes: Long): String {
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    var v = bytes.toDouble()
    var i = 0
    while (v >= 1024 && i < units.size - 1) {
        v /= 1024
        i++
    }
    return if (i == 0) "$bytes B" else String.format(Locale.US, "%.1f %s", v, units[i])
}

/** 进度 + 速度，每 0.2 秒最多上报一次。 */
private class XferMeter(private val kind: String, private val label: String, private val total: Long) {
    private val t0 = System.nanoTime()
    private var last = 0L

    fun update(done: Long, force: Boolean = false) {
        val now = System.nanoTime()
        if (!force && done < total && now - last < 200_000_000L) return
        last = now
        val sec = (now - t0) / 1e9
        val speed = if (sec > 0) (done / sec).toLong() else 0L
        val pm = if (total > 0) (done * 1000 / total).toInt() else 1000
        FileXfer.progress(kind, "$label\n${fmtSize(done)} / ${fmtSize(total)}   ${fmtSize(speed)}/s", pm)
    }
}

object FileXfer {
    private const val CHUNK = 1 shl 20          // 1 MiB
    private const val MAX_HEADER = 64 * 1024

    /** 进度回调（主线程）：kind = "send" / "recv"，文本，千分比。 */
    @Volatile
    var onProgress: ((String, String, Int) -> Unit)? = null

    /** 日志回调（主线程），参数是当前完整日志文本。 */
    @Volatile
    var onLog: ((String) -> Unit)? = null

    private val logBuf = StringBuilder()
    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    private var busyCount = 0
    private var wake: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null

    fun logText(): String = synchronized(logBuf) { logBuf.toString() }

    fun log(s: String) {
        val text = synchronized(logBuf) {
            logBuf.append(timeFmt.format(Date())).append("  ").append(s).append('\n')
            if (logBuf.length > 20000) logBuf.delete(0, logBuf.length - 15000)
            logBuf.toString()
        }
        Link.main.post { onLog?.invoke(text) }
    }

    fun progress(kind: String, text: String, pm: Int) {
        Link.main.post { onProgress?.invoke(kind, text, pm) }
    }

    /** 传输期间保持 CPU 与 Wi-Fi 高性能，息屏也不掉速。 */
    @Synchronized
    @Suppress("DEPRECATION")
    private fun beginBusy() {
        if (busyCount++ == 0) {
            try {
                val pm = Link.app.getSystemService(Context.POWER_SERVICE) as PowerManager
                val wm = Link.app.getSystemService(Context.WIFI_SERVICE) as WifiManager
                val wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "lancast:xfer")
                wl.setReferenceCounted(false)
                wl.acquire(6 * 60 * 60 * 1000L)
                wake = wl
                val fl = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "lancast:xfer")
                fl.setReferenceCounted(false)
                fl.acquire()
                wifi = fl
            } catch (ignored: Exception) {
            }
        }
    }

    @Synchronized
    private fun endBusy() {
        if (busyCount > 0 && --busyCount == 0) {
            try {
                if (wake?.isHeld == true) wake?.release()
            } catch (ignored: Exception) {
            }
            try {
                if (wifi?.isHeld == true) wifi?.release()
            } catch (ignored: Exception) {
            }
            wake = null
            wifi = null
        }
    }

    /** 只改名，不改内容：去掉目录部分（防路径穿越）和控制字符，并把 UTF-8 长度限制在 240 字节内。 */
    private fun safeName(raw: String): String {
        var n = raw.replace('\\', '/').substringAfterLast('/')
        n = n.map { if (it.code < 32) '_' else it }.joinToString("").trim()
        if (n.isEmpty() || n == "." || n == "..") n = "unnamed"
        if (n.toByteArray(Charsets.UTF_8).size > 240) {
            val dot = n.lastIndexOf('.')
            val ext = if (dot > 0 && n.length - dot <= 16) n.substring(dot) else ""
            var base = n.removeSuffix(ext)
            while (base.isNotEmpty() && (base + ext).toByteArray(Charsets.UTF_8).size > 240) base = base.dropLast(1)
            if (base.isNotEmpty() && base.last().isHighSurrogate()) base = base.dropLast(1)
            n = if (base.isEmpty()) "unnamed$ext" else base + ext
        }
        return n
    }

    private fun queryMeta(uri: Uri): Pair<String, Long> {
        var name = "file"
        var size = -1L
        val cols = arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE)
        Link.app.contentResolver.query(uri, cols, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val si = c.getColumnIndex(OpenableColumns.SIZE)
                if (ni >= 0 && !c.isNull(ni)) name = c.getString(ni)
                if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
            }
        }
        return Pair(name, size)
    }

    private fun readN(inp: DataInputStream, n: Int): ByteArray {
        val b = ByteArray(n)
        inp.readFully(b)
        return b
    }

    /* ═════════════ 接收 ═════════════ */

    /**
     * 对方（已通过 PIN 认证，mode = file）要给我发文件。
     * 在调用线程里完成整个接收，结束后关闭连接；不依赖界面是否在前台。
     */
    fun receive(se: Session) {
        if (!Link.receiveEnabled) {
            se.reject("对方已关闭接收文件")
            log("已拒绝「${se.peerName}」发来的文件（接收开关已关闭）")
            return
        }
        var pending: Uri? = null
        val resolver = Link.app.contentResolver
        beginBusy()
        try {
            se.accept()
            se.setSoTimeout(30_000)                    // 30 秒收不到任何数据才算断线，不限总时长
            val inp = se.rawIn
            val out = se.rawOut

            val hlen = ByteBuffer.wrap(readN(inp, 4)).int
            if (hlen <= 0 || hlen > MAX_HEADER) throw IOException("文件头非法")
            val hdr = JSONObject(String(readN(inp, hlen), Charsets.UTF_8))
            val size = hdr.getLong("size")
            if (size < 0) throw IOException("文件大小非法")
            var from = hdr.optString("from", "")
            if (from.isEmpty()) from = se.peerName
            if (from.isEmpty()) from = se.remoteIp

            val name = safeName(hdr.getString("name"))
            // MIME 由扩展名推出，与系统 MediaStore 用的是同一张表，系统就不会给文件名再追加 .txt/.bin 之类的后缀
            val ext = name.substringAfterLast('.', "").lowercase()
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
            val values = ContentValues()
            values.put(MediaStore.Downloads.DISPLAY_NAME, name)
            values.put(MediaStore.Downloads.MIME_TYPE, mime)
            values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/LANCast")
            values.put(MediaStore.Downloads.IS_PENDING, 1)          // 传输期间对其他应用不可见，传完才出现
            val target = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            if (target == null) {
                out.write(0)
                out.flush()
                log("✘ 无法在 下载/LANCast 创建文件：$name")
                return
            }
            pending = target
            out.write(1)                               // 同意接收
            out.flush()

            val md = MessageDigest.getInstance("SHA-256")
            val buf = ByteArray(CHUNK)
            var done = 0L
            val meter = XferMeter("recv", "⬇ 接收  $name（来自 $from）", size)
            val os = resolver.openOutputStream(target, "w") ?: throw IOException("无法写入文件")
            os.use { o ->
                while (done < size) {
                    val want = minOf(buf.size.toLong(), size - done).toInt()
                    val n = inp.read(buf, 0, want)
                    if (n < 0) throw IOException("连接中断")
                    md.update(buf, 0, n)
                    o.write(buf, 0, n)
                    done += n
                    meter.update(done)
                }
                o.flush()
            }
            meter.update(done, true)

            val theirs = readN(inp, 32)
            if (MessageDigest.isEqual(md.digest(), theirs)) {
                val ok = ContentValues()
                ok.put(MediaStore.Downloads.IS_PENDING, 0)
                resolver.update(target, ok, null, null)
                pending = null
                out.write(1)
                out.flush()
                var finalName = name
                try {
                    finalName = queryMeta(target).first
                } catch (ignored: Exception) {
                }
                log("✔ 已接收 $finalName（${fmtSize(size)}，SHA-256 校验通过）来自 $from → 下载/LANCast")
            } else {
                out.write(0)
                out.flush()
                log("✘ $name 校验不一致，已丢弃")
            }
        } catch (e: Exception) {
            log("✘ 接收出错：${e.message ?: e.javaClass.simpleName}")
        } finally {
            val p = pending
            if (p != null) {
                try {
                    resolver.delete(p, null, null)     // 绝不留下半成品
                } catch (ignored: Exception) {
                }
            }
            se.close("done")
            endBusy()
        }
    }

    /* ═════════════ 发送 ═════════════ */

    /**
     * 把若干文件依次发给对方（每个文件一条独立连接）。在后台线程里执行。
     * onDone(成功个数, PIN 是否错误) 在主线程回调。
     */
    fun sendFiles(host: String, port: Int, pin: String, uris: List<Uri>, onDone: (Int, Boolean) -> Unit) {
        thread(name = "xfer-send", isDaemon = true) {
            beginBusy()
            var ok = 0
            var badPin = false
            try {
                for (i in uris.indices) {
                    try {
                        sendOne(host, port, pin, uris[i], i + 1, uris.size)
                        ok++
                    } catch (e: Exception) {
                        val m = e.message ?: e.javaClass.simpleName
                        if (m == "PIN 错误") {
                            badPin = true
                            break
                        }
                        val shown = if (m == "未知模式") "对方的 LANCast 版本太旧，不支持文件传输，请两端都更新" else m
                        log("✘ 发送失败：$shown")
                    }
                }
            } finally {
                endBusy()
            }
            if (!badPin) log("发送结束：成功 $ok / ${uris.size}")
            val okCount = ok
            val bad = badPin
            Link.main.post { onDone(okCount, bad) }
        }
    }

    private fun sendOne(host: String, port: Int, pin: String, uri: Uri, idx: Int, count: Int) {
        val resolver = Link.app.contentResolver
        val meta = queryMeta(uri)
        val name = meta.first
        var size = meta.second
        if (size < 0) {
            val afd = resolver.openAssetFileDescriptor(uri, "r")
            if (afd != null) {
                size = afd.use { it.length }
            }
        }
        if (size < 0) throw IOException("无法获取「$name」的大小（可能是云端/虚拟文件），已跳过")
        val total = size

        val se = Session.connect(host, port, pin, "file", Link.name)     // PIN 错误 / 对方拒绝 会在这里抛出异常
        try {
            se.setSoTimeout(60_000)
            se.tuneBulk()
            val out = se.rawOut
            val inp = se.rawIn
            val hdr = JSONObject().put("name", name).put("size", total).put("from", Link.name)
                .toString().toByteArray(Charsets.UTF_8)
            out.write(ByteBuffer.allocate(4).putInt(hdr.size).array())
            out.write(hdr)
            out.flush()
            if (inp.read() != 1) throw IOException("对方拒绝接收「$name」")

            val md = MessageDigest.getInstance("SHA-256")
            val buf = ByteArray(CHUNK)
            val meter = XferMeter("send", "⬆ 发送 $idx/$count  $name", total)
            var sent = 0L
            val fin = resolver.openInputStream(uri) ?: throw IOException("无法打开「$name」")
            fin.use { f ->
                while (sent < total) {
                    val want = minOf(buf.size.toLong(), total - sent).toInt()
                    val n = f.read(buf, 0, want)
                    if (n < 0) throw IOException("「$name」比声明的小（读取被截断），已中止")
                    md.update(buf, 0, n)
                    out.write(buf, 0, n)
                    sent += n
                    meter.update(sent)
                }
                if (f.read() != -1) throw IOException("「$name」比声明的大（大小不一致），已中止")
            }
            out.write(md.digest())
            out.flush()
            se.setSoTimeout(300_000)                   // 等对方落盘 + 校验
            if (inp.read() != 1) throw IOException("对方校验失败「$name」（数据不一致）")
            meter.update(total, true)
            log("✔ 已发送 $name（${fmtSize(total)}，SHA-256 校验通过）")
        } finally {
            se.close("done")
        }
    }
}
