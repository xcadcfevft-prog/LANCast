package com.lancast.app

import android.content.ContentValues
import android.net.Uri
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.StatFs
import android.os.SystemClock
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.webkit.MimeTypeMap
import org.json.JSONObject
import java.io.DataInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.OutputStream
import java.net.Socket
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.security.MessageDigest
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicInteger
import kotlin.concurrent.thread

/**
 * 文件互传（与 Windows 端 filexfer.js 的协议完全一致）。
 * 复用 TCP 47800 连接和 PIN 认证，握手时 mode = "file"，不占用投屏会话。
 *
 * 帧：16 字节包头(大端) type u8 | flags u8 | reserved u16 | len u32 | pts u64，后面跟正文。
 *   OFFER  32 发送方→接收方  JSON {id, name, size, mtime}
 *   REPLY  33 接收方→发送方  JSON {id, action: accept|reject, offset, reason}   offset = 从第几个字节开始续传
 *   DATA   34 发送方→接收方  原始字节（≤1 MiB），pts = 这块数据在文件中的起始偏移，不做任何转码/压缩
 *   END    35 发送方→接收方  JSON {id, size, sha256}
 *   RESULT 36 接收方→发送方  JSON {id, ok, reason, sha256}
 *   BYE    37 发送方→接收方  这一批文件发完了
 *
 * 无损保证：原始字节流 + 64 位偏移（无大小限制）+ 双方各算整份文件的 SHA-256 并比对，
 * 一致才算成功；接收时先写成“待完成”文件，校验通过才对外可见，不会出现“半个文件”冒充成功。
 */
object FT {
    const val OFFER = 32
    const val REPLY = 33
    const val DATA = 34
    const val END = 35
    const val RESULT = 36
    const val BYE = 37
    const val CHUNK = 1048576
    const val MAX_DATA = 4194304
    const val MAX_JSON = 1048576
}

/** 一次文件传输的记录（界面直接读取这些字段）。state: queued offering sending receiving verifying done failed cancelled */
class Xfer(val send: Boolean, var name: String, val peer: String) {
    @Volatile var size = 0L
    @Volatile var done = 0L
    @Volatile var state = "queued"
    @Volatile var msg = ""
    @Volatile var speed = 0.0
    @Volatile var job: XferJob? = null
    @Volatile var lastT = 0L
    @Volatile var lastD = 0L
    @Volatile var keepPart = false
    @Volatile var saved = ""

    val active: Boolean
        get() = state == "queued" || state == "offering" || state == "sending" || state == "receiving" || state == "verifying"
}

/** 一条 TCP 连接上的一批传输 */
class XferJob {
    @Volatile var cancelled = false
    @Volatile var finished = false
    @Volatile var timedOut = false
    @Volatile var socket: Socket? = null
    @Volatile var inData = false
    @Volatile var lastAct = SystemClock.elapsedRealtime()
}

internal class FFrame(val type: Int, val pts: Long, val body: ByteArray)

object FileXfer {
    val list = CopyOnWriteArrayList<Xfer>()
    @Volatile var listener: (() -> Unit)? = null

    private val ui = Handler(Looper.getMainLooper())
    private val jobs = AtomicInteger(0)
    @Volatile private var lastNotify = 0L
    private val stopRunnable = Runnable { if (jobs.get() <= 0) FileService.stop() }

    /* ───────────── 通用 ───────────── */
    fun human(n: Long): String = when {
        n >= (1L shl 40) -> "%.2f TB".format(n.toDouble() / (1L shl 40).toDouble())
        n >= (1L shl 30) -> "%.2f GB".format(n.toDouble() / (1L shl 30).toDouble())
        n >= (1L shl 20) -> "%.1f MB".format(n.toDouble() / (1L shl 20).toDouble())
        n >= (1L shl 10) -> "%.0f KB".format(n.toDouble() / (1L shl 10).toDouble())
        else -> "$n B"
    }

    fun changed(force: Boolean = false) {
        val now = SystemClock.elapsedRealtime()
        if (!force && now - lastNotify < 250L) return
        lastNotify = now
        ui.post {
            listener?.invoke()
            FileService.refresh()
        }
    }

    private fun progress(x: Xfer) {
        val now = SystemClock.elapsedRealtime()
        if (x.lastT == 0L) {
            x.lastT = now
            x.lastD = x.done
        } else if (now - x.lastT >= 500L) {
            val inst = (x.done - x.lastD).toDouble() / ((now - x.lastT).toDouble() / 1000.0)
            x.speed = if (x.speed > 0.0) x.speed * 0.6 + inst * 0.4 else inst
            x.lastT = now
            x.lastD = x.done
        }
        changed(false)
    }

    private fun newXfer(send: Boolean, name: String, peer: String, job: XferJob): Xfer {
        val x = Xfer(send, name, peer)
        x.job = job
        list.add(0, x)
        changed(true)
        return x
    }

    fun cancel(x: Xfer) {
        val j = x.job ?: return
        j.cancelled = true
        for (o in list) {
            if (o.job === j && o.active) {
                o.state = "cancelled"
                o.msg = "已取消"
            }
        }
        changed(true)
        thread(isDaemon = true) {
            try { j.socket?.close() } catch (ignored: Exception) { }
        }
    }

    fun clearFinished() {
        list.removeIf { !it.active }
        changed(true)
    }

    private fun jobStart() {
        jobs.incrementAndGet()
        ui.removeCallbacks(stopRunnable)
        FileService.start()
    }

    private fun jobEnd() {
        if (jobs.decrementAndGet() <= 0) {
            jobs.set(0)
            ui.postDelayed(stopRunnable, 3000L)
        }
    }

    private fun watchdog(job: XferJob) {
        thread(name = "ft-wd", isDaemon = true) {
            while (!job.finished) {
                try { Thread.sleep(5000L) } catch (ignored: InterruptedException) { }
                if (job.inData && SystemClock.elapsedRealtime() - job.lastAct > 120000L) {
                    job.timedOut = true
                    try { job.socket?.close() } catch (ignored: Exception) { }
                }
            }
        }
    }

    private fun explain(e: Exception, job: XferJob): String {
        if (job.timedOut) return "传输停滞超过 120 秒，已中止"
        val m = e.message ?: ""
        val net = e is java.net.SocketException || e is java.io.EOFException ||
            m.contains("reset", true) || m.contains("Broken pipe", true) || m.contains("closed", true)
        if (net) return "连接中断（对方取消，或网络断开）"
        return if (m.isEmpty()) "连接中断" else m
    }

    private fun toHex(b: ByteArray): String {
        val sb = StringBuilder()
        for (v in b) sb.append(String.format("%02x", v.toInt() and 0xFF))
        return sb.toString()
    }

    private fun sha1Hex(s: String): String =
        toHex(MessageDigest.getInstance("SHA-1").digest(s.toByteArray(Charsets.UTF_8)))

    private fun putHeader(b: ByteArray, type: Int, len: Int, pts: Long) {
        val bb = ByteBuffer.wrap(b)
        bb.put(0, type.toByte())
        bb.putInt(4, len)
        bb.putLong(8, pts)
    }

    private fun readFrame(din: DataInputStream): FFrame {
        val h = ByteArray(16)
        din.readFully(h)
        val bb = ByteBuffer.wrap(h)
        val type = h[0].toInt() and 0xFF
        val len = bb.getInt(4)
        val pts = bb.getLong(8)
        val limit = if (type == FT.DATA) FT.MAX_DATA else FT.MAX_JSON
        if (len < 0 || len > limit) throw IOException("收到非法数据")
        val body = ByteArray(len)
        din.readFully(body)
        return FFrame(type, pts, body)
    }

    private fun readJson(din: DataInputStream, expect: Int): JSONObject {
        val f = readFrame(din)
        if (f.type != expect) throw IOException("协议错误（收到类型 ${f.type}）")
        return JSONObject(String(f.body, Charsets.UTF_8))
    }

    /* ═════════════════════ 发送 ═════════════════════ */
    private class Meta(val name: String, val size: Long, val mtime: Long)

    private fun queryMeta(uri: Uri): Meta {
        var name = ""
        var size = -1L
        var mtime = 0L
        try {
            Link.app.contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (ni >= 0 && !c.isNull(ni)) name = c.getString(ni)
                    val si = c.getColumnIndex(OpenableColumns.SIZE)
                    if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
                    val mi = c.getColumnIndex(DocumentsContract.Document.COLUMN_LAST_MODIFIED)
                    if (mi >= 0 && !c.isNull(mi)) mtime = c.getLong(mi)
                }
            }
        } catch (ignored: Exception) { }
        if (name.isEmpty()) name = (uri.lastPathSegment ?: "file").substringAfterLast('/')
        return Meta(name, size, mtime)
    }

    /** 把 uris 发送给 host:port。立即返回，在后台线程里传输。 */
    fun sendFiles(host: String, port: Int, pin: String, peerName: String, uris: List<Uri>) {
        if (uris.isEmpty()) return
        val job = XferJob()
        val entries = ArrayList<Pair<Uri, Xfer>>()
        for (u in uris) entries.add(Pair(u, Xfer(true, queryMeta(u).name, peerName)))
        for (i in entries.indices.reversed()) {                    // 倒序插入，列表里第一个文件显示在最上面
            val x = entries[i].second
            x.job = job
            list.add(0, x)
        }
        changed(true)
        jobStart()
        watchdog(job)
        thread(name = "ft-send", isDaemon = true) {
            var se: Session? = null
            try {
                se = Session.connect(host, port, pin, "file", Link.name)
                val sock = se.rawSocket
                sock.soTimeout = 0
                try { sock.keepAlive = true } catch (ignored: Exception) { }
                job.socket = sock
                if (job.cancelled) throw IOException("已取消")
                val din = se.rawIn
                val out = se.rawOut
                for (e in entries) {
                    if (job.cancelled) break
                    sendOne(din, out, e.first, e.second, job)
                }
                if (!job.cancelled) {
                    job.inData = false
                    out.write(P.newPkt(FT.BYE, 0, 0L, 0))
                }
            } catch (e: Exception) {
                val why = if (job.cancelled) "已取消" else explain(e, job)
                for (en in entries) {
                    val x = en.second
                    if (x.active) {
                        x.state = if (job.cancelled) "cancelled" else "failed"
                        x.msg = why
                    }
                }
            } finally {
                job.finished = true
                for (en in entries) {
                    val x = en.second
                    if (x.active) {
                        x.state = "cancelled"
                        x.msg = "已取消"
                    }
                }
                try { se?.rawSocket?.close() } catch (ignored: Exception) { }
                jobEnd()
                changed(true)
            }
        }
    }

    private fun fail(x: Xfer, why: String) {
        x.state = "failed"
        x.msg = why
        changed(true)
    }

    private fun sendOne(din: DataInputStream, out: OutputStream, uri: Uri, x: Xfer, job: XferJob) {
        val cr = Link.app.contentResolver
        val meta = queryMeta(uri)
        val pfd: ParcelFileDescriptor? = try { cr.openFileDescriptor(uri, "r") } catch (e: Exception) { null }
        if (pfd == null) {
            fail(x, "无法读取该文件")
            return
        }
        val ins = ParcelFileDescriptor.AutoCloseInputStream(pfd)
        try {
            val st = pfd.statSize
            val size = if (st >= 0L) st else meta.size
            if (size < 0L) {
                fail(x, "无法确定文件大小")
                return
            }
            x.size = size
            x.done = 0L
            x.state = "offering"
            x.msg = ""
            changed(true)
            val id = P.randomHex(6)
            job.inData = false
            out.write(P.jsonPkt(FT.OFFER, JSONObject().put("id", id).put("name", x.name).put("size", size).put("mtime", meta.mtime)))
            val rep = readJson(din, FT.REPLY)
            if (rep.optString("id") != id) throw IOException("协议错误（编号不符）")
            if (rep.optString("action") != "accept") {
                fail(x, rep.optString("reason", "对方拒绝接收"))
                return
            }
            val offset = rep.optLong("offset", 0L)
            if (offset < 0L || offset > size) throw IOException("协议错误（续传位置无效）")

            val md = MessageDigest.getInstance("SHA-256")
            val buf = ByteArray(16 + FT.CHUNK)
            x.state = "sending"
            x.msg = if (offset > 0L) "从 ${human(offset)} 处续传" else ""
            x.lastT = 0L
            x.speed = 0.0
            changed(true)
            job.inData = true
            job.lastAct = SystemClock.elapsedRealtime()
            var pos = 0L
            while (pos < size) {
                if (job.cancelled) throw IOException("已取消")
                val limit = if (pos < offset) offset else size       // 续传：[0,offset) 只参与校验，不再发送
                val want = minOf(FT.CHUNK.toLong(), limit - pos).toInt()
                var n = 0
                while (n < want) {
                    val r = ins.read(buf, 16 + n, want - n)
                    if (r < 0) break
                    n += r
                }
                if (n < want) throw IOException("读取文件失败：文件在传输过程中被改动或变小")
                md.update(buf, 16, want)
                if (pos >= offset) {
                    putHeader(buf, FT.DATA, want, pos)
                    out.write(buf, 0, 16 + want)
                }
                pos += want.toLong()
                x.done = pos
                job.lastAct = SystemClock.elapsedRealtime()
                progress(x)
            }
            job.inData = false
            x.state = "verifying"
            x.msg = "等待对方校验…"
            changed(true)
            val digest = toHex(md.digest())
            out.write(P.jsonPkt(FT.END, JSONObject().put("id", id).put("size", size).put("sha256", digest)))
            val res = readJson(din, FT.RESULT)
            if (res.optBoolean("ok")) {
                x.state = "done"
                x.msg = "已完成 · SHA-256 校验一致"
            } else {
                x.state = "failed"
                x.msg = res.optString("reason", "对方校验失败")
            }
            changed(true)
        } finally {
            try { ins.close() } catch (ignored: Exception) { }
        }
    }

    /* ═════════════════════ 接收 ═════════════════════ */
    private fun freeBytes(): Long {
        return try {
            StatFs(Environment.getExternalStorageDirectory().absolutePath).availableBytes
        } catch (e: Exception) {
            Long.MAX_VALUE
        }
    }

    /** 只去掉 Android/Windows 都不允许的字符，中文等原样保留；整体不超过 200 字节（文件名上限 255 字节） */
    private fun safeName(raw: String): String {
        val sb = StringBuilder()
        for (ch in raw) {
            val bad = ch < ' ' || ch == '\u007f' || "\\/:*?\"<>|".indexOf(ch) >= 0
            sb.append(if (bad) '_' else ch)
        }
        var s = sb.toString().trim().trimEnd('.', ' ')
        if (s.isEmpty()) s = "file"
        if (s.toByteArray(Charsets.UTF_8).size > 200) {
            val dot = s.lastIndexOf('.')
            val ext = if (dot > 0 && s.length - dot <= 16) s.substring(dot) else ""
            var stem = if (ext.isEmpty()) s else s.substring(0, dot)
            val extBytes = ext.toByteArray(Charsets.UTF_8).size
            while (stem.isNotEmpty() && stem.toByteArray(Charsets.UTF_8).size + extBytes > 200) stem = stem.dropLast(1)
            if (stem.isNotEmpty() && Character.isHighSurrogate(stem[stem.length - 1])) stem = stem.dropLast(1)
            s = (if (stem.isEmpty()) "file" else stem) + ext
        }
        return s
    }

    private fun mimeFor(name: String): String {
        val dot = name.lastIndexOf('.')
        if (dot < 0 || dot == name.length - 1) return "application/octet-stream"
        val ext = name.substring(dot + 1).lowercase()
        return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
    }

    private fun queryName(u: Uri): String? {
        try {
            Link.app.contentResolver.query(u, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst() && !c.isNull(0)) return c.getString(0)
            }
        } catch (ignored: Exception) { }
        return null
    }

    private fun discard(u: Uri, prefKey: String) {
        try { Link.app.contentResolver.delete(u, null, null) } catch (ignored: Exception) { }
        Link.prefs.edit().remove(prefKey).apply()
    }

    private fun openWriter(u: Uri, offset: Long): FileOutputStream {
        val pfd = Link.app.contentResolver.openFileDescriptor(u, if (offset > 0L) "rw" else "rwt")
            ?: throw IOException("无法写入")
        return ParcelFileDescriptor.AutoCloseOutputStream(pfd)
    }

    private fun writeFully(ch: FileChannel, b: ByteArray) {
        val bb = ByteBuffer.wrap(b)
        while (bb.hasRemaining()) ch.write(bb)
    }

    /** 有设备以 mode=file 连入并通过 PIN 认证后调用（已 accept）。在调用线程里循环接收，直到对方发完或断开。 */
    fun onIncoming(se: Session) {
        val job = XferJob()
        job.socket = se.rawSocket
        jobStart()
        watchdog(job)
        try { se.rawSocket.keepAlive = true } catch (ignored: Exception) { }
        val din = se.rawIn
        val out = se.rawOut
        try {
            while (true) {
                job.inData = false
                val f = readFrame(din)
                if (f.type == FT.BYE) break
                if (f.type != FT.OFFER) throw IOException("协议错误（期待 OFFER，收到 ${f.type}）")
                val offer = JSONObject(String(f.body, Charsets.UTF_8))
                val x = newXfer(false, offer.optString("name", "file"), se.peerName, job)
                try {
                    recvOne(din, out, offer, x, job)
                } catch (e: Exception) {
                    if (x.active) {
                        x.state = if (job.cancelled) "cancelled" else "failed"
                        x.msg = if (job.cancelled) "已取消"
                        else explain(e, job) + (if (x.keepPart && x.done > 0L) "；已保留 ${human(x.done)}，重新发送同一个文件会自动续传" else "")
                        changed(true)
                    }
                    throw e
                }
            }
        } catch (ignored: Exception) {
            // 记录已在上面更新
        } finally {
            job.finished = true
            try { se.rawSocket.close() } catch (ignored: Exception) { }
            jobEnd()
            changed(true)
        }
    }

    private fun recvOne(din: DataInputStream, out: OutputStream, offer: JSONObject, x: Xfer, job: XferJob) {
        val cr = Link.app.contentResolver
        val prefs = Link.prefs
        val id = offer.optString("id")
        val size = offer.optLong("size", -1L)
        val mtime = offer.optLong("mtime", 0L)
        val name = safeName(offer.optString("name", "file"))
        x.name = name
        x.size = if (size > 0L) size else 0L
        x.state = "offering"
        changed(true)

        fun answer(accept: Boolean, offset: Long, reason: String) {
            val j = JSONObject().put("id", id).put("action", if (accept) "accept" else "reject")
                .put("offset", offset).put("reason", reason)
            out.write(P.jsonPkt(FT.REPLY, j))
        }

        fun refuse(reason: String) {
            x.state = "failed"
            x.msg = reason
            changed(true)
            answer(false, 0L, reason)
        }

        if (size < 0L) {
            refuse("文件大小无效")
            return
        }

        // 1. 找有没有上次没传完的临时文件（同名同大小同修改时间），有就续传
        val key = sha1Hex("$name|$size|$mtime").substring(0, 10)
        val prefKey = "ft_part_$key"
        var resumeUri: Uri? = null
        var offset = 0L
        val savedUri = prefs.getString(prefKey, null)
        if (savedUri != null) {
            try {
                val u = Uri.parse(savedUri)
                val p = cr.openFileDescriptor(u, "r")
                if (p != null) {
                    val len = p.statSize
                    p.close()
                    if (len >= 0L && len <= size) {
                        resumeUri = u
                        offset = len
                    } else {
                        try { cr.delete(u, null, null) } catch (ignored: Exception) { }
                    }
                }
            } catch (ignored: Exception) { }
            if (resumeUri == null) prefs.edit().remove(prefKey).apply()
        }

        // 2. 空间检查
        val free = freeBytes()
        val need = size - offset
        if (need + 32L * 1024L * 1024L > free) {
            refuse("手机存储空间不足（还需要 ${human(need)}，可用 ${human(free)}）")
            return
        }

        // 3. 没有可续传的就新建一个“待完成”文件（校验通过前，其他应用看不到它）
        var target: Uri? = resumeUri
        if (target == null) {
            val cv = ContentValues()
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            cv.put(MediaStore.MediaColumns.MIME_TYPE, mimeFor(name))
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/LANCast")
            cv.put(MediaStore.MediaColumns.IS_PENDING, 1)
            target = try { cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) } catch (e: Exception) { null }
            if (target == null) {
                refuse("手机无法创建接收文件")
                return
            }
            prefs.edit().putString(prefKey, target.toString()).apply()
        }
        val dest: Uri = target ?: return

        // 4. 续传：先把已收到的部分重新算一遍 SHA-256
        val md = MessageDigest.getInstance("SHA-256")
        if (offset > 0L) {
            x.state = "verifying"
            x.done = offset
            x.msg = "正在校验已收到的 ${human(offset)}…"
            changed(true)
            try {
                val p = cr.openFileDescriptor(dest, "r") ?: throw IOException("无法读取已收到的部分")
                ParcelFileDescriptor.AutoCloseInputStream(p).use { ins ->
                    val buf = ByteArray(FT.CHUNK)
                    var left = offset
                    while (left > 0L) {
                        if (job.cancelled) throw IOException("已取消")
                        val r = ins.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                        if (r < 0) throw IOException("已收到的部分比预期短")
                        md.update(buf, 0, r)
                        left -= r.toLong()
                    }
                }
            } catch (e: Exception) {
                if (job.cancelled) throw e
                discard(dest, prefKey)
                refuse("读取临时文件失败，已清除，请重新发送：${e.message}")
                return
            }
        }

        val fos: FileOutputStream = try {
            openWriter(dest, offset)
        } catch (e: Exception) {
            discard(dest, prefKey)
            refuse("手机无法写入文件：${e.message}")
            return
        }

        // 5. 接收数据
        x.keepPart = true
        x.done = offset
        x.lastT = 0L
        x.speed = 0.0
        x.state = "receiving"
        x.msg = if (offset > 0L) "从 ${human(offset)} 处续传" else ""
        changed(true)
        answer(true, offset, "")
        job.inData = true
        job.lastAct = SystemClock.elapsedRealtime()
        var pos = offset
        var end: JSONObject? = null
        try {
            val ch = fos.channel
            ch.position(offset)
            while (true) {
                val f = readFrame(din)
                job.lastAct = SystemClock.elapsedRealtime()
                if (f.type == FT.DATA) {
                    if (f.pts != pos) throw IOException("数据错位（偏移 ${f.pts}，应为 $pos）")
                    if (pos + f.body.size.toLong() > size) throw IOException("收到的数据超过声明的文件大小")
                    md.update(f.body)
                    writeFully(ch, f.body)
                    pos += f.body.size.toLong()
                    x.done = pos
                    progress(x)
                } else if (f.type == FT.END) {
                    end = JSONObject(String(f.body, Charsets.UTF_8))
                    break
                } else {
                    throw IOException("协议错误（数据阶段收到类型 ${f.type}）")
                }
            }
            job.inData = false
            x.state = "verifying"
            x.msg = "正在校验…"
            changed(true)
            try { ch.force(true) } catch (ignored: Exception) { }
        } catch (e: Exception) {
            try { fos.close() } catch (ignored: Exception) { }
            if (job.cancelled) {
                discard(dest, prefKey)
                x.keepPart = false
            }
            throw e
        }
        try { fos.close() } catch (ignored: Exception) { }

        // 6. 校验
        val endJson = end ?: throw IOException("协议错误")
        val digest = toHex(md.digest())
        val endHash = endJson.optString("sha256").lowercase()
        if (pos != size || endJson.optLong("size", -1L) != size || endHash != digest) {
            discard(dest, prefKey)
            x.keepPart = false
            val why = if (pos != size) "收到的字节数（$pos）与文件大小（$size）不符"
            else "SHA-256 校验不一致，文件可能在传输中损坏，已丢弃，请重新发送"
            x.state = "failed"
            x.msg = why
            changed(true)
            out.write(P.jsonPkt(FT.RESULT, JSONObject().put("id", id).put("ok", false).put("reason", why).put("sha256", digest)))
            return
        }

        // 7. 转正：去掉“待完成”标记，文件才对文件管理器/其他应用可见
        var finalName: String? = null
        try {
            val cv = ContentValues()
            cv.put(MediaStore.MediaColumns.IS_PENDING, 0)
            cr.update(dest, cv, null, null)
            finalName = queryName(dest)
        } catch (e: Exception) {
            val why = "接收方无法保存文件：${e.message}"
            x.state = "failed"
            x.msg = why
            changed(true)
            out.write(P.jsonPkt(FT.RESULT, JSONObject().put("id", id).put("ok", false).put("reason", why).put("sha256", digest)))
            return
        }
        prefs.edit().remove(prefKey).apply()
        x.keepPart = false
        x.saved = finalName ?: name
        x.state = "done"
        x.msg = "已完成 · SHA-256 校验一致 · 已保存到「下载/LANCast」：${x.saved}"
        changed(true)
        out.write(P.jsonPkt(FT.RESULT, JSONObject().put("id", id).put("ok", true).put("sha256", digest)))
    }
}
