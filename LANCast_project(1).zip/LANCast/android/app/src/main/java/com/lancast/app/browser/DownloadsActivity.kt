package com.lancast.app.browser

import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** 下载管理页：显示所有下载任务的进度 / 速度 / 状态，点击条目可播放、打开、取消、重试、删除。 */
class DownloadsActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())
    private var data: List<DownloadCenter.Task> = emptyList()
    private lateinit var taskAdapter: TaskAdapter
    private val dateFmt = SimpleDateFormat("MM-dd HH:mm", Locale.getDefault())

    private val tick = object : Runnable {
        override fun run() {
            DownloadCenter.refresh()
            update()
            handler.postDelayed(this, 700)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        DownloadCenter.init(this)

        val back = TextView(this).apply {
            text = "返回"
            textSize = 15f
            setTextColor(Ui.PRIMARY)
            setPadding(dp(12), dp(14), dp(16), dp(14))
            setOnClickListener { finish() }
        }
        val title = TextView(this).apply {
            text = "下载管理"
            textSize = 18f
            setTextColor(Ui.TEXT)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val more = TextView(this).apply {
            text = "更多"
            textSize = 15f
            setTextColor(Ui.PRIMARY)
            setPadding(dp(16), dp(14), dp(12), dp(14))
            setOnClickListener { showMore() }
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setGravity(Gravity.CENTER_VERTICAL)
            setBackgroundColor(Ui.WHITE)
            addView(back)
            addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(more)
        }

        taskAdapter = TaskAdapter()
        val list = ListView(this).apply {
            divider = ColorDrawable(Ui.DIVIDER)
            dividerHeight = dp(1)
            setAdapter(taskAdapter)
            setOnItemClickListener { _, _, i, _ -> if (i < data.size) showActions(data[i]) }
        }
        val empty = TextView(this).apply {
            text = "暂无下载记录\n在「嗅探」列表里点「下载」即可添加"
            gravity = Gravity.CENTER
            textSize = 14f
            setTextColor(Ui.TEXT_SUB)
        }
        list.emptyView = empty
        val body = FrameLayout(this).apply {
            addView(list, FrameLayout.LayoutParams(-1, -1))
            addView(empty, FrameLayout.LayoutParams(-1, -1))
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Ui.WHITE)
            addView(header)
            addView(View(this@DownloadsActivity).apply { setBackgroundColor(Ui.DIVIDER) }, LinearLayout.LayoutParams(-1, dp(1)))
            addView(body, LinearLayout.LayoutParams(-1, 0, 1f))
        })
        lightBars()
    }

    override fun onResume() {
        super.onResume()
        handler.post(tick)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    /** 刷新数据并计算下载速度。 */
    private fun update() {
        val now = System.currentTimeMillis()
        data = DownloadCenter.snapshot()
        for (t in data) {
            if (t.status != DownloadCenter.RUNNING) {
                t.speed = 0
                t.lastTime = 0
                continue
            }
            val dt = now - t.lastTime
            if (t.lastTime == 0L || t.bytes < t.lastBytes) {
                t.lastTime = now
                t.lastBytes = t.bytes
                t.speed = 0
            } else if (dt >= 600) {
                t.speed = (t.bytes - t.lastBytes) * 1000 / dt
                t.lastBytes = t.bytes
                t.lastTime = now
            }
        }
        taskAdapter.notifyDataSetChanged()
    }

    // ---------- 操作 ----------

    private fun showMore() {
        AlertDialog.Builder(this)
            .setItems(arrayOf("清除已完成 / 失败的记录", "打开系统下载目录")) { _, which ->
                when (which) {
                    0 -> { DownloadCenter.clearFinished(); update() }
                    1 -> try {
                        startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
                    } catch (e: ActivityNotFoundException) {
                        toast("没有可用的文件管理器")
                    }
                }
            }.show()
    }

    private fun showActions(t: DownloadCenter.Task) {
        val names = ArrayList<String>()
        val acts = ArrayList<() -> Unit>()
        fun add(name: String, act: () -> Unit) { names.add(name); acts.add(act) }

        when (t.status) {
            DownloadCenter.DONE -> {
                add("播放") { play(t) }
                add("用其他应用打开") { openWith(t) }
            }
            DownloadCenter.FAILED -> add("重试") { DownloadCenter.retry(t); update() }
            else -> add("取消下载") { DownloadCenter.cancel(t); update() }
        }
        add("复制来源链接") {
            (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                .setPrimaryClip(ClipData.newPlainText("url", t.url))
            toast("已复制")
        }
        add("删除") { confirmDelete(t) }

        AlertDialog.Builder(this)
            .setTitle(t.title)
            .setItems(names.toTypedArray()) { _, which -> acts[which]() }
            .show()
    }

    private fun confirmDelete(t: DownloadCenter.Task) {
        if (t.status == DownloadCenter.DONE) {
            AlertDialog.Builder(this)
                .setTitle("删除「${t.title}」")
                .setItems(arrayOf("删除文件和记录", "仅移除记录")) { _, which ->
                    DownloadCenter.remove(t, deleteFile = which == 0)
                    update()
                }
                .setNegativeButton("取消", null)
                .show()
        } else {
            DownloadCenter.remove(t, deleteFile = true)
            update()
        }
    }

    private fun play(t: DownloadCenter.Task) {
        val u = t.fileUri
        if (u == null || !DownloadCenter.exists(Uri.parse(u))) {
            toast("文件不存在，可能已被删除")
            return
        }
        startActivity(Intent(this, PlayerActivity::class.java).putExtra(PlayerActivity.EXTRA_URL, u))
    }

    private fun openWith(t: DownloadCenter.Task) {
        val u = t.fileUri
        if (u == null || !DownloadCenter.exists(Uri.parse(u))) {
            toast("文件不存在，可能已被删除")
            return
        }
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(Uri.parse(u), t.mime ?: "video/*")
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (e: ActivityNotFoundException) {
            toast("没有可用的应用可以打开")
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ---------- 列表 ----------

    private fun statusText(t: DownloadCenter.Task): String {
        val sp = if (t.speed > 0) " · ${formatSize(t.speed)}/s" else ""
        return when (t.status) {
            DownloadCenter.QUEUED -> "排队中…"
            DownloadCenter.RUNNING ->
                if (t.kind == "hls") {
                    if (t.total <= 0) "正在解析…" else "${t.done}/${t.total} 个分片 · ${formatSize(t.bytes)}$sp"
                } else {
                    if (t.total > 0) "${formatSize(t.bytes)} / ${formatSize(t.total)}$sp" else "${formatSize(t.bytes)}$sp"
                }
            DownloadCenter.DONE -> "${formatSize(t.bytes)} · ${dateFmt.format(Date(t.createdAt))}"
            else -> "失败：${t.error ?: "未知错误"}"
        }
    }

    private inner class Row {
        val ctx: Context = this@DownloadsActivity
        val icon = TextView(ctx).apply {
            gravity = Gravity.CENTER
            textSize = 13f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val title = TextView(ctx).apply {
            textSize = 15f
            setTextColor(Ui.TEXT)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.MIDDLE
        }
        val status = TextView(ctx).apply {
            textSize = 12f
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
        }
        val bar = ProgressLine(ctx)
        val root = LinearLayout(ctx)

        init {
            val col = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                addView(title)
                addView(status, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(3) })
                addView(bar, LinearLayout.LayoutParams(-1, dp(4)).apply { topMargin = dp(8) })
            }
            root.orientation = LinearLayout.HORIZONTAL
            root.setGravity(Gravity.CENTER_VERTICAL)
            root.setBackgroundColor(Ui.WHITE)
            root.setPadding(dp(16), dp(14), dp(16), dp(14))
            root.addView(icon, LinearLayout.LayoutParams(dp(46), dp(46)))
            root.addView(col, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(14) })
        }

        fun bind(t: DownloadCenter.Task) {
            title.text = t.title
            status.text = statusText(t)
            val ext = t.title.substringAfterLast('.', "").uppercase().take(4)
            icon.text = if (ext.isEmpty()) "HLS" else ext
            val (fg, bg) = when (t.status) {
                DownloadCenter.DONE -> Ui.GREEN to Ui.GREEN_LIGHT
                DownloadCenter.FAILED -> Ui.RED to Ui.RED_LIGHT
                else -> Ui.PRIMARY to Ui.PRIMARY_LIGHT
            }
            icon.setTextColor(fg)
            icon.background = roundRect(bg, dp(10).toFloat())
            status.setTextColor(if (t.status == DownloadCenter.FAILED) Ui.RED else Ui.TEXT_SUB)
            val active = t.status == DownloadCenter.RUNNING || t.status == DownloadCenter.QUEUED
            bar.visibility = if (active) View.VISIBLE else View.GONE
            if (active) {
                bar.fraction = if (t.status == DownloadCenter.QUEUED) 0f else t.fraction()
                bar.invalidate()
            }
        }
    }

    private inner class TaskAdapter : BaseAdapter() {
        override fun getCount(): Int = data.size
        override fun getItem(position: Int): Any = data[position]
        override fun getItemId(position: Int): Long = position.toLong()
        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val row = (convertView?.tag as? Row) ?: Row().also { it.root.tag = it }
            row.bind(data[position])
            return row.root
        }
    }
}
