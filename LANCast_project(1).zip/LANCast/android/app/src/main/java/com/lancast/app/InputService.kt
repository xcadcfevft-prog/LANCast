package com.lancast.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.hypot
import kotlin.math.min

/**
 * 屏幕控制的执行端：被控制的手机上用无障碍服务替对方「动手」。
 * 两个前提都满足才会执行：① 用户在系统设置里开了本服务；② 本次会话用户点了「允许控制」（Session.ctlAllowed，见 ScreenSource）。
 *
 * 指令（T_INPUT 帧，JSON；坐标 0..1 归一化 = 相对对方看到的画面，与分辨率/旋转无关；完整定义见 docs/PROTOCOL.md 第 11 节）：
 *   {"t":"d","i":sid,"x","y"}                 手指按下
 *   {"t":"m","i":sid,"p":[[x,y,ms],...]}      移动（一批点，ms = 相对按下时刻的毫秒数）
 *   {"t":"u","i":sid,"x","y","d":按住毫秒}     手指抬起
 *   {"t":"h","i":sid}                         按住不动时的保活（500ms 一次）
 *   {"t":"k","k":"back|home|recents|notif|quick"}   导航键
 *   {"t":"e","op":"append|del|clear|replace","s":"文字"}   编辑当前获得焦点的输入框
 *   {"t":"s","p":[...]}                       整笔回放（旧式，兼容保留）
 *
 * 「实时跟手」的做法（与 RustDesk 等开源远控一致）：用 API 26 的连续笔画——按下后派发一段 willContinue=true 的笔画，
 * 手指不抬，之后每段 continueStroke 接着往下画，抬起时发 willContinue=false 的最后一段。
 *   · 一段派发完（onCompleted）才派发下一段；这期间到达的点攒起来，下一段一次走完（路径经过每个点，不丢轨迹）。
 *   · 每段时长 = 这批点真实经过的时间，夹在 10–150ms：落后时自动「追帧」，延迟不会越积越大。
 *   · 点按不走连续笔画：按下后 120ms 内抬起且没移动 → 当作一次普通点按（最稳）；移动超过阈值或按住超过 120ms 才进入连续笔画。
 *   · 保险：笔画进行中超过 2.5 秒没有任何消息（掉线 / 对方崩溃）自动抬起，不会「卡住一根手指」；会话结束时也会抬起。
 */
class InputService : AccessibilityService() {
    companion object {
        @Volatile var inst: InputService? = null
        fun enabled(): Boolean = inst != null

        /** 返回 false 表示服务没开启（调用方据此提示对方）。 */
        fun handle(j: JSONObject): Boolean {
            val s = inst ?: return false
            s.h.post { try { s.exec(j) } catch (ignored: Exception) { } }
            return true
        }

        /** 会话结束 / 撤销授权：松开还按着的手指，清空待执行队列。 */
        fun reset() {
            val s = inst ?: return
            s.h.post { s.q.clear(); s.release() }
        }
    }

    private class G(val gd: GestureDescription, val dur: Long)

    private val h = Handler(Looper.getMainLooper())
    private val q = java.util.ArrayDeque<G>()          // 点按 / 整笔回放的排队
    private var busy = false                           // 系统一次只能跑一个手势

    // 实时触摸状态：0 空闲  1 已按下、尚未决定（点按还是拖动）  2 连续笔画进行中
    private var phase = 0
    private var sid = -1
    private var dx0 = 0f; private var dy0 = 0f         // 按下位置（px）
    private var lx = 0f; private var ly = 0f           // 已派发到的位置（px）
    private var lt = 0L                                // 已派发到的对方时间（ms）
    private var cur: GestureDescription.StrokeDescription? = null
    private val buf = ArrayList<FloatArray>()          // 待派发的点：[x(px), y(px), t(ms)]
    private var upPending = false
    private var ux = 0f; private var uy = 0f; private var ut = 0L
    private var lastRx = 0L

    private val holdRun = Runnable { if (phase == 1) startLive() }
    private val wdRun = object : Runnable {
        override fun run() {
            if (phase == 0) return
            if (SystemClock.elapsedRealtime() - lastRx > 2500L) release() else h.postDelayed(this, 500L)
        }
    }

    override fun onServiceConnected() { inst = this }
    override fun onUnbind(intent: Intent?): Boolean { inst = null; q.clear(); return super.onUnbind(intent) }
    override fun onDestroy() { inst = null; super.onDestroy() }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    /* ───────────── 分发 ───────────── */
    private fun exec(j: JSONObject) {
        when (j.optString("t")) {
            "d" -> onDown(j.optInt("i"), j.optDouble("x").toFloat(), j.optDouble("y").toFloat())
            "m" -> onMove(j.optInt("i"), j.optJSONArray("p"))
            "u" -> onUp(j.optInt("i"), j.optDouble("x").toFloat(), j.optDouble("y").toFloat(), j.optLong("d"))
            "h" -> if (j.optInt("i") == sid) lastRx = SystemClock.elapsedRealtime()
            "k" -> key(j.optString("k"))
            "e" -> edit(j.optString("op"), j.optString("s"))
            "s" -> legacyStroke(j.optJSONArray("p"))
        }
    }

    @Suppress("DEPRECATION")
    private fun screen(): FloatArray {
        val dm = DisplayMetrics()
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
        return floatArrayOf((dm.widthPixels - 1).coerceAtLeast(1).toFloat(), (dm.heightPixels - 1).coerceAtLeast(1).toFloat())
    }

    private fun px(v: Float, size: Float): Float = v.coerceIn(0f, 1f) * size

    /* ───────────── 一次执行一个手势 ───────────── */
    private fun fire(gd: GestureDescription, dur: Long, cb: (Boolean) -> Unit) {
        busy = true
        var fin = false
        val finish = { ok: Boolean -> if (!fin) { fin = true; busy = false; cb(ok) } }
        val started = try {
            dispatchGesture(gd, object : GestureResultCallback() {
                override fun onCompleted(d: GestureDescription?) { finish(true) }
                override fun onCancelled(d: GestureDescription?) { finish(false) }
            }, h)
        } catch (e: Exception) { false }
        if (!started) { finish(false); return }
        h.postDelayed({ finish(false) }, dur + 1500L)          // 保险：回调丢了也不会卡死
    }

    private fun path(sx: Float, sy: Float, pts: List<FloatArray>): Path {
        val p = Path()
        p.moveTo(sx, sy)
        var px = sx
        var py = sy
        for (pt in pts) {
            if (hypot(pt[0] - px, pt[1] - py) > 0.5f) { p.lineTo(pt[0], pt[1]); px = pt[0]; py = pt[1] }
        }
        return p
    }

    private fun enqueue(gd: GestureDescription, dur: Long) {
        if (q.size >= 6) q.pollFirst()
        q.addLast(G(gd, dur))
        pumpQ()
    }

    private fun pumpQ() {
        if (busy || phase != 0) return
        val g = q.pollFirst() ?: return
        fire(g.gd, g.dur) { pumpQ() }
    }

    /* ───────────── 实时触摸 ───────────── */
    private fun onDown(i: Int, x: Float, y: Float) {
        if (phase != 0) abandon()                          // 上一笔的「抬起」丢了：放弃它，系统会在下个手势时取消悬空笔画
        val s = screen()
        sid = i; phase = 1
        dx0 = px(x, s[0]); dy0 = px(y, s[1]); lx = dx0; ly = dy0; lt = 0L
        buf.clear(); upPending = false; cur = null
        lastRx = SystemClock.elapsedRealtime()
        h.postDelayed(holdRun, 120L)
        h.removeCallbacks(wdRun); h.postDelayed(wdRun, 500L)
    }

    private fun onMove(i: Int, a: JSONArray?) {
        if (i != sid || a == null || phase == 0) return
        lastRx = SystemClock.elapsedRealtime()
        val s = screen()
        for (k in 0 until min(a.length(), 64)) {
            val p = a.optJSONArray(k) ?: continue
            buf.add(floatArrayOf(px(p.optDouble(0).toFloat(), s[0]), px(p.optDouble(1).toFloat(), s[1]), p.optLong(2).toFloat()))
        }
        while (buf.size > 96) { var n = buf.size - 2; while (n > 0) { buf.removeAt(n); n -= 2 } }   // 积压太多：稀疏化，保留首尾
        if (phase == 1) {
            val slop = 0.012f * min(s[0], s[1])
            if (buf.any { hypot(it[0] - dx0, it[1] - dy0) > slop }) startLive()
        } else pumpLive()
    }

    private fun onUp(i: Int, x: Float, y: Float, held: Long) {
        if (i != sid) return
        lastRx = SystemClock.elapsedRealtime()
        val s = screen()
        if (phase == 1) {                                  // 没来得及进入拖动：普通点按
            h.removeCallbacks(holdRun)
            val gd = try {
                GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path(dx0, dy0, emptyList()), 0, held.coerceIn(30L, 120L))).build()
            } catch (e: Exception) { null }
            resetState()
            if (gd != null) enqueue(gd, 120L)
            return
        }
        upPending = true; ux = px(x, s[0]); uy = px(y, s[1]); ut = lt + 1
        pumpLive()
    }

    private fun startLive() {
        if (phase != 1) return
        if (busy) { h.postDelayed(holdRun, 30L); return }      // 前一个点按还在执行：等它跑完再开始（保证一次只有一个手势）
        phase = 2
        h.removeCallbacks(holdRun)
        val first = try {
            GestureDescription.StrokeDescription(path(dx0, dy0, emptyList()), 0, 1, true)
        } catch (e: Exception) { resetState(); return }
        cur = first
        val gd = GestureDescription.Builder().addStroke(first).build()
        fire(gd, 1L) { ok -> if (ok) pumpLive() else resetState() }
    }

    private fun pumpLive() {
        if (phase != 2 || busy) return
        val prev = cur ?: return
        val fin = upPending
        if (buf.isEmpty() && !fin) return
        val pts = ArrayList<FloatArray>(buf)
        buf.clear()
        if (fin) pts.add(floatArrayOf(ux, uy, maxOf(ut, if (pts.isEmpty()) lt else pts[pts.size - 1][2].toLong()).toFloat()))
        val tEnd = if (pts.isEmpty()) lt else pts[pts.size - 1][2].toLong()
        val dur = (tEnd - lt).coerceIn(10L, 150L)
        val next = try {
            prev.continueStroke(path(lx, ly, pts), 0, dur, !fin)
        } catch (e: Exception) { resetState(); return }
        if (pts.isNotEmpty()) { lx = pts[pts.size - 1][0]; ly = pts[pts.size - 1][1] }
        lt = tEnd
        cur = next
        fire(GestureDescription.Builder().addStroke(next).build(), dur) { ok ->
            if (!ok || fin) resetState() else pumpLive()
        }
    }

    /** 抬起还按着的手指（会话结束 / 保活超时）。 */
    private fun release() {
        when (phase) {
            0 -> return
            1 -> resetState()
            else -> { upPending = true; ux = lx; uy = ly; ut = lt + 1; pumpLive(); if (!busy && phase == 2) resetState() }
        }
    }

    private fun abandon() {
        h.removeCallbacks(holdRun)
        phase = 0; sid = -1; cur = null; buf.clear(); upPending = false
    }

    private fun resetState() {
        abandon()
        h.removeCallbacks(wdRun)
        pumpQ()
    }

    /* ───────────── 导航键 / 文字 / 旧式整笔 ───────────── */
    private fun key(k: String) {
        val a = when (k) {
            "back" -> GLOBAL_ACTION_BACK
            "home" -> GLOBAL_ACTION_HOME
            "recents" -> GLOBAL_ACTION_RECENTS
            "notif" -> GLOBAL_ACTION_NOTIFICATIONS
            "quick" -> GLOBAL_ACTION_QUICK_SETTINGS
            else -> return
        }
        performGlobalAction(a)
    }

    private fun edit(op: String, s: String) {
        val node = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return
        val cur = if (node.isShowingHintText) "" else (node.text?.toString() ?: "")
        val add = s.take(512)
        val next = when (op) {
            "append" -> cur + add
            "del" -> if (cur.isEmpty()) cur else cur.substring(0, cur.offsetByCodePoints(cur.length, -1))
            "clear" -> ""
            "replace" -> add
            else -> return
        }
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, next)
        node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    private fun legacyStroke(a: JSONArray?) {
        if (a == null || a.length() == 0) return
        val s = screen()
        val pts = ArrayList<FloatArray>()
        for (i in 0 until min(a.length(), 128)) {
            val p = a.optJSONArray(i) ?: continue
            pts.add(floatArrayOf(px(p.optDouble(0).toFloat(), s[0]), px(p.optDouble(1).toFloat(), s[1]), p.optLong(2).toFloat()))
        }
        if (pts.isEmpty()) return
        val dur = (pts[pts.size - 1][2].toLong() - pts[0][2].toLong()).coerceIn(30L, 10_000L)
        val gd = try {
            GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path(pts[0][0], pts[0][1], pts.drop(1)), 0, dur)).build()
        } catch (e: Exception) { return }
        enqueue(gd, dur)
    }
}
