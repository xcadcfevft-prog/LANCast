package com.lancast.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * 屏幕控制的执行端：被控制的手机上用无障碍服务替对方「动手」。
 * 两个前提都满足才会执行：① 用户在系统设置里开了本服务；② 本次会话用户点了「允许控制」（Session.ctlAllowed，见 ScreenSource）。
 *
 * 指令（T_INPUT 帧，JSON；坐标 0..1 归一化 = 相对对方看到的画面，与分辨率/旋转无关；完整定义见 docs/PROTOCOL.md 第 11 节）：
 *   {"t":"d","i":sid,"x","y"}                 手指按下
 *   {"t":"m","i":sid,"p":[[x,y,ms],...]}      移动（一批点，ms = 相对按下时刻的毫秒数）
 *   {"t":"u","i":sid,"x","y","d":按住毫秒}     手指抬起
 *   {"t":"h","i":sid}                         按住不动时的保活（500ms 一次）
 *   {"t":"k","k":"back|home|recents|notif|quick"}   导航键
 *   {"t":"e","op":"append|del|clear|replace","s":"文字"}   编辑当前获得焦点的输入框
 *   {"t":"s","p":[...]}                       整笔回放（旧式，兼容保留）
 *   {"t":"w","x","y","dx","dy","sx","sy"}      滚动（电脑端观看方发来，约 16ms 一包）：
 *                                              sx / sy = 手指应移动的距离，占屏宽 / 屏高的比例（正 = 向右 / 向下；观看方按自己画面里的像素量换算，所以和触控板 1:1 跟手）
 *                                              没有 sx / sy 的旧版观看方：dx / dy 单位「格」（dy>0 向下滚、dx>0 向右滚），1 格 ≈ 12% 屏高 / 屏宽
 *   {"t":"e","op":"del","n":3}                 一次退格 n 个字符；{"t":"e","op":"enter"} 向输入框发回车（Android 11+）
 *
 * 「实时跟手」的做法（与 RustDesk 等开源远控一致）：用 API 26 的连续笔画——按下后派发一段 willContinue=true 的笔画，
 * 手指不抬，之后每段 continueStroke 接着往下画，抬起时发 willContinue=false 的最后一段。
 *   · 一段派发完（onCompleted）才派发下一段；这期间到达的点攒起来，下一段一次走完（路径经过每个点，不丢轨迹）。
 *   · 每段时长 = 这批点真实经过的时间，夹在 10–150ms：落后时自动「追帧」，延迟不会越积越大。
 *   · 点按不走连续笔画：按下后 120ms 内抬起且没移动 → 当作一次普通点按（最稳）；移动超过阈值或按住超过 120ms 才进入连续笔画。
 *   · 保险：笔画进行中超过 2.5 秒没有任何消息（掉线 / 对方崩溃）自动抬起，不会「卡住一根手指」；会话结束时也会抬起。
 *
 * 「丝滑滚动」（电脑端滚轮 / 触控板双指）：不再一格一次「整段滑动」，而是用同一套连续笔画模拟一根手指：
 *   · 手指只在「安全区」里活动（离屏幕四边至少 32–56dp）——系统的状态栏下拉、返回 / 主页手势都发生在屏幕边缘，
 *     以前滑动的起点会被夹到 y=0，于是「往下滚」变成了「拉下通知栏」；
 *   · 收到的位移先攒着，每一段按指数缓动推进（时间常数 45ms），观看方的抖动被抹平，鼠标滚轮的一格也会「滑」过去而不是瞬移；
 *   · 手指走到安全区边缘还没滚够：先停稳再抬起，在对面重新按下接着滚（和人用手指连续划屏一样），滚动量不丢；
 *   · 停止滚动 120ms 后（先停稳，避免产生飞掠惯性）抬起手指；触摸操作进来时立即让路。
 */
class InputService : AccessibilityService() {
    companion object {
        @Volatile var inst: InputService? = null
        private const val LIVE_MIN_MS = 8L              // 连续笔画每段时长的下限 / 上限 / 追赶系数（见 pumpLive）
        private const val LIVE_MAX_MS = 60L
        private const val LIVE_CATCHUP = 0.55f
        private const val SCROLL_TAU_MS = 45f           // 滚动缓动的时间常数：越小越跟手、越大越平滑
        /** 收到打字指令但手机上没有获得输入焦点的输入框时回调（ScreenSource 据此提醒对方） */
        @Volatile var onNoFocus: (() -> Unit)? = null
        fun enabled(): Boolean = inst != null

        /** 返回 false 表示服务没开启（调用方据此提示对方）。 */
        fun handle(j: JSONObject): Boolean {
            val s = inst ?: return false
            s.h.post { try { s.exec(j) } catch (ignored: Exception) { } }
            return true
        }

        /** 会话结束 / 撤销授权：松开还按着的手指，清空待执行队列。 */
        fun reset() {
            val s = inst ?: return
            s.h.post { s.q.clear(); s.release() }
        }
    }

    private class G(val gd: GestureDescription, val dur: Long)

    private val h = Handler(Looper.getMainLooper())
    private val q = java.util.ArrayDeque<G>()          // 点按 / 整笔回放的排队
    private var busy = false                           // 系统一次只能跑一个手势

    // 实时触摸状态：0 空闲  1 已按下、尚未决定（点按还是拖动）  2 连续笔画进行中
    private var phase = 0
    private var sid = -1
    private var dx0 = 0f; private var dy0 = 0f         // 按下位置（px）
    private var lx = 0f; private var ly = 0f           // 已派发到的位置（px）
    private var lt = 0L                                // 已派发到的对方时间（ms）
    private var cur: GestureDescription.StrokeDescription? = null
    private val buf = ArrayList<FloatArray>()          // 待派发的点：[x(px), y(px), t(ms)]
    private var upPending = false
    private var ux = 0f; private var uy = 0f; private var ut = 0L
    private var lastRx = 0L

    // 滚动会话（见类注释「丝滑滚动」）：虚拟手指按在安全区里，按观看方发来的位移缓动推进
    private var scrolling = false                      // 一次滚动会话：从第一条 w 到手指抬起、收尾完成
    private var sDown = false                          // 虚拟手指是否按在屏幕上
    private var sCur: GestureDescription.StrokeDescription? = null
    private var sx = 0f; private var sy = 0f           // 虚拟手指位置（px）
    private var sPX = 0f; private var sPY = 0f         // 还没推进的手指位移（px）
    private var sT = 0L                                // 上一段派发的时刻
    private var sSpeed = 0f                            // 上一段的速度（px/ms），用来决定抬起前要不要先停稳
    private var sIdle = false                          // 观看方已停止滚动：把余量走完、停稳、抬起
    private var sRegrab = false                        // 手指到了安全区边缘还没滚够：抬起，在对面重新按下
    private var sEdgeX = false; private var sEdgeY = false
    private var sSeq = 0                               // 滚动会话序号：已被放弃 / 结束的会话，迟到的手势回调一律忽略
    private val sIdleRun = Runnable { sIdle = true; scrollStep() }

    // 屏幕尺寸缓存（每个触摸点都查一次 WindowManager 太浪费）
    private var scr = floatArrayOf(1f, 1f)
    private var scrT = 0L

    private val holdRun = Runnable { if (phase == 1) startLive() }
    private val wdRun = object : Runnable {
        override fun run() {
            if (phase == 0) return
            if (SystemClock.elapsedRealtime() - lastRx > 2500L) release() else h.postDelayed(this, 500L)
        }
    }

    override fun onServiceConnected() { inst = this }
    override fun onUnbind(intent: Intent?): Boolean { inst = null; q.clear(); return super.onUnbind(intent) }
    override fun onDestroy() { inst = null; super.onDestroy() }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    /* ───────────── 分发 ───────────── */
    private fun exec(j: JSONObject) {
        when (j.optString("t")) {
            "d" -> onDown(j.optInt("i"), j.optDouble("x").toFloat(), j.optDouble("y").toFloat())
            "m" -> onMove(j.optInt("i"), j.optJSONArray("p"))
            "u" -> onUp(j.optInt("i"), j.optDouble("x").toFloat(), j.optDouble("y").toFloat(), j.optLong("d"))
            "h" -> if (j.optInt("i") == sid) lastRx = SystemClock.elapsedRealtime()
            "k" -> key(j.optString("k"))
            "e" -> edit(j.optString("op"), j.optString("s"), j.optInt("n", 1))
            "w" -> wheel(j)
            "s" -> legacyStroke(j.optJSONArray("p"))
        }
    }

    @Suppress("DEPRECATION")
    private fun screen(): FloatArray {
        val now = SystemClock.uptimeMillis()
        if (now - scrT > 400L || scr[0] <= 1f) {              // 旋转后最多 0.4 秒内沿用旧尺寸
            val dm = DisplayMetrics()
            (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
            scr = floatArrayOf((dm.widthPixels - 1).coerceAtLeast(1).toFloat(), (dm.heightPixels - 1).coerceAtLeast(1).toFloat())
            scrT = now
        }
        return scr
    }

    private fun px(v: Float, size: Float): Float = v.coerceIn(0f, 1f) * size

    /* ───────────── 一次执行一个手势 ───────────── */
    private fun fire(gd: GestureDescription, dur: Long, cb: (Boolean) -> Unit) {
        busy = true
        var fin = false
        lateinit var guard: Runnable
        val finish = { ok: Boolean -> if (!fin) { fin = true; h.removeCallbacks(guard); busy = false; cb(ok) } }
        guard = Runnable { finish(false) }                     // 保险：回调丢了也不会卡死
        val started = try {
            dispatchGesture(gd, object : GestureResultCallback() {
                override fun onCompleted(d: GestureDescription?) { finish(true) }
                override fun onCancelled(d: GestureDescription?) { finish(false) }
            }, h)
        } catch (e: Exception) { false }
        if (!started) { finish(false); return }
        h.postDelayed(guard, dur + 1500L)
    }

    private fun path(sx: Float, sy: Float, pts: List<FloatArray>): Path {
        val p = Path()
        p.moveTo(sx, sy)
        var px = sx
        var py = sy
        for (pt in pts) {
            if (hypot(pt[0] - px, pt[1] - py) > 0.5f) { p.lineTo(pt[0], pt[1]); px = pt[0]; py = pt[1] }
        }
        return p
    }

    private fun enqueue(gd: GestureDescription, dur: Long) {
        if (q.size >= 6) q.pollFirst()
        q.addLast(G(gd, dur))
        pumpQ()
    }

    private fun pumpQ() {
        if (busy || phase != 0 || scrolling) return
        val g = q.pollFirst() ?: return
        fire(g.gd, g.dur) { pumpQ() }
    }

    /* ───────────── 实时触摸 ───────────── */
    private fun onDown(i: Int, x: Float, y: Float) {
        if (phase != 0) abandon()                          // 上一笔的「抬起」丢了：放弃它，系统会在下个手势时取消悬空笔画
        if (scrolling) abortScroll()                       // 触摸优先：滚动让路
        val s = screen()
        sid = i; phase = 1
        dx0 = px(x, s[0]); dy0 = px(y, s[1]); lx = dx0; ly = dy0; lt = 0L
        buf.clear(); upPending = false; cur = null
        lastRx = SystemClock.elapsedRealtime()
        h.postDelayed(holdRun, 120L)
        h.removeCallbacks(wdRun); h.postDelayed(wdRun, 500L)
    }

    private fun onMove(i: Int, a: JSONArray?) {
        if (i != sid || a == null || phase == 0) return
        lastRx = SystemClock.elapsedRealtime()
        val s = screen()
        for (k in 0 until min(a.length(), 64)) {
            val p = a.optJSONArray(k) ?: continue
            buf.add(floatArrayOf(px(p.optDouble(0).toFloat(), s[0]), px(p.optDouble(1).toFloat(), s[1]), p.optLong(2).toFloat()))
        }
        while (buf.size > 96) { var n = buf.size - 2; while (n > 0) { buf.removeAt(n); n -= 2 } }   // 积压太多：稀疏化，保留首尾
        if (phase == 1) {
            val slop = 0.012f * min(s[0], s[1])
            if (buf.any { hypot(it[0] - dx0, it[1] - dy0) > slop }) startLive()
        } else pumpLive()
    }

    private fun onUp(i: Int, x: Float, y: Float, held: Long) {
        if (i != sid) return
        lastRx = SystemClock.elapsedRealtime()
        val s = screen()
        if (phase == 1) {                                  // 没来得及进入拖动：普通点按
            h.removeCallbacks(holdRun)
            val gd = try {
                GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path(dx0, dy0, emptyList()), 0, held.coerceIn(30L, 120L))).build()
            } catch (e: Exception) { null }
            resetState()
            if (gd != null) enqueue(gd, 120L)
            return
        }
        upPending = true; ux = px(x, s[0]); uy = px(y, s[1]); ut = lt + 1
        pumpLive()
    }

    private fun startLive() {
        if (phase != 1) return
        if (busy) { h.postDelayed(holdRun, 30L); return }      // 前一个点按还在执行：等它跑完再开始（保证一次只有一个手势）
        phase = 2
        h.removeCallbacks(holdRun)
        val first = try {
            GestureDescription.StrokeDescription(path(dx0, dy0, emptyList()), 0, 1, true)
        } catch (e: Exception) { resetState(); return }
        cur = first
        val gd = GestureDescription.Builder().addStroke(first).build()
        fire(gd, 1L) { ok -> if (ok) pumpLive() else resetState() }
    }

    private fun pumpLive() {
        if (phase != 2 || busy) return
        val prev = cur ?: return
        val fin = upPending
        if (buf.isEmpty() && !fin) return
        val pts = ArrayList<FloatArray>(buf)
        buf.clear()
        if (fin) pts.add(floatArrayOf(ux, uy, maxOf(ut, if (pts.isEmpty()) lt else pts[pts.size - 1][2].toLong()).toFloat()))
        val tEnd = if (pts.isEmpty()) lt else pts[pts.size - 1][2].toLong()
        // 每段要尽量短：一段派发完才能派发下一段，段长 = 这一帧画面的「延迟」。旧版夹在 10–150ms，稳态下会涨到 150ms，
        // 手指一抽一抽地动（约 7 帧/秒）。现在只用约 55% 的真实时长去走这批点（略快于真实速度，积压自然被追平），上限 60ms。
        val span = tEnd - lt
        val dur = (span * LIVE_CATCHUP).toLong().coerceIn(LIVE_MIN_MS, LIVE_MAX_MS)
        val next = try {
            prev.continueStroke(path(lx, ly, pts), 0, dur, !fin)
        } catch (e: Exception) { resetState(); return }
        if (pts.isNotEmpty()) { lx = pts[pts.size - 1][0]; ly = pts[pts.size - 1][1] }
        lt = tEnd
        cur = next
        fire(GestureDescription.Builder().addStroke(next).build(), dur) { ok ->
            if (!ok || fin) resetState() else pumpLive()
        }
    }

    /** 抬起还按着的手指（会话结束 / 保活超时）。 */
    private fun release() {
        if (scrolling) { sPX = 0f; sPY = 0f; sIdle = true; scrollStep() }
        when (phase) {
            0 -> return
            1 -> resetState()
            else -> { upPending = true; ux = lx; uy = ly; ut = lt + 1; pumpLive(); if (!busy && phase == 2) resetState() }
        }
    }

    private fun abandon() {
        h.removeCallbacks(holdRun)
        phase = 0; sid = -1; cur = null; buf.clear(); upPending = false
    }

    private fun resetState() {
        abandon()
        h.removeCallbacks(wdRun)
        pumpQ()
    }

    /* ───────────── 导航键 / 文字 / 旧式整笔 ───────────── */
    private fun key(k: String) {
        val a = when (k) {
            "back" -> GLOBAL_ACTION_BACK
            "home" -> GLOBAL_ACTION_HOME
            "recents" -> GLOBAL_ACTION_RECENTS
            "notif" -> GLOBAL_ACTION_NOTIFICATIONS
            "quick" -> GLOBAL_ACTION_QUICK_SETTINGS
            else -> return
        }
        performGlobalAction(a)
    }

    private fun edit(op: String, s: String, n: Int) {
        val node = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (node == null) {
            onNoFocus?.invoke()
            return
        }
        if (op == "enter") {
            if (Build.VERSION.SDK_INT >= 30) node.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
            return
        }
        val cur = if (node.isShowingHintText) "" else (node.text?.toString() ?: "")
        val add = s.take(512)
        val next = when (op) {
            "append" -> cur + add
            "del" -> {
                var r = cur
                var k = n.coerceIn(1, 64)
                while (k > 0 && r.isNotEmpty()) {
                    r = r.substring(0, r.offsetByCodePoints(r.length, -1))
                    k--
                }
                r
            }
            "clear" -> ""
            "replace" -> add
            else -> return
        }
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, next)
        node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    /* ───────────── 滚动（电脑端滚轮 / 触控板双指）─────────────
     * 无障碍接口没有真正的滚轮事件，只能「伸一根手指」去划。要划得像样，关键是三点：
     *   1. 手指别碰屏幕边缘（系统的下拉通知栏 / 返回 / 主页手势都从边缘开始）→ 只在安全区里活动；
     *   2. 别一格一次地「甩」，而是一根手指连续地跟着位移走 → 内容 1:1 跟手，松手时自然带惯性；
     *   3. 位移经过缓动，观看方发来的抖动 / 滚轮的整格跳变都被抹平。 */
    private fun safeRect(s: FloatArray): FloatArray {
        val d = resources.displayMetrics.density
        val mx = min(max(32f * d, s[0] * 0.06f), s[0] * 0.3f)
        val mt = min(max(48f * d, s[1] * 0.06f), s[1] * 0.3f)
        val mb = min(max(56f * d, s[1] * 0.06f), s[1] * 0.3f)
        return floatArrayOf(mx, mt, s[0] - mx, s[1] - mb)          // [左, 上, 右, 下]
    }

    private fun wheel(j: JSONObject) {
        if (phase != 0) return                                     // 有真实触摸在进行（鼠标按着拖）：忽略滚轮
        val s = screen()
        val fx: Float
        val fy: Float
        if (j.has("sx") || j.has("sy")) {                          // 新版观看方：手指位移占屏幕的比例
            fx = j.optDouble("sx", 0.0).coerceIn(-1.5, 1.5).toFloat() * s[0]
            fy = j.optDouble("sy", 0.0).coerceIn(-1.5, 1.5).toFloat() * s[1]
        } else {                                                   // 旧版观看方：格数，手指方向与滚动方向相反
            fx = -j.optDouble("dx", 0.0).coerceIn(-8.0, 8.0).toFloat() * 0.12f * s[0]
            fy = -j.optDouble("dy", 0.0).coerceIn(-8.0, 8.0).toFloat() * 0.12f * s[1]
        }
        if (fx == 0f && fy == 0f) return
        if (!scrolling) beginScroll(px(j.optDouble("x", 0.5).toFloat(), s[0]), px(j.optDouble("y", 0.5).toFloat(), s[1]), fx, fy, s)
        sPX = (sPX + fx).coerceIn(-2f * s[0], 2f * s[0])           // 积压封顶：不会一口气滚出几屏
        sPY = (sPY + fy).coerceIn(-2f * s[1], 2f * s[1])
        sIdle = false
        h.removeCallbacks(sIdleRun)
        h.postDelayed(sIdleRun, 120L)
        scrollStep()
    }

    private fun beginScroll(cx: Float, cy: Float, fx: Float, fy: Float, s: FloatArray) {
        val r = safeRect(s)
        val w = r[2] - r[0]
        val hh = r[3] - r[1]
        var x = cx.coerceIn(r[0], r[2])
        var y = cy.coerceIn(r[1], r[3])
        // 手指要往哪边走，起点就放在那边的对侧，留足行程（光标本来的位置只影响「在哪个可滚动区域里划」）
        if (fy < 0f && y - r[1] < 0.4f * hh) y = r[1] + 0.78f * hh
        else if (fy > 0f && r[3] - y < 0.4f * hh) y = r[1] + 0.22f * hh
        if (fx < 0f && x - r[0] < 0.4f * w) x = r[0] + 0.78f * w
        else if (fx > 0f && r[2] - x < 0.4f * w) x = r[0] + 0.22f * w
        sSeq++
        scrolling = true; sDown = false; sCur = null
        sx = x; sy = y; sPX = 0f; sPY = 0f; sSpeed = 0f
        sIdle = false; sRegrab = false; sEdgeX = false; sEdgeY = false
        if (phase == 0) q.clear()                                  // 滚动期间排队的点按已经过时了
    }

    /** 往前推进一步：按下 → （缓动跟随）* → [停稳] → 抬起。一次只有一个手势在飞，每个手势完成后回到这里。 */
    private fun scrollStep() {
        if (!scrolling || busy) return
        val now = SystemClock.uptimeMillis()
        val seq = sSeq
        if (!sDown) {                                              // 按下（首次，或到边缘后在对面重抓）
            if (abs(sPX) < 0.5f && abs(sPY) < 0.5f) { if (sIdle) endScroll(); return }
            val first = try {
                GestureDescription.StrokeDescription(path(sx, sy, emptyList()), 0, 1, true)
            } catch (e: Exception) { endScroll(); return }
            sCur = first; sDown = true; sT = now; sSpeed = 0f
            fire(GestureDescription.Builder().addStroke(first).build(), 1L) { ok ->
                if (seq == sSeq) { if (ok) { sT = SystemClock.uptimeMillis(); scrollStep() } else endScroll() }
            }
            return
        }
        val prev = sCur ?: run { endScroll(); return }
        val exhausted = abs(sPX) < 0.5f && abs(sPY) < 0.5f
        if (sRegrab || (sIdle && exhausted)) {                     // 该抬起了
            if (sSpeed > 0.25f) {                                  // 还在动：先原地停一拍，免得抬起时被系统当成「甩」而飞出去
                val rest = try { prev.continueStroke(path(sx, sy, emptyList()), 0, 30, true) } catch (e: Exception) { endScroll(); return }
                sCur = rest; sSpeed = 0f; sT = now
                fire(GestureDescription.Builder().addStroke(rest).build(), 30L) { ok -> if (seq == sSeq) { if (ok) scrollStep() else endScroll() } }
                return
            }
            val up = try { prev.continueStroke(path(sx, sy, emptyList()), 0, 10, false) } catch (e: Exception) { endScroll(); return }
            fire(GestureDescription.Builder().addStroke(up).build(), 10L) { ok ->
                if (seq == sSeq) {
                    sDown = false; sCur = null
                    if (ok && sRegrab) { regrab(); scrollStep() } else endScroll()
                }
            }
            return
        }
        if (exhausted) return                                      // 没有新位移：等下一条 w，或 120ms 无新消息后收尾
        // 缓动推进：每段走掉余量的 1 - e^(-dt/τ)；余量很小时一步走完，免得拖尾
        val dt = (now - sT).coerceIn(8L, 50L)
        val k = if (sIdle) 1f else 1f - exp(-dt / SCROLL_TAU_MS)
        val s = screen()
        val r = safeRect(s)
        var mx = if (abs(sPX) < 2f) sPX else sPX * k
        var my = if (abs(sPY) < 2f) sPY else sPY * k
        var nx = sx + mx
        var ny = sy + my
        if (nx < r[0]) { nx = r[0]; sEdgeX = true } else if (nx > r[2]) { nx = r[2]; sEdgeX = true }
        if (ny < r[1]) { ny = r[1]; sEdgeY = true } else if (ny > r[3]) { ny = r[3]; sEdgeY = true }
        mx = nx - sx
        my = ny - sy
        sPX -= mx
        sPY -= my
        // 撞到安全区边缘后还剩不少没滚够 → 抬起并在对面重抓；剩得很少就舍弃
        val over = (sEdgeX && abs(sPX) > 12f) || (sEdgeY && abs(sPY) > 12f)
        if (over) sRegrab = true
        else { if (sEdgeX) sPX = 0f; if (sEdgeY) sPY = 0f; sEdgeX = false; sEdgeY = false }
        sSpeed = hypot(mx, my) / dt.toFloat()
        val next = try {
            prev.continueStroke(path(sx, sy, listOf(floatArrayOf(nx, ny, 0f))), 0, dt, true)
        } catch (e: Exception) { endScroll(); return }
        sx = nx; sy = ny; sCur = next; sT = now
        fire(GestureDescription.Builder().addStroke(next).build(), dt) { ok -> if (seq == sSeq) { if (ok) scrollStep() else endScroll() } }
    }

    /** 撞边后在对面重新按下：撞到哪条边，就从对面 12% / 88% 处接着划。 */
    private fun regrab() {
        val r = safeRect(screen())
        if (sEdgeY) sy = if (sPY < 0f) r[1] + 0.88f * (r[3] - r[1]) else r[1] + 0.12f * (r[3] - r[1])
        if (sEdgeX) sx = if (sPX < 0f) r[0] + 0.88f * (r[2] - r[0]) else r[0] + 0.12f * (r[2] - r[0])
        sRegrab = false; sEdgeX = false; sEdgeY = false
    }

    private fun endScroll() {
        sSeq++
        h.removeCallbacks(sIdleRun)
        scrolling = false; sDown = false; sCur = null; sPX = 0f; sPY = 0f; sIdle = false; sRegrab = false
        sEdgeX = false; sEdgeY = false
        pumpQ()
    }

    /** 触摸进来时放弃滚动：悬空的笔画会在下一个手势派发时被系统取消。 */
    private fun abortScroll() {
        sSeq++
        h.removeCallbacks(sIdleRun)
        scrolling = false; sDown = false; sCur = null; sPX = 0f; sPY = 0f; sIdle = false; sRegrab = false
        sEdgeX = false; sEdgeY = false
    }

    private fun legacyStroke(a: JSONArray?) {
        if (a == null || a.length() == 0) return
        val s = screen()
        val pts = ArrayList<FloatArray>()
        for (i in 0 until min(a.length(), 128)) {
            val p = a.optJSONArray(i) ?: continue
            pts.add(floatArrayOf(px(p.optDouble(0).toFloat(), s[0]), px(p.optDouble(1).toFloat(), s[1]), p.optLong(2).toFloat()))
        }
        if (pts.isEmpty()) return
        val dur = (pts[pts.size - 1][2].toLong() - pts[0][2].toLong()).coerceIn(30L, 10_000L)
        val gd = try {
            GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path(pts[0][0], pts[0][1], pts.drop(1)), 0, dur)).build()
        } catch (e: Exception) { return }
        enqueue(gd, dur)
    }
}
