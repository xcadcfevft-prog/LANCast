package com.lancast.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder

/**
 * 前台服务（dataSync）：让应用退到后台 / 息屏后依然能被发现、能接收文件，不被系统杀掉。
 * 它只负责「保活」：监听与接收的真正逻辑在 Link / FileXfer 里，随进程常驻。
 * 要彻底停止，请在应用主界面点「退出 LANCast」。
 */
class TransferService : Service() {

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("xfer", "后台待命（接收文件）", NotificationManager.IMPORTANCE_LOW))
        val pi = PendingIntent.getActivity(this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "xfer")
            .setContentTitle("LANCast 正在后台待命")
            .setContentText("可随时接收其他设备发来的文件（点按打开）")
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        try {
            startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } catch (e: Exception) {
            // 系统不允许在此刻启动前台服务（例如被后台重启）：放弃保活，等用户再次打开应用
            stopSelf()
            return START_NOT_STICKY
        }
        Link.init(applicationContext)
        Link.start()
        return START_STICKY
    }
}
