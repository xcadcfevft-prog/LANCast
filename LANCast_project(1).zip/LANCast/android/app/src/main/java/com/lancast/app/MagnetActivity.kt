package com.lancast.app

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.Editable
import android.text.InputType
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.core.view.WindowCompat
import com.frostwire.jlibtorrent.SessionManager
import com.frostwire.jlibtorrent.TorrentInfo
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/** 一次解析的结果 */
class MagnetResult(val name: String, val hash: String, val magnet: String, val files: List<TorrentFile>, val fromCache: Boolean, val secs: Int) {
    val total: Long get() = files.sumOf { it.size }
}

/**
 * jlibtorrent 会话：整个进程共用一个（启动和 DHT 引导都比较慢，复用能让第二次解析快很多）。
 * 界面关闭后延迟 45 秒再停，期间再次打开会直接复用。
 */
object MagnetEngine {
    private val lock = Any()
    private var session: SessionManager? = null
    private val main = Handler(Looper.getMainLooper())
    private val stopTask = Runnable {
        synchronized(lock) { try { session?.stop() } catch (_: Throwable) {}; session = null }
    }

    fun session(): SessionManager {
        main.removeCallbacks(stopTask)
        synchronized(lock) {
            return session ?: SessionManager().also { it.start(); session = it }
        }
    }

    fun release() { main.removeCallbacks(stopTask); main.postDelayed(stopTask, 45_000) }

    /** 不同版本的 jlibtorrent，fetchMagnet 的重载不一样（(uri,秒) / (uri,秒,临时目录) / (uri,秒,boolean)），这里按参数类型自适应 */
    private fun fetchMagnet(s: SessionManager, uri: String, timeoutSec: Int, tmp: File): ByteArray? {
        val m = s.javaClass.methods.filter { it.name == "fetchMagnet" }.minByOrNull { it.parameterTypes.size }
            ?: throw IllegalStateException("当前 jlibtorrent 版本不支持 fetchMagnet")
        val args = m.parameterTypes.mapIndexed { i, t ->
            when {
                i == 0 -> uri
                i == 1 -> timeoutSec
                t == File::class.java -> tmp
                t.name == "boolean" -> false
                else -> null
            }
        }.toTypedArray()
        try {
            return m.invoke(s, *args) as ByteArray?
        } catch (e: java.lang.reflect.InvocationTargetException) {
            throw e.targetException ?: e
        }
    }

    private fun toResult(link: MagnetLink, data: ByteArray, fromCache: Boolean, secs: Int): MagnetResult {
        val ti = TorrentInfo.bdecode(data)
        val fs = ti.files()
        val files = ArrayList<TorrentFile>()
        for (i in 0 until ti.numFiles()) {
            val p = fs.filePath(i)
            if (!MagnetCore.isPadding(p)) files.add(TorrentFile(p, fs.fileSize(i)))
        }
        val name = ti.name().ifEmpty { link.name }
        return MagnetResult(name, link.hash, MagnetCore.build(MagnetLink(link.hash, name, link.trackers, emptyList())), files, fromCache, secs)
    }

    /** 先查本地缓存；没有就联网：追加一批公共 Tracker 帮助找节点，最多 2 轮（第二轮 DHT 已经热了，成功率更高） */
    fun load(ctx: Context, link: MagnetLink, cancelled: AtomicBoolean, onStage: (String) -> Unit): MagnetResult {
        val dir = File(ctx.cacheDir, "magnet").apply { mkdirs() }
        val tmp = File(ctx.cacheDir, "magnet-tmp").apply { mkdirs() }      // 给 fetchMagnet 用的临时目录，和我们自己的缓存分开
        val cf = File(dir, link.hash + ".torrent")
        if (cf.exists()) {
            try { return toResult(link, cf.readBytes(), true, 0) } catch (_: Throwable) { cf.delete() }
        }
        val uri = MagnetCore.build(link, MagnetCore.DEFAULT_TRACKERS)
        val t0 = SystemClock.elapsedRealtime()
        var data: ByteArray? = null
        for (round in 1..2) {
            if (cancelled.get()) throw InterruptedException("cancelled")
            onStage(if (round == 1) "正在寻找节点并下载元数据" else "再试一轮（DHT 已预热）")
            data = fetchMagnet(session(), uri, 40, tmp)
            if (data != null) break
        }
        val bytes = data ?: throw IllegalStateException("未获取到元数据：资源可能已无人做种，或当前网络无法访问 DHT / Tracker。可换个网络（WiFi / 流量）或稍后重试")
        val res = toResult(link, bytes, false, ((SystemClock.elapsedRealtime() - t0) / 1000).toInt())
        try {
            cf.writeBytes(bytes)
            dir.listFiles { f -> f.name.endsWith(".torrent") }?.sortedByDescending { it.lastModified() }?.drop(100)?.forEach { it.delete() }
        } catch (_: Throwable) {}
        return res
    }
}

/**
 * 磁力解析界面。入口：首页「磁力解析」卡片；也可以从浏览器 / 其它应用点 magnet 链接、或分享文字到「瞬流」。
 * 打开时会自动读取剪贴板里的磁力链接；支持多条、迅雷链接、纯哈希。
 */
class MagnetActivity : ComponentActivity() {
    private val io = Executors.newCachedThreadPool()
    private val ui = Handler(Looper.getMainLooper())

    private lateinit var input: EditText
    private lateinit var goBtn: TextView
    private lateinit var cancelBtn: TextView
    private lateinit var statusTv: TextView
    private lateinit var resultBox: LinearLayout
    private lateinit var headTv: TextView
    private lateinit var metaTv: TextView
    private lateinit var nextBtn: TextView
    private lateinit var sortBtn: TextView
    private lateinit var filter: EditText
    private lateinit var countTv: TextView
    private lateinit var listView: ListView

    private var result: MagnetResult? = null
    private var shown: List<TorrentFile> = emptyList()
    private var sortBySize = false
    private var job: AtomicBoolean? = null
    private val pending = ArrayDeque<MagnetLink>()
    @Volatile private var stage = ""
    private var clipChecked = false
    private var ticker: Runnable? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = C.BG
        window.navigationBarColor = C.BG
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = true
            isAppearanceLightNavigationBars = true
        }
        setContentView(buildUi())
        io.execute { try { MagnetEngine.session() } catch (_: Throwable) {} }   // 提前启动会话，DHT 边等边预热
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        // Android 10+ 只允许处于前台焦点的应用读取剪贴板，所以放在这里读
        if (!hasFocus || clipChecked || input.text.isNotBlank()) return
        clipChecked = true
        val t = try {
            (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()
        } catch (_: Throwable) { null }
        if (!t.isNullOrBlank() && MagnetCore.extract(t).isNotEmpty()) {
            input.setText(t.trim())
            setStatus("已读取剪贴板里的磁力链接，点「解析」开始", false)
        }
    }

    override fun onDestroy() {
        job?.set(true)
        stopTicker()
        MagnetEngine.release()
        io.shutdown()
        super.onDestroy()
    }

    /* ───────────── 界面 ───────────── */
    private fun tv(text: String, sp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun chip(text: String, primary: Boolean, onClick: () -> Unit) = TextView(this).apply {
        this.text = text
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setTextColor(if (primary) Color.WHITE else C.PRIMARY)
        background = shape(if (primary) C.PRIMARY else C.SOFT, 22f)
        setPadding(px(16), px(9), px(16), px(9))
        setOnClickListener { onClick() }
    }

    private fun lp(w: Int, h: Int, weight: Float = 0f, top: Int = 0, left: Int = 0) =
        LinearLayout.LayoutParams(w, h, weight).apply { topMargin = px(top); leftMargin = px(left) }

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(C.BG)
            setPadding(px(16), px(12), px(16), px(8))
        }
        // 顶栏
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        bar.addView(tv("‹ 返回", 15f, C.PRIMARY, true).apply { setPadding(0, px(6), px(14), px(6)); setOnClickListener { finish() } })
        bar.addView(tv("磁力解析", 20f, C.INK, true))
        root.addView(bar, lp(MATCH_PARENT, WRAP_CONTENT))

        input = EditText(this).apply {
            hint = "粘贴 magnet:?xt=urn:btih:…（支持多条、迅雷链接、纯哈希）"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            minLines = 2; maxLines = 4
            gravity = Gravity.TOP or Gravity.START
            setTextColor(C.INK)
            background = shape(Color.WHITE, 14f, C.INPUT_LINE, 1f)
            setPadding(px(12), px(10), px(12), px(10))
        }
        root.addView(input, lp(MATCH_PARENT, WRAP_CONTENT, 0f, 10))

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        goBtn = chip("解析", true) { start() }
        cancelBtn = chip("取消", false) { cancel() }.apply { visibility = View.GONE }
        row.addView(goBtn)
        row.addView(cancelBtn, lp(WRAP_CONTENT, WRAP_CONTENT, 0f, 0, 8))
        row.addView(chip("粘贴", false) { pasteClipboard() }, lp(WRAP_CONTENT, WRAP_CONTENT, 0f, 0, 8))
        row.addView(chip("清空", false) { input.setText(""); pending.clear() }, lp(WRAP_CONTENT, WRAP_CONTENT, 0f, 0, 8))
        root.addView(row, lp(MATCH_PARENT, WRAP_CONTENT, 0f, 10))

        statusTv = tv("", 13f, C.SUB).apply { setLineSpacing(0f, 1.15f) }
        root.addView(statusTv, lp(MATCH_PARENT, WRAP_CONTENT, 0f, 10))

        // 结果区
        resultBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = shape(C.CARD, 16f, C.CARD_LINE, 1f)
            setPadding(px(14), px(12), px(14), px(12))
        }
        headTv = tv("", 16f, C.INK, true)
        metaTv = tv("", 12f, C.SUB).apply { setLineSpacing(0f, 1.2f) }
        card.addView(headTv)
        card.addView(metaTv, lp(MATCH_PARENT, WRAP_CONTENT, 0f, 4))
        val acts = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        acts.addView(chip("复制磁力", false) { result?.let { copy(it.magnet, "磁力链接") } })
        acts.addView(chip("复制列表", false) { result?.let { copy(fileListText(it), "文件列表") } }, lp(WRAP_CONTENT, WRAP_CONTENT, 0f, 0, 8))
        acts.addView(chip("分享", false) { share() }, lp(WRAP_CONTENT, WRAP_CONTENT, 0f, 0, 8))
        card.addView(acts, lp(MATCH_PARENT, WRAP_CONTENT, 0f, 10))
        nextBtn = chip("解析下一条", true) { next() }.apply { visibility = View.GONE }
        card.addView(nextBtn, lp(WRAP_CONTENT, WRAP_CONTENT, 0f, 8))
        resultBox.addView(card, lp(MATCH_PARENT, WRAP_CONTENT))

        val fr = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        filter = EditText(this).apply {
            hint = "过滤文件名…"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setSingleLine()
            setTextColor(C.INK)
            background = shape(Color.WHITE, 12f, C.INPUT_LINE, 1f)
            setPadding(px(10), px(7), px(10), px(7))
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { refreshList() }
                override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            })
        }
        sortBtn = chip("按大小", false) { sortBySize = !sortBySize; sortBtn.text = if (sortBySize) "原顺序" else "按大小"; refreshList() }
        fr.addView(filter, lp(0, WRAP_CONTENT, 1f))
        fr.addView(sortBtn, lp(WRAP_CONTENT, WRAP_CONTENT, 0f, 0, 8))
        resultBox.addView(fr, lp(MATCH_PARENT, WRAP_CONTENT, 0f, 10))
        countTv = tv("", 12f, C.SUB)
        resultBox.addView(countTv, lp(MATCH_PARENT, WRAP_CONTENT, 0f, 6))
        root.addView(resultBox, lp(MATCH_PARENT, WRAP_CONTENT, 0f, 10))

        listView = ListView(this).apply {
            divider = null
            isVerticalScrollBarEnabled = true
            adapter = object : BaseAdapter() {
                override fun getCount() = shown.size
                override fun getItem(i: Int) = shown[i]
                override fun getItemId(i: Int) = i.toLong()
                override fun getView(i: Int, v: View?, p: ViewGroup?): View {
                    val t = (v as? TextView) ?: TextView(this@MagnetActivity).apply {
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                        setTextColor(C.INK)
                        setPadding(px(4), px(7), px(4), px(7))
                        setTextIsSelectable(false)
                    }
                    val f = shown[i]
                    val sb = SpannableStringBuilder(f.path)
                    val start = sb.length + 1
                    sb.append('\n').append(MagnetCore.formatSize(f.size))
                    sb.setSpan(ForegroundColorSpan(C.SUB), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    t.text = sb
                    return t
                }
            }
        }
        root.addView(listView, lp(MATCH_PARENT, 0, 1f))
        return root
    }

    /* ───────────── 行为 ───────────── */
    private fun setStatus(msg: String, error: Boolean) {
        statusTv.text = msg
        statusTv.setTextColor(if (error) C.BAD else C.SUB)
        statusTv.visibility = if (msg.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun pasteClipboard() {
        val t = try {
            (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()
        } catch (_: Throwable) { null }
        if (t.isNullOrBlank()) setStatus("剪贴板是空的", true) else { input.setText(t.trim()); setStatus("", false) }
    }

    private fun handleIntent(i: Intent?) {
        if (i == null) return
        val t = (if (i.action == Intent.ACTION_SEND) i.getStringExtra(Intent.EXTRA_TEXT) else i.dataString) ?: return
        if (MagnetCore.extract(t).isNotEmpty()) {
            clipChecked = true
            input.setText(t)
            start()
        }
    }

    private fun start() {
        val text = input.text.toString()
        val links = MagnetCore.extract(text)
        if (links.isEmpty()) {
            setStatus(if (text.isBlank()) "请先粘贴磁力链接" else "没有识别到有效的磁力链接（需要 magnet:?xt=urn:btih:… 或 40 位哈希）", true)
            return
        }
        pending.clear()
        pending.addAll(links.drop(1))
        run(links[0])
    }

    private fun next() { pending.removeFirstOrNull()?.let { run(it) } }

    private fun run(link: MagnetLink) {
        job?.set(true)
        val flag = AtomicBoolean(false)
        job = flag
        result = null
        resultBox.visibility = View.GONE
        shown = emptyList(); (listView.adapter as BaseAdapter).notifyDataSetChanged()
        setBusy(true)
        stage = "准备中"
        val t0 = SystemClock.elapsedRealtime()
        val extra = if (pending.isNotEmpty()) "（还有 ${pending.size} 条排队）" else ""
        stopTicker()
        ticker = object : Runnable {
            override fun run() {
                if (flag.get()) return
                setStatus("$stage… ${(SystemClock.elapsedRealtime() - t0) / 1000}s $extra", false)
                ui.postDelayed(this, 1000)
            }
        }.also { it.run() }
        io.execute {
            try {
                val r = MagnetEngine.load(applicationContext, link, flag) { stage = it }
                ui.post { if (!flag.get()) showResult(r) }
            } catch (e: InterruptedException) {
                // 已取消
            } catch (e: Throwable) {
                ui.post { if (!flag.get()) { setStatus(e.message ?: e.javaClass.simpleName, true); if (pending.isNotEmpty()) showNextOnly() } }
            } finally {
                ui.post { if (job === flag) { setBusy(false); stopTicker() } }
            }
        }
    }

    private fun cancel() {
        job?.set(true)
        stopTicker()
        setBusy(false)
        setStatus("已取消", false)
    }

    private fun stopTicker() { ticker?.let { ui.removeCallbacks(it) }; ticker = null }

    private fun setBusy(b: Boolean) {
        goBtn.visibility = if (b) View.GONE else View.VISIBLE
        cancelBtn.visibility = if (b) View.VISIBLE else View.GONE
    }

    private fun showNextOnly() {
        resultBox.visibility = View.VISIBLE
        headTv.text = "这一条失败了"; metaTv.text = "还有 ${pending.size} 条等待解析"
        nextBtn.visibility = View.VISIBLE
        countTv.text = ""
    }

    private fun showResult(r: MagnetResult) {
        result = r
        setStatus("", false)
        resultBox.visibility = View.VISIBLE
        headTv.text = r.name.ifEmpty { r.hash }
        metaTv.text = "${MagnetCore.formatSize(r.total)} · ${r.files.size} 个文件 · " +
            (if (r.fromCache) "来自缓存" else "用时 ${r.secs} 秒") + "\nHash: ${r.hash}"
        nextBtn.visibility = if (pending.isNotEmpty()) View.VISIBLE else View.GONE
        nextBtn.text = "解析下一条（还有 ${pending.size} 条）"
        filter.setText("")
        refreshList()
    }

    private fun refreshList() {
        val r = result ?: return
        val q = filter.text.toString().trim().lowercase()
        var l = if (q.isEmpty()) r.files else r.files.filter { it.path.lowercase().contains(q) }
        if (sortBySize) l = l.sortedByDescending { it.size }
        shown = l
        (listView.adapter as BaseAdapter).notifyDataSetChanged()
        countTv.text = if (q.isEmpty()) "共 ${r.files.size} 个文件" else "匹配 ${l.size} / ${r.files.size} 个文件"
    }

    private fun fileListText(r: MagnetResult): String =
        r.name + "\n" + r.files.joinToString("\n") { "${MagnetCore.formatSize(it.size)}\t${it.path}" }

    private fun copy(text: String, what: String) {
        try {
            (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("magnet", text))
            Toast.makeText(this, "${what}已复制", Toast.LENGTH_SHORT).show()
        } catch (e: Throwable) {
            Toast.makeText(this, "复制失败", Toast.LENGTH_SHORT).show()
        }
    }

    private fun share() {
        val r = result ?: return
        // Intent 经 Binder 传输有大小上限，超长文件列表只分享前 2000 行
        val text = fileListText(r).lineSequence().take(2000).joinToString("\n") + "\n\n" + r.magnet
        val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
        startActivity(Intent.createChooser(i, "分享文件列表"))
    }
}
