package com.lancast.app

import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*
import androidx.activity.ComponentActivity
import com.frostwire.jlibtorrent.SessionManager
import com.frostwire.jlibtorrent.TorrentInfo
import java.util.concurrent.Executors

/** 磁力解析：jlibtorrent 通过 DHT 拉取元数据并列出文件。启动: startActivity(Intent(this, MagnetActivity::class.java)) */
class MagnetActivity : ComponentActivity() {
    private var session: SessionManager? = null
    private val io = Executors.newSingleThreadExecutor()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val input = EditText(this).apply { hint = "magnet:?xt=urn:btih:..."; setText(intent.dataString ?: "") }
        val go = Button(this).apply { text = "解析" }
        val out = TextView(this).apply { movementMethod = ScrollingMovementMethod(); textSize = 13f }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad)
            addView(input, LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT))
            addView(go); addView(out, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        })
        go.setOnClickListener {
            val uri = input.text.toString().trim()
            if (!uri.startsWith("magnet:?", true)) { out.text = "不是磁力链接"; return@setOnClickListener }
            out.text = "解析中…(最长约 60 秒)"; go.isEnabled = false
            io.execute {
                val msg = try { resolve(uri) } catch (e: Exception) { "错误: ${e.message}" }
                runOnUiThread { out.text = msg; go.isEnabled = true }
            }
        }
    }

    private fun resolve(uri: String): String {
        val s = session ?: SessionManager().also { it.start(); session = it }
        val data = s.fetchMagnet(uri, 60) ?: return "未获取到元数据(超时/无可用节点)"
        val ti = TorrentInfo.bdecode(data)
        val fs = ti.files()
        val sb = StringBuilder("名称: ${ti.name()}\nHash: ${ti.infoHash()}\n总大小: ${fmt(ti.totalSize())}  文件数: ${ti.numFiles()}\n")
        for (i in 0 until ti.numFiles()) sb.append("${fmt(fs.fileSize(i))}  ${fs.filePath(i)}\n")
        return sb.toString()
    }

    private fun fmt(n: Long) = when {
        n > 1e9 -> "%.2f GB".format(n / 1e9); n > 1e6 -> "%.1f MB".format(n / 1e6); else -> "${n / 1000} KB"
    }

    override fun onDestroy() { session?.stop(); io.shutdown(); super.onDestroy() }
}
