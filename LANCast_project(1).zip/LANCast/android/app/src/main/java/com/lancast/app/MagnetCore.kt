package com.lancast.app

import java.util.Base64

/*
 * 磁力链接解析核心（纯 Kotlin，不依赖 Android，可在电脑上用 kotlinc 直接测试）。
 * 与 Windows 端 windows/magnet.js 的解析规则保持一致：
 *   magnet 链接 / thunder:// / 纯哈希 / 夹在文字里的链接；HTML 转义、全角字符、断行、零宽字符；
 *   40 位十六进制与 32 位 base32；dn / tr / tr.N / x.pe；按哈希去重。
 */
class MagnetLink(
    val hash: String,                       // 40 位小写十六进制
    val name: String,
    val trackers: List<String>,
    val peers: List<String>                 // x.pe=host:port
) {
    val magnet: String get() = MagnetCore.build(this)
}

data class TorrentFile(val path: String, val size: Long)

object MagnetCore {
    val DEFAULT_TRACKERS = listOf(
        "udp://tracker.opentrackr.org:1337/announce", "udp://open.stealth.si:80/announce",
        "udp://tracker.torrent.eu.org:451/announce", "udp://exodus.desync.com:6969/announce",
        "udp://open.demonii.com:1337/announce", "udp://explodie.org:6969/announce",
        "udp://tracker.tiny-vps.com:6969/announce", "udp://tracker.dler.org:6969/announce",
        "udp://opentracker.io:6969/announce", "udp://p4p.arenabg.com:1337/announce",
        "udp://open.tracker.cl:1337/announce", "https://tracker.tamersunion.org:443/announce",
        "udp://tracker.theoks.net:6969/announce", "udp://tracker.bittor.pw:1337/announce"
    )

    private const val B32 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"
    private val HEX40 = Regex("^[0-9a-fA-F]{40}$")
    private val B32_32 = Regex("^[A-Za-z2-7]{32}$")
    private val MAGNET_IN_TEXT = Regex("magnet:\\??[^\\s\"'<>\\u3000「」]+", RegexOption.IGNORE_CASE)
    private val THUNDER_IN_TEXT = Regex("thunder://[A-Za-z0-9+/=_-]+", RegexOption.IGNORE_CASE)
    private val BARE_HASH = Regex("^\\s*(?:urn:)?(?:btih:)?([0-9a-fA-F]{40}|[A-Za-z2-7]{32})\\s*$", RegexOption.IGNORE_CASE)
    private val TRAIL_PUNCT = Regex("[.,;:!?)\\]}>。，；！？）】》”’\"']+$")
    private val PCT_RUN = Regex("(?:%[0-9a-fA-F]{2})+")
    private val TRACKER_OK = Regex("^(udp|https?)://[^\\s/]+", RegexOption.IGNORE_CASE)

    /** 32 位 base32 → 40 位十六进制 */
    fun b32ToHex(s: String): String {
        var bits = 0
        var v = 0
        val out = StringBuilder()
        for (ch in s.uppercase()) {
            val i = B32.indexOf(ch)
            require(i >= 0) { "哈希含有非法字符" }
            v = ((v shl 5) or i) and 0xfff
            bits += 5
            if (bits >= 8) {
                out.append("%02x".format((v ushr (bits - 8)) and 255))
                bits -= 8
                v = v and ((1 shl bits) - 1)
            }
        }
        return out.toString()
    }

    /** 合法则返回 40 位小写十六进制，否则返回空串 */
    fun normHash(s: String): String {
        val t = s.trim()
        return when {
            HEX40.matches(t) -> t.lowercase()
            B32_32.matches(t) -> b32ToHex(t)
            else -> ""
        }
    }

    /** 全角 ASCII → 半角，还原 &amp;，去掉零宽字符 */
    fun tidy(s: String): String {
        val sb = StringBuilder(s.length)
        for (c in s) {
            when {
                c in '！'..'～' -> sb.append((c.code - 0xFEE0).toChar())
                c in '​'..'‍' || c == '﻿' || c == '⁠' -> {}
                else -> sb.append(c)
            }
        }
        return sb.toString().replace("&amp;", "&", ignoreCase = true).replace("&#38;", "&")
    }

    private fun dec(s: String, plus: Boolean = true): String {
        val t = if (plus) s.replace('+', ' ') else s
        return PCT_RUN.replace(t) { m ->
            val hex = m.value.replace("%", "")
            val bytes = ByteArray(hex.length / 2) { i -> hex.substring(i * 2, i * 2 + 2).toInt(16).toByte() }
            String(bytes, Charsets.UTF_8)
        }
    }

    private fun parseHostPort(s: String): String? {
        val m = Regex("^\\[?([^\\]\\s]+?)\\]?:(\\d{1,5})$").find(s.trim()) ?: return null
        val port = m.groupValues[2].toInt()
        return if (port in 1..65535) "${m.groupValues[1]}:$port" else null
    }

    private fun decodeThunder(s: String): String {
        val b64 = s.replace(Regex("^thunder://", RegexOption.IGNORE_CASE), "").replace('-', '+').replace('_', '/')
        val t = String(Base64.getMimeDecoder().decode(b64), Charsets.UTF_8)
        return if (t.startsWith("AA") && t.endsWith("ZZ") && t.length >= 4) t.substring(2, t.length - 2) else t
    }

    /** 解析单个 magnet:?… 链接（已清洗）；失败抛 IllegalArgumentException，message 是中文原因 */
    fun parseOne(uri: String): MagnetLink {
        val m = Regex("^magnet:\\??(.*)$", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)).find(uri)
            ?: throw IllegalArgumentException("不是磁力链接")
        val hashes = ArrayList<String>()
        val trackers = ArrayList<String>()
        val peers = ArrayList<String>()
        var name = ""
        var hasV2 = false
        for (part in m.groupValues[1].split('&')) {
            val eq = part.indexOf('=')
            if (eq < 0) continue
            val k = part.substring(0, eq).lowercase().replace(Regex("\\.\\d+$"), "")
            val raw = part.substring(eq + 1)
            when (k) {
                "xt" -> {
                    val v = dec(raw, false)
                    Regex("^urn:btih:(.+)$", RegexOption.IGNORE_CASE).find(v)?.let { hashes.add(it.groupValues[1]) }
                    if (Regex("^urn:btmh:", RegexOption.IGNORE_CASE).containsMatchIn(v)) hasV2 = true
                }
                "dn" -> if (name.isEmpty()) name = dec(raw).trim()
                "tr" -> dec(raw, false).trim().let { if (TRACKER_OK.containsMatchIn(it)) trackers.add(it) }
                "x.pe" -> parseHostPort(dec(raw, false))?.let { peers.add(it) }
            }
        }
        var hash = ""
        for (h in hashes) { hash = normHash(h); if (hash.isNotEmpty()) break }
        if (hash.isEmpty() && hashes.isNotEmpty()) throw IllegalArgumentException("哈希格式不正确（应为 40 位十六进制或 32 位 base32）")
        if (hash.isEmpty() && hasV2) throw IllegalArgumentException("暂不支持纯 BT v2 磁力（链接里没有 btih 哈希）")
        if (hash.isEmpty()) throw IllegalArgumentException("缺少 btih 哈希")
        return MagnetLink(hash, name, trackers.distinctBy { it.lowercase() }, peers.distinct())
    }

    /** 从任意文字里提取全部磁力（magnet / thunder / 纯哈希），按哈希去重，无效项跳过 */
    fun extract(text: String): List<MagnetLink> {
        val t = tidy(text)
        val found = ArrayList<MagnetLink>()
        for (m in MAGNET_IN_TEXT.findAll(t)) {
            runCatching { found.add(parseOne(m.value.replace(Regex("[\\r\\n\\t]"), "").replace(TRAIL_PUNCT, ""))) }
        }
        for (m in THUNDER_IN_TEXT.findAll(t)) {
            runCatching { found.addAll(extract(decodeThunder(m.value))) }
        }
        if (found.isEmpty()) {
            BARE_HASH.find(t)?.let { b ->
                val h = normHash(b.groupValues[1])
                if (h.isNotEmpty()) found.add(MagnetLink(h, "", emptyList(), emptyList()))
            }
        }
        return found.distinctBy { it.hash }
    }

    /** 解析一条；失败抛 IllegalArgumentException */
    fun parse(input: String): MagnetLink {
        val t = tidy(input).trim().trimStart('<', '"', '\'', '「').trimEnd('>', '"', '\'', '」')
        if (t.startsWith("magnet:", ignoreCase = true)) return parseOne(t.replace(Regex("[\\r\\n\\t]"), ""))
        extract(t).firstOrNull()?.let { return it }
        if (t.startsWith("thunder:", ignoreCase = true)) throw IllegalArgumentException("迅雷链接里不是磁力链接")
        throw IllegalArgumentException("不是磁力链接")
    }

    private fun enc(s: String) = java.net.URLEncoder.encode(s, "UTF-8").replace("+", "%20")

    /** 生成规范的 magnet 链接；extraTrackers 会追加（按 URL 去重），用来给解析引擎更多寻址来源 */
    fun build(link: MagnetLink, extraTrackers: List<String> = emptyList()): String {
        val sb = StringBuilder("magnet:?xt=urn:btih:").append(link.hash)
        if (link.name.isNotEmpty()) sb.append("&dn=").append(enc(link.name))
        for (tr in (link.trackers + extraTrackers).distinctBy { it.lowercase() }) sb.append("&tr=").append(enc(tr))
        for (p in link.peers) sb.append("&x.pe=").append(p)
        return sb.toString()
    }

    fun formatSize(n: Long): String {
        var v = n.toDouble()
        val u = arrayOf("B", "KB", "MB", "GB", "TB")
        var i = 0
        while (v >= 1024 && i < u.size - 1) { v /= 1024; i++ }
        return if (i == 0 || v >= 100) "%.0f %s".format(v, u[i]) else if (v >= 10) "%.1f %s".format(v, u[i]) else "%.2f %s".format(v, u[i])
    }

    /** BEP 47 补位文件（.pad/ 或 _____padding_file_），不应该出现在文件列表里 */
    fun isPadding(path: String): Boolean {
        val segs = path.split('/')
        return segs.any { it == ".pad" || it.startsWith("_____padding_file_") }
    }
}
