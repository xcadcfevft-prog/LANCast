package com.lancast.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.graphics.Matrix
import android.graphics.Rect
import android.graphics.SurfaceTexture
import android.graphics.YuvImage
import android.hardware.Camera
import android.view.Surface
import android.view.WindowManager
import java.io.ByteArrayOutputStream

/**
 * 视频通话的画质四档（和投屏画质弹窗同样的四个名字）。
 * 视频帧 = 相机原始 YUV 直接压成 JPEG（逐帧独立，丢一帧不影响后面；不做运动补偿等有损预测），
 * 档位只决定「分辨率 / JPEG 质量 / 帧率上限」。音频始终是 48 kHz / 16 bit 原始 PCM，不受画质档位影响。
 */
class VideoTier(val name: String, val w: Int, val h: Int, val quality: Int, val fps: Int, val native: Boolean = false)

object VideoTiers {
    val ALL = listOf(
        VideoTier("视觉无损（高码率）", 1280, 720, 95, 30),
        VideoTier("均衡", 960, 540, 80, 24),
        VideoTier("省流畅", 640, 360, 55, 20),
        // 极致无损 Beta：和投屏一样——原生分辨率（取相机支持的最大预览尺寸）、不限帧率（取相机最高帧率）、JPEG 质量 100
        VideoTier("极致无损 Beta", Int.MAX_VALUE, Int.MAX_VALUE, 100, 60, true)
    )
    fun of(i: Int) = ALL[i.coerceIn(0, ALL.size - 1)]
    /** 没单独选过视频画质时，默认沿用投屏画质设置，保证两处一开始就是同一档 */
    fun saved(): Int = try {
        Link.prefs.getInt("video_tier", Link.prefs.getInt("preset", 0)).coerceIn(0, ALL.size - 1)
    } catch (e: Exception) { 0 }
    fun save(i: Int) { try { Link.prefs.edit().putInt("video_tier", i).apply() } catch (ignored: Exception) { } }
}

/**
 * 视频帧（T_CHAT_VIDEO = 51，加密前的明文）：
 *   u8 ver(=1) | u8 画质档位 | u8 旋转（×90°，顺时针，接收方按它转正）| u8 保留 | u16 宽（大端）| u16 高（大端）| u32 序号（大端） | JPEG 数据
 */
object VideoCodec {
    const val HDR = 12
    const val MAX_JPEG = 3 * 1024 * 1024

    fun pack(seq: Int, tier: Int, rot: Int, w: Int, h: Int, jpeg: ByteArray, len: Int): ByteArray {
        val b = ByteArray(HDR + len)
        b[0] = 1; b[1] = tier.toByte(); b[2] = ((rot / 90) and 3).toByte(); b[3] = 0
        b[4] = (w ushr 8).toByte(); b[5] = w.toByte(); b[6] = (h ushr 8).toByte(); b[7] = h.toByte()
        b[8] = (seq ushr 24).toByte(); b[9] = (seq ushr 16).toByte(); b[10] = (seq ushr 8).toByte(); b[11] = seq.toByte()
        System.arraycopy(jpeg, 0, b, HDR, len)
        return b
    }
}

/** 接收端：只保留最新一帧，专用线程解码（解码慢就自动跳帧，不会越积越多），解码完交给 deliver（主线程之外的线程里调用） */
class VideoRx(private val deliver: (Bitmap) -> Unit) {
    @Volatile private var dead = false
    private var slot: ByteArray? = null
    private val lock = Object()
    private val th = Thread {
        while (!dead) {
            var b: ByteArray? = null
            synchronized(lock) {
                while (slot == null && !dead) try { lock.wait() } catch (e: InterruptedException) { return@Thread }
                b = slot; slot = null
            }
            val buf = b ?: continue
            try { decode(buf)?.let(deliver) } catch (ignored: Throwable) { }
        }
    }.also { it.name = "video-rx"; it.isDaemon = true; it.start() }

    fun push(buf: ByteArray) { synchronized(lock) { slot = buf; lock.notifyAll() } }
    fun stop() { dead = true; synchronized(lock) { slot = null; lock.notifyAll() } }

    private fun decode(b: ByteArray): Bitmap? {
        if (b.size <= VideoCodec.HDR + 4 || b.size > VideoCodec.HDR + VideoCodec.MAX_JPEG || b[0].toInt() != 1) return null
        val rot = (b[2].toInt() and 3) * 90
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(b, VideoCodec.HDR, b.size - VideoCodec.HDR, o)
        if (o.outWidth <= 0 || o.outHeight <= 0 || o.outWidth > 4096 || o.outHeight > 4096) return null      // 防止畸形帧撑爆内存
        val bmp = BitmapFactory.decodeByteArray(b, VideoCodec.HDR, b.size - VideoCodec.HDR) ?: return null
        if (rot == 0) return bmp
        val out = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(rot.toFloat()) }, true)
        if (out !== bmp) bmp.recycle()
        return out
    }
}

/**
 * 相机采集（android.hardware.Camera，不需要额外依赖）：预览回调拿到 NV21 → 按档位限帧 → 压成 JPEG → onFrame(打好包的帧)。
 * 旋转不在发送端做（省 CPU），写进帧头由接收方转正；前置摄像头发出去不镜像（和微信一样，对方看到的是正的）。
 * onLocal 每隔几帧给本地小窗一张缩小的自拍预览（直接从刚压好的 JPEG 解码 1/4 大小，很便宜）。
 */
class CameraEngine(
    private val tierIdx: () -> Int,
    private val onFrame: (ByteArray) -> Unit,
    private val onLocal: (Bitmap) -> Unit,
    private val onFail: () -> Unit
) {
    // 相机的所有操作（打开 / 翻转 / 换档 / 关闭）和预览回调都在这条专用线程上：JPEG 压缩不会卡界面
    private val ht = android.os.HandlerThread("video-cam").also { it.start() }
    private val h = android.os.Handler(ht.looper)
    private var cam: Camera? = null
    @Volatile var front = true
    @Volatile var enabled = true            // 关摄像头 = 不再发帧（相机继续开着，重新打开立刻有画面）
    private var seq = 0
    private var lastMs = 0L
    private var localN = 0
    private var camOri = 0
    private var curW = 0
    private var curH = 0
    @Volatile private var curTier = 0
    private var tex: SurfaceTexture? = null
    private val jpg = ByteArrayOutputStream(256 * 1024)

    /** 异步打开：失败（被占用 / 设备不支持）时调 onFail */
    fun start() { h.post { try { open() } catch (e: Throwable) { closeCam(); onFail() } } }

    fun stop() {
        h.post {
            closeCam()
            try { tex?.release() } catch (ignored: Exception) { }
            tex = null
            ht.quitSafely()
        }
    }

    fun flip() { h.post { front = !front; closeCam(); try { open() } catch (e: Throwable) { closeCam(); onFail() } } }

    /** 通话中换画质档位：重开相机套用新分辨率 / 帧率 */
    fun retier() { h.post { if (cam != null && curTier != tierIdx()) { closeCam(); try { open() } catch (e: Throwable) { closeCam(); onFail() } } } }

    private fun closeCam() {
        try { cam?.setPreviewCallback(null); cam?.stopPreview() } catch (ignored: Exception) { }
        try { cam?.release() } catch (ignored: Exception) { }
        cam = null
    }

    private fun pickId(): Int {
        val info = Camera.CameraInfo()
        val want = if (front) Camera.CameraInfo.CAMERA_FACING_FRONT else Camera.CameraInfo.CAMERA_FACING_BACK
        for (i in 0 until Camera.getNumberOfCameras()) { Camera.getCameraInfo(i, info); if (info.facing == want) return i }
        return 0
    }

    private fun open() {
        val id = pickId()
        val c = Camera.open(id)
        try {
            val info = Camera.CameraInfo(); Camera.getCameraInfo(id, info)
            camOri = info.orientation
            val ti = tierIdx()
            val t = VideoTiers.of(ti)
            val p = c.parameters
            // 选最接近档位目标（按像素面积，宽 > 高）的预览尺寸
            val sizes = p.supportedPreviewSizes.filter { it.width >= it.height }
            val sz = if (t.native) sizes.maxByOrNull { it.width.toLong() * it.height }      // 极致无损：原生（最大）分辨率
                else sizes.minByOrNull { Math.abs(it.width.toLong() * it.height - t.w.toLong() * t.h) }
            if (sz != null) p.setPreviewSize(sz.width, sz.height)
            p.previewFormat = ImageFormat.NV21
            val ranges = p.supportedPreviewFpsRange
            val r = ranges.filter { it[Camera.Parameters.PREVIEW_FPS_MAX_INDEX] >= t.fps * 1000 }.minByOrNull { it[Camera.Parameters.PREVIEW_FPS_MAX_INDEX] }
                ?: ranges.maxByOrNull { it[Camera.Parameters.PREVIEW_FPS_MAX_INDEX] }
            if (r != null) p.setPreviewFpsRange(r[Camera.Parameters.PREVIEW_FPS_MIN_INDEX], r[Camera.Parameters.PREVIEW_FPS_MAX_INDEX])
            if (p.supportedFocusModes.contains(Camera.Parameters.FOCUS_MODE_CONTINUOUS_VIDEO)) p.focusMode = Camera.Parameters.FOCUS_MODE_CONTINUOUS_VIDEO
            c.parameters = p
            val ps = c.parameters.previewSize
            curW = ps.width; curH = ps.height; curTier = ti
            if (tex == null) tex = SurfaceTexture(0)
            c.setPreviewTexture(tex)                      // 不显示预览，只要回调
            c.setPreviewCallback { data, _ -> handle(data) }
            c.startPreview()
            cam = c
        } catch (e: Throwable) { try { c.release() } catch (ignored: Exception) { }; throw e }
    }

    private fun rotation(): Int {
        val rot = try {
            (Link.app.getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.rotation
        } catch (e: Exception) { Surface.ROTATION_0 }
        val deg = when (rot) { Surface.ROTATION_90 -> 90; Surface.ROTATION_180 -> 180; Surface.ROTATION_270 -> 270; else -> 0 }
        return if (front) (camOri + deg) % 360 else (camOri - deg + 360) % 360
    }

    private fun handle(data: ByteArray) {
        if (!enabled) return
        val t = VideoTiers.of(curTier)
        val now = System.currentTimeMillis()
        if (now - lastMs < 1000L / t.fps - 4) return        // 限帧
        lastMs = now
        val w = curW; val hh = curH
        if (data.size < w * hh * 3 / 2) return
        try {
            jpg.reset()
            YuvImage(data, ImageFormat.NV21, w, hh, null).compressToJpeg(Rect(0, 0, w, hh), t.quality, jpg)
            val bytes = jpg.toByteArray()
            if (bytes.size > VideoCodec.MAX_JPEG) return
            val rot = rotation()
            onFrame(VideoCodec.pack(seq++, curTier, rot, w, hh, bytes, bytes.size))
            if (++localN % 4 == 0) {
                val o = BitmapFactory.Options().apply { inSampleSize = 4 }
                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
                if (bmp != null) {
                    val out = if (rot == 0 && !front) bmp else Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply {
                        postRotate(rot.toFloat()); if (front) postScale(-1f, 1f)      // 自拍小窗按镜子显示（只是本地预览，发出去的不镜像）
                    }, true)
                    if (out !== bmp) bmp.recycle()
                    onLocal(out)
                }
            }
        } catch (ignored: Throwable) { }
    }
}
