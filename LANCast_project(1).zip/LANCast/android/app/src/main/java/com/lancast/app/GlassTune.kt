package com.lancast.app

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.os.Build

/**
 * 流光玻璃的可调参数（DIY）。保存在 Link.prefs（键 gt_xxx），滑动时实时生效：
 * 玻璃折射着色器每次绘制都会读取这里的值，极光背景在参数变化时重建。
 */
object GT {
    class P(val key: String, val label: String, val min: Float, val max: Float, val def: Float, val agsl: Boolean = false, val unit: String = "") {
        var v = def
    }

    // 默认值 = 「清透液态玻璃」：折射适中、色散很淡、完整透出背景并提一点饱和度、只留一层薄雾
    val strength = P("strength", "折射强度", 0f, 2.5f, 1.0f, true)
    val bevel = P("bevel", "边缘斜面宽度", 4f, 36f, 20f, true, "dp")
    val lens = P("lens", "中心放大", 0f, 0.2f, 0.04f, true)
    val disp = P("disp", "色散（彩边）", 0f, 0.5f, 0.16f, true)
    val blur = P("blur", "磨砂模糊", 0f, 1f, 0.40f, true)
    val sat = P("sat", "透出背景饱和度", 0.6f, 1.8f, 1.25f, true)
    val bright = P("bright", "透出背景亮度", 0.2f, 1.6f, 0.96f, true)
    val frost = P("frost", "磨砂雾面", 0f, 1f, 0.28f)
    val spec = P("spec", "边缘高光", 0f, 2f, 1.00f)
    val tint = P("tint", "主按钮着色", 0f, 1f, 0.50f, true)
    val aurora = P("aurora", "极光亮度", 0.2f, 1.6f, 1.00f)

    val all = listOf(strength, bevel, lens, disp, blur, sat, bright, frost, spec, tint, aurora)

    /** 默认参数版本：升版本会让所有人的 DIY 值回到新默认值一次（否则旧的极限值会盖掉新默认） */
    private const val VER = 2

    fun load(p: android.content.SharedPreferences) {
        if (p.getInt("gt_ver", 0) < VER) {
            reset(); save(p)
            p.edit().putInt("gt_ver", VER).apply()
        } else {
            for (x in all) x.v = p.getFloat("gt_" + x.key, x.def).coerceIn(x.min, x.max)
        }
    }

    fun save(p: android.content.SharedPreferences) {
        val e = p.edit(); for (x in all) e.putFloat("gt_" + x.key, x.v); e.apply()
    }

    fun reset() { for (x in all) x.v = x.def }

    /** 参数变化后：重建极光 + 让所有玻璃重画 */
    fun apply() {
        Glass.aurora?.get()?.let { it.rebuild(); it.invalidate(); it.snapNow() }
        Glass.refresh()
    }
}

/** 底部弹出的「玻璃调节」面板：不遮暗背景，改一项，后面的真实界面立刻跟着变 */
object GlassTune {
    fun show(ctx: Context) {
        val dlg = Dialog(ctx, android.R.style.Theme_Translucent_NoTitleBar)
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(ctx.px(18), ctx.px(14), ctx.px(18), ctx.px(18))
            background = ctx.shape(Color.WHITE, 28f, C.CARD_LINE, 1f)
        }
        box.addView(TextView(ctx).apply {
            text = "玻璃调节（实时预览）"
            textSize = 17f; typeface = Typeface.DEFAULT_BOLD; setTextColor(C.INK)
        })
        box.addView(TextView(ctx).apply {
            text = if (Build.VERSION.SDK_INT >= 33) "拖动滑块，后面的界面立即变化" else "此设备低于 Android 13：折射类参数不生效，其余可调"
            textSize = 12f; setTextColor(C.SUB)
            setPadding(0, ctx.px(2), 0, ctx.px(8))
        })
        val list = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        val vals = HashMap<GT.P, TextView>()
        val bars = HashMap<GT.P, SeekBar>()
        fun fmt(p: GT.P) = String.format(java.util.Locale.US, if (p.max <= 3f) "%.2f" else "%.0f", p.v) + p.unit
        for (p in GT.all) {
            val row = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL; setPadding(0, ctx.px(6), 0, 0) }
            val head = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
            head.addView(TextView(ctx).apply {
                text = p.label + if (p.agsl && Build.VERSION.SDK_INT < 33) "（需 Android 13+）" else ""
                textSize = 13f; setTextColor(C.INK)
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val tv = TextView(ctx).apply { text = fmt(p); textSize = 12f; setTextColor(C.SUB) }
            vals[p] = tv
            head.addView(tv)
            row.addView(head)
            val sb = SeekBar(ctx).apply {
                max = 200
                progress = Math.round((p.v - p.min) / (p.max - p.min) * 200f)
                progressTintList = android.content.res.ColorStateList.valueOf(C.PRIMARY)
                thumbTintList = android.content.res.ColorStateList.valueOf(C.PRIMARY)
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar, pr: Int, user: Boolean) {
                        p.v = p.min + (p.max - p.min) * pr / 200f
                        tv.text = fmt(p)
                        if (user) GT.apply()
                    }
                    override fun onStartTrackingTouch(s: SeekBar) {}
                    override fun onStopTrackingTouch(s: SeekBar) { GT.save(Link.prefs) }
                })
            }
            bars[p] = sb
            row.addView(sb)
            list.addView(row)
        }
        val sv = ScrollView(ctx).apply { addView(list) }
        box.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        val btns = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, ctx.px(12), 0, 0) }
        fun btn(t: String, filled: Boolean, onClick: () -> Unit) = TextView(ctx).apply {
            text = t; textSize = 14f; gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD
            setTextColor(if (filled) Color.WHITE else C.PRIMARY)
            background = if (filled) ctx.shape(C.PRIMARY, 14f) else ctx.shape(Color.WHITE, 14f, C.PRIMARY, 1.2f)
            setOnClickListener { onClick() }
        }
        btns.addView(btn("恢复默认", false) {
            GT.reset(); GT.save(Link.prefs)
            for (p in GT.all) { bars[p]?.progress = Math.round((p.v - p.min) / (p.max - p.min) * 200f); vals[p]?.text = fmt(p) }
            GT.apply()
        }, LinearLayout.LayoutParams(0, ctx.px(46), 1f))
        btns.addView(btn("完成", true) { dlg.dismiss() }, LinearLayout.LayoutParams(0, ctx.px(46), 1f).apply { leftMargin = ctx.px(12) })
        box.addView(btns)

        dlg.setContentView(box)
        dlg.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            setGravity(Gravity.BOTTOM)
            val h = (ctx.resources.displayMetrics.heightPixels * 0.55f).toInt()
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, h)
            attributes = attributes.apply { y = ctx.px(8) }
        }
        dlg.show()
    }
}
