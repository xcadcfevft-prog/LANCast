package com.lancast.app

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.app.Activity
import android.view.WindowManager
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.core.view.WindowInsetsCompat

/**
 * 全屏通话页（仿微信）：暗色渐变背景 / 圆角头像 + 名字 / 底部状态文字 / 三个圆形按钮（麦克风 · 挂断 · 扬声器）。
 * 来电时变成「拒绝（红）+ 接听（绿）」。左上角按钮缩回聊天页顶部的通话条，点通话条可再展开。
 * 视频通话接通后同样用本页：背景变透明露出下面的视频画面（对方画面全屏 + 自拍小窗），
 * 顶部是名字 / 时长，右上角画质 / 翻转，底部是 麦克风 · 摄像头 · 挂断 · 扬声器 四个圆形按钮，风格与语音通话完全一致。
 */
class CallScreen(
    private val ctx: Context,
    private val onAnswer: () -> Unit,
    private val onChanged: () -> Unit,
    private val onTier: () -> Unit = { }
) {
    val view = FrameLayout(ctx)
    var minimized = false
        private set
    var isEnded = false
        private set

    private val h = Handler(Looper.getMainLooper())
    private var lastPh = "idle"
    private var lastName = "对方"
    private var lastPid: String? = null
    private fun px(v: Int) = ctx.px(v)
    private val voiceBg = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.parseColor("#2B2420"), Color.parseColor("#0B0908")))
    /** 视频通话中：顶部 / 底部各一层半透明黑色渐变，保证白色文字和按钮在任何画面上都看得清 */
    private val videoBg = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(Color.TRANSPARENT, Color.TRANSPARENT)).apply {
        setColors(intArrayOf(Color.parseColor("#99000000"), Color.TRANSPARENT, Color.TRANSPARENT, Color.parseColor("#B3000000")), floatArrayOf(0f, 0.22f, 0.68f, 1f))
    }

    private val avatar = TextView(ctx)
    private val nameTv = TextView(ctx)
    private val subTv = TextView(ctx)
    private val statusTv = TextView(ctx)
    private val row = LinearLayout(ctx)
    private val mic: Btn
    private val end: Btn
    private val spk: Btn
    private val ans: Btn
    private val cam: Btn
    private val vTop = LinearLayout(ctx)
    private val vName = TextView(ctx)
    private val vTime = TextView(ctx)
    private val chips = LinearLayout(ctx)
    private val tierChip = TextView(ctx)
    private val flipChip = TextView(ctx)
    private val min: FrameLayout
    private var videoMode = false

    private class Btn(val box: LinearLayout, val disc: FrameLayout, val label: TextView) { var kind = "" }

    private fun btn(onClick: () -> Unit): Btn {
        val disc = FrameLayout(ctx).apply { isClickable = true; setOnClickListener { onClick() } }
        val label = TextView(ctx).apply { textSize = 13f; setTextColor(Color.WHITE); gravity = Gravity.CENTER }
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            addView(disc, LinearLayout.LayoutParams(px(68), px(68)))
            addView(label, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = px(10) })
        }
        row.addView(box, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        return Btn(box, disc, label)
    }

    private fun style(b: Btn, kind: String, bg: Int, tint: Int, label: String) {
        b.disc.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(bg) }
        if (b.kind != kind) {
            b.kind = kind
            b.disc.removeAllViews()
            b.disc.addView(IconView(ctx, kind, tint, kind.startsWith("hangup"), if (kind.startsWith("hangup")) 1.2f else 1.8f), FrameLayout.LayoutParams(px(32), px(32), Gravity.CENTER))
        }
        b.label.text = label
    }

    init {
        view.visibility = View.GONE
        view.isClickable = true                                   // 盖住下面的聊天页，不让点击穿透
        view.background = voiceBg

        min = FrameLayout(ctx).apply {
            isClickable = true; setOnClickListener { minimize() }
            addView(IconView(ctx, "minimize", Color.WHITE, false, 1.8f), FrameLayout.LayoutParams(px(26), px(26), Gravity.CENTER))
        }
        view.addView(min, FrameLayout.LayoutParams(px(48), px(48), Gravity.TOP or Gravity.START).apply { topMargin = px(20); marginStart = px(14) })

        // 视频通话中：顶部居中 名字 + 时长
        vName.apply { textSize = 17f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        vTime.apply { textSize = 13f; setTextColor(Color.parseColor("#CCFFFFFF")); gravity = Gravity.CENTER }
        vTop.apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; visibility = View.GONE
            addView(vName, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
            addView(vTime, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = px(2) })
        }
        view.addView(vTop, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = px(24); marginStart = px(70); marginEnd = px(70) })
        fun chip(t: TextView, label: String, f: () -> Unit) = t.apply {
            text = label; textSize = 12.5f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(px(12), px(6), px(12), px(6))
            background = GradientDrawable().apply { cornerRadius = px(16).toFloat(); setColor(Color.parseColor("#55000000")) }
            isClickable = true; setOnClickListener { f() }
        }
        chip(tierChip, "画质") { onTier() }
        chip(flipChip, "翻转") { VoiceCall.flipCamera() }
        chips.apply {
            orientation = LinearLayout.HORIZONTAL; visibility = View.GONE
            addView(tierChip, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
            addView(flipChip, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { marginStart = px(8) })
        }
        view.addView(chips, FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.TOP or Gravity.END).apply { topMargin = px(28); marginEnd = px(14) })

        avatar.apply {
            gravity = Gravity.CENTER; textSize = 42f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply { cornerRadius = px(14).toFloat(); setColor(Color.parseColor("#4A5A6A")) }
        }
        nameTv.apply { textSize = 26f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END }
        subTv.apply { textSize = 12f; setTextColor(Color.parseColor("#99FFFFFF")); gravity = Gravity.CENTER }
        val mid = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            addView(avatar, LinearLayout.LayoutParams(px(112), px(112)))
            addView(nameTv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = px(18) })
            addView(subTv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = px(6) })
        }
        view.addView(mid, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER).apply { bottomMargin = px(70); marginStart = px(24); marginEnd = px(24) })

        statusTv.apply { textSize = 17f; setTextColor(Color.parseColor("#E6FFFFFF")); gravity = Gravity.CENTER }
        view.addView(statusTv, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM).apply { bottomMargin = px(190) })

        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        mic = btn { VoiceCall.mute(!VoiceCall.st.muted) }
        cam = btn { VoiceCall.camera(!VoiceCall.st.camOn) }
        end = btn { if (VoiceCall.st.phase == "ringing") VoiceCall.decline() else VoiceCall.hangup() }
        spk = btn { VoiceCall.speaker(!VoiceCall.st.speakerOn) }
        ans = btn { onAnswer() }
        view.addView(row, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM).apply { bottomMargin = px(48); marginStart = px(24); marginEnd = px(24) })

        // 状态栏 / 导航栏 / 刘海：内容躲开
        ViewCompat.setOnApplyWindowInsetsListener(view) { v, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            v.setPadding(b.left, b.top, b.right, b.bottom)
            insets
        }
    }

    private var barsHidden = false
    /** 通话页盖住聊天页时：状态栏 / 导航栏收起、刘海区也铺满 = 真正的全屏（边缘滑动才临时露出）；收起通话页时还原 */
    private fun setFullBars(on: Boolean) {
        if (barsHidden == on) return
        val act = ctx as? Activity ?: return
        barsHidden = on
        val w = act.window
        WindowCompat.setDecorFitsSystemWindows(w, !on)
        val c = WindowCompat.getInsetsController(w, w.decorView)
        val lp = w.attributes
        if (on) {
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            c.hide(WindowInsetsCompat.Type.systemBars())
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        } else {
            c.show(WindowInsetsCompat.Type.systemBars())
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT
        }
        w.attributes = lp
    }

    fun minimize() { minimized = true; onChanged() }
    fun expand() { minimized = false; onChanged() }

    /** 通话状态变化 / 每秒刷新时调用；返回 true = 本页正盖在聊天页上（通话条要收起） */
    fun refresh(): Boolean {
        val st = VoiceCall.st
        val ph = st.phase
        if (ph != "idle") {
            isEnded = false; h.removeCallbacksAndMessages(null)
            lastName = Link.pairs().firstOrNull { it.id == st.peerId }?.name ?: "对方"
            if (st.peerId != null) lastPid = st.peerId
        } else {
            minimized = false
            if (lastPh != "idle" && st.reason.isNotEmpty() && (lastPh == "calling" || st.reason.startsWith("对方"))) {
                isEnded = true                                          // 对方拒绝 / 没接 / 挂断：停留一会儿再收起
                h.removeCallbacksAndMessages(null)
                h.postDelayed({ isEnded = false; view.visibility = View.GONE; onChanged() }, 1800)
            }
        }
        lastPh = ph
        val show = isEnded || (ph != "idle" && !minimized)
        val vid = !isEnded && ph == "active" && st.video       // 视频通话中：背景透明，露出下面的视频画面
        if (vid != videoMode) {
            videoMode = vid
            view.background = if (vid) videoBg else voiceBg
            view.isClickable = !vid                            // 视频中空白处的触摸要穿透给下面的视频区（双击 / 捏合 / 拖动）
        }
        view.visibility = if (show) View.VISIBLE else View.GONE
        setFullBars(show)
        if (!show) return false

        avatar.visibility = if (vid) View.GONE else View.VISIBLE
        subTv.visibility = if (vid) View.GONE else View.VISIBLE
        nameTv.visibility = if (vid) View.GONE else View.VISIBLE
        statusTv.visibility = if (vid) View.GONE else View.VISIBLE
        vTop.visibility = if (vid) View.VISIBLE else View.GONE
        chips.visibility = if (vid) View.VISIBLE else View.GONE
        if (vid) {
            vName.text = lastName
            val vs = ((System.currentTimeMillis() - st.since) / 1000).coerceAtLeast(0)
            vTime.text = "%02d:%02d · %s".format(vs / 60, vs % 60, VideoTiers.of(st.tier).name) + (if (st.muted) " · 已静音" else "")
        }
        val pid = VoiceCall.st.peerId ?: lastPid
        val abmp = if (pid != null) Avatar.peerRounded(ctx, pid, px(224), px(14).toFloat()) else null
        if (abmp != null) { avatar.text = ""; avatar.background = android.graphics.drawable.BitmapDrawable(ctx.resources, abmp); avatar.setOnClickListener { Avatar.show(ctx, Avatar.viewPeer(ctx, pid!!)) } }
        else {
            avatar.setOnClickListener(null); avatar.isClickable = false
            avatar.text = lastName.trim().let { if (it.isEmpty()) "?" else String(Character.toChars(it.codePointAt(0))) }
            avatar.background = GradientDrawable().apply { cornerRadius = px(14).toFloat(); setColor(Color.parseColor("#4A5A6A")) }
        }
        nameTv.text = lastName
        subTv.text = if (st.video) "视频通话" else "无损 PCM · 48 kHz / 16 bit"
        val secs = ((System.currentTimeMillis() - st.since) / 1000).coerceAtLeast(0)
        statusTv.text = when {
            isEnded -> st.reason
            ph == "calling" -> "正在等待对方接受邀请…"
            ph == "ringing" -> if (st.video) "邀请你视频通话" else "邀请你语音通话"
            else -> "%02d:%02d".format(secs / 60, secs % 60)
        }
        val white = Color.WHITE
        val dim = Color.parseColor("#33FFFFFF")
        val ring = ph == "ringing" && !isEnded
        cam.box.visibility = if (vid) View.VISIBLE else View.GONE
        mic.box.visibility = if (ring) View.GONE else View.VISIBLE
        spk.box.visibility = if (ring) View.GONE else View.VISIBLE
        ans.box.visibility = if (ring) View.VISIBLE else View.GONE
        style(mic, if (st.muted) "micoff" else "mic", if (st.muted) dim else white, if (st.muted) white else Color.parseColor("#222222"), if (st.muted) "麦克风已关" else "麦克风已开")
        style(spk, if (st.speakerOn) "speaker" else "speakeroff", if (st.speakerOn) white else dim, if (st.speakerOn) Color.parseColor("#222222") else white, if (st.speakerOn) "扬声器已开" else "扬声器已关")
        style(cam, if (st.camOn) "cam" else "camoff", if (st.camOn) white else dim, if (st.camOn) Color.parseColor("#222222") else white, if (st.camOn) "摄像头已开" else "摄像头已关")
        style(end, "hangup", Color.parseColor("#DD4B4B"), white, if (ring) "拒绝" else if (ph == "calling" || isEnded) "取消" else "挂断")
        style(ans, "hangup2", Color.parseColor("#2BB86A"), white, "接听")
        row.alpha = if (isEnded) 0.45f else 1f
        row.isEnabled = !isEnded
        for (b in listOf(mic, cam, end, spk, ans)) b.disc.isClickable = !isEnded
        return true
    }
}
