package com.lancast.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.IBinder
import android.os.PowerManager
import androidx.core.content.ContextCompat
import com.frostwire.jlibtorrent.Priority
import com.frostwire.jlibtorrent.Sha1Hash
import com.frostwire.jlibtorrent.TorrentHandle
import com.frostwire.jlibtorrent.TorrentInfo
import java.io.File
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/** 种子里的一个（非补位）文件。index 是它在 libtorrent 里的文件下标（含补位文件），offset 是在整个种子里的字节偏移 */
class BtFile(val index: Int, val path: String, val size: Long, val offset: Long) {
    val name: String get() = path.substringAfterLast('/')
}

/** 一个下载任务。同时充当“分片来源”，让本地流服务器能问 libtorrent 某个分片下完没、并让它优先下载 */
class BtTask(val hash: String, val torrent: ByteArray, @Volatile var dir: File) : PieceSource {
    val ti: TorrentInfo = TorrentInfo.bdecode(torrent)
    val name: String = ti.name().ifEmpty { hash }
    val fileCount: Int = ti.numFiles()
    val files: List<BtFile>
    val pads: Set<Int>
    private val pl: Int = ti.pieceLength()
    private val np: Int = ti.numPieces()
    val selected: MutableSet<Int> = java.util.Collections.synchronizedSet(LinkedHashSet())

    @Volatile var handle: TorrentHandle? = null
    @Volatile var paused = false
    @Volatile var done = false
    @Volatile var error = ""
    @Volatile var state = "queued"       // queued / checking / downloading / paused / done / error
    @Volatile var doneBytes = 0L
    @Volatile var wantedBytes = 0L
    @Volatile var down = 0
    @Volatile var up = 0
    @Volatile var peers = 0
    @Volatile var seeds = 0
    val streams = AtomicInteger()

    init {
        val fs = ti.files()
        val l = ArrayList<BtFile>()
        val p = HashSet<Int>()
        var off = 0L
        for (i in 0 until fileCount) {
            val path = fs.filePath(i)
            val size = fs.fileSize(i)
            if (MagnetCore.isPadding(path)) p.add(i) else l.add(BtFile(i, path, size, off))
            off += size
        }
        files = l
        pads = p
    }

    val totalBytes: Long get() = files.sumOf { it.size }
    val selectedBytes: Long get() = files.filter { it.index in selected }.sumOf { it.size }
    val progress: Float get() = if (done) 1f else if (wantedBytes > 0) (doneBytes.toFloat() / wantedBytes).coerceIn(0f, 1f) else 0f
    val active: Boolean get() = !paused && !done

    fun file(index: Int): BtFile? = files.firstOrNull { it.index == index }
    fun localFile(f: BtFile): File = File(dir, f.path)
    /** 文件在磁盘上已经完整可读（任务已完成，且大小对得上） */
    fun fileComplete(f: BtFile): Boolean = done && localFile(f).let { it.isFile && it.length() == f.size }

    override val pieceLength: Int get() = pl
    override val numPieces: Int get() = np
    override fun have(piece: Int): Boolean = done || (try { handle?.havePiece(piece) ?: false } catch (_: Throwable) { false })
    override fun setDeadline(piece: Int, ms: Int) { try { handle?.setPieceDeadline(piece, ms) } catch (_: Throwable) {} }
    override fun resetDeadline(piece: Int) {
        // 不同版本的 jlibtorrent 都有这个方法，用反射以防万一；取不到就算了（截止时间在分片下完后会自动清除）
        try { resetM?.invoke(handle ?: return, piece) } catch (_: Throwable) {}
    }

    companion object {
        private val resetM = try { TorrentHandle::class.java.getMethod("resetPieceDeadline", Int::class.javaPrimitiveType) } catch (_: Throwable) { null }
    }
}

/**
 * 磁力下载引擎：基于 jlibtorrent（和磁力解析共用同一个会话）。
 *  - 任务列表持久化到 filesDir/bt，重启后自动恢复（libtorrent 会校验磁盘上已有的数据，从断点继续）
 *  - 边下边播：本地 127.0.0.1 HTTP 服务（Range），播放器读到哪就把哪附近的分片调成最高优先级
 *  - 任务全部完成 / 暂停后自动停止前台服务
 */
object BtEngine {
    private lateinit var app: Context
    val ctx: Context get() = app
    private var inited = false
    private val worker = Executors.newSingleThreadExecutor { r -> Thread(r, "bt-worker").apply { isDaemon = true } }

    /** 引擎操作可能要启动 libtorrent 会话（慢），界面里一律丢到后台线程做 */
    fun post(r: () -> Unit) { worker.execute { try { r() } catch (_: Throwable) {} } }
    private val tasks = LinkedHashMap<String, BtTask>()
    private var tick: ScheduledExecutorService? = null
    private var tickN = 0
    private val server = StreamServer({ h, i -> target(h, i) })

    private val btDir: File get() = File(app.filesDir, "bt").apply { mkdirs() }
    val defaultDir: File get() = File(app.getExternalFilesDir(null) ?: app.filesDir, "磁力下载").apply { mkdirs() }

    fun init(ctx: Context) {
        val toStart = ArrayList<BtTask>()
        synchronized(this) {
            if (inited) return
            app = ctx.applicationContext
            inited = true
            val sf = File(btDir, "state.txt")
            val saved = try { BtState.decode(sf.readText()) } catch (_: Throwable) { emptyList() }
            for (s in saved) {
                try {
                    val t = BtTask(s.hash, File(btDir, s.hash + ".torrent").readBytes(), File(s.dir))
                    t.selected.addAll(s.selected ?: t.files.map { it.index })
                    t.paused = s.paused; t.done = s.done
                    t.state = if (t.done) "done" else if (t.paused) "paused" else "queued"
                    tasks[s.hash] = t
                    if (t.active) toStart.add(t)
                } catch (_: Throwable) {}
            }
        }
        for (t in toStart) start(t)          // 启动 libtorrent 会话比较慢，放在锁外面，免得界面读任务列表时被卡住
    }

    @Synchronized fun list(): List<BtTask> = tasks.values.toList()
    @Synchronized fun get(hash: String): BtTask? = tasks[hash]
    fun hasActive(): Boolean = synchronized(this) { tasks.values.any { it.active } }

    private fun save() {
        try {
            val text = synchronized(this) {
                BtState.encode(tasks.values.map { t ->
                    val all = t.files.size == t.selected.size
                    SavedTask(t.hash, t.dir.absolutePath, t.paused, if (all) null else t.selected.toList(), t.done)
                })
            }
            File(btDir, "state.txt").writeText(text)
        } catch (_: Throwable) {}
    }

    /** 加入下载。selected = null 表示全部文件；已存在的任务会把新选的文件并进去 */
    fun add(ctx: Context, hash: String, torrent: ByteArray, selected: Collection<Int>?): BtTask {
        init(ctx)
        val old = get(hash)
        if (old != null) {
            if (selected != null) setSelected(old, old.selected.toSet() + selected)
            if (old.paused) resume(old) else if (!old.done) ensureRunning(old)
            return old
        }
        val dir = defaultDir
        val t = BtTask(hash, torrent, dir)
        t.selected.addAll(selected ?: t.files.map { it.index })
        if (t.selected.isEmpty()) throw IllegalArgumentException("没有选中任何文件")
        val need = t.selectedBytes
        val free = dir.usableSpace
        if (free < need + (50L shl 20)) throw IllegalStateException("存储空间不足：需要 ${MagnetCore.formatSize(need)}，剩余 ${MagnetCore.formatSize(free)}")
        File(btDir, "$hash.torrent").writeBytes(torrent)
        synchronized(this) { tasks[hash] = t }
        start(t)
        return t
    }

    private fun prios(t: BtTask): Array<Priority> =
        Array(t.fileCount) { i -> if (i in t.selected || i in t.pads) Priority.NORMAL else Priority.IGNORE }

    /** 默认加入的种子会被 libtorrent 的“自动排队”管理（同时只下 3 个）；这里取消它，由我们自己决定谁在下载 */
    private fun forceStart(th: TorrentHandle) {
        try {
            val flag = Class.forName("com.frostwire.jlibtorrent.TorrentFlags").getField("AUTO_MANAGED").get(null)
            th.javaClass.methods.firstOrNull { it.name == "unsetFlags" && it.parameterTypes.size == 1 }?.invoke(th, flag)
        } catch (_: Throwable) {}
        try { th.resume() } catch (_: Throwable) {}
    }

    private fun attach(t: BtTask, th: TorrentHandle) {
        t.handle = th
        try { th.prioritizeFiles(prios(t)) } catch (_: Throwable) {}
        if (t.paused) { try { th.pause() } catch (_: Throwable) {} } else forceStart(th)
    }

    /** 确保任务已经在会话里。注意：不能对已存在的种子再调 download()，它会把文件优先级重置成“全部下载” */
    private fun ensureRunning(t: BtTask) {
        try {
            val s = MagnetEngine.session()
            val th = s.find(Sha1Hash(t.hash))
            if (th != null && th.isValid()) { if (t.handle == null) attach(t, th) else { try { t.handle?.resume() } catch (_: Throwable) {} } }
            else { t.handle = null; s.download(t.ti, t.dir) }
            if (t.state == "paused" || t.state == "queued" || t.state == "error") t.state = "checking"
            t.error = ""
        } catch (e: Throwable) {
            t.error = e.message ?: e.javaClass.simpleName; t.state = "error"
        }
        ensureTick()
        TorrentService.start()
    }

    fun start(t: BtTask) {
        t.paused = false; t.done = false
        ensureRunning(t)
        save()
    }

    fun pause(t: BtTask) {
        t.paused = true; t.down = 0; t.up = 0; t.state = "paused"
        try { t.handle?.pause() } catch (_: Throwable) {}
        save(); TorrentService.refresh()
    }

    fun resume(t: BtTask) {
        if (t.done) return
        t.paused = false
        if (t.handle != null) { t.state = "checking"; try { t.handle?.resume() } catch (_: Throwable) {}; ensureTick(); TorrentService.start() } else ensureRunning(t)
        save()
    }

    fun setSelected(t: BtTask, sel: Set<Int>) {
        val grew = sel.any { it !in t.selected }
        t.selected.clear(); t.selected.addAll(sel.filter { i -> t.files.any { it.index == i } })
        if (t.done && grew) { start(t); return }
        try { t.handle?.prioritizeFiles(prios(t)) } catch (_: Throwable) {}
        save()
    }

    fun remove(t: BtTask, deleteFiles: Boolean) {
        synchronized(this) { tasks.remove(t.hash) }
        try {
            val s = MagnetEngine.peek()
            val th = t.handle ?: s?.find(Sha1Hash(t.hash))
            if (s != null && th != null && th.isValid()) s.remove(th)
        } catch (_: Throwable) {}
        t.handle = null
        try { File(btDir, t.hash + ".torrent").delete() } catch (_: Throwable) {}
        if (deleteFiles) deleteData(t)
        save()
        if (!hasActive()) { stopTick(); TorrentService.stop() }
    }

    /** 只删种子里列出的文件，以及因此变空的文件夹；绝不递归删除整个目录 */
    private fun deleteData(t: BtTask) {
        val root = try { t.dir.canonicalFile } catch (_: Throwable) { return }
        val dirs = HashSet<File>()
        for (i in 0 until t.fileCount) {
            val rel = try { t.ti.files().filePath(i) } catch (_: Throwable) { continue }
            val f = try { File(root, rel).canonicalFile } catch (_: Throwable) { continue }
            if (!f.path.startsWith(root.path + File.separator)) continue
            try { f.delete() } catch (_: Throwable) {}
            var d = f.parentFile
            while (d != null && d != root && d.path.startsWith(root.path + File.separator)) { dirs.add(d); d = d.parentFile }
        }
        try { File(root, ".${t.hash}.parts").delete() } catch (_: Throwable) {}
        for (d in dirs.sortedByDescending { it.path.length }) try { d.delete() } catch (_: Throwable) {}   // 非空会删除失败，正好
    }

    /* ───────────── 边下边播 ───────────── */
    private fun target(hash: String, index: Int): StreamTarget? {
        val t = get(hash) ?: return null
        val f = t.file(index) ?: return null
        return StreamTarget(f.name, f.size, f.offset, t.localFile(f), t, if (t.done) 0 else 200,
            { t.streams.incrementAndGet() }, { t.streams.decrementAndGet() })
    }

    /**
     * 给播放器的地址：文件已经下完就直接给本地文件；否则给本地流地址（会自动把该文件加入下载并开始）。
     * 返回 Pair(uri, 是否本地文件)
     */
    fun playUri(t: BtTask, index: Int): Pair<String, Boolean> {
        val f = t.file(index) ?: throw IllegalArgumentException("文件不存在")
        if (t.fileComplete(f)) return Pair(android.net.Uri.fromFile(t.localFile(f)).toString(), true)
        if (index !in t.selected) setSelected(t, t.selected.toSet() + index)
        if (t.paused) resume(t) else if (!t.done) ensureRunning(t)
        else start(t)                       // 任务标记为完成但文件缺失：重新校验 / 下载
        return Pair(server.url(t.hash, index, f.name), false)
    }

    /** 本机 HTTP 地址（给外部播放器用；不改变任务状态） */
    fun httpUrl(t: BtTask, f: BtFile): String = server.url(t.hash, f.index, f.name)

    /* ───────────── 后台轮询 ───────────── */
    @Synchronized private fun ensureTick() {
        if (tick != null) return
        tick = Executors.newSingleThreadScheduledExecutor { r -> Thread(r, "bt-tick").apply { isDaemon = true } }.also {
            it.scheduleWithFixedDelay({ try { poll() } catch (_: Throwable) {} }, 100, 500, TimeUnit.MILLISECONDS)
        }
    }

    @Synchronized private fun stopTick() { tick?.shutdownNow(); tick = null }

    private fun poll() {
        val list = list()
        val s = MagnetEngine.peek()
        var changed = false
        for (t in list) {
            if (t.done || t.paused || s == null) continue
            var th = t.handle
            if (th == null || !th.isValid()) {
                th = try { s.find(Sha1Hash(t.hash)) } catch (_: Throwable) { null }
                if (th == null || !th.isValid()) continue
                attach(t, th)
            }
            val st = th.status()
            t.doneBytes = st.totalWantedDone(); t.wantedBytes = st.totalWanted()
            t.down = st.downloadPayloadRate(); t.up = st.uploadPayloadRate()
            t.peers = st.numPeers(); t.seeds = st.numSeeds()
            val sn = st.state().name
            t.state = if (sn.startsWith("CHECKING") || sn == "ALLOCATING") "checking" else "downloading"
            if (st.isFinished() && t.wantedBytes > 0 && t.doneBytes >= t.wantedBytes) {
                t.done = true; t.state = "done"; t.down = 0; t.up = 0; t.peers = 0
                try { s.remove(th) } catch (_: Throwable) {}          // 文件留在原地，只是不再做种，省电
                t.handle = null
                changed = true
                TorrentService.notifyDone(t.name)
            }
        }
        if (changed) save()
        if (++tickN % 2 == 0) TorrentService.refresh()
        if (!hasActive() && list.none { it.streams.get() > 0 }) { stopTick(); TorrentService.stop() }
    }

    fun notificationText(): Pair<String, Int> {
        val act = list().filter { it.active }
        if (act.isEmpty()) return Pair("磁力下载", -1)
        val d = act.sumOf { it.doneBytes }; val w = act.sumOf { it.wantedBytes }
        val sp = act.sumOf { it.down.toLong() }
        val txt = (if (act.size == 1) act[0].name else "${act.size} 个任务") + " · ↓ " + MagnetCore.formatSize(sp) + "/s"
        return Pair(txt, if (w > 0) (d * 100 / w).toInt() else -1)
    }
}

/** 下载期间的前台服务：切到别的应用 / 熄屏也继续下，通知栏显示总进度；任务都结束后自动退出 */
class TorrentService : Service() {
    companion object {
        private const val CH = "lancast_bt"
        private const val NID = 7
        private const val NID_DONE = 8
        @Volatile private var inst: TorrentService? = null

        fun start() {
            try { ContextCompat.startForegroundService(BtEngine.ctx, Intent(BtEngine.ctx, TorrentService::class.java)) } catch (_: Throwable) {}
        }
        fun stop() { try { BtEngine.ctx.stopService(Intent(BtEngine.ctx, TorrentService::class.java)) } catch (_: Throwable) {} }
        fun refresh() { inst?.update() }
        fun notifyDone(name: String) {
            try {
                val c = BtEngine.ctx
                val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                ensureChannel(nm)
                val n = Notification.Builder(c, CH).setSmallIcon(android.R.drawable.stat_sys_download_done)
                    .setContentTitle("下载完成").setContentText(name).setAutoCancel(true).setContentIntent(open(c)).build()
                nm.notify(NID_DONE, n)
            } catch (_: Throwable) {}
        }
        private fun ensureChannel(nm: NotificationManager) {
            if (nm.getNotificationChannel(CH) == null) nm.createNotificationChannel(NotificationChannel(CH, "磁力下载", NotificationManager.IMPORTANCE_LOW))
        }
        private fun open(c: Context): PendingIntent = PendingIntent.getActivity(
            c, 0, Intent(c, DownloadsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    private var wake: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        inst = this
        goForeground()
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "lancast:bt").apply { setReferenceCounted(false); acquire(12L * 60 * 60 * 1000) }
            @Suppress("DEPRECATION")
            wifi = (applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager)
                .createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "lancast-bt").apply { setReferenceCounted(false); acquire() }
        } catch (_: Throwable) {}
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        goForeground()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        inst = null
        try { wake?.let { if (it.isHeld) it.release() } } catch (_: Throwable) {}
        try { wifi?.let { if (it.isHeld) it.release() } } catch (_: Throwable) {}
        super.onDestroy()
    }

    private fun build(text: String, pct: Int): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        ensureChannel(nm)
        val b = Notification.Builder(this, CH).setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("瞬流 磁力下载").setContentText(text).setOnlyAlertOnce(true).setOngoing(true).setContentIntent(open(this))
        if (pct >= 0) b.setProgress(100, pct, false) else b.setProgress(0, 0, true)
        return b.build()
    }

    private fun goForeground() {
        try {
            val (t, p) = BtEngine.notificationText()
            startForeground(NID, build(t, p), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } catch (_: Throwable) { stopSelf() }
    }

    fun update() {
        try {
            val (t, p) = BtEngine.notificationText()
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NID, build(t, p))
        } catch (_: Throwable) {}
    }
}
