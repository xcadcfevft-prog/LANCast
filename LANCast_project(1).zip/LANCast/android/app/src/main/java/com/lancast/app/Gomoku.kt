package com.lancast.app

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import java.security.SecureRandom

/**
 * 瞬流「五子棋对战」（安卓端）。Windows 端对应 windows/gomoku.js，规范见 docs/PROTOCOL.md 第 19 节。
 *
 * 信令和对局消息都走已有的加密聊天连接（hub.sendGame → {t:"gm", ...}），不开新端口、不做新握手：
 *   invite  邀请方 → 对方：{op:"invite", gid, side, turn}  side = 邀请方执哪色（1 黑 2 白，随机），turn = 第一局谁先手
 *   accept  对方同意 → 双方各自打开独立的棋盘窗口（GomokuActivity，邀请方 = host，分歧时以它的棋盘为准）
 *   reject / busy / end
 *   g       对局内消息 {op:"g", gid, d:{k:...}}，原样交给棋盘页面（assets/gomoku.html，规则、同步、校验都在页面里，与 Windows 端是同一个文件）
 *
 * 线程：状态变化都投递到主线程串行处理；WebView 的 JS 桥回调在别的线程，一律 post 回主线程。
 */
object Gomoku : ChatHub.GameSink {
    private const val RING_TIMEOUT_MS = 40_000L

    class State {
        @Volatile var phase = "idle"           // idle | inviting（我邀请别人）| invited（别人邀请我）| playing | ended（对方已离开，棋盘窗口还开着）
        @Volatile var peerId: String? = null
        @Volatile var gid = ""
        @Volatile var side = 1                 // 邀请阶段 = 邀请方的颜色；对局中 = 我的颜色
        @Volatile var turn = 1
        @Volatile var host = false
        @Volatile var reason = ""
        @Volatile var up = true
    }

    val st = State()

    /** 状态变化回调（主线程）：主界面据此弹邀请对话框 / 提示 */
    @Volatile var onChange: (() -> Unit)? = null

    private val ui = Handler(Looper.getMainLooper())
    private val rnd = SecureRandom()
    private var inviteSent = false
    private var timeoutRun: Runnable? = null
    private var inviteRun: Runnable? = null
    private var tickRun: Runnable? = null

    // 棋盘窗口
    private var sink: ((String) -> Unit)? = null
    private var closer: (() -> Unit)? = null
    private var winReady = false
    private val inbox = ArrayList<String>()

    private fun hub() = ChatNet.hub
    private fun emit() { ui.post { onChange?.invoke() } }
    private fun nameOf(id: String?) = Link.pairs().firstOrNull { it.id == id }?.name ?: "对方"
    private fun sig(id: String, obj: JSONObject): Boolean = try { hub().sendGame(id, obj) } catch (e: Exception) { false }
    private fun sigOp(id: String, op: String, gid: String): Boolean = sig(id, JSONObject().put("op", op).put("gid", gid))
    private fun newGid(): String { val b = ByteArray(8); rnd.nextBytes(b); return b.joinToString("") { "%02x".format(it) } }

    fun install() { hub().game = this }

    // ───────── 状态机（主线程）─────────
    private fun cancelTimers() {
        timeoutRun?.let { ui.removeCallbacks(it) }; timeoutRun = null
        inviteRun?.let { ui.removeCallbacks(it) }; inviteRun = null
        tickRun?.let { ui.removeCallbacks(it) }; tickRun = null
    }

    private fun reset(reason: String, closeWin: Boolean) {
        cancelTimers()
        val was = st.phase
        st.phase = "idle"; st.peerId = null; st.gid = ""; st.reason = reason
        if (closeWin && (was == "playing" || was == "ended")) closer?.invoke()
        emit()
    }

    private fun begin(side: Int, host: Boolean) {
        cancelTimers()
        st.phase = "playing"; st.side = side; st.host = host; st.reason = ""; st.up = true
        winReady = false; inbox.clear()
        showWindow(true)
        val tick = object : Runnable {
            override fun run() {
                if (st.phase != "playing") return
                val id = st.peerId ?: return
                val up = hub().isConnected(id)
                if (up != st.up) { st.up = up; deliver(JSONObject().put("k", "_link").put("up", up)) }
                if (!up) hub().ensure(id)
                ui.postDelayed(this, 1000)
            }
        }
        tickRun = tick; ui.postDelayed(tick, 1000)
        emit()
    }

    /** 打开 / 切回棋盘窗口。应用在后台时系统不允许直接弹窗，改发通知，点开进入 */
    fun showWindow(fromBegin: Boolean = false) {
        if (st.phase != "playing" && st.phase != "ended") return
        val ctx = Link.app
        if (fromBegin && Link.listener == null) { Notice.game("智斗五子棋·文房雅趣", "与「" + nameOf(st.peerId) + "」的对局已开始，点开进入棋盘", true); return }
        try { ctx.startActivity(Intent(ctx, GomokuActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)) } catch (ignored: Exception) { }
    }

    /** 我发起邀请（调用前界面已确认对方在线）。加密连接还没建好时每秒重试发信令，直到超时 */
    fun invite(peerId: String): Boolean {
        if (st.phase != "idle" && st.phase != "ended") return false
        if (st.phase == "ended") windowClosed(true)
        val gid = newGid()
        st.phase = "inviting"; st.peerId = peerId; st.gid = gid; st.reason = ""
        st.side = if (rnd.nextBoolean()) 1 else 2; st.turn = if (rnd.nextBoolean()) 1 else 2; st.host = true
        inviteSent = false
        ChatNet.start()
        val t0 = System.currentTimeMillis()
        val r = object : Runnable {
            override fun run() {
                if (st.phase != "inviting" || st.gid != gid) return
                if (System.currentTimeMillis() - t0 > RING_TIMEOUT_MS) { sigOp(peerId, "end", gid); reset("对方没有回应邀请", false); return }
                if (!inviteSent && sig(peerId, JSONObject().put("op", "invite").put("gid", gid).put("side", st.side).put("turn", st.turn))) inviteSent = true
                ui.postDelayed(this, 1000)
            }
        }
        inviteRun = r
        emit(); r.run()
        return true
    }

    fun cancelInvite() {
        if (st.phase != "inviting") return
        st.peerId?.let { sigOp(it, "end", st.gid) }
        reset("已取消邀请", false)
    }

    fun accept() {
        if (st.phase != "invited") return
        val id = st.peerId ?: return
        sigOp(id, "accept", st.gid)
        begin(if (st.side == 1) 2 else 1, false)       // st.side 是邀请方的颜色，我执另一色
    }

    fun decline() {
        if (st.phase != "invited") return
        st.peerId?.let { sigOp(it, "reject", st.gid) }
        reset("已拒绝", false)
    }

    /** 我这边离开对局（关了棋盘窗口 / 返回键确认） */
    private fun leave() {
        if (st.phase != "playing") return
        st.peerId?.let { sigOp(it, "end", st.gid) }
        reset("你已离开对局", false)
    }

    fun peerGone(peerId: String) { ui.post { if (st.peerId == peerId && st.phase != "idle") reset("已取消配对", true) } }

    /** 读线程里调用：投递到主线程处理 */
    override fun onSignal(peerId: String, m: ChatCrypto.Plain) { ui.post { handle(peerId, m) } }

    private fun handle(peerId: String, m: ChatCrypto.Plain) {
        if (m.op == "invite") {
            when {
                st.phase == "idle" -> {
                    st.phase = "invited"; st.peerId = peerId; st.gid = m.gid; st.side = m.side; st.turn = m.turn; st.host = false; st.reason = ""
                    armInviteTimeout(peerId, m.gid)
                    if (Link.listener == null) Notice.game("智斗五子棋·文房雅趣 · 邀请", "「" + nameOf(peerId) + "」邀请你来一局（点开应用回应）", false)
                    emit()
                }
                st.phase == "inviting" && st.peerId == peerId -> {
                    // 同时互相邀请：设备 ID 较小的一方的邀请有效，另一方改为接受它
                    if (peerId < Link.id) {
                        sigOp(peerId, "end", st.gid)
                        cancelTimers()
                        st.phase = "invited"; st.gid = m.gid; st.side = m.side; st.turn = m.turn; st.host = false
                        armInviteTimeout(peerId, m.gid)
                        emit()
                    }
                }
                st.phase == "playing" && st.peerId == peerId && st.gid == m.gid -> sigOp(peerId, "accept", m.gid)     // 重复邀请：重发接受
                else -> sigOp(peerId, "busy", m.gid)
            }
            return
        }
        if (st.peerId != peerId || st.gid != m.gid) return
        when (m.op) {
            "accept" -> if (st.phase == "inviting") begin(st.side, true)
            "reject" -> if (st.phase == "inviting") reset("对方拒绝了「智斗五子棋·文房雅趣」邀请", false)
            "busy" -> if (st.phase == "inviting") reset("对方正忙（已有邀请或对局）", false)
            "end" -> when (st.phase) {
                "inviting" -> reset("对方没有接受邀请", false)
                "invited" -> reset("对方取消了邀请", false)
                "playing" -> { deliver(JSONObject().put("k", "_gone")); cancelTimers(); st.phase = "ended"; st.reason = "对方已离开对局"; emit() }
            }
            "g" -> if (st.phase == "playing") m.d?.let { deliver(it) }
        }
    }

    private fun armInviteTimeout(peerId: String, gid: String) {
        val r = Runnable { if (st.phase == "invited" && st.gid == gid) { sigOp(peerId, "end", gid); reset("邀请已过期", false) } }
        timeoutRun = r; ui.postDelayed(r, RING_TIMEOUT_MS)
    }

    // ───────── 与棋盘窗口（WebView）之间 ─────────
    fun initJson(): String = JSONObject().put("side", st.side).put("turn", st.turn).put("host", st.host)
        .put("peerName", nameOf(st.peerId)).put("gid", st.gid).toString()

    /** 棋盘窗口发来的消息（WebView 桥线程）→ 转给对方 */
    fun fromWindow(s: String) {
        ui.post {
            if (st.phase != "playing") return@post
            val id = st.peerId ?: return@post
            val o = try { JSONObject(s) } catch (e: Exception) { return@post }
            val d = ChatCrypto.sanitizeGameData(o) ?: return@post
            sig(id, JSONObject().put("op", "g").put("gid", st.gid).put("d", d))
        }
    }

    private fun deliver(d: JSONObject) {
        val s = d.toString()
        val f = sink
        if (winReady && f != null) f(s) else if (inbox.size < 500) inbox.add(s)
    }

    /** 棋盘窗口创建好了（主线程）：sink 把一条消息送进页面，close 关掉窗口 */
    fun attach(sink: (String) -> Unit, close: () -> Unit) {
        this.sink = sink; this.closer = close; winReady = false
    }

    /** 页面脚本都就绪了：把排队的消息放进去 */
    fun windowReady() {
        ui.post {
            winReady = true
            val f = sink
            if (f != null) { for (s in inbox) f(s) }
            inbox.clear()
        }
    }

    /** 棋盘窗口关了。真的离开（不是旋转屏幕之类）才算离开对局 */
    fun windowClosed(leaving: Boolean) {
        ui.post {
            sink = null; closer = null; winReady = false
            if (!leaving) return@post
            if (st.phase == "playing") leave() else if (st.phase == "ended") reset("", false)
        }
    }
}

/** 五子棋棋盘窗口：独立任务（最近任务里是单独一张卡片），里面是 assets/gomoku.html。 */
class GomokuActivity : Activity() {
    private var web: WebView? = null
    private val ui = Handler(Looper.getMainLooper())

    class Bridge {
        @JavascriptInterface fun init(): String = Gomoku.initJson()
        @JavascriptInterface fun send(s: String) { Gomoku.fromWindow(s) }
        @JavascriptInterface fun ready() { Gomoku.windowReady() }
    }

    @android.annotation.SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Gomoku.st.phase != "playing" && Gomoku.st.phase != "ended") { finishAndRemoveTask(); return }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        val w = WebView(this)
        w.settings.javaScriptEnabled = true
        w.settings.domStorageEnabled = true
        w.settings.mediaPlaybackRequiresUserGesture = false
        w.setBackgroundColor(0xFFE6D8BB.toInt())
        w.webChromeClient = WebChromeClient()
        w.webViewClient = object : WebViewClient() {
            // 只允许加载本地棋盘页：任何跳转到别处的企图都拦掉（页面里有 JS 桥）
            override fun shouldOverrideUrlLoading(view: WebView, request: android.webkit.WebResourceRequest): Boolean = true
        }
        w.addJavascriptInterface(Bridge(), "AndroidGomoku")
        web = w
        setContentView(w, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        Gomoku.attach(
            { js -> ui.post { web?.evaluateJavascript("window.__gmIn&&window.__gmIn($js)", null) } },
            { ui.post { finishAndRemoveTask() } }
        )
        w.loadUrl("file:///android_asset/gomoku.html")
    }

    override fun onBackPressed() {
        val ph = Gomoku.st.phase
        if (ph != "playing") { finishAndRemoveTask(); return }
        AlertDialog.Builder(this).setTitle("离开对局")
            .setMessage("离开后这局对弈会结束，对方会收到通知。")
            .setPositiveButton("离开") { _, _ -> finishAndRemoveTask() }
            .setNegativeButton("继续下棋", null).show()
    }

    override fun onDestroy() {
        val leaving = isFinishing
        web?.let { (it.parent as? ViewGroup)?.removeView(it); it.destroy() }
        web = null
        Gomoku.windowClosed(leaving)
        super.onDestroy()
    }
}
