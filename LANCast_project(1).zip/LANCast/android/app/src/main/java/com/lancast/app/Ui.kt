package com.lancast.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.view.View
import androidx.core.graphics.PathParser
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** 「瞬流」界面配色（取自 UI 设计图） */
object C {
    val BG = Color.parseColor("#F6FAFC")          // 页面底色
    val CARD = Color.WHITE                        // 卡片
    val CARD_LINE = Color.parseColor("#E6EEF4")   // 卡片描边
    val PRIMARY = Color.parseColor("#3B6B7F")     // 主按钮 / 图标
    val INK = Color.parseColor("#0E1A24")         // 主文字
    val SUB = Color.parseColor("#66788A")         // 次要文字
    val SOFT = Color.parseColor("#EAF3F8")        // 图标圆底 / 浅色按钮
    val BACK = Color.parseColor("#E1EEF6")        // 返回按钮底
    val INPUT_LINE = Color.parseColor("#D3E3EC")  // 输入框描边
    val GREEN = Color.parseColor("#6DB27A")       // 在线
    val GRAY = Color.parseColor("#B4C0CA")        // 离线
    val OK = Color.parseColor("#1F7A3D")
    val BAD = Color.parseColor("#B3541E")
    val WIN_BLUE = Color.parseColor("#2F7FE0")    // Windows 图标蓝
}

fun Context.px(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

/** 圆角矩形背景；strokeDp > 0 时带描边 */
fun Context.shape(fill: Int, radiusDp: Float, strokeColor: Int = 0, strokeDp: Float = 0f): GradientDrawable {
    val d = resources.displayMetrics.density
    return GradientDrawable().apply {
        setColor(fill)
        cornerRadius = radiusDp * d
        if (strokeDp > 0f) setStroke(Math.round(strokeDp * d), strokeColor)
    }
}

/** 圆形背景 */
fun circle(fill: Int): GradientDrawable = GradientDrawable().apply {
    shape = GradientDrawable.OVAL
    setColor(fill)
}

/**
 * 用代码画的图标（24×24 网格），不依赖任何图片/资源文件。
 * kind: back chev scan monitor folder pencil gear windows phone cast refresh
 */
class IconView(ctx: Context, private val kind: String, private val tint: Int = C.PRIMARY, private val filled: Boolean = false) : View(ctx) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path: Path = build(kind)
    private val extra: Path? = if (kind == "monitor") PathParser.createPathFromPathData("M12 16 V19.5 M7.5 20 H16.5") else null

    init {
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeJoin = Paint.Join.ROUND
        paint.strokeWidth = 2.2f
    }

    private fun build(k: String): Path = when (k) {
        "back" -> PathParser.createPathFromPathData("M15 5 L8 12 L15 19")
        "chev" -> PathParser.createPathFromPathData("M9 5 L16 12 L9 19")
        "scan" -> PathParser.createPathFromPathData(
            "M4 8 V6 Q4 4 6 4 H8 M16 4 H18 Q20 4 20 6 V8 M20 16 V18 Q20 20 18 20 H16 M8 20 H6 Q4 20 4 18 V16 M8 12 H16"
        )
        "monitor" -> PathParser.createPathFromPathData("M5 4.5 H19 Q21 4.5 21 6.5 V14 Q21 16 19 16 H5 Q3 16 3 14 V6.5 Q3 4.5 5 4.5 Z")
        "folder" -> PathParser.createPathFromPathData("M3 7 Q3 5 5 5 H9 L11.2 7.2 H19 Q21 7.2 21 9.2 V17 Q21 19 19 19 H5 Q3 19 3 17 Z")
        "pencil" -> PathParser.createPathFromPathData("M5 18.5 L5 14.6 L14.6 5 L18.5 8.9 L8.9 18.5 Z M3 22 H21")
        "phone" -> PathParser.createPathFromPathData("M8 3 H16 Q17.5 3 17.5 4.5 V19.5 Q17.5 21 16 21 H8 Q6.5 21 6.5 19.5 V4.5 Q6.5 3 8 3 Z M10.5 18 H13.5")
        "cast" -> PathParser.createPathFromPathData("M3 8 V6.5 Q3 5 4.5 5 H19.5 Q21 5 21 6.5 V17.5 Q21 19 19.5 19 H14 M3 12 A9 9 0 0 1 12 21 M3 16.5 A4.5 4.5 0 0 1 7.5 21 M3 21 H3.01")
        "refresh" -> PathParser.createPathFromPathData("M21 12 A9 9 0 1 1 18 5.3 M21 3 V8 H16")
        "gear" -> gear()
        else -> Path()
    }

    /** 8 齿的齿轮外形 + 中心圆孔 */
    private fun gear(): Path {
        val p = Path()
        val cx = 12f
        val cy = 12f
        val teeth = 8
        val rOut = 9.6
        val rIn = 7.3
        val step = 2.0 * PI / teeth
        for (i in 0 until teeth) {
            val a = i * step
            val pts = doubleArrayOf(a - step * 0.30, rIn, a - step * 0.17, rOut, a + step * 0.17, rOut, a + step * 0.30, rIn)
            for (j in 0 until 4) {
                val ang = pts[j * 2]
                val r = pts[j * 2 + 1].toFloat()
                val x = cx + r * cos(ang).toFloat()
                val y = cy + r * sin(ang).toFloat()
                if (i == 0 && j == 0) p.moveTo(x, y) else p.lineTo(x, y)
            }
        }
        p.close()
        p.addCircle(cx, cy, 3.1f, Path.Direction.CW)
        return p
    }

    override fun onDraw(canvas: Canvas) {
        val s = minOf(width, height) / 24f
        val ox = (width - 24f * s) / 2f
        val oy = (height - 24f * s) / 2f
        canvas.save()
        canvas.translate(ox, oy)
        canvas.scale(s, s)
        if (kind == "windows") {
            paint.style = Paint.Style.FILL
            paint.color = tint
            val g = 1.1f
            canvas.drawRect(RectF(3f, 3.6f, 12f - g, 11.6f), paint)
            canvas.drawRect(RectF(12f + g, 2.6f, 21f, 11.6f), paint)
            canvas.drawRect(RectF(3f, 12.4f, 12f - g, 20.4f), paint)
            canvas.drawRect(RectF(12f + g, 12.4f, 21f, 21.4f), paint)
        } else {
            paint.color = tint
            paint.style = if (filled) Paint.Style.FILL_AND_STROKE else Paint.Style.STROKE
            canvas.drawPath(path, paint)
            extra?.let {
                paint.style = Paint.Style.STROKE
                canvas.drawPath(it, paint)
            }
        }
        canvas.restore()
    }
}
