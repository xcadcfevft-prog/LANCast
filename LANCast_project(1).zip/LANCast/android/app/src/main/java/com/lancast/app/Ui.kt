package com.lancast.app

import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.ViewConfiguration
import android.widget.LinearLayout
import kotlin.math.hypot
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.view.Gravity
import android.util.TypedValue
import android.widget.TextView
import androidx.core.graphics.PathParser
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** 所有悬浮按钮栏（顶栏、控制栏）里的按钮统一用这个尺寸：12dp 字（不随系统字体放大）、左右 12dp / 上下 6dp 内边距。 */
fun styleBarButton(tv: TextView) {
    val d = tv.resources.displayMetrics.density
    tv.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 12f)
    tv.setTextColor(Color.WHITE)
    tv.gravity = Gravity.CENTER
    tv.includeFontPadding = false
    tv.setPadding((12 * d).toInt(), (6 * d).toInt(), (12 * d).toInt(), (6 * d).toInt())
}

/** 「瞬流」界面配色（取自 UI 设计图） */
object C {
    val BG = Color.parseColor("#F6FAFC")          // 页面底色
    val CARD = Color.WHITE                        // 卡片
    val CARD_LINE = Color.parseColor("#E6EEF4")   // 卡片描边
    val PRIMARY = Color.parseColor("#3B6B7F")     // 主按钮 / 图标
    val INK = Color.parseColor("#0E1A24")         // 主文字
    val SUB = Color.parseColor("#66788A")         // 次要文字
    val SOFT = Color.parseColor("#EAF3F8")        // 图标圆底 / 浅色按钮
    val BACK = Color.parseColor("#E1EEF6")        // 返回按钮底
    val INPUT_LINE = Color.parseColor("#D3E3EC")  // 输入框描边
    val GREEN = Color.parseColor("#6DB27A")       // 在线
    val GRAY = Color.parseColor("#B4C0CA")        // 离线
    val OK = Color.parseColor("#1F7A3D")
    val BAD = Color.parseColor("#B3541E")
    val WIN_BLUE = Color.parseColor("#2F7FE0")    // Windows 图标蓝
}

fun Context.px(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

/** 圆角矩形背景；strokeDp > 0 时带描边 */
fun Context.shape(fill: Int, radiusDp: Float, strokeColor: Int = 0, strokeDp: Float = 0f): GradientDrawable {
    val d = resources.displayMetrics.density
    return GradientDrawable().apply {
        setColor(fill)
        cornerRadius = radiusDp * d
        if (strokeDp > 0f) setStroke(Math.round(strokeDp * d), strokeColor)
    }
}

/** 圆形背景 */
fun circle(fill: Int): GradientDrawable = GradientDrawable().apply {
    shape = GradientDrawable.OVAL
    setColor(fill)
}

/**
 * 用代码画的图标（24×24 网格），不依赖任何图片/资源文件。
 * kind: back chev scan monitor folder pencil gear windows phone cast refresh
 */
class IconView(ctx: Context, private val kind: String, private val tint: Int = C.PRIMARY, private val filled: Boolean = false) : View(ctx) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path: Path = build(kind)
    private val extra: Path? = if (kind == "monitor") PathParser.createPathFromPathData("M12 16 V19.5 M7.5 20 H16.5") else null

    init {
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeJoin = Paint.Join.ROUND
        paint.strokeWidth = 2.2f
    }

    private fun build(k: String): Path = when (k) {
        "back" -> PathParser.createPathFromPathData("M15 5 L8 12 L15 19")
        "chev" -> PathParser.createPathFromPathData("M9 5 L16 12 L9 19")
        "scan" -> PathParser.createPathFromPathData(
            "M4 8 V6 Q4 4 6 4 H8 M16 4 H18 Q20 4 20 6 V8 M20 16 V18 Q20 20 18 20 H16 M8 20 H6 Q4 20 4 18 V16 M8 12 H16"
        )
        "monitor" -> PathParser.createPathFromPathData("M5 4.5 H19 Q21 4.5 21 6.5 V14 Q21 16 19 16 H5 Q3 16 3 14 V6.5 Q3 4.5 5 4.5 Z")
        "folder" -> PathParser.createPathFromPathData("M3 7 Q3 5 5 5 H9 L11.2 7.2 H19 Q21 7.2 21 9.2 V17 Q21 19 19 19 H5 Q3 19 3 17 Z")
        "pencil" -> PathParser.createPathFromPathData("M5 18.5 L5 14.6 L14.6 5 L18.5 8.9 L8.9 18.5 Z M3 22 H21")
        "phone" -> PathParser.createPathFromPathData("M8 3 H16 Q17.5 3 17.5 4.5 V19.5 Q17.5 21 16 21 H8 Q6.5 21 6.5 19.5 V4.5 Q6.5 3 8 3 Z M10.5 18 H13.5")
        "cast" -> PathParser.createPathFromPathData("M3 8 V6.5 Q3 5 4.5 5 H19.5 Q21 5 21 6.5 V17.5 Q21 19 19.5 19 H14 M3 12 A9 9 0 0 1 12 21 M3 16.5 A4.5 4.5 0 0 1 7.5 21 M3 21 H3.01")
        "refresh" -> PathParser.createPathFromPathData("M21 12 A9 9 0 1 1 18 5.3 M21 3 V8 H16")
        "gear" -> gear()
        else -> Path()
    }

    /** 8 齿的齿轮外形 + 中心圆孔 */
    private fun gear(): Path {
        val p = Path()
        val cx = 12f
        val cy = 12f
        val teeth = 8
        val rOut = 9.6
        val rIn = 7.3
        val step = 2.0 * PI / teeth
        for (i in 0 until teeth) {
            val a = i * step
            val pts = doubleArrayOf(a - step * 0.30, rIn, a - step * 0.17, rOut, a + step * 0.17, rOut, a + step * 0.30, rIn)
            for (j in 0 until 4) {
                val ang = pts[j * 2]
                val r = pts[j * 2 + 1].toFloat()
                val x = cx + r * cos(ang).toFloat()
                val y = cy + r * sin(ang).toFloat()
                if (i == 0 && j == 0) p.moveTo(x, y) else p.lineTo(x, y)
            }
        }
        p.close()
        p.addCircle(cx, cy, 3.1f, Path.Direction.CW)
        return p
    }

    override fun onDraw(canvas: Canvas) {
        val s = minOf(width, height) / 24f
        val ox = (width - 24f * s) / 2f
        val oy = (height - 24f * s) / 2f
        canvas.save()
        canvas.translate(ox, oy)
        canvas.scale(s, s)
        if (kind == "windows") {
            paint.style = Paint.Style.FILL
            paint.color = tint
            val g = 1.1f
            canvas.drawRect(RectF(3f, 3.6f, 12f - g, 11.6f), paint)
            canvas.drawRect(RectF(12f + g, 2.6f, 21f, 11.6f), paint)
            canvas.drawRect(RectF(3f, 12.4f, 12f - g, 20.4f), paint)
            canvas.drawRect(RectF(12f + g, 12.4f, 21f, 21.4f), paint)
        } else {
            paint.color = tint
            paint.style = if (filled) Paint.Style.FILL_AND_STROKE else Paint.Style.STROKE
            canvas.drawPath(path, paint)
            extra?.let {
                paint.style = Paint.Style.STROKE
                canvas.drawPath(it, paint)
            }
        }
        canvas.restore()
    }
}

/** 控制模式下，在观看方手指位置画一个即时反馈圆点（不等对方画面回传，手感更跟手）。 */
class TouchDot(ctx: Context) : View(ctx) {
    private val d = ctx.resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(110, 80, 180, 255) }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 2f * d; color = Color.argb(210, 255, 255, 255)
    }
    private var cx = 0f
    private var cy = 0f
    private var on = false

    init { isClickable = false; isFocusable = false }

    fun at(x: Float, y: Float) { cx = x; cy = y; on = true; invalidate() }
    fun hide() { if (on) { on = false; invalidate() } }

    override fun onDraw(c: Canvas) {
        if (!on) return
        c.drawCircle(cx, cy, 20f * d, fill)
        c.drawCircle(cx, cy, 20f * d, ring)
    }
}

/**
 * 可拖动的悬浮按钮栏：布局不变，**长按（约 0.4 秒）后手指不抬就能拖到屏幕任意位置**，位置会记住。
 * 短按、点击里面的按钮照常工作；拖动期间不会误触按钮（长按触发时给按钮发 CANCEL）；位置始终夹在屏幕内。
 */
class DragBox(ctx: Context, private val prefs: SharedPreferences, private val key: String, private val pill: Boolean = false) : LinearLayout(ctx) {
    private val h = Handler(Looper.getMainLooper())
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private var dragging = false
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var refX = 0f
    private var refY = 0f
    private var baseTx = 0f
    private var baseTy = 0f
    private val longPress = Runnable { startDrag() }

    /* 隐藏 / 显示：长按进入「可移动」状态时同时出现一个「隐藏」按钮（已隐藏时是「显示」），点它切换；
     * 隐藏后整条栏消失，只在原处留一小块透明区域，再长按这块区域就会出现「显示」。按钮 4 秒内没人点就收回去。 */
    private var hidden = false
    private var editing = false
    private var savedBg: android.graphics.drawable.Drawable? = null
    private val prevVis = HashMap<View, Int>()
    private val toggle = TextView(ctx).apply {
        styleBarButton(this)
        setTextColor(Color.parseColor("#FFC66D"))
        if (pill) background = ctx.shape(Color.parseColor("#99141A21"), 18f)
        isClickable = true
        setOnClickListener { setHidden(!hidden) }
    }
    private val editEnd = Runnable { endEdit() }

    private fun applyHidden() {
        if (hidden) {
            for (i in 0 until childCount) { val c = getChildAt(i); if (c !== toggle) { prevVis[c] = c.visibility; c.visibility = View.GONE } }
            if (savedBg == null) savedBg = background
            background = null
            minimumWidth = (48 * resources.displayMetrics.density).toInt()
            minimumHeight = (40 * resources.displayMetrics.density).toInt()
        } else {
            for (i in 0 until childCount) { val c = getChildAt(i); if (c !== toggle) c.visibility = prevVis[c] ?: View.VISIBLE }
            prevVis.clear()
            if (savedBg != null) { background = savedBg; savedBg = null }
            minimumWidth = 0
            minimumHeight = 0
        }
        requestLayout()
    }

    fun setHidden(v: Boolean) {
        if (v != hidden) { hidden = v; applyHidden() }
        endEdit()
    }

    /** 每次开始 / 结束查看时调用：回到显示状态（隐藏状态不跨会话保存，免得找不到按钮栏）。 */
    fun resetHidden() { setHidden(false) }

    private fun startEdit() {
        editing = true
        toggle.text = if (hidden) "显示" else "隐藏"
        if (toggle.parent == null) {
            val lp = LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT)
            if (pill) lp.leftMargin = (8 * resources.displayMetrics.density).toInt()
            addView(toggle, lp)
        }
        h.removeCallbacks(editEnd)
        h.postDelayed(editEnd, 4000L)
    }

    private fun endEdit() {
        editing = false
        h.removeCallbacks(editEnd)
        if (toggle.parent === this) removeView(toggle)
    }

    init { isClickable = true }                       // 按钮之间的空隙也由本栏接收，不会穿透到下面的画面

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dragging = false
                if (editing) { h.removeCallbacks(editEnd); h.postDelayed(editEnd, 4000L) }
                downX = ev.rawX; downY = ev.rawY; lastX = downX; lastY = downY
                h.postDelayed(longPress, 400L)
            }
            MotionEvent.ACTION_MOVE -> {
                lastX = ev.rawX; lastY = ev.rawY
                if (!dragging && hypot(lastX - downX, lastY - downY) > slop) h.removeCallbacks(longPress)
            }
        }
        if (dragging) { drag(ev); return true }
        val r = super.dispatchTouchEvent(ev)
        if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) h.removeCallbacks(longPress)
        return r
    }

    private fun cancelChildren() {
        val t = SystemClock.uptimeMillis()
        val c = MotionEvent.obtain(t, t, MotionEvent.ACTION_CANCEL, 0f, 0f, 0)
        super.dispatchTouchEvent(c)
        c.recycle()
    }

    private fun startDrag() {
        dragging = true
        cancelChildren()
        startEdit()
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        parent?.requestDisallowInterceptTouchEvent(true)
        refX = lastX; refY = lastY; baseTx = translationX; baseTy = translationY
        alpha = 0.85f; scaleX = 1.06f; scaleY = 1.06f
    }

    private fun drag(ev: MotionEvent) {
        when (ev.actionMasked) {
            MotionEvent.ACTION_MOVE -> moveTo(baseTx + ev.rawX - refX, baseTy + ev.rawY - refY)
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                dragging = false
                alpha = 1f; scaleX = 1f; scaleY = 1f
                val p = parent as? View ?: return
                if (p.width > 0 && p.height > 0) {
                    prefs.edit().putFloat("pos_${key}_x", translationX / p.width).putFloat("pos_${key}_y", translationY / p.height).apply()
                }
            }
        }
    }

    private fun moveTo(tx: Float, ty: Float) {
        val p = parent as? View ?: return
        val minX = -left.toFloat()
        val maxX = (p.width - left - width).toFloat()
        val minY = -top.toFloat()
        val maxY = (p.height - top - height).toFloat()
        translationX = tx.coerceIn(minOf(minX, maxX), maxOf(minX, maxX))
        translationY = ty.coerceIn(minOf(minY, maxY), maxOf(minY, maxY))
    }

    /** 按记住的位置摆放（屏幕尺寸 / 方向变化后重新夹进屏幕内）。 */
    fun restore() {
        if (dragging) return
        val p = parent as? View ?: return
        if (p.width <= 0 || width <= 0 || !prefs.contains("pos_${key}_x")) return
        moveTo(prefs.getFloat("pos_${key}_x", 0f) * p.width, prefs.getFloat("pos_${key}_y", 0f) * p.height)
    }

    override fun onSizeChanged(w: Int, h2: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h2, ow, oh)
        post { restore() }
    }
}
