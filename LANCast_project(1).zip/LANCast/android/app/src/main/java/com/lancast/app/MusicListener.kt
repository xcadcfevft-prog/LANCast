package com.lancast.app

import android.service.notification.NotificationListenerService

/**
 * 空壳「通知使用权」服务。
 *
 * 安卓不允许普通应用读取别的音乐 App 的歌名 / 封面 / 进度，也不允许控制它们播放；唯一的正规途径是
 * MediaSessionManager.getActiveSessions(listenerComponent)，而它要求调用方是一个已被用户授予「通知使用权」的 NotificationListenerService。
 * 本服务什么通知都不读、不存，只是为了让 MusicMeta 能拿到这个资格。没授权时沉浸音乐照样能把声音传过去，只是没有歌名封面、不能远程控制。
 */
class MusicListener : NotificationListenerService()
