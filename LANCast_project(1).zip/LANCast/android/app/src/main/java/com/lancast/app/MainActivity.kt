package com.lancast.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.Outline
import android.view.ViewOutlineProvider
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.DocumentsContract
import android.provider.Settings
import android.text.Editable
import android.text.InputFilter
import android.text.InputType
import android.text.TextWatcher
import android.text.TextUtils
import android.view.GestureDetector
import android.view.HapticFeedbackConstants
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.BaseInputConnection
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.HorizontalScrollView
import org.json.JSONArray
import org.json.JSONObject
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/** 视频通话「全屏」是否像投屏观看的「全屏」一样同时切到横屏（true = 一致；改成 false 则只做沉浸式全屏、保持当前方向） */
private const val VIDEO_FULL_LANDSCAPE = true

class MainActivity : ComponentActivity(), Link.Listener {

    private data class CastReq(val mode: String, val host: String = "", val port: Int = 0, val pin: String = "", val ctl: Boolean = false)

    /* ── 页面 ── */
    private lateinit var root: FrameLayout
    private lateinit var home: ScrollView
    private lateinit var settingsPage: FrameLayout
    private lateinit var pairedPage: FrameLayout
    private lateinit var viewer: FrameLayout
    private lateinit var chatPage: ChatPage

    /* ── 首页控件 ── */
    private lateinit var qrIv: ImageView
    private lateinit var qrSub: TextView
    private lateinit var netTv: TextView
    private lateinit var statusCard: LinearLayout
    private lateinit var statusTv: TextView
    private lateinit var stopBtn: TextView
    private lateinit var peersBox: LinearLayout
    private lateinit var xfersCard: LinearLayout
    private lateinit var xfersBox: LinearLayout
    private lateinit var statsTv: TextView

    /* ── 设置页控件 ── */
    private lateinit var nameEt: EditText
    private lateinit var avatarIv: ImageView
    private lateinit var bioEt: EditText
    private lateinit var dirSub: TextView
    private lateinit var dirReset: TextView
    private lateinit var presetVal: TextView
    private lateinit var presetNote: TextView
    private lateinit var audioSw: Switch
    private lateinit var bgSw: Switch
    private lateinit var ctlSub: TextView
    private lateinit var netSub: TextView

    /* ── 屏幕控制（观看方） ── */
    private lateinit var ctlBtn: TextView
    private lateinit var discBtn: TextView
    private lateinit var fullBtn: TextView
    private var fullLand = false                   // 「全屏」：横屏铺开，电脑画面更大
    private var chatFullOn = false                 // 视频通话（聊天页里）的「全屏」：和投屏观看一样的沉浸式 + 横屏
    private lateinit var topRow: DragBox
    private lateinit var navBar: LinearLayout
    /* 控制电脑时的收纳菜单：平时只有左侧一个半透明小圆点。以前整条「控制 / 全屏 / 断开」顶栏一直盖在电脑画面右上角，
     * 正好挡住窗口的最小化 / 最大化 / 关闭按钮——点那一带就像撞上一堵墙。 */
    private lateinit var ctlDock: LinearLayout
    private lateinit var dockMenu: LinearLayout
    private lateinit var dockFull: TextView
    private val dockCollapse = Runnable { dockOpen(false) }
    private var dockDX = 0f
    private var dockDY = 0f
    private var dockBX = 0f
    private var dockBY = 0f
    private var dockMoved = false
    private var pendingUp: Runnable? = null            // 点击的「抬起」延后几毫秒发出（见 deskClick）
    /* 控制电脑时，系统被边缘滑动唤出的临时状态栏 / 导航栏会盖住画面最上 / 最下一行并吞掉触摸（约 1~3 秒）：一出现就收回去 */
    private val reHideBars = Runnable {
        if (viewing && ctlOn && desk) WindowCompat.getInsetsController(window, window.decorView).hide(WindowInsetsCompat.Type.systemBars())
    }
    private var viewSession: Session? = null
    private var ctlOn = false
    private val strokeBuf = ArrayList<FloatArray>()      // 待发送的移动点 [x, y, 相对按下时刻的毫秒]
    private var strokeT0 = 0L
    private var ctlSid = 0
    private var ctlDown = false
    private var lastSendT = 0L
    private var lastNorm: FloatArray? = null
    private lateinit var dot: TouchDot
    private lateinit var navInner: LinearLayout

    /* ── 控制电脑（对方是 Windows）：触摸 → 鼠标 / 滚轮 / 键盘 ── */
    private var desk = true                        // 统一：不论对方是电脑还是手机，都用「控制电脑」的鼠标语义 / 按钮 / 逻辑
    private var peerWin = true                     // 对方真的是电脑（手机被控时光标要由本机自己画出来）
    private var deskPad = false                    // false = 触控模式（手指点哪光标到哪）；true = 触控板模式（手指相对移动光标）
    private var panLocal = false                   // 控制中临时切到「缩放 / 平移画面」（只作用于本机画面）
    private var dkIgnore = false                   // 本次按下落在黑边上
    private var dkTwo = false                      // 两指：滚轮 / 右键
    private var dkTwoMoved = false
    private var dkTwoPath = 0f
    private var dkTwoT0 = 0L
    private var dkTwoX = 0f
    private var dkTwoY = 0f
    private var dkWx = 0f
    private var dkSx = 0f
    private var dkSy = 0f
    private var dkWy = 0f
    private var dkWT = 0L
    private var dkMoved = false
    private var dkLong = false                     // 长按已触发
    private var dkBtn = false                      // 左键是否按着
    private var dkDownX = 0f
    private var dkDownY = 0f
    private var dkLastX = 0f
    private var dkLastY = 0f
    private var dkLastT = 0L
    private var dkT0 = 0L
    private var dkDownN = floatArrayOf(0.5f, 0.5f)
    private var curN = floatArrayOf(0.5f, 0.5f)    // 光标位置（0..1）
    private val dkPts = ArrayList<FloatArray>()
    private val dkLongRun = Runnable { deskLong() }
    private val deskFlushRun = Runnable { deskFlush() }

    /* ── 实时打字：隐藏的输入框 + 差量发送 ── */
    private lateinit var kbdEt: EditText
    private var kbdOn = false
    private var kbdMute = false
    private var kbdLast = ""

    /* ── 已配对设备页 ── */
    private lateinit var pairedBox: LinearLayout

    private class XRow(val box: LinearLayout, val name: TextView, val info: TextView, val bar: ProgressBar, val btn: TextView)
    private val xRows = HashMap<Xfer, XRow>()
    private var tv: TextureView? = null
    private var sink: ScreenSink? = null
    private var viewing = false
    private var pendingCast: CastReq? = null
    private var pendingTarget: Paired? = null
    private val ui = Handler(Looper.getMainLooper())

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val QR_CYCLE = 60                  // 二维码每 60 秒自动刷新一轮
    private var qrLeft = QR_CYCLE
    private var qrLast = ""
    private var qrNoNet = false
    private var qrSide = 0
    private var peersSig = ""

    /* 铺满状态（与 Windows 端一致）：mode 0=自动 1=完整显示 2=铺满裁剪 3=手动缩放 */
    private var vw = 0
    private var vh = 0
    private var mode = 0
    private var manualRel = 1f
    private var panX = 0f
    private var panY = 0f
    private val autoLoss = 0.22f              // 被裁掉的面积 ≤ 22% 时自动铺满

    private val projLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        onProjection(r.resultCode, r.data)
    }
    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { _ ->
        launchProjection()
    }

    private val pickLauncher = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        val target = pendingTarget
        pendingTarget = null
        if (uris != null && uris.isNotEmpty() && target != null) {
            for (u in uris) {
                try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (ignored: Exception) { }
            }
            doSend(target, uris)
        }
    }
    private val avatarLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            if (Avatar.save(this, uri)) { refreshAvatar(); Toast.makeText(this, "头像已更新", Toast.LENGTH_SHORT).show() }
            else Toast.makeText(this, "无法使用这张图片（不是图片或超过 30MB）", Toast.LENGTH_LONG).show()
        }
    }
    private val notifLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { _ -> }

    /** 语音通话需要麦克风权限：有就直接执行，没有就先申请，授权后再执行 */
    private var micThen: (() -> Unit)? = null
    private val micLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val f = micThen; micThen = null
        if (granted) f?.invoke() else android.widget.Toast.makeText(this, "没有麦克风权限，无法语音通话", android.widget.Toast.LENGTH_LONG).show()
    }
    private fun withMic(f: () -> Unit) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) { f(); return }
        micThen = f
        micLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }
    /** 视频通话：麦克风必需，相机可选（没给相机权限就只收不发画面，通话照常） */
    private var camThen: (() -> Unit)? = null
    private val micCamLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        val f = camThen; camThen = null
        if (r[Manifest.permission.RECORD_AUDIO] == true || checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) android.widget.Toast.makeText(this, "没有相机权限：你的画面不会发出去，但能看到对方", android.widget.Toast.LENGTH_LONG).show()
            f?.invoke()
        } else android.widget.Toast.makeText(this, "没有麦克风权限，无法通话", android.widget.Toast.LENGTH_LONG).show()
    }
    private fun withMicCam(f: () -> Unit) {
        val need = ArrayList<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.RECORD_AUDIO)
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.CAMERA)
        if (need.isEmpty()) { f(); return }
        camThen = f
        micCamLauncher.launch(need.toTypedArray())
    }
    // 严格无损：先要「访问照片位置信息」等权限，不管用户给不给，都继续弹出选文件界面（没给的话发送时会明确提示）
    private val mediaPermLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { _ ->
        pickLauncher.launch(arrayOf("*/*"))
    }
    private val scanLauncher = registerForActivityResult(ScanContract()) { result ->
        val text = result.contents
        if (text != null) onScanned(text)
    }
    private val treeLauncher = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            var ok = true
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            } catch (e: Exception) {
                ok = false
            }
            if (ok) {
                Link.prefs.edit().putString("recv_tree", uri.toString()).apply()
                updateSettingsUi()
                Toast.makeText(this, "接收目录已更改", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "无法获得该文件夹的写入权限，请换一个文件夹", Toast.LENGTH_LONG).show()
            }
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            refreshPeers()
            refreshUi()
            ui.postDelayed(this, 2000)
        }
    }

    private val qrTick = object : Runnable {
        override fun run() {
            qrLeft--
            if (qrLeft <= 0) {
                drawQr(false)
                qrLeft = QR_CYCLE
            }
            updateQrSub()
            ui.postDelayed(this, 1000)
        }
    }

    private val statusHide = Runnable {
        if (CastService.current == null) statusCard.visibility = View.GONE
    }

    private fun dp(v: Int) = px(v)

    /* ═════════════ 生命周期 ═════════════ */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Link.init(this)
        Link.start()
        if (ListenService.enabled()) ListenService.start(this)
        buildUi()
        setContentView(root)
        if (Build.VERSION.SDK_INT >= 33 && !Link.prefs.getBoolean("asked_notif", false) &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            Link.prefs.edit().putBoolean("asked_notif", true).apply()      // 后台收到投屏请求时要靠通知提醒你
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        window.statusBarColor = C.BG
        window.navigationBarColor = C.BG
        val ic = WindowCompat.getInsetsController(window, window.decorView)
        ic.isAppearanceLightStatusBars = true
        ic.isAppearanceLightNavigationBars = true
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (viewing) {
                    exitViewer("已断开")
                } else if (chatVisible() && chatPage.exitVideoFull()) {
                    // 视频通话全屏中：返回键只退出全屏，不退出聊天页 / 不挂断
                } else if (chatVisible()) {
                    closeChat()
                } else if (settingsPage.visibility == View.VISIBLE || pairedPage.visibility == View.VISIBLE) {
                    showPage(home)
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    override fun onStart() {
        super.onStart()
        Link.listener = this
        ChatNet.start()
        ChatNet.onChange = { id -> chatPage.refresh(id); peersSig = ""; renderPeers() }
        VoiceCall.onChange = { onCallChanged() }
        Gomoku.onChange = { onGomokuChanged() }
        onGomokuChanged()             // 应用在后台时收到的五子棋邀请，回到前台就弹出来
        chatPage.refreshCall()
        FileXfer.listener = { renderXfers(); chatPage.refresh(null) }
        renderXfers()
        chatPage.peerId?.let { ChatNet.hub.viewing = it; chatPage.refresh(it) }
        openChatFromIntent()
        qrLeft = QR_CYCLE
        drawQr(true)
        updateQrSub()
        ui.post(tick)
        ui.postDelayed(qrTick, 1000)
        updateSettingsUi()            // 从系统无障碍设置回来时刷新状态
        Link.deliverParked()          // 应用在后台时挂起的投屏请求，现在交给界面
    }

    override fun onStop() {
        super.onStop()
        Link.listener = null
        FileXfer.listener = null
        ChatNet.onChange = null
        VoiceCall.onChange = null
        Gomoku.onChange = null
        gmDialog?.dismiss(); gmDialog = null
        VoiceCall.onRemoteFrame = null; VoiceCall.onLocalFrame = null      // 界面不可见：不再解码视频
        ChatNet.hub.viewing = null
        ui.removeCallbacks(tick)
        ui.removeCallbacks(qrTick)
        if (viewing) exitViewer("应用退到后台，已结束查看")
    }

    /* ═════════════ 小工具 ═════════════ */
    private fun txt(text: String, sp: Float, color: Int = C.INK, bold: Boolean = false): TextView = TextView(this).apply {
        this.text = text
        textSize = sp
        setTextColor(color)
        includeFontPadding = false
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun icon(kind: String, color: Int = C.PRIMARY, filled: Boolean = false): IconView = IconView(this, kind, color, filled)

    private fun ll(w: Int, h: Int, weight: Float = 0f, top: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(w, h, weight).apply { topMargin = px(top) }

    private fun fl(w: Int, h: Int, g: Int): FrameLayout.LayoutParams = FrameLayout.LayoutParams(w, h, g)

    /** 带按下反馈的点击 */
    private fun click(v: View, f: () -> Unit) {
        v.isClickable = true
        v.setOnClickListener { f() }
        v.setOnTouchListener { view, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> view.alpha = 0.78f
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> view.alpha = 1f
            }
            false
        }
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = shape(C.CARD, 24f, C.CARD_LINE, 1f)
        elevation = px(2).toFloat()
        outlineAmbientShadowColor = Color.parseColor("#2A5B7A8C")
        outlineSpotShadowColor = Color.parseColor("#2A5B7A8C")
    }

    /** 卡片里的小按钮：filled=实心主色；否则白底描边 */
    private fun pill(text: String, filled: Boolean, danger: Boolean = false, onClick: () -> Unit): TextView {
        val col = if (danger) C.BAD else C.PRIMARY
        return TextView(this).apply {
            this.text = text
            textSize = 13f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            includeFontPadding = false
            setTextColor(if (filled) Color.WHITE else col)
            background = if (filled) shape(col, 10f) else shape(Color.WHITE, 10f, col, 1.4f)
            click(this, onClick)
        }
    }

    private fun hideKeyboard() {
        try {
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(window.decorView.windowToken, 0)
        } catch (ignored: Exception) { }
    }

    /* ═════════════ 界面 ═════════════ */
    private fun buildUi() {
        buildHome()
        buildSettings()
        buildPairedPage()

        viewer = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            visibility = View.GONE
        }
        statsTv = TextView(this).apply {
            setTextColor(Color.parseColor("#dfe8ee"))
            setBackgroundColor(Color.parseColor("#b0141a21"))
            textSize = 11f
            setPadding(dp(8), dp(3), dp(8), dp(3))
        }
        // 统计信息已移除：statsTv 不再加入界面
        val disc = TextView(this).apply {
            text = "断开"
            styleBarButton(this)
            background = shape(Color.parseColor("#99141A21"), 18f)
        }
        discBtn = disc
        click(disc) { exitViewer("已断开") }
        ctlBtn = TextView(this).apply {
            text = "控制"
            styleBarButton(this)
            background = shape(Color.parseColor("#99141A21"), 18f)
            visibility = View.GONE
        }
        click(ctlBtn) { setControl(!ctlOn) }
        topRow = DragBox(this, Link.prefs, "top", pill = true).apply { orientation = LinearLayout.HORIZONTAL }
        fullBtn = TextView(this).apply {
            text = "全屏"
            styleBarButton(this)
            background = shape(Color.parseColor("#99141A21"), 18f)
        }
        click(fullBtn) { setFullLand(!fullLand) }
        topRow.addView(ctlBtn, LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(8) })
        topRow.addView(fullBtn, LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(8) })
        topRow.addView(disc)
        viewer.addView(topRow, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.END or Gravity.TOP).apply {
            rightMargin = dp(10); topMargin = dp(10)
        })
        ctlDock = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        val dockHandle = TextView(this).apply {
            text = "≡"
            setTextColor(Color.WHITE)
            setTextSize(android.util.TypedValue.COMPLEX_UNIT_DIP, 16f)
            gravity = Gravity.CENTER
            includeFontPadding = false
            background = shape(Color.parseColor("#66141A21"), 16f)       // 约 40% 不透明：看得见，但不抢画面
        }
        dockMenu = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; visibility = View.GONE }
        ctlDock.addView(dockHandle, LinearLayout.LayoutParams(dp(32), dp(32)))
        ctlDock.addView(dockMenu, LinearLayout.LayoutParams(WRAP, WRAP))
        dockHandle.setOnTouchListener { v, ev -> dockTouch(v, ev) }
        viewer.addView(ctlDock, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.START or Gravity.TOP).apply {
            leftMargin = dp(6); topMargin = dp(120)
        })
        navBar = DragBox(this, Link.prefs, "nav").apply {
            orientation = LinearLayout.HORIZONTAL
            background = shape(Color.parseColor("#B3141A21"), 22f)
            setPadding(dp(6), dp(4), dp(6), dp(4))
            visibility = View.GONE
        }
        navInner = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val navScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(navInner)
        }
        navBar.addView(navScroll, LinearLayout.LayoutParams(WRAP, WRAP))
        kbdEt = EditText(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            setTextColor(Color.TRANSPARENT)
            isCursorVisible = false
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            imeOptions = EditorInfo.IME_FLAG_NO_EXTRACT_UI or EditorInfo.IME_FLAG_NO_FULLSCREEN
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(t: CharSequence?, st: Int, c: Int, a: Int) {}
                override fun onTextChanged(t: CharSequence?, st: Int, b: Int, c: Int) {}
                override fun afterTextChanged(e: Editable?) { kbdChanged(e) }
            })
        }
        viewer.addView(kbdEt, FrameLayout.LayoutParams(dp(2), dp(2), Gravity.START or Gravity.BOTTOM))
        dot = TouchDot(this)
        viewer.addView(dot, FrameLayout.LayoutParams(MATCH, MATCH))
        viewer.addView(navBar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER_HORIZONTAL or Gravity.BOTTOM).apply {
            bottomMargin = dp(18)
        })
        viewer.setOnTouchListener { _, ev ->
            if (ev.actionMasked == MotionEvent.ACTION_DOWN && dockMenu.visibility == View.VISIBLE) dockOpen(false)
            if (ctlOn && ev.actionMasked == MotionEvent.ACTION_DOWN && (ev.x < dp(48) || ev.x > viewer.width - dp(48))) updateGestureExclusion(ev.y)
            if (ctlOn && !panLocal) {
                ctlTouch(ev)
            } else {
                scaleDet.onTouchEvent(ev)
                gestDet.onTouchEvent(ev)
            }
            true
        }
        viewer.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
            applyTransform()
            topRow.restore()
            (navBar as? DragBox)?.restore()
            dockRestore()
            updateGestureExclusion()
        }

        root = FrameLayout(this)
        root.setBackgroundColor(C.BG)
        root.addView(home, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(settingsPage, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(pairedPage, FrameLayout.LayoutParams(MATCH, MATCH))
        chatPage = ChatPage(this, { closeChat() }, { sendTo(it) }, { p ->
            val live = Link.peers[p.id]
            connectDialog(p.name, live?.ip ?: p.ip, live?.port ?: p.port, p.pin, p.platform)
        }, { }, { f -> withMic(f) }, { f -> withMicCam(f) }, { on -> setChatFull(on) })
        root.addView(chatPage.view, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(viewer, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    /* ───────────── 安全聊天 ───────────── */
    private fun openChat(p: Paired) {
        ChatNet.start()
        home.visibility = View.GONE; settingsPage.visibility = View.GONE; pairedPage.visibility = View.GONE
        window.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        chatPage.open(p)
    }

    private fun closeChat() {
        chatPage.close()
        window.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN)
        hideKeyboard()
        showPage(home)
    }

    private fun chatVisible() = chatPage.view.visibility == View.VISIBLE

    private var lastGmPhase = "idle"
    private var gmDialog: AlertDialog? = null
    /** 五子棋状态变化：对方邀请 → 弹「接受 / 拒绝」；邀请 / 结束时给提示。接受后棋盘在独立窗口（GomokuActivity）里打开 */
    private fun onGomokuChanged() {
        val st = Gomoku.st
        val ph = st.phase
        if (ph == "invited") {
            if (gmDialog == null) {
                val gid = st.gid
                val nm = Link.pairs().firstOrNull { it.id == st.peerId }?.name ?: "对方"
                gmDialog = AlertDialog.Builder(this).setTitle("智斗五子棋·文房雅趣")
                    .setMessage("「" + nm + "」邀请你来一局「智斗五子棋·文房雅趣」。\n\n同意后会打开独立的棋盘窗口，黑白方已随机分好。")
                    .setCancelable(false)
                    .setPositiveButton("接受") { _, _ -> gmDialog = null; if (Gomoku.st.gid == gid) Gomoku.accept() }
                    .setNegativeButton("拒绝") { _, _ -> gmDialog = null; if (Gomoku.st.gid == gid) Gomoku.decline() }
                    .show()
            }
        } else if (gmDialog != null) { gmDialog?.dismiss(); gmDialog = null }
        if (ph == "inviting" && lastGmPhase != "inviting") android.widget.Toast.makeText(this, "🎮 已向「" + (Link.pairs().firstOrNull { it.id == st.peerId }?.name ?: "对方") + "」发出「智斗五子棋·文房雅趣」邀请，等待对方同意…", android.widget.Toast.LENGTH_SHORT).show()
        if ((ph == "idle" || ph == "ended") && lastGmPhase != ph && st.reason.isNotEmpty()) android.widget.Toast.makeText(this, "🎮 " + st.reason, android.widget.Toast.LENGTH_SHORT).show()
        lastGmPhase = ph
    }

    private var lastCallPhase = "idle"
    /** 通话状态变化：刷新通话条；来电时自动切到对方的聊天页（接听按钮在那里）；结束时提示原因 */
    private fun onCallChanged() {
        val st = VoiceCall.st
        chatPage.refreshCall()
        if (st.phase == "ringing" && lastCallPhase != "ringing" && !viewing) {
            Link.pairs().firstOrNull { it.id == st.peerId }?.let { if (chatPage.peerId != it.id || !chatVisible()) openChat(it) }
        }
        if (st.phase == "idle" && lastCallPhase != "idle" && st.reason.isNotEmpty()) android.widget.Toast.makeText(this, "📞 " + st.reason, android.widget.Toast.LENGTH_SHORT).show()
        lastCallPhase = st.phase
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        openChatFromIntent()
    }

    private fun openChatFromIntent() {
        val id = intent?.getStringExtra("chatPeer") ?: return
        intent.removeExtra("chatPeer")
        Link.pairs().firstOrNull { it.id == id }?.let { openChat(it) }
    }

    /* ───────────── 首页 ───────────── */
    private fun buildHome() {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(20), px(20), px(20), px(24))
        }

        // 顶部：标题 + 设置
        val head = FrameLayout(this)
        val titleCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleCol.addView(txt("瞬流", 34f, C.INK, true))
        titleCol.addView(txt("随时互传 · 极速直达", 15f, C.SUB).apply { setPadding(0, px(10), 0, 0) })
        head.addView(titleCol, fl(WRAP, WRAP, Gravity.START or Gravity.CENTER_VERTICAL))
        val gearCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(px(10), px(6), px(2), px(6))
        }
        gearCol.addView(icon("gear", C.INK), ll(px(28), px(28)))
        gearCol.addView(txt("设置", 12f, C.SUB).apply { setPadding(0, px(5), 0, 0) })
        click(gearCol) { showPage(settingsPage) }
        head.addView(gearCol, fl(WRAP, WRAP, Gravity.END or Gravity.TOP))
        col.addView(head, ll(MATCH, WRAP))

        // 本机动态二维码
        qrSide = min(px(220), resources.displayMetrics.widthPixels - px(110))
        // 卡片内容上下留白一致：卡片顶 → 标题、副标题 → 二维码、二维码 → 卡片底，视觉上都是 24dp
        // （二维码图片自带约 5dp 的白边，所以后两处的实际间距要少 5dp）
        val qrCard = card().apply {
            gravity = Gravity.CENTER
            setPadding(px(20), px(24), px(20), px(22))
        }
        // 标题：整行宽度 + 文字居中 → 横向居中；字体上下的多余留白已去掉，纵向位置才准
        qrCard.addView(txt("本机动态二维码", 18f, C.INK, true).apply {
            gravity = Gravity.CENTER
        }, ll(MATCH, WRAP))
        qrSub = txt("", 13.5f, C.SUB).apply {
            gravity = Gravity.CENTER
        }
        qrCard.addView(qrSub, ll(MATCH, WRAP, 0f, 8))
        qrIv = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.WHITE)
        }
        qrCard.addView(qrIv, ll(qrSide, qrSide, 0f, 19))
        // 当前网络：局域网 / 虚拟局域网（蒲公英等）/ 移动数据。流量下二维码照常可用，这里说明对方怎样才连得上本机
        netTv = txt("", 12.5f, C.SUB).apply {
            gravity = Gravity.CENTER
            setLineSpacing(0f, 1.15f)
        }
        qrCard.addView(netTv, ll(MATCH, WRAP, 0f, 12))
        col.addView(qrCard, ll(MATCH, WRAP, 0f, 22))

        // 扫描设备二维码
        val scanBtn = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = shape(C.PRIMARY, 30f)
        }
        scanBtn.addView(icon("scan", Color.WHITE), ll(px(26), px(26)))
        scanBtn.addView(txt("扫描设备二维码", 18f, Color.WHITE, true).apply { setPadding(px(12), 0, 0, 0) })
        click(scanBtn) { startScan() }
        col.addView(scanBtn, ll(MATCH, px(60), 0f, 16))

        // 两台设备不在一起（比如手机在流量下、电脑在家）：没法当面扫码，就复制 / 粘贴配对链接
        val linkRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        linkRow.addView(softBtn("复制配对链接") { copyPairLink() }, LinearLayout.LayoutParams(0, px(46), 1f))
        linkRow.addView(softBtn("粘贴配对链接") { pastePairLink() }, LinearLayout.LayoutParams(0, px(46), 1f).apply { leftMargin = px(12) })
        col.addView(linkRow, ll(MATCH, WRAP, 0f, 12))

        // 状态（平时隐藏；配对 / 发送 / 投屏时才出现）
        statusCard = card().apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(px(20), px(14), px(14), px(14))
            visibility = View.GONE
        }
        statusTv = txt("", 14f, C.PRIMARY, true).apply { setLineSpacing(0f, 1.15f) }
        statusCard.addView(statusTv, ll(0, WRAP, 1f))
        stopBtn = pill("结束投屏", true) { CastService.current?.shutdown("已手动结束") }
        stopBtn.visibility = View.GONE
        statusCard.addView(stopBtn, LinearLayout.LayoutParams(px(88), px(34)).apply { leftMargin = px(10) })
        col.addView(statusCard, ll(MATCH, WRAP, 0f, 16))

        // 已配对设备
        val pairedCard = card().apply { setPadding(px(20), px(18), px(20), px(20)) }
        val ph = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, px(2), 0, px(2))
        }
        ph.addView(txt("已配对设备", 17f, C.INK, true), ll(0, WRAP, 1f))
        ph.addView(icon("chev", C.INK), ll(px(22), px(22)))
        click(ph) { showPage(pairedPage) }
        pairedCard.addView(ph, ll(MATCH, WRAP))
        peersBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        pairedCard.addView(peersBox, ll(MATCH, WRAP, 0f, 16))
        col.addView(pairedCard, ll(MATCH, WRAP, 0f, 16))

        // 传输记录（有传输时才出现）
        xfersCard = card().apply {
            setPadding(px(20), px(18), px(20), px(14))
            visibility = View.GONE
        }
        val xh = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        xh.addView(txt("传输记录", 17f, C.INK, true), ll(0, WRAP, 1f))
        val clr = txt("清除已结束", 13f, C.SUB).apply { setPadding(px(8), px(4), 0, px(4)) }
        click(clr) { FileXfer.clearFinished() }
        xh.addView(clr)
        xfersCard.addView(xh, ll(MATCH, WRAP))
        xfersBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        xfersCard.addView(xfersBox, ll(MATCH, WRAP))
        col.addView(xfersCard, ll(MATCH, WRAP, 0f, 16))

        // 底部说明
        val foot = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        foot.addView(View(this).apply { setBackgroundColor(C.CARD_LINE) }, ll(0, px(1), 1f))
        foot.addView(txt("传输不限大小 · 原字节无损 · SHA-256 全文件校验", 11f, C.SUB).apply {
            maxLines = 1
            setPadding(px(10), 0, px(10), 0)
        })
        foot.addView(View(this).apply { setBackgroundColor(C.CARD_LINE) }, ll(0, px(1), 1f))
        col.addView(foot, ll(MATCH, WRAP, 0f, 24))

        home = ScrollView(this).apply {
            setBackgroundColor(C.BG)
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(col)
        }
    }

    /* ───────────── 设置页 ───────────── */
    private class SCard(val card: LinearLayout, val sub: TextView)

    private fun topBar(title: String): FrameLayout {
        val bar = FrameLayout(this)
        val back = FrameLayout(this).apply { background = circle(C.BACK) }
        back.addView(icon("back", C.INK), fl(px(22), px(22), Gravity.CENTER))
        click(back) { showPage(home) }
        bar.addView(back, fl(px(44), px(44), Gravity.START or Gravity.CENTER_VERTICAL))
        bar.addView(txt(title, 26f, C.INK, true), fl(WRAP, WRAP, Gravity.CENTER))
        return bar
    }

    private fun settingCard(iconKind: String, title: String, sub: String): SCard {
        val c = card().apply {
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(px(20), px(24), px(20), px(22))
        }
        val ic = FrameLayout(this).apply { background = circle(C.SOFT) }
        ic.addView(icon(iconKind, C.PRIMARY), fl(px(30), px(30), Gravity.CENTER))
        c.addView(ic, ll(px(62), px(62)))
        c.addView(txt(title, 20f, C.INK, true), ll(WRAP, WRAP, 0f, 14))
        val s = txt(sub, 14f, C.SUB).apply { gravity = Gravity.CENTER }
        c.addView(s, ll(WRAP, WRAP, 0f, 8))
        return SCard(c, s)
    }

    private fun bigBtn(text: String, onClick: () -> Unit): TextView = TextView(this).apply {
        this.text = text
        textSize = 17f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        includeFontPadding = false
        setTextColor(Color.WHITE)
        background = shape(C.PRIMARY, 26f)
        click(this, onClick)
    }

    private fun softBtn(text: String, onClick: () -> Unit): TextView = TextView(this).apply {
        this.text = text
        textSize = 15f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        includeFontPadding = false
        setTextColor(C.PRIMARY)
        background = shape(C.SOFT, 23f)
        click(this, onClick)
    }

    private fun halfBtn(text: String, iconKind: String, filled: Boolean, onClick: () -> Unit): LinearLayout {
        val fg = if (filled) Color.WHITE else C.PRIMARY
        val b = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = shape(if (filled) C.PRIMARY else C.SOFT, 16f)
        }
        b.addView(icon(iconKind, fg, iconKind == "folder" && !filled), ll(px(22), px(22)))
        b.addView(txt(text, 16f, fg, true).apply { setPadding(px(8), 0, 0, 0) })
        click(b, onClick)
        return b
    }

    private fun buildSettings() {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(20), px(16), px(20), px(28))
        }
        col.addView(topBar("设置"), ll(MATCH, px(48)))

        // 头像
        val ca = settingCard("user", "头像", "图片原文件无损保存，居中裁成正方形显示")
        avatarIv = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(Color.parseColor("#E3EDF5"))
            clipToOutline = true
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) { o.setOval(0, 0, v.width, v.height) }
            }
        }
        avatarIv.setOnClickListener { Avatar.show(this, Avatar.viewMine(this)) }
        ca.card.addView(avatarIv, ll(px(96), px(96), 0f, 18).apply { gravity = Gravity.CENTER_HORIZONTAL })
        val avRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        avRow.addView(halfBtn("选择图片", "pencil", true) { avatarLauncher.launch("image/*") }, LinearLayout.LayoutParams(0, px(52), 1f))
        avRow.addView(halfBtn("移除头像", "folder", false) { Avatar.clear(this); refreshAvatar() }, LinearLayout.LayoutParams(0, px(52), 1f).apply { leftMargin = px(12) })
        ca.card.addView(avRow, ll(MATCH, WRAP, 0f, 18))
        col.addView(ca.card, ll(MATCH, WRAP, 0f, 16))
        refreshAvatar()

        // 主页介绍
        val cb = settingCard("pencil", "主页介绍", "写一段话介绍自己，已配对并连上的设备能看到")
        bioEt = EditText(this).apply {
            setText(Bio.mine())
            textSize = 15f
            setTextColor(C.INK)
            gravity = Gravity.TOP or Gravity.START
            minLines = 3; maxLines = 6
            background = shape(Color.parseColor("#FCFEFF"), 14f, C.INPUT_LINE, 1.2f)
            setPadding(px(16), px(12), px(16), px(12))
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE or android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            filters = arrayOf(InputFilter.LengthFilter(Bio.MAX_CHARS))
            hint = "例如：喜欢摄影和开源，欢迎互传文件~（最多 ${Bio.MAX_CHARS} 字）"
        }
        cb.card.addView(bioEt, ll(MATCH, WRAP, 0f, 18))
        cb.card.addView(bigBtn("保存介绍") {
            val t = Bio.setMine(bioEt.text.toString())
            bioEt.setText(t); bioEt.clearFocus(); hideKeyboard()
            Toast.makeText(this, if (t.isEmpty()) "已清空主页介绍" else "主页介绍已保存", Toast.LENGTH_SHORT).show()
        }, ll(MATCH, px(52), 0f, 14))
        col.addView(cb.card, ll(MATCH, WRAP, 0f, 16))

        // 设备名称
        val c1 = settingCard("monitor", "设备名称", "在其他设备上显示的名字")
        nameEt = EditText(this).apply {
            setText(Link.name)
            setSingleLine(true)
            textSize = 16f
            setTextColor(C.INK)
            gravity = Gravity.CENTER_VERTICAL
            background = shape(Color.parseColor("#FCFEFF"), 14f, C.INPUT_LINE, 1.2f)
            setPadding(px(16), 0, px(16), 0)
            imeOptions = EditorInfo.IME_ACTION_DONE
            filters = arrayOf(InputFilter.LengthFilter(40))
        }
        c1.card.addView(nameEt, ll(MATCH, px(52), 0f, 18))
        c1.card.addView(bigBtn("保存名称") { saveName() }, ll(MATCH, px(52), 0f, 14))
        col.addView(c1.card, ll(MATCH, WRAP, 0f, 16))

        // 接收目录
        val c2 = settingCard("folder", "接收目录", "")
        dirSub = c2.sub
        val rowBtns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        rowBtns.addView(halfBtn("打开目录", "folder", false) { openRecvDir() }, LinearLayout.LayoutParams(0, px(52), 1f))
        rowBtns.addView(halfBtn("更改目录", "pencil", true) { treeLauncher.launch(null) }, LinearLayout.LayoutParams(0, px(52), 1f).apply { leftMargin = px(12) })
        c2.card.addView(rowBtns, ll(MATCH, WRAP, 0f, 18))
        dirReset = txt("恢复默认目录（下载/${FileXfer.DEFAULT_DIR}）", 13f, C.SUB).apply {
            setPadding(px(10), px(8), px(10), px(4))
            paintFlags = paintFlags or android.graphics.Paint.UNDERLINE_TEXT_FLAG
        }
        click(dirReset) {
            Link.prefs.edit().remove("recv_tree").apply()
            updateSettingsUi()
            Toast.makeText(this, "已恢复默认接收目录", Toast.LENGTH_SHORT).show()
        }
        c2.card.addView(dirReset, ll(WRAP, WRAP, 0f, 8))
        col.addView(c2.card, ll(MATCH, WRAP, 0f, 16))

        // 投屏设置（画质 / 声音）
        val c3 = settingCard("cast", "投屏设置", "手机投屏给其他设备时的画质与声音")
        val qRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = shape(C.SOFT, 14f)
            setPadding(px(16), 0, px(14), 0)
        }
        qRow.addView(txt("画质", 16f, C.INK, true), ll(0, WRAP, 1f))
        presetVal = txt("", 14f, C.SUB)
        qRow.addView(presetVal)
        qRow.addView(icon("chev", C.SUB), ll(px(18), px(18)))
        click(qRow) { pickPreset() }
        c3.card.addView(qRow, ll(MATCH, px(52), 0f, 18))
        presetNote = txt(EXTREME_DESC, 13f, C.BAD).apply {         // 选了第四档「极致无损 Beta」时显示的说明
            setPadding(px(14), px(10), px(14), px(10))
            background = shape(0x14B3541E, 12f)
            visibility = View.GONE
        }
        c3.card.addView(presetNote, ll(MATCH, WRAP, 0f, 10))
        val aRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = shape(C.SOFT, 14f)
            setPadding(px(16), 0, px(14), 0)
        }
        aRow.addView(txt("同时传输手机声音（无损 PCM）", 15f, C.INK, true), ll(0, WRAP, 1f))
        audioSw = Switch(this).apply {
            isChecked = Link.prefs.getBoolean("audio", true)
            trackTintList = ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(C.PRIMARY, C.GRAY))
            setOnCheckedChangeListener { _, c -> Link.prefs.edit().putBoolean("audio", c).apply() }
        }
        aRow.addView(audioSw)
        c3.card.addView(aRow, ll(MATCH, px(52), 0f, 10))
        col.addView(c3.card, ll(MATCH, WRAP, 0f, 16))

        // 后台常驻接收（安卓 ↔ 安卓）
        val c5 = settingCard("phone", "后台常驻接收", "开启后，应用在后台时其他设备也能向本机发文件、扫码配对；对方发起投屏时会弹通知")
        val bRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = shape(C.SOFT, 14f)
            setPadding(px(16), 0, px(14), 0)
        }
        bRow.addView(txt("在通知栏常驻，随时可接收", 15f, C.INK, true), ll(0, WRAP, 1f))
        bgSw = Switch(this).apply {
            isChecked = ListenService.enabled()
            trackTintList = ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(C.PRIMARY, C.GRAY))
            setOnCheckedChangeListener { _, c -> if (c != ListenService.enabled()) ListenService.setEnabled(this@MainActivity, c) }
        }
        bRow.addView(bgSw)
        c5.card.addView(bRow, ll(MATCH, px(52), 0f, 18))
        col.addView(c5.card, ll(MATCH, WRAP, 0f, 16))

        // 网络与跨网络互联（蒲公英 / ZeroTier / Tailscale 等虚拟局域网）
        val c7 = settingCard("globe", "网络与跨网络互联", "")
        netSub = c7.sub
        c7.card.addView(txt("流量下也能配对、互传：先在两台设备上都登录蒲公英（或 ZeroTier / Tailscale）加入同一个虚拟网络，再用首页的「扫描设备二维码」，或「复制 / 粘贴配对链接」（两台设备不在一起时用它）配对。" +
            "已配对的设备会同时记住局域网和虚拟局域网两个地址：在家用 Wi-Fi、出门用流量，都会自动选连得通的那条。\n\n" +
            "建议同时打开上面的「后台常驻接收」，并在系统里允许瞬流在后台运行（电池优化设为「不限制」），否则流量下切到后台后，对方可能连不上本机。", 12.5f, C.SUB).apply {
            setLineSpacing(0f, 1.2f)
            setPadding(px(4), px(14), px(4), 0)
        }, ll(MATCH, WRAP))
        col.addView(c7.card, ll(MATCH, WRAP, 0f, 16))

        // 屏幕控制（被控制端）
        val c6 = settingCard("cursor", "屏幕控制", "")
        ctlSub = c6.sub
        c6.card.addView(bigBtn("去系统设置开启") {
            try { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } catch (e: Exception) {
                Toast.makeText(this, "请在 系统设置 → 无障碍 里开启「瞬流 屏幕控制」", Toast.LENGTH_LONG).show()
            }
        }, ll(MATCH, px(52), 0f, 18))
        c6.card.addView(txt("在「无障碍 → 已下载的应用」里找到「瞬流 屏幕控制」并打开。若提示「受限制的设置」：长按瞬流图标 → 应用信息 → 右上角「⋮」→ 允许受限制的设置，再回来开启。每次被控制前仍会征求你的同意。", 12.5f, C.SUB).apply {
            setLineSpacing(0f, 1.2f)
            setPadding(px(4), px(12), px(4), 0)
        }, ll(MATCH, WRAP))
        col.addView(c6.card, ll(MATCH, WRAP, 0f, 16))

        // 配对密钥
        val c4 = settingCard("refresh", "配对密钥", "刷新后，之前扫过码的设备需要重新扫码")
        val rb = TextView(this).apply {
            text = "刷新二维码"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            includeFontPadding = false
            setTextColor(C.PRIMARY)
            background = shape(C.SOFT, 26f)
        }
        click(rb) { confirmRefreshQr() }
        c4.card.addView(rb, ll(MATCH, px(52), 0f, 18))
        col.addView(c4.card, ll(MATCH, WRAP, 0f, 16))

        val sv = ScrollView(this).apply {
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(col)
        }
        settingsPage = FrameLayout(this).apply {
            setBackgroundColor(C.BG)
            visibility = View.GONE
            addView(sv, FrameLayout.LayoutParams(MATCH, MATCH))
        }
        updateSettingsUi()
    }

    private fun updateSettingsUi() {
        val custom = FileXfer.recvTree() != null
        dirSub.text = if (custom) FileXfer.recvLabel() else "下载/${FileXfer.DEFAULT_DIR}（Download/${FileXfer.DEFAULT_DIR}）"
        dirReset.visibility = if (custom) View.VISIBLE else View.GONE
        presetVal.text = PRESETS[presetIdx()].label + "  "
        PRESETS[presetIdx()].let { p ->
            presetNote.text = p.desc
            presetNote.visibility = if (p.desc.isNotEmpty()) View.VISIBLE else View.GONE
        }
        audioSw.isChecked = audioOn()
        bgSw.isChecked = ListenService.enabled()
        val la = Link.localAddrs()
        netSub.text = if (la.isEmpty()) "未联网" else la.joinToString("\n") {
            it.iface + "   " + it.ip + "   ·   " + when (it.kind) {
                NetX.Kind.LAN -> "局域网"
                NetX.Kind.OVERLAY -> "虚拟局域网"
                NetX.Kind.CELL -> "移动数据"
                else -> "其他"
            }
        }
        ctlSub.text = if (InputService.enabled()) "已开启 · 其他安卓设备经你同意后可以控制本机" else "未开启 · 开启后，其他安卓设备经你同意才能控制本机"
    }

    private fun presetIdx(): Int = Link.prefs.getInt("preset", 0).coerceIn(0, PRESETS.size - 1)
    private fun audioOn(): Boolean = Link.prefs.getBoolean("audio", true)

    private fun pickPreset() {
        AlertDialog.Builder(this)
            .setTitle("投屏画质")
            .setSingleChoiceItems(PRESETS.map { it.label }.toTypedArray(), presetIdx()) { d, which ->
                d.dismiss()
                val p = PRESETS[which]
                if (p.desc.isEmpty()) {
                    Link.prefs.edit().putInt("preset", which).apply()
                    updateSettingsUi()
                } else {                                  // 极致无损（Beta）：先把风险讲清楚，用户确认了才切换
                    AlertDialog.Builder(this)
                        .setTitle(p.label)
                        .setMessage(p.desc + "\n\n原生分辨率、不限帧率、不做任何有损压缩；画面静止时几乎不占带宽，画面大面积变化（如播放视频）时需要很高的网速。")
                        .setPositiveButton("开启") { _, _ ->
                            Link.prefs.edit().putInt("preset", which).apply()
                            updateSettingsUi()
                        }
                        .setNegativeButton("取消", null)
                        .show()
                }
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun refreshAvatar() {
        if (!::avatarIv.isInitialized) return
        val bmp = Avatar.load(this, px(192))      // 2 倍像素，高分屏更清晰
        if (bmp != null) avatarIv.setImageBitmap(bmp)
        else avatarIv.setImageBitmap(Avatar.deviceFace(this, "android", px(192)))      // 没设头像 / 头像解不出来：显示手机图标
    }

    private fun saveName() {
        val n = nameEt.text.toString().trim()
        if (n.isEmpty()) {
            Toast.makeText(this, "设备名称不能为空", Toast.LENGTH_SHORT).show()
            return
        }
        Link.updateName(n)
        nameEt.setText(n)
        nameEt.clearFocus()
        hideKeyboard()
        Toast.makeText(this, "已保存", Toast.LENGTH_SHORT).show()
        drawQr(true)
    }

    private fun openRecvDir() {
        val tries = ArrayList<Intent>()
        val tree = FileXfer.recvTree()
        if (tree != null) {
            try {
                val doc = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
                tries.add(Intent(Intent.ACTION_VIEW).setDataAndType(doc, DocumentsContract.Document.MIME_TYPE_DIR).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
            } catch (ignored: Exception) { }
        } else {
            val doc = Uri.parse("content://com.android.externalstorage.documents/document/" + Uri.encode("primary:Download/" + FileXfer.DEFAULT_DIR))
            tries.add(Intent(Intent.ACTION_VIEW).setDataAndType(doc, DocumentsContract.Document.MIME_TYPE_DIR))
        }
        tries.add(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
        for (i in tries) {
            try {
                startActivity(i)
                return
            } catch (ignored: Exception) { }
        }
        Toast.makeText(this, "请在文件管理器里打开「" + FileXfer.recvLabel() + "」", Toast.LENGTH_LONG).show()
    }

    /* ───────────── 已配对设备页 ───────────── */
    private fun buildPairedPage() {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(20), px(16), px(20), px(28))
        }
        col.addView(topBar("已配对设备"), ll(MATCH, px(48)))
        pairedBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(pairedBox, ll(MATCH, WRAP, 0f, 16))
        val sv = ScrollView(this).apply {
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(col)
        }
        pairedPage = FrameLayout(this).apply {
            setBackgroundColor(C.BG)
            visibility = View.GONE
            addView(sv, FrameLayout.LayoutParams(MATCH, MATCH))
        }
    }

    private fun showPage(p: View) {
        home.visibility = if (p === home) View.VISIBLE else View.GONE
        settingsPage.visibility = if (p === settingsPage) View.VISIBLE else View.GONE
        pairedPage.visibility = if (p === pairedPage) View.VISIBLE else View.GONE
        if (p === settingsPage) {
            nameEt.setText(Link.name)
            updateSettingsUi()
        } else {
            hideKeyboard()
        }
        peersSig = ""
        renderPeers()
    }

    /* ═════════════ 状态 / 设备列表 ═════════════ */
    private fun status(msg: String) {
        statusTv.text = msg
        statusCard.visibility = if (msg.isEmpty()) View.GONE else View.VISIBLE
        ui.removeCallbacks(statusHide)
        ui.postDelayed(statusHide, 10_000)
        refreshUi()
    }

    private fun refreshUi() {
        val casting = CastService.current != null
        stopBtn.visibility = if (casting) View.VISIBLE else View.GONE
        if (casting) {
            if (statusTv.text.isEmpty()) statusTv.text = "正在投屏"
            statusCard.visibility = View.VISIBLE
        }
    }

    private fun refreshPeers() {
        val now = System.currentTimeMillis()
        // 虚拟局域网 / 远程路径上的 UDP 偶尔丢包，掉线判定放宽到 12 秒；同一局域网内仍是 6 秒
        Link.peers.values.removeAll { now - it.seen > (if (Link.isLanPeer(it.ip)) 6000 else 12000) }
        for (p in Link.pairs()) {
            val live = Link.peers[p.id]
            if (live != null && (live.ip != p.ip || live.port != p.port)) Link.savePair(p.copy(ip = live.ip, port = live.port))   // 对方换了 IP，自动跟上
        }
        renderPeers()
    }

    private fun renderPeers() {
        val paired = Link.pairs().sortedBy { it.name }
        val sb = StringBuilder()
        for (p in paired) {
            val live = Link.peers[p.id]
            sb.append(ChatNet.hub.unread(p.id)).append('#').append(p.id).append('|').append(p.name).append('|').append(live?.ip ?: p.ip).append('|').append(live != null).append('|').append(Avatar.peerHash(this, p.id)).append(Bio.peer(p.id).hashCode()).append(';')
        }
        sb.append(pairedPage.visibility)
        val sig = sb.toString()
        if (sig == peersSig) return          // 没变化就不重建，避免点按时闪烁
        peersSig = sig

        peersBox.removeAllViews()
        if (paired.isEmpty()) {
            peersBox.addView(txt("还没有配对的设备", 15f, C.INK, true))
            peersBox.addView(txt("点上方「扫描设备二维码」，扫描另一台设备（电脑或手机）上瞬流显示的二维码即可配对；不在一起时用「粘贴配对链接」。", 13f, C.SUB).apply {
                setLineSpacing(0f, 1.2f)
                setPadding(0, px(8), 0, 0)
            })
        } else {
            for ((i, p) in paired.take(3).withIndex()) {
                if (i > 0) peersBox.addView(View(this).apply { setBackgroundColor(C.CARD_LINE) }, ll(MATCH, px(1), 0f, 14))
                peersBox.addView(deviceRow(p, false), ll(MATCH, WRAP, 0f, if (i > 0) 14 else 0))
            }
        }

        pairedBox.removeAllViews()
        if (paired.isEmpty()) {
            pairedBox.addView(txt("还没有配对的设备。回到首页，点「扫描设备二维码」，扫描另一台设备（电脑或手机）上瞬流显示的二维码。", 14f, C.SUB).apply {
                setLineSpacing(0f, 1.2f)
                setPadding(px(4), px(8), px(4), 0)
            })
        } else {
            for (p in paired) {
                val c = card().apply { setPadding(px(20), px(18), px(20), px(18)) }
                c.addView(deviceRow(p, true), ll(MATCH, WRAP))
                pairedBox.addView(c, ll(MATCH, WRAP, 0f, 14))
            }
        }
    }

    private fun deviceRow(p: Paired, full: Boolean): View {
        val live = Link.peers[p.id]
        val online = live != null
        val ip = live?.ip ?: p.ip
        val port = live?.port ?: p.port
        val isWin = p.platform == "windows"

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val av = FrameLayout(this).apply { background = circle(C.SOFT) }
        val pavBmp = Avatar.peerCircle(this, p.id, px(104))
        if (pavBmp != null) { av.background = android.graphics.drawable.BitmapDrawable(resources, pavBmp); av.setOnClickListener { Avatar.show(this, Avatar.viewPeer(this, p.id)) } }
        else av.addView(icon(if (isWin) "windows" else "phone", if (isWin) C.WIN_BLUE else C.PRIMARY), fl(px(26), px(26), Gravity.CENTER))
        row.addView(av, ll(px(52), px(52)))

        val mid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(12), 0, px(8), 0)
        }
        mid.addView(txt(p.name, 17f, C.INK, true).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        })
        val st = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, px(6), 0, 0)
        }
        st.addView(View(this).apply { background = circle(if (online) C.GREEN else C.GRAY) }, ll(px(8), px(8)))
        st.addView(txt(if (isWin) "Windows 设备" else "安卓设备", 13f, C.SUB).apply { setPadding(px(6), 0, 0, 0) })
        mid.addView(st)
        mid.addView(txt(if (online) Link.pathLabel(ip) + " · 设备在线" else "设备离线", 12.5f, C.SUB).apply {
            maxLines = 1
            setPadding(0, px(6), 0, 0)
        })
        val peerBio = Bio.peer(p.id)
        if (peerBio.isNotEmpty()) mid.addView(txt(peerBio, 12.5f, C.INK).apply {
            maxLines = 2
            ellipsize = TextUtils.TruncateAt.END
            setPadding(px(10), px(6), px(10), px(6))
            background = shape(Color.parseColor("#1A2F80B0"), 8f)
            setOnClickListener {
                android.app.AlertDialog.Builder(this@MainActivity).setTitle(p.name + " 的主页介绍").setMessage(peerBio).setPositiveButton("好", null).show()
            }
        })
        row.addView(mid, ll(0, WRAP, 1f))

        val btns = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val un = ChatNet.hub.unread(p.id)
        btns.addView(pill(if (un > 0) "聊天 ($un)" else "聊天", true) { openChat(p) }, ll(px(92), px(32)))
        btns.addView(pill("发送文件", false) { sendTo(p) }, ll(px(92), px(32), 0f, 7))
        btns.addView(pill("屏幕互投", false) { connectDialog(p.name, ip, port, p.pin, p.platform) }, ll(px(92), px(32), 0f, 7))
        if (isWin) btns.addView(pill(if (MusicService.running()) "停止沉浸音乐" else "沉浸音乐", false) { musicEntry(p, ip, port) }, ll(px(92), px(32), 0f, 7))
        if (full) btns.addView(pill("取消配对", false, true) { confirmUnpair(p) }, ll(px(92), px(32), 0f, 7))
        row.addView(btns)
        row.setOnLongClickListener { confirmUnpair(p); true }
        return row
    }

    override fun onPeers() = refreshPeers()
    override fun onStatus(msg: String) {
        status(msg)
        if (msg.startsWith("沉浸音乐")) { peersSig = ""; refreshPeers() }          // 按钮在「沉浸音乐 / 停止沉浸音乐」之间切换
    }

    /** 本机网络变了（Wi-Fi / 移动数据 / 蒲公英 VPN 开关）：马上刷新二维码、网络状态和设备在线路径 */
    override fun onNetwork() {
        drawQr(true)
        updateQrSub()
        updateSettingsUi()
        peersSig = ""
        renderPeers()
    }

    /* ═════════════ 文件互传 ═════════════ */
    private fun sendTo(p: Paired) {
        pendingTarget = p
        val want = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= 33) {
            want.add(Manifest.permission.READ_MEDIA_IMAGES)
            want.add(Manifest.permission.READ_MEDIA_VIDEO)
        } else {
            want.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        want.add(Manifest.permission.ACCESS_MEDIA_LOCATION)
        val missing = want.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        // 每个缺的权限只主动请求一次，用户拒绝后不再反复打扰（发送时仍会提示位置信息可能被系统抹掉）
        if (missing.isNotEmpty() && !Link.prefs.getBoolean("media_perm_asked", false)) {
            Link.prefs.edit().putBoolean("media_perm_asked", true).apply()
            mediaPermLauncher.launch(missing.toTypedArray())
        } else {
            pickLauncher.launch(arrayOf("*/*"))
        }
    }

    private fun doSend(p: Paired, uris: List<Uri>) {
        val live = Link.peers[p.id]
        val host = live?.ip ?: p.ip
        val port = live?.port ?: p.port
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        FileXfer.sendFiles(host, port, p.pin, p.name, uris, p.id)
        status("正在向「" + p.name + "」发送 " + uris.size + " 个文件")
    }

    private fun makeRow(x: Xfer): XRow {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, px(14), 0, px(4))
        }
        val name = txt("", 14f, C.INK, true).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.MIDDLE
        }
        val info = txt("", 12f, C.SUB).apply {
            setLineSpacing(0f, 1.15f)
            setPadding(0, px(4), 0, px(8))
        }
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000
            progressTintList = ColorStateList.valueOf(C.PRIMARY)
            progressBackgroundTintList = ColorStateList.valueOf(C.SOFT)
        }
        val btn = pill("取消", false) { FileXfer.cancel(x) }
        box.addView(name, ll(MATCH, WRAP))
        box.addView(info, ll(MATCH, WRAP))
        box.addView(bar, ll(MATCH, px(6)))
        box.addView(btn, ll(px(72), px(30), 0f, 10))
        return XRow(box, name, info, bar, btn)
    }

    private fun xferText(x: Xfer): String {
        return when (x.state) {
            "queued" -> "排队中"
            "offering" -> if (x.msg.isEmpty()) "等待对方确认…" else x.msg
            "sending", "receiving" -> {
                val pct = if (x.size > 0L) x.done.toDouble() * 100.0 / x.size.toDouble() else 100.0
                var t = "%.1f%% · %s / %s".format(pct, FileXfer.human(x.done), FileXfer.human(x.size))
                if (x.speed > 1.0) {
                    t += " · " + FileXfer.human(x.speed.toLong()) + "/s"
                    val left = ((x.size - x.done).toDouble() / x.speed).toLong()
                    t += " · 剩余 " + (if (left >= 3600L) (left / 3600L).toString() + " 小时 " + (left % 3600L / 60L).toString() + " 分" else if (left >= 60L) (left / 60L).toString() + " 分 " + (left % 60L).toString() + " 秒" else left.toString() + " 秒")
                }
                if (x.msg.isNotEmpty()) t += " · " + x.msg
                t
            }
            "verifying" -> if (x.msg.isEmpty()) "校验中…" else x.msg
            "done" -> x.msg + " · " + FileXfer.human(x.size)
            else -> x.msg
        }
    }

    private fun renderXfers() {
        val list = FileXfer.list
        xfersCard.visibility = if (list.isEmpty()) View.GONE else View.VISIBLE
        val seen = HashSet<Xfer>()
        var idx = 0
        for (x in list) {
            seen.add(x)
            val r = xRows[x] ?: makeRow(x).also { xRows[x] = it }
            r.name.text = (if (x.send) "↑ " else "↓ ") + x.name + "  ·  " + x.peer
            r.info.text = xferText(x)
            r.info.setTextColor(if (x.state == "failed") C.BAD else if (x.state == "done") C.OK else C.SUB)
            r.bar.progress = if (x.size > 0L) Math.min(1000L, x.done * 1000L / x.size).toInt() else (if (x.state == "done") 1000 else 0)
            r.btn.visibility = if (x.active) View.VISIBLE else View.GONE
            if (xfersBox.getChildAt(idx) !== r.box) {
                (r.box.parent as? ViewGroup)?.removeView(r.box)
                xfersBox.addView(r.box, idx)
            }
            idx++
        }
        val iter = xRows.entries.iterator()
        while (iter.hasNext()) {
            val ent = iter.next()
            if (!seen.contains(ent.key)) {
                xfersBox.removeView(ent.value.box)
                iter.remove()
            }
        }
    }

    /* ═════════════ 连接 ═════════════ */
    private fun connectDialog(title: String, host: String, port: Int, pin: String, platform: String) {
        val android = platform == "android"
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(host + " · 请选择要做什么（查看时可申请控制对方" + (if (android) "手机" else "电脑") + "）")
            .setPositiveButton("查看对方屏幕") { _, _ -> viewPeer(host, port, pin, true) }
            .setNegativeButton("投出我的屏幕") { _, _ -> pushPeer(host, port, pin, true) }
            .setNeutralButton("取消", null)
            .show()
    }

    private fun confirmUnpair(p: Paired) {
        AlertDialog.Builder(this)
            .setTitle("取消配对")
            .setMessage("确定取消与「" + p.name + "」的配对吗？之后需要重新扫码才能再连接。")
            .setPositiveButton("取消配对") { _, _ ->
                Link.forgetPair(p.id)
                VoiceCall.peerGone(p.id)
                Gomoku.peerGone(p.id)
                peersSig = ""
                refreshPeers()
            }
            .setNegativeButton("保留", null)
            .show()
    }

    /* ═════════════ 扫码配对 / 本机二维码 ═════════════ */
    private fun startScan() {
        val o = ScanOptions()
        o.setDesiredBarcodeFormats(listOf("QR_CODE"))
        o.setPrompt("")
        o.setBeepEnabled(false)
        o.setOrientationLocked(false)
        scanLauncher.launch(o)
    }

    private fun onScanned(text: String) {
        val q = Link.parseQr(text)
        if (q == null) {
            Toast.makeText(this, "这不是瞬流的配对二维码 / 配对链接", Toast.LENGTH_LONG).show()
            return
        }
        if (q.id == Link.id) {
            Toast.makeText(this, "这是本机自己的二维码 / 链接，请用另一台设备上的", Toast.LENGTH_LONG).show()
            return
        }
        status("正在与「" + q.name + "」配对…")
        thread(isDaemon = true) {
            try {
                val p = Link.pairWith(q)
                runOnUiThread {
                    status("已与「" + p.name + "」配对成功：现在可以互传文件、互相投屏了")
                    refreshPeers()
                    Toast.makeText(this, "配对成功", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                runOnUiThread { status("配对失败：" + (e.message ?: "未知错误")) }
            }
        }
    }

    /** 重新读取本机局域网 IP 并生成二维码；内容没变就不重画。 */
    private fun drawQr(force: Boolean) {
        /* 以前只认 Wi-Fi 局域网，流量下没有地址、二维码直接灰掉。现在：局域网和虚拟局域网（蒲公英等）的地址都放进二维码，
         * 只有移动数据时放移动数据的地址——二维码照常可用，对方在同一个虚拟局域网里就能连上；只有完全没网才灰掉。 */
        val st = Link.netState()
        qrNoNet = st.none
        netTv.text = NetX.summary(st)
        netTv.setTextColor(if (st.onlyCell || st.none) C.BAD else C.SUB)
        qrIv.alpha = if (qrNoNet) 0.25f else 1f
        val text = Link.pairText()
        if (!force && text == qrLast) return
        try {
            qrIv.setImageBitmap(makeQr(text, qrSide))
            qrLast = text
        } catch (ignored: Exception) { }
    }

    private fun updateQrSub() {
        qrSub.text = if (qrNoNet) "未联网 · 请连接 Wi-Fi 或打开移动数据" else "$qrLeft 秒后自动刷新 · 扫码一次, 双向互通"
    }

    /** 复制本机的配对链接（内容和二维码完全一样）：两台设备不在一起时发给对方，对方点「粘贴配对链接」即可。 */
    private fun copyPairLink() {
        if (Link.netState().none) {
            Toast.makeText(this, "本机现在没有可用的网络地址，没法生成配对链接", Toast.LENGTH_LONG).show()
            return
        }
        try {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("瞬流配对链接", Link.pairText()))
        } catch (e: Exception) {
            Toast.makeText(this, "复制失败：" + (e.message ?: "未知错误"), Toast.LENGTH_LONG).show()
            return
        }
        AlertDialog.Builder(this)
            .setTitle("已复制配对链接")
            .setMessage("把它发给另一台设备，在对方的瞬流里点「粘贴配对链接」（电脑端：展开「跨网络互联」再粘贴）。\n\n" +
                "两台设备不在同一个局域网时，请先在两边都登录蒲公英（或 ZeroTier / Tailscale）加入同一个虚拟网络。\n\n" +
                "链接里含配对密钥，请只发给你信任的人；之后在设置里刷新二维码，旧链接就失效。")
            .setPositiveButton("知道了", null)
            .show()
    }

    /** 粘贴对方的配对链接（对方点「复制配对链接」得到的）：和扫码配对完全一样，但不用面对面。 */
    private fun pastePairLink() {
        var clip = ""
        try {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            clip = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(this)?.toString() ?: ""
        } catch (ignored: Exception) { }
        val et = EditText(this).apply {
            hint = "lancast://pair?…"
            textSize = 14f
            minLines = 2
            maxLines = 4
            setText(if (Link.parseQr(clip) != null) clip else "")
        }
        val box = FrameLayout(this).apply { setPadding(px(20), px(8), px(20), 0) }
        box.addView(et, FrameLayout.LayoutParams(MATCH, WRAP))
        AlertDialog.Builder(this)
            .setTitle("粘贴配对链接")
            .setMessage("在另一台设备上点「复制配对链接」，把链接粘贴到这里。")
            .setView(box)
            .setPositiveButton("配对") { _, _ -> onScanned(et.text.toString()) }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun confirmRefreshQr() {
        AlertDialog.Builder(this)
            .setTitle("刷新二维码")
            .setMessage("会更换本机的配对密钥。刷新后，之前扫过码的设备需要重新扫码才能连接本机。")
            .setPositiveButton("刷新") { _, _ ->
                Link.newPin()
                qrLeft = QR_CYCLE
                drawQr(true)
                updateQrSub()
                status("配对密钥已刷新，之前扫过码的设备需要重新扫码")
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun makeQr(text: String, size: Int): Bitmap {
        val hints = HashMap<EncodeHintType, Any>()
        hints[EncodeHintType.CHARACTER_SET] = "UTF-8"
        hints[EncodeHintType.MARGIN] = 1
        val bm = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size, hints)
        val w = bm.width
        val h = bm.height
        val px = IntArray(w * h)
        for (y in 0 until h) {
            for (x in 0 until w) px[y * w + x] = if (bm.get(x, y)) Color.BLACK else Color.WHITE
        }
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bmp.setPixels(px, 0, w, 0, 0, w, h)
        return bmp
    }

    /** 查看对方屏幕（手机作接收端） */
    private fun viewPeer(host: String, port: Int, pin: String, askCtl: Boolean) {
        if (Link.busy) { Toast.makeText(this, "正忙，请先结束当前会话", Toast.LENGTH_SHORT).show(); return }
        Link.busy = true
        status("连接中，等待对方允许…")
        thread(isDaemon = true) {
            try {
                val se = Session.connect(host, port, pin, "pull", Link.name, if (askCtl) "req" else "")
                runOnUiThread { enterViewer(se) }
            } catch (e: Exception) {
                Link.busy = false
                runOnUiThread { status("连接失败：${e.message}") }
            }
        }
    }

    /** 把手机屏幕投给对方（手机作发送端）：先申请权限和录屏授权，再由前台服务去连接 */
    private fun pushPeer(host: String, port: Int, pin: String, offerCtl: Boolean) {
        if (Link.busy) { Toast.makeText(this, "正忙，请先结束当前会话", Toast.LENGTH_SHORT).show(); return }
        if (!offerCtl) {
            Link.busy = true
            beginCast(CastReq("push", host, port, pin))
            return
        }
        AlertDialog.Builder(this)
            .setTitle("投出我的屏幕")
            .setMessage("要允许对方控制本机吗？" + (if (InputService.enabled()) "" else "\n\n本机还没开启「屏幕控制」服务（设置 → 屏幕控制），开启前对方只能看。") +
                "\n\n控制期间通知栏有「结束」按钮，可随时终止。")
            .setPositiveButton("允许控制") { _, _ -> Link.busy = true; beginCast(CastReq("push", host, port, pin, true)) }
            .setNegativeButton("仅投屏") { _, _ -> Link.busy = true; beginCast(CastReq("push", host, port, pin, false)) }
            .setNeutralButton("取消", null)
            .show()
    }

    private fun beginCast(req: CastReq) {
        pendingCast = req
        val need = ArrayList<String>()
        if (audioOn() && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (need.isEmpty()) launchProjection() else permLauncher.launch(need.toTypedArray())
    }

    private fun launchProjection() {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projLauncher.launch(mpm.createScreenCaptureIntent())
    }

    /* ───────── 沉浸音乐（只传声音 + 歌曲信息，不采集屏幕；息屏不中断，见 MusicService.kt / docs/PROTOCOL.md 第 23 节） ───────── */
    private var musicPeer = ""

    private fun batteryIgnored(): Boolean = try {
        (getSystemService(POWER_SERVICE) as android.os.PowerManager).isIgnoringBatteryOptimizations(packageName)
    } catch (e: Exception) { true }

    private fun musicEntry(p: Paired, ip: String, port: Int) {
        if (MusicService.running()) {
            MusicService.stop(this)
            status("正在结束沉浸音乐…")
            return
        }
        val listener = MusicMeta.granted(this)
        val battery = batteryIgnored()
        val sb = StringBuilder("把手机正在播放的音乐无损地传到「${p.name}」，电脑上显示实时播放器（歌名、封面、进度），还能从电脑控制播放。")
        sb.append("\n\n全程不采集屏幕：息屏、锁屏后照常播放；网络断了会自动重连并补发缓存的音频，不丢音。")
        sb.append("\n\n先在手机上用音乐 App 播放；个别 App 禁止被采集声音，那种歌只能静音传输。")
        if (!listener) sb.append("\n\n⚠ 还没开启「通知使用权」：声音能传，但电脑上看不到歌名封面，也不能从电脑控制。")
        if (!battery) sb.append("\n\n⚠ 建议把瞬流的电池优化设为「不受限制」：否则手机长时间息屏后，系统可能掐断网络。")
        val b = AlertDialog.Builder(this).setTitle("沉浸音乐").setMessage(sb.toString())
            .setPositiveButton("开始") { _, _ -> beginMusic(p, ip, port) }
        if (!listener) b.setNeutralButton("开启通知使用权") { _, _ ->
            try { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) } catch (ignored: Exception) { }
        }
        if (!battery) b.setNegativeButton("取消电池限制") { _, _ ->
            try {
                startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            } catch (e: Exception) {
                try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (ignored: Exception) { }
            }
        } else b.setNegativeButton("取消", null)
        b.show()
    }

    private fun beginMusic(p: Paired, ip: String, port: Int) {
        musicPeer = p.name
        pendingCast = CastReq("music", ip, port, p.pin, false)
        val need = ArrayList<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (need.isEmpty()) launchProjection() else permLauncher.launch(need.toTypedArray())     // 授权后 permLauncher 回调会接着弹系统的「录制」确认
    }

    private fun onProjection(code: Int, data: Intent?) {
        val req = pendingCast ?: return
        pendingCast = null
        if (req.mode == "music") {                    // 沉浸音乐：不占用投屏会话（不动 Link.busy）
            if (code != Activity.RESULT_OK || data == null) { status("已取消"); return }
            ContextCompat.startForegroundService(this, Intent(this, MusicService::class.java).apply {
                putExtra("code", code)
                putExtra("data", data)
                putExtra("host", req.host)
                putExtra("port", req.port)
                putExtra("pin", req.pin)
                putExtra("peer", musicPeer)
            })
            status("正在启动沉浸音乐…")
            return
        }
        if (code != Activity.RESULT_OK || data == null) {
            Link.busy = false
            Link.pendingPull?.let { s -> Link.pendingPull = null; thread { s.reject("手机用户没有授权录屏") } }
            status("已取消")
            return
        }
        val withAudio = audioOn() && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val i = Intent(this, CastService::class.java).apply {
            putExtra("code", code)
            putExtra("data", data)
            putExtra("mode", req.mode)
            putExtra("host", req.host)
            putExtra("port", req.port)
            putExtra("pin", req.pin)
            putExtra("ctl", req.ctl)
            putExtra("audio", withAudio)
            putExtra("preset", presetIdx())
        }
        ContextCompat.startForegroundService(this, i)
        status("正在启动投屏…")
    }

    /** 有设备连进来（Link 在主线程回调）。返回 true 表示接管。 */
    override fun onIncoming(s: Session): Boolean {
        if (Link.busy || isFinishing) return false
        Link.busy = true
        when (s.mode) {
            "push" -> thread(isDaemon = true) {          // 对方把屏幕投给我：直接进入观看
                try {
                    s.accept()
                    runOnUiThread { enterViewer(s) }
                } catch (e: Exception) {
                    Link.busy = false
                }
            }
            "pull" -> {                                  // 对方想看我的屏幕：必须本人点允许
                val go = { ctl: Boolean ->
                    s.ctlAllowed = ctl
                    Link.pendingPull = s
                    beginCast(CastReq("pull"))
                }
                val b = AlertDialog.Builder(this).setTitle("屏幕共享请求").setCancelable(false)
                if (s.ctlReq) {
                    b.setMessage("「${s.peerName}」请求查看并控制本机屏幕。" +
                        (if (InputService.enabled()) "" else "\n\n本机还没开启「屏幕控制」服务（设置 → 屏幕控制），开启前对方只能查看。") +
                        "\n\n控制期间通知栏有「结束」按钮，可随时终止。")
                        .setPositiveButton("允许查看并控制") { _, _ -> go(true) }
                        .setNeutralButton("仅允许查看") { _, _ -> go(false) }
                } else {
                    b.setMessage("「${s.peerName}」请求查看本机屏幕，允许吗？")
                        .setPositiveButton("允许") { _, _ -> go(false) }
                }
                b.setNegativeButton("拒绝") { _, _ ->
                    Link.busy = false
                    thread { s.reject("对方拒绝了请求") }
                }.show()
            }
            else -> {
                Link.busy = false
                thread { s.reject("未知模式") }
            }
        }
        return true
    }

    /* ═════════════ 观看窗口 ═════════════ */
    private fun enterViewer(se: Session) {
        Link.busy = true
        viewing = true
        viewSession = se
        topRow.resetHidden(); (navBar as? DragBox)?.resetHidden()
        ctlBtn.visibility = if (se.canControl) View.VISIBLE else View.GONE
        desk = true
        peerWin = se.peerPlatform.equals("windows", ignoreCase = true)
        panLocal = false
        deskPad = Link.prefs.getBoolean("deskPad", false)
        fillNav()
        setControl(false)
        vw = 0; vh = 0; mode = 0; panX = 0f; panY = 0f; manualRel = 1f
        home.visibility = View.GONE
        settingsPage.visibility = View.GONE
        pairedPage.visibility = View.GONE
        viewer.visibility = View.VISIBLE
        applyImmersive(true)
        val t = TextureView(this)
        tv = t
        viewer.addView(t, 0, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        statsTv.text = "等待画面…"
        Link.holdWifi(true)
        val s = ScreenSink(se, t, { w, h -> vw = w; vh = h; applyTransform() }, { r -> exitViewer(r) }, { txt -> statsTv.text = txt })
        sink = s
        s.start()
        Toast.makeText(this, "双击或捏合：完整显示 / 铺满；单指拖动可平移", Toast.LENGTH_LONG).show()
    }

    /** 「全屏」：切到横屏，画面（尤其是横屏的电脑画面）铺得更大；再点一次恢复自动旋转。 */
    private fun setFullLand(on: Boolean) {
        fullLand = on
        syncOrientation()
        fullBtn.text = if (on) "退出全屏" else "全屏"
        if (::dockFull.isInitialized) dockFull.text = fullBtn.text
    }

    /** 方向只由两个「全屏」决定：投屏观看的全屏 / 视频通话的全屏，任何一个开着就锁横屏（传感器决定哪一边），都关了才恢复自动旋转 */
    private fun syncOrientation() {
        requestedOrientation = if (fullLand || (chatFullOn && VIDEO_FULL_LANDSCAPE)) android.content.pm.ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        else android.content.pm.ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    }

    /** 视频通话「全屏」（ChatPage 回调）：和投屏观看窗口同一套 —— 状态栏 / 导航栏全部收起（边缘滑动才临时露出）、刘海区也铺满、屏幕常亮、横屏。 */
    private fun setChatFull(on: Boolean) {
        chatFullOn = on
        syncOrientation()
        applyImmersive(on || viewing)
    }

    /** 系统栏被临时唤出 / 切回前台后可能还在：全屏期间一回到前台就再收一次 */
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && chatFullOn && !viewing) WindowCompat.getInsetsController(window, window.decorView).hide(WindowInsetsCompat.Type.systemBars())
    }

    private fun exitViewer(reason: String) {
        if (!viewing) return
        setFullLand(false)
        topRow.resetHidden(); (navBar as? DragBox)?.resetHidden()
        viewing = false
        setControl(false)
        setKeyboard(false)
        ctlBtn.visibility = View.GONE
        viewSession = null
        val s = sink
        sink = null
        s?.stop(reason)
        tv?.let { viewer.removeView(it) }
        tv = null
        viewer.visibility = View.GONE
        showPage(home)
        applyImmersive(chatFullOn)             // 视频通话全屏还开着的话，保持沉浸式
        Link.holdWifi(false)
        Link.busy = false
        status(reason)
    }

    /* ═════════════ 屏幕控制（观看方）═════════════
     * 控制模式下画面固定「完整显示」，单指的一笔触摸被记录成 [x,y,ms] 序列，抬手时作为一条 T_INPUT 发给对方，
     * 对方的无障碍服务按原速度回放（点按 / 滑动 / 长按都是同一种指令）。坐标用相对画面的 0..1，与分辨率、旋转无关。 */
    private fun setControl(on: Boolean) {
        flushPendingUp()                                        // 还没发出去的「抬起」先发掉，免得对方的鼠标键一直按着
        if (desk && dkBtn) deskLeft(false, curN)                // 退出控制时别让对方的鼠标键一直按着
        ctlOn = on && viewSession?.canControl == true
        ctlBtn.text = if (ctlOn) "退出控制" else "控制"
        navBar.visibility = if (ctlOn && !desk) View.VISIBLE else View.GONE     // 控制电脑：底部按钮栏会盖住任务栏开始按钮，并入左侧圆点菜单
        val dockMode = ctlOn && desk                            // 控制电脑：顶栏收成左侧小圆点，把画面右上角（最小化 / 最大化 / 关闭）还给电脑
        topRow.visibility = if (dockMode) View.GONE else View.VISIBLE
        ctlDock.visibility = if (dockMode) View.VISIBLE else View.GONE
        dockOpen(false)
        if (dockMode) ctlDock.post { dockRestore() }
        strokeBuf.clear()
        ctlDown = false
        ui.removeCallbacks(keepAlive)
        deskReset()
        panLocal = false
        if (!ctlOn) setKeyboard(false)
        fillNav()
        dot.hide()
        if (ctlOn) { mode = 1; panX = 0f; panY = 0f }
        applyTransform()
        updateGestureExclusion()
        showCursorDot()
        if (ctlOn) {
            Toast.makeText(this,
                "控制" + (if (peerWin) "电脑" else "手机") + "：轻点 = 左键，长按 = 右键，两指滑动 = 滚轮，两指轻点 = 右键。所有按钮都收在左侧「≡」圆点里：点开可切换触控 / 触控板、回桌面、打字、全屏、退出控制、断开，拖动圆点可换位置",
                Toast.LENGTH_LONG).show()
        }
    }

    private fun sendInput(j: JSONObject) {
        val s = viewSession ?: return
        if (pendingUp != null && j.optString("t") != "h") flushPendingUp()     // 前一次点击的「抬起」必须排在后面所有指令之前
        if (s.alive) s.sendHi(P.jsonPkt(P.T_INPUT, j))
    }

    /** 把触摸点换算成对方画面里的 0..1 坐标；落在画面外（黑边）返回 null。 */
    private fun norm(x: Float, y: Float): FloatArray? {
        val g = geom() ?: return null
        val dw = vw * g[0] * g[2]
        val dh = vh * g[0] * g[2]
        val nx = (x - (viewer.width - dw) / 2f - panX) / dw
        val ny = (y - (viewer.height - dh) / 2f - panY) / dh
        if (nx < 0f || nx > 1f || ny < 0f || ny > 1f) return null
        return floatArrayOf(nx, ny)
    }

    /** 控制电脑时的「边缘补偿」。手机屏幕最边上那一小条常被系统占用（顶部下拉状态栏 / 底部上滑回主页 / 两侧返回手势 / 防误触），
     *  手指根本碰不到最上面一行，于是电脑窗口的最小化 / 最大化 / 关闭、任务栏就像隔着一堵墙。
     *  做法：手指进入距屏幕边缘 10dp 以内就当作贴着边；10~24dp 之间把画面边缘那一带线性拉伸开（连续、单调），24dp 以外原样，
     *  所以画面中间的点击精度不受影响，边缘一带最多偏差几个 dp（比「碰不到」强得多）。 */
    private fun edgeFix(v: Float, len: Float): Float {
        if (!(desk && ctlOn)) return v
        val e = dp(10).toFloat()
        val a = dp(24).toFloat()
        if (len <= a * 2f + 1f) return v
        return when {
            v <= e -> 0f
            v < a -> (v - e) * a / (a - e)
            v >= len - e -> len
            v > len - a -> len - (len - e - v) * a / (a - e)
            else -> v
        }
    }

    /** 同 [norm]，但手指在画面外时不返回 null，而是夹到最近的边上；离画面超过 tol 像素才返回 null。
     *  以前只要手指滑出画面（黑边 / 屏幕边缘）这一点就被丢弃，对方光标停在原地——这就是「顶上有堵墙、够不到最小化按钮」的一半原因。 */
    private fun normNear(rx: Float, ry: Float, tol: Float): FloatArray? {
        val g = geom() ?: return null
        val x = edgeFix(rx, viewer.width.toFloat())
        val y = edgeFix(ry, viewer.height.toFloat())
        val dw = vw * g[0] * g[2]
        val dh = vh * g[0] * g[2]
        val left = (viewer.width - dw) / 2f + panX
        val top = (viewer.height - dh) / 2f + panY
        if (x < left - tol || x > left + dw + tol || y < top - tol || y > top + dh + tol) return null
        return floatArrayOf(((x - left) / dw).coerceIn(0f, 1f), ((y - top) / dh).coerceIn(0f, 1f))
    }

    private fun normClamp(x: Float, y: Float): FloatArray? = normNear(x, y, 1e9f)

    private fun r4(v: Float): Double = Math.round(v * 10000f) / 10000.0

    private fun flushMoves() {
        if (strokeBuf.isEmpty()) return
        val arr = JSONArray()
        for (p in strokeBuf) arr.put(JSONArray().put(r4(p[0])).put(r4(p[1])).put(p[2].toLong()))
        strokeBuf.clear()
        lastSendT = SystemClock.uptimeMillis()
        sendInput(JSONObject().put("t", "m").put("i", ctlSid).put("p", arr))
    }

    private val keepAlive = object : Runnable {            // 按住不动时每 500ms 告诉对方「手指还在」，对方才不会误判掉线
        override fun run() {
            if (!ctlDown) return
            if (SystemClock.uptimeMillis() - lastSendT >= 400L) {
                lastSendT = SystemClock.uptimeMillis()
                sendInput(JSONObject().put("t", "h").put("i", ctlSid))
            }
            ui.postDelayed(this, 500L)
        }
    }

    private fun endStroke(ev: MotionEvent) {
        if (!ctlDown) return
        flushMoves()
        val n = normClamp(ev.x, ev.y) ?: lastNorm
        if (n != null) sendInput(JSONObject().put("t", "u").put("i", ctlSid).put("x", r4(n[0])).put("y", r4(n[1])).put("d", ev.eventTime - strokeT0))
        ctlDown = false
        ui.removeCallbacks(keepAlive)
        dot.hide()
    }

    /** 实时跟手：按下 / 移动（批量，约 12ms 一包）/ 抬起，逐步发给对方，对方用连续笔画同步执行。 */
    private fun ctlTouch(ev: MotionEvent) {
        if (desk) deskTouch(ev) else phoneTouch(ev)
    }

    private fun phoneTouch(ev: MotionEvent) {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val n = normNear(ev.x, ev.y, dp(30).toFloat())      // 贴着画面边缘的黑边也算（夹到边上）；离得远的才忽略
                if (n == null) { ctlDown = false; return }
                ctlSid++
                ctlDown = true
                strokeBuf.clear()
                strokeT0 = ev.eventTime
                lastNorm = n
                lastSendT = SystemClock.uptimeMillis()
                sendInput(JSONObject().put("t", "d").put("i", ctlSid).put("x", r4(n[0])).put("y", r4(n[1])))
                dot.at(ev.x, ev.y)
                ui.removeCallbacks(keepAlive)
                ui.postDelayed(keepAlive, 500L)
            }
            MotionEvent.ACTION_MOVE -> if (ctlDown) {
                for (k in 0 until ev.historySize) {
                    val n = normClamp(ev.getHistoricalX(k), ev.getHistoricalY(k)) ?: continue
                    lastNorm = n
                    strokeBuf.add(floatArrayOf(n[0], n[1], (ev.getHistoricalEventTime(k) - strokeT0).toFloat()))
                }
                val n = normClamp(ev.x, ev.y)
                if (n != null) {
                    lastNorm = n
                    strokeBuf.add(floatArrayOf(n[0], n[1], (ev.eventTime - strokeT0).toFloat()))
                }
                dot.at(ev.x, ev.y)
                if (SystemClock.uptimeMillis() - lastSendT >= 12L || strokeBuf.size >= 24) flushMoves()
            }
            MotionEvent.ACTION_POINTER_DOWN -> endStroke(ev)         // 多指不支持：把当前这一笔抬起，等下一次单指按下
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> endStroke(ev)
        }
    }

    /** 一次发送一段文字（粘贴长文本用）；\n 当作回车 */
    private fun sendText(t: String) {
        val parts = t.split("\n")
        for ((i, part) in parts.withIndex()) {
            if (i > 0) sendInput(JSONObject().put("t", "e").put("op", "enter"))
            var o = 0
            while (o < part.length) {
                val end = min(part.length, o + 512)
                sendInput(JSONObject().put("t", "e").put("op", "append").put("s", part.substring(o, end)))
                o = end
            }
        }
    }

    private fun showKeyboardDialog() {
        val et = EditText(this).apply { hint = "要发送到对方的文字" }
        AlertDialog.Builder(this)
            .setTitle("向对方输入文字")
            .setMessage(if (peerWin) "文字会输入到电脑当前获得焦点的位置" else "需要先在对方手机上点中一个输入框")
            .setView(et)
            .setPositiveButton("发送") { _, _ ->
                val t = et.text.toString()
                if (t.isNotEmpty()) sendText(t)
            }
            .setNeutralButton("发送并回车") { _, _ ->
                val t = et.text.toString()
                if (t.isNotEmpty()) sendText(t)
                sendInput(JSONObject().put("t", "e").put("op", "enter"))
            }
            .setNegativeButton("关闭", null)
            .show()
    }

    /* ───────── 实时打字 ─────────
     * 隐藏输入框里始终留一个空格做「哨兵」，这样在空输入框里按退格也能产生一次变化。
     * 输入法还在组词（拼音）时不发；上屏后把「前后文本的差」换算成：退格 n 次 + 追加文字。回车 = 文本里的 \n。 */
    private fun setKeyboard(on: Boolean) {
        if (on == kbdOn) return
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        if (on) {
            kbdMute = true
            kbdEt.setText(" ")
            kbdEt.setSelection(1)
            kbdMute = false
            kbdLast = " "
            kbdEt.requestFocus()
            imm.showSoftInput(kbdEt, InputMethodManager.SHOW_IMPLICIT)
        } else {
            imm.hideSoftInputFromWindow(kbdEt.windowToken, 0)
            kbdEt.clearFocus()
        }
        kbdOn = on
    }

    private fun kbdChanged(e: Editable?) {
        if (e == null || kbdMute || !ctlOn) return
        if (BaseInputConnection.getComposingSpanStart(e) >= 0) return          // 还在组词：等上屏
        val now = e.toString()
        val old = kbdLast
        var p = 0
        val lim = min(old.length, now.length)
        while (p < lim && old[p] == now[p]) p++
        if (p > 0 && p < old.length && Character.isHighSurrogate(old[p - 1])) p--   // 不要把 emoji 的代理对从中间劈开
        val del = old.codePointCount(p, old.length)
        val add = now.substring(p)
        if (del > 0) {
            val j = JSONObject().put("t", "e").put("op", "del")
            if (del > 1) j.put("n", del)
            sendInput(j)
        }
        if (add.isNotEmpty()) sendText(add)
        kbdLast = now
        if (now.isEmpty() || now.length > 400) {                                // 清空 / 太长：重置并放回哨兵
            kbdMute = true
            kbdEt.setText(" ")
            kbdEt.setSelection(1)
            kbdMute = false
            kbdLast = " "
        }
    }

    /* ───────── 控制按钮栏（按对方是手机还是电脑填不同的按钮）───────── */
    private fun navBtn(label: String, onTap: () -> Unit): TextView {
        val b = TextView(this).apply {
            text = label
            styleBarButton(this)
        }
        click(b, onTap)
        return b
    }

    /** 手机被控时对方画面里没有鼠标指针：触控板模式下由本机画一个光标点（电脑被控时画面里自带指针，不用画） */
    private fun showCursorDot() {
        if (peerWin || !deskPad || !ctlOn || !::dot.isInitialized) return
        val g = geom() ?: return
        val dw = vw * g[0] * g[2]
        val dh = vh * g[0] * g[2]
        dot.at((viewer.width - dw) / 2f + panX + curN[0] * dw, (viewer.height - dh) / 2f + panY + curN[1] * dh)
    }

    private fun toggleDeskPad() {
        deskPad = !deskPad
        if (deskPad) showCursorDot() else if (::dot.isInitialized) dot.hide()
        Link.prefs.edit().putBoolean("deskPad", deskPad).apply()
        Toast.makeText(this, if (deskPad) "触控板模式：手指滑动移动光标，轻点 = 左键，长按后滑动 = 拖拽" else "触控模式：手指点哪，光标就到哪", Toast.LENGTH_SHORT).show()
        fillNav()
        if (::dockMenu.isInitialized && dockMenu.visibility == View.VISIBLE) dockOpen(true)
    }

    /** 控制电脑时，所有按钮都收在左侧「≡」圆点的菜单里（两列），画面上平时只剩一个小圆点——点画面的任何位置都不会被按钮挡住。 */
    private fun fillDock() {
        if (!::dockMenu.isInitialized) return
        dockMenu.removeAllViews()
        if (!desk) return
        dockFull = dockBtn(if (fullLand) "退出全屏" else "全屏") { setFullLand(!fullLand); dockOpen(true) }
        fun row(a: TextView, b: TextView) {
            val r = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            r.addView(a, LinearLayout.LayoutParams(WRAP, WRAP))
            r.addView(b, LinearLayout.LayoutParams(WRAP, WRAP).apply { leftMargin = dp(6) })
            dockMenu.addView(r, LinearLayout.LayoutParams(WRAP, WRAP).apply { topMargin = dp(6) })
        }
        row(dockBtn(if (deskPad) "触控板" else "触控") { toggleDeskPad() },
            dockBtn("桌面") { sendInput(JSONObject().put("t", "key").put("k", "win+d")); dockOpen(false) })
        row(dockBtn("文字…") { dockOpen(false); showKeyboardDialog() }, dockFull)
        row(dockBtn("退出控制") { setControl(false) }, dockBtn("断开") { exitViewer("已断开") })
    }

    private fun fillNav() {
        if (!::navInner.isInitialized) return
        fillDock()
        navInner.removeAllViews()
        if (!desk) {
            for ((label, act) in listOf("返回" to "back", "主页" to "home", "任务" to "recents", "通知" to "notif")) {
                navInner.addView(navBtn(label) { sendInput(JSONObject().put("t", "k").put("k", act)) })
            }
            navInner.addView(navBtn(if (kbdOn) "收起键盘" else "键盘") { setKeyboard(!kbdOn); fillNav() })
            navInner.addView(navBtn("文字…") { showKeyboardDialog() })
            return
        }
        navInner.addView(navBtn(if (deskPad) "触控板" else "触控") { toggleDeskPad() })
        navInner.addView(navBtn("桌面") { sendInput(JSONObject().put("t", "key").put("k", "win+d")) })
        navInner.addView(navBtn("文字…") { showKeyboardDialog() })
    }

    /* ═════════════ 控制电脑：触摸 → 鼠标 ═════════════
     * 触控模式：手指点哪光标到哪；轻点 = 左键；按住并移动 = 左键拖动；长按 = 右键。
     * 触控板模式：手指相对移动光标（带加速）；轻点 = 左键；长按后滑动 = 拖拽。
     * 两种模式下：两指滑动 = 滚轮（水平 / 垂直），两指轻点 = 右键。缩放 / 平移画面请用「缩放平移」按钮。 */
    private fun pt(x: Float, y: Float): JSONArray = JSONArray().put(r4(x)).put(r4(y))

    private fun deskMove(x: Float, y: Float) {
        dkPts.add(floatArrayOf(x, y))
        if (dkPts.size >= 24 || SystemClock.uptimeMillis() - lastSendT >= 8L) {          // 约 8ms 合并一包（120Hz 触摸屏一帧一包）
            deskFlush()
        } else {
            ui.removeCallbacks(deskFlushRun)
            ui.postDelayed(deskFlushRun, 8L)
        }
    }

    private fun deskFlush() {
        ui.removeCallbacks(deskFlushRun)
        if (dkPts.isEmpty()) return
        val arr = JSONArray()
        if (dkBtn) {
            for (p in dkPts) arr.put(pt(p[0], p[1]))                       // 拖动：每个点都要
        } else {
            val l = dkPts[dkPts.size - 1]
            arr.put(pt(l[0], l[1]))                                        // 悬停：只要最新位置
        }
        dkPts.clear()
        lastSendT = SystemClock.uptimeMillis()
        sendInput(JSONObject().put("t", "pm").put("p", arr))
    }

    private fun deskBtn(down: Boolean, b: String, n: FloatArray) {
        deskFlush()
        lastSendT = SystemClock.uptimeMillis()
        sendInput(JSONObject().put("t", if (down) "pd" else "pu").put("b", b).put("x", r4(n[0])).put("y", r4(n[1])))
    }

    /** 点击 = 按下，约 30ms 后抬起。按下和抬起在同一毫秒送到时，Windows 标题栏的最小化 / 最大化 / 关闭按钮（以及浏览器自绘的标题栏按钮）
     *  经常没来得及进入「按下」状态就收到抬起，这一下点击就被吞了。后面任何指令发出前都会先把还没发的「抬起」发掉（见 sendInput），顺序不会乱。 */
    private fun deskClick(b: String, n: FloatArray) {
        flushPendingUp()
        deskBtn(true, b, n)
        val r = Runnable { pendingUp = null; deskBtn(false, b, n) }
        pendingUp = r
        ui.postDelayed(r, 30L)
    }

    private fun flushPendingUp() {
        val r = pendingUp ?: return
        pendingUp = null
        ui.removeCallbacks(r)
        r.run()
    }

    /** 左键按下 / 抬起；按着期间复用 keepAlive 每 500ms 发保活 */
    private fun deskLeft(down: Boolean, n: FloatArray) {
        deskBtn(down, "l", n)
        dkBtn = down
        ctlDown = down
        ui.removeCallbacks(keepAlive)
        if (down) ui.postDelayed(keepAlive, 500L)
    }

    private fun deskLong() {
        if (dkTwo || dkMoved || dkIgnore || dkLong) return
        dkLong = true
        viewer.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        if (deskPad) deskLeft(true, curN) else deskClick("r", dkDownN)
    }

    private fun deskReset() {
        ui.removeCallbacks(dkLongRun)
        ui.removeCallbacks(deskFlushRun)
        dkPts.clear()
        dkTwo = false
        dkMoved = false
        dkLong = false
        dkIgnore = false
    }

    private fun deskTouch(ev: MotionEvent) {
        val slop = dp(8).toFloat()
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                ui.removeCallbacks(dkLongRun)
                dkTwo = false; dkMoved = false; dkLong = false; dkIgnore = false
                dkDownX = ev.x; dkDownY = ev.y; dkLastX = ev.x; dkLastY = ev.y
                dkT0 = ev.eventTime; dkLastT = ev.eventTime
                if (!deskPad) {
                    val n = normNear(ev.x, ev.y, dp(30).toFloat())          // 贴边的黑边也算：能点到画面最边缘的最小化 / 关闭按钮
                    if (n == null) { dkIgnore = true; return }
                    dkDownN = n
                    curN = n
                    dkPts.add(floatArrayOf(n[0], n[1]))
                    deskFlush()                                            // 光标先过去（悬停）
                    dot.at(ev.x, ev.y)
                }
                ui.postDelayed(dkLongRun, 450L)
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                ui.removeCallbacks(dkLongRun)
                if (ev.pointerCount == 2) {
                    if (dkBtn) deskLeft(false, curN)
                    dkTwo = true; dkMoved = true; dkTwoMoved = false; dkTwoPath = 0f; dkTwoT0 = ev.eventTime
                    dkTwoX = (ev.getX(0) + ev.getX(1)) / 2f
                    dkTwoY = (ev.getY(0) + ev.getY(1)) / 2f
                    dkWx = 0f; dkWy = 0f; dkSx = 0f; dkSy = 0f; dkWT = 0L
                    dot.hide()
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (dkTwo) {
                    if (ev.pointerCount < 2) return
                    val cx = (ev.getX(0) + ev.getX(1)) / 2f
                    val cy = (ev.getY(0) + ev.getY(1)) / 2f
                    val step = dp(28).toFloat()                            // 手指滑过 28dp = 滚 1 格
                    dkWx += -(cx - dkTwoX) / step
                    dkWy += -(cy - dkTwoY) / step
                    run { val g = geom(); if (g != null) { dkSx += (cx - dkTwoX) / (vw * g[0] * g[2]); dkSy += (cy - dkTwoY) / (vh * g[0] * g[2]) } }   // 手机被控：内容跟手指 1:1
                    dkTwoPath += hypot(cx - dkTwoX, cy - dkTwoY)
                    dkTwoX = cx; dkTwoY = cy
                    if (dkTwoPath > slop) dkTwoMoved = true
                    val now = SystemClock.uptimeMillis()
                    if (dkTwoMoved && now - dkWT >= 16L && (abs(dkWx) > 0.01f || abs(dkWy) > 0.01f)) {      // 约一帧一包，滚动才丝滑
                        val n = (if (deskPad) null else normClamp(cx, cy)) ?: curN
                        sendInput(JSONObject().put("t", "w").put("x", r4(n[0])).put("y", r4(n[1]))
                            .put("dx", Math.round(dkWx * 1000f) / 1000.0).put("dy", Math.round(dkWy * 1000f) / 1000.0)
                            .put("sx", Math.round(dkSx * 1e5f) / 1e5).put("sy", Math.round(dkSy * 1e5f) / 1e5))
                        dkWx = 0f; dkWy = 0f; dkSx = 0f; dkSy = 0f; dkWT = now
                        lastSendT = now
                    }
                    return
                }
                if (dkIgnore) return
                if (!dkMoved && !dkLong && hypot(ev.x - dkDownX, ev.y - dkDownY) > slop) {
                    dkMoved = true
                    ui.removeCallbacks(dkLongRun)
                    if (!deskPad) deskLeft(true, dkDownN)                  // 触控模式：超过阈值才算拖动，在按下点按下左键
                }
                if (deskPad) {
                    val g = geom() ?: return
                    val dw = vw * g[0] * g[2]
                    val dh = vh * g[0] * g[2]
                    var lx = dkLastX
                    var ly = dkLastY
                    var lt = dkLastT
                    for (k in 0..ev.historySize) {
                        val x = if (k < ev.historySize) ev.getHistoricalX(k) else ev.x
                        val y = if (k < ev.historySize) ev.getHistoricalY(k) else ev.y
                        val t = if (k < ev.historySize) ev.getHistoricalEventTime(k) else ev.eventTime
                        val ddx = x - lx
                        val ddy = y - ly
                        val sp = hypot(ddx, ddy) / max(1L, t - lt).toFloat()      // px/ms
                        val gain = 1.3f + min(2.5f, sp)                            // 慢移精确，快移跑得远
                        curN = floatArrayOf((curN[0] + ddx * gain / dw).coerceIn(0f, 1f), (curN[1] + ddy * gain / dh).coerceIn(0f, 1f))
                        deskMove(curN[0], curN[1])
                        lx = x; ly = y; lt = t
                    }
                    dkLastX = lx; dkLastY = ly; dkLastT = lt
                    showCursorDot()
                } else if (dkBtn) {
                    for (k in 0..ev.historySize) {
                        val x = if (k < ev.historySize) ev.getHistoricalX(k) else ev.x
                        val y = if (k < ev.historySize) ev.getHistoricalY(k) else ev.y
                        val n = normClamp(x, y) ?: continue                // 拖到画面外：光标停在边上，不是原地不动
                        curN = n
                        deskMove(n[0], n[1])
                    }
                    dot.at(ev.x, ev.y)
                }
            }
            MotionEvent.ACTION_POINTER_UP -> {
                if (dkTwo && ev.pointerCount == 2 && !dkTwoMoved && ev.eventTime - dkTwoT0 < 350L) {
                    deskClick("r", curN)                                   // 两指轻点 = 右键
                    dkTwoMoved = true
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                ui.removeCallbacks(dkLongRun)
                if (dkTwo) {
                    dkTwo = false
                    dot.hide()
                    showCursorDot()
                    return
                }
                if (!dkIgnore) {
                    if (dkBtn) {
                        deskFlush()
                        deskLeft(false, curN)
                    } else if (ev.actionMasked == MotionEvent.ACTION_UP && !dkMoved && !dkLong && ev.eventTime - dkT0 < 600L) {      // 长按在 450ms 才触发；以前这里卡 400ms，按 400~450ms 抬手既不点击也不长按
                        deskClick("l", if (deskPad) curN else dkDownN)        // 轻点 = 左键单击
                    }
                }
                dot.hide()
                showCursorDot()
            }
        }
    }

    /* ───────── 左侧收纳圆点 ───────── */
    private fun dockBtn(label: String, onTap: () -> Unit): TextView = navBtn(label, onTap).apply {
        background = shape(Color.parseColor("#CC141A21"), 18f)
    }

    private fun dockOpen(on: Boolean) {
        if (!::dockMenu.isInitialized) return
        ui.removeCallbacks(dockCollapse)
        dockMenu.visibility = if (on) View.VISIBLE else View.GONE
        if (on) ui.postDelayed(dockCollapse, 4000L)                // 4 秒没人点就自己收回去
        ctlDock.post { dockMoveTo(ctlDock.translationX, ctlDock.translationY) }
    }

    private fun dockTouch(v: View, ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dockDX = ev.rawX; dockDY = ev.rawY
                dockBX = ctlDock.translationX; dockBY = ctlDock.translationY
                dockMoved = false
                v.parent?.requestDisallowInterceptTouchEvent(true)
            }
            MotionEvent.ACTION_MOVE -> {
                if (!dockMoved && hypot(ev.rawX - dockDX, ev.rawY - dockDY) > dp(8).toFloat()) dockMoved = true
                if (dockMoved) dockMoveTo(dockBX + ev.rawX - dockDX, dockBY + ev.rawY - dockDY)
            }
            MotionEvent.ACTION_UP -> if (dockMoved) dockSavePos() else dockOpen(dockMenu.visibility != View.VISIBLE)
        }
        return true
    }

    private fun dockMoveTo(tx: Float, ty: Float) {
        if (viewer.width <= 0 || ctlDock.width <= 0) return
        val minX = -ctlDock.left.toFloat()
        val maxX = (viewer.width - ctlDock.left - ctlDock.width).toFloat()
        val minY = -ctlDock.top.toFloat()
        val maxY = (viewer.height - ctlDock.top - ctlDock.height).toFloat()
        ctlDock.translationX = tx.coerceIn(min(minX, maxX), max(minX, maxX))
        ctlDock.translationY = ty.coerceIn(min(minY, maxY), max(minY, maxY))
    }

    private fun dockSavePos() {
        if (viewer.width <= 0 || viewer.height <= 0) return
        Link.prefs.edit().putFloat("pos_dock_x", ctlDock.translationX / viewer.width).putFloat("pos_dock_y", ctlDock.translationY / viewer.height).apply()
    }

    private fun dockRestore() {
        if (!::ctlDock.isInitialized || ctlDock.width <= 0 || viewer.width <= 0 || !Link.prefs.contains("pos_dock_x")) return
        dockMoveTo(Link.prefs.getFloat("pos_dock_x", 0f) * viewer.width, Link.prefs.getFloat("pos_dock_y", 0f) * viewer.height)
    }

    /** 控制中让系统不要在屏幕左 / 右边缘抢手势（返回手势）：以手指所在高度为中心留一段（系统最多认 200dp）。
     *  顶部状态栏下拉和底部上滑回主页没法排除；手指滑到那里时坐标会被夹到画面边缘（见 normNear）。 */
    private fun updateGestureExclusion(touchY: Float = -1f) {
        val w = viewer.width
        val h = viewer.height
        if (!ctlOn || w <= 0 || h <= 0) {
            if (viewer.systemGestureExclusionRects.isNotEmpty()) viewer.systemGestureExclusionRects = emptyList()
            return
        }
        val eh = min(h, dp(200))
        val top = ((if (touchY < 0f) 0f else touchY - eh / 2f).toInt()).coerceIn(0, h - eh)
        val ew = dp(40)
        viewer.systemGestureExclusionRects = listOf(Rect(0, top, ew, top + eh), Rect(w - ew, top, w, top + eh))
    }

    private fun applyImmersive(on: Boolean) {
        WindowCompat.setDecorFitsSystemWindows(window, !on)
        val c = WindowCompat.getInsetsController(window, window.decorView)
        val lp = window.attributes
        if (on) {
            c.hide(WindowInsetsCompat.Type.systemBars())
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            ViewCompat.setOnApplyWindowInsetsListener(window.decorView) { v, insets ->
                if (viewing && ctlOn && desk && insets.isVisible(WindowInsetsCompat.Type.systemBars())) {
                    ui.removeCallbacks(reHideBars)
                    ui.postDelayed(reHideBars, 60L)
                }
                ViewCompat.onApplyWindowInsets(v, insets)
            }
        } else {
            ViewCompat.setOnApplyWindowInsetsListener(window.decorView, null)
            c.show(WindowInsetsCompat.Type.systemBars())
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT
        }
        window.attributes = lp
    }

    /* ═════════════ 铺满策略（参考 YouTube） ═════════════
     * 完整显示：整幅画面可见（上下/左右留黑边）
     * 铺满裁剪：放大到填满屏幕，裁掉超出部分，可拖动平移
     * 自动：被裁掉的面积 ≤ autoLoss 才铺满（16:9 → 20:9 手机横屏约裁 20%），否则完整显示（竖屏手机 → 横屏电脑）
     * 捏合缩放结束后自动吸附到「完整显示 / 铺满」，双击在两者间切换
     */
    private fun geom(): FloatArray? {
        val w = viewer.width.toFloat()
        val h = viewer.height.toFloat()
        if (vw <= 0 || vh <= 0 || w <= 0f || h <= 0f) return null
        val fitS = min(w / vw, h / vh)
        val fillS = max(w / vw, h / vh)
        val ratio = fillS / fitS
        val rel = when (mode) {
            1 -> 1f
            2 -> ratio
            3 -> manualRel
            else -> if (1f - 1f / ratio <= autoLoss) ratio else 1f
        }
        return floatArrayOf(fitS, ratio, rel)
    }

    private fun applyTransform() {
        val t = tv ?: return
        val g = geom() ?: return
        val w = viewer.width.toFloat()
        val h = viewer.height.toFloat()
        val dw = vw * g[0] * g[2]
        val dh = vh * g[0] * g[2]
        val mx = max(0f, (dw - w) / 2f)
        val my = max(0f, (dh - h) / 2f)
        panX = panX.coerceIn(-mx, mx)
        panY = panY.coerceIn(-my, my)
        val m = Matrix()
        m.setScale(dw / w, dh / h, w / 2f, h / 2f)       // TextureView 默认把画面拉伸到整个控件，这里还原成正确比例
        m.postTranslate(panX, panY)
        t.setTransform(m)
    }

    private val scaleDet by lazy {
        ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                val g = geom() ?: return false
                manualRel = (g[2] * d.scaleFactor).coerceIn(1f, max(1f, g[1] * 4f))
                mode = 3
                applyTransform()
                return true
            }

            override fun onScaleEnd(d: ScaleGestureDetector) {
                val g = geom() ?: return
                if (manualRel < 1.05f) {
                    mode = 1; panX = 0f; panY = 0f
                } else if (abs(manualRel - g[1]) / g[1] < 0.05f) {
                    mode = 2
                }
                applyTransform()
            }
        })
    }

    private val gestDet by lazy {
        GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: MotionEvent): Boolean {
                val g = geom() ?: return false
                mode = if (g[2] > 1.01f) 1 else 2
                panX = 0f; panY = 0f
                applyTransform()
                return true
            }

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
                if (scaleDet.isInProgress) return false
                panX -= distanceX
                panY -= distanceY
                applyTransform()
                return true
            }
        })
    }
}
