package com.lancast.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.DocumentsContract
import android.provider.Settings
import android.text.InputFilter
import android.text.TextUtils
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import org.json.JSONArray
import org.json.JSONObject
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class MainActivity : ComponentActivity(), Link.Listener {

    private data class CastReq(val mode: String, val host: String = "", val port: Int = 0, val pin: String = "", val ctl: Boolean = false)

    /* ── 页面 ── */
    private lateinit var root: FrameLayout
    private lateinit var home: ScrollView
    private lateinit var settingsPage: FrameLayout
    private lateinit var pairedPage: FrameLayout
    private lateinit var viewer: FrameLayout

    /* ── 首页控件 ── */
    private lateinit var qrIv: ImageView
    private lateinit var qrSub: TextView
    private lateinit var statusCard: LinearLayout
    private lateinit var statusTv: TextView
    private lateinit var stopBtn: TextView
    private lateinit var peersBox: LinearLayout
    private lateinit var xfersCard: LinearLayout
    private lateinit var xfersBox: LinearLayout
    private lateinit var statsTv: TextView

    /* ── 设置页控件 ── */
    private lateinit var nameEt: EditText
    private lateinit var dirSub: TextView
    private lateinit var dirReset: TextView
    private lateinit var presetVal: TextView
    private lateinit var audioSw: Switch
    private lateinit var bgSw: Switch
    private lateinit var ctlSub: TextView

    /* ── 屏幕控制（观看方） ── */
    private lateinit var ctlBtn: TextView
    private lateinit var navBar: LinearLayout
    private var viewSession: Session? = null
    private var ctlOn = false
    private val strokeBuf = ArrayList<FloatArray>()      // 待发送的移动点 [x, y, 相对按下时刻的毫秒]
    private var strokeT0 = 0L
    private var ctlSid = 0
    private var ctlDown = false
    private var lastSendT = 0L
    private var lastNorm: FloatArray? = null
    private lateinit var dot: TouchDot

    /* ── 已配对设备页 ── */
    private lateinit var pairedBox: LinearLayout

    private class XRow(val box: LinearLayout, val name: TextView, val info: TextView, val bar: ProgressBar, val btn: TextView)
    private val xRows = HashMap<Xfer, XRow>()
    private var tv: TextureView? = null
    private var sink: ScreenSink? = null
    private var viewing = false
    private var pendingCast: CastReq? = null
    private var pendingTarget: Paired? = null
    private val ui = Handler(Looper.getMainLooper())

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val QR_CYCLE = 60                  // 二维码每 60 秒自动刷新一轮
    private var qrLeft = QR_CYCLE
    private var qrLast = ""
    private var qrNoNet = false
    private var qrSide = 0
    private var peersSig = ""

    /* 铺满状态（与 Windows 端一致）：mode 0=自动 1=完整显示 2=铺满裁剪 3=手动缩放 */
    private var vw = 0
    private var vh = 0
    private var mode = 0
    private var manualRel = 1f
    private var panX = 0f
    private var panY = 0f
    private val autoLoss = 0.22f              // 被裁掉的面积 ≤ 22% 时自动铺满

    private val projLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        onProjection(r.resultCode, r.data)
    }
    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { _ ->
        launchProjection()
    }

    private val pickLauncher = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        val target = pendingTarget
        pendingTarget = null
        if (uris != null && uris.isNotEmpty() && target != null) {
            for (u in uris) {
                try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (ignored: Exception) { }
            }
            doSend(target, uris)
        }
    }
    private val notifLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { _ -> }
    private val scanLauncher = registerForActivityResult(ScanContract()) { result ->
        val text = result.contents
        if (text != null) onScanned(text)
    }
    private val treeLauncher = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            var ok = true
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            } catch (e: Exception) {
                ok = false
            }
            if (ok) {
                Link.prefs.edit().putString("recv_tree", uri.toString()).apply()
                updateSettingsUi()
                Toast.makeText(this, "接收目录已更改", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "无法获得该文件夹的写入权限，请换一个文件夹", Toast.LENGTH_LONG).show()
            }
        }
    }

    private val tick = object : Runnable {
        override fun run() {
            refreshPeers()
            refreshUi()
            ui.postDelayed(this, 2000)
        }
    }

    private val qrTick = object : Runnable {
        override fun run() {
            qrLeft--
            if (qrLeft <= 0) {
                drawQr(false)
                qrLeft = QR_CYCLE
            }
            updateQrSub()
            ui.postDelayed(this, 1000)
        }
    }

    private val statusHide = Runnable {
        if (CastService.current == null) statusCard.visibility = View.GONE
    }

    private fun dp(v: Int) = px(v)

    /* ═════════════ 生命周期 ═════════════ */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Link.init(this)
        Link.start()
        if (ListenService.enabled()) ListenService.start(this)
        buildUi()
        setContentView(root)
        if (Build.VERSION.SDK_INT >= 33 && !Link.prefs.getBoolean("asked_notif", false) &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            Link.prefs.edit().putBoolean("asked_notif", true).apply()      // 后台收到投屏请求时要靠通知提醒你
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        window.statusBarColor = C.BG
        window.navigationBarColor = C.BG
        val ic = WindowCompat.getInsetsController(window, window.decorView)
        ic.isAppearanceLightStatusBars = true
        ic.isAppearanceLightNavigationBars = true
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (viewing) {
                    exitViewer("已断开")
                } else if (settingsPage.visibility == View.VISIBLE || pairedPage.visibility == View.VISIBLE) {
                    showPage(home)
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    override fun onStart() {
        super.onStart()
        Link.listener = this
        FileXfer.listener = { renderXfers() }
        renderXfers()
        qrLeft = QR_CYCLE
        drawQr(true)
        updateQrSub()
        ui.post(tick)
        ui.postDelayed(qrTick, 1000)
        updateSettingsUi()            // 从系统无障碍设置回来时刷新状态
        Link.deliverParked()          // 应用在后台时挂起的投屏请求，现在交给界面
    }

    override fun onStop() {
        super.onStop()
        Link.listener = null
        FileXfer.listener = null
        ui.removeCallbacks(tick)
        ui.removeCallbacks(qrTick)
        if (viewing) exitViewer("应用退到后台，已结束查看")
    }

    /* ═════════════ 小工具 ═════════════ */
    private fun txt(text: String, sp: Float, color: Int = C.INK, bold: Boolean = false): TextView = TextView(this).apply {
        this.text = text
        textSize = sp
        setTextColor(color)
        includeFontPadding = false
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun icon(kind: String, color: Int = C.PRIMARY, filled: Boolean = false): IconView = IconView(this, kind, color, filled)

    private fun ll(w: Int, h: Int, weight: Float = 0f, top: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(w, h, weight).apply { topMargin = px(top) }

    private fun fl(w: Int, h: Int, g: Int): FrameLayout.LayoutParams = FrameLayout.LayoutParams(w, h, g)

    /** 带按下反馈的点击 */
    private fun click(v: View, f: () -> Unit) {
        v.isClickable = true
        v.setOnClickListener { f() }
        v.setOnTouchListener { view, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> view.alpha = 0.78f
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> view.alpha = 1f
            }
            false
        }
    }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = shape(C.CARD, 24f, C.CARD_LINE, 1f)
        elevation = px(2).toFloat()
        outlineAmbientShadowColor = Color.parseColor("#2A5B7A8C")
        outlineSpotShadowColor = Color.parseColor("#2A5B7A8C")
    }

    /** 卡片里的小按钮：filled=实心主色；否则白底描边 */
    private fun pill(text: String, filled: Boolean, danger: Boolean = false, onClick: () -> Unit): TextView {
        val col = if (danger) C.BAD else C.PRIMARY
        return TextView(this).apply {
            this.text = text
            textSize = 13f
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            includeFontPadding = false
            setTextColor(if (filled) Color.WHITE else col)
            background = if (filled) shape(col, 10f) else shape(Color.WHITE, 10f, col, 1.4f)
            click(this, onClick)
        }
    }

    private fun hideKeyboard() {
        try {
            val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
            imm.hideSoftInputFromWindow(window.decorView.windowToken, 0)
        } catch (ignored: Exception) { }
    }

    /* ═════════════ 界面 ═════════════ */
    private fun buildUi() {
        buildHome()
        buildSettings()
        buildPairedPage()

        viewer = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            visibility = View.GONE
        }
        statsTv = TextView(this).apply {
            setTextColor(Color.parseColor("#dfe8ee"))
            setBackgroundColor(Color.parseColor("#b0141a21"))
            textSize = 11f
            setPadding(dp(8), dp(3), dp(8), dp(3))
        }
        // 统计信息已移除：statsTv 不再加入界面
        val disc = TextView(this).apply {
            text = "断开"
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = shape(Color.parseColor("#99141A21"), 18f)
            setPadding(dp(18), dp(8), dp(18), dp(8))
        }
        click(disc) { exitViewer("已断开") }
        ctlBtn = TextView(this).apply {
            text = "控制"
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = shape(Color.parseColor("#99141A21"), 18f)
            setPadding(dp(18), dp(8), dp(18), dp(8))
            visibility = View.GONE
        }
        click(ctlBtn) { setControl(!ctlOn) }
        val topRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        topRow.addView(ctlBtn, LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(8) })
        topRow.addView(disc)
        viewer.addView(topRow, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.END or Gravity.TOP).apply {
            rightMargin = dp(10); topMargin = dp(10)
        })
        navBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = shape(Color.parseColor("#B3141A21"), 22f)
            setPadding(dp(6), dp(4), dp(6), dp(4))
            visibility = View.GONE
        }
        for ((label, act) in listOf("返回" to "back", "主页" to "home", "任务" to "recents", "通知" to "notif", "键盘" to "kbd")) {
            val b = TextView(this).apply {
                text = label
                textSize = 14f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                setPadding(dp(14), dp(10), dp(14), dp(10))
            }
            click(b) { if (act == "kbd") showKeyboardDialog() else sendInput(JSONObject().put("t", "k").put("k", act)) }
            navBar.addView(b)
        }
        dot = TouchDot(this)
        viewer.addView(dot, FrameLayout.LayoutParams(MATCH, MATCH))
        viewer.addView(navBar, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER_HORIZONTAL or Gravity.BOTTOM).apply {
            bottomMargin = dp(18)
        })
        viewer.setOnTouchListener { _, ev ->
            if (ctlOn) {
                ctlTouch(ev)
            } else {
                scaleDet.onTouchEvent(ev)
                gestDet.onTouchEvent(ev)
            }
            true
        }
        viewer.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> applyTransform() }

        root = FrameLayout(this)
        root.setBackgroundColor(C.BG)
        root.addView(home, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(settingsPage, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(pairedPage, FrameLayout.LayoutParams(MATCH, MATCH))
        root.addView(viewer, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    /* ───────────── 首页 ───────────── */
    private fun buildHome() {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(20), px(20), px(20), px(24))
        }

        // 顶部：标题 + 设置
        val head = FrameLayout(this)
        val titleCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleCol.addView(txt("瞬流", 34f, C.INK, true))
        titleCol.addView(txt("随时互传 · 极速直达", 15f, C.SUB).apply { setPadding(0, px(10), 0, 0) })
        head.addView(titleCol, fl(WRAP, WRAP, Gravity.START or Gravity.CENTER_VERTICAL))
        val gearCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(px(10), px(6), px(2), px(6))
        }
        gearCol.addView(icon("gear", C.INK), ll(px(28), px(28)))
        gearCol.addView(txt("设置", 12f, C.SUB).apply { setPadding(0, px(5), 0, 0) })
        click(gearCol) { showPage(settingsPage) }
        head.addView(gearCol, fl(WRAP, WRAP, Gravity.END or Gravity.TOP))
        col.addView(head, ll(MATCH, WRAP))

        // 本机动态二维码
        qrSide = min(px(220), resources.displayMetrics.widthPixels - px(110))
        // 卡片内容上下留白一致：卡片顶 → 标题、副标题 → 二维码、二维码 → 卡片底，视觉上都是 24dp
        // （二维码图片自带约 5dp 的白边，所以后两处的实际间距要少 5dp）
        val qrCard = card().apply {
            gravity = Gravity.CENTER
            setPadding(px(20), px(24), px(20), px(19))
        }
        // 标题：整行宽度 + 文字居中 → 横向居中；字体上下的多余留白已去掉，纵向位置才准
        qrCard.addView(txt("本机动态二维码", 18f, C.INK, true).apply {
            gravity = Gravity.CENTER
        }, ll(MATCH, WRAP))
        qrSub = txt("", 13.5f, C.SUB).apply {
            gravity = Gravity.CENTER
        }
        qrCard.addView(qrSub, ll(MATCH, WRAP, 0f, 8))
        qrIv = ImageView(this).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.WHITE)
        }
        qrCard.addView(qrIv, ll(qrSide, qrSide, 0f, 19))
        col.addView(qrCard, ll(MATCH, WRAP, 0f, 22))

        // 扫描设备二维码
        val scanBtn = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = shape(C.PRIMARY, 30f)
        }
        scanBtn.addView(icon("scan", Color.WHITE), ll(px(26), px(26)))
        scanBtn.addView(txt("扫描设备二维码", 18f, Color.WHITE, true).apply { setPadding(px(12), 0, 0, 0) })
        click(scanBtn) { startScan() }
        col.addView(scanBtn, ll(MATCH, px(60), 0f, 16))

        // 状态（平时隐藏；配对 / 发送 / 投屏时才出现）
        statusCard = card().apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(px(20), px(14), px(14), px(14))
            visibility = View.GONE
        }
        statusTv = txt("", 14f, C.PRIMARY, true).apply { setLineSpacing(0f, 1.15f) }
        statusCard.addView(statusTv, ll(0, WRAP, 1f))
        stopBtn = pill("结束投屏", true) { CastService.current?.shutdown("已手动结束") }
        stopBtn.visibility = View.GONE
        statusCard.addView(stopBtn, LinearLayout.LayoutParams(px(88), px(34)).apply { leftMargin = px(10) })
        col.addView(statusCard, ll(MATCH, WRAP, 0f, 16))

        // 已配对设备
        val pairedCard = card().apply { setPadding(px(20), px(18), px(20), px(20)) }
        val ph = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, px(2), 0, px(2))
        }
        ph.addView(txt("已配对设备", 17f, C.INK, true), ll(0, WRAP, 1f))
        ph.addView(icon("chev", C.INK), ll(px(22), px(22)))
        click(ph) { showPage(pairedPage) }
        pairedCard.addView(ph, ll(MATCH, WRAP))
        peersBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        pairedCard.addView(peersBox, ll(MATCH, WRAP, 0f, 16))
        col.addView(pairedCard, ll(MATCH, WRAP, 0f, 16))

        // 传输记录（有传输时才出现）
        xfersCard = card().apply {
            setPadding(px(20), px(18), px(20), px(14))
            visibility = View.GONE
        }
        val xh = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        xh.addView(txt("传输记录", 17f, C.INK, true), ll(0, WRAP, 1f))
        val clr = txt("清除已结束", 13f, C.SUB).apply { setPadding(px(8), px(4), 0, px(4)) }
        click(clr) { FileXfer.clearFinished() }
        xh.addView(clr)
        xfersCard.addView(xh, ll(MATCH, WRAP))
        xfersBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        xfersCard.addView(xfersBox, ll(MATCH, WRAP))
        col.addView(xfersCard, ll(MATCH, WRAP, 0f, 16))

        // 底部说明
        val foot = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        foot.addView(View(this).apply { setBackgroundColor(C.CARD_LINE) }, ll(0, px(1), 1f))
        foot.addView(txt("传输不限大小 · 原字节无损 · SHA-256 全文件校验", 11f, C.SUB).apply {
            maxLines = 1
            setPadding(px(10), 0, px(10), 0)
        })
        foot.addView(View(this).apply { setBackgroundColor(C.CARD_LINE) }, ll(0, px(1), 1f))
        col.addView(foot, ll(MATCH, WRAP, 0f, 24))

        home = ScrollView(this).apply {
            setBackgroundColor(C.BG)
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(col)
        }
    }

    /* ───────────── 设置页 ───────────── */
    private class SCard(val card: LinearLayout, val sub: TextView)

    private fun topBar(title: String): FrameLayout {
        val bar = FrameLayout(this)
        val back = FrameLayout(this).apply { background = circle(C.BACK) }
        back.addView(icon("back", C.INK), fl(px(22), px(22), Gravity.CENTER))
        click(back) { showPage(home) }
        bar.addView(back, fl(px(44), px(44), Gravity.START or Gravity.CENTER_VERTICAL))
        bar.addView(txt(title, 26f, C.INK, true), fl(WRAP, WRAP, Gravity.CENTER))
        return bar
    }

    private fun settingCard(iconKind: String, title: String, sub: String): SCard {
        val c = card().apply {
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(px(20), px(24), px(20), px(22))
        }
        val ic = FrameLayout(this).apply { background = circle(C.SOFT) }
        ic.addView(icon(iconKind, C.PRIMARY, iconKind == "folder"), fl(px(30), px(30), Gravity.CENTER))
        c.addView(ic, ll(px(62), px(62)))
        c.addView(txt(title, 20f, C.INK, true), ll(WRAP, WRAP, 0f, 14))
        val s = txt(sub, 14f, C.SUB).apply { gravity = Gravity.CENTER }
        c.addView(s, ll(WRAP, WRAP, 0f, 8))
        return SCard(c, s)
    }

    private fun bigBtn(text: String, onClick: () -> Unit): TextView = TextView(this).apply {
        this.text = text
        textSize = 17f
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        includeFontPadding = false
        setTextColor(Color.WHITE)
        background = shape(C.PRIMARY, 26f)
        click(this, onClick)
    }

    private fun halfBtn(text: String, iconKind: String, filled: Boolean, onClick: () -> Unit): LinearLayout {
        val fg = if (filled) Color.WHITE else C.PRIMARY
        val b = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = shape(if (filled) C.PRIMARY else C.SOFT, 16f)
        }
        b.addView(icon(iconKind, fg, iconKind == "folder" && !filled), ll(px(22), px(22)))
        b.addView(txt(text, 16f, fg, true).apply { setPadding(px(8), 0, 0, 0) })
        click(b, onClick)
        return b
    }

    private fun buildSettings() {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(20), px(16), px(20), px(28))
        }
        col.addView(topBar("设置"), ll(MATCH, px(48)))

        // 设备名称
        val c1 = settingCard("monitor", "设备名称", "在其他设备上显示的名字")
        nameEt = EditText(this).apply {
            setText(Link.name)
            setSingleLine(true)
            textSize = 16f
            setTextColor(C.INK)
            gravity = Gravity.CENTER_VERTICAL
            background = shape(Color.parseColor("#FCFEFF"), 14f, C.INPUT_LINE, 1.2f)
            setPadding(px(16), 0, px(16), 0)
            imeOptions = EditorInfo.IME_ACTION_DONE
            filters = arrayOf(InputFilter.LengthFilter(40))
        }
        c1.card.addView(nameEt, ll(MATCH, px(52), 0f, 18))
        c1.card.addView(bigBtn("保存名称") { saveName() }, ll(MATCH, px(52), 0f, 14))
        col.addView(c1.card, ll(MATCH, WRAP, 0f, 16))

        // 接收目录
        val c2 = settingCard("folder", "接收目录", "")
        dirSub = c2.sub
        val rowBtns = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        rowBtns.addView(halfBtn("打开目录", "folder", false) { openRecvDir() }, LinearLayout.LayoutParams(0, px(52), 1f))
        rowBtns.addView(halfBtn("更改目录", "pencil", true) { treeLauncher.launch(null) }, LinearLayout.LayoutParams(0, px(52), 1f).apply { leftMargin = px(12) })
        c2.card.addView(rowBtns, ll(MATCH, WRAP, 0f, 18))
        dirReset = txt("恢复默认目录（下载/${FileXfer.DEFAULT_DIR}）", 13f, C.SUB).apply {
            setPadding(px(10), px(8), px(10), px(4))
            paintFlags = paintFlags or android.graphics.Paint.UNDERLINE_TEXT_FLAG
        }
        click(dirReset) {
            Link.prefs.edit().remove("recv_tree").apply()
            updateSettingsUi()
            Toast.makeText(this, "已恢复默认接收目录", Toast.LENGTH_SHORT).show()
        }
        c2.card.addView(dirReset, ll(WRAP, WRAP, 0f, 8))
        col.addView(c2.card, ll(MATCH, WRAP, 0f, 16))

        // 投屏设置（画质 / 声音）
        val c3 = settingCard("cast", "投屏设置", "手机投屏给其他设备时的画质与声音")
        val qRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = shape(C.SOFT, 14f)
            setPadding(px(16), 0, px(14), 0)
        }
        qRow.addView(txt("画质", 16f, C.INK, true), ll(0, WRAP, 1f))
        presetVal = txt("", 14f, C.SUB)
        qRow.addView(presetVal)
        qRow.addView(icon("chev", C.SUB), ll(px(18), px(18)))
        click(qRow) { pickPreset() }
        c3.card.addView(qRow, ll(MATCH, px(52), 0f, 18))
        val aRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = shape(C.SOFT, 14f)
            setPadding(px(16), 0, px(14), 0)
        }
        aRow.addView(txt("同时传输手机声音（无损 PCM）", 15f, C.INK, true), ll(0, WRAP, 1f))
        audioSw = Switch(this).apply {
            isChecked = Link.prefs.getBoolean("audio", true)
            trackTintList = ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(C.PRIMARY, C.GRAY))
            setOnCheckedChangeListener { _, c -> Link.prefs.edit().putBoolean("audio", c).apply() }
        }
        aRow.addView(audioSw)
        c3.card.addView(aRow, ll(MATCH, px(52), 0f, 10))
        col.addView(c3.card, ll(MATCH, WRAP, 0f, 16))

        // 后台常驻接收（安卓 ↔ 安卓）
        val c5 = settingCard("phone", "后台常驻接收", "开启后，应用在后台时其他设备也能向本机发文件、扫码配对；对方发起投屏时会弹通知")
        val bRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = shape(C.SOFT, 14f)
            setPadding(px(16), 0, px(14), 0)
        }
        bRow.addView(txt("在通知栏常驻，随时可接收", 15f, C.INK, true), ll(0, WRAP, 1f))
        bgSw = Switch(this).apply {
            isChecked = ListenService.enabled()
            trackTintList = ColorStateList(arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()), intArrayOf(C.PRIMARY, C.GRAY))
            setOnCheckedChangeListener { _, c -> if (c != ListenService.enabled()) ListenService.setEnabled(this@MainActivity, c) }
        }
        bRow.addView(bgSw)
        c5.card.addView(bRow, ll(MATCH, px(52), 0f, 18))
        col.addView(c5.card, ll(MATCH, WRAP, 0f, 16))

        // 屏幕控制（被控制端）
        val c6 = settingCard("cast", "屏幕控制", "")
        ctlSub = c6.sub
        c6.card.addView(bigBtn("去系统设置开启") {
            try { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } catch (e: Exception) {
                Toast.makeText(this, "请在 系统设置 → 无障碍 里开启「瞬流 屏幕控制」", Toast.LENGTH_LONG).show()
            }
        }, ll(MATCH, px(52), 0f, 18))
        c6.card.addView(txt("在「无障碍 → 已下载的应用」里找到「瞬流 屏幕控制」并打开。若提示「受限制的设置」：长按瞬流图标 → 应用信息 → 右上角「⋮」→ 允许受限制的设置，再回来开启。每次被控制前仍会征求你的同意。", 12.5f, C.SUB).apply {
            setLineSpacing(0f, 1.2f)
            setPadding(px(4), px(12), px(4), 0)
        }, ll(MATCH, WRAP))
        col.addView(c6.card, ll(MATCH, WRAP, 0f, 16))

        // 配对密钥
        val c4 = settingCard("refresh", "配对密钥", "刷新后，之前扫过码的设备需要重新扫码")
        val rb = TextView(this).apply {
            text = "刷新二维码"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            includeFontPadding = false
            setTextColor(C.PRIMARY)
            background = shape(C.SOFT, 26f)
        }
        click(rb) { confirmRefreshQr() }
        c4.card.addView(rb, ll(MATCH, px(52), 0f, 18))
        col.addView(c4.card, ll(MATCH, WRAP, 0f, 16))

        val sv = ScrollView(this).apply {
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(col)
        }
        settingsPage = FrameLayout(this).apply {
            setBackgroundColor(C.BG)
            visibility = View.GONE
            addView(sv, FrameLayout.LayoutParams(MATCH, MATCH))
        }
        updateSettingsUi()
    }

    private fun updateSettingsUi() {
        val custom = FileXfer.recvTree() != null
        dirSub.text = if (custom) FileXfer.recvLabel() else "下载/${FileXfer.DEFAULT_DIR}（Download/${FileXfer.DEFAULT_DIR}）"
        dirReset.visibility = if (custom) View.VISIBLE else View.GONE
        presetVal.text = PRESETS[presetIdx()].label + "  "
        audioSw.isChecked = audioOn()
        bgSw.isChecked = ListenService.enabled()
        ctlSub.text = if (InputService.enabled()) "已开启 · 其他安卓设备经你同意后可以控制本机" else "未开启 · 开启后，其他安卓设备经你同意才能控制本机"
    }

    private fun presetIdx(): Int = Link.prefs.getInt("preset", 0).coerceIn(0, PRESETS.size - 1)
    private fun audioOn(): Boolean = Link.prefs.getBoolean("audio", true)

    private fun pickPreset() {
        AlertDialog.Builder(this)
            .setTitle("投屏画质")
            .setSingleChoiceItems(PRESETS.map { it.label }.toTypedArray(), presetIdx()) { d, which ->
                Link.prefs.edit().putInt("preset", which).apply()
                updateSettingsUi()
                d.dismiss()
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun saveName() {
        val n = nameEt.text.toString().trim()
        if (n.isEmpty()) {
            Toast.makeText(this, "设备名称不能为空", Toast.LENGTH_SHORT).show()
            return
        }
        Link.updateName(n)
        nameEt.setText(n)
        nameEt.clearFocus()
        hideKeyboard()
        Toast.makeText(this, "已保存", Toast.LENGTH_SHORT).show()
        drawQr(true)
    }

    private fun openRecvDir() {
        val tries = ArrayList<Intent>()
        val tree = FileXfer.recvTree()
        if (tree != null) {
            try {
                val doc = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
                tries.add(Intent(Intent.ACTION_VIEW).setDataAndType(doc, DocumentsContract.Document.MIME_TYPE_DIR).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
            } catch (ignored: Exception) { }
        } else {
            val doc = Uri.parse("content://com.android.externalstorage.documents/document/" + Uri.encode("primary:Download/" + FileXfer.DEFAULT_DIR))
            tries.add(Intent(Intent.ACTION_VIEW).setDataAndType(doc, DocumentsContract.Document.MIME_TYPE_DIR))
        }
        tries.add(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
        for (i in tries) {
            try {
                startActivity(i)
                return
            } catch (ignored: Exception) { }
        }
        Toast.makeText(this, "请在文件管理器里打开「" + FileXfer.recvLabel() + "」", Toast.LENGTH_LONG).show()
    }

    /* ───────────── 已配对设备页 ───────────── */
    private fun buildPairedPage() {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(20), px(16), px(20), px(28))
        }
        col.addView(topBar("已配对设备"), ll(MATCH, px(48)))
        pairedBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(pairedBox, ll(MATCH, WRAP, 0f, 16))
        val sv = ScrollView(this).apply {
            overScrollMode = View.OVER_SCROLL_NEVER
            addView(col)
        }
        pairedPage = FrameLayout(this).apply {
            setBackgroundColor(C.BG)
            visibility = View.GONE
            addView(sv, FrameLayout.LayoutParams(MATCH, MATCH))
        }
    }

    private fun showPage(p: View) {
        home.visibility = if (p === home) View.VISIBLE else View.GONE
        settingsPage.visibility = if (p === settingsPage) View.VISIBLE else View.GONE
        pairedPage.visibility = if (p === pairedPage) View.VISIBLE else View.GONE
        if (p === settingsPage) {
            nameEt.setText(Link.name)
            updateSettingsUi()
        } else {
            hideKeyboard()
        }
        peersSig = ""
        renderPeers()
    }

    /* ═════════════ 状态 / 设备列表 ═════════════ */
    private fun status(msg: String) {
        statusTv.text = msg
        statusCard.visibility = if (msg.isEmpty()) View.GONE else View.VISIBLE
        ui.removeCallbacks(statusHide)
        ui.postDelayed(statusHide, 10_000)
        refreshUi()
    }

    private fun refreshUi() {
        val casting = CastService.current != null
        stopBtn.visibility = if (casting) View.VISIBLE else View.GONE
        if (casting) {
            if (statusTv.text.isEmpty()) statusTv.text = "正在投屏"
            statusCard.visibility = View.VISIBLE
        }
    }

    private fun refreshPeers() {
        val now = System.currentTimeMillis()
        Link.peers.values.removeAll { now - it.seen > 6000 }
        for (p in Link.pairs()) {
            val live = Link.peers[p.id]
            if (live != null && (live.ip != p.ip || live.port != p.port)) Link.savePair(p.copy(ip = live.ip, port = live.port))   // 对方换了 IP，自动跟上
        }
        renderPeers()
    }

    private fun renderPeers() {
        val paired = Link.pairs().sortedBy { it.name }
        val sb = StringBuilder()
        for (p in paired) {
            val live = Link.peers[p.id]
            sb.append(p.id).append('|').append(p.name).append('|').append(live?.ip ?: p.ip).append('|').append(live != null).append(';')
        }
        sb.append(pairedPage.visibility)
        val sig = sb.toString()
        if (sig == peersSig) return          // 没变化就不重建，避免点按时闪烁
        peersSig = sig

        peersBox.removeAllViews()
        if (paired.isEmpty()) {
            peersBox.addView(txt("还没有配对的设备", 15f, C.INK, true))
            peersBox.addView(txt("点上方「扫描设备二维码」，扫描另一台设备（电脑或手机）上瞬流显示的二维码即可配对。", 13f, C.SUB).apply {
                setLineSpacing(0f, 1.2f)
                setPadding(0, px(8), 0, 0)
            })
        } else {
            for ((i, p) in paired.take(3).withIndex()) {
                if (i > 0) peersBox.addView(View(this).apply { setBackgroundColor(C.CARD_LINE) }, ll(MATCH, px(1), 0f, 14))
                peersBox.addView(deviceRow(p, false), ll(MATCH, WRAP, 0f, if (i > 0) 14 else 0))
            }
        }

        pairedBox.removeAllViews()
        if (paired.isEmpty()) {
            pairedBox.addView(txt("还没有配对的设备。回到首页，点「扫描设备二维码」，扫描另一台设备（电脑或手机）上瞬流显示的二维码。", 14f, C.SUB).apply {
                setLineSpacing(0f, 1.2f)
                setPadding(px(4), px(8), px(4), 0)
            })
        } else {
            for (p in paired) {
                val c = card().apply { setPadding(px(20), px(18), px(20), px(18)) }
                c.addView(deviceRow(p, true), ll(MATCH, WRAP))
                pairedBox.addView(c, ll(MATCH, WRAP, 0f, 14))
            }
        }
    }

    private fun deviceRow(p: Paired, full: Boolean): View {
        val live = Link.peers[p.id]
        val online = live != null
        val ip = live?.ip ?: p.ip
        val port = live?.port ?: p.port
        val isWin = p.platform == "windows"

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val av = FrameLayout(this).apply { background = circle(C.SOFT) }
        av.addView(icon(if (isWin) "windows" else "phone", if (isWin) C.WIN_BLUE else C.PRIMARY), fl(px(26), px(26), Gravity.CENTER))
        row.addView(av, ll(px(52), px(52)))

        val mid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(px(12), 0, px(8), 0)
        }
        mid.addView(txt(p.name, 17f, C.INK, true).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        })
        val st = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, px(6), 0, 0)
        }
        st.addView(View(this).apply { background = circle(if (online) C.GREEN else C.GRAY) }, ll(px(8), px(8)))
        st.addView(txt(if (isWin) "Windows 设备" else "安卓设备", 13f, C.SUB).apply { setPadding(px(6), 0, 0, 0) })
        mid.addView(st)
        mid.addView(txt(if (online) "局域网直连 · 设备在线" else "设备离线", 12.5f, C.SUB).apply {
            maxLines = 1
            setPadding(0, px(6), 0, 0)
        })
        row.addView(mid, ll(0, WRAP, 1f))

        val btns = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        btns.addView(pill("发送文件", true) { sendTo(p) }, ll(px(92), px(32)))
        btns.addView(pill("屏幕互投", false) { connectDialog(p.name, ip, port, p.pin, p.platform) }, ll(px(92), px(32), 0f, 7))
        if (full) btns.addView(pill("取消配对", false, true) { confirmUnpair(p) }, ll(px(92), px(32), 0f, 7))
        row.addView(btns)
        row.setOnLongClickListener { confirmUnpair(p); true }
        return row
    }

    override fun onPeers() = refreshPeers()
    override fun onStatus(msg: String) = status(msg)

    /* ═════════════ 文件互传 ═════════════ */
    private fun sendTo(p: Paired) {
        pendingTarget = p
        pickLauncher.launch(arrayOf("*/*"))
    }

    private fun doSend(p: Paired, uris: List<Uri>) {
        val live = Link.peers[p.id]
        val host = live?.ip ?: p.ip
        val port = live?.port ?: p.port
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        FileXfer.sendFiles(host, port, p.pin, p.name, uris)
        status("正在向「" + p.name + "」发送 " + uris.size + " 个文件")
    }

    private fun makeRow(x: Xfer): XRow {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, px(14), 0, px(4))
        }
        val name = txt("", 14f, C.INK, true).apply {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.MIDDLE
        }
        val info = txt("", 12f, C.SUB).apply {
            setLineSpacing(0f, 1.15f)
            setPadding(0, px(4), 0, px(8))
        }
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000
            progressTintList = ColorStateList.valueOf(C.PRIMARY)
            progressBackgroundTintList = ColorStateList.valueOf(C.SOFT)
        }
        val btn = pill("取消", false) { FileXfer.cancel(x) }
        box.addView(name, ll(MATCH, WRAP))
        box.addView(info, ll(MATCH, WRAP))
        box.addView(bar, ll(MATCH, px(6)))
        box.addView(btn, ll(px(72), px(30), 0f, 10))
        return XRow(box, name, info, bar, btn)
    }

    private fun xferText(x: Xfer): String {
        return when (x.state) {
            "queued" -> "排队中"
            "offering" -> if (x.msg.isEmpty()) "等待对方确认…" else x.msg
            "sending", "receiving" -> {
                val pct = if (x.size > 0L) x.done.toDouble() * 100.0 / x.size.toDouble() else 100.0
                var t = "%.1f%% · %s / %s".format(pct, FileXfer.human(x.done), FileXfer.human(x.size))
                if (x.speed > 1.0) {
                    t += " · " + FileXfer.human(x.speed.toLong()) + "/s"
                    val left = ((x.size - x.done).toDouble() / x.speed).toLong()
                    t += " · 剩余 " + (if (left >= 3600L) (left / 3600L).toString() + " 小时 " + (left % 3600L / 60L).toString() + " 分" else if (left >= 60L) (left / 60L).toString() + " 分 " + (left % 60L).toString() + " 秒" else left.toString() + " 秒")
                }
                if (x.msg.isNotEmpty()) t += " · " + x.msg
                t
            }
            "verifying" -> if (x.msg.isEmpty()) "校验中…" else x.msg
            "done" -> x.msg + " · " + FileXfer.human(x.size)
            else -> x.msg
        }
    }

    private fun renderXfers() {
        val list = FileXfer.list
        xfersCard.visibility = if (list.isEmpty()) View.GONE else View.VISIBLE
        val seen = HashSet<Xfer>()
        var idx = 0
        for (x in list) {
            seen.add(x)
            val r = xRows[x] ?: makeRow(x).also { xRows[x] = it }
            r.name.text = (if (x.send) "↑ " else "↓ ") + x.name + "  ·  " + x.peer
            r.info.text = xferText(x)
            r.info.setTextColor(if (x.state == "failed") C.BAD else if (x.state == "done") C.OK else C.SUB)
            r.bar.progress = if (x.size > 0L) Math.min(1000L, x.done * 1000L / x.size).toInt() else (if (x.state == "done") 1000 else 0)
            r.btn.visibility = if (x.active) View.VISIBLE else View.GONE
            if (xfersBox.getChildAt(idx) !== r.box) {
                (r.box.parent as? ViewGroup)?.removeView(r.box)
                xfersBox.addView(r.box, idx)
            }
            idx++
        }
        val iter = xRows.entries.iterator()
        while (iter.hasNext()) {
            val ent = iter.next()
            if (!seen.contains(ent.key)) {
                xfersBox.removeView(ent.value.box)
                iter.remove()
            }
        }
    }

    /* ═════════════ 连接 ═════════════ */
    private fun connectDialog(title: String, host: String, port: Int, pin: String, platform: String) {
        val android = platform == "android"
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(host + " · 请选择要做什么" + (if (android) "（查看时可申请控制对方手机）" else ""))
            .setPositiveButton("查看对方屏幕") { _, _ -> viewPeer(host, port, pin, android) }
            .setNegativeButton("投出我的屏幕") { _, _ -> pushPeer(host, port, pin, android) }
            .setNeutralButton("取消", null)
            .show()
    }

    private fun confirmUnpair(p: Paired) {
        AlertDialog.Builder(this)
            .setTitle("取消配对")
            .setMessage("确定取消与「" + p.name + "」的配对吗？之后需要重新扫码才能再连接。")
            .setPositiveButton("取消配对") { _, _ ->
                Link.forgetPair(p.id)
                peersSig = ""
                refreshPeers()
            }
            .setNegativeButton("保留", null)
            .show()
    }

    /* ═════════════ 扫码配对 / 本机二维码 ═════════════ */
    private fun startScan() {
        val o = ScanOptions()
        o.setDesiredBarcodeFormats(listOf("QR_CODE"))
        o.setPrompt("")
        o.setBeepEnabled(false)
        o.setOrientationLocked(false)
        scanLauncher.launch(o)
    }

    private fun onScanned(text: String) {
        val q = Link.parseQr(text)
        if (q == null) {
            Toast.makeText(this, "这不是瞬流的配对二维码", Toast.LENGTH_LONG).show()
            return
        }
        if (q.id == Link.id) {
            Toast.makeText(this, "这是本机自己的二维码，请扫描另一台设备上的", Toast.LENGTH_LONG).show()
            return
        }
        status("正在与「" + q.name + "」配对…")
        thread(isDaemon = true) {
            try {
                val p = Link.pairWith(q)
                runOnUiThread {
                    status("已与「" + p.name + "」配对成功：现在可以互传文件、互相投屏了")
                    refreshPeers()
                    Toast.makeText(this, "配对成功", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                runOnUiThread { status("配对失败：" + (e.message ?: "未知错误")) }
            }
        }
    }

    /** 重新读取本机局域网 IP 并生成二维码；内容没变就不重画。 */
    private fun drawQr(force: Boolean) {
        qrNoNet = Link.lanIps().isEmpty()
        val text = Link.pairText()
        if (!force && text == qrLast) return
        try {
            qrIv.setImageBitmap(makeQr(text, qrSide))
            qrLast = text
        } catch (ignored: Exception) { }
        qrIv.alpha = if (qrNoNet) 0.25f else 1f
    }

    private fun updateQrSub() {
        qrSub.text = if (qrNoNet) "未连接局域网 · 请先连接 Wi-Fi" else "$qrLeft 秒后自动刷新 · 扫码一次, 双向互通"
    }

    private fun confirmRefreshQr() {
        AlertDialog.Builder(this)
            .setTitle("刷新二维码")
            .setMessage("会更换本机的配对密钥。刷新后，之前扫过码的设备需要重新扫码才能连接本机。")
            .setPositiveButton("刷新") { _, _ ->
                Link.newPin()
                qrLeft = QR_CYCLE
                drawQr(true)
                updateQrSub()
                status("配对密钥已刷新，之前扫过码的设备需要重新扫码")
            }
            .setNegativeButton("取消", null)
            .show()
    }

    private fun makeQr(text: String, size: Int): Bitmap {
        val hints = HashMap<EncodeHintType, Any>()
        hints[EncodeHintType.CHARACTER_SET] = "UTF-8"
        hints[EncodeHintType.MARGIN] = 1
        val bm = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size, hints)
        val w = bm.width
        val h = bm.height
        val px = IntArray(w * h)
        for (y in 0 until h) {
            for (x in 0 until w) px[y * w + x] = if (bm.get(x, y)) Color.BLACK else Color.WHITE
        }
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bmp.setPixels(px, 0, w, 0, 0, w, h)
        return bmp
    }

    /** 查看对方屏幕（手机作接收端） */
    private fun viewPeer(host: String, port: Int, pin: String, askCtl: Boolean) {
        if (Link.busy) { Toast.makeText(this, "正忙，请先结束当前会话", Toast.LENGTH_SHORT).show(); return }
        Link.busy = true
        status("连接中，等待对方允许…")
        thread(isDaemon = true) {
            try {
                val se = Session.connect(host, port, pin, "pull", Link.name, if (askCtl) "req" else "")
                runOnUiThread { enterViewer(se) }
            } catch (e: Exception) {
                Link.busy = false
                runOnUiThread { status("连接失败：${e.message}") }
            }
        }
    }

    /** 把手机屏幕投给对方（手机作发送端）：先申请权限和录屏授权，再由前台服务去连接 */
    private fun pushPeer(host: String, port: Int, pin: String, offerCtl: Boolean) {
        if (Link.busy) { Toast.makeText(this, "正忙，请先结束当前会话", Toast.LENGTH_SHORT).show(); return }
        if (!offerCtl) {
            Link.busy = true
            beginCast(CastReq("push", host, port, pin))
            return
        }
        AlertDialog.Builder(this)
            .setTitle("投出我的屏幕")
            .setMessage("要允许对方控制本机吗？" + (if (InputService.enabled()) "" else "\n\n本机还没开启「屏幕控制」服务（设置 → 屏幕控制），开启前对方只能看。") +
                "\n\n控制期间通知栏有「结束」按钮，可随时终止。")
            .setPositiveButton("允许控制") { _, _ -> Link.busy = true; beginCast(CastReq("push", host, port, pin, true)) }
            .setNegativeButton("仅投屏") { _, _ -> Link.busy = true; beginCast(CastReq("push", host, port, pin, false)) }
            .setNeutralButton("取消", null)
            .show()
    }

    private fun beginCast(req: CastReq) {
        pendingCast = req
        val need = ArrayList<String>()
        if (audioOn() && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (need.isEmpty()) launchProjection() else permLauncher.launch(need.toTypedArray())
    }

    private fun launchProjection() {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projLauncher.launch(mpm.createScreenCaptureIntent())
    }

    private fun onProjection(code: Int, data: Intent?) {
        val req = pendingCast ?: return
        pendingCast = null
        if (code != Activity.RESULT_OK || data == null) {
            Link.busy = false
            Link.pendingPull?.let { s -> Link.pendingPull = null; thread { s.reject("手机用户没有授权录屏") } }
            status("已取消")
            return
        }
        val withAudio = audioOn() && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val i = Intent(this, CastService::class.java).apply {
            putExtra("code", code)
            putExtra("data", data)
            putExtra("mode", req.mode)
            putExtra("host", req.host)
            putExtra("port", req.port)
            putExtra("pin", req.pin)
            putExtra("ctl", req.ctl)
            putExtra("audio", withAudio)
            putExtra("preset", presetIdx())
        }
        ContextCompat.startForegroundService(this, i)
        status("正在启动投屏…")
    }

    /** 有设备连进来（Link 在主线程回调）。返回 true 表示接管。 */
    override fun onIncoming(s: Session): Boolean {
        if (Link.busy || isFinishing) return false
        Link.busy = true
        when (s.mode) {
            "push" -> thread(isDaemon = true) {          // 对方把屏幕投给我：直接进入观看
                try {
                    s.accept()
                    runOnUiThread { enterViewer(s) }
                } catch (e: Exception) {
                    Link.busy = false
                }
            }
            "pull" -> {                                  // 对方想看我的屏幕：必须本人点允许
                val go = { ctl: Boolean ->
                    s.ctlAllowed = ctl
                    Link.pendingPull = s
                    beginCast(CastReq("pull"))
                }
                val b = AlertDialog.Builder(this).setTitle("屏幕共享请求").setCancelable(false)
                if (s.ctlReq) {
                    b.setMessage("「${s.peerName}」请求查看并控制本机屏幕。" +
                        (if (InputService.enabled()) "" else "\n\n本机还没开启「屏幕控制」服务（设置 → 屏幕控制），开启前对方只能查看。") +
                        "\n\n控制期间通知栏有「结束」按钮，可随时终止。")
                        .setPositiveButton("允许查看并控制") { _, _ -> go(true) }
                        .setNeutralButton("仅允许查看") { _, _ -> go(false) }
                } else {
                    b.setMessage("「${s.peerName}」请求查看本机屏幕，允许吗？")
                        .setPositiveButton("允许") { _, _ -> go(false) }
                }
                b.setNegativeButton("拒绝") { _, _ ->
                    Link.busy = false
                    thread { s.reject("对方拒绝了请求") }
                }.show()
            }
            else -> {
                Link.busy = false
                thread { s.reject("未知模式") }
            }
        }
        return true
    }

    /* ═════════════ 观看窗口 ═════════════ */
    private fun enterViewer(se: Session) {
        Link.busy = true
        viewing = true
        viewSession = se
        ctlBtn.visibility = if (se.canControl) View.VISIBLE else View.GONE
        setControl(false)
        vw = 0; vh = 0; mode = 0; panX = 0f; panY = 0f; manualRel = 1f
        home.visibility = View.GONE
        settingsPage.visibility = View.GONE
        pairedPage.visibility = View.GONE
        viewer.visibility = View.VISIBLE
        applyImmersive(true)
        val t = TextureView(this)
        tv = t
        viewer.addView(t, 0, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        statsTv.text = "等待画面…"
        Link.holdWifi(true)
        val s = ScreenSink(se, t, { w, h -> vw = w; vh = h; applyTransform() }, { r -> exitViewer(r) }, { txt -> statsTv.text = txt })
        sink = s
        s.start()
        Toast.makeText(this, "双击或捏合：完整显示 / 铺满；单指拖动可平移", Toast.LENGTH_LONG).show()
    }

    private fun exitViewer(reason: String) {
        if (!viewing) return
        viewing = false
        setControl(false)
        ctlBtn.visibility = View.GONE
        viewSession = null
        val s = sink
        sink = null
        s?.stop(reason)
        tv?.let { viewer.removeView(it) }
        tv = null
        viewer.visibility = View.GONE
        showPage(home)
        applyImmersive(false)
        Link.holdWifi(false)
        Link.busy = false
        status(reason)
    }

    /* ═════════════ 屏幕控制（观看方）═════════════
     * 控制模式下画面固定「完整显示」，单指的一笔触摸被记录成 [x,y,ms] 序列，抬手时作为一条 T_INPUT 发给对方，
     * 对方的无障碍服务按原速度回放（点按 / 滑动 / 长按都是同一种指令）。坐标用相对画面的 0..1，与分辨率、旋转无关。 */
    private fun setControl(on: Boolean) {
        ctlOn = on && viewSession?.canControl == true
        ctlBtn.text = if (ctlOn) "退出控制" else "控制"
        navBar.visibility = if (ctlOn) View.VISIBLE else View.GONE
        strokeBuf.clear()
        ctlDown = false
        ui.removeCallbacks(keepAlive)
        dot.hide()
        if (ctlOn) {
            mode = 1; panX = 0f; panY = 0f
            applyTransform()
            Toast.makeText(this, "控制模式：单指点按 / 滑动 / 长按，会在对方手机上执行", Toast.LENGTH_LONG).show()
        }
    }

    private fun sendInput(j: JSONObject) {
        val s = viewSession ?: return
        if (s.alive) s.sendHi(P.jsonPkt(P.T_INPUT, j))
    }

    /** 把触摸点换算成对方画面里的 0..1 坐标；落在画面外（黑边）返回 null。 */
    private fun norm(x: Float, y: Float): FloatArray? {
        val g = geom() ?: return null
        val dw = vw * g[0]
        val dh = vh * g[0]
        val nx = (x - (viewer.width - dw) / 2f) / dw
        val ny = (y - (viewer.height - dh) / 2f) / dh
        if (nx < 0f || nx > 1f || ny < 0f || ny > 1f) return null
        return floatArrayOf(nx, ny)
    }

    private fun r4(v: Float): Double = Math.round(v * 10000f) / 10000.0

    private fun flushMoves() {
        if (strokeBuf.isEmpty()) return
        val arr = JSONArray()
        for (p in strokeBuf) arr.put(JSONArray().put(r4(p[0])).put(r4(p[1])).put(p[2].toLong()))
        strokeBuf.clear()
        lastSendT = SystemClock.uptimeMillis()
        sendInput(JSONObject().put("t", "m").put("i", ctlSid).put("p", arr))
    }

    private val keepAlive = object : Runnable {            // 按住不动时每 500ms 告诉对方「手指还在」，对方才不会误判掉线
        override fun run() {
            if (!ctlDown) return
            if (SystemClock.uptimeMillis() - lastSendT >= 400L) {
                lastSendT = SystemClock.uptimeMillis()
                sendInput(JSONObject().put("t", "h").put("i", ctlSid))
            }
            ui.postDelayed(this, 500L)
        }
    }

    private fun endStroke(ev: MotionEvent) {
        if (!ctlDown) return
        flushMoves()
        val n = norm(ev.x, ev.y) ?: lastNorm
        if (n != null) sendInput(JSONObject().put("t", "u").put("i", ctlSid).put("x", r4(n[0])).put("y", r4(n[1])).put("d", ev.eventTime - strokeT0))
        ctlDown = false
        ui.removeCallbacks(keepAlive)
        dot.hide()
    }

    /** 实时跟手：按下 / 移动（批量，约 12ms 一包）/ 抬起，逐步发给对方，对方用连续笔画同步执行。 */
    private fun ctlTouch(ev: MotionEvent) {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val n = norm(ev.x, ev.y)
                if (n == null) { ctlDown = false; return }          // 按在黑边上：忽略
                ctlSid++
                ctlDown = true
                strokeBuf.clear()
                strokeT0 = ev.eventTime
                lastNorm = n
                lastSendT = SystemClock.uptimeMillis()
                sendInput(JSONObject().put("t", "d").put("i", ctlSid).put("x", r4(n[0])).put("y", r4(n[1])))
                dot.at(ev.x, ev.y)
                ui.removeCallbacks(keepAlive)
                ui.postDelayed(keepAlive, 500L)
            }
            MotionEvent.ACTION_MOVE -> if (ctlDown) {
                for (k in 0 until ev.historySize) {
                    val n = norm(ev.getHistoricalX(k), ev.getHistoricalY(k)) ?: continue
                    lastNorm = n
                    strokeBuf.add(floatArrayOf(n[0], n[1], (ev.getHistoricalEventTime(k) - strokeT0).toFloat()))
                }
                val n = norm(ev.x, ev.y)
                if (n != null) {
                    lastNorm = n
                    strokeBuf.add(floatArrayOf(n[0], n[1], (ev.eventTime - strokeT0).toFloat()))
                }
                dot.at(ev.x, ev.y)
                if (SystemClock.uptimeMillis() - lastSendT >= 12L || strokeBuf.size >= 24) flushMoves()
            }
            MotionEvent.ACTION_POINTER_DOWN -> endStroke(ev)         // 多指不支持：把当前这一笔抬起，等下一次单指按下
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> endStroke(ev)
        }
    }

    private fun showKeyboardDialog() {
        val et = EditText(this).apply { hint = "输入要发到对方当前输入框的文字" }
        AlertDialog.Builder(this)
            .setTitle("向对方输入文字")
            .setMessage("需要先在对方手机上点中一个输入框")
            .setView(et)
            .setPositiveButton("发送") { _, _ ->
                val s = et.text.toString()
                if (s.isNotEmpty()) sendInput(JSONObject().put("t", "e").put("op", "append").put("s", s))
            }
            .setNeutralButton("退格") { _, _ -> sendInput(JSONObject().put("t", "e").put("op", "del")) }
            .setNegativeButton("关闭", null)
            .show()
    }

    private fun applyImmersive(on: Boolean) {
        WindowCompat.setDecorFitsSystemWindows(window, !on)
        val c = WindowCompat.getInsetsController(window, window.decorView)
        val lp = window.attributes
        if (on) {
            c.hide(WindowInsetsCompat.Type.systemBars())
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        } else {
            c.show(WindowInsetsCompat.Type.systemBars())
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT
        }
        window.attributes = lp
    }

    /* ═════════════ 铺满策略（参考 YouTube） ═════════════
     * 完整显示：整幅画面可见（上下/左右留黑边）
     * 铺满裁剪：放大到填满屏幕，裁掉超出部分，可拖动平移
     * 自动：被裁掉的面积 ≤ autoLoss 才铺满（16:9 → 20:9 手机横屏约裁 20%），否则完整显示（竖屏手机 → 横屏电脑）
     * 捏合缩放结束后自动吸附到「完整显示 / 铺满」，双击在两者间切换
     */
    private fun geom(): FloatArray? {
        val w = viewer.width.toFloat()
        val h = viewer.height.toFloat()
        if (vw <= 0 || vh <= 0 || w <= 0f || h <= 0f) return null
        val fitS = min(w / vw, h / vh)
        val fillS = max(w / vw, h / vh)
        val ratio = fillS / fitS
        val rel = when (mode) {
            1 -> 1f
            2 -> ratio
            3 -> manualRel
            else -> if (1f - 1f / ratio <= autoLoss) ratio else 1f
        }
        return floatArrayOf(fitS, ratio, rel)
    }

    private fun applyTransform() {
        val t = tv ?: return
        val g = geom() ?: return
        val w = viewer.width.toFloat()
        val h = viewer.height.toFloat()
        val dw = vw * g[0] * g[2]
        val dh = vh * g[0] * g[2]
        val mx = max(0f, (dw - w) / 2f)
        val my = max(0f, (dh - h) / 2f)
        panX = panX.coerceIn(-mx, mx)
        panY = panY.coerceIn(-my, my)
        val m = Matrix()
        m.setScale(dw / w, dh / h, w / 2f, h / 2f)       // TextureView 默认把画面拉伸到整个控件，这里还原成正确比例
        m.postTranslate(panX, panY)
        t.setTransform(m)
    }

    private val scaleDet by lazy {
        ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                val g = geom() ?: return false
                manualRel = (g[2] * d.scaleFactor).coerceIn(1f, max(1f, g[1] * 4f))
                mode = 3
                applyTransform()
                return true
            }

            override fun onScaleEnd(d: ScaleGestureDetector) {
                val g = geom() ?: return
                if (manualRel < 1.05f) {
                    mode = 1; panX = 0f; panY = 0f
                } else if (abs(manualRel - g[1]) / g[1] < 0.05f) {
                    mode = 2
                }
                applyTransform()
            }
        })
    }

    private val gestDet by lazy {
        GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: MotionEvent): Boolean {
                val g = geom() ?: return false
                mode = if (g[2] > 1.01f) 1 else 2
                panX = 0f; panY = 0f
                applyTransform()
                return true
            }

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
                if (scaleDet.isInProgress) return false
                panX -= distanceX
                panY -= distanceY
                applyTransform()
                return true
            }
        })
    }
}
