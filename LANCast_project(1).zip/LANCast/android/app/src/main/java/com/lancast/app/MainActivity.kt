package com.lancast.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputFilter
import android.text.InputType
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class MainActivity : ComponentActivity(), Link.Listener {

    private data class CastReq(val mode: String, val host: String = "", val port: Int = 0, val pin: String = "")

    private lateinit var root: FrameLayout
    private lateinit var home: ScrollView
    private lateinit var viewer: FrameLayout
    private lateinit var infoTv: TextView
    private lateinit var pinTv: TextView
    private lateinit var peersBox: LinearLayout
    private lateinit var statusTv: TextView
    private lateinit var stopBtn: Button
    private lateinit var presetSp: Spinner
    private lateinit var audioCb: CheckBox
    private lateinit var statsTv: TextView
    private lateinit var xfersBox: LinearLayout
    private lateinit var xfersEmpty: TextView
    private class XRow(val box: LinearLayout, val name: TextView, val info: TextView, val bar: ProgressBar, val btn: Button)
    private val xRows = HashMap<Xfer, XRow>()
    private var tv: TextureView? = null
    private var sink: ScreenSink? = null
    private var viewing = false
    private var pendingCast: CastReq? = null
    private val ui = Handler(Looper.getMainLooper())

    /* 铺满状态（与 Windows 端一致）：mode 0=自动 1=完整显示 2=铺满裁剪 3=手动缩放 */
    private var vw = 0
    private var vh = 0
    private var mode = 0
    private var manualRel = 1f
    private var panX = 0f
    private var panY = 0f
    private val autoLoss = 0.22f              // 被裁掉的面积 ≤ 22% 时自动铺满

    private val projLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        onProjection(r.resultCode, r.data)
    }
    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { _ ->
        launchProjection()
    }

    private val pickLauncher = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris != null && uris.isNotEmpty()) sendDialog(uris)
    }
    private val notifLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { _ -> }

    private val tick = object : Runnable {
        override fun run() {
            refreshPeers()
            refreshUi()
            ui.postDelayed(this, 2000)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    /* ═════════════ 生命周期 ═════════════ */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Link.init(this)
        Link.start()
        buildUi()
        setContentView(root)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (viewing) {
                    exitViewer("已断开")
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    override fun onStart() {
        super.onStart()
        Link.listener = this
        FileXfer.listener = { renderXfers() }
        renderXfers()
        ui.post(tick)
    }

    override fun onStop() {
        super.onStop()
        Link.listener = null
        FileXfer.listener = null
        ui.removeCallbacks(tick)
        if (viewing) exitViewer("应用退到后台，已结束查看")
    }

    /* ═════════════ 界面 ═════════════ */
    private fun label(text: String, size: Float, bold: Boolean = false): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(Color.parseColor("#1c2733"))
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun buildUi() {
        val pad = dp(20)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        col.addView(label("LANCast", 24f, true))
        col.addView(label("安卓与 Windows 局域网互相投屏 · 文件互传", 13f).apply { setTextColor(Color.parseColor("#5d6b7a")) })

        infoTv = label("", 14f).apply { setPadding(0, dp(16), 0, 0) }
        col.addView(infoTv)
        val pinRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        pinTv = label(Link.pin, 32f, true).apply { letterSpacing = 0.12f }
        pinRow.addView(pinTv)
        pinRow.addView(Button(this).apply {
            text = "换一个"
            setOnClickListener { pinTv.text = Link.newPin() }
        })
        col.addView(pinRow)
        col.addView(label("对方连接本机时需要输入这组 PIN", 12f).apply { setTextColor(Color.parseColor("#5d6b7a")) })

        col.addView(label("画质", 15f, true).apply { setPadding(0, dp(20), 0, dp(4)) })
        presetSp = Spinner(this)
        presetSp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, PRESETS.map { it.label })
        presetSp.setSelection(Link.prefs.getInt("preset", 0).coerceIn(0, PRESETS.size - 1))
        presetSp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                Link.prefs.edit().putInt("preset", position).apply()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        col.addView(presetSp)
        audioCb = CheckBox(this).apply {
            text = "同时传输手机声音（无损 PCM）"
            isChecked = Link.prefs.getBoolean("audio", true)
            setOnCheckedChangeListener { _, c -> Link.prefs.edit().putBoolean("audio", c).apply() }
        }
        col.addView(audioCb)

        col.addView(label("附近的设备", 15f, true).apply { setPadding(0, dp(20), 0, dp(4)) })
        peersBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(peersBox)
        col.addView(Button(this).apply {
            text = "找不到设备？手动输入 IP"
            isAllCaps = false
            setOnClickListener { connectDialog("手动连接", null, P.PORT, "manual") }
        })

        col.addView(label("文件互传", 15f, true).apply { setPadding(0, dp(20), 0, dp(4)) })
        col.addView(label("不限大小、不限格式。传完后双方各算一遍 SHA-256 并比对，一致才算成功，保证和原文件逐字节相同；中途断线可自动续传。收到的文件在「下载/LANCast」文件夹。", 12f).apply {
            setTextColor(Color.parseColor("#5d6b7a"))
        })
        col.addView(Button(this).apply {
            text = "选择文件并发送…"
            isAllCaps = false
            setOnClickListener { pickLauncher.launch(arrayOf("*/*")) }
        })
        col.addView(Button(this).apply {
            text = "打开下载文件夹"
            isAllCaps = false
            setOnClickListener { openDownloads() }
        })
        xfersEmpty = label("还没有传输记录。电脑发来的文件会自动保存，也会显示在这里。", 12f).apply {
            setTextColor(Color.parseColor("#5d6b7a"))
            setPadding(0, dp(8), 0, dp(8))
        }
        col.addView(xfersEmpty)
        xfersBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(xfersBox)
        col.addView(Button(this).apply {
            text = "清除已结束的记录"
            isAllCaps = false
            setOnClickListener { FileXfer.clearFinished() }
        })

        statusTv = label("等待连接", 14f).apply {
            setTextColor(Color.parseColor("#0b6e8a"))
            setPadding(0, dp(16), 0, dp(4))
        }
        col.addView(statusTv)
        stopBtn = Button(this).apply {
            text = "结束投屏"
            visibility = View.GONE
            setOnClickListener { CastService.current?.shutdown("已手动结束") }
        }
        col.addView(stopBtn)

        home = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#e9edf1"))
            addView(col)
        }

        viewer = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            visibility = View.GONE
        }
        statsTv = TextView(this).apply {
            setTextColor(Color.parseColor("#dfe8ee"))
            setBackgroundColor(Color.parseColor("#b0141a21"))
            textSize = 11f
            setPadding(dp(8), dp(3), dp(8), dp(3))
        }
        viewer.addView(statsTv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.START or Gravity.BOTTOM).apply {
            leftMargin = dp(10); bottomMargin = dp(10)
        })
        viewer.addView(Button(this).apply {
            text = "断开"
            setOnClickListener { exitViewer("已断开") }
        }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.END or Gravity.TOP).apply {
            rightMargin = dp(10); topMargin = dp(10)
        })
        viewer.setOnTouchListener { _, ev ->
            scaleDet.onTouchEvent(ev)
            gestDet.onTouchEvent(ev)
            true
        }
        viewer.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> applyTransform() }

        root = FrameLayout(this)
        root.addView(home, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(viewer, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    private fun status(msg: String) {
        statusTv.text = msg
        refreshUi()
    }

    private fun refreshUi() {
        stopBtn.visibility = if (CastService.current != null) View.VISIBLE else View.GONE
        infoTv.text = "本机：${Link.name}\nIP：${Link.localIps().joinToString(" / ").ifEmpty { "未连接网络" }}"
    }

    private fun refreshPeers() {
        val now = System.currentTimeMillis()
        Link.peers.values.removeAll { now - it.seen > 6000 }
        peersBox.removeAllViews()
        if (Link.peers.isEmpty()) {
            peersBox.addView(label("还没有发现设备。请确认电脑上的 LANCast 已打开，并且在同一个 Wi-Fi 下。", 13f).apply {
                setTextColor(Color.parseColor("#5d6b7a"))
            })
            return
        }
        for (p in Link.peers.values.sortedBy { it.name }) {
            peersBox.addView(Button(this).apply {
                isAllCaps = false
                text = "${p.name}（${if (p.platform == "windows") "Windows" else "安卓"}  ${p.ip}）"
                setOnClickListener { connectDialog(p.name, p.ip, p.port, p.id) }
            })
        }
    }

    override fun onPeers() = refreshPeers()
    override fun onStatus(msg: String) = status(msg)

    /* ═════════════ 连接 ═════════════ */
    /* ═════════════ 文件互传 ═════════════ */
    private fun openDownloads() {
        try {
            startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
        } catch (e: Exception) {
            Toast.makeText(this, "请在文件管理器的「下载/LANCast」里查看", Toast.LENGTH_LONG).show()
        }
    }

    private fun sendDialog(uris: List<Uri>) {
        for (u in uris) {
            try { contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (ignored: Exception) { }
        }
        val peers = Link.peers.values.sortedBy { it.name }
        val names = ArrayList<String>()
        for (p in peers) names.add(p.name + "（" + (if (p.platform == "windows") "Windows" else "安卓") + " " + p.ip + "）")
        names.add("手动输入 IP…")
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val sp = Spinner(this)
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        val ipEt = EditText(this).apply {
            hint = "对方 IP，例如 192.168.1.20"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            visibility = View.GONE
        }
        val pinEt = EditText(this).apply {
            hint = "对方屏幕上显示的 6 位 PIN"
            inputType = InputType.TYPE_CLASS_NUMBER
            filters = arrayOf(InputFilter.LengthFilter(8))
        }
        fun keyOf(pos: Int): String = if (pos < peers.size) peers[pos].id else "manual"
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                ipEt.visibility = if (position >= peers.size) View.VISIBLE else View.GONE
                pinEt.setText(Link.prefs.getString("pin_" + keyOf(position), "") ?: "")
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        box.addView(label("发送 " + uris.size + " 个文件到：", 13f))
        box.addView(sp)
        box.addView(ipEt)
        box.addView(pinEt)
        AlertDialog.Builder(this)
            .setTitle("发送文件")
            .setView(box)
            .setNegativeButton("取消", null)
            .setPositiveButton("发送") { _, _ ->
                val pos = sp.selectedItemPosition
                val manual = pos >= peers.size
                val host = if (manual) ipEt.text.toString().trim() else peers[pos].ip
                val port = if (manual) P.PORT else peers[pos].port
                val peerName = if (manual) host else peers[pos].name
                val pin = pinEt.text.toString().trim()
                if (host.isEmpty() || pin.length < 4) {
                    Toast.makeText(this, "请填写对方 IP 和 PIN", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                Link.prefs.edit().putString("pin_" + keyOf(pos), pin).apply()
                if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
                FileXfer.sendFiles(host, port, pin, peerName, uris)
                statusTv.text = "正在向「" + peerName + "」发送 " + uris.size + " 个文件"
            }
            .show()
    }

    private fun makeRow(x: Xfer): XRow {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, dp(8))
        }
        val name = label("", 14f, true)
        val info = label("", 12f)
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 1000 }
        val btn = Button(this).apply {
            text = "取消"
            isAllCaps = false
            setOnClickListener { FileXfer.cancel(x) }
        }
        box.addView(name)
        box.addView(info)
        box.addView(bar)
        box.addView(btn)
        return XRow(box, name, info, bar, btn)
    }

    private fun xferText(x: Xfer): String {
        return when (x.state) {
            "queued" -> "排队中"
            "offering" -> if (x.msg.isEmpty()) "等待对方确认…" else x.msg
            "sending", "receiving" -> {
                val pct = if (x.size > 0L) x.done.toDouble() * 100.0 / x.size.toDouble() else 100.0
                var t = "%.1f%% · %s / %s".format(pct, FileXfer.human(x.done), FileXfer.human(x.size))
                if (x.speed > 1.0) {
                    t += " · " + FileXfer.human(x.speed.toLong()) + "/s"
                    val left = ((x.size - x.done).toDouble() / x.speed).toLong()
                    t += " · 剩余 " + (if (left >= 3600L) (left / 3600L).toString() + " 小时 " + (left % 3600L / 60L).toString() + " 分" else if (left >= 60L) (left / 60L).toString() + " 分 " + (left % 60L).toString() + " 秒" else left.toString() + " 秒")
                }
                if (x.msg.isNotEmpty()) t += " · " + x.msg
                t
            }
            "verifying" -> if (x.msg.isEmpty()) "校验中…" else x.msg
            "done" -> x.msg + " · " + FileXfer.human(x.size)
            else -> x.msg
        }
    }

    private fun renderXfers() {
        val list = FileXfer.list
        xfersEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        val seen = HashSet<Xfer>()
        var idx = 0
        for (x in list) {
            seen.add(x)
            val r = xRows[x] ?: makeRow(x).also { xRows[x] = it }
            r.name.text = (if (x.send) "↑ " else "↓ ") + x.name + "  ·  " + x.peer
            r.info.text = xferText(x)
            r.info.setTextColor(Color.parseColor(if (x.state == "failed") "#b3541e" else if (x.state == "done") "#1f7a3d" else "#5d6b7a"))
            r.bar.progress = if (x.size > 0L) Math.min(1000L, x.done * 1000L / x.size).toInt() else (if (x.state == "done") 1000 else 0)
            r.btn.visibility = if (x.active) View.VISIBLE else View.GONE
            if (xfersBox.getChildAt(idx) !== r.box) {
                (r.box.parent as? ViewGroup)?.removeView(r.box)
                xfersBox.addView(r.box, idx)
            }
            idx++
        }
        val iter = xRows.entries.iterator()
        while (iter.hasNext()) {
            val ent = iter.next()
            if (!seen.contains(ent.key)) {
                xfersBox.removeView(ent.value.box)
                iter.remove()
            }
        }
    }

    private fun connectDialog(title: String, host: String?, port: Int, key: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val ipEt = EditText(this).apply {
            hint = "对方 IP，例如 192.168.1.20"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        if (host == null) box.addView(ipEt)
        val pinEt = EditText(this).apply {
            hint = "对方屏幕上显示的 6 位 PIN"
            inputType = InputType.TYPE_CLASS_NUMBER
            filters = arrayOf(InputFilter.LengthFilter(8))
            setText(Link.prefs.getString("pin_$key", "") ?: "")
        }
        box.addView(pinEt)

        fun go(pull: Boolean) {
            val h = host ?: ipEt.text.toString().trim()
            val p = pinEt.text.toString().trim()
            if (h.isEmpty() || p.length < 4) {
                Toast.makeText(this, "请填写 IP 和 PIN", Toast.LENGTH_SHORT).show()
                return
            }
            Link.prefs.edit().putString("pin_$key", p).apply()
            if (pull) viewPeer(h, port, p) else pushPeer(h, port, p)
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(box)
            .setPositiveButton("查看对方屏幕") { _, _ -> go(true) }
            .setNegativeButton("投出我的屏幕") { _, _ -> go(false) }
            .setNeutralButton("取消", null)
            .show()
    }

    /** 查看对方屏幕（手机作接收端） */
    private fun viewPeer(host: String, port: Int, pin: String) {
        if (Link.busy) { Toast.makeText(this, "正忙，请先结束当前会话", Toast.LENGTH_SHORT).show(); return }
        Link.busy = true
        status("连接中，等待对方允许…")
        thread(isDaemon = true) {
            try {
                val se = Session.connect(host, port, pin, "pull", Link.name)
                runOnUiThread { enterViewer(se) }
            } catch (e: Exception) {
                Link.busy = false
                runOnUiThread { status("连接失败：${e.message}") }
            }
        }
    }

    /** 把手机屏幕投给对方（手机作发送端）：先申请权限和录屏授权，再由前台服务去连接 */
    private fun pushPeer(host: String, port: Int, pin: String) {
        if (Link.busy) { Toast.makeText(this, "正忙，请先结束当前会话", Toast.LENGTH_SHORT).show(); return }
        Link.busy = true
        beginCast(CastReq("push", host, port, pin))
    }

    private fun beginCast(req: CastReq) {
        pendingCast = req
        val need = ArrayList<String>()
        if (audioCb.isChecked && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (need.isEmpty()) launchProjection() else permLauncher.launch(need.toTypedArray())
    }

    private fun launchProjection() {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projLauncher.launch(mpm.createScreenCaptureIntent())
    }

    private fun onProjection(code: Int, data: Intent?) {
        val req = pendingCast ?: return
        pendingCast = null
        if (code != Activity.RESULT_OK || data == null) {
            Link.busy = false
            Link.pendingPull?.let { s -> Link.pendingPull = null; thread { s.reject("手机用户没有授权录屏") } }
            status("已取消")
            return
        }
        val withAudio = audioCb.isChecked && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val i = Intent(this, CastService::class.java).apply {
            putExtra("code", code)
            putExtra("data", data)
            putExtra("mode", req.mode)
            putExtra("host", req.host)
            putExtra("port", req.port)
            putExtra("pin", req.pin)
            putExtra("audio", withAudio)
            putExtra("preset", presetSp.selectedItemPosition)
        }
        ContextCompat.startForegroundService(this, i)
        status("正在启动投屏…")
    }

    /** 有设备连进来（Link 在主线程回调）。返回 true 表示接管。 */
    override fun onIncoming(s: Session): Boolean {
        if (Link.busy || isFinishing) return false
        Link.busy = true
        when (s.mode) {
            "push" -> thread(isDaemon = true) {          // 对方把屏幕投给我：直接进入观看
                try {
                    s.accept()
                    runOnUiThread { enterViewer(s) }
                } catch (e: Exception) {
                    Link.busy = false
                }
            }
            "pull" -> AlertDialog.Builder(this)          // 对方想看我的屏幕：必须本人点允许
                .setTitle("屏幕共享请求")
                .setMessage("「${s.peerName}」请求查看本机屏幕，允许吗？")
                .setCancelable(false)
                .setPositiveButton("允许") { _, _ ->
                    Link.pendingPull = s
                    beginCast(CastReq("pull"))
                }
                .setNegativeButton("拒绝") { _, _ ->
                    Link.busy = false
                    thread { s.reject("对方拒绝了请求") }
                }
                .show()
            else -> {
                Link.busy = false
                thread { s.reject("未知模式") }
            }
        }
        return true
    }

    /* ═════════════ 观看窗口 ═════════════ */
    private fun enterViewer(se: Session) {
        Link.busy = true
        viewing = true
        vw = 0; vh = 0; mode = 0; panX = 0f; panY = 0f; manualRel = 1f
        home.visibility = View.GONE
        viewer.visibility = View.VISIBLE
        applyImmersive(true)
        val t = TextureView(this)
        tv = t
        viewer.addView(t, 0, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        statsTv.text = "等待画面…"
        Link.holdWifi(true)
        val s = ScreenSink(se, t, { w, h -> vw = w; vh = h; applyTransform() }, { r -> exitViewer(r) }, { txt -> statsTv.text = txt })
        sink = s
        s.start()
        Toast.makeText(this, "双击或捏合：完整显示 / 铺满；单指拖动可平移", Toast.LENGTH_LONG).show()
    }

    private fun exitViewer(reason: String) {
        if (!viewing) return
        viewing = false
        val s = sink
        sink = null
        s?.stop(reason)
        tv?.let { viewer.removeView(it) }
        tv = null
        viewer.visibility = View.GONE
        home.visibility = View.VISIBLE
        applyImmersive(false)
        Link.holdWifi(false)
        Link.busy = false
        status(reason)
    }

    private fun applyImmersive(on: Boolean) {
        WindowCompat.setDecorFitsSystemWindows(window, !on)
        val c = WindowCompat.getInsetsController(window, window.decorView)
        val lp = window.attributes
        if (on) {
            c.hide(WindowInsetsCompat.Type.systemBars())
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        } else {
            c.show(WindowInsetsCompat.Type.systemBars())
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT
        }
        window.attributes = lp
    }

    /* ═════════════ 铺满策略（参考 YouTube） ═════════════
     * 完整显示：整幅画面可见（上下/左右留黑边）
     * 铺满裁剪：放大到填满屏幕，裁掉超出部分，可拖动平移
     * 自动：被裁掉的面积 ≤ autoLoss 才铺满（16:9 → 20:9 手机横屏约裁 20%），否则完整显示（竖屏手机 → 横屏电脑）
     * 捏合缩放结束后自动吸附到「完整显示 / 铺满」，双击在两者间切换
     */
    private fun geom(): FloatArray? {
        val w = viewer.width.toFloat()
        val h = viewer.height.toFloat()
        if (vw <= 0 || vh <= 0 || w <= 0f || h <= 0f) return null
        val fitS = min(w / vw, h / vh)
        val fillS = max(w / vw, h / vh)
        val ratio = fillS / fitS
        val rel = when (mode) {
            1 -> 1f
            2 -> ratio
            3 -> manualRel
            else -> if (1f - 1f / ratio <= autoLoss) ratio else 1f
        }
        return floatArrayOf(fitS, ratio, rel)
    }

    private fun applyTransform() {
        val t = tv ?: return
        val g = geom() ?: return
        val w = viewer.width.toFloat()
        val h = viewer.height.toFloat()
        val dw = vw * g[0] * g[2]
        val dh = vh * g[0] * g[2]
        val mx = max(0f, (dw - w) / 2f)
        val my = max(0f, (dh - h) / 2f)
        panX = panX.coerceIn(-mx, mx)
        panY = panY.coerceIn(-my, my)
        val m = Matrix()
        m.setScale(dw / w, dh / h, w / 2f, h / 2f)       // TextureView 默认把画面拉伸到整个控件，这里还原成正确比例
        m.postTranslate(panX, panY)
        t.setTransform(m)
    }

    private val scaleDet by lazy {
        ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                val g = geom() ?: return false
                manualRel = (g[2] * d.scaleFactor).coerceIn(1f, max(1f, g[1] * 4f))
                mode = 3
                applyTransform()
                return true
            }

            override fun onScaleEnd(d: ScaleGestureDetector) {
                val g = geom() ?: return
                if (manualRel < 1.05f) {
                    mode = 1; panX = 0f; panY = 0f
                } else if (abs(manualRel - g[1]) / g[1] < 0.05f) {
                    mode = 2
                }
                applyTransform()
            }
        })
    }

    private val gestDet by lazy {
        GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: MotionEvent): Boolean {
                val g = geom() ?: return false
                mode = if (g[2] > 1.01f) 1 else 2
                panX = 0f; panY = 0f
                applyTransform()
                return true
            }

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
                if (scaleDet.isInProgress) return false
                panX -= distanceX
                panY -= distanceY
                applyTransform()
                return true
            }
        })
    }
}
