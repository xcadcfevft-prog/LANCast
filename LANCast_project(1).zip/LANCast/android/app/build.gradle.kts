plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.lancast.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.lancast.app"
        minSdk = 29            // AudioPlaybackCapture(无损采集系统声音) 需要 Android 10+
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-ktx:1.9.2")
    implementation("com.journeyapps:zxing-android-embedded:4.3.0")   // 扫码（自带取景界面，不依赖 Google 服务）
    implementation("com.google.zxing:core:3.5.3")                    // 生成二维码
}
