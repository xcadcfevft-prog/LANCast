// LANCast 握手协议自检（Node 18+，无依赖）：  node docs/protocol-selftest.js
// 按 docs/PROTOCOL.md 的规范实现一个 v2 对端，并用「与 windows/renderer.js 完全相同的 v1 握手」去连它，
// 同时验证 v2 客户端连 v1 服务端（Windows）也能成功。这里不测 Kotlin 代码，只验证规范本身自洽且向后兼容。
const net = require('net'), crypto = require('crypto');
const HDR = 16, T = { HELLO: 1, CHALLENGE: 2, ACCEPT: 3, REJECT: 4 };
const hmac = (k, m) => crypto.createHmac('sha256', k).update(m).digest('hex');
const pkt = (type, obj) => { const b = Buffer.from(JSON.stringify(obj)); const h = Buffer.alloc(HDR); h[0] = type; h.writeUInt32BE(b.length, 4); return Buffer.concat([h, b]); };
function reader(sock, onPkt) {
  let buf = Buffer.alloc(0);
  sock.on('data', d => { buf = Buffer.concat([buf, d]);
    while (buf.length >= HDR) { const n = buf.readUInt32BE(4); if (buf.length < HDR + n) break;
      onPkt(buf[0], JSON.parse(buf.slice(HDR, HDR + n).toString())); buf = buf.slice(HDR + n); } });
}
// —— 服务端：v2（Android）或 v1（Windows），由 ver 参数决定 ——
function startServer(pin, ver) {
  return new Promise(res => {
    const srv = net.createServer(sock => {
      const nonce = crypto.randomBytes(16).toString('hex');
      const ch = { nonce, name: 'srv', platform: ver === 2 ? 'android' : 'windows' };
      if (ver === 2) Object.assign(ch, { ver: 2, id: 'srvid0001', caps: ['file', 'proof'] });
      sock.write(pkt(T.CHALLENGE, ch));
      reader(sock, (t, j) => {
        if (t !== T.HELLO) return;
        if (j.auth !== hmac(pin, nonce)) { sock.write(pkt(T.REJECT, { reason: 'bad auth' })); return; }
        const acc = { ok: true };
        if (ver === 2 && (j.ver || 1) >= 2 && /^[0-9a-f]{16,64}$/.test(j.cn || '')) { acc.ver = 2; acc.proof = hmac(pin, 'srv:' + nonce + ':' + j.cn); }
        sock.write(pkt(T.ACCEPT, acc)); setTimeout(() => sock.end(), 50);
      });
    }).listen(0, '127.0.0.1', () => res(srv));
  });
}
// —— 客户端：v1 = 原 Windows 握手；v2 = 新握手（含 cn，校验 proof） ——
function connect(port, pin, ver) {
  return new Promise((resolve, reject) => {
    const s = net.connect(port, '127.0.0.1'); const cn = crypto.randomBytes(16).toString('hex'); let ch;
    s.on('error', reject);
    reader(s, (t, j) => {
      if (t === T.CHALLENGE) { ch = j;
        const h = { ver: ver, name: 'cli', platform: ver === 2 ? 'android' : 'windows', mode: 'file', auth: hmac(pin, j.nonce) };
        if (ver === 2) Object.assign(h, { id: 'cliid0001', caps: ['file'], cn });
        s.write(pkt(T.HELLO, h));
      } else if (t === T.ACCEPT) {
        const proofOk = j.proof === hmac(pin, 'srv:' + ch.nonce + ':' + cn);
        if (ver === 2 && (ch.ver || 1) >= 2 && !proofOk) return reject(new Error('proof 校验失败'));
        resolve({ proofOk, srvVer: ch.ver || 1 }); s.destroy();
      } else if (t === T.REJECT) reject(new Error(j.reason));
    });
  });
}
(async () => {
  const pin = '4815162342', bad = [];
  const check = (name, ok) => { console.log((ok ? 'PASS ' : 'FAIL ') + name); if (!ok) bad.push(name); };
  const v2 = await startServer(pin, 2), v1 = await startServer(pin, 1);
  const p2 = v2.address().port, p1 = v1.address().port;
  let r;
  r = await connect(p2, pin, 2); check('v2 客户端 → v2 服务端：proof 通过', r.proofOk && r.srvVer === 2);
  r = await connect(p2, pin, 1); check('v1 客户端（现有 Windows 握手）→ v2 服务端：照常成功、无 proof', !r.proofOk);
  r = await connect(p1, pin, 2); check('v2 客户端 → v1 服务端（Windows）：照常成功、不要求 proof', !r.proofOk && r.srvVer === 1);
  r = await connect(p1, pin, 1); check('v1 ↔ v1：原行为不变', !r.proofOk);
  try { await connect(p2, '0000000000', 2); check('错误密钥应被拒绝', false); } catch (e) { check('错误密钥被拒绝：' + e.message, true); }
  // 冒充的服务端：宣称 v2 但不知道密钥，给不出正确 proof
  const fake = await new Promise(res => { const f = net.createServer(sock => {
    const nonce = crypto.randomBytes(16).toString('hex');
    sock.write(pkt(T.CHALLENGE, { nonce, name: 'evil', platform: 'android', ver: 2 }));
    reader(sock, (t, j) => { if (t === T.HELLO) sock.write(pkt(T.ACCEPT, { ok: true, ver: 2, proof: hmac('guess', 'srv:' + nonce + ':' + j.cn) })); });
  }).listen(0, '127.0.0.1', () => res(f)); });
  try { await connect(fake.address().port, pin, 2); check('冒充的 v2 服务端应被识破', false); } catch (e) { check('冒充的 v2 服务端被识破：' + e.message, true); }
  [v2, v1, fake].forEach(s => s.close());
  console.log(bad.length ? '\n有 ' + bad.length + ' 项失败' : '\n全部通过'); process.exit(bad.length ? 1 : 0);
})();
