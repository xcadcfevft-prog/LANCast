package com.lancast.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputFilter
import android.text.InputType
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import kotlin.concurrent.thread
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

class MainActivity : ComponentActivity(), Link.Listener {

    private data class CastReq(val mode: String, val host: String = "", val port: Int = 0, val pin: String = "")

    private lateinit var root: FrameLayout
    private lateinit var home: ScrollView
    private lateinit var viewer: FrameLayout
    private lateinit var infoTv: TextView
    private lateinit var pinTv: TextView
    private lateinit var peersBox: LinearLayout
    private lateinit var statusTv: TextView
    private lateinit var stopBtn: Button
    private lateinit var presetSp: Spinner
    private lateinit var audioCb: CheckBox
    private lateinit var statsTv: TextView
    private var tv: TextureView? = null
    private var sink: ScreenSink? = null
    private var viewing = false
    private var pendingCast: CastReq? = null
    private val ui = Handler(Looper.getMainLooper())

    /* 铺满状态（与 Windows 端一致）：mode 0=自动 1=完整显示 2=铺满裁剪 3=手动缩放 */
    private var vw = 0
    private var vh = 0
    private var mode = 0
    private var manualRel = 1f
    private var panX = 0f
    private var panY = 0f
    private val autoLoss = 0.22f              // 被裁掉的面积 ≤ 22% 时自动铺满

    private val projLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        onProjection(r.resultCode, r.data)
    }
    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { _ ->
        launchProjection()
    }

    private val tick = object : Runnable {
        override fun run() {
            refreshPeers()
            refreshUi()
            ui.postDelayed(this, 2000)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    /* ═════════════ 生命周期 ═════════════ */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Link.init(this)
        Link.start()
        buildUi()
        setContentView(root)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (viewing) {
                    exitViewer("已断开")
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    override fun onStart() {
        super.onStart()
        Link.listener = this
        ui.post(tick)
    }

    override fun onStop() {
        super.onStop()
        Link.listener = null
        ui.removeCallbacks(tick)
        if (viewing) exitViewer("应用退到后台，已结束查看")
    }

    /* ═════════════ 界面 ═════════════ */
    private fun label(text: String, size: Float, bold: Boolean = false): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(Color.parseColor("#1c2733"))
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun buildUi() {
        val pad = dp(20)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        col.addView(label("LANCast", 24f, true))
        col.addView(label("安卓与 Windows 局域网互相投屏", 13f).apply { setTextColor(Color.parseColor("#5d6b7a")) })

        infoTv = label("", 14f).apply { setPadding(0, dp(16), 0, 0) }
        col.addView(infoTv)
        val pinRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        pinTv = label(Link.pin, 32f, true).apply { letterSpacing = 0.12f }
        pinRow.addView(pinTv)
        pinRow.addView(Button(this).apply {
            text = "换一个"
            setOnClickListener { pinTv.text = Link.newPin() }
        })
        col.addView(pinRow)
        col.addView(label("对方连接本机时需要输入这组 PIN", 12f).apply { setTextColor(Color.parseColor("#5d6b7a")) })

        col.addView(label("画质", 15f, true).apply { setPadding(0, dp(20), 0, dp(4)) })
        presetSp = Spinner(this)
        presetSp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, PRESETS.map { it.label })
        presetSp.setSelection(Link.prefs.getInt("preset", 0).coerceIn(0, PRESETS.size - 1))
        presetSp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                Link.prefs.edit().putInt("preset", position).apply()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
        col.addView(presetSp)
        audioCb = CheckBox(this).apply {
            text = "同时传输手机声音（无损 PCM）"
            isChecked = Link.prefs.getBoolean("audio", true)
            setOnCheckedChangeListener { _, c -> Link.prefs.edit().putBoolean("audio", c).apply() }
        }
        col.addView(audioCb)

        col.addView(label("附近的设备", 15f, true).apply { setPadding(0, dp(20), 0, dp(4)) })
        peersBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(peersBox)
        col.addView(Button(this).apply {
            text = "找不到设备？手动输入 IP"
            isAllCaps = false
            setOnClickListener { connectDialog("手动连接", null, P.PORT, "manual") }
        })

        statusTv = label("等待连接", 14f).apply {
            setTextColor(Color.parseColor("#0b6e8a"))
            setPadding(0, dp(16), 0, dp(4))
        }
        col.addView(statusTv)
        stopBtn = Button(this).apply {
            text = "结束投屏"
            visibility = View.GONE
            setOnClickListener { CastService.current?.shutdown("已手动结束") }
        }
        col.addView(stopBtn)

        home = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#e9edf1"))
            addView(col)
        }

        viewer = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            visibility = View.GONE
        }
        statsTv = TextView(this).apply {
            setTextColor(Color.parseColor("#dfe8ee"))
            setBackgroundColor(Color.parseColor("#b0141a21"))
            textSize = 11f
            setPadding(dp(8), dp(3), dp(8), dp(3))
        }
        viewer.addView(statsTv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.START or Gravity.BOTTOM).apply {
            leftMargin = dp(10); bottomMargin = dp(10)
        })
        viewer.addView(Button(this).apply {
            text = "断开"
            setOnClickListener { exitViewer("已断开") }
        }, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.END or Gravity.TOP).apply {
            rightMargin = dp(10); topMargin = dp(10)
        })
        viewer.setOnTouchListener { _, ev ->
            scaleDet.onTouchEvent(ev)
            gestDet.onTouchEvent(ev)
            true
        }
        viewer.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> applyTransform() }

        root = FrameLayout(this)
        root.addView(home, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root.addView(viewer, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
    }

    private fun status(msg: String) {
        statusTv.text = msg
        refreshUi()
    }

    private fun refreshUi() {
        stopBtn.visibility = if (CastService.current != null) View.VISIBLE else View.GONE
        infoTv.text = "本机：${Link.name}\nIP：${Link.localIps().joinToString(" / ").ifEmpty { "未连接网络" }}"
    }

    private fun refreshPeers() {
        val now = System.currentTimeMillis()
        Link.peers.values.removeAll { now - it.seen > 6000 }
        peersBox.removeAllViews()
        if (Link.peers.isEmpty()) {
            peersBox.addView(label("还没有发现设备。请确认电脑上的 LANCast 已打开，并且在同一个 Wi-Fi 下。", 13f).apply {
                setTextColor(Color.parseColor("#5d6b7a"))
            })
            return
        }
        for (p in Link.peers.values.sortedBy { it.name }) {
            peersBox.addView(Button(this).apply {
                isAllCaps = false
                text = "${p.name}（${if (p.platform == "windows") "Windows" else "安卓"}  ${p.ip}）"
                setOnClickListener { connectDialog(p.name, p.ip, p.port, p.id) }
            })
        }
    }

    override fun onPeers() = refreshPeers()
    override fun onStatus(msg: String) = status(msg)

    /* ═════════════ 连接 ═════════════ */
    private fun connectDialog(title: String, host: String?, port: Int, key: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }
        val ipEt = EditText(this).apply {
            hint = "对方 IP，例如 192.168.1.20"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        if (host == null) box.addView(ipEt)
        val pinEt = EditText(this).apply {
            hint = "对方屏幕上显示的 6 位 PIN"
            inputType = InputType.TYPE_CLASS_NUMBER
            filters = arrayOf(InputFilter.LengthFilter(8))
            setText(Link.prefs.getString("pin_$key", "") ?: "")
        }
        box.addView(pinEt)

        fun go(pull: Boolean) {
            val h = host ?: ipEt.text.toString().trim()
            val p = pinEt.text.toString().trim()
            if (h.isEmpty() || p.length < 4) {
                Toast.makeText(this, "请填写 IP 和 PIN", Toast.LENGTH_SHORT).show()
                return
            }
            Link.prefs.edit().putString("pin_$key", p).apply()
            if (pull) viewPeer(h, port, p) else pushPeer(h, port, p)
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(box)
            .setPositiveButton("查看对方屏幕") { _, _ -> go(true) }
            .setNegativeButton("投出我的屏幕") { _, _ -> go(false) }
            .setNeutralButton("取消", null)
            .show()
    }

    /** 查看对方屏幕（手机作接收端） */
    private fun viewPeer(host: String, port: Int, pin: String) {
        if (Link.busy) { Toast.makeText(this, "正忙，请先结束当前会话", Toast.LENGTH_SHORT).show(); return }
        Link.busy = true
        status("连接中，等待对方允许…")
        thread(isDaemon = true) {
            try {
                val se = Session.connect(host, port, pin, "pull", Link.name)
                runOnUiThread { enterViewer(se) }
            } catch (e: Exception) {
                Link.busy = false
                runOnUiThread { status("连接失败：${e.message}") }
            }
        }
    }

    /** 把手机屏幕投给对方（手机作发送端）：先申请权限和录屏授权，再由前台服务去连接 */
    private fun pushPeer(host: String, port: Int, pin: String) {
        if (Link.busy) { Toast.makeText(this, "正忙，请先结束当前会话", Toast.LENGTH_SHORT).show(); return }
        Link.busy = true
        beginCast(CastReq("push", host, port, pin))
    }

    private fun beginCast(req: CastReq) {
        pendingCast = req
        val need = ArrayList<String>()
        if (audioCb.isChecked && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) need.add(Manifest.permission.POST_NOTIFICATIONS)
        if (need.isEmpty()) launchProjection() else permLauncher.launch(need.toTypedArray())
    }

    private fun launchProjection() {
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projLauncher.launch(mpm.createScreenCaptureIntent())
    }

    private fun onProjection(code: Int, data: Intent?) {
        val req = pendingCast ?: return
        pendingCast = null
        if (code != Activity.RESULT_OK || data == null) {
            Link.busy = false
            Link.pendingPull?.let { s -> Link.pendingPull = null; thread { s.reject("手机用户没有授权录屏") } }
            status("已取消")
            return
        }
        val withAudio = audioCb.isChecked && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val i = Intent(this, CastService::class.java).apply {
            putExtra("code", code)
            putExtra("data", data)
            putExtra("mode", req.mode)
            putExtra("host", req.host)
            putExtra("port", req.port)
            putExtra("pin", req.pin)
            putExtra("audio", withAudio)
            putExtra("preset", presetSp.selectedItemPosition)
        }
        ContextCompat.startForegroundService(this, i)
        status("正在启动投屏…")
    }

    /** 有设备连进来（Link 在主线程回调）。返回 true 表示接管。 */
    override fun onIncoming(s: Session): Boolean {
        if (Link.busy || isFinishing) return false
        Link.busy = true
        when (s.mode) {
            "push" -> thread(isDaemon = true) {          // 对方把屏幕投给我：直接进入观看
                try {
                    s.accept()
                    runOnUiThread { enterViewer(s) }
                } catch (e: Exception) {
                    Link.busy = false
                }
            }
            "pull" -> AlertDialog.Builder(this)          // 对方想看我的屏幕：必须本人点允许
                .setTitle("屏幕共享请求")
                .setMessage("「${s.peerName}」请求查看本机屏幕，允许吗？")
                .setCancelable(false)
                .setPositiveButton("允许") { _, _ ->
                    Link.pendingPull = s
                    beginCast(CastReq("pull"))
                }
                .setNegativeButton("拒绝") { _, _ ->
                    Link.busy = false
                    thread { s.reject("对方拒绝了请求") }
                }
                .show()
            else -> {
                Link.busy = false
                thread { s.reject("未知模式") }
            }
        }
        return true
    }

    /* ═════════════ 观看窗口 ═════════════ */
    private fun enterViewer(se: Session) {
        Link.busy = true
        viewing = true
        vw = 0; vh = 0; mode = 0; panX = 0f; panY = 0f; manualRel = 1f
        home.visibility = View.GONE
        viewer.visibility = View.VISIBLE
        setImmersive(true)
        val t = TextureView(this)
        tv = t
        viewer.addView(t, 0, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        statsTv.text = "等待画面…"
        Link.holdWifi(true)
        val s = ScreenSink(se, t, { w, h -> vw = w; vh = h; applyTransform() }, { r -> exitViewer(r) }, { txt -> statsTv.text = txt })
        sink = s
        s.start()
        Toast.makeText(this, "双击或捏合：完整显示 / 铺满；单指拖动可平移", Toast.LENGTH_LONG).show()
    }

    private fun exitViewer(reason: String) {
        if (!viewing) return
        viewing = false
        val s = sink
        sink = null
        s?.stop(reason)
        tv?.let { viewer.removeView(it) }
        tv = null
        viewer.visibility = View.GONE
        home.visibility = View.VISIBLE
        setImmersive(false)
        Link.holdWifi(false)
        Link.busy = false
        status(reason)
    }

    private fun setImmersive(on: Boolean) {
        WindowCompat.setDecorFitsSystemWindows(window, !on)
        val c = WindowCompat.getInsetsController(window, window.decorView)
        val lp = window.attributes
        if (on) {
            c.hide(WindowInsetsCompat.Type.systemBars())
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        } else {
            c.show(WindowInsetsCompat.Type.systemBars())
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT
        }
        window.attributes = lp
    }

    /* ═════════════ 铺满策略（参考 YouTube） ═════════════
     * 完整显示：整幅画面可见（上下/左右留黑边）
     * 铺满裁剪：放大到填满屏幕，裁掉超出部分，可拖动平移
     * 自动：被裁掉的面积 ≤ autoLoss 才铺满（16:9 → 20:9 手机横屏约裁 20%），否则完整显示（竖屏手机 → 横屏电脑）
     * 捏合缩放结束后自动吸附到「完整显示 / 铺满」，双击在两者间切换
     */
    private fun geom(): FloatArray? {
        val w = viewer.width.toFloat()
        val h = viewer.height.toFloat()
        if (vw <= 0 || vh <= 0 || w <= 0f || h <= 0f) return null
        val fitS = min(w / vw, h / vh)
        val fillS = max(w / vw, h / vh)
        val ratio = fillS / fitS
        val rel = when (mode) {
            1 -> 1f
            2 -> ratio
            3 -> manualRel
            else -> if (1f - 1f / ratio <= autoLoss) ratio else 1f
        }
        return floatArrayOf(fitS, ratio, rel)
    }

    private fun applyTransform() {
        val t = tv ?: return
        val g = geom() ?: return
        val w = viewer.width.toFloat()
        val h = viewer.height.toFloat()
        val dw = vw * g[0] * g[2]
        val dh = vh * g[0] * g[2]
        val mx = max(0f, (dw - w) / 2f)
        val my = max(0f, (dh - h) / 2f)
        panX = panX.coerceIn(-mx, mx)
        panY = panY.coerceIn(-my, my)
        val m = Matrix()
        m.setScale(dw / w, dh / h, w / 2f, h / 2f)       // TextureView 默认把画面拉伸到整个控件，这里还原成正确比例
        m.postTranslate(panX, panY)
        t.setTransform(m)
    }

    private val scaleDet by lazy {
        ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                val g = geom() ?: return false
                manualRel = (g[2] * d.scaleFactor).coerceIn(1f, max(1f, g[1] * 4f))
                mode = 3
                applyTransform()
                return true
            }

            override fun onScaleEnd(d: ScaleGestureDetector) {
                val g = geom() ?: return
                if (manualRel < 1.05f) {
                    mode = 1; panX = 0f; panY = 0f
                } else if (abs(manualRel - g[1]) / g[1] < 0.05f) {
                    mode = 2
                }
                applyTransform()
            }
        })
    }

    private val gestDet by lazy {
        GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: MotionEvent): Boolean {
                val g = geom() ?: return false
                mode = if (g[2] > 1.01f) 1 else 2
                panX = 0f; panY = 0f
                applyTransform()
                return true
            }

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
                if (scaleDet.isInProgress) return false
                panX -= distanceX
                panY -= distanceY
                applyTransform()
                return true
            }
        })
    }
}
